# Issue 122 — stable platform integration

Owner: [issue122](https://github.com/oborskyivitalii/oborskyivitalii/issues/122).
This continues the prepared platform source, not a new delivery framework.
Base: protected main `bea2628`; preserved preparation: `5a89989`, integrating
PR79's `86a2704`. The exact runtime/producer freeze remains in the
[delivered compatibility review](2026-10-24-r3-runtime-compatibility.md).
This file records root implementation/self-analysis and the distinct reviews below.
Clean local source checkpoint210cb5/treeb966e013 was independently reviewed; the
subsequent aggregate-budget correction is separately reviewed below. Final metadata
refresh and native delivery remain pending at this versioned freeze.

## Intent and acceptance

Deliver the already prepared platform integration through the existing full route
to establish accepted S. Preserve delivered R1/R2, the fourteen frozen producer
objects, current budgets and the existing publisher. Finish catalog, generated
output, RI and source-bound independent review in this delivery.

Parent AC02 is already delivered. AC03/06 retain actual independent content,
complete S→M→C history and recovery obligations. Other parent criteria remain open
until their whole evidence is reconciled; this platform step cannot close #122.
Article editorial/PDF/rights decisions remain with #5/#2. Ordinary generation
excludes rights-pending R37 and the technical reader-reference preview.

## Findings and dispositions

| Finding | Evidence and implication | Treatment / current result |
| --- | --- | --- |
| R3-CODE-01 | Content history binds tested head, while production has the distinct identical-tree merge identity. Validating history against production rejected normal content publication. | Existing staging-policy validates the authenticated tested manifest and retains exact contentRelease equality plus tested/merged/tree authentication. One actual-consumer regression passes with distinct head/merge and rejects relabeling, changed content and unrelated source. |
| R3-CODE-02 | Prepared source split Space and the remainder into separate180-second processes and permitted390seconds overall; the local first full attempt then timed out in its second batch. | Restore one worker with all selected modules, one180-second/16MiB bound and210-second reporting wrapper. Existing coverage/skip/failure/empty-module regression now asserts one complete execution; no cases or source obligations removed. Final complete run is native CI, not a claimed local pass. |
| R3-QA-01 | The merged profile test lacked its closing block before the content-reuse case; Node could not parse the owner. | Restore the missing closure. Existing repository-only and raw content-report cases pass, without a new suite. |
| R3-AST-01 | PR79's transitive AST scan reaches two inherited quality consumers importing generated space.js as an authored pose oracle. | Use the canonical builder model/configuration for the same expected poses in the existing motion and scroll consumers. No guard exception, runtime edit or producer change. |
| R3-META-01 | Prepared catalog/map still names removed adapters and old generated revisions; imported exact findings overlap earlier main records and exceed the existing publication-ledger bound. | Reconcile actual paths, map the existing snapshot/index owners, preserve every main finding in its ledger, import only globally unique PR79 findings and shorten imported reason text to immutable original-ledger/row references. Closed scanner inputs and two-megabyte bound remain. |
| R3-INIT-01 | The full transitive guard reaches existing build/check callback references and treated all function-scoped edges as initialization cycles. | Preserve every resolved edge/ownership/purity check and all-edge runtime/pure rejection; reject module-scope helper cycles; report deferred components for the existing independent manual callsite review. This narrows the automatic cycle claim explicitly, rather than claiming all dependency cycles are absent. |
| R3-DOC-01 | Acceptance descriptions still restrict delivery to R1 and call the prepared content implementation absent. | Reconcile current scope/status in the existing policy/profile/content guides. Stable criterion intents, IDs, check mappings and external gates remain; requirements independently verified that comparison. |

The existing content acceptance fixture is reused by the production regression;
it was moved into the existing staging-evidence fixture owner, without copying
another acceptance model. Controlled fixture observations remain unit evidence.
They do not establish an actual browser, publication or recovery.

## Independent role executions

| Role | Separate nonauthoring agent | Actual inspected scope / initial result | Correction/final checkpoint |
| --- | --- | --- | --- |
| Requirements & Acceptance | `/root/r3b_requirements` | Read live intent, policy, original ACs, source owners and freeze before implementation. Bounded platform scope accepted; stale descriptions identified. Actual policy delta comparison preserves schema/intents/IDs/checks/gate mappings. | Completed-source review accepted clean210cb5/treeb966e013; subsequent aggregate-budget restoration accepted independently after direct source/test comparison. Native acceptance pending. |
| Code Reviewer | `/root/r3b_code` | Independently inspected routing/admission, complete history/replay, source selection, artifact and staging/production consumers. Found and reproduced R3-CODE-01. All14 producer objects match the freeze. | Source corrections accepted independently, including all14 producer objects, ledger union and both deferred callsite components. Source-budget restoration accepted independently: one180s/16MiB execution and210s wrapper; native acceptance pending. |
| White-box QA | `/root/r3b_whitebox` | Executed both complete-history cases and existing content-gate/serialized-lease negatives. Found R3-QA-01 through actual Node parsing. | Correction review passes3/3 targeted cases, zero skips,6.457s on clean210cb5. Budget delta passes its own named1/1 case and preserves skip/fail/empty and complete native accounting; native acceptance pending. No tests authored by this role. |
| Exploratory / Interaction QA | `/root/r3b_operator` | Actual isolated ordinary build: five routes, no articles. Actual artifact/Color verifier selects the exact R3 tuple and mandatory rights. Historical repository merge remains cheap; platform preparation remains full. Missing accepted records gives explicit platform fallback using a bounded API fixture. | Actual clean210cb5 observer exits0 with exact base/policy/prospective tree, errors[], and no delivery authority. All14 frozen objects verified; budget delta independently confirms all74 selected staging modules in exactlyone injected execution with exact streams and180s/16MiB, without claiming those suites ran. Native acceptance pending. No physical-device/native release claim. |

Each role reads actual sources and forms its own conclusion. Root reconciles
findings; another role's summary is not independent acceptance. Verbatim receipts
and deterministic metadata/RI refreshes do not restart source review.

### Deferred callback boundary and independent callsite review

The Code Reviewer independently inspected both reported components, using the
actual AST edge/callsite inventory: one28-file build/validator component and the
two-file Color/block-flight component. Module-scope literal imports have no cycle.
Runtime and pure owners still reject every cycle, even function-scoped imports.
All395 resolved edges across117 files retain their ownership/resolution checks.
The existing architecture suite passes11/11, including eager helper rejection,
deferred runtime rejection and explicit reporting of a build callback pair.

Color exports finish before validateFlight loads block-flight; its reverse import
therefore observes the completed API. Build/check library loads finish before
exported operations; reviewed async browser CLIs yield before cyclic scenario
calls. Navigation's main-only IIFE follows exports. The ordinary artifact CLI was
actually executed successfully; its initial build does not reach the retention/
offline reverse reference before export. Release edition/staging-policy import
artifact completely before operation. Review found a standalone archive CLI
export-order hazard; its existing export assignment now precedes the CLI block.
No runtime producer changes or cycle allowlist were introduced.

Function scope alone does not prove deferral. Direct IIFE callees are treated as
eager; indirect top-level calls, .call/.apply and callback execution remain manual
review limits. The source-bound callsite observations above are not an all-CLI,
all-state or general initialization proof. Requirements independently accepted
this explicit automatic/manual allocation within AC04; whole AC04 stays open.
The pure RI-identity comparison now belongs to routing and is called through a lazy
forwarding wrapper in the source selector, removing the new R3 routing/selection cycle rather than exempting it.

## QA allocation and local evidence

| Risk / AC | Oracle and selected owner | Observed checkpoint |
| --- | --- | --- |
| Hidden intermediate/reverted controls; genuine repository merge / AC03,05,06 | Existing content-baseline cases inspect every temporary-Git parent edge and authenticate bounded mocked native App evidence. | Both cases pass; wrong App/source and changed/reverted self-exempting policy reject. Native history remains a later external observation. |
| Cheap repository route and source failure / AC01,02,04 | Existing test-profile-selection owner. | Restored repository-only and raw content-report cases pass2/2, zero skips. |
| Normal content merge / AC03,06 | Existing release-controller production fixture, shared content fixture and real staging-policy consumer. | Full production preservation plus new identical-tree content merge pass2/2, zero skips. |
| Runtime aliases and fixed pose / AC04 | Existing generated-edition, report-guard and R3-rights cases in color-motion-contract. | Pass3/3, zero skips; canonical and immutable aliases and mandatory rights retained. |
| Ordinary package leakage / AC04 | Actual builder and artifact→Color verification, independently executed by operator. | Five routes, no articles, ordinary publication readers empty; rights required. Dirty preparation evidence only. |
| Platform/package Basic | Existing local.cjs. | Pass: five routes,16 theme/archive tests and10 flight tests, zero skips. |
| Current source quality and freshness | Existing formatting/style/AST, coupling, RI and selected source routes. | Formatting525 owners, style142 files, AST117/395, coupling17checks/17layers, fresh RI1754files/200dirs, coupling20/20 and RI29/29 pass. Full local attempt at210cb5 timed out; no complete local pass claimed. Native final complete source result remains pending. |

Existing permanent profile owners select the affected content-baseline,
content-delivery, release-controller, profile and motion tests through their normal
PR-targeted/staging/production routes. No separate diagnostic matrix is added.

## Style, maintenance and limits

CS01/04: canonical owners, explicit identity boundaries and no generated editing
authority. CS05: pinned maintained formatting of touched owners. The R37 profile's
format-only correction preserves its parsed data and53000-character limits; no
manuscript, adaptation, edition acceptance or rights change is authored here.
CS08/09/10: existing Basic, bounded style/AST guard, source suites and independently
reviewed evidence. CS02/03/06/07 runtime/reader behavior remains the frozen prepared
implementation and its earlier issue5 reviews; current hosted proof is still needed.
This delivery does not introduce another animation clock, publisher or budget.

The main secret baseline and reviewed ledgers retain exact bytes. The checksum
ledger preserves its755 main rows and imports nine globally unique existing PR79
rows. Publication preserves all1687 main rows, ordered/data-identical, followed by
1943 globally unique imported records. Same-ID/same-disposition imports reuse canonical main records; immutable PR79
retains their original reason variants. Long imported reasons point to PR79's exact
original ledger and row ID, preserving original proof/review disposition rather
than asserting new independent approval. The loader verifies13718 unique exact IDs
under its unchanged closed four-input and two-megabyte limits.

The sixteen historical v8 HTML files remain losslessly archived with byte-verified
member manifest in the preserved source; no historical content is discarded.
Current v11 previews are regenerated by their existing owner. Earlier captures
retain their historical/unselected disposition and do not become current visual QA.

The restored aggregate-budget regression passes; the exact preflight producer/consumer
case also passes1/1, zero skips, with the210s source wrapper and unchanged180s scanner
deadline. The earlier full local attempt remains failed and is not a full current-source
pass. The next complete source execution is the required native GitHub job.

## First native correction and authored blocker

The first ready source7aafae1 failed native Basic/preview target selection because
protected main rejects a new per-test profile enum. Its RI/owning jobs also exposed
incomplete standalone CLI fixtures, the unimplemented four-worker ceiling and a
stale offline bundle manifest. These are recorded failures, not passed source
or accepted platform evidence; owner staging has not been requested.

The same19 mandatory content memberships now use typed per-test `content: true`
while preserving the closed legacy profile namespace. Independent semantic
comparison proves every other registry value, mandatory membership and permanent
route is unchanged. The actual protected-main consumer accepts this representation.
CLI fixtures include the three real canonical delivery dependencies; their plan
shape explicitly includes the new classification evidence. The lazy forwarding
wrapper preserves the RI comparison API without requiring unrelated imports at
module initialization. The worker now enforces its existing maximum of four
files. The existing offline manifest is regenerated; Code Review independently
matched all73 public/review entries. This is no new test matrix or prerequisite PR.

All four roles independently reviewed these corrections. Code Review validated
both registry consumers, exact19-membership semantic equivalence, current manifest
entries and the unchanged authored limit. Requirements accepted the technical
scope but identified the character-limit choice as outside implied R3 authority.
White-box QA executed the existing inventory/diagnostic and worker-ceiling cases:
2/2, zero skips. Operator independently exercised the actual protected-base consumer
(74 modules) and current content consumer (19 modules), without claiming those
whole suites ran. All14 frozen producer objects retain their prior reviewed bytes.

**Readiness is blocked by an authored constraint:** R37 contains52940 raw Markdown
code points but compiles to53610 upload code points. Both authored limits are53000;
the publisher correctly rejects this610-point excess. Article/profile/publisher/
scanner/runtime owners remain unchanged. Raising to54000 requires the maintainer's
explicit change to the agreed ceiling; retaining53000 requires editorial work.
No validator bypass, test omission or invented inapplicability supplies acceptance.
The complete native source/platform delivery remains pending after that decision.

## Authorized ceiling correction — 25 October 2026

The maintainer explicitly approved raising the proposed internal character ceiling
to54,000. This supersedes the pending decision above and changes only the two
existing `linkedinCharacters` / `mediumCharacters` values from53,000 to54,000.
These are authored review bounds measured in Unicode code points of compiled
upload text, not claims about platform-provider limits. R37 remains byte-exact;
PR79's separately advanced R38 is not imported. Editions, semantic content,
rights decisions, scanner policy and all fourteen frozen producer objects remain.

The separate Requirements & Acceptance Reviewer `/root/ceiling_requirements`
independently fetched live #122/PR146 and inspected original AC01–AC08, the current
profile loader/tests and prior platform/freeze records before implementation.
Preimplementation result: ACCEPTED this narrow change; existing Unicode,
adaptation-selection and over-limit tests plus the actual article loader are
sufficient. Native full platform delivery remains required; parent AC02 alone
remains complete. Completed-candidate role results and checks follow below.

CS01/04/05/08/10 apply to the existing profile owner and source-bound maintenance.
No test, runtime, compiler, scanner, case selection or execution limit is altered.
Necessary RI/CI metadata is refreshed by its existing owners.

### Newly exposed print-binding correction

The first actual full article load after the ceiling correction passed the
character guard but failed the existing strict print-binding guard. This exposes
a previously masked stale `print.keepTogether[1]` binding, not a new text defect.
Actual historical R30 compilation at14157c20 maps old
`6ba05c1f2f05ab6fe73fcb9c439d83dbf90871f80c5184268d997dcc395b86f5`
to the Part III opening paragraph beginning “Correct problem framing makes…”.
The same functional paragraph in unchanged R37 begins “The first investment
decision already depends…” and uniquely hashes to
`8193c7c369e09a4a19ab6f2c29cf2dec1850e1e47d46189a98e68c66da8741c1`.
Only that exact pin is refreshed; both keep-with-next entries, the valid table
pin, grouping counts, strict validator and prose remain unchanged.

Requirements independently reproduced the failure, compared the historical/current
AST nodes and accepted this necessary same-PR metadata repair before editing.
Code and Operator reproduced the failure. Code initially proposed the current
second-table hash without matching the old target; direct exact old-pin lookup
corrected that inference. The original paragraph grouping is retained. Root also
compiled the actual historical/current sources and confirmed that correspondence.
This is explicit reconciliation using source evidence, not reviewer majority.

### Completed independent correction reviews and checks

| Role | Separate actual execution | Source-bound result / limits |
| --- | --- | --- |
| Requirements & Acceptance | `/root/ceiling_requirements`, preimplementation, stale-pin treatment and completed correction | ACCEPTED: independently fetched live intent/ACs/author decision, compared actual R30/R37 targets and parsed three-value profile delta, executed full loader. Both bounds54,000; R37/rights/edition intact. Native gates remain. |
| Code Review | `/root/ceiling_code`, initial and actual correction follow-ups | ACCEPTED after withdrawing the unsupported table-target inference and directly matching the historical paragraph. Complete loader passes; all14 frozen producers, source/editions/rights/scanners unchanged. Derived RI scope checked; no code authored. |
| White-box QA | `/root/ceiling_whitebox`, initial and actual correction follow-ups | ACCEPTED: existing profile suite12/12, zero skips,6.008s; named print-binding case1/1, zero skips,0.705s. An isolated actual-R37 stale-pin probe rejects and corrected-pin probe accepts, retaining the strict guard. No tests authored. |
| Exploratory / Interaction QA | `/root/ceiling_operator`, failed CLI and actual corrected-source execution | ACCEPTED: real CLI exits0 for R37/22sections/4figures; independently executed full loader gives53,610/54,000 for both equivalent platforms. All24 inspected manuscript/publication/edition files identical; ordinary selection empty. No native-PDF/device/publication claim. |

Reviewed profile SHA256:
`854a76a275ea057737646f93899e6cf5425495a0b5abc581af1f1937274a8033`.
The root independently executed CLI/full loader with the same counts/source.
Existing local Basic passes five routes,16 theme/archive plus10 flight cases.
Bounded style passes142files. The RI/CI refresh's expanded JSON formatting is
normalized with pinned Prettier; parsed map data remains identical. Fresh RI,
format and coupling/current-source checks bind the committed candidate below;
complete native source execution and platform delivery remain pending.

The existing permanent `publishing-profile.test.cjs` retains targeted/content/
staging/production allocation for Unicode counts, selected rendition and exact/
stale/duplicate grouping guards. No new mirrored-value test or broader matrix.

## Requested code-complexity audit — 25 October 2026

The maintainer asked whether the complexity concerns article or code, where the
code can be simplified and whether the implementation has become unnecessarily
complicated. This is a bounded analysis request, not authorization for the
previously proposed prerequisite, a policy exception or an identity migration.
Inspected clean local5ea10b5 and remote PR1465edce5d share tree
`2d57748220ac07b26db130e8fa72f2eacab41bd4`; protected main remainsbea2628.
No production source, test, runtime, scanner policy, rights or threshold change is made by
this audit record. The earlier blanket minimum-extra-PR framing is qualified below.

### Observed source and native findings

| Finding | Exact owner / observation | Interpretation and bounded treatment |
| --- | --- | --- |
| Code metric | profile.cjs327–401: printSelection has75lines and Cognitive Complexity34 against25. Actual pinned single-file ESLint gives0errors/1warning. | This is a maintainability signal about code, unrelated to article length. It is not evidence that the article is wrong or that this function produced an incorrect result. One coherent print-group helper is a real readability improvement; avoid a generic validator framework or helper-per-condition metric gaming. |
| Hidden blocking severity | eslint.config.cjs69 says warn25; scanners.cjs348–372 rejects every unlisted warning with exceptions.json complexity[]. Actual warning-to-gate probe reproduces the native failure. | Make blocking status explicit and run existing touched-JS lint locally before expensive CI. Bounded style guard success does not establish actual ESLint success. No new CI service/gate is needed. |
| Broad identity coupling | build.cjs199–209 includes components.producer in browser identity;253–266 hashes every tools/site and tools/publishing source/lock. Color and edition identities inherit that base; color-motion-contract.select1490 requires an exact known fingerprint before byte checks. | Producer provenance is necessary; using every producer edit as a new browser-compatibility family creates avoidable maintenance. Separate source/producer/artifact provenance from runtime byte/behavior/interface compatibility. Keep fresh source checks and complete artifact proof. |
| Growing historical lookup | color-motion-contract.cjs has50families/139runtime rows/1612lines;1457lines are declarations. There are66 distinct five-file byte sets and90 combinations after preserving edition and all behavior/reader flags.49rows repeat the same edition/bytes/policy while differing in build identity. | Historical identities remain evidence/aliases. Stop requiring another manual historical family for each compatible producer-only edit. Moving the same table into JSON would only move the bookkeeping. |
| Parallel rights membership | package.cjs publicationRequired196–328 lists114literal IDs/111unique; each of the three R3 IDs is repeated twice. Duplicate rows do not alter some() results. | This is demonstrated redundant maintenance, not evidence of a rights failure. A future single trusted runtime registry may own mandatory-rights classification; independent rights evidence/approval must remain. Candidate-supplied flags cannot grant clearance. |

Operator independently read exported records issue5-r30-print-plain and
issue5-review-paths-plain: every one of the five browser-file hashes is identical,
while fingerprints differ. Code and White-box independently measured the full
registry through actual AST/data. This establishes that producer-only changes
can churn compatibility identities; it does not establish that every producer
change is harmless. Identical scripts/styles do not prove compatible rendered
HTML, schema, behavior, source freshness or publisher semantics.

Native Basic40172407144 on5edce5d passes formatting, architecture and minimal
source/build checks, then rejects the34/25 warning; selected source execution
is skipped. Navigation40172407097 and owning40172407142 pass; preview40172407077
fails. No owner stage, App, merge, production activation or accepted platform.
The root's separate local scanner command did not execute lint because its
artifact.json setup was absent. This is an execution gap, not another lint pass;
the independent single-file ESLint observations above and native log establish
the actual finding. An earlier touched-JS lint invocation could have found it
before the native run. No unchanged-source rerun is justified.

### Proportionate choices and proposed sequence

1. For the current warning, explicitly choose a maintenance treatment instead of
   automatically creating another prerequisite. The small coherent validator
   refactor is sound; with today's frozen producer/zero-active-debt plan, it still
   requires the proved compatibility dependency. There is also an existing
   source-bound, expiring reviewed-debt mechanism in reviewComplexity/CS05:
   a narrowly approved entry for the exact warning and unchanged validator source
   file, with the required immutable baseline/expiry/removal evidence, could preserve the
   frozen identity and avoid that dependency. It postpones cleanup rather than
   simplifies code, and needs an explicit treatment decision under the current
   no-waiver plan. Neither a global threshold increase nor any exception is
   authorized or applied by this analysis.
2. The higher-value architectural cleanup is one deliberate separation of
   producer/build provenance from runtime compatibility, followed by the small
   validator extraction. Bind compatibility to verified emitted runtime bytes and
   explicit behavior/schema/HTML/edition contracts. Keep complete source/artifact
   hashes and source/predecessor leases; retain historical aliases/rollback.
   Consolidate duplicated trusted membership declarations only as needed for that
   boundary, rather than starting a historical cleanup campaign. This is a proposal
   requiring scoped design/acceptance before implementation, not a delivered fix.

Preserve current exact-block/type/duplicate/adjacency/bounds checks; the stale
paragraph failure already demonstrated their value. Preserve actual canonical/
immutable bytes, unknown/conflicting-runtime rejection, editions, licensed-byte
anti-relabel and mandatory-rights evidence, current source/artifact admission and
historical archive verification independent of today's registry. Removing producer
from a hash or loosening select without a replacement contract would erase a
binding rather than complete the simplification.

Existing profile12/12, print-binding1/1 and actual stale-pin negative/current-pin
positive cover their original unchanged validator scope. Existing motion/rights/
archive tests own unknown/mixed/edition/tamper/anti-relabel/rollback conditions.
A future identity boundary needs one bounded new oracle showing compatibility
stability alongside changed provenance; no broad new test matrix is justified.
A future current-source change still needs its actual ordinary native delivery.

### Separate audit role executions

| Role | Actual separate execution | Independent finding / limits |
| --- | --- | --- |
| Requirements & Acceptance | /root/ceiling_requirements, resumed for this user audit | Read live original intent/ACs and sources. Necessary validators versus accidental coupling distinguished. Corrected the unconditional extra-PR framing; existing exact expiring-debt route identified as a decision, not permission. No code/test edits or full reruns. |
| Code Review | /root/ceiling_code, resumed audit | Actual AST counts and source/consumer inspection:50/139registry,66byte sets/90recorded byte/edition/behavior/reader-flag groups,114/111rights IDs. One grouping helper proposed; provenance/compatibility conflation is the larger issue. No edits/full CI rerun. |
| White-box QA | /root/ceiling_whitebox, resumed audit | Actual pinned ESLint on four inspected modules finds only profile warning; actual warning-to-gate and producer-only identity probes. Existing risk/oracle allocation retains validator, tamper, rights, edition and archive rejection. No implementation or broad suite. |
| Exploratory / Operator QA | /root/ceiling_operator, resumed audit | Actual single-file lint and exported same-byte/different-fingerprint pair; native failure/source-step skip inspected. Operator severity and identity fan-out demonstrated; future interface proof remains open. No deploy or expensive full compilation. |

The original parent ACs and their checkbox states are unchanged. Only AC02 is
complete. #122 remains the owner; PR146 remains Draft. Recommendations are not
maintainer-approved architecture or policy changes.

## Approved refactor — small steps, 25 October 2026

The maintainer explicitly approved the audited refactor in existing PR146 and
requested smaller steps, a result/status after each and the complete remaining
plan. This supersedes the earlier limits-only/no-refactor restriction and amends
the producer freeze only for affected owners. The old PR145 inputs remain
historical evidence; no additional prerequisite PR is created. Original AC IDs,
rights/editorial boundaries, protected delivery, source/artifact freshness,
scanner/lint limits and execution budgets remain.

| Step | Outcome | Current state |
| --- | --- | --- |
| F1 | Separate fresh producer provenance from a verified client descriptor; prove all three actual editions against unchanged main. | Complete: clean-source local proof at20bf4b60; native/full delivery staysF5/F6. |
| F2 | One cohesive print-group helper; unchanged validator/error behavior and25lint rule. | Complete: bounded source/validator parity; native/full delivery staysF5/F6. |
| F3 | Consolidate repeated compatibility data while preserving139historical IDs/flags/editions/bytes. | Complete: bounded data/API parity; whole source/native delivery remainsF5/F6. |
| F4 | Canonical mandatory-rights classification, same111unique IDs/anti-relabel guards; clear early real lint. | Complete: bounded classification/lint step; full source/native delivery remainsF5/F6. |
| F5 | Generated/catalog/RI/contracts, selected source and four scoped roles; native Basic/RI/owning/preview. | Pending. |
| F6 | Existing full owner stage, genuine App, protected merge and actual postmerge. | Pending. |
| R3c | Actual independent content through existing publisher, complete history and required recovery. | Pending. |
| R3d | Original whole ACs/contracts/evidence/timing reconciliation. | Pending; only wholeAC02complete. |

### F1 — implementation and bounded verification

`components.producer` still hashes every previous producer input, including the
new compatibility helper. New `components.client` hashes the five freshly
assembled base-runtime payloads, typed schema/navigation/article-renderer and
finite route/media contracts, and existing scene/assets/route/shared/page-template
fingerprints. Exact descriptor2fe6a007782832aee3818c1a0b80e95a1fb548b11dca1551a3423f690e6dc014
maps to existing base alias43054e4d9861831ec39cbf2e4217ca33b13959bb329959fd7a86413b2ddea3d2.
Unknown descriptors receive a different identity; malformed present descriptors
reject. Historical absent-client locks retain the original calculation.

Full builds assemble payloads once, hash them, emit the same bytes and directly
rehash the emitted files. The known alias additionally checks required active
body/control/navigation/footer/fallback/meta hooks in canonical and immutable
HTML. The existing output tokenizer supplies a bounded canonical-markup view,
excluding raw text, comments and inert templates; this is not a general browser
parser or a claim of full DOM/semantic equivalence. Existing snapshot/article boot
checks and fresh full source/browser admission remain mandatory.

Content reuse compares every non-client component INCLUDING producer before
reusing the authenticated descriptor, then verifies actual raw bytes/hooks.
Changed producer code still requires a full platform build; identical client
bytes do not supply cheap content-release authority. Document signatures and
current source/tree/generation/artifact evidence remain fresh. Color and edition
rendering functions, R37 prose/rights and13unaffected frozen producer objects stay
unchanged in F1. Publication of the article/production is excluded.

The existing permanent Color test owner contains one bounded producer/client
oracle and its meaningful failure cases; its registry inputs now include the
helper. Existing three-edition generation/tamper/rights cases are retained.
Initial stale-generated-output failure is historical, not a test pass; output
was regenerated through its owner. Initial helper metadata-only hashing and
raw-regex/data-id/comment/fallback gaps were independently found, corrected and
allocated to that same oracle. No extra test framework or hosted matrix is added.

Style: CS01/04/05/08/10 apply to build/HTML/client/content evidence owners. Touched
pinned ESLint and the bounded style/AST guards are distinct checks. Native lint
of the untouched print validator remains the original F2blocker, not waived.

Separate roles actually resumed for design, source review and corrections:
The identifiers below are literal agent roles, not deterministic CI checks.

| Role | Agent | Prepared-source observations / remaining proof |
| --- | --- | --- |
| Requirements | /root/ceiling_requirements | Accepted scope/design; required direct raw-byte hashing rather than metadata-only claim. Corrected direct-byte and canonical-hook source delta accepted; clean main-consumer proof pending. |
| Code review | /root/ceiling_code | Inspected full source/diff, producer equality, legacy fallback, dependency direction and output parity. Actual runtime parity and corrected canonical grammar accepted; final proof pending. |
| White-box | /root/ceiling_whitebox | Actual data-id/comment/missing-fallback fault injections found the hook gaps. Original faults, template underflow and bounded oracle corrected/rechecked; accepted for clean-source main proof; no broad suite. |
| Operator | /root/ceiling_operator | Actual five routes, canonical/immutable equality, fresh producer/stable client and missing-hook refusal observed. Corrected actual Home fake-hook scenario rejects; final clean-current package/rights consumer proof pending. |

## Ordered remaining work

1. The approved54,000 correction is complete. The maintainer subsequently approved F1–F6 above within PR146. Complete the F1 actual-main compatibility proof, then the bounded validator/registry/rights/lint steps and original native delivery; no additional prerequisite or rule waiver.
2. Existing Basic/RI/owning and preview, one owner full platform stage, genuine App,
   protected merge and actual postmerge. Record tested/merged identities separately.
3. Later actual content/recovery through the existing publisher and complete history.
4. Final contracts, original ACs, role evidence and actual queue/setup/execution
   reconciliation in #122. No receipt-only or extra acceptance prerequisite PR.

## Issue synopsis

The stable platform integration preserves the exact compatibility-approved runtime,
repairs concrete merge defects and finishes existing source/metadata owners.
Local preparation is not platform acceptance; native stage/merge and later actual
content/recovery remain separately reported gates in the live issue.

F1 prepared checks: pinned touched-JS ESLint0errors/0warnings; current producer/client
and actual three-edition generation cases2/2, zero skips; content-release/baseline/
build-cohesion32/32, zero skips, with subsequent bounded canonical-grammar
correction probes accepted independently. The first RI attempt before staging
removed generated paths failed; its29tests had2errors, not acceptance. The catalog,
index and generated views are reconciled before clean-source proof. Whole native
source/scanners/hosted outcomes are reserved forF5/F6.

### F1 completion receipt — exact unchanged-main consumer proof

F1 is complete as a **local compatibility proof**, not native platform acceptance.
Actual remote PR146 source20bf4b60ea1bfc8c45a2ccfc6d9f08f59e3146f6,
tree93951cee3d0aba9975290d26fcf38709385e29bc, was checked out clean.
The separately detached, clean trusted consumer is exact protectedmain
bea2628263fd348779ee0f0a6d622401b0909fca/tree107fecde5f8a39537bd2c2d5f1a4959a94a821ae.
The receipt-only metadata commit does not relabel these artifacts or checks.

One fresh ordinary artifact was built at that remote source, converted by the
unchanged Color builder and derived into staging/production. Candidate code
created narrow package gates, source-bound rights records and two packages;
unchanged-main code consumed them with artifact.verify, motion.select,
package.sourceGate, publicationRights and package.verify. Plain additionally
retains its expected publication refusal. All three missing-rights cases reject.
No browser/full-source/native gate was fabricated: fullGate, productionEligible
and deploymentAuthorized remain false in every package gate.

The first local5dcf90 harness run failed because local.gate writes its report
and returns undefined. Its harness also had a mismatched plain-refusal regex.
Both harness assumptions were corrected; the final proof freshly rebuilt from
remote20bf4b60 rather than relabeling local5dcf90 data. This was no production-code
or guard relaxation. The proof JSON SHA256 is
8081d0dd12444ed58f01ae0dd62e4dcb25174d3a1dd432bc6dc9039e14275f70.

```json
{
  "schema": 1,
  "kind": "local-unchanged-main-compatibility-proof",
  "pass": true,
  "sourceCommit": "20bf4b60ea1bfc8c45a2ccfc6d9f08f59e3146f6",
  "sourceTree": "93951cee3d0aba9975290d26fcf38709385e29bc",
  "trustedCommit": "bea2628263fd348779ee0f0a6d622401b0909fca",
  "trustedTree": "107fecde5f8a39537bd2c2d5f1a4959a94a821ae",
  "priorProducer": "0e3aee60ba2a7917f817c2959c10fc092f413caf9e6e6845a6761951303b5c56",
  "producer": "09d109e03212ff0d5c4c43d5b7663f098f44ae686a0e8201b54f3f698021a73c",
  "client": "2fe6a007782832aee3818c1a0b80e95a1fb548b11dca1551a3423f690e6dc014",
  "rows": [
    {
      "edition": "plain",
      "runtime": "issue122-r3-platform-plain",
      "fingerprint": "ba98907322811d153fb4d67a1941bf847c6b505b15164943902774a95556d965",
      "artifactDigest": "ad69686bbabffddc6ffc97d06edaab3c575ad5f0be93bd01b1e48eb2a5ca87ba",
      "rightsDigest": null,
      "packageDigest": null,
      "artifactVerified": true,
      "sourceGateVerified": true,
      "missingRightsRejected": true,
      "publicationPackageVerified": false,
      "plainPublicationRejected": true,
      "fullGate": false,
      "productionEligible": false,
      "deploymentAuthorized": false
    },
    {
      "edition": "staging",
      "runtime": "issue122-r3-platform-staging",
      "fingerprint": "4040aee07b41e837fa0f8a95c7ecd0d263922097e62e9dbcbc07668729ab3de6",
      "artifactDigest": "85fc4e7c54e7f82cbd998d5d6bbc9ec5e90a627e09d4334082b6ce3f3d86f997",
      "rightsDigest": "731c698c21c495a7b20bdbec27e13e8193a81a2eac7591b32aeb5fc2bb4d703b",
      "packageDigest": "b1d68cbc5886eac256536c0b5fcce59899f90f7322b9249f89ec391a1be44c2f",
      "artifactVerified": true,
      "sourceGateVerified": true,
      "missingRightsRejected": true,
      "publicationPackageVerified": true,
      "plainPublicationRejected": false,
      "fullGate": false,
      "productionEligible": false,
      "deploymentAuthorized": false
    },
    {
      "edition": "production",
      "runtime": "issue122-r3-platform-production",
      "fingerprint": "10ea7815a570596cecc18432660293f87bf0e6a9a836d91495fd48dbc6a6ce14",
      "artifactDigest": "6036266e67fce82c9928fefeb706fcec079f3d91fc5b4b4d92cfcf1cc08475e5",
      "rightsDigest": "fe631560a449e55733df5bda98a2847d744c8bd31173d0219ddc87e3c4d96f64",
      "packageDigest": "cbef6b303daf20e5b4d2c4744cb4dbbb47c0ed2e6d983a79f5f5ed5e7939de3b",
      "artifactVerified": true,
      "sourceGateVerified": true,
      "missingRightsRejected": true,
      "publicationPackageVerified": true,
      "plainPublicationRejected": false,
      "fullGate": false,
      "productionEligible": false,
      "deploymentAuthorized": false
    }
  ],
  "fullNativeAcceptance": false,
  "deployed": false
}
```

All four distinct roles completed final actual-source/proof review:

| Role | Final independent result on20bf4b60/tree93951cee |
| --- | --- |
| /root/ceiling_requirements | ACCEPTED. Read actual proof/artifacts/rights/packages and independently re-executed unchanged-main consumers for3editions/2packages. Source/gate/scope limits preserved; originalACs unchanged. |
| /root/ceiling_code | ACCEPTED. Authenticated clean candidate/main trees and actual consumer implementations; source/test hashes match corrected review; all13unaffected producer objects remain exact; no unresolved code/evidence blocker. |
| /root/ceiling_whitebox | ACCEPTED. Original fault corrections retained; actual source/gate/rights/physical package consumption re-executed independently; no false full/native authority. |
| /root/ceiling_operator | ACCEPTED. Independently consumed all3fresh remote-head artifacts and2publication packages; clean source/tree/generation-lock identities, fresh rights and exact runtime tuples verified. |

Final bounded results: actual producer/client plus three-edition cases2/2;
shared-HTML cohesion8/8; broader content-release/baseline/cohesion32/32prepared
checks with affected correction readback; Basic five routes/16theme+archive/10flight;
pinned touched-JS ESLint0errors/0warnings; bounded style143files; AST118files/398edges;
fresh RI1755files/200directories, RI29/29 and coupling20/20/17checks/17layers.
The initial RI29 run with2errors and stale-output preparation failures remain
failed history; corrected index/catalog/owner generation passed. These checks
do not claim full selected-source/scanner or native platform acceptance.

Only tools/site changes among the14historically frozen producer objects. R37
source SHA2568c788866896cf28ecc4dc6da8bbdcdc3c8fc76a561b485596fd0f467e2a04d71
is unchanged; all ordinary article selections remain empty. F2 follows below.

## F2 completion — print-group validator, 25 October 2026

Owner remains [issue122](https://github.com/oborskyivitalii/oborskyivitalii/issues/122)
and Draft [PR146](https://github.com/oborskyivitalii/oborskyivitalii/pull/146).
The maintainer authorized this small step under the approved plan. Prepared base
is74c3f058ccda15991d8876737f3bb3c58cdaf0ef/treefa0d9f64fa06ec160cfd91413e5e62ec4415502e;
the sole production-source delta is tools/publishing/profile.cjs, SHA256
bf25017a99e51a263355aeb15634647757ea12ebd76587e467c5979a3df3ee27.
Source-bound remote commit links are recorded in the live issue/PR after upload;
the prepared checks below are not relabeled as native or clean-head CI.

### Change and preserved contract

One same-module `printGroups(print, nodes, paragraph, bind)` owns the existing
keepTogether/keepWithNext loop. The loop is unchanged; the call occupies its
original position between title and prompt checks. The original `selected` set,
`bind` closure and paragraph predicate retain shared identity, type, uniqueness,
adjacency,1–50 bounds, error text and first-error order. There are no new exports,
dependencies, generic validation layer, lint exceptions or threshold changes.
This applies CS01/04/05/08/10 to the existing publisher owner.

Actual pinned lint reproduced the prior34/25 warning before editing. The final
pinned ESLint with `--max-warnings 0` passes with zero errors/warnings. A separate
measurement-only threshold0 invocation reports printSelection16 and printGroups18;
the repository rule remains25. Pinned formatting passes without unrelated reflow.

| Risk / AC | Executed oracle | Observed outcome / limit |
| --- | --- | --- |
| Bounds, types, duplicates and adjacency / AC04 | Existing tests/publishing-profile.test.cjs |12/12,zero skips; implementer9.086s, separate White-box9.667s. No new mirrored helper test. |
| Shared binding and error precedence / AC04 | White-box actual baseline/current loadProfile differential |22/22 identical public outcomes:6accepted,16exact-error rejections, including0/50/51,invalid arrays/types/stale pins/cross-role duplicates and competing faults. Temporary harness only. |
| Real article/operator surface / AC04 | Actual publisher CLI and full R37 loader; copied-input stale-pin probe |53,610/54,000 Unicode code points,22sections,4figures; current8193c7… accepts, stale6ba05c… rejects unchanged distinct-source error, restoring current accepts. |
| Rights and article integrity / AC04 | Actual loader/selection and Git comparison |R37 rights review-pending; ordinary article selection[]; manuscriptSHA8c788866… and profileSHA854a76a2… unchanged. Native PDF/editorial/rights decisions remain separate. |
| Source freshness versus runtime parity / AC04/08 | Owner build --all, previews and actual previous/current runtime byte comparison |Fresh producerda63a1c858c00114b3afa8d3c9c95655cee98a1d8e321ae17c0c9cc238500c27; same verified client2fe6a0…/alias43054e…; all5canonical+5immutable runtime files byte-identical; all5route versions refreshed. |
| Generated/site cohesion / AC04 | build --check, preview --check and Basic |Five routes,16theme/archive cases,10flight cases; syntax/geometry/snapshot/size checks pass; deploymentAuthorized=false. |
| Style/dependency boundaries / AC04 | Bounded style guard and AST guard |143style files pass; no import/initialization change. Existing deferred build/check components remain the already reviewed boundary, not a new cycle exemption. |

The owner regenerated current route snapshots, output lock and offlinev11 previews.
The catalog removes only the five replaced current snapshot directories/files
and admits their generated replacements under the same site owner. Historical
runtime records, scanner inputs/budgets, rights classifications and test membership
remain unchanged. F1's20bf artifact proof remains attached to that source; runtime
parity here does not reuse its artifact/source acceptance at the new producer.

### Four independent F2 executions and maintenance

| Role | Separate execution | Completed result and actual scope |
| --- | --- | --- |
| Requirements & Acceptance | /root/f2_requirements, preimplementation and final |GO before editing; final accepts exact extraction, actual pinned lint/R37 loader/ten-byte-copy comparisons and bounded AC04/07/08 traceability. No new requirement defect or whole-AC advancement. |
| Code Review | /root/f2_code, source and final delta |Accepts literal baseline reconstruction, actual lint/formatting, final report/MEMORY/catalog and direct runtime comparisons. No blocking findings; no new dependency or waiver. |
| White-box QA | /root/f2_whitebox, source and final delta |Actual12/12 and22/22 API comparison; independently rechecks final source hash, ten runtime copies, article hashes and catalog boundaries. No blockers; does not claim exhaustive branch/native coverage. |
| Exploratory / Interaction QA | /root/f2_operator, operator charter and final delta |Actual CLI/full loader/current→stale→restored pin, rights/ordinary selection; final direct byte/catalog/report checks agree. No operator blocker; native PDF/full CI remain unobserved. |

The implementer reconciled the four independent results; no production correction
was needed after extraction. Temporary reporting probes initially used a wrong
article filename or assumed nested/optional object shapes; corrected inventory/schema
reads pass. These were harness/reporting mistakes, not validator failures or new tests.

Final deterministic maintenance: fresh RI1755files/200directories; RI29/29 in19.539s;
coupling20/20 in1.067s and17checks/17layers. AST118files/399edges passes; the source
extraction changes no imports. Actual indexed catalog replacements, output ownership
and unautomated source/dependency review remain distinct from live GitHub evidence.

F2 supplies bounded AC04/07/08 evidence, not whole parent acceptance. The original
5edce5d native failure remains historical; selected source tests were skipped there.
No native/full-source/scanner/browser/PDF/staging/App/merge/production acceptance is
claimed by this step. F3 follows below; only wholeAC02 is complete.

## F3 completion — shared compatibility declarations, 25 October 2026

Owner remains [issue122](https://github.com/oborskyivitalii/oborskyivitalii/issues/122)
and Draft [PR146](https://github.com/oborskyivitalii/oborskyivitalii/pull/146).
The approved small step consolidates repeated trusted declarations while retaining
all historical identities and guard behavior. Prepared base is74913dc0053abadfcbb8e71bd666d647b1378a38,
tree7fc2e5699ca78d263e67d0b02525738e0aa5396f. The sole production-source delta is
tools/quality/color-motion-contract.cjs, SHA256
9600fb22ad91c3d3af79fe4d7430ce9767eeed3053bbc34ef88e986c6adf3100.
The live issue/PR records the exact uploaded commit; prepared checks are not native CI.

### Change, invariants and test allocation

The existing module now declares seven behavior/reader profiles,31shared JS-byte/
behavior profiles and15plain/staging CSS pairs. Fifty historical family declarations
retain explicit ID prefixes, base engines and only their admitted edition fingerprints.
A fixed plain/staging/production expansion constructs the same139internal rows;
absent editions stay absent. Admitted production CSS reuses its identical plain bytes,
while production identity and edition verification remain separate.

The module shrinks from1612lines/69,717bytes to957lines/43,281bytes. This reduces
repeated maintenance; it is not a browser-speed claim. Every consumer function from
`reviewedRuntime` onward is byte-identical, including selection, reader defaults,
canonical/immutable byte checks, pacing and report guards. Returned nested objects
remain fresh. There are no new exports, dependencies, external registries or validation
frameworks. Rights classification/package code, tests, test membership, scanners,
thresholds, execution budgets and authored/browser sources remain unchanged.

CS01/04/05/08/10 apply to the existing trusted registry owner. Formatting affects
the changed declarations only; the unchanged consumer tail proves no unrelated reflow.
Actual pinned ESLint with `--max-warnings 0` and pinned formatting pass.

| Risk / AC | Actual independent oracle or existing check | Observed result and limit |
| --- | --- | --- |
| Historical identity/data loss / AC04 | Isolated actual74913dc module versus current public API; independent Code/White-box declaration comparisons |139public records/selections and all50original family fields match, including absence semantics. Historical IDs/fingerprints remain unique;11unadmitted production IDs reject. |
| Reader flags/defaults / AC04 | Both runtime fingerprints and base engines plus unknown identity |Root190engines×5methods=950equal queries; White-box75representative queries across seven policies independently agree. |
| Shared mutable aliases / AC04 | Mutate returned files/variant/effects, query the same or sibling alias |Root139isolation probes and separate White-box/operator sibling probes pass; trusted shared declarations cannot be changed through returned records. |
| Byte, identity, edition and rights refusal / AC04 | Existing18fixture cases; White-box42guard perturbations; operator28consumer scenarios |18/18,zero skips,4.639s; separate controlled negative/API scenarios pass. Missing licensed rights and licensed-byte relabelling still reject. No hosted/native claim. |
| Source/output/style boundary / AC04/08 | build --check, previews --check, Basic, bounded style and AST guards |Generated public/preview/output-lock bytes remain current and unchanged. Basic5routes/16theme+archive/10flight passes; style143files and AST118files399edges pass. Existing deferred components remain the reviewed boundary. |

The actual baseline/public snapshot SHA256 is
c7fb50b2115c81985b1196f745ebe70400bbb1967a4cefc5f29af3d7e766de8c;
temporary parity evidence is /tmp/issue122-f3-parity.json. The existing permanent
tests/color-motion-contract.test.cjs route remains selected by registry changes in
the existing PR-targeted/staging/production profiles. No permanent test merely
restating the new data representation was added. These are bounded preservation
oracles; they do not prove exhaustive branch or native coverage.

### Retained failure — current-generation assertion still names R30

The first local name selector used a negative lookahead that also matched the
file container, so it ran all26module cases:25pass,1fail,zero skips in8.420s.
The failure is the existing test at981, `reader-link runtime tuples reproduce the
complete current plain, staging and production byte closure`: its literal
`issue5-r30-print-plain` assertion at1006 conflicts with actual `issue122-r3-platform-plain`.
An explicit positive selector then ran the intended18data/guard fixture cases above.
That pass does not turn the full module green.

The single failing case was separately rerun on the actual detached74913dc
baseline worktree and failed identically in1.081s; tracked source was exact, with
only two untracked dependency links used for execution. This is a preexisting
integration mismatch, not a F3behavior regression. Its test body and memberships
remain unchanged. Disposition F3-01: resolve current-generation oracle identity
while preserving the three-edition byte/edition/navigation checks during already
planned F5integration; no waiver, deletion, budget change or unchanged-source rerun
campaign. Full selected-source acceptance remains explicitly open.

### Four independent F3 executions and maintenance

| Role | Separate execution | Actual completed source/final-delta result |
| --- | --- | --- |
| Requirements & Acceptance | /root/f3_requirements, preimplementation/representation/final |Accepts bounded F3; independently runs139record/selection/isolation checks and950reader queries,11absent-edition refusals, unchanged API/tail/lint. Confirms the baseline failure stays open for F5/F6 and cannot advance whole parent acceptance. |
| Code Review | /root/f3_code, source/final delta |Own50family/139row/public comparisons,950queries,11absent editions and real lint/formatting pass. Shared declarations are proportional; no source blocker. Final metadata review identifies the stale remainder sentence described below. |
| White-box QA | /root/f3_whitebox, source/final delta |Own field/absence/139row parity,75reader queries,42guard negatives,11absent editions and sibling isolation pass. Reads both failure logs and unchanged test/package/profile boundaries; no source blocker. |
| Exploratory / Interaction QA | /root/f3_operator, charter/final delta |28controlled consumer scenarios pass; independently inspects rights/alias/edition refusals, baseline/current failure logs and final report limits. Browser/native/publication acceptance remains outside the charter. |

The three final-delta reviewers identified one stale report remainder sentence
that still listed F3 as pending. It was removed without changing source/tests;
F4 is consistently next. The implementer reconciles these separate results without
substituting self-review for their independent evidence.

Deterministic maintenance: RI1755files/200directories is fresh; RI29/29 in8.366s,
coupling20/20 in0.630s and17checks/17layers pass. Only existing review/MEMORY and
derived agent context accompany the registry source. No generated rendition, output
lock, catalog/schema or RI/CI policy change is required by this declaration refactor.

F3 provides bounded AC04/07/08 step evidence; only whole parentAC02 is complete.
F4 follows below, then F5,F6,R3c,R3d. No native/full-source/scanner/browser/staging/App/merge/production acceptance
is supplied by this data refactor. F1/F2 evidence remains bound to its original sources.
PR146 stays Draft.

## F4 completion — canonical rights classification and early lint, 25 October 2026

Owner remains issue122/Draft PR146. Prepared base is3a00cbc7814a19c26b8e300ea142d8f1f06c534f,
tree99db110aae91709e32adc9285ce5cb2e52ee33c4. The approved step preserves mandatory
rights and makes existing blocking lint visible; it grants no publication approval.
Exact uploaded source links remain in the live issue/PR; prepared checks are not native CI.

| Authored owner | Final source SHA256 / change |
| --- | --- |
| tools/quality/color-motion-contract.cjs |ec4e74f5f37abac6cf5d7fb936a27ce1dfc6a40f3c748e29b2df56b9bdd7e15b;37trusted family requirements and canonical publicationRequired. |
| tools/staging/package.cjs |94e340e5d532ac8dbd5a5aa3649d4468e3a60c852fa2e5b32cee6a165e31736b; existing API delegates through the original deferred dependency. |
| tools/quality/scanners.cjs |ae325cf39063b70a17ea666bf0a6d8b01e93c13b60d68c4a0e22e0179ebfa5ad; adds only the explicit `Lint blocked:` error prefix. |

The former114literal rows are exactly111unique IDs across37uniformly licensed
families. Trusted `requiresPublicationRights: true` now lives with those historical
families; the independent rights report/approval remains separately required.
Candidate flags are ignored. The original licensed-fingerprint OR known-canonical-byte
discriminator still prevents base/historical relabelling before unchanged exact
variant/edition/canonical/immutable verification. All139public runtime records remain
unchanged; the registry exports one new canonical function for its existing consumer.
No byte-only compatibility or rights-approval shortcut is introduced.

The existing scanner still applies its exact source-bound debt/expiry policy and
configured warning/25threshold. Its new prefix explains that unreviewed debt blocks
lint. The quality README supplies the actual pinned touched-JS `--max-warnings 0`
command; the rights guide points to the canonical classifier and retains separate
artifact authentication/evidence/approval. CS01/04/05/08/10 apply to these existing
owners. No test, profile, threshold, exception, scanner coverage or execution budget changes.

| Risk / AC | Actual check or independent oracle | Result / limit |
| --- | --- | --- |
| Classification drift / AC04 | Actual immutable3a00cbc package versus current package and canonical registry |725equal result/error comparisons over139IDs:111required/28not required;139public records exact. Sorted required-ID set SHA256ba51804e89a580e568313bcd8d118a9c14930b73097f3149292a6427cb7e0742. |
| False clearance, relabelling and tamper / AC04 | Old/current false candidate flags, licensed-byte base/historical relabelling, canonical/immutable substitutions; existing Color/rights fixtures |23/23,zero skips,5.740s; no current-generation/whole-module pass claimed. White-box independently executes12negative/binding cases; operator17consumer/lint scenarios pass. |
| Lint stays blocking / AC04 | Existing source-bound/expiry/debt negatives; real pinned lint and actual archived pre-F2 warning |Code reviewer2/2,zero skips; all3current JS files lint/format clean. Archived actual34/25warning exits1 and current scanner clearly rejects it with file/rule/message. No debt allowance or rule change. |
| Generated/source/dependency boundary / AC04/08 | Owner build/preview checks, Basic, bounded style and AST |Output/lock/previews unchanged and fresh; Basic5routes/16theme+archive/10flight pass, deploymentAuthorized=false. Style143files/AST118files398edges pass; only the duplicate deferred common import is removed, no new initialization cycle. |

Temporary evidence: /tmp/issue122-f4-parity.json, /tmp/issue122-f4-whitebox.json,
/tmp/issue122-f4-operator.json. Existing permanent Color/rights and quality-source
tests retain their PR-targeted/staging/production routes; no duplicated ID ledger or
implementation-mirroring test was added. Requirements and independent review remain
separate from the implementer's API comparison and ordinary CI checks.

### Four independent F4 executions and maintenance

| Role | Actual separate F4 follow-up execution | Completed source/final-report result |
| --- | --- | --- |
| Requirements & Acceptance | /root/f3_requirements, preimplementation/source/final |Accepts37uniform families/111IDs, independently checks139classifications/records,278forged flags, licensed-set digest and guard failures. Final report/MEMORY retain original ACs and separate approval. |
| Code Review | /root/f3_code, source/final |Own old-list/new-flag equality, exact source diffs, deferred dependency, actual lint/formatting,2complexity cases and licensed relabelling pass. Reads final parity/QA reports; no blockers. |
| White-box QA | /root/f3_whitebox, source/final |Independent111-ID/37-family equality and12controlled metadata/binding/negative scenarios pass. Final claims retain verified-artifact prerequisite and F3-01; no findings. |
| Exploratory / Interaction QA | /root/f3_operator, charter/final |17consumer/lint scenarios, exact README command and actual archived34/25warning→blocking error pass. Final docs/report limits agree; no findings or public action. |

All four final source/report readbacks accepted; production hashes remained unchanged.
RI1755files/200directories is fresh; RI29/29 in10.108s, coupling20/20 in0.658s and
17checks/17layers pass. These are implementer maintenance receipts, distinct from
the reviewers' own executions and any live/native acceptance.

F4 supplies bounded AC04/07/08 evidence; only whole parentAC02 is complete. The last
full Color-module observation remains F3's25/26; F3-01's stale R30current-generation
expectation is unchanged and stays open for F5. No full selected-source/scanner/native
acceptance is claimed here. F5integration/native Basic/RI/owning/preview is next, then
F6full owner stage/App/merge/postmerge, R3ccontent/recovery and R3dwhole acceptance.

## F5 source integration checkpoint — 25 October 2026, native pending

Owner remains issue122/PR146. This checkpoint reconciles the approved refactor
with the existing source, scanner and generated contracts. It does not supply
native/full-stage/App/merge acceptance. Only whole parentAC02 remains complete.

### Corrections and retained invariants

| Existing owner | Bounded correction and independent oracle |
| --- | --- |
| tests/color-motion-contract.test.cjs | F3-01 now names the actual current R3 platform in all three editions, preserving historical R30 and complete byte/edition/navigation closure. Full module26/26, zero skips,11.130s on prepared source. |
| tools/quality/generated-checksums.cjs; tests/quality-sources.test.cjs | Add only the computed `client` component to the closed generated-lock fields. The real builder/source/file/line-bound private proof remains required; copied/fabricated proof, wrong location/type/value/owner and copied unknown JSON fields reject. Corrected existing cases2/2, zero skips. |
| Two active Writing/Events producer records | Refresh only tools/site/html.cjs from its old digest to the F1 reviewed bytes. All other28 producer occurrences, inventories, bodies, original hashes and historical issue5 migration record remain exact. Independent old/current valid-input rendering comparisons and stale/wrong-producer negatives pass. |
| tests/article-media.test.cjs | The current-preview test captures authored edition and independent Node-crypto SHA256 of the declared manuscript before building. It follows its actual fixture instead of requiring R30/R37 repinning. Existing PDF closure, rights approval=false,800KB budget, JPEG refusal, corrupt/missing/forged-input and native-link assertions remain. Root1/1 and independent QA1/1 pass, zero skips. |
| tests/site-engine.test.cjs | A template rename changes the deliberately bound pageTemplates/client/runtime identity, so the existing case expects all five routes. Both missing-input/coherent-output refusals and the separate Home-content-only local-rebuild test remain. Actual corrected case1/1, zero skips. |
| tests/publication-records.test.cjs | Replace only the obsolete two-batch comment and two390000 literals with the existing one180000+30000 reporting contract. Both staging/production forced-timeout paths still fail and retain original TAP/stderr/wrapper reports. Root1/1 and separate QA/operator1/1 pass. |
| tools/quality/delivery-routing.cjs | Extract one private per-file category helper. contentSelection46→19; helper7 under unchanged25. Preserve derived-identity/rejection/classify evaluation order, including classification errors on rejected inputs, record/base→candidate order, deduplication, eligibility and media lane. Code26 and White-box20 old/current result/error comparisons match. Clean real-Git9/9 and independent operator2/2 pass, zero skips. |
| review/site-v1-offline-bundle-v11.json | Regenerated by the existing bundle owner after the earlier preview changes. Current source, fifteen previews and bundle checks pass; no generated rendition was hand-edited. |

No runtime/publication source, rights approval, scanner detector, complexity
threshold, test membership, source deadline, output limit or worker ceiling is
relaxed. The current source fixture remains R37/review-pending; R38 work in PR79
is separate. This step does not merge, render or publish R38.

### Failed attempts remain failed

The first clean local79-module run atb5e4c7707eb69f03959f77227d828cd48118cf1c,
tree0fcd69ca4b09c8a0735e1a3ddff46f21ab85c49d, timed out under the original180s
limit. It emitted185ok/25not-ok results without final accounting. Those are
partial outcomes, not a completed suite or a waived set of failures. Diagnosis
found the two stale active producer pins, the current-article oracle and missing
historical Git fixture blobs. The exact pinned prerequisites were fetched and
verified with GIT_NO_LAZY_FETCH=1; no fixture pin or guard was weakened.

After those corrections, the second clean79-module run at
32e90fe1b0837b8e6b14abacfcfd4bc871a5df7a,
tree403317b5a7725ce3e467147f04f31fd64abf5e00, also timed out at180000ms
(191.053s including wrapper/reporting). It emitted318ok/1not-ok without final
accounting. The one emitted failure was the stale390000 wrapper expectation
corrected above; output81478bytes did not approach16MiB. Truncated ordered TAP
cannot establish a critical path or whole-module coverage. LocalNode24.22.1
differs from native24.19.0; this is an environment limit, not a proven cause or
promise of a native pass. There is no third unchanged local full-run campaign.

An intermediate9-case routing execution passed6 and failed3 because the real
CLI correctly rejects uncommitted producer implementation. After the reviewed
helper was committed at0c867ec9da73ec4073b6d7a5c88a90181b00a5ca, the same9cases
passed in8.531s; operator independently passes2/2. The producer guard and fixtures
remain unchanged. An unnecessary RI/CI-map refresh only expanded JSON formatting;
its parsed content was identical and the original canonical bytes were restored.

### Scanner maintenance and old-edition allocation

The cleanbb1f76ca929b36d541c17709f32d32c6a6d8e61b source checkpoint passes
Basic5routes/16theme+archive/10flight in4.417s; permanent Python128/128 in31.662s;
format526files; bounded style143files; AST118files398edges; generated/previews/
bundle freshness; five owning mechanical checks and RI/coupling freshness.
These are bounded local receipts, not final-head/native acceptance. Advisory
feeds pass with zero findings and all91 pinned Python dependencies verified.

That checkpoint's full lint failed only on the46/25 classifier fixed above.
Its full security scan failed on Semgrep execution and751 untriaged Hex findings.
The installed Semgrep native binary was truncated:159383552bytes instead of its
wheel RECORD's256951176, with a different hash. Reinstalling the same1.179.0 pin
restores exact RECORD bytes/hash/executable mode and the unchanged91-package/
147-dependency graph. A30s version probe remained incomplete; only an actual
complete original-bound security scan can establish its pass.

One of the751 findings was the removed current-preview source literal. The
remaining750 exact path/type/hashed-value candidates have a retained inert proof:
review/issue-122/2026-10-25-f5-exact-checksum-proof.json.gz
(93855compressed bytes;926883decoded bytes). Its capturedFileSha256 fields explicitly bind the original clean bb1f76c source,
not later appended receipts; current exact token/line presence is checked separately.
It records683 recomputed checksum
proofs,30 typed Git-object proofs,21 historical producer attestations and16 exact
archival declarations. Actual proof includes five original native archive/member
closures, current AST pins, historical manuscript/semantic pairs, v8 HTML originals,
canonical runtime/edition formulas, raw performance ZIP members and source files.

Producer-attested fields are explicitly separated from rehashed preimages.
Unavailable collector Git objects and old executable/script preimages are not
claimed to exist or to have been rehashed. Sixteen archival declaration fields
retain their original rejected/superseded/limited-result or F1 local-proof status;
their original artifact bytes/results are not revalidated or advanced. Exact
immutable owner records, named emitters, contemporaneous review context and the
original source-bound F1 receipt establish their public noncredential role.

The initial demand to recover every discarded preimage was an overstrict review
interpretation, not a canonical repository requirement. Requirements independently
checked README151–156 and release-gates200, then reviewed the concrete original
contexts. This correction does not create a generic JSON/hex exemption or grant
artifact authenticity. Use only append-only exact dispositions in the existing
checksum companion; preserve all prior rows/order/reasons and the other three
ledgers byte-for-byte, the closed input list, detectors,2MB bound and rejection
of unknown path/type/value. The proof artifact is audit evidence, not a scanner
authority or a new runtime/CI framework. The existing companion now appends750
exact rows after its764 prior rows:1514 total,860581bytes below the unchanged2MB
bound. All prior rows/order/reasons and the other three ledger files remain
byte-identical. Actual closed-ledger loading accepts14468 exact reviewed IDs.
Final scanner replay and four-role ledger/report readback remain pending here.

The maintainer asked whether historical article revisions need repeated heavy
testing now that R38 is current. The registry already assigns20 task-snapshot
modules only to their owning issue policy; routine128-case Python selection
excludes numeric task snapshots. Permanent article/media/runtime cases protect
current behavior and finite compatibility/refusal contracts, rather than rerun
every old edition's browser/PDF/performance matrix. Historical byte/provenance
inspection here is one-time triage for accumulated exact findings. No old browser,
PDF rendering, performance or native-platform campaign was restarted. The
current-preview oracle improvement above removes needless edition-literal upkeep;
frozen editorial snapshots remain with issue2/5. No allocation or gate is removed.

### Independent roles and next native evidence

Four actual distinct role follow-ups inspect every coherent correction:
/root/f3_requirements, /root/f3_code, /root/f3_whitebox and /root/f3_operator.
Requirements runs before dependent edits and on the completed source; Code and
both QA roles independently inspect source and execute their bounded oracles.
The separate exact-ID checksum proofs and public/declaration limits are preserved
in the compressed audit record. Final ledger/report readbacks remain required
before Ready; their completed receipts will be appended verbatim.

The existing ready_for_review workflows own canonical current-head Basic/source,
navigation/RI, owning acceptance and hosted preview evidence. No explicit local
full-suite-pass prerequisite exists; Ready after stable focused/local checks and
four final roles requests that native verification, not a green full-source claim.
The unchanged79-module plan, one180s/16MiB process, cap4workers, zero-skip accounting
and failure propagation still apply. Native failure needs diagnosis, not waiver
or an unchanged rerun loop. F5 remains open until its exact-head native results
are reconciled. F6 owner stage/genuine App/protected merge/postmerge, R3c meaningful
content/recovery and R3d whole acceptance/timing reconciliation remain afterward.

### F5 final local verification receipt — native still pending

This receipt supersedes the checkpoint's pending local scanner/ledger readbacks.
The actual clean scanner source is fedba7cef7ebdb763d2629fe2f98ee3deba8c049,
tree ab7ed8b858bba9061a792ed9af00205cd7f78a5f; its frozen artifact digest is
b12e4ad141e3a1c2e1e215cec5a5f8469d74fa7b1daeb581c37ff87967ccf206.
No later receipt/upload head is substituted for that tested source.

| Actual check | Completed result at that source |
| --- | --- |
| Full lint | PASS18.638s; ESLint, Stylelint and Ruff pass. |
| Full security | PASS78.339s under180s; Semgrep334files/eight rules/zero errors, Bandit and secrets pass.1354tracked text files/6920reviewed candidates/308generated admissions; real generated proof39files/360IDs. |
| Advisory feeds | PASS23.241s; npm, publication npm and pip pass, zero new findings. |
| Report binding | All three reports independently read back with the exact source/tree/candidate/artifact above, local target=null and historyScan=false. No hosted/history/full-source execution is inferred. |

The separate clean be9782830faa3dde9e49d0cf231657091ebdbc67 checkpoint retains its
Basic4.717s, RI29/29 in11.441s, coupling20/20 in0.648s and five owning mechanical
passes. Owning automation_pass/evidence_valid are true; ready_for_issue_closure
is false. The later change only clarifies capture-time metadata and regenerates
its inert proof/report/RI; those prior executions are not relabelled.

Four distinct completed final source/metadata executions and the requirements
check-bound readback are retained below as verbatim result excerpts:

| Actual separate role | Final receipt excerpt |
| --- | --- |
| /root/f3_requirements | “source/scanner prerequisites support upload/Ready solely to obtain native exact-head 79-module verification under original budgets.” |
| /root/f3_code | “no blocking findings.” |
| /root/f3_whitebox | “Wrong path/type/hash all reject; duplicate rejects with original loader error in temporary-only copied ledgers.” |
| /root/f3_operator | “Final bounded operator ledger/report verdict ACCEPT” |

All750 exact proof/ledger IDs and current token/line locations match;764 prior
rows and the other three ledgers remain exact. Each of the32 captured file hashes
was independently checked against its explicitly named bb1f76c Git source.
The source, rule, profile, threshold, time/output/worker and authority limits above
remain. These local receipts support the existing upload/Ready/native route;
F5 still requires complete current-head native accounting, and F6/R3c/R3d and
the remaining whole parent ACs remain open.

### F5 first native failure and bounded correction

The first Ready request used uploaded source5b3618bd/treec5d7a70b; full immutable
identities remain in the original native source report. Basic run40203674695
failed its original180000ms source limit after803 emitted top-level passes and
one emitted failure, without final accounting. These partial outcomes do not
establish complete79-module coverage. The sole emitted failure was an obsolete
workflow-expression oracle. Navigation/RI run40203674708 and owning acceptance
run40203674671 passed. Preview build run40203674815 failed because optional
historical baseline selection read an ancestor without site/rights.json.
PR146 returned to Draft; no staging/merge admission was requested.

The bounded selector correction first validates current HEAD, protected main and
base freshness, then classifies protected-base-to-candidate outside any catch.
A platform/control/mixed delta returns ordinary platform before historical APIs.
Only optional per-PR historical selection moves inside its existing catch;
missing old inputs produce an observation and ordinary fallback. Current invalid
inputs stay fatal. Complete S-to-C history, genuine App, artifact/generation
authentication, cleanup and source leases remain. The prototype test now asserts
the exact existing Draft79-only article-preview expression; Ready smoke and
admission negatives remain. Workflow policy itself is unchanged.

Actual real-Git regressions cover zero historical APIs for platform changes;
wrong HEAD, unprotected/moved main and missing current rights; and eligible
current content with an incompatible historical ancestor, without reuse or
download. Root content4/4 and prototype1/1 pass with zero skips. All four distinct
roles independently accepted this completed correction. Code review injected
the original selector locally and both new regressions failed for their intended
faults. Basic, bounded style, touched pinned ESLint and Prettier pass. The source
correction is committed atee4ca54; actual source/test bytes are retained there.

A narrow diagnostic of the22 modules behind the native buffered frontier,
using the existing isolated worker/cap4 and local Node24.22.1, completed in62.637s:
344 tests,343pass/1fail, zero skips. It remains a failed diagnostic. The one failure
was the existing repository-lint test running with uncommitted changes: the
canonical clean guard correctly rejects before creating its scanner report.
After committing the source, that same case passed1/1 in0.502s. No guard/test fix
or waiver was needed. The previously unreported publishing adaptation case also
passes alone1/1 in3.243s; ordered native TAP alone did not establish a hang.

Actual local per-file summary events measured publishing43.289s/17pass,
quality-sources33.656s/34pass plus the dirty-precondition failure, and
site-articles31.630s/18pass. They were native selected positions58,59 and70;
these positions are not measured native start times. Requirements approved
adding only these three measured long files after release-controller and before
pages-migration in the existing priority list. All ten prior priorities retain
relative order, with the same lexical remainder. This is a scheduling hypothesis,
not a measured native speedup or completed acceptance result.

One behavioral regression records actual serial-worker per-file summaries,
verifies all five selected fixtures in order and requires complete zero-skip
accounting. Existing four-worker overlap/ceiling, failure and SIGTERM/SIGINT
coverage remain. Root scheduling7/7 passes in4.870s, including both signal cases;
touched pinned ESLint and Prettier pass. README now describes the actual existing
Math.min(4, availableParallelism()) ceiling rather than its stale allocation.
One180s/16MiB source process and210s reporting wrapper, selected membership,
isolation and all failure propagation remain unchanged. Fresh exact-head native
Basic/source/RI/owning/preview is still required; F5 and remaining whole ACs stay
open until that evidence is reconciled.

All four actual scheduling follow-ups completed on these same three changed
owners: Requirements passes the bounded hypothesis/unchanged obligations;
Code independently passes the real worker case1/1; White-box passes3/3 and
temporary old-order/dropped-module fault probes; Operator passes3/3 covering
order, four overlapping slots and isolated failure accounting. No role claims
a native speedup, complete full-source pass or completed F5. The final source
and deterministic metadata may now be uploaded while Draft to request fresh
native verification through the existing Ready event.

### F5 second native result — performance remains open

Uploaded9a1ec67f/tree7ca262bf exactly matches reviewed local42efde9 tree.
The second native Basic run40207687553 again failed the original180000ms source
limit:502 emitted top-level passes, no emitted not-ok and no final accounting.
Its original report binds clean source before/after to that uploaded head;
stdout127568bytes and stderr0 remain far below16MiB. Artifact12604037447 retains
the original JSON/TAP/stderr. Fewer visible cases after reordering cannot prove
less coverage or slower execution, because Node buffers output by selected file.
The three-priority hypothesis did not achieve the required complete result.
There is no unchanged retry or full-source pass claim; PR146 returned to Draft.

At the same source native navigation40207687510, owning40207687525 and routing
observation40207687526 pass. Preview40207687582 build, publish and hosted runtime/
revision/two-width smoke all pass, including the formerly failing historical
baseline step. Its separate Staging admission job correctly remains failed until
the future F6 owner stage; it is not replaced by preview smoke or marked passed.

The actual maintained formatter receipt counts526files (280JS,9CSS,53HTML,
42Python,118JSON,24YAML). The earlier626 was a transcription error corrected
above; no formatter scope, result or source allocation changed.

A narrow source-bound diagnostic executes the original metadata-reconciliation
test callback through module-local dependency interception, without changing
process-global exports or repository sources. At9a1ec67f it observes529 primary
Python helper calls/35.090s inside that helper in36.194s total;307calls/20.872s
come from parsing evolving intermediate documents between amendments. These
are local diagnostic counts/timings, not native critical-path evidence or a new
acceptance pass. Preserve the primary parser, exact content/metadata refusal
and finite runtime/isolation contracts while reviewing one useful simplification;
no additional code change or reduced test obligation is authorized by this
diagnostic alone. F5 and the full remaining F6/R3c/R3d plan remain open.

### F5 bounded test factorization and file observations

Requirements independently confirmed that exact five-page content preservation
and metadata refusal do not require35 duplicate full amendment-chain replays.
The same existing metadata test retains all seven mutated inputs on all five
pages at restoreStructuredMetadata, including proof each mutation changes bytes.
Every Writing mutation still executes its original early full-path refusal.
All five positive full paths and the other compact/numeric/owner/duplicate/raw
HTML tests remain. Four non-Writing full paths retain distinct integrations:

| Mutation partition | Direct boundary | Additional complete-chain integration |
| --- | --- | --- |
| Foreign schema, changed language | All five pages | Both Writing refusals |
| Unknown field | All five pages | Home and Writing |
| Malformed JSON | All five pages | Research and Writing |
| Duplicate type | All five pages | Talks and Writing |
| Property order | All five pages | Credits and Writing |
| Metadata spelling | All five pages | Writing and unchanged compact-spelling tests |

The primary parser and every evolving-document validation remain byte-exact.
The same narrowly observed callback now makes193 interpreter/helper calls,
compared with529 before factorization. Its diagnostic explicitly identifies
the prepared test bytes against base8f05dc6, not a clean-base acceptance run.
The counts establish336 fewer interpreter starts; elapsed values from different
contention/profile conditions do not establish a native speedup.

Only the expensive direct-flight test replaces its twelve-frame warmup with one
real painted frame, then asserts actual draw count, ready/settled state, exact
source camera pose and the single existing ambient RAF. This deliberately begins
at the first ready ambient phase rather than after660ms of warm animation. All
40 fresh width/from/to visits, every80ms full-flight frame and cache/late-transit/
intermediate-room/destination assertions remain. Shared settle and all other
quality/cadence/phase/isolation/finite-argument tests are byte-exact. The changed
case passes1/1 without skips; a separate solo process records13.811s, distinct
from the earlier contended27.893s and prepatch profiled17.977s observations.

The existing worker adds a private, optional stderr observation: capacity once,
then at most one dequeue/completion per validated selected file. The2N+1 bound
excludes forwarded inner cases, including names identical to selected files.
OS capacity, configured parallelism and effective ceiling are separate fields;
monotonic elapsed and native file-wrapper duration include process overhead and
are not CPU time or body-start timestamps. Only canonical TAP/complete zero-skip
accounting establishes pass. Synchronous diagnostic write failures are isolated;
all existing run/summary/error/abort/exit handling and16MiB/180s bounds remain.

Root metadata6/6 and scheduler/observation8/8 pass without skips. A QA fault probe
found the first nested-name regression could accept a wrong inner duration even
with correct record count/order; the production filter was already correct.
The corrected test independently records outer nesting-zero wrapper events and
compares exact file/duration/status, passing1/1. Removing only the entryFile guard
now fails that exact oracle. Separate actual tiny passing/failing workers retain
their original exit/accounting even when every diagnostic write throws or writes
nothing. Four actual completed Requirements/Code/White-box/Operator follow-ups
accept the final five-owner correction, including this corrected oracle. These
bounded results support one substantively changed native request; both prior
native failures remain failed, and F5 still requires complete native79 accounting.

The first local RI preflight reported three stale-view errors because its view
was built before the changed coupling map was refreshed/formatted. This guard
correctly rejects the prior map hash. Rebuild the derived view after the final
canonical map, then rerun the same29 RI cases; preserve the original failed log.
No source classifier, RI rule or test expectation changes for this correction.

### F5 complete native accounting and portable observation correction

Native Basic40211425193 at clean2db45d3e/tree357a465c completes all79 selected
modules in129265.093911ms, within the original180000ms budget. Its final native
accounting is1155tests/1154pass/1fail/0skip/0cancel/0todo; process error is null.
The run remains FAILED. The single failure is the new observation regression;
navigation40211425137 and owning40211425152 correctly reject the same defect.
Preview40211425160 build/publish/hosted two-width smoke pass; F6 Staging admission
still has no owner-stage proof and is not claimed passed.

The original artifact12605643106 retains matching source JSON, raw TAP and stderr.
Its159 timing records contain exactly capacity plus79 dispatch/completion pairs;
actual OS/configured/effective capacity is4/4/4. Last completion is129264ms.
Space file wrapper measures65.096s and Executive49.470s, including process
overhead. These are current-run observations, not a causal speedup allocation
or a pass relabelled at the later correction.

The stronger oracle exposed a portability error: pinned Node24.19 does not
reliably supply the optional entryFile field used by the local24.22 probe.
Nested selected-name test durations could therefore precede file completion.
The sole production correction also requires the documented numeric nesting0,
keeping path/name/entryFile/seen guards and all authoritative handlers unchanged.
Unknown depth omits optional observations. These advisory fields cannot prove
arbitrary malicious top-level name authenticity; canonical accounting separately
rejects filename-only top-level captions and remains the acceptance authority.

The existing regression now runs both native-metadata and absent-entryFile
partitions on the actual returned stream. A test-only prepended listener removes
that optional field before observation, with a sidecar proving genuine nested
selected-name events retain depth1 and lack the field. Independent outer-wrapper
duration/status equality remains exact. Removing only the depth guard fails this
case on local24.22 too, without changing its canonical four passing assertions.
Root scheduling/portable observations9/9 pass with zero skips; all four distinct
completed correction roles accept, and Code/White-box/Operator independently run
both partitions and fault probes. Pinned touched ESLint/Prettier pass. This
supports fresh corrected-source native verification; no budget,79module set,
parser, flight matrix, auth rule or prior failed result is changed.

### F5 completed source phase — verified269ef3a

F5 is complete for actual clean source269ef3a/tree07875713. Native Basic
run40212736835 passes the same79 selected modules:1156/1156 tests, zero failures,
skips, cancellations or todos, in148649.484593ms under180000ms. Process status0,
signal/error null; original16MiB bounds remain. Source before and after resolve
to that same immutable commit/tree, with sourceDirty=false. Artifact12606630749
retains byte-verified original JSON/TAP/stderr; no later receipt head substitutes
for its source. Both portable observation partitions, metadata and40-flight
cases pass natively. The159 advisory rows cover79 unique file pairs at actual
OS/configured/effective capacity4/4/4; TAP/accounting remains the pass authority.

| Actual native evidence at269ef3a | Result |
| --- | --- |
| Basic/source40212736835 | PASS; full lint/format/architecture, five-route Basic and79-module source accounting. |
| Navigation/RI40212736750 | PASS. |
| Owning acceptance40212736805 | PASS in its mechanical scope; whole-issue closure remains false. |
| Routing observation40212736749 | PASS. |
| Preview40212736808 build121227433274, publish121227648690, smoke121227804265 | Each job PASS, including exact hosted revision/runtime and two widths. |
| Same preview's Staging admission121227354233 | FAILURE: no completed F6 owner-stage proof. The workflow aggregate remains failed; it is not all-PR-checks-green or delivery acceptance. |

Four actual distinct final readbacks independently verify the physical native
archive/member bytes, clean source binding, full raw accounting and their reviewed
source hashes. Requirements accepts the bounded code/native phase only; Code
checks all13 reviewed source/test/control hashes; White-box confirms both native
portable cases and exact selected-module set; Operator verifies all79 observed
file pairs without treating them as coverage. No reviewer reran a full campaign.
The two local partial runs, two native timeouts and complete-but-failed2db run
remain retained with their original dispositions. Full scanner receipts remain
bound to their original fedba source; fresh full owner-stage scanners belong toF6.

The following receipt-only owner/MEMORY/RI commit is a different source. It inherits
no269 test result, artifact or admission. Requirements independently confirmed
the finite handoff: return PR146 to Draft, record these fixed source-bound facts,
validate current receipt metadata/policy, then use actual fresh current-head
checks, source/artifact leases, one owner stage and genuine App forF6. Recording
the receipt does not require a recursive79-module/preview campaign and cannot
waive any future delivery gate. No whole parent AC is newly checked; onlyAC02
remains complete. Remaining plan isF6 platform delivery, R3c meaningful independent
content/recovery, thenR3d whole-acceptance/contracts/timing reconciliation.

### F6 native preflight and explicit ordinary-edition fixture

F6 started on clean808dae28/tree67040e44 against protected mainbea2628. Four
distinct resumed roles accepted the receipt-only successor for fresh verification;
the complete PR still selects the conservative website/control route. The live
ruleset retains all five required contexts, strict up-to-date and no bypass.

Basic40215263460/1 failed at180000ms:582 emitted passes, zero emitted failures,
no final accounting. Its original source ZIP12607311711 is retained. All40
completed modules whose earlier duration exceeded1s were slower1.26–1.73times
than tested269, median1.42. This supports observed timing variation, not a proven
infrastructure cause. Requirements and White-box independently verified raw
bytes and the issue's single reasoned retry rule. The sole complete Basic retry,
40215263460/2, passes79modules/1156tests, zero fail/skip/cancel/todo, in142025.489ms.
Original180s/16MiB/cap4 remain. ZIP12607671843 and its original JSON/TAP/stderr
were independently verified by Code and White-box. Both attempts stay bound
to clean808; the first failure is not overwritten or combined with the second.

Current RI40215263200, owning40215263302 and routing40215263293 pass. Preview
40215263318 build121235009682, publish121235237641 and two-width smoke121235377150
pass; its separate pre-stage admission remains failed. The sole owner command
6400759799 started main-owned stage40216194800/1. Its trusted target log binds
PR146/source808/basebea/run/attempt; begin-admission passes.

Stage build121237869950 fails before deployable upload. Original prepublication
ZIP12607682957 retains all26 guards:25pass, including128 Python tests, complete
lint/security/advisories, current RI/style and artifact/rights/package checks.
The74-module source process times out at180s, with566 emitted passes, one actual
failure and no final accounting. Its module set excludes five existing diagnostics
from PR's79; no membership was changed. Publish, hosted gates and promotion are
skipped; merge-admission fails and no genuine App or merge is requested.

The actual failure is the ordinary three-edition fixture in
tests/color-motion-contract.test.cjs. Protected main's controller defaults
SITE_ARTICLE_PREVIEW totrue, whereas the candidate Ready workflow selectsfalse
for PR146. artifact.build inherits that environment unless its existing explicit
articlePreviewMode option is supplied. The fixture accidentally builds a
candidate article preview and then asks the production-edition owner to convert
it. The unchanged production guard correctly refuses. The retained stage artifact
is a review preview, not an approved or published article.

Requirements accepted one narrow test correction: explicitly selectfalse for
this ordinary fixture. No global environment reset, workflow, production guard,
runtime, article, rights, budget or selected test is changed. Original808 under
preview=true reproduces the exact refusal. The corrected existing case passes
undertrue andfalse; all26 Color cases pass undertrue, zero skips,12.079s locally.
All three editions, canonical/immutable byte checks, tampering and missing-rights
refusals remain. Touched pinned lint/format, Basic and bounded style pass. This
fixes the deterministic fixture failure; it does not establish a timeout cause
or native performance acceptance. Fresh corrected-source gates remain required.

Four actual resumed correction roles completed: Requirements accepts the exact
fixture/receipt scope; Code verifies the unchanged production owners and all
remaining assertions; White-box independently verifies selector/refusal boundaries
under both environments and finds no second ordinary-to-production default in
the selected74-module inventory; Operator executes both ordinary environment
cases and the existing genuine preview-to-production/sitemap refusal,3/3pass.
Their identities remain /root/f3_requirements, /root/f3_code, /root/f3_whitebox and
/root/f3_operator. Reviewed test SHA begins16228378; roles retain the full digest
and raw scoped receipts. RI29/29 and coupling20/20 pass. This supports corrected
source verification only, not a completed native stage or inherited808 acceptance.

F6 is incomplete. PR146 returned Draft for this correction. Next is exact-head
Basic/RI/owning/preview, then the existing complete owner stage, genuine App,
protected merge and actual postmerge. R3c meaningful content/recovery and R3d
whole-AC/contracts/timings remain; only wholeAC02 is complete. CS01/04/05/07/08/10
map to explicit fixture input ownership, unchanged failure guards, bounded
before/after checks and source-bound evidence. No unchanged stage retry follows
from this correction.

### F6 corrected-head native verification — blocked

Actual corrected source7d8706d3e42d2d3edf06a0b47170f04e3f4d35d5 has tree
de86948c7f1acf5bddb4dee4d231bbc13dfbb917. This section is a local receipt prepared
after its native executions, not a newly admitted source or another retry reset.
Live issue122 and PR146 retain the current outcome and full remaining plan.

Basic40217820258/1, job121242690708, fails180000ms with ETIMEDOUT/process1.
It emits582ok/0not-ok and no final accounting:58modules start,54complete with
passing wrappers,4remain running and21never start. ZIP12607944489 is41801bytes,
SHA25672992696b797d278a802b8a7fb499b75764288eb7c62ccf38f5522fb8966a78b.
Original ZIP CRCs and extracted JSON/TAP/stderr bytes were verified.

Requirements and White-box independently verify the genuine fixture correction,
unchanged test/runtime/membership/limit inputs and actual broad timing variation:
all35 completed modules previously over1s are1.40085–1.83375times slower than
passed808, median1.54964. Corrected Color passes and starts after Space/Executive
complete, so the correction cannot explain their earlier slowdown. This is not
proof of an infrastructure cause. The existing issue rule permits exactly one
evidenced complete retry for this corrected source; both roles accept that scope.

The sole complete retry40217820258/2, job121244681727, also fails180000ms with
ETIMEDOUT/process1. It emits582ok/0not-ok without final accounting:63modules
start,59complete with passing wrappers,4remain running and16never start.
ZIP12609345181 is41981bytes,
SHA25656547593eccb3d6082e5ad71dd6ccbdba4574128b220835ac0edb52eb6c2870c.
White-box independently rehashes the ZIP and verifies all three exact raw members
and failed accounting. Partial success is not selected-source acceptance.

Both attempts are clean7d/tree de869 before and after, Node24.19.0, exactly79
selected modules, OS/configured/effective capacity4/4/4,180s and16MiB unchanged.
Corrected Color wrappers pass13.023s/13.214s, including the actual ordinary-edition
case. Retry Space takes110.711s, Executive79.865s and release-rights54.178s.
These are observed module durations, not a newly proved critical-path cause.

RI40217820193, owning40217820195 and routing40217820169 pass at7d.
Preview40217820293 build121242899563, publish121243126895 and smoke121243281796
pass; smoke executes1440/390 normal/no-canvas cases. Separate Staging admission
121242824185 fails without corrected owner proof, so the aggregate is not green.

PR146 returned Draft at2026-10-25T17:57:45Z, still open/unmerged at7d/basebea.
No corrected ownerstage, App, protected merge, stable promotion or production
action was requested. The unsubmitted App form grants no evidence. Main and PR79
remain unchanged. Historical808 stage failure and all earlier failures remain.

F6 is blocked. No further unchanged retry, metadata-only reset or speculative
source churn is permitted. Next is bounded diagnosis of actual repeated test
cost; any concrete correction needs affected four-role review and fresh evidence
under the same cases and budgets. Then complete current checks, ownerstage,
genuine App, protected merge and actual postmerge. R3c meaningful content/recovery
and R3d whole-AC/contracts/timing follow; only wholeAC02 remains complete.

### F6 bounded test-cost correction — 25 October 2026

Fresh live revalidation retained mainbea2628, DraftPR146head7d8706d and
the two failed native attempts above. The local9fe636b checkpoint was preserved;
its receipt is included here without using it to reset remote eligibility.
The maintainer requested continuation of the next bounded F6 step.

**Changed owner:** tests/space.test.cjs only; corrected bytes888cfd4d…194450a3.
The actual visit fixture keeps isolated realms and its existing12-frame settle.
Eighteen cold navigation setup sites now use paintInitialRoute: zero prior draws,
one actual60ms frame, exactlyone draw, ready stringtrue, settled travel, exact
model-derived initial route pose and one pending ambient callback. These are six
assertions, not a time-only readiness assumption. No mutable setup is cached.

Removing the added helper and reversing exactly18 call substitutions reproduces
the actual7d file byte-for-byte. All72 ordered Space test declarations and every
original assertion/route pair/flight-frame loop remain. The40flight fresh-context
matrix is untouched. Native scrolled-pose generation, post-scroll/focus/resize/
lifecycle settling and distinct warm-remount settling remain exact. This reduces
redundant cold-start ambient paints; it does change that setup's temporal sampling.
Executive and its ordered metadata/refusal/parsing boundaries are unchanged.

Matched local commands ran both full modules sequentially on Node24.22.1, with
no source mutation during either execution. Baseline is clean7d; the candidate
is dirty7d with only the corrected Space bytes. Raw spec-reporter output, stderr
and source-bound JSON records are retained as issue122-f6-cost-before/after in
the local diagnostic directory. The .tap suffix of those files does not make
them canonical TAP or selected-source admission.

| Observation | Actual before | Actual after |
| --- | ---: | ---: |
| Whole-command wall seconds | 148.950 | 170.184 |
| Sum of72 Space test seconds | 73.708 | 73.116 |
| Sum of23 unchanged Executive test seconds | 74.536 | 96.339 |
| Complete test accounting | 95/95 | 95/95 |
| Failed/cancelled/skipped/todo; stderr bytes | 0/0/0/0;0 | 0/0/0/0;0 |

The unchanged ordered95 names and stable source hashes establish scoped
integration preservation. These observations do **not** establish an overall
speedup, a native timeout fix or an environmental cause. No unchanged retry
or broad Executive refactor follows from them.

| Independent role | Actual separate execution and result |
| --- | --- |
| Requirements | /root/f6_cost_requirements: independently fetched live owner/PR, reviewed scope before implementation, proved exact reverse preservation and all18 cold sites, then read both actual measurement records. Accepts the bounded correction and one fresh native verification; whole acceptance remains open. |
| Code | /root/f6_cost_code: inspected actual source/diff; Acorn confirms72 ordered test names, correcting an earlier71-name regex miss. Exact reverse proof and one positive/seven rejecting helper probes pass. Independently read both measured outputs. Accepts bounded source and honest measurement limits. |
| White-box | /root/f6_cost_whitebox: separately proved exact reverse preservation and inspected all18 sites. Extracted actual helper passes five routes plus default and rejects nine injected paint/readiness/pose/clock faults. Independently reads95/95 and stable hashes; accepts scope, not timing acceptance. |
| Operator | /root/f6_cost_operator: actual CLI PRplan remains exactly79modules with the same reasons; staging remains exactly74. Runner/worker/registry/Executive bytes are unchanged. Five routes plus default and eight invalid fixture states give14/14 helper probes. Independently reads both measured executions; accepts verification, browser/device scope inapplicable to this test-only delta. |

AC04/07/08 and CS01/04/05/07/08/10 map to the test owner, unchanged inventories,
real pinned lint/format, bounded style/Basic/RI/owning checks, exact preservation
and four separate review executions. No parent criterion is newly complete.
No runtime/producer/rights/scanner/registry/workflow/limit owner changed.

Prepared-source checks pass: full pinned formatting with no changed files,
real touched-JS lint with zero warnings, Basic five routes/16theme+archive/
10flight cases, bounded style143files, fresh RI1756files/200dirs and29regressions,
coupling20regressions and17checks/17layers. Derived catalog/map topology and
the RI/CI map remain unchanged; only the existing agent-context projection
needs regeneration. These local results do not supply clean native admission.

**Next:** commit the reviewed source and deterministic metadata, verify its exact
clean identity and request one fresh native Basic/source/RI/owning/preview run.
The same79/cap4/180s/16MiB and zero-skip accounting remain mandatory. Failure
stays blocked with no unchanged repeat. F6 ownerstage/App/protected merge/
postmerge, then R3c meaningful content/recovery and R3d whole-AC/contracts/timing
remain. The current correction grants no staging, merge or production acceptance.

### F6 test-cost native verification — blocked

Actual uploaded sourcee36f7292208480a8a993c2eec72b57ef01c263dc has reviewed
tree8c247724a03a5b1ba150f31e70526ff5c62d3233. Local authore2a6fc7 has the
same tree and empty diff; all four roles independently read back the actual
uploaded identity. Fresh clean expected-e36 owning policy passes all five checks.
No locale2 native evidence is relabeled. This final section is a local-only
receipt, not another remote eligibility reset or new native verification request.

FreshBasic40223631087/1, job121260316080, fails ETIMEDOUT180000ms/process1.
The actual report binds clean sourcee36/tree8c before and after, exactly79modules,
Node24.19.0 and configured/available/effective capacity4/4/4. Original16MiB
output and180s deadline remain. RawTAP emits582ok/0not-ok with no final Node
accounting; all observedAccounting arrays are empty. Partial output is failure.

Raw timing records show66unique module starts,62completed/passing wrappers,
4running and13unstarted. Space passes100.205881s; Executive passes78.324698s.
The62 completed wrappers sum686.479worker-wall seconds, or171.620 at cap4;
this is not CPU time or a complete-run prediction. Aggregate unfinished work
remains beyond the Space setup correction; no unique cause or timeout fix is proved.

Original artifact12610498119 is42067bytes,
SHA256efb6636d94853eb1f5af4a77da3324108b40d5511c2f63ef30a12637dba38566.
The ZIP digest/CRCs and all three extracted raw files were physically verified.
Requirements and White-box separately rehash/read the actual archive and agree
on the exact source, failed deadline, partial accounting and blocked disposition.
The actual selected lint report passes at e36/tree8c; this is not full security.

RI40223631113, owning40223631037 and routing40223631071 pass. Preview40223631094
build121260507550, publish121260686937 and hosted smoke121260832013 pass.
Separate Staging admission121260431114 fails without current owner proof;
the aggregate is not green. No ownerstage/App/merge/production action follows.
PR146 is Draft again at the unchangede36 remote head, mainbea2628.

No unchanged retry is requested or performed. Next bounded work is actual
invocation/input-cost attribution across recurring fixture builds, HTML parsing
and subprocesses. Any correction must first demonstrate its concrete saved work
and preserve scenarios/refusals/bounds with affected four-role review, before
another fresh candidate verification. Do not restart an unchanged full campaign.
F6delivery, R3cmeaningful content/recovery and R3dwhole acceptance remain;
only parentAC02 is complete. Live issue/PR contain the actual final outcome.

### F6 diagnosis — execution costs and runner hardware

The maintainer requested diagnosis first: identify what became expensive before
making another correction. This inspection changes no implementation, test,
selection, budget, readiness or delivery state. Remote source remains e36f729,
mainbea2628 and PR146Draft. Local a892f58 contains only prior receipts over the
same implementation bytes. All measurements below are observations, not admission.

**The selected suite did not expand; production/parser code remained unchanged.**
All five retained source archives select the identical ordered79modules under
Node24.19, cap4,180s/16MiB. Between808 ande36 only the Color/Space tests and
review/MEMORY/derived RI changed; Executive, Python/JS parsers, production
engine, source selector, worker and registry remain byte-identical.

| Actual source / native observation | CPU model recorded in lint environment | Source result |
| --- | --- | --- |
| 808dae2, Basic40215263460 attempt1 | AMD EPYC7763 | 180s timeout |
| Same808dae2/tree67040e44, attempt2 | AMD EPYC9V45 | All79modules/1156tests pass142.025s |
| 7d8706d, Basic40217820258 attempts1and2 | AMD EPYC7763 | Both180s timeouts |
| e36f729, Basic40223631087 attempt1 | AMD EPYC7763 | 180s timeout |

All records show four allocated CPUs, identical Node/OS/image-version fields
and16,766,414,848memory bytes. The64-/96-core strings describe the host model,
not allocated capacity. Hardware-model variation is directly recorded. Its
association with broad slower execution is strong, including the unchanged808
pair; CPU frequency/load/host contention were not measured, so sole CPU-model
causality is not proved. Lint's environment imageVersion is20261023.334.3;
the raw job's separate Runner Image group reports20261012.334.1, also unchanged.

| Module wrapper seconds | Complete808 pass | Latest e36 timeout |
| --- | ---: | ---: |
| Space | 76.489 | 100.206 |
| Executive / frozen HTML reconciliation | 55.080 | 78.325 |
| Release rights | 36.543 | 54.668 |
| Release controller | 27.409 | 40.623 |
| Publishing | 20.355 | 30.923 |

Wrappers run in parallel; these columns are not whole-job wall totals. The62
common completed wrappers rise479.644→686.479worker-wall seconds (+43.1%).
All41 that previously exceeded1s are slower, with median ratio1.478. Latest
completed wrappers plus running ages occupy719.943 of720available worker-slot
seconds. This establishes occupied slots, not measured CPU utilization. Repeated
582emittedTAP passes reflect ordered output buffering, not all executed assertions.

**Executive: repeated full-document restoration and synchronous Python starts.**
One actual named contact/title test was profiled locally with V8 sampling and
coverage. It passes1/1 in14.161s on Node24.22 with test-isolation=none. Coverage
records22full restore calls,301parseHTML/helperContracts calls,597normalizeHTML,
252normalizeMany,12Writing view rebuilds and6event collection restorations.
Each helperContracts call starts one Python process;306total synchronous child
spawns comprise301Python helpers and5Git calls. The sampler attributes
13.028320of14.028598sampled seconds (92.87%) to synchronous child spawning,
including parent blocking/waiting; this is not Python or parent CPU accounting.
The existing128-entry/4MiB exact-byte cache and ordered validation remain intact.

A bounded synthetic transport probe uses the same actual helper and30tinyHTML
requests:30separate processes take1166.096ms, one30-request batch37.046ms,
with exactly identical ordered contracts. This demonstrates small-request
process/boundary overhead locally; it is not a full-restore or CI speed prediction.

**Space: real geometry in a simulated browser.** The unchanged40-flight/two-width
case passes1/1 under the same local diagnostic method in17.430s. Coverage records
40fresh visits,960actual scene frames,7,473,224point projections and147,305
cameraVertices calls. The sampler assigns14.110of17.115sampled seconds
to the scene bundle, with projection/clipping/shape composition/drawing dominant;
the Canvas stub callbacks, including numeric-argument checks, receive1.604sampled
seconds. There are no sleeps implied
by p.frame(80): that argument advances the logical animation clock. This case
alone costs16.534s in latest native Space, versus10.368s in the complete808pass.

**Rights: repeated artifact inventories/compression and fixture copies.** One
actual inventory case passes1/1 locally in1.670s; coverage records one fresh
fixture/build, seven public-artifact manifest calls and401zlib buffer calls.
The sampler records0.578of1.582sampled seconds in synchronous compression,
mostly the public manifest's per-file gzip, and0.121s in recursive directory copy.
Its fixture mistakenly supplies the node_modules filter to mkdirSync while
cpSync has only recursive=true. Thus tools/publishing/toolchain/node_modules
is included. Local inventory is1,142dependency files/~21MB; thirteen call sites
could copy~274MB logical dependency bytes plus cleanup if each executes once.
This is a local/static estimate, not native I/O or timing attribution. The misplaced
filter predates F6 (75d6da51,18October); it is existing cost, not the new regression.

**Separate job overhead:** raw command-group boundaries show source-tool install
8.827→14.223s, earlier-generation selection30.208→47.443s and lint7.346→10.015s.
Those run before the source child and do not consume its180s budget. The source
wrapper itself is145.126→184.791s. History selection refuses23earlier candidates
before artifact download; it does not rebuild23old article editions. No archived
article browser/PDF campaign was reintroduced. No browser/Ubuntu installation is
inside this source job. Whole-suite network-syscall absence was not measured.

Raw native archives and current local profile/coverage summaries are retained in
the existing diagnostic directory. A strace attempt failed immediately with
PTRACE_TRACEME Operation not permitted; it executed no test and supplied no
syscall trace. The three bounded named-case profiles and transport probe are
diagnosis only, not repeated79-module campaigns or canonical native acceptance.

Independent roles separately inspected the original artifacts/source: Requirements
reconciled identical-source hardware and workload comparisons; Code checked the
restoration/process boundary and misplaced copy filter; White-box verified timing,
occupied-slot arithmetic and Space coverage; Operator verified actual job boundaries,
CPU/environment records, history refusal order and archive-test allocation.
The distinct reused identities /root/f6_cost_requirements, /root/f6_cost_code,
/root/f6_cost_whitebox and /root/f6_cost_operator each executed fresh diagnostic
follow-ups and actual report/raw-evidence readbacks. Requirements/White-box
precision findings narrowed the suite-equality and Canvas/camera-call wording;
their corrections do not change source, measurements or blocked disposition.
Final report/profile readbacks are recorded in the session's issue/PR outcome.

The diagnosis points first to repeated Python process boundaries and repeated
fixture/inventory work for a future bounded correction. Changing geometry coverage,
CPU selection or deadlines is not implemented or authorized by this diagnosis.
F6 remains blocked, then R3ccontent/recovery and R3dwhole acceptance remain;
only parentAC02 stays complete.

### Diagnosis-first workflow — 25 October 2026

The maintainer requested an enduring failure workflow in AGENTS: do not rerun
failed tests unchanged or guess fixes; inspect what failed and why, then plan
bounded diagnostic actions or evidence-supported fix hypotheses. AGENTS routes
to the canonical six-step CONTRIBUTING flow. Existing retry controls describe
mechanics and supply no automatic retry permission. The current failure remains
Basic40223631087/1 on e36; no new source acceptance or delivery follows.

**Next diagnostic question, recorded before execution:** in the already-profiled
Executive contact/title case, which exact helper inputs repeat, at what call
sites, and does cache eviction account for repeated parsing? Existing V8 branch
coverage distinguishes276single-input misses from25batch parser calls; those
counts alone cannot identify full documents, fragments or eviction causes.
Use one execution of that named case with read-only V8 debugger observations of
normalizer lookups/parser entries. Capture ordered SHA256/UTF-8 sizes, cache
occupancy and call-site provenance without changing source/parser/cache/guards.
Bound execution to120seconds and at most4000observations; stop after that one
case, retaining failure if instrumentation fails. This new information, rather
than another broad timing profile, can distinguish duplicate work from necessary
ordered document validation. Debugger timing is not performance evidence or
native acceptance. No unchanged79-module campaign, fix or readiness transition.

**Executed diagnostic:** the one named contact/title case passes1/1, with zero
failures/cancellations/skips/todos. Local Node24.22.1 records1646observations:
1067cache lookups,301parser entries and278evictions, with no instrumentation
errors. The22.176s instrumented command is not a speed measurement. Git head is
6061e96 with only AGENTS/CONTRIBUTING/review dirty; actual SEO normalizer, JS/Python
helper and Executive test hashes are identical before/after and to e36. Inspector
breakpoints read local arguments/cache state and resume execution; no function,
parser, source, cache or global monkeypatch is installed.

| Actual parser boundary | Python starts | Input rows | Full-document rows |
| --- | ---: | ---: | ---: |
| Single-input normalization | 276 | 276 | 256 |
| Existing batch normalization | 25 | 80 | 4 |
| Total | 301 | 356 | 260 |

All356parsed input SHA256 values are distinct: **zero identical inputs are parsed
again in this case**. Their total UTF-8 input is5,231,293bytes;260full-document
rows account for4,880,088bytes. Full-document classification means a leading
HTML doctype, independently recorded from call-site provenance. The1067lookups
include711hits:321single and390batch;356misses become exactly356parsed rows.

The existing cache reaches128entries and4,193,779bytes within its4MiB bound.
Of278evictions,149hit only the entry bound,125only the byte bound and4both.
Those evictions do not cause duplicate parser inputs in this observation. Thus
the hypothesis that enlarging the cache would remove repeated helper work is
contradicted for this named case; other Executive cases remain unobserved.

Caller attribution identifies169single-input starts on evolving full documents
inside the ordered amendment loop (2,674,947input bytes). Existing hash-verified
amendment snapshots use21batch starts/74fragment rows; structured metadata uses
4batch starts/6rows. The remaining single starts cover restoration boundaries,
approved-content/presentation/event steps, initial documents, frozen Research
navigation and20independent fragments. Unique intermediate documents cannot
be treated as repeated immutable inputs or blindly batched across dependencies.

Retained raw observations are2,164,817bytes, SHA256
a930e040ac54068b0b28acaf80aa341c9f7501d44fd255cc5845ff9328536a57;
observer SHA256ee1b547ea7f08a886dd6124098f29b67a5822339afb51d75bb40a8b7aa2964f6.
The command/source hashes, canonical1/1TAP, exact ordered input hashes/sizes,
lookup/eviction records and derived summaries remain in the diagnostic inputs
directory. The observations independently reproduce prior V8 branch counts.

**Native tail inspection:** at180s the four running modules are delivery
observation, quality, release archive and renderer;13modules have not started.
Their work is not merely unflushed reporting. Five of the13unstarted modules
(Writing variants, profile selection, review flow, staging reporting and Writing
quality) account for36.257of38.565worker-wall seconds in the faster808pass.
These historical durations are not lower bounds or current completion estimates.
Actual720available worker-slot seconds are almost entirely occupied; this is
not measured CPU utilization, and no unconditional required saving is established.

**Runner identity follow-up requested by the maintainer:** the slow attempts
share a CPU model, not one registered runner. Actual job metadata gives distinct
runner IDs and raw job logs give distinct Worker IDs; slow attempts span eastus,
northcentralus and eastus2. These fields do not establish physical-host identity.

| Retained native observation | Runner ID | CPU model | Source result |
| --- | ---: | --- | --- |
| 269ef3a, Basic40212736835/1 | 1000007726 | Intel Xeon6973P-C | 1156/1156,148.649s |
| 808dae2, Basic40215263460/1 | 1000007747 | AMD EPYC7763 | Timeout180s |
| Same808, Basic40215263460/2 | 1000007753 | AMD EPYC9V45 | 1156/1156,142.025s |
| 7d8706d, Basic40217820258/1 | 1000007765 | AMD EPYC7763 | Timeout180s |
| Same7d, Basic40217820258/2 | 1000007774 | AMD EPYC7763 | Timeout180s |
| e36f729, Basic40223631087/1 | 1000007783 | AMD EPYC7763 | Timeout180s |

The earlier known F5 success was checked as a possible counterexample: it uses
Xeon6973P-C, not7763. Git comparison269→808 changes only review/MEMORY/derivedRI;
implementation and tests are identical. All six expose four allocated CPUs.
The F5 record has16,765,378,560memory bytes, slightly different from the other
five's16,766,414,848; the earlier identical-memory statement remains scoped to
those five. F5 archive SHA256 is
c6f5377f953acdc4f345174fc3f02711f53935a91dc763276ba3e826a054bfa5.
Exact six-row metadata, Worker IDs/regions and archive bindings are retained in
operator-runner-comparison-six.json. Within these six observations, four7763
runs fail and two runs on other CPU models pass. Hardware class remains the
strongest observed grouping; no successful7763 appears in this bounded sample.
That is not proof every7763 run fails or that CPU model alone causes failure:
frequency, contention/load and actual process CPU/wait accounting remain unknown.
No new native execution was needed to check this hypothesis. A code correction
is still premature while its relation to the failed deadline is unproved.

**Further bounded plan, not executed here:** distinguish Python startup/JSON
transport from actual parsing using the existing helper on a fixed, hashed sample
of actual current full HTML and approved fragments. Compare separate invocations
with one ordered batch and warm in-process contracts, keeping identical outputs
and reporting each boundary's timing separately. This can test whether reusing a
parser process while retaining every ordered validation deserves a fix proposal;
the earlier93%parent spawn/wait attribution does not isolate startup cost.
Stop after the fixed sample; no whole-suite or native retry is implied. Rejection
ordering, malformed/partial output, process failure, cleanup and bounds must be
addressed before any implementation proposal. F6 remains blocked; original79,
cap4,180s/16MiB and all acceptance/delivery gates remain.

All four distinct roles executed fresh work and final actual-source/raw-evidence
readbacks for this iteration: /root/f6_cost_requirements, /root/f6_cost_code,
/root/f6_cost_whitebox and /root/f6_cost_operator. Each accepted the actual
AGENTS/CONTRIBUTING flow, diagnostic counts/limits and six-row hardware correction;
all report no blocking finding. The roles independently recomputed raw counts,
checked source equality and archive/runner identities rather than accepting an
orchestrator summary. Their scoped acceptance supplies no native delivery result.

Prepared protocol/navigation checks pass: RI29/29, coupling20/20, root-layout15/15,
style guard143files and pinned formatting526files/zerochanges. RI views cover
1756files/200directories; coupling retains17checks/17layers, with only the two
guide input hashes and aggregate digest refreshed. Final clean-source owning
policy and uploaded identity are recorded in the issue outcome. No new suite,
workflow, profile, membership, budget, source test or production code is changed.
AC04/07/08 gain bounded evidence; only whole parentAC02 remains complete.

### F6 source deadline amendment — 25 October 2026

The maintainer approved reconsidering the global source deadline to finish#122.
[Dated decision6403603405](https://github.com/oborskyivitalii/oborskyivitalii/issues/122#issuecomment-6403603405)
supersedes the earlier180s freeze only for complete source execution: one fixed
300s child deadline plus the existing30s reporting grace, hence330s outer source
wrapper. The existing single owner executionLimits supplies actual spawn options,
reports and the derived wrapper. No timer is renewed per module and no CPU model
is filtered. All original180s receipts above remain failed at their exact sources.

Sizing uses retained complete passes142.025s/148.649s and observed broad slower
wrappers up to approximately1.83times:148.649×1.83≈272s, with about10%additional
headroom to300s. This heuristic is not a full-suite bound, speedup claim, promised
completion time or soleCPUcausality. It amends an operational CI deadline; browser
and product performance contracts remain. The Basic and prepublication build jobs
retain their existing10-minute ceilings, which still require actual verification.

Scope is the canonical source constant, active deadline oracles in the three
existing profile/publication/prepublication suites, current two contract guides,
owningAC04/COVERAGE/DELIVERY prose and required MEMORY/RI metadata. Selection79PR
and74staging,cap4,16MiB,isolation,zero-skip accounting,abort/reap and every scenario
and refusal remain. Scanner/default guards stay180s and all workflow/hosted/rights
budgets/gates stay. Further parser/cache/fixture refactoring is deferred.

Pre-edit Requirements independently accepts this exact amendment. Reuse the
three complete affected modules to verify changed deadline wiring, real source
reports, timeout/partial/skip/mutation/empty-module rejection, source330s versus
other180s dispatch and real SIGTERM/SIGINT cleanup. Independently observe actual
source spawn options without waiting300s. After applicable Basic/lint/style/RI,
four actual final roles and exact-source policy, request one fresh native
verification for this changed candidate. No unchanged failed campaign or new PR.
Current amendment verification/native acceptance remains pending at this entry.

Prepared verification now passes all73cases in the three complete affected
modules, zero failures/cancellations/skips/todos, in23.101s locally. This is
targeted correctness evidence, not a complete source performance measurement.
The existing negatives retain failed process/timeout/partial streams, source
mutation and zero-skip/empty-module refusal; real worker SIGTERM/SIGINT cleanup
and parallel-preflight abort cases pass. Test names and all other assertions remain.

White-box independently observes actual child_process.spawnSync options through
read-only V8 instrumentation:300000ms/16777216bytes, unchanged worker arguments,
one tiny selected module,1/1canonicalTAP/zero skips, no instrumentation errors.
Operator separately verifies unsupported CLI timeout overrides reject before
execution; both staging/production dispatch one330000ms source wrapper and all
other guards180000ms/16MiB. Injected source failure stays blocking and retains
original streams. Neither probe is native/full-source acceptance or a speed claim.

Basic passes5routes/16theme+archive/10flight cases; actual pinned touched-JS lint
has zero warnings and the style guard passes143files. Initial formatter/RI
preparation fails because the maintained RI/CI map's serialized bytes differ
from the hash captured by the generated index; the diagnostic comparison finds
only that map hash and aggregate RI digest differ. Original format-failure and
diagnostic records are retained. Canonical formatting followed by dependent RI
regeneration resolves the discrepancy before verification: formatting526files
has zero changes, RI29/29 and coupling20/20 pass, views cover1756files/200dirs
and the existing coupling retains17checks/17layers. No code/test correction
follows from that metadata failure. Actual selection remains79PR/74staging.

The four existing distinct role identities executed fresh requirement/code/
white-box/operator work, actual-source reviews and their own observations.
Exact clean-source policy, final uploaded-source readbacks and native completion
are separate remaining gates; this amendment inherits none of e36/808's results.

The first clean local policy run is rejected before checks: appending the full
exception to the already3971-character COVERAGE gate exceeds its4000-character
schema bound. The original failed JSON/log is retained. The correction keeps
that bound and the entire historical description, adding a short cross-reference
to DELIVERY; AC04 and DELIVERY retain the full dated exception. Policy validation
then succeeds. No criterion, check, gate or acceptance requirement is removed.
