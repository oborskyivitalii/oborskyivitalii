The Sum of Our Technology — R21 review copy

Extract the whole ZIP. Open The_Sum_of_Our_Technology_R21.md in a GitHub-flavoured Markdown viewer,
keeping images/ next to it. Two native GFM tables and four PNG figures are retained.

The Markdown is byte-identical to review.md in render artifact 68a248faffe167c077f9deee97d015a1ff64187a8f7d21a1389e309362f094e2.
It is a reading rendition, not the canonical authoring source or a platform post.
The canonical source is site/publications/pmday-ai-both-sides/manuscript.en.md.
Local image paths and authored captions/credits are the declared transformations;
no table-to-row-heading fallback is applied. LinkedIn/Medium outputs are separate.

Rights: Article by Vitalii Oborskyi; author-selected AI-generated Cover 02 and three original full-page UA Online PMDay 2026 Autumn v35 slide screenshots. Original source-deck and third-party credits remain applicable. Per-item publication clearance remains pending.
Selection: review; rights: review-pending; canonical: pending.
This review package does not establish publication or rights acceptance.

Administrative asset notes (intentionally outside the article):
cover: Author-selected AI-generated Cover 02, prepared 18 October 2026. Title-free detail is a lossless PNG encoding of the approved JPEG pixels. Four originals and six channel-image variants are retained in cover02/manifest.json. Publication and rights acceptance remain separate.
pmday-slide-03: Full-page slide 3 from Vitalii Oborskyi's v35 review deck. Source-deck and third-party credits preserved; publication rights pending.
pmday-slide-09: Full-page slide 9 from Vitalii Oborskyi's v35 review deck. Source-deck and third-party credits preserved; publication rights pending.
pmday-slide-12: Full-page slide 12 from Vitalii Oborskyi's v35 review deck. Source-deck and third-party credits preserved; publication rights pending.

provenance.json binds the source, semantic edition, render artifact and every
other package member. The ZIP itself is recorded in the dated R21 review receipt.
