from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import subprocess
import zipfile
import fitz

root = Path('/workspace/scratch/25351d6f7f8e/article-work')
work = root.parent
base = 'd488c64b825d60c4c6531f9cad2091eefc4a04ba'
path = 'site/publications/pmday-ai-both-sides/manuscript.en.md'
old = subprocess.check_output(['git', 'show', f'{base}:{path}'], cwd=root)
new = (root / path).read_bytes()
old_text, new_text = old.decode(), new.decode()
sha = lambda data: hashlib.sha256(data).hexdigest()
checks = []

def record(name, condition, detail):
    checks.append({'name': name, 'pass': bool(condition), 'detail': detail})

def section(text, first, last):
    return text.split(first, 1)[1].split(last, 1)[0]

def destinations(text):
    result = []
    for match in re.finditer(r'\]\(', text):
        start = match.end()
        index, depth = start, 1
        while depth and index < len(text):
            if text[index] == '\\':
                index += 2
                continue
            if text[index] == '(':
                depth += 1
            elif text[index] == ')':
                depth -= 1
            index += 1
        if depth:
            raise ValueError('Unclosed link target')
        result.append(text[start:index - 1])
    return result

prompts = lambda text: len(re.findall(r'^\*\*What if not\?\*\*$', text, re.M))
refs_old = section(old_text, '## Sources & references\n', '## How to cite this draft\n')
refs_new = section(new_text, '## Sources & references\n', '## How to cite this draft\n')
figures = lambda text: re.findall(r'^!\[.*$', text, re.M)
tables = lambda text: re.findall(r'(?:^\|[^\n]*\n)+', text, re.M)
record('prompt_count', prompts(old_text) == prompts(new_text) == 12, prompts(new_text))
record('source_notes_byte_equal', refs_old == refs_new, {'entries': len(re.findall(r'^\d+\. ', refs_new, re.M))})
record('figure_declarations_equal', figures(old_text) == figures(new_text) and len(figures(new_text)) == 4, 4)
record('tables_byte_equal', tables(old_text) == tables(new_text) and len(tables(new_text)) == 2, 2)
record('provenance_byte_equal', section(old_text, '## Review provenance\n', '## Revision history\n') == section(new_text, '## Review provenance\n', '## Revision history\n'), 'Contributor dispositions unchanged')
record('link_destination_multiset', Counter(destinations(old_text)) == Counter(destinations(new_text)), {'all_links_including_four_images': len(destinations(new_text))})
record('numeric_citation_count', len(re.findall(r'\\\[(\d+)\\\]', old_text)) == len(re.findall(r'\\\[(\d+)\\\]', new_text)) == 49, 49)

expected = [
    '## I. How We Build: Rebalancing the SDLC',
    '## II. What We Build: Engineering Control Around Model Judgment',
    '## III. What If Not? From Assumptions to Project Decisions',
]
record('combined_headings', all(new_text.count(h) == 1 for h in expected), expected)
record('planning_is_first', new_text.split(expected[2], 1)[1].lstrip().startswith('**Correct problem framing makes the required work visible before implementation.**'), 'Part III first paragraph')

result = json.loads(Path('/tmp/r30-native-result.json').read_text())
native = Path(result['directory'])
manifest = json.loads((native / 'manifest.json').read_text())
producer_files = manifest['producer']['inputs'] + manifest['inputHashes']
bad = [x['path'] for x in producer_files if sha((root / x['path']).read_bytes()) != x['sha256']]
record('native_source_and_producer', not bad and manifest['source']['sha256'] == sha(new), {'bindings': len(producer_files), 'mismatches': bad})
record('native_manuscript', (native / 'article.md').read_bytes() == new, sha(new))

evidence = json.loads((root / 'review/issue-2/r30-20261024/artifact-evidence.json').read_text())
prefix = 'The_Sum_of_Our_Technology_R30_2026-10-24'
delivery = work / 'r30-delivery'
readback = work / 'r30-delivery-readback'
zip_path = readback / (prefix + '_Native_Review_Kit.zip')
bad_members = []
with zipfile.ZipFile(zip_path) as archive:
    names = archive.namelist()
    expected_names = [m['path'] for m in evidence['archive']['members']]
    record('complete_readback_kit_inventory', len(names) == len(set(names)) == 34 and set(names) == set(expected_names), len(names))
    for item in evidence['archive']['members']:
        data = archive.read(item['path'])
        if len(data) != item['bytes'] or sha(data) != item['sha256'] or data != (native / item['path']).read_bytes():
            bad_members.append(item['path'])
record('readback_kit_native_bytes', not bad_members, {'mismatches': bad_members, 'archive_sha256': sha(zip_path.read_bytes())})
record('readback_zip_byte_identical', zip_path.read_bytes() == (delivery / zip_path.name).read_bytes(), sha(zip_path.read_bytes()))
record('readback_manuscript_byte_identical', (readback / (prefix + '.md')).read_bytes() == new, sha(new))
native_pdf = (native / 'article.pdf').read_bytes()
stored_pdf = (readback / (prefix + '.pdf')).read_bytes()
record('native_pdf_preserved', (delivery / (prefix + '.pdf')).read_bytes() == native_pdf and stored_pdf.startswith(native_pdf), {'native_sha256': sha(native_pdf), 'stored_sha256': sha(stored_pdf), 'native_bytes': len(native_pdf), 'stored_bytes': len(stored_pdf), 'appended_bytes': len(stored_pdf) - len(native_pdf), 'appended_c2pa_marker': b'c2pa' in stored_pdf[len(native_pdf):].lower()})
a = fitz.open(stream=native_pdf, filetype='pdf')
b = fitz.open(stream=stored_pdf, filetype='pdf')
same_pages = len(a) == len(b) == 22 and all(pa.get_text() == pb.get_text() and pa.get_links() == pb.get_links() and pa.rect == pb.rect for pa, pb in zip(a, b))
record('stored_pdf_text_links_dimensions_outline', same_pages and a.get_toc() == b.get_toc(), {'pages': len(a), 'pixel_comparison': 'Separately executed root transport receipt; not rerun by this role'})

paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base, '--', 'site/retained', 'site/publications/pmday-ai-both-sides/editions', 'review/issue-2'], cwd=root).decode().splitlines()
changed = []
for name in paths:
    baseline = subprocess.check_output(['git', 'show', f'{base}:{name}'], cwd=root)
    if not (root / name).exists() or (root / name).read_bytes() != baseline:
        changed.append(name)
record('historical_retained_bytes', not changed, {'files': len(paths), 'changed': changed})
record('owning_policy_unchanged', (root / '.github/acceptance/issue-5.json').read_bytes() == subprocess.check_output(['git', 'show', f'{base}:.github/acceptance/issue-5.json'], cwd=root), sha((root / '.github/acceptance/issue-5.json').read_bytes()))

report = {'baseline': base, 'prepared_source_sha256': sha(new), 'native_artifact': native.name, 'checks': checks, 'pass': all(c['pass'] for c in checks), 'role': '/root/r30_requirements', 'scope': 'Independent source/artifact/readback identity checks; not final clean policy or live delivery'}
Path('/tmp/r30-requirements-source-artifact-checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['pass'] else 1)
