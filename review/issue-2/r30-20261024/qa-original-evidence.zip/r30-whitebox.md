# R30 independent White-box QA — candidate review

Reviewer: `/root/r29_precision_qa`; separate from manuscript and native-print implementers.
Date: 24 October 2026. Owner: issue 5 / Draft PR79; editorial owner: issue 2.
This is an executed review of the dirty R30 candidate, not final clean-commit acceptance.
No production, test, metadata or repository review file was changed by this reviewer.

## Verdict

**No blocking defect found in the inspected semantic or native-rendering scope.**
The two selected publisher test files pass independently, **29/29 with no skips**.
An independent actual-artifact probe passes **15/15 bounded cases**, including four
additional negative partitions. The new layout moves existing source content; it
does not reconstruct or shorten the article in an output-specific prose copy.

PDF pagination and clipboard behavior still require the separately assigned
Exploratory / Interaction QA observations. Final source closure remains pending:
this receipt cannot be relabelled as evidence for an unseen later commit or artifact.

## Inspected identity and inputs

- Base commit: `d488c64b825d60c4c6531f9cad2091eefc4a04ba`.
- Base tree: `cf513c5b4dbcede0f1db8fdb30bd9b0f009a3369`.
- Candidate manuscript SHA256:
  `2c8729927685f7abec734865013dded9e98cce925bbd727faae74f074006bc29`.
- Candidate semantic SHA256:
  `35324c43d2eb499e1bb17d2a4a07ec80649d9714a6715206705fadd9f5e1ee06`.
- Native kit identity:
  `14743fdc40b0f06232203da46ec01fd941c17c5b3cd353930f452ba7c03f685b`.
- PDF SHA256: `e96c4f21ce1f5a130527d3a37fce8f3f46e4b02c57b8fc701331ad1c72374cc1`;
  1,422,262 bytes.
- Source state: `working-tree-review`; Node `v24.22.1`.

Read the independent requirements preflight, approved R30 review scope, root
AGENTS/CONTRIBUTING and routed test allocation. Independently inspected the actual
manuscript and metadata/blueprint diffs; changed profile validator, kit renderer,
template, CSS and both test diffs; unchanged AST/compiler/shared-render and semantic
owners; current artifact manifest and all six native/platform HTML bodies.
Read original R29 source through the immutable Git base for comparison.

Implementation hashes used in this execution:

| Path | SHA256 |
| --- | --- |
| `tools/publishing/kit.cjs` | `370344064b930fb0c6c801005a4152bd9f135f86ecfff1e5406490a7a80f97ec` |
| `tools/publishing/profile.cjs` | `589be280c3d8ee1d9676414bae2ef846ffa2cbffef9ee0bc04a4e068c104db55` |
| `site/templates/articles/print.html` | `f06eebb1c638fe4de44545a460a6618328d6cfe0b4f42d5feaa363b085ee7dd0` |
| `site/engine/article-print.css` | `085b5d48cf79bdb8e6321f017353b8e882ffeb705883149871b09e940c0ea0fd` |
| `tests/publishing.test.cjs` | `c8cf74de2c51dfa423e1d6a07f31dc94e744fccb6096da2d9f9acdcb172fa252` |
| `tests/publishing-profile.test.cjs` | `ae31306d2cbea3ea91a30caaef01c20333a1d5d1a7ea164020b17e16f1b6850f` |

## Bounded risk-to-test matrix

| Risk / AC | Independent oracle and selected case | Executed result / route |
| --- | --- | --- |
| R30.3–5: shortening silently removes a condition or citation | Compare actual paragraphs with R29; compare complete reference-list AST, table ASTs, figure inventory, and citation/link multisets, then inspect moved claim associations | Pass. 12 prompts, 36 unchanged source-note entries, two exact tables, four figures, 49 numeric citations and all 90 link destinations preserved. Both source-31 contexts remain distinct. |
| R30.6/8: stale, mistyped, duplicate or misordered print bindings silently target different prose | Current validator test supplies stale digest, wrong node type, duplicate digest, wrong title position, invalid next node, prompt collision, empty/oversize arrays and unknown key; independent negatives add ambiguous repeated source block, cross-group collision, missing byline and empty print opt-in | Pass. All four independent negative partitions reject, and existing selected negative cases pass. |
| R30.6/7: title relocation or grouping drops, duplicates or reorders body content | Compare all six actual HTML bodies to the unaffected compiler output after removing only declared layout wrappers and the two relocated header paragraphs; account for the declared platform table and image transformations | Pass for article, print, LinkedIn, Medium and both copy-ready HTML files. Each has one complete R30 byline and 12 prompt/first-answer groups; all remaining body bytes match. |
| R30.6/8: nested Contents drops or duplicates anchors or misgroups supporting material | Compare actual navigation target sequence to admitted source sections; require unique live IDs, nested main-part lists and the four declared trailing appendix targets | Pass: 22 unique valid targets, five ordered lists, main/subsection nesting and separate supporting group. |
| R30.7/8: full-source roles leak into an authored adaptation, or ordinary profiles require the new option | Existing renderer fixture checks distinct adaptation content and absence of inherited layout groups; existing plain/illustrated profiles still render. Independently load both real non-opted-in profiles | Pass. `reader-reference` and `pmday-two-shifts` remain admitted without `print`; no new required configuration. |
| R30.7: reviewed files differ from the manifest or actual producer | Run `verifyKit`; independently hash every declared producer and source input against the current filesystem | Pass. Complete inventory is 33 declared outputs plus its manifest. Actual source/semantic identity and PDF bytes match. |
| R30.6: CSS grouping markup still permits a visibly orphaned prompt or split small table | Actual native PDF inspection by the separately assigned exploratory reviewer | Not executed by this role. Markup and source binding pass; this does not establish pagination. |
| R30.7: selection in copy-ready view omits the header or includes navigation | Source/test inspection confirms the copy-ready class, header inclusion, hidden navigation/summary and instructions; actual selection belongs to exploratory QA | Structural checks pass; no native-editor or physical clipboard claim from this role. |

The two existing permanent test owners are `tests/publishing.test.cjs` and
`tests/publishing-profile.test.cjs`. `tools/quality/test-profiles.json` maps both to
`pr-targeted`, `staging`, `production` and `content`; their inputs cover these
publisher/profile/template/CSS changes. The RI/CI map retains the publisher owner.
This execution used the direct bounded Node selection, not a hosted Actions run.
The additional disposable probe is a retained manual diagnostic, not a newly
registered permanent test. It found no defect requiring another production case.

## Structural analysis

The optional `print` branch validates exact admitted AST block digests before
layout. Explicit roles require a unique matching source block; subtitle/byline
must be the first two paragraphs following the leading matching title. Grouping
roles exclude images and reject duplicates across roles. A prompt's deliberately
repeated digest remains one reader declaration: each occurrence must have its
first answer paragraph immediately after it. Explicit print selection cannot
also claim that prompt digest. These distinctions prevent a generic prose search
from accidentally selecting or moving a similarly worded paragraph.

The kit renders through the existing shared AST renderer and includes that owner
in producer provenance. Different authored adaptations clear the full-source
reader/print selection. The no-print branch retains the previously compiled body.
Title links are retained explicitly in the body, while links inside subtitle or
byline remain in the header. The actual full and platform body comparisons confirm
that wrapper addition and furniture relocation preserve all other content.

The finite validation bounds and original compiler/resource limits remain in
place. `break-inside: avoid-page` is a layout request; it cannot alone prove that
every selected block fits a page. The current short table and paragraph grouping
need the actual native PDF observations, not a stronger claim from code inspection.

## Semantic precision findings

No new unresolved semantic loss was found in the actual edited argument.

- Part I identifies actual constraints and expressly denies automatic end-to-end
  gains. The 8-to-100 example still fixes downstream capacity, admits all work to
  derive the +92 queue, gives controlled intake as an alternative and states the
  spare-capacity caveat. Observational and vendor evidence remains qualified.
- Review's detection, understanding and operational functions remain distinct.
  The replacement counterargument allows verified mechanisms to supersede manual
  inspection, retains uncovered judgment/intervention needs and immediately
  requires comparison against the real workflow and full cost.
- The account-recovery example preserves the verified-address/new-address policy
  distinction. Agreement among code, tests and explanations is described as a
  possible shared interpretation error. An independent runtime guard can still
  share the development error; the actual-path forbidden case and separate
  approval are retained. Policy/test-set completeness is expressly not established.
- Part II asks whether a viable arrangement exists. It retains enforceable limits,
  meaningful signals, timely correction and human capacity **and authority where
  required**. It does not promise a permanently stable configuration or imply
  internal model tuning is sufficient.
- The statistical passage preserves independent representative trials, one-sided
  95% coverage, reliable classification and stable conditions. Golden-set
  representativeness and adversarial testing remain separate. Both tables are
  structurally unchanged, including the synthetic and illustrative qualifiers.
- Human review remains competent, equipped, staffed and empowered to refuse.
  Unavailable review yields only the fixed preapproved route, without model-added
  steps or account-specific information; waiting cannot become approval.
- Part III now starts with work required before implementation and explicitly
  connects dependencies to the risk map, staffing and budget. It preserves the
  current-process/simple-safe-alternative comparison, comparable conditions,
  useful completed outcomes, full cost and attribution to the model's contribution.
  Insufficient evidence retains bounds; routing gains cannot justify broader action.

These are precision checks against the existing source and agreed requirements.
No new empirical fact-checking or general endorsement of cited studies is implied.

## Executed evidence and probe correction

- `node --test tests/publishing.test.cjs tests/publishing-profile.test.cjs`:
  exit 0; 29 passed, zero failed/skipped; 64.429 seconds. Original output:
  `/tmp/r30-whitebox-tests.tap` (raw Node reporter output).
- `node /tmp/r30-whitebox-probe.cjs`: final exit 0; 15 bounded cases pass.
  Source: `/tmp/r30-whitebox-probe.cjs`; raw output:
  `/tmp/r30-whitebox-probe.raw`; structured result:
  `/tmp/r30-whitebox-probe.json`.
- `git diff --check`: exit 0 at the inspected candidate.

The first disposable probe compared wrapper removal incorrectly: it removed the
closing `div` but left the wrapper's extra inter-block newline. Six byte-level
body comparisons therefore failed on exactly that formatting difference. The
probe was corrected to remove the closing wrapper and its own newline; no source,
implementation or permanent test changed. Original source/result/raw output are
preserved as `/tmp/r30-whitebox-probe.initial.cjs`, `.initial.json` and `.initial.raw`.
The corrected comparison preserves the body bytes themselves, including code
content; it does not collapse all whitespace or ignore arbitrary missing text.

The Node subprocess boundary required the declared sandbox escalation; tests and
probe then executed normally. No broad browser/device matrix or optional full
suite was run. No measured branch-coverage percentage is claimed from this review.

## Remaining gates

Retain separate all-page PDF and copy-surface observations, code/artifact review,
final Requirements & Acceptance review and exact clean-source policy evidence.
Owner-authenticated artifact storage/readback, actual editor behavior, publication
rights, hosted/device acceptance, main-conflict integration and publication are not
established by these source/component checks. A later changed candidate requires
a delta assessment; unchanged evidence can be reused only with identity proof.
