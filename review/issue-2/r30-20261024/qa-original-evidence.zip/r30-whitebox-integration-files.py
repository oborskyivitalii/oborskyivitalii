import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path('/workspace/scratch/25351d6f7f8e/article-work')
base = 'd488c64b825d60c4c6531f9cad2091eefc4a04ba'
report = {'base': base, 'cases': []}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)

def check(name, operation):
    try:
        details = operation()
        report['cases'].append({'name': name, 'status': 'pass', 'details': details})
    except Exception as error:
        report['cases'].append({'name': name, 'status': 'fail', 'error': str(error)})

def prior_identity():
    previous = json.loads(pathlib.Path('/tmp/r30-whitebox-probe.json').read_text())
    identity = previous['identity']
    for filename, expected in identity['implementation'].items():
        assert sha((root / filename).read_bytes()) == expected, filename
    source = 'site/publications/pmday-ai-both-sides/manuscript.en.md'
    assert sha((root / source).read_bytes()) == identity['sourceSha256']
    native = pathlib.Path(identity['directory'])
    assert json.loads((native / 'manifest.json').read_text())['artifactId'] == identity['artifactId']
    pdf = sha((native / 'article.pdf').read_bytes())
    assert pdf == 'e96c4f21ce1f5a130527d3a37fce8f3f46e4b02c57b8fc701331ad1c72374cc1'
    return {'sourceSha256': identity['sourceSha256'], 'artifactId': identity['artifactId'], 'pdfSha256': pdf, 'implementation': identity['implementation']}

def generated_deletions():
    old = json.loads(git('show', base + ':docs/site-revision.json'))
    new = json.loads((root / 'docs/site-revision.json').read_text())
    lock = json.loads((root / 'site/output-lock.json').read_text())
    retained = json.loads((root / 'site/retained/manifest.json').read_text())['files']
    names = ['archive.js', 'navigation.js', 'space.js', 'styles.css', 'theme.js']
    expected = {'docs/runtime/' + old['engine'] + '/' + name for name in names}
    expected.update('docs/' + entry['url'] for entry in old['routes'].values())
    deleted = set(git('diff', '--name-only', '--diff-filter=D', base).decode().splitlines())
    assert len(expected) == 10
    assert deleted == expected, {'unexpected': sorted(deleted - expected), 'missing': sorted(expected - deleted)}
    for file in deleted:
        relative = file.removeprefix('docs/')
        assert relative not in retained, relative
        assert relative not in lock['files'], relative
        assert not (root / file).exists(), file
    for entry in new['routes'].values():
        assert sha((root / 'docs' / entry['url']).read_bytes()) == entry['sha256']
    return {'deletedCount': len(deleted), 'deleted': sorted(deleted), 'retainedIntersection': [], 'currentRouteCount': len(new['routes']), 'outputLockSha256': sha((root / 'site/output-lock.json').read_bytes()), 'siteRevisionSha256': sha((root / 'docs/site-revision.json').read_bytes())}

def retained_history():
    retained_bytes = (root / 'site/retained/manifest.json').read_bytes()
    assert retained_bytes == git('show', base + ':site/retained/manifest.json')
    retained = json.loads(retained_bytes)['files']
    for file, digest in retained.items():
        assert sha((root / 'site/retained' / file).read_bytes()) == digest, file
        assert sha((root / 'docs' / file).read_bytes()) == digest, file
    owners = ['site/retained', 'review/issue-2', 'site/publications/pmday-ai-both-sides/editions']
    historical = set(git('ls-tree', '-r', '--name-only', base, '--', *owners).decode().splitlines())
    changed = set(git('diff', '--name-only', base, '--', *owners).decode().splitlines())
    assert not historical.intersection(changed), sorted(historical.intersection(changed))
    return {'retainedFilesVerifiedInOwnerAndDocs': len(retained), 'retainedManifestSha256': sha(retained_bytes), 'historicalTrackedPaths': len(historical), 'historicalChanged': []}

def base_runtime():
    supplied = json.loads(pathlib.Path('/tmp/r30-runtime-byte-parity.json').read_text())
    old = supplied['baselineEngine']
    new = supplied['candidateEngine']
    actual = {}
    for file, entry in supplied['browserFiles'].items():
        previous = git('show', base + ':docs/runtime/' + old + '/' + file)
        current = (root / 'docs/runtime' / new / file).read_bytes()
        assert previous == current, file
        assert current == (root / 'docs' / file).read_bytes(), file
        assert sha(current) == entry['sha256'], file
        actual[file] = sha(current)
    return {'baselineEngine': old, 'candidateEngine': new, 'files': actual}

check('previous native manuscript, implementation and artifact review identity is unchanged', prior_identity)
check('the ten deletions are exactly obsolete unretained candidate runtime and snapshots', generated_deletions)
check('all retained owners/output bytes and prior article review/edition paths are unchanged', retained_history)
check('all five base browser files exactly match R29 in actual bytes', base_runtime)
report['pass'] = all(case['status'] == 'pass' for case in report['cases'])
pathlib.Path('/tmp/r30-whitebox-integration-files.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['pass'] else 1)
