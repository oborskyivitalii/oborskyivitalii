import hashlib,json,zipfile
from pathlib import Path
import fitz
root=Path('/workspace/scratch/25351d6f7f8e')
source=root/'r30-delivery'
readback=root/'r30-delivery-readback'
name='The_Sum_of_Our_Technology_R30_2026-10-24.pdf'
a=fitz.open(source/name)
b=fitz.open(readback/name)
assert len(a)==len(b)==22
pages=[]
for i,(pa,pb) in enumerate(zip(a,b)):
 xa=pa.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
 xb=pb.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
 pages.append({'page':i+1,'dimensions_identical':(xa.width,xa.height)==(xb.width,xb.height),'pixels_identical':xa.samples==xb.samples,'links_identical':pa.get_links()==pb.get_links(),'text_identical':pa.get_text()==pb.get_text()})
 assert all(v for k,v in pages[-1].items() if k!='page')
raw=(readback/name).read_bytes();original=(source/name).read_bytes()
appendix=raw[len(original):]
report={'pdf_pages':pages,'outline_identical':a.get_toc()==b.get_toc(),'native_pdf_preserved_as_exact_prefix':raw.startswith(original),'appended_bytes':len(appendix),'appended_c2pa_marker_present':b'c2pa' in appendix.lower(),'native_pdf_sha256':hashlib.sha256(original).hexdigest(),'stored_pdf_sha256':hashlib.sha256(raw).hexdigest(),'claim':'Storage adds an incremental PDF provenance update. All 22 rendered pages, text, link annotations and outline compare identically. Native byte-exact PDF is also inside the byte-identical full ZIP.'}
evidence=json.loads((root/'article-work/review/issue-2/r30-20261024/artifact-evidence.json').read_text())
archive=readback/'The_Sum_of_Our_Technology_R30_2026-10-24_Native_Review_Kit.zip'
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(v['path'] for v in evidence['archive']['members'])
 for m in evidence['archive']['members']:
  data=z.read(m['path']); assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
report['readback_zip_members_verified']=len(evidence['archive']['members'])
Path('/tmp/r30-transport-readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='pdf_pages'},indent=2))
