# R30 Requirements preflight — failed clean-policy inventory correction

Reviewer: `/root/r30_requirements`, independent of implementation.
Date: 24 October 2026. Owner: issue5 / Draft PR79; editorial owner: issue2.
Inspected clean-policy source: `cdb68f8a9fa4fd26525c577051cffa6314288109`.
This is a bounded pre-implementation supplement under R30.8, not a revision of
the accepted editorial requirements or a pass for the failed policy.

## Decision

**Proceed with exactly16catalog-owner corrections from `tools/site/build.cjs`
to `site/README.md` for the newly generated R30 runtime/snapshot entries.**
Keep every other field and all classification/validation code unchanged.
No new author permission is needed: this restores the already-required canonical
inventory contract within the authorized R30 integration.

## Actual cause and inspected evidence

The first exact-clean policy has8/12passing groups and valid clean-source evidence.
Its failures must remain original failed evidence. I inspected the concise failure
output, current `publicationInventoryCompatible` in
`tools/quality/source-tests.cjs`, its complete existing test in
`tests/test-profile-selection.test.cjs`, the real ancestor-reuse scenario in
`tests/content-baseline.test.cjs`, content profile configuration and the actual
current/baseline path catalogs.

`publicationInventoryCompatible` already requires every derived `docs` entry to
have exactly kind/owner/purpose/role, owner `site/README.md`, role `generated`,
file/directory kind and a nonempty purpose. All baseline R29 `docs` entries use
that owner. Exactly16new R30 entries instead name `tools/site/build.cjs`:
the new runtime directory and five files, plus five snapshot directories and
their five route documents. Their other shape fields satisfy the contract.

The R30 edition entry has the correct article-workflow owner. Unchanged review
history/evidence entries cannot cause the current-versus-current equality failure:
they are outside the publication/derived projection and are identical on both
sides. **No new review-history allowance or broader classifier is needed.** The
initial suggestion that the new QA/evidence shape was responsible is disproved
by this inspection and should not survive as the final diagnosis.

My read-only in-memory probe uses the actual current runner and registry:

- original current/current compatibility: **false**;
- identical catalog with only these16owner values corrected: **true**;
- change one corrected owner back to `tools/site/build.cjs`: **rejected**.

Original result: `/tmp/r30-requirements-inventory-probe.json`.
No repository file or implementation was changed by this reviewer.

## Bounded correction acceptance

1. The semantic catalog delta from `cdb68f8` changes exactly those16owner values.
   Paths, purpose, role, kind, previous immutable history and R30 edition/evidence
   entries remain unchanged, apart from separately declared review receipts.
2. `publicationInventoryCompatible`, classifier allowlists, content/derived input
   patterns, unsupported-entry pinning and all resource/identity/rejection bounds
   remain byte-unchanged. Do not skip validation or accept a second owner merely
   to accommodate erroneous metadata.
3. Current/current compatibility passes with actual corrected metadata. Existing
   malformed owner/role, new unsupported code/provenance, changed/deleted existing
   unsupported entry, schema-change and unbound-diff negatives retain their expected
   rejections. The existing test covers these risks; no broad new suite is needed.
4. The real content-baseline ancestor/reuse scenario again classifies its controlled
   content-only fixture correctly. Draft-only/missing admission remains platform;
   the complete R30 change itself still requires platform classification because
   it changes print/template/tool owners.
5. Regenerate the derived RI/evidence projection, review the actual correction with
   the independent roles, freeze and rerun the unchanged owning policy on the new
   exact clean source. Keep the first8/12run and its cause as historical evidence.

The separate stale R29 preview hash and current Color-family test expectations
are appropriate to update to their exact R30 identities while retaining the existing
full-closure, byte-budget and different-variant rejection assertions. This preflight
does not authorize loosening those tests or relabelling their earlier failures.
Article/native producer identities must remain unchanged; their prior acceptance
can be reused only with that identity check.
