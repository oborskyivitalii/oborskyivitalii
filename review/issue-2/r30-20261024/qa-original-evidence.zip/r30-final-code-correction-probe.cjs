'use strict';
const fs = require('node:fs');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const root = '/workspace/scratch/25351d6f7f8e/article-work';
process.chdir(root);
const base = 'cdb68f8a9fa4fd26525c577051cffa6314288109';
const hash = (x) => crypto.createHash('sha256').update(x).digest('hex');
const before = (f) => cp.execFileSync('git', ['show', base + ':' + f]);
const paths = ['.github/repository-paths.json', 'tests/article-media.test.cjs', 'tests/release-controller.test.cjs'];
const current = JSON.parse(fs.readFileSync(paths[0]));
const previous = JSON.parse(before(paths[0]));
assert.deepEqual(Object.keys(previous), Object.keys(current));
assert.deepEqual(Object.keys(previous.entries), Object.keys(current.entries));
const changes = Object.keys(current.entries).filter((f) => JSON.stringify(current.entries[f]) !== JSON.stringify(previous.entries[f]));
assert.equal(changes.length, 16);
for (const f of changes) {
  const a = previous.entries[f], b = current.entries[f];
  assert.ok(f.startsWith('docs/'));
  assert.equal(a.owner, 'tools/site/build.cjs');
  assert.equal(b.owner, 'site/README.md');
  assert.deepEqual({...a, owner: b.owner}, b);
}
const replacements = {
  'tests/article-media.test.cjs': [
    ['real R29 preview', 'real R30 preview'],
    ['9c75ec7b9372e159cc33c332e25e68010fcedd81293c838ba53ce1bf7f679d1e', '2c8729927685f7abec734865013dded9e98cce925bbd727faae74f074006bc29'],
    ['pmday-ai-both-sides-en-review-20261024-r29', 'pmday-ai-both-sides-en-review-20261024-r30'],
  ],
  'tests/release-controller.test.cjs': [['issue5-review-paths-production', 'issue5-r30-print-production']],
};
const normalized = {};
for (const [f, pairs] of Object.entries(replacements)) {
  let x = before(f).toString();
  for (const [a, b] of pairs) {
    assert.equal(x.split(a).length - 1, 1);
    x = x.replace(a, b);
  }
  assert.equal(fs.readFileSync(f, 'utf8'), x);
  normalized[f] = {exactAllowedLiteralSubstitutions: pairs.length, allOtherBytesPreserved: true};
}
const runner = require(root + '/tools/quality/source-tests.cjs');
const registry = runner.loadRegistry(root);
const oldResult = runner.publicationInventoryCompatible(registry, previous, previous);
const newResult = runner.publicationInventoryCompatible(registry, current, current);
const transition = runner.publicationInventoryCompatible(registry, previous, current);
assert.equal(oldResult, false);
assert.equal(newResult, true);
assert.equal(transition, true);
const bad = structuredClone(current);
bad.entries[changes[0]].owner = 'tools/site/build.cjs';
const rejected = !runner.publicationInventoryCompatible(registry, current, bad);
assert.equal(rejected, true);
const stable = ['tools/quality/source-tests.cjs', 'tools/quality/test-profiles.json', 'tests/test-profile-selection.test.cjs', 'tests/content-baseline.test.cjs', '.github/acceptance/issue-5.json', 'tests/test_issue5_acceptance.py', 'tools/staging/package.cjs', 'tools/quality/color-motion-contract.cjs', 'tests/color-motion-contract.test.cjs', 'tests/staging-regression.test.cjs', 'tests/fixtures/delivery.cjs', 'tools/quality/artifact.cjs', 'tools/site/snapshot.cjs', 'tools/release/edition.cjs'];
const protectedFiles = Object.fromEntries(stable.map((f) => {
  const b = fs.readFileSync(f);
  assert.deepEqual(b, before(f));
  return [f, {sha256: hash(b), byteUnchanged: true}];
}));
const changedAll = cp.execFileSync('git', ['diff', '--name-only', base], {encoding: 'utf8'}).trim().split('\n').filter(Boolean);
const currentR30 = cp.execFileSync('git', ['diff', '--name-only', 'd488c64'], {encoding: 'utf8'}).trim().split('\n').filter(Boolean);
const classification = runner.classifyContent(registry, currentR30);
assert.equal(classification.mode, 'platform');
const data = {
  base,
  scope: 'Independent Code reviewer read-only exact-delta probe; no repository mutations',
  currentChangedPaths: changedAll,
  sourceHashes: Object.fromEntries(paths.map((f) => [f, hash(fs.readFileSync(f))])),
  catalog: {changedPaths: changes, changeCount: changes.length, onlyOwnerSubstitutions: true, previousCurrentCurrent: oldResult, correctedCurrentCurrent: newResult, previousToCorrected: transition, wrongOwnerStillRejected: rejected},
  fixtures: normalized,
  protectedFiles,
  completeR30: {pathCount: currentR30.length, classification: classification.mode},
  pass: true,
};
fs.writeFileSync('/tmp/r30-final-code-correction-probe.json', JSON.stringify(data, null, 2) + '\n');
console.log(JSON.stringify({pass: data.pass, sourceHashes: data.sourceHashes, catalogCount: changes.length, completeR30: data.completeR30}, null, 2));
