# R30 native print-layout implementation receipt

Implementer: `/root/r30_print_implementation` (not an independent quality reviewer).
Execution owner: issue 5 / Draft PR79; editorial owner: issue 2.
Baseline: `d488c64b825d60c4c6531f9cad2091eefc4a04ba`.
Candidate: dirty prepared source; exact owned-file identities below. Root owns manuscript,
profile data, edition/launch, artifact rendering, RI/catalog and final source acceptance.

## Implemented behavior

- Optional profile `print` binds exact admitted AST blocks: `titleBlock.subtitle` and
  `.byline` must be the two paragraph blocks immediately after the admitted title.
  They move into the HTML/PDF header without duplicate prose. Technical edition
  identity is preserved as document metadata. Other profiles retain author metadata.
- `keepTogether` binds individual paragraphs/tables; `keepWithNext` binds paragraphs
  followed by a paragraph/table, with consecutive bindings forming a coherent group.
  Up to50 distinct bindings per role are accepted; invalid, stale, repeated, wrong-type,
  misordered title, detached prompt-answer and unsupported-role bindings reject.
- Existing source-bound prompt roles keep the prompt and first following answer together.
  Explicit source selection determines grouping; no wording/bold/table-size heuristic.
- Native Contents nests H3 under H2 and uses existing trailing appendix metadata for a
  visually separate supporting group. All source/appendix content remains in the body.
- Full-source layout bindings do not leak into independently authored adaptations.
  Full/equivalent HTML preserve title source links, subtitle links, provenance and text.
- Copy-ready HTML embeds the same canonical stylesheet, hides Contents/generated summary,
  and instructs Ctrl/Cmd+A so the visible title/subtitle/byline and full body copy together.
  This preserves the full article while retaining platform table-row fallbacks and images.
- `render.cjs`, now directly used by the layout adapter, is explicitly included in native
  kit producer hashes and the existing native test fixture copy inventory.
- Main11pt body size, A4 margins and native printArticle producer are unchanged.
  No PDF postprocessing, new active module, runtime script, dependency, acceptance-policy
  or historical-artifact edit was made by this implementer.

## Verification executed

`node --test tests/publishing-profile.test.cjs tests/publishing.test.cjs`
with normal authorized subprocess access: **29/29 PASS**, fail0, skipped0, cancelled0,
todo0;58665.739565ms. Actual original log: `/tmp/r30-print-tests-final.log`.

The new validation case exercises one valid profile plus10 invalid declarations and a
prompt detached from its answer. The new native-kit integration case checks all four
full/equivalent HTML forms, unified furniture exactly once, subtitle/title source links,
nested Contents, separate appendices, both repeated prompt groups, short table and ending
groups, full text/source preservation, correct platform fallbacks, and adaptation isolation.
It also checks the actual complete native manifest and copy instruction/mode selection.

Both tests live in existing selected files, already routed through issue5 PUBLISHER →
`test_issue5_acceptance.Issue5AcceptanceTests.test_publisher_contracts` and the maintained
publisher profile inventory. No new suite/file/selection route is needed.

Configured Prettier check for six JS/CSS/template/test owners: **PASS** using
`tools/quality/prettier.config.json`. `git diff --check`: **PASS**.
Untouched functions/tests were restored byte-for-byte after an initial formatter default
expanded unrelated formatting; only touched/new functions retain scoped formatting.

## Retained unsuccessful attempts

- `/tmp/r30-print-tests.log`: sandbox-run blocked native AST child process with EPERM;
  direct in-process diagnostics identified the same restriction in existing compiler tests.
  This is blocked execution, not a code pass or evidence of a Node-version defect.
- `/tmp/r30-print-tests-escalated.log`: an intermediate normal-subprocess run overlapped
  the copy-view template edit. Cached old module plus newly read template caused an
  undeclared `documentClass` slot. It is invalid as final-source evidence and is preserved.
  The stable-source final rerun above resolves that concrete integration state.

## Remaining work / limits

Root's actual native PDF visual/copy inspection and four independent quality roles remain
separate. These source tests do not prove pagination, clipboard transfer to actual platform
editors, human readability, hosted/device admission, rights clearance or publication.
Basic, bounded style guard, full owning policy and RI/CI exact-source acceptance are root's
required integration gates. No commit/push/issue checkbox or external publication occurred
in this implementation subtask.

## Exact owned-file SHA256

```json
{
  "guides/ARTICLE-WORKFLOW.md": "83272df023a2ce9ef12a77a8252e684abaf822653102b65c8b9a8e01c26af295",
  "site/engine/article-print.css": "085b5d48cf79bdb8e6321f017353b8e882ffeb705883149871b09e940c0ea0fd",
  "site/templates/articles/print.html": "f06eebb1c638fe4de44545a460a6618328d6cfe0b4f42d5feaa363b085ee7dd0",
  "tests/publishing-profile.test.cjs": "ae31306d2cbea3ea91a30caaef01c20333a1d5d1a7ea164020b17e16f1b6850f",
  "tests/publishing.test.cjs": "c8cf74de2c51dfa423e1d6a07f31dc94e744fccb6096da2d9f9acdcb172fa252",
  "tools/publishing/kit.cjs": "370344064b930fb0c6c801005a4152bd9f135f86ecfff1e5406490a7a80f97ec",
  "tools/publishing/profile.cjs": "589be280c3d8ee1d9676414bae2ef846ffa2cbffef9ee0bc04a4e068c104db55"
}
```

## Original log SHA256

```json
{
  "/tmp/r30-print-tests.log": "9468ff08bab8bc07e5ca72c0ddfcdd442fbe785e4bbc2a7a8bda0e93865f750c",
  "/tmp/r30-print-tests-escalated.log": "c67c9383729e211205ad031f83a3fd20aa13b8122b8cfa3239515163bbed0f3f",
  "/tmp/r30-print-tests-final.log": "df3dd95ef21908978a62e559ad51f23e00f2250eaab074cfc4d55c62f54b7edc"
}
```
