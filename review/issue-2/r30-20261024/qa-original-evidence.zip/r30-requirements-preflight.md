# R30 independent Requirements & Acceptance preflight

Reviewer: `/root/r30_requirements`; independent of implementation.
Date: 24 October 2026.
Execution owner: issue 5 / existing Draft PR79. Editorial owner: issue 2.
Inspected baseline: `d488c64b825d60c4c6531f9cad2091eefc4a04ba`.
Manuscript: `site/publications/pmday-ai-both-sides/manuscript.en.md`, SHA256
`9c75ec7b9372e159cc33c332e25e68010fcedd81293c838ba53ce1bf7f679d1e`.
The supplied R29 Markdown and this canonical source were byte-identical on inspection.
Working tree was clean. This is a pre-implementation requirements review, not R30 acceptance.

## Inputs inspected

- Full R29 argument, source apparatus and provenance/history; exact local R29 file.
- Root AGENTS, CONTRIBUTING, README, MEMORY (dated handoff), repository-map routes,
  review template, acceptance contract, article workflow, relevant site/source/check-profile
  routes, existing issue-5 policy and code-style rule inventory.
- Live issue 5 and issue 2, including current R29 checkpoint and stable ACs. Both remain
  open. Existing R29 evidence is not evidence for a forthcoming R30 candidate.
- Parent-provided approved editorial plan and the user's `Ок роби` authorization.

## Verdict

**Proceed with the bounded R30 implementation.** The agreed plan directly answers
the request for clearer structure, precise memorable wording and shorter argument
without simplifying its conditions. It supplies concrete editorial and visual oracles.
No material author decision is missing for this scope. The treatments below clarify
verification; they do not add publication, redesign or integration work.

### Clarifications before implementation

1. **Compression is an objective, not a numerical gate.** Report one reproducible
   body-word comparison using identical exclusions on R29/R30. The suggested 10–15%
   is an aspiration; it cannot justify deleting necessary qualifications. Source notes
   and URLs must not inflate the claimed prose reduction. Page count is not a target.
2. **Preserve citation associations, not the old ordering.** Reordering sections
   necessarily reorders links. Compare the source-entry inventory and citation/link
   destination multiset, then inspect each moved claim's attachment. An old ordered
   link-array equality is not an appropriate R30 oracle. Source 31's contextual
   destinations must remain distinct. Counts alone do not establish preserved meaning.
3. **Keep the approved human dependency conditional.** Model configuration is a
   hypothesis to test; useful reliable operation at justified full cost is not promised.
   Retain meaningful signals, timely correction and human capacity **and authority
   where required**. A viable configuration need not exist for the proposed delegation.
4. **Scope PDF changes to native semantic rendering.** Use the normal publisher and
   its shared owners, with evidence for any generic template change. Do not edit the
   PDF or generated HTML directly, rely on fixed page numbers, or solve grouping by
   shrinking type/margins. Dense-slide redraw is optional future work, not required R30.
5. **Review delivery is distinct from whole-issue closure.** Keep PR79 Draft; do not
   relabel old hosted/native-editor/device evidence as R30. The existing main conflict
   remains outside this editorial increment. No merge, staging promotion or public post
   follows from this authorization.

## Proposed stable R30 acceptance subconditions

These supplement existing ACs in the dated review record; they do not replace or
renumber the owning issues' criteria.

| ID | Observable outcome and oracle | Existing AC relation | Check / decision |
| --- | --- | --- | --- |
| R30.1 | Three major parts use the approved combined headings, once each, in source, body and Contents. Part I names actual SDLC constraints; Part II names control around model judgment; Part III names project decisions. No extra global subsection layer. | Issue5 AC02/06/08; issue2 AC01 | Source/AST inspection plus actual PDF/HTML navigation. |
| R30.2 | Argument order implements the approved mechanism-first delivery explanation, combined review functions, separate explanation/recovery subsections, consolidated substitution condition, and planning-first Part III with the actual-process/simple-safe-alternative/full-cost comparison. One final ending remains. | Issue5 AC06; issue2 AC01 | Whole-text independent editorial comparison, including transitions and counterargument. |
| R30.3 | All 12 standalone prompts, 36 numbered source entries and substantive qualification notes, four declared figures and two tables survive. Citation targets remain attached to the supported claims, including both contextual source31 URLs. Existing reviewers and dispositions remain accurate; Olivier's substantive proposals remain under consideration. | Issue5 AC02/06/07/09; issue2 AC01/02/03 | Inventory comparison and semantic review, not counts alone. Historical editions/deliverables byte-unchanged. |
| R30.4 | The conditional 8→100 example retains fixed downstream capacity, unrestricted-intake +92 consequence, bounded-intake alternative and spare-capacity caveat. Counterargument permits verified substitution for manual inspection. Policy correctness remains distinct from independent enforcement. Statistics retain one-sided95%, independent representative sampling, classification and stable-condition assumptions, and separate adversarial coverage. | Issue5 AC06; issue2 AC01/02 | Targeted paragraph-level independent precision review against R29. |
| R30.5 | Runtime argument retains timely intervention, conditional competent/equipped/staffed/authorized humans, fixed preapproved routing when unavailable, no account-specific output or waiting-as-approval, reassessment, and full-cost/value attribution. Planning explicitly connects required work before implementation to risk maps, staffing and budget. | Issue5 AC06; issue2 AC01 | Targeted precision review of Part II/III and pilot table. |
| R30.6 | PDF has one coherent title/subtitle/author/edition-date block; Contents visibly distinguishes parts, subsections and supporting apparatus. Every What-if-not prompt stays with its first answer paragraph. The short 200-response table is intact; compact planning passage and final ending remain coherent. No clipping, overlaps, tiny type or missing source content. | Issue5 AC02/08/09; issue2 AC03 | Native pipeline PDF; all-page visual inspection, focused full-resolution grouping checks and Contents/citation target checks. Larger pilot table may paginate appropriately. |
| R30.7 | R30 is a new immutable content edition with consistent manuscript/blueprint/profile/launch/citation/history metadata. Native PDF/HTML/platform outputs and complete kit verify against source/producer/manifests; all declared formats and assets remain present. Rights and working-tree review provenance stay explicit. | Issue5 AC02/07/09/10; issue2 AC03/04/05 | Native publisher validation/render/verify; package hashes/member inventory and local copy surface checks. Actual editors and publication retain separate gates. |
| R30.8 | Any template/CSS/config changes follow CS01–CS10 through canonical owners; general publisher behavior and other profiles remain compatible. New or altered tests exercise actual grouping/metadata failure risks, are correctly mapped, and do not weaken limits. Current Basic, owning policy and relevant RI/CI checks bind the final clean source. | Issue5 AC04/11/12/15 | Independent code/white-box reviews, mapped tests, RI build/verify and exact clean-source acceptance. Report blocked/failed evidence honestly. |
| R30.9 | Existing PR79 contains source-bound R30 deliverables and all four independently executed role receipts, findings/dispositions, exact commit/tree and current acceptance reconciliation. Commits use Refs#5. Prior receipts remain historical; whole pending ACs remain open. | Issue5 AC11/12; issue2 AC01–06 | Live readback, review record and final requirements assessment. Author/publication/rights/device/hosted decisions remain separately owned. |

## Retained baseline observations

Executed a small read-only Python comparison: 12 exact standalone prompts,
36 numbered source entries, four image declarations, two table separator rows,
matching supplied/canonical bytes. A simple whitespace count of all Markdown before
`## Sources & references` gives 3,848 tokens, including markup/URLs/alt text; this is
**not** a visible-prose word metric and must not be confused with the earlier estimates.

Read-only commands included Git head/status, targeted `rg` route inventory, direct
source reads and GitHub issue GETs. No implementation, test or document was changed.
No new external research claim is introduced by this preflight.

## Transport feasibility clarification

The parent raised the unchanged repository byte bound before implementation.
I inspected `.github/REPOSITORY-INTELLIGENCE.md` (Identity, bounds and verification),
`tools/repository_intelligence.py` and the R29 final-delivery correction record.
That record measured 248,710,325 hashed bytes before its supplemental review text,
against 250,000,000. A new approximately 4.8MB PDF/archive duplicate is therefore
not a credible default plan; the actual R30 inventory still needs measurement.

**Disposition: durable owner-accessible artifact storage is an acceptable R30
transport choice.** The relevant live issue5 AC02/09/12 and article workflow require
a real source-bound, visually reviewed PDF, complete verified kit, exact evidence
and reviewable delivery. They do not require every rendition's binary bytes to be
duplicated in Git. Committing canonical source, immutable edition, source/producer/
member/byte manifest, original review receipts and durable artifact locators to
PR79, while actually delivering the complete native files through the user's
persistent ChatGPT file storage, meets this bounded increment's delivery intent.
R30.9's wording "PR79 contains ... deliverables" includes such linked durable
deliverables; it does not require a binary duplicate in the repository.

Conditions:

- Verify that storage succeeds and the stored/downloaded bytes match the inspected
  native outputs; preserve exact sizes, SHA256, filenames, artifact/edition identity,
  complete member inventory and producer/reproduction information in the repository.
- Give the user usable PDF, manuscript and full-kit links. Preserve the actual local
  source-bound four-role reviews; storage is not a substitute for artifact inspection.
- Identify owner-authenticated file links as such in repository delivery evidence.
  They are not public GitHub artifact downloads. Access by an unrelated GitHub
  reviewer is not established; if required later, record that retrieval gate pending.
- Do not add private storage URLs to public-site Materials, publication events,
  canonical metadata or release acceptance. No public release is implied.
- Preserve every prior frozen rendition, all current byte/count/size bounds and scan
  coverage. Neither hidden exclusions nor a partial kit is an accepted workaround.

This is a routine transport decision under the authorized review delivery, not a
request to weaken the existing requirements or obtain a new publishing permission.

## Final review still required

Return the completed candidate identity, actual source/artifacts, raw tests, all role
receipts and finding dispositions for final traceability assessment. This preflight
does not approve unseen edits or claim the eventual PDF defects have been corrected.
