# R30 independent White-box QA — final policy correction

Reviewer: `/root/r29_precision_qa`; independent of catalog and fixture implementers.
Date: 24 October 2026. Owner: issue 5 / Draft PR79; editorial owner: issue 2.
Correction base: `cdb68f8a9fa4fd26525c577051cffa6314288109`.
Base tree: `144ef063e4dd0d7adfec0f7be85c41897d2a95ee`.
Scope: three changed files only. No repository source was edited by this reviewer.

## Verdict

**The bounded correction passes independent QA.** Four selected existing test
cases passed, and six independent catalog/identity probe cases passed. There is
no blocking finding in this inspected correction. The earlier exact-clean policy
remains an **8/12 failure**, and the corrected final clean policy must still run.
This receipt does not promote local focused checks into a whole-policy pass.

## Original failure and actual cause

Inspected the original `/tmp/r30-acceptance-cdb68f8.json`: valid clean-source
evidence at the commit/tree above, `automation_pass: false`, eight passed and four
failed groups. It is 168,253 bytes; SHA256:
`b287373bcaeb8c300ccfee8fc250022e53b74bcb48d891c8fe3326a6569f174f`.
The failure summary is `/tmp/r30-acceptance-failures-summary.json`, SHA256
`de3e4baa0bb6c378c713a660df5d979d3ba8b7c5cba0bb3929770fc15166b42d`.
These original failed receipts remain preserved.

- **CONTENT-CI:** the current inventory failed its unchanged derived-entry owner
  contract. Sixteen new generated runtime/snapshot entries named
  `tools/site/build.cjs`; the contract requires `site/README.md`. Consequently the
  current/current inventory check failed, and the controlled real ancestor-reuse
  scenario classified as platform instead of content. The QA archive was not the
  cause; no review-history allowance was needed.
- **CONTENT-LANES / DELIVERY:** one current production Color fixture still
  expected `issue5-review-paths-production` although the actual producer selects
  `issue5-r30-print-production`.
- **READER:** the live preview fixture still pinned the R29 source hash and edition
  while loading the actual R30 manuscript. This was a current-fixture identity
  mismatch, not evidence of a changed transfer budget.

Read `/tmp/r30-requirements-inventory-preflight.md`, the actual three-file diff,
unchanged `publicationInventoryCompatible`, the complete existing inventory
negative case, the real ancestor-reuse scenario and both affected fixture cases.

## Exact corrected files

| File | SHA256 at independent execution |
| --- | --- |
| `.github/repository-paths.json` | `aa5da5417103aaee0db19d047d78ad868e3a059a7d06d566a58b742a4bc4455a` |
| `tests/article-media.test.cjs` | `25b2433385ac92d557bea105ad2caa3d5cfdaf84eb80dfd9b78cf953c2e97c70` |
| `tests/release-controller.test.cjs` | `46b02ea1f2e5bbf75c53b22e5fa43530d80aba59e4513c00e1697c9456416c46` |

The catalog's semantic delta is exactly the sixteen approved owner substitutions.
Entry paths, kind, purpose, role, all other entries and top-level fields remain
unchanged. The current preview test changes exactly its name, explicit source hash
and explicit content edition. The release-controller test changes one current
production tuple literal. Historical fixtures and rejection assertions remain.

## Risk-to-test matrix and actual results

| Risk / AC | Independent oracle and selected check | Result |
| --- | --- | --- |
| R30.8: catalog correction broadens classification instead of repairing metadata | Compare parsed old/current catalogs; require exactly sixteen owner-only changes. Exercise actual old and corrected catalogs through the unchanged function | Pass. Old/current-self compatibility is false; corrected self and old-to-corrected compatibility are true |
| R30.8: malformed metadata is now silently admitted | Run existing full inventory positive/negative case; independently restore one actual corrected entry to its wrong owner | Pass. Wrong owner still rejected; all ten existing malformed/unsupported/schema negative mutations reject; unbound inventory diff stays platform |
| R30.8: current inventory looks valid but real admitted ancestor reuse still fails | Run the existing real-source ancestor-generation case, including its actual fixture Git history, generated inventory and archive | Pass. Admitted ancestor selects content; skipped owning admission stays platform; changed shared catalog label stays platform |
| R30.8: the complete implementation change is accidentally reclassified as content | Classify the actual complete R30 changed-path set from the immutable R29 base | Pass. All 47 changed paths still produce platform classification; print/tool changes remain present |
| R30.3/7/8: replacing a stale fixture pin hides an unintended edition or content change | Hash the actual manuscript, read actual selected metadata and run the exact real R30 preview test | Pass. Source `2c872992…`, R30 edition, full media/PDF and rights inventory closure match |
| R30.7/8: current production fixture update weakens variant or byte admission | Select the actual current production artifact, inspect unchanged negative assertions and run the exact production Color test | Pass. R30 tuple selects, bytes remain exact, wrong/missing rendition and already-applied edition cases reject |

The preview test still requires total reading transfer below **800,000 gzip bytes**,
separate PDF download transfer above 500,000, four WebP assets, one JPEG, one PDF
download, complete rights inventory and pending approval. Its ordinary-link/PDF
identity/forged-size/unsupported-offline-resource rejection cases remain intact.
The production fixture retains different-variant rejection, exact runtime and
analytics-byte comparisons, size validation and release/rights assertions.

## Unchanged guard and policy proof

Byte-compared these owners with the clean correction base; all are unchanged:

| Owner | SHA256 |
| --- | --- |
| `tools/quality/source-tests.cjs` | `757bc8ca6c746124baaadca5998b56b8547fe3e1748055adc73f71bc22bb89be` |
| `tools/quality/test-profiles.json` | `dc52efed0c73b8abe0beba7bffa017cc6935545730a08c2773f68b018545421f` |
| `tests/test-profile-selection.test.cjs` | `32d9e4e8c09859a7f665e84848dff54a3b8dd7ec79e3a5ec300729c9c028cef1` |
| `tests/content-baseline.test.cjs` | `a2ee4be170b7051fb377db90074c78f5bd324650d0ea6ef5e118097668b0a805` |
| `.github/acceptance/issue-5.json` | `27ad8e1dd6f328c5cfeebd48b572abc365e9fdd9c3296be06ea6bd0f4c451429` |

The classifier, input allowlists, unsupported-entry pinning, test allocation and
owning policy therefore did not change to accommodate the bad metadata. The
original native/article source and publisher owners are outside this three-file
delta. Their earlier verified observations remain scoped to those unchanged bytes.

## Independently executed commands

1. `node --test --test-reporter=tap --test-name-pattern='publication inventory
   admits content bookkeeping|a new branch can reuse an admitted earlier merged
   ancestor generation' tests/test-profile-selection.test.cjs
   tests/content-baseline.test.cjs`
   — exit 0, **2/2 selected cases**, no failures/skips, 6.611 seconds.
2. `node --test --test-reporter=tap --test-name-pattern='real R30 preview retains
   full edition|explicit production Color preserves approved runtime'
   tests/article-media.test.cjs tests/release-controller.test.cjs`
   — exit 0, **2/2 selected cases**, no failures/skips, 11.718 seconds.
3. `node /tmp/r30-final-whitebox-catalog-probe.cjs`
   — exit 0, **6/6 independent probe cases**.
4. `git diff --check` — exit 0.

The Node subprocess escalation was used for these bounded existing fixture checks.
The test-name selections intentionally execute the required cases, not every case
in the four modules. No native render, publisher suite or full policy was rerun.

## Retained execution evidence

| Evidence | SHA256 |
| --- | --- |
| `/tmp/r30-final-whitebox-inventory-tests.raw` | `e55fd91222784c57f48bceae678140a62da40e4f6d583bc73203fb4f1396a4f2` |
| `/tmp/r30-final-whitebox-fixture-tests.raw` | `96f9408b9ebf729a7bb98c79eda06657c93dd2261ffb90508b2ca83f4e936311` |
| `/tmp/r30-final-whitebox-catalog-probe.json` | `30f0fa0227bb2119a6f363ae6fc8cad1a2e3ac63a0f9e163053f610ba252e738` |

The independent probe's executable and raw output remain at
`/tmp/r30-final-whitebox-catalog-probe.cjs` and
`/tmp/r30-final-whitebox-catalog-probe.raw`.

## Remaining closure

The root must complete derived RI/evidence refreshes, preserve the first failed
clean receipt and this correction record, freeze the corrected candidate and run
the unchanged full issue-5 policy on its exact clean commit/tree. A four-case local
correction pass does not establish that complete final result. Author/editorial,
rights, hosted/device, merge and publication decisions remain separately owned.
