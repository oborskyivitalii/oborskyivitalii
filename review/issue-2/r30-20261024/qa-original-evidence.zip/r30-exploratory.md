# R30 independent exploratory and interaction QA

## Verdict and scope

**PASS for the bounded R30 reading-surface and local interaction charter, with two cosmetic observations.** No blocking layout, navigation, citation-target, or clipboard-transfer defect was found in the actual native kit identified below. This is not approval to merge or publish, and it does not establish acceptance inside Medium or LinkedIn native editors.

Reviewer role: independent Exploratory/Interaction QA (`r29_reading_surface`, reassigned to R30). I did not author the R30 manuscript, print implementation, producer changes, or regression tests. I inspected the produced R30 artifact rather than treating R29 observations or producer receipts as acceptance evidence. No implementation file was edited during this review.

## Artifact binding

- Review date: 24 October 2026.
- Repository: `/workspace/scratch/25351d6f7f8e/article-work`; implementation baseline supplied to the reviewer: `d488c64`.
- Edition: `pmday-ai-both-sides-en-review-20261024-r30`.
- Manuscript SHA-256: `2c8729927685f7abec734865013dded9e98cce925bbd727faae74f074006bc29`.
- Semantic SHA-256: `35324c43d2eb499e1bb17d2a4a07ec80649d9714a6715206705fadd9f5e1ee06`.
- Native artifact ID: `14743fdc40b0f06232203da46ec01fd941c17c5b3cd353930f452ba7c03f685b`.
- Actual kit: `/workspace/scratch/25351d6f7f8e/article-work/dist/publications/pmday-ai-both-sides/14743fdc40b0f06232203da46ec01fd941c17c5b3cd353930f452ba7c03f685b`.
- PDF: `article.pdf`, 22 pages, 1,422,262 bytes; SHA-256 `e96c4f21ce1f5a130527d3a37fce8f3f46e4b02c57b8fc701331ad1c72374cc1`.
- Producer result: `/tmp/r30-native-result.json`; producer log: `/tmp/r30-render.log`.
- Runtime: Node 24.22.1, Playwright 1.63.0, explicitly configured review Chromium 153.0.8010.0. This browser is a local review environment, not the managed release environment.

## Independently designed charter

Starting from the approved requirements in `/tmp/r30-requirements-preflight.md`, I concentrated on failures that would defeat the intended clearer reading structure: a title displaced by navigation, flattened major/subordinate headings, prompts separated from their first answers, a split small example, fragmented planning or ending, unreadable retained figures, incorrect internal destinations, changed external citation targets, and copy-ready content that loses material during an actual clipboard operation.

The examination was bounded to the actual native PDF, four generated HTML reading variants, and two copy-ready variants. It deliberately did not grow into a platform/device matrix or a new editorial review of all research claims.

## Actual actions and observations

### PDF: every page inspected

Rendered all 22 PDF pages with PyMuPDF at 1.25× into `page-1.png` through `page-22.png`. Viewed all six contact sheets covering every page, then viewed full-size pages 1, 9, 10, 12, 13, and 14. The PDF's printed footer numbering agrees with its one-based page numbers; tool link indices are zero-based and were converted in the checks.

- **Page 1:** title, subtitle, author, revision, date, and short generated summary form one coherent opening block. Contents below it distinguishes the major parts from indented subheads. A separate “Sources and publication record” group contains four supporting sections. No duplicate byline appears below Contents.
- **Pages 2–14:** all main reading pages are present, without observed clipping or overlapping text. The body starts on page 2. Parts I, II, and III start on pages 3, 8, and 13 respectively. No body-font reduction was needed to obtain this layout.
- **All twelve standalone prompts:** independently extracted the first answer paragraph after each exact `What if not?` prompt from the manuscript and matched its complete normalized text in the PDF. Each prompt precedes its complete first answer on the same page. Their pages are `2, 5, 6, 6, 7, 7, 8, 10, 10, 11, 11, 12`.
- **Page 10:** the 200-response example is whole, including the 196/3/1 rows and the consequence column. It remains adjacent to the release argument and its following prompt/answer.
- **Pages 13–14:** the planning paragraph is complete immediately beneath the Part III heading. The pilot table uses two pages with a repeated header and intact rows. Its text remains legible. A two-page pilot table is allowed by the requirements; its length is not itself a failure.
- **Page 14:** the argument's ending is contiguous and has one final emphasized sentence, followed by Further reading. Sources begin separately on page 15.
- **Figures on pages 9 and 12:** full-page inspection confirms that the retained diagram titles, key labels, relationships, and captions can be read. The original slides contain dense secondary text; no new redraw or simplification is required by this charter. The other two article images are present in the all-page review and HTML image checks.
- **Pages 15–22:** source entries, citation guidance, provenance, and revision history are present. Source numbering is visible without clipped left edges. Supporting material remains visibly distinct from the main argument. This is a reading-surface finding, not a new verification of every cited external source.

### PDF destinations and citations

All 22 Contents links point to the intended named destination. Each corresponding heading appears on the destination page, and its outline node points to that same page. The outline also contains the article title, for 23 nodes total.

There are 49 numeric citation annotations. Their `(citation number, target URI)` multiset exactly matches the manuscript: zero missing and zero extra. Both contextual targets associated with source 31 remain present. External URLs were compared as stored targets; no claim is made that each remote page was freshly visited or remains available.

### HTML: actual navigation

Served only the native kit on a loopback HTTP server and used the configured local Chromium. In each of `article.html`, `print.html`, `linkedin.html`, and `medium.html`, clicked every one of the 22 Contents links: **88 actual clicks**. Each action set the expected hash, selected the expected heading, and placed that target in the viewport.

Each variant has four successfully loaded images and 49 numeric citation links. Article and print variants retain two tables. Platform reading variants use the intended row-based fallback instead. The browser run made no external requests and recorded no page errors.

### Copy-ready: actual clipboard and paste

For each of `linkedin-copy-ready.html` and `medium-copy-ready.html`, used real keyboard `Control+A`, `Control+C`, and `Control+V` into a separate local `contenteditable` target. Read the actual clipboard HTML/plain payload and inspected the resulting pasted DOM. This was not simulated by assigning source HTML directly to the target.

For both transfers:

- Complete normalized visible text equals the source's visible text.
- Ordered headings are unchanged. The title, subtitle, and R30 author/date line remain present, with the byline once.
- All four image sources are unchanged and all four images load before and after paste.
- All 49 numeric link labels and URLs are unchanged, in the same order.
- All eight fallback rows remain: three rows for the response example and five for the pilot table. Their ordered headings and all cell prose are retained, supported by heading equality and complete visible-text equality.
- Navigation and the generated article summary are hidden in the copy-ready source; they are not inserted as visible article content by the tested copy operation.

The pasted screenshots record the local editor after the caret moved to the end of the pasted document. They are transfer evidence, not a claim about a publication platform's visual treatment.

## Findings and disposition

1. **Two repeated outline labels — minor, nonblocking.** The PDF outline label for Part III repeats its first line, and the label for Sources repeats “Sources & references.” The visible headings and Contents entries are correct, and both outline destinations navigate to the correct pages (13 and 15). This is a native PDF bookmark-label cosmetic defect. It does not justify widening the current work or editing the PDF after generation. A later producer-level fix should preserve heading semantics and be verified on actual output.
2. **Short history tail on page 22 — cosmetic preference.** Page 22 has two intact historical bullets totaling 17 words, plus the footer. This uses a mostly empty last page, but it does not interrupt the argument or a current paragraph. Page count is not an acceptance target. Do not shrink body text or reflow unrelated content to remove it.
3. **“Verify the Explanation” near the foot of page 5 — not a defect.** The heading has its complete two-line introductory paragraph beneath it. The subsequent standalone prompt and its entire first answer appear together on page 6. It therefore satisfies both the ordinary heading-with-following-content behavior and the specific prompt/answer requirement. Forcing the whole subsection to start on page 6 would add whitespace without resolving a failed requirement.

No blocking finding requires another implementation change or rerender on this artifact. No new durable regression test was authored by this reviewer; the temporary check scripts are acceptance evidence and leave implementation ownership separate.

## Risk, scenario, oracle, result

| Risk / requirement area | Scenario | Independent oracle | Observed result |
| --- | --- | --- | --- |
| R30.1 / R30.7: hierarchy fails to clarify the argument | Open title/Contents, scan all pages | Actual PDF renders; visible nesting and supporting group | Pass |
| R30.3 / R30.7: prompt loses its consequence | Read every prompt at page boundaries | Complete source first-answer match on same PDF page | 12/12 pass |
| R30.6 / R30.7: tables or planning become harder to read | Read response example and pilot decisions | Whole short table; compact planning; intact pilot rows and repeated header | Pass |
| R30.6: citation attachment or target is lost | Compare source numeric links to PDF annotations | Exact multiset of number/URI pairs | 49/49, zero differences |
| R30.7: navigation lands in the wrong section | Click every HTML Contents item; inspect PDF destinations | Expected target heading, hash/page, viewport | 88 HTML actions and 22 PDF targets pass |
| R30.7: copy-ready transfer drops article material | Actual keyboard copy/paste to local editor | Full visible-text equality; exact headings/images/numeric links; 8 fallback headings | Both forms pass |
| Preserved figures become illegible | Inspect retained dense diagrams at full-page size | Direct visual reading of titles/labels/captions | Acceptable within unchanged-artwork scope |

## Evidence and diagnostic limits

Evidence directory: `/tmp/r30-exploratory/`.

- `pdf-inventory.json`: actual page inventory, rendered page images, and contact sheets.
- `pdf-checks.json`: final prompt grouping, numeric target comparison, short-table evidence, outline, and Contents links.
- `supplemental-checks.json`: exact clipboard preservation checks, corrected fallback counts, all 88 HTML actions, all 22 PDF targets, and the two outline-label observations.
- `browser-check.mjs` and `browser-checks.json`: actual local navigation/clipboard procedure and raw observations.
- `linkedin-clipboard.html`, `linkedin-clipboard.txt`, `medium-clipboard.html`, `medium-clipboard.txt`: retained clipboard MIME payloads.
- `page-1.png` through `page-22.png`; six `pages-*.png` contact sheets; HTML and pasted-target screenshots.

Three diagnostic limitations were corrected without changing the artifact: an initial simplistic link regex truncated a DOI containing nested parentheses (the initial output is retained as `pdf-checks-initial-parser.json`); a first optional parser invocation lacked BeautifulSoup and was replaced with existing structured evidence/PyMuPDF; and the initial row-fallback selector expected a class that is not used by the generated plain `section > h3` representation. The final exact checks use balanced link parsing and the actual row headings. These were local test-oracle errors, not product defects, and they did not require a new artifact.

**Unobserved:** native LinkedIn and Medium editor sanitization/publishing, signed-in sessions, physical devices, hosted deployment, managed release browser behavior, printer output, and remote source availability. The findings above apply to this exact local review kit. Semantic editorial/source acceptance remains the separate reviewer’s responsibility.
