import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const {chromium}=require('/workspace/scratch/25351d6f7f8e/article-work/tools/publishing/toolchain/node_modules/playwright');
const native=JSON.parse(fs.readFileSync('/tmp/r30-native-result.json','utf8'));
const root=native.directory,out='/tmp/r30-exploratory';
const browserConfig=JSON.parse(fs.readFileSync('/tmp/r30-browser.json','utf8'));
const result={artifactId:native.manifest.artifactId,source:native.manifest.source.sha256,formats:[],copy:[],blockedExternalRequests:[],errors:[]};
const mime={'.html':'text/html;charset=utf-8','.css':'text/css','.png':'image/png','.json':'application/json'};
const server=http.createServer((req,res)=>{
 const pathname=new URL(req.url,'http://localhost').pathname;
 if(pathname==='/paste-target') {res.setHeader('Content-Type','text/html');res.end('<!doctype html><meta charset="utf-8"><title>Local QA paste target</title><div id="editor" contenteditable="true" style="min-height:200px;border:1px solid #888"></div>');return;}
 const file=path.resolve(root,'.'+decodeURIComponent(pathname));
 if(!file.startsWith(root+path.sep)){res.statusCode=403;res.end();return;}
 try {const b=fs.readFileSync(file);res.setHeader('Content-Type',mime[path.extname(file)]||'application/octet-stream');res.end(b);}catch{res.statusCode=404;res.end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin=`http://127.0.0.1:${server.address().port}`;
let browser;
try {
 browser=await chromium.launch({...browserConfig,headless:true});
 const context=await browser.newContext({viewport:{width:1280,height:1000},permissions:['clipboard-read','clipboard-write'],serviceWorkers:'block'});
 await context.route('**/*',async route=>{const u=route.request().url();if(u.startsWith(origin)||u.startsWith('data:'))await route.continue();else{result.blockedExternalRequests.push(u);await route.abort();}});
 const inspect=async(page,scope='main')=>page.locator(scope).evaluate(el=>{
  const visible=(n)=>{const s=getComputedStyle(n);return s.display!=='none'&&s.visibility!=='hidden';};
  return {text:el.innerText,headings:[...el.querySelectorAll('h1,h2,h3')].map(n=>n.textContent.trim()),images:[...el.querySelectorAll('img')].map(n=>({src:n.getAttribute('src'),loaded:n.complete&&n.naturalWidth>0,width:n.naturalWidth})),numeric:[...el.querySelectorAll('a')].filter(n=>/\[\d+\]/.test(n.textContent)).map(n=>({text:n.textContent.trim(),href:n.href})),navVisible:[...el.querySelectorAll('nav')].some(visible),summaryVisible:[...el.querySelectorAll('.article-print-summary')].some(visible),rowSections:[...el.querySelectorAll('section')].filter(n=>n.className.includes('table')).map(n=>n.textContent.trim()),tables:el.querySelectorAll('table').length};
 });
 const page=await context.newPage();
 for(const file of ['article.html','print.html','linkedin.html','medium.html']) {
  await page.goto(origin+'/'+file,{waitUntil:'networkidle'});
  const state=await inspect(page);
  const links=await page.locator('nav a[href^="#"]').evaluateAll(nodes=>nodes.map(n=>({text:n.textContent.trim(),href:n.getAttribute('href')})));
  const navigation=[];
  for(const link of links){
   await page.locator(`nav a[href="${link.href}"]`).click();
   navigation.push(await page.evaluate(({href,text})=>{const el=document.getElementById(decodeURIComponent(href.slice(1)));const b=el?.getBoundingClientRect();return{href,text,hash:location.hash,target:el?.textContent.trim(),inViewport:!!b&&b.bottom>0&&b.top<innerHeight};},link));
  }
  await page.goto(origin+'/'+file,{waitUntil:'networkidle'});
  await page.screenshot({path:out+'/'+file.replace('.html','')+'-firstscreen.png'});
  result.formats.push({file,state,navigation});
 }
 for(const platform of ['linkedin','medium']){
  const file=platform+'-copy-ready.html';
  const source=await context.newPage();await source.goto(origin+'/'+file,{waitUntil:'networkidle'});
  const before=await inspect(source);
  await source.locator('h1').click();await source.keyboard.press('Control+a');await source.keyboard.press('Control+c');
  const clipboard=await source.evaluate(async()=>{const items=await navigator.clipboard.read();let html='',plain='';for(const i of items){if(i.types.includes('text/html'))html+=await(await i.getType('text/html')).text();if(i.types.includes('text/plain'))plain+=await(await i.getType('text/plain')).text();}return{html,plain};});
  fs.writeFileSync(out+'/'+platform+'-clipboard.html',clipboard.html);fs.writeFileSync(out+'/'+platform+'-clipboard.txt',clipboard.plain);
  const target=await context.newPage();await target.goto(origin+'/paste-target');await target.locator('#editor').focus();await target.keyboard.press('Control+v');
  const after=await inspect(target,'#editor');
  await target.screenshot({path:out+'/'+platform+'-pasted-firstscreen.png'});
  result.copy.push({platform,before,after,clipboardBytes:{html:Buffer.byteLength(clipboard.html),plain:Buffer.byteLength(clipboard.plain)},equalVisibleText:before.text.replace(/\s+/g,' ').trim()===after.text.replace(/\s+/g,' ').trim()});
  await source.close();await target.close();
 }
 await context.close();
}catch(e){result.errors.push(String(e.stack||e));}finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));fs.writeFileSync(out+'/browser-checks.json',JSON.stringify(result,null,2));}
console.log(JSON.stringify({formats:result.formats.map(x=>({file:x.file,images:x.state.images.length,numeric:x.state.numeric.length,tables:x.state.tables,rowSections:x.state.rowSections.length,navigation:x.navigation.length,badNavigation:x.navigation.filter(y=>!y.inViewport||y.hash!==y.href)})),copy:result.copy.map(x=>({platform:x.platform,beforeImages:x.before.images.length,afterImages:x.after.images.length,beforeNumeric:x.before.numeric.length,afterNumeric:x.after.numeric.length,equalVisibleText:x.equalVisibleText,beforeTables:x.before.tables,afterTables:x.after.tables,beforeRowSections:x.before.rowSections.length,afterRowSections:x.after.rowSections.length,navVisible:x.before.navVisible,summaryVisible:x.before.summaryVisible})),errors:result.errors,blockedExternalRequests:result.blockedExternalRequests},null,2));
