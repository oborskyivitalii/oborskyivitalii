'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const cp = require('node:child_process');
const root = '/workspace/scratch/25351d6f7f8e/article-work';
const base = 'cdb68f8a9fa4fd26525c577051cffa6314288109';
const runner = require(path.join(root, 'tools/quality/source-tests.cjs'));
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const read = file => fs.readFileSync(path.join(root, file));
const atBase = file => cp.execFileSync('git', ['show', base + ':' + file], { cwd: root });
const before = JSON.parse(atBase('.github/repository-paths.json'));
const current = JSON.parse(read('.github/repository-paths.json'));
const expected = JSON.parse(fs.readFileSync('/tmp/r30-catalog-owner-correction.json', 'utf8'));
const registry = runner.loadRegistry(root);
const report = { base, node: process.version, sourceHashes: {}, cases: [] };
const files = ['.github/repository-paths.json', 'tests/article-media.test.cjs', 'tests/release-controller.test.cjs', 'tools/quality/source-tests.cjs', 'tools/quality/test-profiles.json', 'tests/test-profile-selection.test.cjs', 'tests/content-baseline.test.cjs', '.github/acceptance/issue-5.json'];
for (const file of files) report.sourceHashes[file] = hash(read(file));
function check(name, action) {
  try { report.cases.push({ name, status: 'pass', details: action() }); }
  catch (error) { report.cases.push({ name, status: 'fail', error: error.message }); }
}
check('catalog semantic delta is exactly the sixteen approved owner corrections', () => {
  assert.deepEqual(Object.keys(current).sort(), Object.keys(before).sort());
  assert.deepEqual(Object.keys(current.entries).sort(), Object.keys(before.entries).sort());
  for (const key of Object.keys(current).filter(key => key !== 'entries')) assert.deepEqual(current[key], before[key]);
  const changed = Object.keys(current.entries).filter(file => JSON.stringify(current.entries[file]) !== JSON.stringify(before.entries[file]));
  assert.equal(changed.length, 16);
  assert.deepEqual(changed.sort(), expected.records.map(row => row.path).sort());
  for (const file of changed) {
    assert.equal(before.entries[file].owner, 'tools/site/build.cjs');
    assert.equal(current.entries[file].owner, 'site/README.md');
    assert.deepEqual({ ...before.entries[file], owner: 'site/README.md' }, current.entries[file]);
  }
  return { changedOwners: changed.length, catalogSha256: hash(read('.github/repository-paths.json')) };
});
check('original inventory fails; corrected inventory passes without changing the guard', () => {
  assert.equal(runner.publicationInventoryCompatible(registry, before, before), false);
  assert.equal(runner.publicationInventoryCompatible(registry, current, current), true);
  assert.equal(runner.publicationInventoryCompatible(registry, before, current), true);
  return { originalCurrentCurrent: false, correctedCurrentCurrent: true, originalToCorrected: true };
});
check('one wrongly owned generated record remains rejected', () => {
  const bad = structuredClone(current);
  bad.entries[expected.records[0].path].owner = 'tools/site/build.cjs';
  assert.equal(runner.publicationInventoryCompatible(registry, current, bad), false);
  return { rejectedPath: expected.records[0].path };
});
check('classification guards, profiles, negative tests and owning policy are byte-unchanged', () => {
  const unchanged = files.slice(3);
  for (const file of unchanged) assert.deepEqual(read(file), atBase(file), file);
  return unchanged;
});
check('the complete R30 increment still requires platform classification', () => {
  const paths = cp.execFileSync('git', ['diff', '--name-only', 'd488c64b825d60c4c6531f9cad2091eefc4a04ba'], { cwd: root, encoding: 'utf8' }).trim().split('\n');
  assert.ok(paths.includes('tools/publishing/kit.cjs'));
  assert.ok(paths.includes('site/templates/articles/print.html'));
  const classified = runner.classifyContent(registry, paths);
  assert.equal(classified.mode, 'platform');
  return { mode: classified.mode, changedPaths: paths.length };
});
check('current fixture updates bind actual R30 source and production tuple', () => {
  const source = read('site/publications/pmday-ai-both-sides/manuscript.en.md');
  const metadata = JSON.parse(read('site/publications/pmday-ai-both-sides/publication.json'));
  const mediaTest = read('tests/article-media.test.cjs').toString('utf8');
  const releaseTest = read('tests/release-controller.test.cjs').toString('utf8');
  assert.equal(hash(source), '2c8729927685f7abec734865013dded9e98cce925bbd727faae74f074006bc29');
  assert.equal(metadata.edition, 'pmday-ai-both-sides-en-review-20261024-r30');
  assert.ok(mediaTest.includes("'" + hash(source) + "'"));
  assert.ok(mediaTest.includes("'" + metadata.edition + "'"));
  const motion = require(path.join(root, 'tools/quality/color-motion-contract.cjs'));
  const actual = JSON.parse(fs.readFileSync('/tmp/r30-color-production/artifact.json', 'utf8'));
  assert.equal(motion.select(actual).id, 'issue5-r30-print-production');
  assert.ok(releaseTest.includes("'issue5-r30-print-production'"));
  return { sourceSha256: hash(source), edition: metadata.edition, productionTuple: motion.select(actual).id };
});
report.pass = report.cases.every(item => item.status === 'pass');
fs.writeFileSync('/tmp/r30-final-whitebox-catalog-probe.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (!report.pass) process.exitCode = 1;
