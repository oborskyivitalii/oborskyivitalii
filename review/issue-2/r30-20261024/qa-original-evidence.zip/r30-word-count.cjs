const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {execFileSync} = require('node:child_process');
const root = '/workspace/scratch/25351d6f7f8e/article-work';
const {loadArticle,compile} = require(path.join(root,'tools/publishing/article.cjs'));
const article = loadArticle(root,'pmday-ai-both-sides');
const file = article.source.path;
const baseline = execFileSync('git',['show','d488c64b825d60c4c6531f9cad2091eefc4a04ba:'+file],{cwd:root}).toString('utf8');
const current = fs.readFileSync(path.join(root,file),'utf8');
function visible(node) {
  if (node.type === 'image') return '';
  if (node.type === 'link' && /^\[\d+\]$/.test((node.children || []).map(visible).join(''))) return '';
  if (node.type === 'text' || node.type === 'inlineCode') return node.value || '';
  return (node.children || []).map(visible).join(['table','tableRow','root','list','listItem'].includes(node.type) ? ' ' : '');
}
function count(source) {
  const nodes = compile(source,article.assets,{title:article.metadata.title}).model.tree.children;
  const end = nodes.findIndex(n=>n.type==='heading' && n.id==='sources-references');
  if (end<0) throw new Error('Source boundary absent');
  const prose = nodes.slice(3,end).map(visible).join('\n');
  const words = prose.match(/[\p{L}\p{N}]+(?:['’][\p{L}\p{N}]+)*/gu) || [];
  return {sha256:crypto.createHash('sha256').update(source).digest('hex'),words:words.length};
}
const report = {method:'Same AST-visible body from after title/subtitle/byline through before Sources & references; includes argument headings, prompts, table cells and resource link labels; excludes generated figure captions/credits, image alt text, link URLs, numeric citation labels, markup, generated TOC, source notes and publication apparatus. Unicode letter/number words; apostrophes internal; hyphens/dashes separate.',baseline:count(baseline),r30:count(current)};
report.wordsRemoved=report.baseline.words-report.r30.words;
report.reductionPercent=100*report.wordsRemoved/report.baseline.words;
fs.writeFileSync('/tmp/r30-body-word-count.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
