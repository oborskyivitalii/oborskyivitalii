'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const root = '/workspace/scratch/25351d6f7f8e/article-work';
const { loadArticle, compile } = require(path.join(root, 'tools/publishing/article.cjs'));
const { loadProfile } = require(path.join(root, 'tools/publishing/profile.cjs'));
const { verifyKit } = require(path.join(root, 'tools/publishing/kit.cjs'));
const { blockDigest } = require(path.join(root, 'tools/publishing/semantic.cjs'));
const { render, plain } = require(path.join(root, 'tools/publishing/render.cjs'));
const hash = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const report = { reviewer: '/root/r29_precision_qa', node: process.version, cases: [] };
function check(name, fn) {
  try { const details = fn(); report.cases.push({ name, status: 'pass', details }); }
  catch (error) { report.cases.push({ name, status: 'fail', error: error.message }); }
}
function read(relative) { return fs.readFileSync(path.join(root, relative)); }
function body(html) { return html.match(/<article class="article-print-body">([\s\S]*?)<\/article>/)[1]; }
function ungroup(html) { return html.replaceAll('<div class="article-print-keep">', '').replaceAll('</div>', ''); }
function snippets(model, role) { return model.tree.children.filter((node) => node.type === role); }
async function main() {
  const article = loadArticle(root, 'pmday-ai-both-sides');
  const source = read(article.source.path);
  const original = execFileSync('git', ['show', 'd488c64b825d60c4c6531f9cad2091eefc4a04ba:' + article.source.path], { cwd: root });
  const baseline = compile(original.toString('utf8'), article.assets, { title: article.metadata.title });
  const result = JSON.parse(fs.readFileSync('/tmp/r30-native-result.json', 'utf8'));
  const manifest = await verifyKit(result.directory);
  report.identity = {
    base: 'd488c64b825d60c4c6531f9cad2091eefc4a04ba',
    candidateState: article.source.state,
    sourceSha256: hash(source),
    semanticSha256: article.edition.semanticSha256,
    artifactId: manifest.artifactId,
    directory: result.directory,
    implementation: Object.fromEntries(['tools/publishing/kit.cjs', 'tools/publishing/profile.cjs', 'site/templates/articles/print.html', 'site/engine/article-print.css', 'tests/publishing.test.cjs', 'tests/publishing-profile.test.cjs'].map((file) => [file, hash(read(file))])),
  };
  check('current immutable source, producer inputs and complete kit bind actual bytes', () => {
    assert.equal(hash(source), '2c8729927685f7abec734865013dded9e98cce925bbd727faae74f074006bc29');
    assert.equal(manifest.source.sha256, hash(source));
    assert.equal(manifest.semanticSha256, article.edition.semanticSha256);
    for (const item of [...manifest.inputHashes, ...manifest.producer.inputs]) assert.equal(hash(read(item.path)), item.sha256, item.path);
    return { outputs: manifest.outputs.length, pdf: manifest.outputs.find((item) => item.path === 'article.pdf') };
  });
  check('source inventory preserves all prompts, full source-note AST, exact tables and figures', () => {
    const prompts = (model) => snippets(model, 'paragraph').filter((node) => plain(node) === 'What if not?');
    assert.equal(prompts(article.model).length, 12);
    assert.equal(prompts(baseline.model).length, 12);
    assert.deepEqual(snippets(article.model, 'table'), snippets(baseline.model, 'table'));
    assert.equal(snippets(article.model, 'table').length, 2);
    assert.deepEqual(article.model.figures, baseline.model.figures);
    assert.equal(article.model.figures.length, 4);
    const notes = (model) => { const nodes = model.tree.children; const index = nodes.findIndex((node) => node.id === 'sources-references'); return nodes.slice(index + 1).find((node) => node.type === 'list' && node.ordered); };
    assert.deepEqual(notes(article.model), notes(baseline.model));
    assert.equal(notes(article.model).children.length, 36);
    return { prompts: 12, sources: 36, tables: 2, figures: article.model.figures };
  });
  check('citation destination multisets and both contextual source-31 associations survive', () => {
    const citations = (model) => model.links.filter((link) => /\[\d+\]/.test(link.text)).map((link) => JSON.stringify(link)).sort();
    assert.deepEqual(citations(article.model), citations(baseline.model));
    const urls = (model) => model.links.map((link) => link.url).sort();
    assert.deepEqual(urls(article.model), urls(baseline.model));
    return { numericCitations: citations(article.model).length, links: article.model.links.length, source31: article.model.links.filter((link) => link.text.includes('[31]')) };
  });
  const assets = article.assets.map((asset) => ({ ...asset, url: manifest.assets.find((item) => item.id === asset.id).path }));
  const compiled = compile(source.toString('utf8'), assets, { title: article.metadata.title, preserveTables: true });
  const nodes = compiled.model.tree.children;
  const furniture = Object.values(article.profile.print.titleBlock).map((digest) => nodes.find((node) => blockDigest(node) === digest));
  for (const filename of ['article.html', 'print.html', 'linkedin.html', 'medium.html', 'linkedin-copy-ready.html', 'medium-copy-ready.html']) {
    check(filename + ': moved furniture and grouping preserve the entire source body', () => {
      const html = fs.readFileSync(path.join(result.directory, filename), 'utf8');
      const platform = /linkedin|medium/.test(filename);
      let expected = platform ? compiled.platformBodyHtml : compiled.bodyHtml;
      for (const node of furniture) expected = expected.replace(render({ tree: node }, assets, platform), '');
      if (filename.includes('copy-ready')) for (const asset of assets) expected = expected.replaceAll('src="' + asset.url + '"', 'src="data:image/png;base64,' + asset.bytes.toString('base64') + '"');
      assert.equal(ungroup(body(html)).trim(), expected.trim());
      const header = html.match(/<header[\s\S]*?<\/header>/)[0];
      for (const node of furniture) assert.ok(header.includes(render({ tree: { type: 'root', children: node.children } }, assets, platform)));
      assert.equal((html.match(/Vitalii Oborskyi · Editorial draft R30 · 24 October 2026/g) || []).length, 1);
      assert.equal((body(html).match(/<div class="article-print-keep"><p><strong>What if not\?<\/strong><\/p>\n<p>/g) || []).length, 12);
      return { sourceBodyExactAfterDeclaredTransforms: true, promptGroups: 12, titleFurnitureInstances: 1 };
    });
  }
  check('nested Contents covers each admitted section once with valid unique targets', () => {
    const html = fs.readFileSync(path.join(result.directory, 'print.html'), 'utf8');
    const nav = html.match(/<nav[\s\S]*?<\/nav>/)[0];
    const targets = [...nav.matchAll(/href="#([^"]+)"/g)].map((match) => match[1]);
    const wanted = article.sections.filter((section) => section.depth < 4).map((section) => section.id);
    assert.deepEqual(targets, wanted);
    assert.equal(new Set(targets).size, targets.length);
    for (const target of targets) assert.equal((html.match(new RegExp('id="' + target + '"', 'g')) || []).length, 1, target);
    assert.equal((nav.match(/<ol>/g) || []).length, 5);
    for (const section of article.sections.filter((section) => section.depth === 2 && /^[I]+\./.test(section.text))) assert.ok(nav.includes('<li><a href="#' + section.id + '">' + section.text + '</a><ol>'));
    const support = nav.split('class="article-print-toc-appendices"')[1];
    for (const appendix of article.profile.reader.sections.appendices) assert.ok(support.includes('href="#' + appendix + '"'));
    return { targets: targets.length, lists: 5, appendixTargets: article.profile.reader.sections.appendices };
  });
  check('ordinary real profiles remain admitted without print-role opt-in', () => {
    const ids = ['reader-reference', 'pmday-two-shifts'];
    for (const id of ids) assert.equal(loadArticle(root, id).profile.print, undefined);
    return ids;
  });
  const temporary = fs.mkdtempSync('/tmp/r30-whitebox-profile-');
  try {
    const profilePath = 'site/publications/pmday-ai-both-sides/profile.json';
    const save = (relative, data) => { const target = path.join(temporary, relative); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, data); };
    save(article.launch.path, article.launch.bytes);
    for (const asset of article.assets) save(asset.path, asset.bytes);
    function negative(name, change, expected) {
      check(name, () => {
        const candidate = structuredClone(article.profile);
        const model = { ...article, model: structuredClone(article.model) };
        change(candidate, model);
        save(profilePath, JSON.stringify(candidate));
        let observed;
        assert.throws(() => { try { loadProfile(temporary, model); } catch (error) { observed = error.message; throw error; } }, expected);
        return { rejection: observed };
      });
    }
    negative('negative: an ambiguous repeated source block cannot acquire an explicit print role', (profile, model) => {
      const selected = model.model.tree.children.find((node) => blockDigest(node) === profile.print.keepTogether[1]);
      model.model.tree.children.push(structuredClone(selected));
    }, /distinct admitted/);
    negative('negative: one digest cannot be selected by both grouping roles', (profile) => {
      profile.print.keepWithNext.push(profile.print.keepTogether[1]);
    }, /distinct admitted/);
    negative('negative: incomplete title furniture cannot silently use a missing byline', (profile) => {
      delete profile.print.titleBlock.byline;
    }, /distinct admitted/);
    negative('negative: empty print opt-in is rejected', (profile) => { profile.print = {}; }, /explicit layout binding/);
  } finally { fs.rmSync(temporary, { recursive: true, force: true }); }
  report.status = report.cases.every((item) => item.status === 'pass') ? 'pass' : 'fail';
  fs.writeFileSync('/tmp/r30-whitebox-probe.json', JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
  if (report.status !== 'pass') process.exitCode = 1;
}
main().catch((error) => { report.error = error.stack; report.status = 'fail'; fs.writeFileSync('/tmp/r30-whitebox-probe.json', JSON.stringify(report, null, 2) + '\n'); console.error(error); process.exitCode = 1; });
