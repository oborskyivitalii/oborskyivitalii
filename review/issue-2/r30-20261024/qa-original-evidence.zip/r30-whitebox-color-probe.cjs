'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const root = '/workspace/scratch/25351d6f7f8e/article-work';
const motion = require(path.join(root, 'tools/quality/color-motion-contract.cjs'));
const delivery = require(path.join(root, 'tools/staging/package.cjs'));
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const report = { reviewer: '/root/r29_precision_qa', node: process.version, hashes: {}, cases: [] };
for (const file of ['tools/quality/color-motion-contract.cjs', 'tools/staging/package.cjs', 'tests/color-motion-contract.test.cjs', 'tests/staging-regression.test.cjs']) report.hashes[file] = hash(path.join(root, file));
function check(name, action) {
  try { report.cases.push({ name, status: 'pass', details: action() }); }
  catch (error) { report.cases.push({ name, status: 'fail', error: error.message }); }
}
for (const mode of ['plain', 'staging', 'production']) {
  const directory = '/tmp/r30-color-' + mode;
  const artifact = JSON.parse(fs.readFileSync(path.join(directory, 'artifact.json'), 'utf8'));
  const receipt = JSON.parse(fs.readFileSync(directory + '.json', 'utf8'));
  const expectedId = 'issue5-r30-print-' + mode;
  check(mode + ': current actual files match registered tuple and predecessor bytes', () => {
    const runtime = motion.select(artifact);
    assert.equal(runtime.id, expectedId);
    assert.deepEqual(runtime.variant, receipt.variant);
    assert.deepEqual(runtime.files, receipt.files);
    assert.deepEqual(runtime.files, motion.reviewedRuntime('issue5-review-paths-' + mode).files);
    for (const [filename, expected] of Object.entries(runtime.files)) {
      assert.equal(hash(path.join(directory, 'public', filename)), expected, filename);
      assert.equal(hash(path.join(directory, 'public/runtime', runtime.variant.fingerprint, filename)), expected, filename);
    }
    assert.equal(motion.flightCheck(artifact), 'blockFlight');
    for (const engine of [runtime.variant.fingerprint, runtime.variant.baseEngine]) {
      assert.equal(motion.articleReadingMode(engine), 'stationary');
      assert.equal(motion.readerWholeBlocksRequired(engine), true);
      assert.equal(motion.readerPaperRequired(engine), true);
      assert.equal(motion.readerDeferredMediaRequired(engine), true);
      assert.equal(motion.readerInteractionsRequired(engine), true);
    }
    return { id: runtime.id, variant: runtime.variant, files: runtime.files, artifactSha256: hash(path.join(directory, 'artifact.json')) };
  });
  check(mode + ': mandatory rights guard rejects missing record before file access', () => {
    assert.equal(delivery.publicationRequired(artifact, artifact.components), true);
    let observed;
    assert.throws(() => {
      try { delivery.publicationRights('/no-file-access', artifact, undefined, artifact.components); }
      catch (error) { observed = error.message; throw error; }
    }, /licensed publication rights record required/);
    return { publicationRequired: true, missingRights: observed };
  });
  check(mode + ': canonical bytes, immutable bytes, base engine and edition remain strict', () => {
    const canonical = structuredClone(artifact);
    canonical.files['space.js'].sha256 = '0'.repeat(64);
    assert.throws(() => motion.select(canonical), /unreviewed Color bytes/);
    const immutable = structuredClone(artifact);
    immutable.files['runtime/' + immutable.variant.fingerprint + '/navigation.js'].sha256 = '0'.repeat(64);
    assert.throws(() => motion.select(immutable), /conflicting immutable Color bytes/);
    const engine = structuredClone(artifact);
    engine.variant.baseEngine = motion.reviewedRuntime('issue5-review-paths-' + mode).variant.baseEngine;
    engine.components.variant.baseEngine = engine.variant.baseEngine;
    assert.throws(() => motion.select(engine), /Color motion identity/);
    const edition = structuredClone(artifact);
    edition.edition = mode === 'staging' ? undefined : { id: 'staging', indexable: false, analytics: false };
    assert.throws(() => motion.select(edition), /edition differs/);
    return { negativePartitions: 4 };
  });
}
report.pass = report.cases.every(item => item.status === 'pass');
fs.writeFileSync('/tmp/r30-whitebox-color-probe.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (!report.pass) process.exitCode = 1;
