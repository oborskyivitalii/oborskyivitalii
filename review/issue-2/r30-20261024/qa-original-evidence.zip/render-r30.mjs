import fs from 'node:fs';
import { createRequire } from 'node:module';
import chromium from '/tmp/r30-runtime/node_modules/@sparticuz/chromium/build/index.js';
import { createReviewProducer } from '/workspace/scratch/25351d6f7f8e/article-work/tools/publishing/print.mjs';
const require = createRequire(import.meta.url);
const { renderKit, verifyKit } = require('/workspace/scratch/25351d6f7f8e/article-work/tools/publishing/kit.cjs');
const executablePath = await chromium.executablePath();
fs.writeFileSync('/tmp/r30-browser.json', JSON.stringify({ executablePath, args: chromium.args }, null, 2));
const printProducer = createReviewProducer({
  executablePath,
  packagePath: '/tmp/r30-runtime/node_modules/@sparticuz/chromium/package.json',
  archivePath: '/tmp/r30-runtime/sparticuz-chromium-153.0.0.tgz',
  args: chromium.args,
});
const result = await renderKit('/workspace/scratch/25351d6f7f8e/article-work', 'pmday-ai-both-sides', {
  outputRoot: '/workspace/scratch/25351d6f7f8e/article-work/dist/publications', pdf: true, printProducer,
});
await verifyKit(result.directory);
fs.writeFileSync('/tmp/r30-native-result.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify({ directory: result.directory, artifactId: result.manifest.artifactId, outputs: result.manifest.outputs.length }));
