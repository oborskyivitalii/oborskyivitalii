# R30 Requirements assessment — final policy correction

Reviewer: `/root/r30_requirements`, independent of implementers.
Date: 24 October 2026. Owner: issue5 / Draft PR79; editorial owner: issue2.
Correction base: `cdb68f8a9fa4fd26525c577051cffa6314288109`, tree
`144ef063e4dd0d7adfec0f7be85c41897d2a95ee`.
Candidate: prepared three-file correction, not a new clean-policy result.

## Decision

**PASS for the bounded correction under R30.8.** It restores the existing inventory
contract and updates current-fixture expectations to the already reviewed R30
identities. No requirement, classifier, allowlist, resource budget or rejection
condition is weakened. There is no further implementation correction requested.

R30.1–R30.7 remain supported by their unchanged article/native identities.
**Whole R30.8/R30.9 completion still requires the new exact-clean policy and live
same-Draft-PR/issue reconciliation.** The original clean8/12failure remains failed
evidence; the focused successes below do not retroactively change it.

## Actual inspected delta and identities

I inspected the complete three-file diff against the correction base, surrounding
test assertions and unchanged inventory guard. A direct reconstruction confirms:

| File | Exact change | Inspected SHA256 |
| --- | --- | --- |
| `.github/repository-paths.json` | Exactly16new generated runtime/snapshot owner fields change from `tools/site/build.cjs` to `site/README.md`; all paths, other entry fields and top-level data remain unchanged. | `aa5da5417103aaee0db19d047d78ad868e3a059a7d06d566a58b742a4bc4455a` |
| `tests/article-media.test.cjs` | Exactly three substitutions: test name R29→R30, explicit manuscript hash and explicit edition ID. | `25b2433385ac92d557bea105ad2caa3d5cfdaf84eb80dfd9b78cf953c2e97c70` |
| `tests/release-controller.test.cjs` | Exactly one substitution: current production tuple becomes `issue5-r30-print-production`. | `46b02ea1f2e5bbf75c53b22e5fa43530d80aba59e4513c00e1697c9456416c46` |

The classifier, test-profile registry, complete inventory-negative test, real
content-baseline test and issue5policy are byte-identical to the correction base.
The catalog error—not the R30 QA archive or history shape—caused CONTENT-CI's
current/current and controlled ancestor-reuse failures. No history allowance was
added. The two fixture changes retain literal independent expectations rather than
computing expected values from the implementation under test.

My six direct source/identity conditions pass. Original observation:
`/tmp/r30-requirements-correction-checks.json`. All28native source/producer bindings
also remain exact, including manuscript
`2c8729927685f7abec734865013dded9e98cce925bbd727faae74f074006bc29`
and kit `14743fdc40b0f06232203da46ec01fd941c17c5b3cd353930f452ba7c03f685b`.
No native rerender or repeated browser interaction is necessary for these unchanged
bytes; the independent correction-role dispositions remain part of the handoff.

## Requirements-to-evidence reconciliation

I read the implementation receipt, independent White-box correction receipt and
their original raw results. They establish the following bounded outcomes:

- Corrected actual inventory passes current/current and old-to-corrected comparison.
  Restoring an incorrect owner still rejects. The ten existing malformed-owner/role,
  unsupported-entry, deletion/change and schema negatives survive; an unbound
  inventory diff still cannot select content.
- The existing real ancestor-generation scenario again admits its controlled
  content-only fixture. Skipped admission and changed shared labels still select
  platform. The complete47-path R30 increment remains a platform change.
- The actual real R30 preview passes with its explicit source/edition pins. Its
 800,000-byte gzip reading threshold, declared full PDF/media/rights closure and
  corrupt/missing/forged/unsupported-resource rejection assertions remain unchanged.
- The actual production Color fixture selects the exact R30 tuple while retaining
  distinct-rendition, runtime/analytics-byte, rights and incorrect-selection checks.

Execution evidence:

| Executor and scope | Actual result |
| --- | --- |
| Implementer, both full affected test modules |37/37passed; zero failures/skips/cancellations; `/tmp/r30-final-fixture-tests.log`. |
| Independent White-box, existing inventory and real ancestor-reuse cases |2/2selected cases passed; `/tmp/r30-final-whitebox-inventory-tests.raw`. |
| Independent White-box, current preview and production Color cases |2/2selected cases passed; `/tmp/r30-final-whitebox-fixture-tests.raw`. |
| Independent White-box, additional actual-catalog/identity probes |6/6passed; `/tmp/r30-final-whitebox-catalog-probe.json`. |
| Requirements, actual source-delta reconstruction and identity checks |Six conditions pass; no tests, implementation or native files edited by this role. |

The4selected independent cases are not represented as the entire four-module
inventory or the owning policy. I did not rerun native rendering or full tests.
The separate Code correction review and Exploratory unchanged-surface disposition
must be preserved alongside this requirements result before the corrected candidate
advances; this report does not impersonate those roles.

## Remaining exact-source closure

Preserve the original failed policy and all correction receipts; refresh the
evidence/member inventories and derived RI views; freeze the corrected source;
then execute the unchanged issue5policy on that exact clean commit/tree. Keep the
source-bound result distinct from these focused observations, and verify actual
PR79 delivery, Draft state, Refs#5 and criterion-by-criterion checkbox treatment.
Author, rights, native-editor, device, hosted, merge and publication gates remain
separately owned. No new author decision is required for this metadata/fixture repair.
