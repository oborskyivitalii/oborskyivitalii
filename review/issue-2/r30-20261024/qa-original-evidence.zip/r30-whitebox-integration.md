# R30 independent White-box QA — integration delta and correction

Reviewer: `/root/r29_precision_qa`. Date: 24 October 2026.
Execution owner: issue 5 / Draft PR79; editorial owner: issue 2.
Base: `d488c64b825d60c4c6531f9cad2091eefc4a04ba`.
This receipt supplements `/tmp/r30-whitebox.md`; it assesses the current working
candidate, not an unseen final clean commit. The reviewer changed no repository source.

## Verdict

**The integration delta passes after an independently verified correction.**
The initial registration-only candidate had a real publication-rights admission
regression and a stale current-output test expectation. Both are resolved in the
exact corrected files identified below. The corrected focused regressions pass
**45/45**, with no skipped cases. Independent probes pass **9/9 grouped actual
Color cases** and **4/4 source/retention identity checks**.

No blocking gap remains in this bounded delta. Complete catalog/README/QA archive
closure, the final clean source and the full exact-source issue-5 policy remain
the root's responsibility. This receipt does not infer their success.

## Initial findings, preserved as failures

### WB-R30-I1 — missing rights registration (blocking; now corrected)

Adding the three `issue5-r30-print-*` runtime tuples to the Color admission owner
without adding them to `tools/staging/package.cjs`'s explicit licensed list made
the new tuples selectable while leaving publication rights optional.

Independently exercised each actual plain/staging/production artifact from
`/tmp/r30-color-<mode>/artifact.json`. All three selected their R30 tuple but
returned `false` from `publicationRequired(artifact, artifact.components)`.
`publicationRights('/no-file-access', artifact, undefined, artifact.components)`
returned `null`. This was an actual guard regression, not solely an outdated test.

Original result: `/tmp/r30-whitebox-color-initial-probe.json`.
Original package-owner SHA256:
`91e7430e9b737d05cab9d6a25d1533dd4f561dc4109522979bdd2afa7b8df243`.

The original implementation agent added exactly the three new runtime IDs to the
existing licensed owner. Independent re-execution now requires rights in every
mode and throws `licensed publication rights record required` before file access
when the record is absent. The test correction adds the R30/predecessor pair to
the existing byte-preservation and mandatory-rights regression. It also adds R30
to the existing selection, production-identity and malformed/mixed-identity cases.
No threshold, runtime byte, old tuple or guard was removed.

### WB-R30-I2 — stale current-output identity oracle (blocking; now corrected)

The initial focused Color suite ran **21/22**. The current-output closure test
still expected `issue5-review-paths-plain`; the actual correctly selected tuple was
`issue5-r30-print-plain`. Its corresponding staging/production expectations were
also stale, as was the current-family fixture in `staging-regression.test.cjs`.

Original executed failure: `/tmp/r30-whitebox-color-tests.initial.raw`.
Original Color test SHA256:
`ccdd2bff5f899113943ebc5d4b878c5eb52d246569f36bef1e18a7f2a2a287c7`.

The implementer updated those exact current-output expectations and preserved
the historical tuple cases. Independent execution of the two affected regression
files now passes **45/45** (Color 23; staging 22).

## Exact corrected integration identity

| File | SHA256 |
| --- | --- |
| `tools/quality/color-motion-contract.cjs` | `27d61846d818129016c98a783f150e67c4dc7732c4d26639e2a1fff8e6f7551a` |
| `tools/staging/package.cjs` | `442e928c835467c4f73f0f698338a29aef90708479154ca9428bb4b1fcc961a0` |
| `tests/color-motion-contract.test.cjs` | `665c853aa97e4086c85b858a9a23d39dd95433d55acf892d6f3f262af406ece6` |
| `tests/staging-regression.test.cjs` | `982691e68e8634e3ed112dbb4d1b586dac4d1c410c7f679d1a0e1e7f34ccf5c1` |

The Color owner adds one family and three exact variants. Existing selection
logic remains unchanged. The new family retains fixed-block flight, stationary
article reading and the interactions/whole-block/paper/deferred-media requirements.

| Variant | Fingerprint | Actual `artifact.json` SHA256 |
| --- | --- | --- |
| Plain | `fba2e4029b56b03c2f701fb5ea883a36a512fc8319af6bf42c272fcfe1f010c9` | `4769e546ef772b09b07e655e18b0e4f8cd96d3d7c2c9c50f4f7b8486c1b7ee6c` |
| Staging | `15891192cb1cfc9b5701234f77e7a54a2ffc6c31ec2cc95db699d1a9d94b656e` | `d199d4ec877530049a9348ecc78292b0f1f94ff65338291cf7dbeaa030e6a576` |
| Production | `b6fac470206f55a3e9d130d4f5296f06fff9ae9840f63a5fd1ce803998dbe43e` | `6a9cc84dff0a38f7b1f50f13334035939cd0ed4cdbc460e4e97eaad7caeaeeb6` |

All three bind base engine
`c4aa9fa8604178e3ca297f5158cf62563f5eb3448a82b3b12f97a8a48f461f11`.
Their actual five canonical and five immutable runtime files were independently
hashed against the registered tuple, supplied receipt and R29 Color predecessor.
Every comparison passes. The receipts' dirty-source status remains explicit;
these are local runtime-identity observations, not release packages or deployment.

## Risk-to-test matrix

| Risk / AC | Independent oracle and actual check | Result |
| --- | --- | --- |
| R30.8: new family admits the wrong bytes or drops reader requirements | Inspect registration-only diff; select each actual artifact, hash canonical and immutable files, compare predecessor bytes and query reading, flight and all required reader flags | Pass in all three modes |
| R30.7/8: exact runtime selects but rights become optional | Missing-rights call with supplied verified revision and deliberately unavailable directory must reject before file access | Initial failure in all three modes; corrected pass in all three; permanent regression now covers the new pair |
| R30.8: registry or test change weakens identity validation | Independently tamper canonical bytes, immutable bytes, base engine and edition; run existing changed regression owners | All 12 independent negative partitions reject; 45/45 permanent tests pass |
| R30.7/8: generated cleanup deletes retained published dependencies | Derive the ten expected old paths from baseline site revision; compare deletion set exactly; require no retained-manifest or current-lock entry; hash all retained owner/output files | Pass: exactly ten obsolete unretained candidate files; all 25 retained files intact in both locations |
| R30.3/7: integration invalidates earlier article review or rewrites history | Rehash source, six reviewed print/test owners and native PDF; compare 93 baseline tracked retained/article-review/edition paths with current tree | Pass: prior reviewed identity and historical bytes unchanged |

The two affected permanent regression files are already mapped in
`tools/quality/test-profiles.json` to `pr-targeted`, `staging` and `production`.
They remain owned by `guides/SITE-CHECK-PROFILES.md`; the Color owner remains in
their input sets and RI/CI routing. These are directly executed local tests;
no hosted Actions, native-device or browser-behavior pass is claimed.

## Generated deletions and retained history

The ten deleted paths are exactly the previous candidate's five runtime files
under engine `36e9a52051ed974d077e86ea028f5c57838370418637c71391fdf0c9e1eca297`
and its five route snapshots. None is in `site/retained/manifest.json` or the
current output lock. All five current route snapshots exist with their declared
hashes. The site contract explicitly distinguishes current unpublished candidate
snapshots from imported retained published versions.

Independently verified all **25** retained manifest members in both `site/retained`
and `docs`; the manifest itself is byte-identical to baseline. No change or deletion
affects any of the **93** tracked baseline paths under retained source, existing
article review records or existing article editions. This check includes R29's
frozen delivery and does not mistake the new untracked R30 files for old history.

The five current base browser files are byte-for-byte equal to the corresponding
R29 files read from the immutable Git base, independently confirming
`/tmp/r30-runtime-byte-parity.json`.

| Integration record | SHA256 |
| --- | --- |
| `site/output-lock.json` | `9caa81be0930df34792fd0dfd216a830bca53c30559118e36590f0a8ea2444b5` |
| `docs/site-revision.json` | `9327bd89c13f1e918a1358d4471f5d19961e9c9feaa123b556a90b90514d9cfb` |
| `site/retained/manifest.json` | `e678dfc591f579cfde0f0f16cd240ba7c0f8a0c3c4ccb103ad1506bbaee8fe0d` |

## Reused native evidence: identity proved unchanged

The manuscript remains
`2c8729927685f7abec734865013dded9e98cce925bbd727faae74f074006bc29`;
the native kit remains
`14743fdc40b0f06232203da46ec01fd941c17c5b3cd353930f452ba7c03f685b`;
the PDF remains
`e96c4f21ce1f5a130527d3a37fce8f3f46e4b02c57b8fc701331ad1c72374cc1`.
All six prior reviewed publisher/template/CSS/test hashes match the original
White-box receipt. The integration correction changes no article producer input.
The earlier 29/29 publisher and 15/15 semantic/native checks therefore remain
applicable to their unchanged scope; they were not needlessly rerun.

## Executed commands and retained raw evidence

- Initial `node --test tests/color-motion-contract.test.cjs`: sandboxed test file
  failed at startup without individual-case results. Raw result retained at
  `/tmp/r30-whitebox-color-tests.sandbox.raw`; this was not counted as a suite pass.
- `node --test --test-reporter=tap tests/color-motion-contract.test.cjs` using the
  established Node escalation: exit 1, 21/22, the exact stale-ID failure above.
  Original raw output: `/tmp/r30-whitebox-color-tests.initial.raw`.
- Independent actual three-mode original rights reproduction:
  `/tmp/r30-whitebox-color-initial-probe.json`; all three reproduced the bypass.
- Corrected `node --test --test-reporter=tap tests/color-motion-contract.test.cjs
  tests/staging-regression.test.cjs`: exit 0, 45/45, no skips, 10.345 seconds.
  Raw output: `/tmp/r30-whitebox-color-correction-tests.raw`.
- `node /tmp/r30-whitebox-color-probe.cjs`: exit 0; 9/9 grouped cases, including
  12 negative partitions. Source, JSON and raw retained under that same stem.
- `python /tmp/r30-whitebox-integration-files.py`: exit 0; 4/4 source/retention
  cases. Source, JSON and raw retained under that same stem.
- `git diff --check`: exit 0 on the corrected candidate.

Raw receipt hashes:

| Receipt | SHA256 |
| --- | --- |
| Original Color regression failure | `c75b7215f7ea9c9a4b34f2ad2a09b89660e08a7202243f30dffaeeafcce94c33` |
| Original rights-bypass reproduction | `010dd7aa5def8e4385f7f952ba9d74c126656d9170ce2831cd3c263e71106342` |
| Corrected focused regression | `902fe83fcda99dad1820d68b44a5cfa2cf9e2374648be721a266164d64480b5f` |
| Corrected actual Color probe JSON | `80cadac6a179665a29b2e93cfe34088c763221765526d4ee97c17e53b1e5eff8` |
| Source/retention probe JSON | `212a143e40865cd043b6c362d4a8f407d646f78c5f9d2c41739f2e19b425f5dc` |

## Limits and final closure

This delta tested the newly exposed integration risks and preserved original
failure evidence. It did not rerun unrelated suites or a broad browser matrix.
Catalog completion was still in progress for the README/QA archive at assignment;
this receipt does not approve that unfinished inventory. The root must bind the
completed catalog, review package, independent receipts and unchanged policy to
the actual final clean commit/tree. Later material changes require their own
bounded delta review. No merge, staging promotion or publication follows from
this technical correction.
