# R30 Color integration correction

Implementer: `/root/r30_print_implementation`, not an independent reviewer.
Owner: issue5 / existing Draft PR79; editorial owner issue2.
Candidate: prepared dirty R30 source following d488c64; exact owned-file hashes below.

## Original independently observed failure

White-box QA `/root/r29_precision_qa` inspected all three actual
`/tmp/r30-color-{plain,staging,production}/artifact.json` candidates. Color selection
returned the new `issue5-r30-print-*` identities, but the existing explicit licensed
runtime list omitted them. Thus `publicationRequired` returned false and
`publicationRights('/no-file-access', artifact, undefined, artifact.components)`
returned null instead of requiring rights. The original hash-bound probe is retained.

The same independent original Color test run was21/22: the current-output closure
still asserted the older `issue5-review-paths-*` identity. Historical cases remain
valid; only the current-source expectations needed to advance. A separate existing
staging regression also compared current generated components with the old plain ID.

## Bounded correction

- Added exactly `issue5-r30-print-plain`, `issue5-r30-print-staging` and
  `issue5-r30-print-production` to `tools/staging/package.cjs`'s existing licensed list.
  Missing rights are now rejected before any attempt to access the supplied path.
- Extended existing Color selection, production identity and mixed/unknown-byte cases
  to the new family. Added the existing preservation/rights pair
  `['issue5-r30-print', 'issue5-review-paths']`.
- Updated the current-output plain/staging/production/base-engine expectations and the
  staging-regression current plain expectation. Prior families and their historical
  oracles remain intact. No thresholds, deadlines, test policy or guard behavior widened.

Only the three files below changed in this correction. The seven native print-layout
handoff owners all retain their exact earlier bytes; no runtime or native artifact
source was changed. The family-pair tests also establish equality of all five runtime
files with the predecessor while requiring distinct artifact fingerprints.

## Executed checks

`node --test tests/color-motion-contract.test.cjs tests/staging-regression.test.cjs`
with normal subprocess access: **45/45 PASS**,0fail,0skipped,0cancelled,0todo;
7541.020976ms. This includes23Color cases and22staging cases, with the new family
running the unchanged rights/byte/base-engine/edition rejection assertions.

Actual three-mode probe: each real artifact selects its exact R30 ID,
`publicationRequired === true`, and absent rights throw
`licensed publication rights record required` before file access: **3/3 PASS**.

Configured Prettier check on all three changed files: **PASS** using
`tools/quality/prettier.config.json`; `git diff --check`: **PASS**.
No source changes occurred during the final focused test execution.

The existing maintained Color and staging test selection routes remain; no new test
file/profile is introduced. Independent White-box delta review is requested separately.
These controlled contract checks do not claim staging/production deployment, rights
acceptance, hosted/browser/device success or full clean-source issue acceptance.

## Changed-file SHA256

```json
{
  "tools/staging/package.cjs": "442e928c835467c4f73f0f698338a29aef90708479154ca9428bb4b1fcc961a0",
  "tests/color-motion-contract.test.cjs": "665c853aa97e4086c85b858a9a23d39dd95433d55acf892d6f3f262af406ece6",
  "tests/staging-regression.test.cjs": "982691e68e8634e3ed112dbb4d1b586dac4d1c410c7f679d1a0e1e7f34ccf5c1"
}
```

## Protected print handoff comparison

```json
{
  "guides/ARTICLE-WORKFLOW.md": {
    "sha256": "83272df023a2ce9ef12a77a8252e684abaf822653102b65c8b9a8e01c26af295",
    "matchesPrintHandoff": true
  },
  "site/engine/article-print.css": {
    "sha256": "085b5d48cf79bdb8e6321f017353b8e882ffeb705883149871b09e940c0ea0fd",
    "matchesPrintHandoff": true
  },
  "site/templates/articles/print.html": {
    "sha256": "f06eebb1c638fe4de44545a460a6618328d6cfe0b4f42d5feaa363b085ee7dd0",
    "matchesPrintHandoff": true
  },
  "tests/publishing-profile.test.cjs": {
    "sha256": "ae31306d2cbea3ea91a30caaef01c20333a1d5d1a7ea164020b17e16f1b6850f",
    "matchesPrintHandoff": true
  },
  "tests/publishing.test.cjs": {
    "sha256": "c8cf74de2c51dfa423e1d6a07f31dc94e744fccb6096da2d9f9acdcb172fa252",
    "matchesPrintHandoff": true
  },
  "tools/publishing/kit.cjs": {
    "sha256": "370344064b930fb0c6c801005a4152bd9f135f86ecfff1e5406490a7a80f97ec",
    "matchesPrintHandoff": true
  },
  "tools/publishing/profile.cjs": {
    "sha256": "589be280c3d8ee1d9676414bae2ef846ffa2cbffef9ee0bc04a4e068c104db55",
    "matchesPrintHandoff": true
  }
}
```

## Original evidence SHA256

```json
{
  "/tmp/r30-whitebox-color-initial-probe.json": "010dd7aa5def8e4385f7f952ba9d74c126656d9170ce2831cd3c263e71106342",
  "/tmp/r30-whitebox-color-tests.initial.raw": "c75b7215f7ea9c9a4b34f2ad2a09b89660e08a7202243f30dffaeeafcce94c33",
  "/tmp/r30-integration-correction-probe.json": "1117e2a4a6e767df623c4c1c66abda5ce1f5ad18a526ac2de859ce2e2b202081",
  "/tmp/r30-integration-correction-tests.log": "a83b4a200b50aa8c38079914f4b0be1151ca43f30e89e70563334f9862ea71dd"
}
```
