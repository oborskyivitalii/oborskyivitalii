# R21 independent review addendum — final preview/fixture integration

Reviewer: `/root/r21_independent_review`, separate non-authoring reviewer. This adds a bounded review of the final integration delta under #5 AC11–AC12 to the original R21 receipt. It does not replace or amend that receipt, whose SHA256 remains `554f30c31bdc327ef14716b11192eb246f693cbd99e9c5d9574b2973ca3aba53`.

**Result: PASS for the two current-build test expectation corrections and regenerated site preview/bundle files below. No new blocking finding in this delta. The broad mapped test run remains incomplete.**

Base is still `3e12e47953bc8c81316544b1da206a956a337307`; candidate is the explicitly dirty prepared R21. I verified that all 34 substantive/generated files pinned in the original receipt remain byte-identical to that reviewed state, including manuscript, review ZIP, exporter, rights inventory and runtime compatibility contract. The original editorial/artifact and RF01–RF03 conclusions are therefore unchanged.

## Inspected changes and checks

- `tests/release-controller.test.cjs` changes one expected result for an actual freshly built production Color variant to `issue5-review-markdown-production`. `tests/staging-regression.test.cjs` changes one expected current plain variant to `issue5-review-markdown-plain`. Both match the independently built identities in the original review. The surrounding variant, byte, metadata, rights and failure assertions remain intact; historical fixtures are preserved.
- The ten fixed-theme preview files differ from their previous versions only in generated identity values. They contain no executable scripts. The five interactive previews now include the existing canonical space/navigation corrections as well as current identities. They are refreshed source copies, not byte-identical old previews. I extracted the executable scripts from all five actual outputs and verified each against `docs/theme.js`, `space.js`, `archive.js` and `navigation.js`; each embedded route payload names the current canonical engine. The generator files and all five canonical runtime/CSS files themselves are unchanged from the base.
- Independently executed `node tools/build_site_previews.cjs --check`: PASS. This reproduces every expected fixed/interactive page, gallery and source/output manifest from current inputs without writing them.
- Independently executed `python tools/build_site_bundle.py --check`: PASS. Exact deterministic bundle payload and member/checksum manifest match. Bundle SHA256 is `f86c08603f84de0a43ca7c059191655db4f49bd990a98e95584ef5b0ef2e9ab7`.
- Inspected both checksum-manifest diffs: changes track generated source/output identities and canonical source bytes. Review-only/noindex declarations, capture disposition, generator ownership and the distinction from deployment or visual acceptance are preserved. The unchanged gallery and pre-existing historical material are not relabelled as current visual proof.
- Inspected the implementer's final focused log `/tmp/r21-integration-final.log`: 85 tests passed, no failures/cancellations/skips. This is implementer-executed evidence for the reported three-module follow-up, not my independent execution of that suite.

No author/runtime source change, rights acceptance, new article PDF, deployment, hosted performance run or device review is supplied by this addendum. The generated interactive previews contain already-current runtime bytes; generator equivalence alone is not a new browser or visual acceptance observation.

## Bounded timeout diagnosis

The batch-2 report records `ETIMEDOUT` at the unchanged 240-second limit. Its TAP contains 213 `ok` verdicts, no `not ok` verdict and no final plan/accounting. I matched those emitted names to all statically named tests in the first 18 listed modules, ending with `tests/prototype-admission.test.cjs`.

The first listed module with no emitted test result is `tests/publication-records.test.cjs`; its first test is “parallel preflight overlaps real guards in two slots and waits before package proof”. The following publishing-history/print/profile/safety modules likewise have no emitted results in that report. Because test-runner output can buffer later files, this identifies the first useful isolation target, not a proven root cause or proof that every later module failed to execute. I did not expand this review into runtime repair, change timeouts or declare the full profile green.

## Exact additional reviewed bytes

These 19 files extend the original receipt's 34-file manifest. The original receipt remains unchanged. Later verbatim ledger/receipt inclusion and deterministic RI refresh do not authorise substantive changes outside these pinned bytes.

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `tests/release-controller.test.cjs` | 62196 | `e549ebfb0d7dcfe2bf1ace49c61f5718329f30f8cb01c6369a682a460bb819e3` |
| `tests/staging-regression.test.cjs` | 48336 | `c78b98ae25baf3e8e70a159d3c113393dafae28e80d575fbf3c8bbc0901b336c` |
| `review/site-v1-20261004-v11-credits-day.html` | 139334 | `184205f155e72a11ce75f8a7fdcb8f2b9f62c5f1ea6f7638d2328f8896b9eabc` |
| `review/site-v1-20261004-v11-credits-interactive.html` | 837061 | `f40a9d60722fa6f94a128097f526a1958fd0e0762182d0f502e37e1e99b9a04a` |
| `review/site-v1-20261004-v11-credits-night.html` | 139353 | `3b6fd79aaaecd555483f7f436d8c96d840d8713fcab678bfebb971c42da2988b` |
| `review/site-v1-20261004-v11-day.html` | 182405 | `13ce1c12e3158589e56e659a36bbe041b6cde56ae8ef0e66cf0930883a9608d5` |
| `review/site-v1-20261004-v11-interactive.html` | 880188 | `38943e6d87df768fca6653942429ed95790f5983d33df92756f6fb35f2009418` |
| `review/site-v1-20261004-v11-night.html` | 182438 | `cb6cfc92e25aed124a81527e2f1f4fba20637f203044a129e994325bc31fa767` |
| `review/site-v1-20261004-v11-research-day.html` | 113092 | `75e8618ea74ca3199045b87edc31973f1d56a42a3610031f4f13d438c7b415b2` |
| `review/site-v1-20261004-v11-research-interactive.html` | 810827 | `18dac0074706c0bb812f80d5c1f104a390dfb386e21350dfce07f594899647e2` |
| `review/site-v1-20261004-v11-research-night.html` | 113113 | `0f7f077a7059294f77058c944c11daccc8b61ffbde662139dd6ea2d48dff1eb6` |
| `review/site-v1-20261004-v11-talks-day.html` | 105086 | `898adfe8414c190e23300542848638740cbd6c502e1dd3d93cf742bd80fc15b8` |
| `review/site-v1-20261004-v11-talks-interactive.html` | 802829 | `ba86404af5dd84e0cc0494e47a0a12dae2c1a26fb6500c4e506c9f527945cf0d` |
| `review/site-v1-20261004-v11-talks-night.html` | 105109 | `69f62b2ddb0dff5cbe703333e3fa58882dd0408b04fc4b5e5caa2959da1016df` |
| `review/site-v1-20261004-v11-writing-day.html` | 149255 | `8378805be2baebd515b416deacd1bcfa13e8954f6a086f79f5b0a8086144ee67` |
| `review/site-v1-20261004-v11-writing-interactive.html` | 847828 | `bc4ecb08f6f2cbf118361b340c7a84e83ccccf2a4424b802c581641cfb6c3a70` |
| `review/site-v1-20261004-v11-writing-night.html` | 149274 | `1cc1ba782901ccfda41d490156a32a7a844042d240286a5ee256c8bf9c7829c8` |
| `review/site-v1-offline-bundle-v11.json` | 8241 | `828b10220a83242346df6f48aba6e55d468028d4cd4fb04d49ee176ea7577e2b` |
| `review/site-v1-static-previews-v11.json` | 3984 | `138d4ed99d25c16c5ea09f81446f87aa85eb749fd23e431babcb6fb7af75301d` |
