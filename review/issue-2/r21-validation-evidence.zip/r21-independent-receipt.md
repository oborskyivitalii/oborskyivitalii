# R21 independent review receipt — 21 October 2026

Reviewer: `/root/r21_independent_review`, separate non-authoring reviewer subagent. I did not edit the manuscript, publisher, runtime contracts, tests or other production files. The author authorised the next revision after the R20 reviews. Owners are [article #2](https://github.com/oborskyivitalii/oborskyivitalii/issues/2), [publisher #5](https://github.com/oborskyivitalii/oborskyivitalii/issues/5) and [Draft PR79](https://github.com/oborskyivitalii/oborskyivitalii/pull/79).

**Result: the bounded R21 editorial, portable-review export and associated compatibility changes pass independent review after three corrected findings. No unresolved blocking finding remains in this reviewed scope. This is not whole-PR, hosted-performance, rights, PDF, device, merge or publication acceptance.**

## Reviewed identity and scope

Base: `3e12e47953bc8c81316544b1da206a956a337307`. Candidate: explicitly dirty prepared R21, reviewed against `git diff HEAD`, including staged and unstaged corrections. The file manifest below binds the final substantive bytes; a later commit is not presumed reviewed merely because it contains this receipt.

| Identity | Value |
| --- | --- |
| Content edition | `pmday-ai-both-sides-en-review-20261021-r21-cover02` |
| Canonical manuscript SHA256 | `8f5b878c7d37bd0e613f47bf5a5536340cd4efa9c36080b97a53b401187931ac` |
| Semantic SHA256 | `496303580c2b309121ae6ac71ff8625fae981255af4fb82296d34032478ad17a` |
| Render artifact | `68a248faffe167c077f9deee97d015a1ff64187a8f7d21a1389e309362f094e2` |
| Render manifest SHA256 | `e593873efd9b094bc7c0eb091be34c5bdd35bd0a429cf559d794e623893cecb8` |
| Delivered ZIP SHA256 | `fe1393f0de20d7ed4832d14e573401abd3e3b090dff05e07f904a0e68467516d` |
| Delivered Markdown SHA256 | `742339501c4c5342e48797db16c65ac0c7efecb6b690e74db5d75d9393a627fd` |

Read the live issue/AC and Draft PR context, root AGENTS/CONTRIBUTING and relevant acceptance, editorial, source/provenance, style, article-workflow and release/check contracts; the R21 research intake; the complete manuscript and substantive diff; the actual delivered ZIP and all four embedded images; exporter and compatibility corrections. Generated metadata/identity changes were inspected as derived integration. This does not claim a new exhaustive audit of all repository documentation or unchanged references.

## Findings and correction review

| ID | Severity and location | Evidence and implication | AC | Final disposition |
| --- | --- | --- | --- | --- |
| RF01 | Medium; `tools/publishing/ast.mjs`, `article.cjs`, `kit.cjs` | The initial unconditional second Markdown response made an admitted 1,000,000-byte source exceed the unchanged 8 MB compiler-response cap: base output 7,000,310 bytes succeeded; initial output 8,000,331 bytes failed with ENOBUFS. | #5 AC06/AC07/AC11 | Closed. Optional `preserveTables` selects the single Markdown output only for full review kits. Independently reran both modes at exactly 1 MB successfully; confirmed default compiler JSON for the real R21 equals the base compiler's output, and review mode changes only the Markdown field. The new boundary/over-limit regression covers the risk. |
| RF02 | Low; manuscript reference [36] | The initial p.21 locator confused the PDF index with printed page 22. The quoted statistic is in §4.1. | #2 AC02 | Closed. Locator is now §4.1; inspected the primary passage and rebound final source/edition/ZIP. The final portable text differs from the previously inspected text only by that locator correction. |
| RF03 | High; `tools/staging/package.cjs` licensed-runtime inventory during compatibility integration | New exact Color family IDs were initially absent from `publicationRequired`. My fresh builds selected them but all three returned false, allowing an absent rights report to bypass that check. | #5 AC10/AC11/AC12; rights preservation | Closed. All three IDs are added without changing policy. Fresh independent plain/staging/production builds now require the rights record and reject its absence before file access. Corrupted canonical/immutable bytes, stale identity and wrong edition are still rejected. Existing historical-family coverage remains. |

## Editorial and primary-source assessment

The revised text preserves the two distinct delegations, the three-part structure, six runtime assumptions, account-recovery thread, METR uncertainty and direction-of-bias caveat, and the substantial Anthropic counterevidence. The forecast and team self-report are explicitly from the same vendor. The explanation/rewrite merge preserves their different failure mechanisms. Slide 9's left and right halves are now explained without implying conventional software lacks semantic requirements.

The first pilot row now requires advance criteria for meaningful improvement, tolerable deterioration and sufficient comparable observations. Four weeks is an initial baseline, not a sample-size guarantee; uncertain evidence permits only continuing the bounded pilot. This adequately addresses the review's noise objection without inventing universal numeric tolerances. Hard prohibited-event rules remain separate and strict. The statistical argument retains severity, representative-sampling assumptions and the limits of ordinary-traffic tests; detailed Wilson figures remain in note [24].

Independently checked these originals in the changed-claim scope:

| Original | Checked scope and result |
| --- | --- |
| [Demirer, Musolff and Yang, September full text](https://www.mertdemirer.com/Papers/Demirer_Writing_vs_shipping_code.pdf) | §§4.1, 6.2 and 7.2.3–4 support the confidential Copilot/public GitHub provenance, filtered experimentation, platform-specific cohort proxies and two compatible supply/demand explanations. The modest Android observation is supported by the detailed section; removing it based only on the abstract would have lost an accurate qualification. The manuscript does not establish consumer attention as the sole mechanism. |
| [Chen and Stratton, August full text](https://fion.ac/jellyfish.pdf) | Confirmed 718 client firms, proprietary metadata, observational design and §4.1's 3.45 additional days against a 7.03-day baseline. The revised text correctly says elapsed PR submission-to-merge time, not active reviewer labour, and identifies data-partner/confidentiality-review scope. |
| [NIST §7.2.4.1](https://www.itl.nist.gov/div898/handbook/prc/section2/prc241.htm) | Explicitly describes the Wilson method. Keeping [24] is justified. |

No exhaustive re-verification of all 36 references is claimed. Compression is local, chiefly in the close and repeated framing; consistent URL/image-excluding body token counts were 3,758 for R20 and 3,754 for R21. Do not describe this as a 20–25% reduction or a materially shorter whole essay.

## Actual delivered artifact

I opened `review/issue-2/r21-review-markdown.zip`, extracted and read its actual Markdown and administrative files, and opened all four PNGs. ZIP CRCs, seven unique safe paths, declared byte counts and hashes match. The final Markdown equals the kit's `review.md`, with strict UTF-8, intact names and no `asset:` references or row-heading substitutions.

An independent pinned-GFM reparse compared the actual reading copy's complete semantic AST with the canonical source after only the declared local image-path and authored caption/credit transformations. They matched. Both genuine GFM tables remain, with three and five data rows. Administrative cover/rights notes are absent from reading captions and retained in README/instructions/provenance. The opening epigraph is not duplicated. This was actual-content inspection, not reliance on a hash manifest alone.

I also visually inspected the implementer's Chromium screenshots of the actual opening, evaluation table and pilot table. They are readable at the reported 1440-pixel viewport; the report records four loaded images, two tables and no horizontal overflow. The browser run was performed by the implementer, not independently rerun by this reviewer. This is portable-reading QA, not all-page PDF or device acceptance. The final locator-only correction does not change the reviewed layout; all four images remain identical.

### Delivered ZIP members

| Member | Bytes | SHA256 |
| --- | ---: | --- |
| `The_Sum_of_Our_Technology_R21.md` | 51119 | `742339501c4c5342e48797db16c65ac0c7efecb6b690e74db5d75d9393a627fd` |
| `images/01-cover.png` | 373126 | `843c22a1e6e16d16e824e8be74d593dea3c2f2e6e30b36504e1fff9617f82096` |
| `images/03-pmday-slide-03.png` | 115546 | `1ae890f9c23827a42e7e068327c6a6ff8738c0194cab97584fd535a6b473ef42` |
| `images/04-pmday-slide-09.png` | 188436 | `ad1479a5366464b0f5f71f863700bb1071867d6ef5f90111d0f64a46e3b807ab` |
| `images/05-pmday-slide-12.png` | 170621 | `2f13e3eabd00a27460a83169d296cfc2a8cf4b33e068d1ee22079479028c0d18` |
| `README.txt` | 2052 | `826a927a3f1340aa78672d289e41dc95efdd6eb8e191eed17fc4a65db278325c` |
| `provenance.json` | 2450 | `8413987a2d935f830d3e2c9f79532701a58c0671fc4a89b38053728aabe1bbdc` |

## Exporter and derived integration

The review rendition uses the full manuscript, preserves GFM tables, resolves ordered local figures and carries only authored reader captions/credits. The unchanged default compiler mode preserves Medium/LinkedIn fallback. Optional bounded `reviewNote` metadata is excluded from reader semantics and emitted into instructions; it remains covered by producer input identity. There is no new arbitrary reader-prose injection or increased response budget.

The cold-generated `docs/` and output lock bind changed publisher inputs. Independently compared all five renamed runtime files with the base: byte-identical. Five route pages and five immutable snapshots match their prior content after normalising only generated identities/runtime paths. No authored engine/template/scene rewrite occurred. Forty-six pre-existing media, edition and R20 bundle files were separately confirmed byte-identical to the base. Review status, pending rights and null canonical remain unchanged.

The changed producer identity required explicit equivalent-runtime Color registrations. Independently built all three variants from current docs, verified snapshot manifests and actual canonical/immutable script/style bytes, and compared them with the prior admitted deferred-media family. All five runtime hashes and behavioural/reader flags match; fingerprints are distinct and correctly reproduced:

| Variant | Final fingerprint |
| --- | --- |
| Plain | `40fdfd7664c5dd3466a20be9f9794c56d8a87a4d370f56b539312fdbf67de134` |
| Staging | `e09f54aadf05ddd71b90ebfa5f51fbc76667ff3fa1176776ea3621273d4e6558` |
| Production | `baf693a92f010b96304c2a31361bf7470ed61d9cdd060d0eaec8e19ad4a2b55d` |

Base engine is `0ae47df264d0690aa610d865f4ea8086aa2a9e1c934a44a3a1ea8e5c1e119a6f`. Registrations preserve existing families, strict selector checks, rights enforcement, scenario requirements and budgets. This demonstrates unchanged runtime compatibility, not fresh hosted performance admission. No real deployment was performed by this reviewer.

## Check evidence and acceptance limits

| Evidence | Source and disposition |
| --- | --- |
| Independent review checks | Actual ZIP/UTF-8/provenance and complete GFM comparison; image inspection; publisher validation and final kit verification; compiler boundary and base-output parity; historical preservation; generated-byte/content equivalence; three locally built Color variants with byte/identity/edition negatives and mandatory-rights checks: PASS in the bounded scope above. |
| Final editorial/publisher suite | Implementer-executed report `/tmp/r21-content-final.json`: 249/249 across 20 modules, no skips; includes final article identity and print exporter. Inspected report; not represented as my independent execution. |
| Final compatibility suite | Implementer reports 32/32 across the two changed motion/browser-evidence modules, plus cold-build check, formatting and style guard PASS. Independent source and fresh-build checks above substantiate the corrected mechanism. |
| Other local gates | Implementer reports final Basic, RI/RI-CI and associated regressions passing. No broader independent re-execution claimed. |
| Initial broad mapped PR run | FAILED/INCOMPLETE: space batch 69/69 passed, remaining batch timed out and included a transient source-identity mismatch plus the new producer's previously unregistered Color fingerprint. Do not relabel this run as green or attribute the fingerprint failure to pre-existing upstream code. Later bounded rechecks must retain their own exact scope/results. |
| Remaining mapped batches | Still in progress at receipt finalisation; execution/outcome ledger is the implementer's responsibility. This receipt does not certify their result or overall PR readiness. |

This satisfies the separate review subcondition for this R21 iteration under #2 AC01–AC02 and #5 AC06–AC07/AC11–AC12, with limited supporting export evidence for #2 AC03. Whole editorial/deck/PDF/rights/author acceptance and publication criteria remain open. No issue checkbox closure, organiser-name acceptance, cross-repository decision, external posting, merge, staging promotion or production authorisation follows from this receipt.

## Final substantive file manifest

SHA256 and byte lengths below pin the reviewed candidate. Deterministic RI/catalog/map refreshes, MEMORY/status-ledger updates and the verbatim receipt are excluded to avoid recursive receipt hashing; their exclusion does not permit changed implementation or changed editorial meaning. Existing removed runtime/snapshot paths are byte/content-equivalent predecessors of the listed generated destinations. A substantive change outside these bytes requires renewed review.

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `docs/credits.html` | 83977 | `cdf49f52bf82a705194196b636fee5c579d36b4a42c3d044fb1b98599feebfd1` |
| `docs/index.html` | 53021 | `391479d7cb89fde0c1b1ffa449732e557d91631acd87812e41e5ab01181fca42` |
| `docs/research.html` | 57708 | `2c10f70ed09724ab3caaf7605ce606e1e95b39237034fa5f2ce99fe57d04aa5e` |
| `docs/runtime/0ae47df264d0690aa610d865f4ea8086aa2a9e1c934a44a3a1ea8e5c1e119a6f/archive.js` | 19194 | `24691f49c8c0b458958de6422396af4a6ea73f2d6bffa610e4f0ca788b04f383` |
| `docs/runtime/0ae47df264d0690aa610d865f4ea8086aa2a9e1c934a44a3a1ea8e5c1e119a6f/navigation.js` | 106189 | `aa08831aa7f9daf54877588c4405fba288930831c689bfe0f1a816755ddfe2d3` |
| `docs/runtime/0ae47df264d0690aa610d865f4ea8086aa2a9e1c934a44a3a1ea8e5c1e119a6f/space.js` | 130978 | `c3a1968dad74b9289947f22c366dd3ff5f692a419cdf9ddb75c279d1ebc3fdbd` |
| `docs/runtime/0ae47df264d0690aa610d865f4ea8086aa2a9e1c934a44a3a1ea8e5c1e119a6f/styles.css` | 55214 | `a9d62982dec28d42220c4fcd6a467df2f8af07c43e5676762be74298a86c0ae7` |
| `docs/runtime/0ae47df264d0690aa610d865f4ea8086aa2a9e1c934a44a3a1ea8e5c1e119a6f/theme.js` | 3355 | `6500c6baeb508580d979b799fe8f2db5a031bc8cec6461da6c5598d28275de5a` |
| `docs/site-revision.json` | 2191 | `5294405662b681cf38fac2f2c04ff33c6a969c0160a8672d29859c800df29db2` |
| `docs/snapshots/1341432dddfb7e8df51bdb3e2e98a99f02441d3e956d45daaa5c890182380819/index.html` | 53159 | `d1691c0683dc4674d50fe82c976e7b057b58883b965005bc68af427f7f26024a` |
| `docs/snapshots/65c5ae793aaa9a479b5748dad7b456ecdf2e754418a4b8937b1925352a20ea5d/credits.html` | 84067 | `e0b4820e15e4a42eff2ef23e10a313afd25107267f1b6eb3d18206c85820db20` |
| `docs/snapshots/c795e5ca7cac0e4082933b8beebc17f8f8e6c92a340ce8866738f7a4f0230a54/research.html` | 57804 | `f94f2036dbb8865f0dc048f2c12390924508c9a142b3e4d25d8102ef24e5d7a4` |
| `docs/snapshots/eefef66b885f028dd63917c984bc0031040957a32f7b6f3980525f90ed1caa8b/writing.html` | 94834 | `8f61039844a8c5a1acd68112c233d14ee0a53579482377481f1048dd6de6fee0` |
| `docs/snapshots/fd9c3ee9c9014836fe114f82c168490c29803a822573e4e46cdd0c5942a5806d/talks.html` | 49791 | `a5f4ad9e39960c6245c6fbc270700f3ce025b1148afc0308946643dfa7d00435` |
| `docs/talks.html` | 49689 | `b265e48cc6f5991fa8aa90f537592900c679f09f78f31ebce664ec178e1b2461` |
| `docs/writing.html` | 94744 | `bfbced5c618664213e4f5934982fccd689ec168eb8e7f16e9150cf5cd7e1d4b1` |
| `drafts/pmday-article-draft.en.md` | 46489 | `56202fef129055ed214b018c25fe6cd7419198fe028824f9f1483511ef91a7e7` |
| `guides/ARTICLE-WORKFLOW.md` | 16274 | `6f045e79c0c22342c8de26e9c77744082a005d59f3c51db3aa06d4c84b0c0aca` |
| `review/issue-2/r21-review-markdown.zip` | 833747 | `fe1393f0de20d7ed4832d14e573401abd3e3b090dff05e07f904a0e68467516d` |
| `site/output-lock.json` | 11220 | `57699dbbf8942380a3cd00f4d2ce45ab7893cdb9f9079ec09fbaac7350ef6239` |
| `site/publications/pmday-ai-both-sides/blueprint.md` | 6125 | `e9ad69fe6df062da33eba6085ff377fee2ed39e2ecfff37d7263716d7639c4bf` |
| `site/publications/pmday-ai-both-sides/editions/pmday-ai-both-sides-en-review-20261021-r21-cover02.json` | 493 | `95d57dd41e415274a050b05c336c9fe6193e1f32cf3a293094320518d75295d1` |
| `site/publications/pmday-ai-both-sides/manuscript.en.md` | 48221 | `8f5b878c7d37bd0e613f47bf5a5536340cd4efa9c36080b97a53b401187931ac` |
| `site/publications/pmday-ai-both-sides/profile.json` | 2417 | `7e54bec6dd5487e97b292ba9f72d25a5826fc782901cb4847d5c7fc024c11ed8` |
| `site/publications/pmday-ai-both-sides/publication.json` | 10895 | `c0e24ca833fbeadeeeed2bfe7b6b60bac8a33505d1875c9f943557851f9932c8` |
| `tests/article-browser-evidence.test.cjs` | 40704 | `5bd0f097f3c42f7868dfa0fe8d704dec3f9ee59df2c59546c000732a73266f97` |
| `tests/article-media.test.cjs` | 15721 | `27a39db9de6bb9e764b437135f0ea618f51bf2701b1fe1a32e14ca1760c6913f` |
| `tests/color-motion-contract.test.cjs` | 38677 | `d5902a3377aaab4544f1d1a814cbefadac90afb309c42f87f2832747d0e06fb9` |
| `tests/publishing.test.cjs` | 41951 | `dd2928e41ec3f7833c52b32ad768d772f9769787f6e2b2c489aaee76ee661fd2` |
| `tools/publishing/article.cjs` | 18661 | `2387d26c1ec608586c7b124f4a7971b4b9195b83f79dfbe06731700eee04b5c1` |
| `tools/publishing/ast.mjs` | 11158 | `b7ca7eadfb43bbe8eac8fd0b1684452dea58755afd55616674d6b49db3bd8155` |
| `tools/publishing/kit.cjs` | 18441 | `e0d9c6576987eefaa0b3523f66bd63ab67fa308d652909aee2f95a1c6a85509d` |
| `tools/quality/color-motion-contract.cjs` | 60893 | `36dc7ad9b799623470c4e2db64319d735c6a24e5fd113227d5f4b7299f221bd2` |
| `tools/staging/package.cjs` | 18026 | `15088194e9f8727edb235ceea4b0bb454aae835b3db2963acaa5f18f4d4f72dd` |

No further implementation task is requested by this reviewer. Preserve this receipt verbatim in the owning review record; append final execution results separately with their source/run limits.
