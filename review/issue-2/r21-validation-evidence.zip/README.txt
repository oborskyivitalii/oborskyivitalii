R21 local validation evidence, 21 October 2026

Owner: review/issue-2/2026-10-21-r21-review.md in PR79.
Base: 3e12e47953bc8c81316544b1da206a956a337307; reviewed dirty R21 candidate.
The original independent receipt and addendum pin substantive source bytes.

Final bounded results: publisher 15/15; editorial/export 249/249; compatibility
32/32; fixture/preview/source follow-up 85/85; Basic 16+10; bounded style,
configured formatting and cold-generated source checks pass. Overlapping suites
are not additive. Later RI/bookkeeping results are recorded in the owner ledger.

Failed/incomplete history is deliberately included: initial broad mapped run
failed/timed out; recovery batch 1 had a stale current-ID expectation; recovery
batch 3 had that class of mismatch plus stale generated previews. The final
focused runs resolve those specific failures. Recovery batch 2 hit its unchanged
240-second timeout with 213 passing emitted verdicts and no final accounting.
That batch and the full mapped profile remain INCOMPLETE, not PASS.

No hosted performance, all-device, article-PDF, rights, merge, staging or external
publication acceptance is represented. Screenshots concern the actual portable
R21 reading copy at the reported viewport. Absolute temporary paths in raw reports
identify the local execution context; use this archive for preserved report bytes.
