R20 author-review copy, 21 October 2026.

Extract the entire ZIP and open The_Sum_of_Our_Technology_R20.md in a UTF-8 Markdown viewer. Keep images/ beside it. The four figures are local PNG files, so they do not require asset: support. The existing presentation link remains an external source link.

The canonical editing owner is site/publications/pmday-ai-both-sides/manuscript.en.md in PR79 of oborskyivitalii/oborskyivitalii. This generated copy includes declared captions and credits. Its exact source/semantic identity and file hashes are in provenance.json. It is not a published article, new PDF or approved platform post.
