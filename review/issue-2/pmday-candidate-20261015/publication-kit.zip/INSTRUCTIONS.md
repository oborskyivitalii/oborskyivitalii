# AI Changes Both Sides of Software Engineering — distribution review candidate

Full content edition: pmday-ai-both-sides-en-review-20261015
Source provenance: working-tree-review
Canonical: pending: verify the accepted live site page first

Review wording, heading sources, table row labels, captions and credits against the manuscript.
Open <platform>-copy-ready.html, select the article body, and paste into the native editor.
Copy-ready images preserve reviewer bytes; native-editor image transfer must be checked.

Medium: upload each ordered image below manually at its matching figure position.
Do not assume pasted embedded images survive. Recheck caption, alt text, credit and source link.
Use the canonical only after accepted live-site verification; otherwise leave publication pending.
LinkedIn: inspect the selected adaptation or equivalent rendition, including every heading source.
Record actual native-editor changes and observed publication as a separate event.

images/01-cover.png — We can delegate more work. We still have to own the consequences. (AI-generated editorial illustration directed for this article; built-in ImageGen, 15 October 2026.)
images/02-presentation-cover.png — PMDay presentation, v35 review edition, 15 slides. Recording in Ukrainian. (Vitalii Oborskyi. Preview rendered from the pinned v35 PDF; presentation credits remain in the source deck.)
images/03-two-shifts.png — Figure 1. How software is built and what it depends on at runtime are independent questions. (Original diagram for this article, based on the PMDay HOW/WHAT distinction.)
images/04-delivery-queue.png — Figure 2. Local acceleration can increase unfinished work. Synthetic capacities; downstream capacity is unchanged and all generated work is admitted. (Original explanatory diagram; no measured AI productivity result is represented.)
images/05-runtime-control.png — Figure 3. Control before and after consequence. Semantic checking is fallible; permissions constrain authority. Later intervention cannot necessarily reverse earlier consequences. (Original diagram for this article, informed by PMDay slide 12 and Uncertainty Architecture.)

Rights: Article by Vitalii Oborskyi. Original explanatory diagrams and AI-generated editorial cover prepared for this edition. Publication-specific rights review remains pending. Linked sources and the presentation retain their own notices and credits.
