# #188 Exploratory and Interaction QA correction

**Affected recheck passed.** The original Setext and fence-info counterexamples now refuse, allowed fence examples still pass, and the raw-HTML automation limit is stated precisely. The unchanged handoff and lifecycle remain usable. AC04 native checks, protected admission and merge remain pending separately.

## Source and execution

- Same independent nonauthor reviewer `/root/grammar188_exploratory`. The first findings and operator walkthrough are preserved in `grammar188-exploratory.md`. This is an affected correction recheck with exposure to the Requirements scope clarification only after reporting the first findings. No authored fixes/tests, external writes, or delegated execution. Provider internals were not observed.
- Exact clean candidate `69b6e7f7aa85bfbf93bb969a648ea22a71d7e8ab`, tree `5b9c58bb6a2ad5d0baacbfde1afc4d63bb142939`, parent `eb49a288138c006db3985548158c32f34b0ffca6`, target base `0394f52c82a34c304c123aeaee023c5ec44a85b0`. Correction delta SHA-256 `113b754e053372bd1697b84c625f50791047e70944e0006eeb7b9ee0203c5c25` independently matched `git diff --binary HEAD^ HEAD`. Manifest `a01edd58ba1d5bda8f6ff99b92b706d16a712219b76575aa8f0df9e5a7e3bc54`; all nine paths passed `sha256sum -c`. Full base-to-head `git diff --check` passed.
- Common and role prompt blobs remained `26b5d554da6027ff6aff850c2ab6bacb93b9ee38` and `8b07e0a4c59c81b4efc8806c1043c631775eed32`. Original intake SHA-256 `53eb844ab52e59fbeaffdcbf96830c62117fd3b600c65cea880fffae97b75739`.
- Affected charter: nine in-memory guard probes, the single existing continuity regression, source and scope readback, and live PR/candidate-run lookup. The first pass's independent GFM oracle remains applicable to the unchanged counterexample bytes.

## Expected and observed

The test input is the actual candidate MEMORY plus one suffix per case. Each result below matched its expectation.

| Probe | Expected and observed |
| --- | --- |
| `Snapshot` then eight hyphens, or `History` then seven hyphens | Both refused with `Setext underline markers are unsupported in continuity sections: MEMORY.md`. |
| Backtick fence with `<!--` as info string, or tilde fence with `md <!--` as info string | Both refused with `HTML comment markers are unsupported in continuity sections: MEMORY.md`. |
| Column-one Markdown fence containing a Setext marker and a literal comment marker in its body | Passed. |
| Standalone `***` | Passed as the documented horizontal rule. |
| Quoted raw `<pre>` block | Passed within the documented automated limit. `CONTRIBUTING.md:326–328` retains the authoring prohibition and now defines the guard as line-leading through three leading spaces. The producer docstring likewise says leading openers. No requirement claims automated container parsing. |
| Raw `<pre>` opener with two leading spaces | Refused with `Raw HTML blocks are unsupported in continuity sections: MEMORY.md`. |
| Actual tracked handoff with no fixture | Passed. |

Existing regression `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_repository_intelligence.py -k test_memory_and_agent_bounds_and_required_sections_fail` ran one test in 0.684s, OK. The added inputs stay in the maintained Navigation method and existing AC01/AC04 CONTINUITY selector. No additional campaign was needed for the affected exploration.

## Handoff and gate status

MEMORY has identical Git blob `a1aad2951e8ec481bc4eeb0ba3f8448a750aa9c4` on both candidates. The delivery guide and dispatch workflow are unchanged from the first walkthrough. The lifecycle trigger/replacement passage is unchanged in meaning. At fresh readback [PR #192](https://github.com/oborskyivitalii/oborskyivitalii/pull/192) remained open and Draft at `eb49a288` against `0394f52c`, with no PR workflow runs associated with the local correction SHA. The prior exact-head Source, Navigation and Owning acceptance successes and the [conditional admission failure](https://github.com/oborskyivitalii/oborskyivitalii/actions/runs/43026323767/job/130541880446) remain evidence about that published predecessor. AC02 handoff and AC03 lifecycle exploratory gates remain satisfied. After the publish/Ready boundary use only matching-current-head CI and the protected owner dispatch. Hosted interaction and device work are inapplicable to this repository-only source and operator workflow.
