# Issue #188 — White-box QA, third source-bound judgment

**Verdict: changes required.** WB-01 and WB-02 now reproduce their expected refusals. WB-03 still permits all five required sections to be hidden in a valid column-one fence. AC01 and the White-box gate for AC04 remain open.

## Reviewed source

- Reviewer `/root/memory_whitebox`, distinct nonauthor White-box role and affected correction continuation. Reused my preserved first and second results only (SHA-256 `7a0a3618fa211afe70a54abe8cde7ff28da0a81b8c7de92872ea808c2f2dd799` and `0fd34e52c84ce50512e44c65d3dae2ef0a3ea225f990b9d78a721d68f1c628b2`). No fresh first-context claim, peer notes, or archive verdicts.
- [Issue #188](https://github.com/oborskyivitalii/oborskyivitalii/issues/188), base `0394f52c82a34c304c123aeaee023c5ec44a85b0`, predecessor `fe014c571f7c7bb8d1e0ee03307fc7c8f1dcae25`, local commit `1b8f9580fef680743268f202e7c0340ba6d5931e`, tree `00ce746dc55ccf062cd2db1eeba480afbb1768ee`. No assertion that the local commit was published. All 15 packet-manifest records verified. Manifest SHA-256 `57fee6eb5af54ae1ff2b6975dcb4272abd5a25f767ef8ab8021f623374bf51be`, full diff SHA-256 `341c3b6b514835cf6164b95380b87b3660478c927e8856c5bcd3784cc0733679`. Full base-to-candidate diff passed git diff --check.
- Common and role prompts retain Git blobs `26b5d554da6027ff6aff850c2ab6bacb93b9ee38` and `f3d5e777711d05fa844052a0c49339eb577a06d1`. Inspected source and test delta, canonical continuity protocol, real config and unchanged policy selectors, plus affected security ledgers and deterministic admission tests.
- Python 3.12.14 and Node 24.22.1 in a separate clean detached checkout for exact-source checks. Intentional mutations used another export of the same tree. Independent oracle was Pandoc 3.1.11.1 CommonMark AST, with YAML metadata enabled for front matter. No canonical checkout or external writes.

## WB-03 — Blocking, AC01 and AC04

The raw substring search at `tools/repository_intelligence.py:142–163` interprets a Markdown-escaped less-than sign as opening an HTML comment. On following lines, `115–131` skips every fence, nested-fence and raw-HTML opener while the apparent comment is active. Consequently a literal escaped comment line can mask a valid column-one fence opening. The apparent comment ends at a literal terminator that is already inside the Markdown code block. The RI projection then exposes all five headings as ordinary lines and the continuity guard accepts them.

Prepend these three lines to the exact candidate MEMORY and append a normal closing fence at column one.

~~~~text
\<!--
```md
-->
~~~~

The independent CommonMark AST reports **zero heading nodes**. On the exported exact tree the normal RI CLI reports **build exit 0** with generated views and **verify exit 0** with the views fresh. A tilde-fence variant and a raw `<pre>` opener instead of the fence independently yield the same false acceptance. All three use literal Markdown and remain within both size caps. The backtick and tilde cases meet the new column-one fence convention, so nested-fence restrictions do not address the fault.

Treatment belongs in the continuity parser and existing regression. Respect Markdown escape semantics before changing comment state, and ensure comment state cannot mask an actual supported block boundary. A conservative refusal of ambiguous inline-to-block transitions would require an explicit bounded syntax decision and should preserve ordinary comments and examples. Keep the existing `NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail` in the permanent RI suite, the navigation workflow job and the issue-188 CONTINUITY owning selector. Record the independent rendered-heading expectation and check this failure with an existing plain positive case. Revalidate exact Bandit source and line bindings and the public checksum only if producer bytes change.

## Independent affected probes

| Scenario | Candidate CLI and parser observation |
| --- | --- |
| WB-01, normal raw HTML wrapper and standalone comment-prefix Snapshot text | Both build exit 1. Raw HTML or missing heading diagnostic as appropriate. Parser found no Snapshot. |
| WB-02, BOM-prefixed raw pre and top-level fence | Both build exit 1. Parser found zero headings. |
| BOM plus genuine first Snapshot | Build exit 0. Parser found all genuine headings. |
| BOM plus front matter, and embedded U+2028 heading text | Build exit 1 with appropriate front matter/missing section diagnostic. Parser found no Snapshot. |
| List-nested fence then a top-level fence, and quote-nested fence | Build exit 1 with the documented column-one diagnostic. |
| Actual MEMORY, top-level fenced example alongside valid headings, ordinary HTML comment, and ordinary indented code sample | Build exit 0 with genuine Snapshot. |
| BOM-inclusive multibyte CRLF boundary | Original 8,192 bytes pass. Original 8,193 bytes fail. Both seven lines and both contain the genuine sections. |
| WB-03, escaped comment followed by top-level backtick/tilde fence or raw HTML | All three build and verify exit 0, independently parsed zero headings. |

Legacy Markdown callers still use the default mode, and both new decisions are guarded by plain mode. Existing full RI suite passed. Previous source-bound cross-version comparison (65 Markdown files outside review and six synthetic cases) is reused for the unchanged default-mode operations.

## Executed source checks and limits

- `python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'` passed 40/40 in 9.059 seconds. The detached candidate remained clean. Real configured limits and all five headings are asserted by the selected continuity regression.
- `python3 tools/check_ri_ci.py verify` passed 17 checks/19 layers, digest `2bffbd0bc232a9dbfc1e48e55fec8c5debe591baa8c32ae8582b7b5261ca649b`; live GitHub state explicitly unverified. `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify` passed on the unmodified candidate.
- `python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-188.json --report <external temp> --require-clean --expected-source 1b8f9580fef680743268f202e7c0340ba6d5931e` passed five selectors, AC01–AC04 automated-pass and seven external gates pending. Source dirty false, candidate tree exact, RI source digest `8a75ba20df404c05f341ac231c25a1f863d44e8d985170b9d7e24a2edf954a33`. Read-only Git alternates provided the immutable style baseline. Report `/tmp/issue-188-whitebox-r3-owning.FwPk0a`, SHA-256 `5d3150acd8909e1a362cff406148688a5c467c3d806132be93c07d53a1718a3c`.
- `node --test --test-name-pattern='^(Bandit admission|closed secret ledgers admit only exact)' tests/quality-sources.test.cjs` passed 5/5. Cases protect exact source/rule/line and coverage, new/missing/duplicated findings, expiry/byte drift/shift/symlink, scanner errors or malformed reports, and exact path/rule/hash matching. Separately recomputed the three producer Bandit source and finding-line digests, verified unchanged subprocess import/call AST against the base, retained all other policy rows/metadata, and recomputed the one appended checksum review ID as SHA-1 of the public SHA-256 text for exactly the Bandit policy path and Hex High Entropy rule. This is deterministic guard coverage and metadata verification. No actual scanner campaign was executed in this role.
- Full CLI probe source `/tmp/issue-188-whitebox-r3-probe.py`, SHA-256 `e38d59368bd1569033e26873fe6852594ea539ba50676610d5c97011342651a2`. Raw output `/tmp/issue-188-whitebox-r3-probe.log`, SHA-256 `503502585e349c2399b9f5686949d67621e742d9001e59d153d1e5d8fe7b1764`. Mutations in the exported fixture are intentional and are not source-bound acceptance results.

No measured branch coverage, native Actions, trusted route admission, live PR/production facts, browser or merge evidence was established by this review.
