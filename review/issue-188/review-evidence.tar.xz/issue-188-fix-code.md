# Issue #188 / PR #192 — independent Code correction review

**Initial verdict: BLOCK.** The candidate rejects a documented inline code span in paired emphasis, accepts an active raw tag in the same context, and misclassifies standalone indented code and nested fences around ordered lists. AC01 and the Code gate of AC04 remain open. The correction to the owning-issue link is present. No implementation or acceptance change was made by this reviewer.

## Reviewed source

- Candidate `067f31651649b5393fa71b1b3dc172c52601b0c3`, tree `b912049fd533609377c24c9590b896987066426b`, clean native checkout before and after review. Compared predecessor `5c870fc447ef1ba4cebbfef3cef53834a0af8e2d` and full base `0394f52c82a34c304c123aeaee023c5ec44a85b0`.
- Packet manifest SHA-256 `e704f603691c90f7ec369a3dd3cd591d23bb43daa5386c54a7d7d875d0c905fd`. All 15 listed files verified. Supplied diff SHA-256 `c730c8260dc830bc6a3f91dfcf1f798a6087138c9d4a9de6a9315006a9d46436`.
- Common contract `agents/reviewers/README.md`, SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`. Role prompt `agents/reviewers/code-review.md`, SHA-256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Read the issue intake, AGENTS, CONTRIBUTING, CODE-STYLE, repository and RI entry points, candidate continuity code/tests, owner config/policy, and generated identity/mapping changes. Compared scoped source and listed review artifacts by path/identity. Did not inspect prior verdicts, review archives, parent notes, or peer outputs. Local remote-tracking ref matched the supplied predecessor. Hosted runs, live issue history, merge/admission and provider-internal context were outside this read-only Code review.

## Blocking findings

1. **P2 — A backslash escape changes the code-span delimiter boundary** (`tools/repository_intelligence.py:94–108`, used at lines 153–158). The masking alternation consumes `\` and the first backtick, but its code-span alternative forbids starting at the following backtick because it checks the preceding raw character. The parser may then treat a genuine closing delimiter as an opening delimiter. With the five canonical headings present, `check_continuity` and a local `markdown-it` CommonMark render show opposite outcomes:

   ```markdown
   <em>Record \``<details>`</em>
   <em>Record \``literal`<details>`</em>
   ```

   The first renders a literal backtick followed by a code span containing `&lt;details&gt;`. The guard raises `Raw HTML blocks are unsupported in continuity sections`. The second renders a literal backtick, `<code>literal</code>`, an active `<details>` tag and a literal backtick. The guard succeeds because it masks the active tag with the wrongly paired delimiters. The candidate expressly supports inline code in this paired-emphasis position and tests that a raw nested tag must be refused. Existing new tests cover unequal delimiter lengths but miss escape adjacency. AC01/AC04 and CS05/CS08. Recognize escaped punctuation and delimiter runs in sequence, preserve the refusal, and cover both outcomes through the existing continuity test.

2. **P2 — Fence classification loses list indentation and continuation** (`tools/repository_intelligence.py:135–145`). Any preceding nonindented list marker sets the same boolean regardless of how many columns the item requires. An unindented text line then clears that state even when Markdown treats it as a lazy paragraph continuation. With the canonical headings present, append the following after a blank line. The four-space fence-shaped text is rendered as a standalone indented code block after an ordered list whose item requires five spaces, but the guard rejects it as a misplaced fence.

   ```text
   100. Example

       ```md
       ## Snapshot
       ```
   ```

   Appending the following instead renders a five-space fenced code block inside the same list item, after a lazy paragraph continuation, but the guard succeeds. This bypasses the maintained column-one fence restriction. Confirmed both render shapes using the same local CommonMark parser.

   ```text
   100. Example
   lazy continuation

        ```md
        ## Snapshot
        ```
   ```

   The candidate tests standalone code only without a preceding list, and a nested fence only without an intervening continuation. AC01/AC04 and CS05/CS08. Classify these adjacent cases consistently within the bounded syntax and add the paired pass/refusal regression cases. Preserve the legacy `plain=False` path.

## Other review results

- The issue URL in `MEMORY.md:18` points to the owning issue directly and removes the suspect status fragment. The file routes to exact predecessor CI and distinguishes previous observations from next actions. I verified the change as source and left live handoff/admission observations to the applicable reviewers.
- The maintained guard still requires each literal heading and rejects repeated canonical top-level ATX headings, including optional indentation and closing hashes. Tests distinguish active duplicates from literals in ordinary top-level examples. Existing line and byte boundary, multibyte overage, missing heading and comment/front-matter refusal checks remain in the existing suite and acceptance mapping. The regex targets the repository's literal canonical H2 contract.
- Legacy `active_markdown(..., plain=False)` has the same observed output or error as the predecessor across 529 tracked Markdown files, excluding the prior-review artifact. Artifact-title, indexed-heading and link consumers still call that mode. The implementation retains the existing source owner and uses the fixed size cap ahead of the stricter processing. The protocol remains in CONTRIBUTING and the same tests/CI paths remain the owners. This addresses CS01/04/07/09 ownership, limits and guard boundaries; CS05/08 and AC04 fail on the uncovered behavior above. The supplied AC/guard mapping is in the existing owner for CS10. No release decision is supplied by this review.
- `python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'` passed 40/40. RI `verify` reported fresh, `check_ri_ci.py verify` passed 17 checks across 19 layers and explicitly did not verify live GitHub state, `check_code_style.py` passed within its reported scope, and `git diff --check 0394f52 HEAD` passed. The four counterexamples above were independently run against the real continuity function in memory and checked against the local `markdown-it` CommonMark renderer.
- **Scanner rebinding verified for the changed owner.** Recomputed candidate and predecessor whole-source and line SHA-256 values for the three exact Bandit rows. Raw report `bbeebe207b59abe21ec5a73079714e22f7bd6a4fb9bbab10053661ccdfc6158b` has zero scanner errors and three findings for this source: B404 at 17 (unchanged), B607 and B603 at 260 (from 242). The raw code excerpts, finding types, names, severities, and confidences match the candidate policy. The import and call ASTs and hashed finding lines match the predecessor. Outside the three owner rows all policy entries and policy metadata are identical; within those rows only whole-source digest and the two line numbers changed. The entropy report `d2b6b6edd6f71077b4ad197b2e9a435e00d8d1925403fe726b9df90def8610c6` contains 32 hashed findings for the policy file. Recomputed all 32 against exact policy lines. The changed scanner identity at line 408 is the SHA-1 of the actual candidate Python source SHA-256 and matches the sole ID replacement in the checksum ledger byte-for-byte. This comparison covers the supplied changed-owner reports; it does not count as complete repository or hosted security execution. A corrected producer will require fresh exact-source rebinding and affected review.
