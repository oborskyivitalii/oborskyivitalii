# #188 / PR #192 independent Code / Artifact correction recheck

Verdict **changes required**. The ordinary inline raw HTML heading finding is fixed in the ordinary prose path. The same rendered-heading invariant still fails through the retained paired raw emphasis exception. AC01 and the AC04 Code gate remain open.

## Inspected source

Clean detached HEAD `5ee8503d6cc5042b56a9eaea1336cb287bfd145e`, tree `7923c301e7c71957caff6df996481dc4e89f0178`, predecessor `7a0552e081a8430e58047c1a46c35c0a3e79cacb`, protected base `0394f52c82a34c304c123aeaee023c5ec44a85b0`. Cumulative correction diff SHA-256 `5c3021bc632d80af6594c297d598c5518611d938fefcc605f48e0c47b3d1a4b9` independently reproduced from Git. Manifest SHA-256 `f9c15e470fd5b20d8f934ab6c873545e2f3f7bd46d9a46b06dd9bc1c6c6d2ecd`, all nine entries verified. Common prompt blob `26b5d554da6027ff6aff850c2ab6bacb93b9ee38`, Code prompt blob `2363340a1eaae62fdbd3ab070fda5c6436ec8124`. Intake SHA-256 `53eb844ab52e59fbeaffdcbf96830c62117fd3b600c65cea880fffae97b75739`. Preserved the earlier first result at `ff188-code.md`, SHA-256 `3fbb47d8ee3b308fad73468e268b3d50cb6ea893d120220d59c669bc02d316a9`. This is the same reviewer continuing with the correction packet after first result preservation, not a new clean-context launch. No peer verdicts used.

## Blocking finding

**Major — a preceding multiline code span can expose a raw duplicate H2 in the emphasis exception. AC01, AC04.** On a synthetic valid five-section handoff, append a blank line and this exact two-line text:

~~~markdown
Before `open
<em>`<h2>Snapshot</h2>`</em>
~~~

The candidate's exact `check_continuity` function accepted the fixture. GitHub GFM's stateless Markdown endpoint accepted a synthetic control with one `## Snapshot` followed by the two lines and emitted a second active H2:

~~~html
<h2>Snapshot</h2>
<p>Before <code class="notranslate">open &lt;em&gt;</code></p><h2>Snapshot</h2>`<p></p>
~~~

`tools/repository_intelligence.py:94–111` replaces what it considers same-line code spans before deciding whether the raw tags are only paired emphasis. Lines 143–151 grant this exception based on a single source line. GFM instead starts the code span on the preceding line and closes it on the first backtick of the apparent emphasis line. That leaves `<h2>Snapshot</h2>` active. This produces the same excess active heading as the earlier ordinary prose and bare-link cases. A bounded grammar that reserves raw tag syntax uniformly outside fenced examples would avoid approximating paragraph-level tokenization. Retain native `*`/`**` Markdown emphasis and the documented fence/entity paths. The existing `MEMORY.md` uses no paired raw emphasis. If retaining the exception, validate its actual paragraph scope and keep the repro as a negative case in the existing suite.

## Verified effects and limits

- Exact local guard rejected `See <h2>Snapshot</h2> in the checkpoint.` in ordinary prose and accepted escaped `&lt;` examples, a regular angle-delimited relative Markdown link, and fenced raw examples. The synthetic GitHub GFM call separately preserved the entity and fenced examples as text and rendered the relative link.
- All 40 RI unit tests passed. Exact RI/CI coupling passed 17 checks over 19 layers with source digest `93f53c09828df1c6a9dc50c7de6220c2ada7558a7c595d82ccf0273e89db4c6d`, bounded style guard passed for 165 files, and `git diff --check` passed. These checks do not establish rendered Markdown correctness, native CI, admission or merge.
- Recomputed B404 line 17 and B607/B603 line 260 source SHA-256 and exact untrimmed line hashes. All three bindings match. The ledger binds the detect-secrets exact ID for the new RI producer SHA-256. No scanner rule or expiration expansion. Full security/advisory suites were outside this recheck.
- The raw-tag restriction retains the original owner and scoped `plain=True` path. No new dependency, route, validator or website files. The tests exercise the named acceptance selector but do not yet cover the paragraph-crossing failure. No local repository content was transmitted for the renderer check. No repo or external persistent writes.
