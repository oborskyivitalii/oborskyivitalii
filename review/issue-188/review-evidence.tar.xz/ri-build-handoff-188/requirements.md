# Requirements & Acceptance — independent candidate-delta review

Verdict: AC01's local requirements correction passes, and the state-first
resumption route satisfies the documented state behavior. The direct handoff
anchor is real and exact-source for the previous published head. AC02 remains
pending for the corrected source until the anchor is refreshed with verified
published results and independently rewalked. AC04 remains open.

## Source and scope

- #188 intake and stable ACs `cebc093fab86eb0de972b6a946471047d820ca46f6745f1fe4e52a214a34391d`. Inspected the original snapshot and read the live issue body. No AC was renumbered or weakened by the candidate policy.
- Protected base `0394f52c82a34c304c123aeaee023c5ec44a85b0`; previous head `04a7bc7a9609bda50b443b4750f3db4404ac7d9f`; local candidate `bb826f40f1645077d95c655422dcecadcd186184`, tree `9fefb65dfba9ad549ad0f66050a6ac77dd72d309`.
- Candidate delta SHA-256 `3c2760a1d8f27a4a7ea7228154871ed5861925a71bdd7dd1591dfff406881d27` reproduced from Git. Sorted path-byte manifest `fefa3497ba0519b2b3299374eec0313560818971f2a36c704a53ef1c9b6ad393` matches the candidate Git blobs.
- Common reviewer contract SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. Read root rules, contributing/continuity, acceptance, RI, code-style and the trusted delivery route relevant to this correction.
- Targeted review of the three requested outcomes and affected gates. I did not judge peer roles, the prior chronological preimplementation-review receipt, live admission of the unpublished candidate, or the protected merge. Provider model/context internals were not observed.

## Findings

**Acceptance blocker for AC02 until publication and refresh** — `MEMORY.md:18`
links [the dated checkpoint](https://github.com/oborskyivitalii/oborskyivitalii/pull/192#issuecomment-6805331637).
The readback records the full previous head, three check results and a missing
admission result. GitHub's commit-keyed workflow results independently confirm
the three linked successes and the failed admission run. Admission job
`130602683307` logs confirm the full previous head and `missing staging admission`.
The checkpoint identifies the pending correction, which is enough to reconstruct
the currently published Draft's stopping point. It is not evidence that the local
correction is the published source or that its checks ran there. The live issue
still displays AC01/AC02 checked while the dated checkpoint records both reopened,
so the checkboxes do not supply the missing candidate evidence. After publishing
and obtaining the applicable native results, refresh the stable comment with the
exact corrected SHA, completed step, check links/results, remaining ACs and next
concrete action. Read back the anchor and reconcile issue checkboxes against
current-source evidence and the independent handoff gate.

No blocking local implementation finding for the tested AC01 correction. The
same plain Markdown view controls sections and inventory title for MEMORY, so
inventory cannot reparse those two line boundaries differently. The full-build
fixtures cover BOM before fence, BOM before title and U+2028 within a fence,
retaining the expected inventory title and UTF-8 byte digest. The previous
positive/negative limit and heading checks remain in the maintained test.
The 8,192-byte inclusive cap remains proportionate to the accepted bounded
handoff and uses UTF-8 bytes. This delta judgment does not establish when the
prior preimplementation decision was made.

## Criteria and exact evidence

| AC | Evidence and result | Outstanding gate |
| --- | --- | --- |
| AC01 | Candidate's owning `CONTINUITY` and `INVENTORY` passed. Pandoc 3.1.11.1 GFM independently returned one literal code block, title `Memory` and the five level-two headings for each of the three exact fixture shapes. | Candidate Requirements judgment supports the correction. Native final-source evidence and applicable independent checks belong to the orchestrator. |
| AC02 | `INVENTORY` passed. `MEMORY.md:23–27` branches on live PR state first: open proceeds through correction/review/admission, closed-unmerged stops at the issue, merged goes directly to actual merge-commit/tree/public-byte verification and refresh. Live PR #192 was open/Draft at `04a7bc7`, base `0394f52`; merged/closed paths were traced from source only. | Refresh exact-source dated anchor and obtain Exploratory HANDOFF on the corrected published source. |
| AC03 | `AGENT-ROUTE` and `COUPLING` passed. The candidate preserves the replacement triggers and decision/action separation in the existing protocol; no competing handoff mechanism added. | Required Code/Exploratory lifecycle observations are distinct gates. |
| AC04 | `STYLE`, `COUPLING`, `INVENTORY` and `CONTINUITY` passed locally. Current delta records style/allocation mapping and preserves the applicable control-reviewed route. | Exact published-source four-role/correction evidence, native checks and selected trusted lane, owner admission and actual protected merge remain external. No production claim. |

Exact-source local run:
`python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-188.json --report /tmp/issue-188-req-final-bb826f4.json --require-clean --expected-source bb826f40f1645077d95c655422dcecadcd186184`.
Five checks passed; all seven external gates stayed pending in the automated
report, with closure false. RI source digest
`4aabbd372527a0dd29e69065684d3ce15d647241295984d826f0ca8a05a2baa3`.
Separate RI verify passed, including in-memory regeneration, and coupling
verify passed with 17 checks/19 layers. Protected-base candidate diff
passed `git diff --check`. The local checkout was clean. No old-head check
was counted as corrected-source evidence.
