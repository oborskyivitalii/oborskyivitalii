# White-box QA for #188 / PR #192

**Verdict: pass for the targeted RI correction.** No blocking finding for the AC01 fence/title/identity path or its AC04 test allocation. The previously failing full builds now accept the valid examples, and the previous inventory title fallback is corrected. The retained guard still rejects out-of-contract input. This is the first result from `/root/whitebox_final` on this candidate.

## Source and scope

- Protected base `0394f52c82a34c304c123aeaee023c5ec44a85b0`, preceding PR head `04a7bc7a9609bda50b443b4750f3db4404ac7d9f`.
- Candidate `bb826f40f1645077d95c655422dcecadcd186184`, tree `9fefb65dfba9ad549ad0f66050a6ac77dd72d309`. Original checkout status was clean. `sha256sum -c ../review-188/candidate.manifest` verified all nine changed-file byte identities. `cmp` matched the supplied diff to `git diff --binary 04a7bc7 bb826f4`; `git diff --check 04a7bc7 bb826f4` exited 0.
- Packet identities, SHA-256. Intent `cebc093fab86eb0de972b6a946471047d820ca46f6745f1fe4e52a214a34391d`, delta diff `3c2760a1d8f27a4a7ea7228154871ed5861925a71bdd7dd1591dfff406881d27`, changed-file manifest `fefa3497ba0519b2b3299374eec0313560818971f2a36c704a53ef1c9b6ad393`.
- Common prompt `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`, role prompt `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`. Used the continuity and review clauses in CONTRIBUTING, RI contract, check registry and source workflow definitions. No current peer output was inspected. A search of the versioned candidate's dated analysis surfaced earlier iteration review summaries after the independent probe had been designed. The outcome uses the implementation, policy, commands and independent oracle. The orchestrator holds launch parameter and acceptance evidence. Provider context internals are unknown.

## Structure and allocation

The guarded path at `tools/repository_intelligence.py:338` checks line and byte budgets on decoded original input before validating active headings. The view used for that validation removes the initial BOM for interpretation and recognizes Markdown physical line breaks. It is then carried through `build` at line 502 to the inventory title search at line 295. Headingless continuity entries and other Markdown still take the inventory's general parsing fallback. `scan` at line 198 hashes the raw bytes separately. This protects against a second parser disagreeing about where the fence ends or where the title begins while preserving the raw identity and the rejection rules.

| Risk and AC | Independent oracle and executed scenario | Existing owner and allocation |
| --- | --- | --- |
| Valid fenced content rejected by inventory or ignored at title extraction, AC01 | Pandoc GFM AST contains the real level-one title, five level-two headings, and the literal marker in a code block. Full candidate builds return the title. Prior producer against the same bytes reproduces each original failure. | Update to the existing continuity method at `tests/test_repository_intelligence.py:811`. Navigation job `navigation` runs the suite through `ri-regressions`, and Owning acceptance job `acceptance` invokes the same method through `CONTINUITY`. Pandoc and combined CRLF are bounded manual QA. |
| Original byte identity changes with normalized title view, AC01/04 | Independently hash bytes with Python `hashlib.sha256` and compare the exact content record after each accepted build. Validate freshness of the unchanged candidate and inspect title fallback on README and headingless-contract AGENTS. | Existing continuity test assertions and Navigation's `ri-freshness`. Owning `INVENTORY` invokes the generic catalog/fresh-view method. |
| Strict continuity rules loosen when inventory receives the approved view, AC01 | 120/121 lines and 8,192/8,193 bytes, including UTF-8 multibyte text and a BOM. Match rejection causes for front matter, raw tag, literal unfenced marker, indented fence, Setext, fenced missing heading, extra heading and duplicate heading. | Retain the existing continuity regression in Navigation and Owning acceptance. No new suite or job. |
| Route or generated view goes stale, AC04 | Match the maintained RI/CI routes to workflow commands and run map verifier, coupling suite, RI freshness and clean exact-source owning policy. | SITE-CHECK-PROFILES D01/D02/D03/D09 and routes R/O. The historical #31 snapshot method is outside the policy selection. |

## Observed execution

Python 3.12.14 and Pandoc 3.1.11.1. On the original exact candidate with `PYTHONDONTWRITEBYTECODE=1`:

- `python3 -m unittest discover -s tests -p test_repository_intelligence.py` ran 40 tests in 13.591 s, OK.
- `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify` exited 0 and printed `Repository Intelligence context is fresh.` RI source digest `4aabbd372527a0dd29e69065684d3ce15d647241295984d826f0ca8a05a2baa3`.
- `python3 tools/check_ri_ci.py verify` exited 0, 19 layers and 17 checks, source digest `49b4ee1537e5373d7f01fad52b1fd63187c63b3cc0a0587641a3f025bc14a048`. `python3 -m unittest discover -s tests -p test_ri_ci.py` ran 23 tests in 0.545 s, OK.
- `python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-188.json --require-clean --expected-source bb826f40f1645077d95c655422dcecadcd186184 --report "$report_dir/report.json"` exited 0. AGENT-ROUTE, CONTINUITY, COUPLING, INVENTORY and STYLE each ran one passing test. Report bound the clean exact commit and tree, marked AC01–04 automated-pass, and retained seven pending manual gates with `ready_for_issue_closure=false`. Initial CLI attempt exited 2 because `--report` is required; the successful run supplied a transient external report path.

The independent probe ran via `PYTHONDONTWRITEBYTECODE=1 python3 -`. It cloned the exact local commit to a clean detached temporary replica, called `ri.verify(replica, cfg)` on original bytes, then called `ri.build(replica, cfg)` on each fixture after replacing only the replica MEMORY bytes. The base body used `# Memory probe` and the five required `##` lines, each followed by a blank line and `Record.`. Each fenced example contained the literal text “Demonstrate \`<!-- without closing its inline marker”. The plain fence also contained `# Fenced decoy`. The U+2028 example put U+2028 immediately after three backticks on a fence-content line and before the literal text. The four fence positives were parsed with `pandoc -f gfm -t json`, with the optional initial UTF-8 signature consumed at the Markdown reader boundary. RI received every raw byte including BOM and CRLF. The probe loaded the preceding producer with `git show 04a7bc7:tools/repository_intelligence.py` for the three bounded fault comparisons.

| Accepted case | Observed bytes / lines | Raw SHA-256 checked | Earlier producer |
| --- | --- | --- | --- |
| BOM before opening fence | 216 / 27 | `696cee82985d254d3e3991ae2d1813275be599ab54ce4e0bc2e131b970ed8585` | Unmatched comment-bearing code span |
| BOM before title | 216 / 27 | `18bba738a9d8a19f561af32791deb065e88ad41621f0935a82eef5e150992140` | Incorrect title `MEMORY.md` |
| U+2028 within fence | 204 / 27 | `e233412c62657816bcb09465b2521f294ffa380b441290c3544f7c6fd2c424e3` | Unmatched comment-bearing code span |
| Combined BOM, U+2028 and CRLF | 233 / 27 | `3eee837176cbec8806a88fbce62ff57ca79fcce639a2ca2c57c05831c04f604f` | Outside fault comparison |
| Exact line limit | 527 / 120 | `a88487e20ec7198fa99b0ce5e87078b77d2dac12acfd53aa69825ed5721d3203` | Outside fault comparison |
| Exact byte limit including BOM | 8,192 / 23 | `017fc49c3a08481b35763d964bf3a672032c17bfabccbc360dec975c3a5740e7` | Outside fault comparison |

All six builds returned `Memory probe`, `Agent guide`, and `Vitalii Oborskyi — author site and publication platform` for their corresponding paths. The ten negative builds returned their expected errors: line bound, UTF-8 byte bound, unsupported front matter, unsupported raw HTML, unsupported HTML comment markers, fence must start at column one, unsupported Setext, missing `## Snapshot`, noncanonical `## Extra`, and duplicate `## Snapshot`. The successful probe exited 0, restored the original bytes, confirmed a clean replica and removed it. The first probe exited 1 on a reviewer-written fallback-title assertion that used shortened guessed titles for existing AGENTS/README. The successful probe sourced those exact titles from the pinned documents and left the candidate and acceptance oracle unchanged.

## Limits

This is a bounded structural exercise without a measured coverage claim. Pandoc supplied a positive rendering oracle, with no live GitHub rendering or native CI observation. The parser's complete Markdown grammar, protected delivery and the live handoff's semantic truth remain outside this role's targeted result. No repository or external changes were made.
