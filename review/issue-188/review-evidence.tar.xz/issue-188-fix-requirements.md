# Requirements & Acceptance correction review — #188 / PR #192

**Changes requested.** The exact local candidate corrects the reported basic inline, standalone indented-code, canonical duplicate and handoff cases. It regresses the retained refusal of list-nested fences after an ordinary list continuation and leaves a false refusal in the stated multi-backtick class. AC01 and AC04 remain open. A GitHub rewalk supports the corrected AC02 pointer, with the current correction still local during the review.

## Source and executed checks

- Local clean candidate `067f31651649b5393fa71b1b3dc172c52601b0c3`, tree `b912049fd533609377c24c9590b896987066426b`. Previous head `5c870fc447ef1ba4cebbfef3cef53834a0af8e2d`. Protected base `0394f52c82a34c304c123aeaee023c5ec44a85b0`.
- Verified every file in packet manifest SHA-256 `e704f603691c90f7ec369a3dd3cd591d23bb43daa5386c54a7d7d875d0c905fd`. Used the preserved preflight and its neutral intent/prompt inputs as a role-specific continuation. Reviewed actual changed guard, tests, protocol, acceptance policy and handoff, without reading other reviewer reports. The prior preflight's live-issue exposure is disclosed there.
- Ran all 40 RI tests, RI freshness verify and RI/CI-map verification at this candidate. All passed. Coupling reported 17 checks across 19 layers. Independently ran focused fixtures through both head and predecessor guard functions and rendered each relevant case using `pandoc -f gfm -t html`. No repository or remote writes.

## Findings

1. **P2 · AC01 / AC04. The correction admits a list-nested fence that the predecessor refused.** `tools/repository_intelligence.py:135–144` overwrites list context when it sees a nonblank continuation indented two spaces. Append the following fragment after the five real sections. Pandoc renders the fence as a child of the list item. The old guard fails with the column-one restriction. The candidate accepts because it clears list context on the continuation and then skips the indented opening and closing fence. The retained boundary is explicit in CONTRIBUTING and the correction's analysis. Extend the maintained regression with a continued list item and keep the standalone code positive.

~~~text
- list
  continued paragraph

    ```md
    ## Snapshot
    ```
~~~

2. **P2 · AC01 / AC04. An escaped literal backtick adjacent to a valid multi-backtick span still triggers false raw-HTML refusal inside paired emphasis.** At `tools/repository_intelligence.py:94–108`, the substitution consumes the escape and its first backtick, but its next match still evaluates the negative lookbehind against that escaped backtick. Construct the line as `"<em>" + chr(92) + chr(96)*3 + "<details>" + chr(96)*2 + "</em>"`. Pandoc renders a literal backtick followed by inline code containing escaped `<details>`, all inside emphasis. Both source versions reject it as raw HTML. Account for the escaped prefix in opening delimiter recognition and preserve the refusal of real raw nested tags and mismatched code delimiters.
3. **P3 · AC01. Internal heading whitespace is outside the current duplicate matcher.** `tools/repository_intelligence.py:379–388` catches exact repeated canonical headings and closing-marker variants. Additional `## Open   work ##` and an equivalent internal-tab fixture both pass and render another H2 titled `Open work`. Under a bounded plain-text ATX title oracle, normalize internal Markdown whitespace or explicitly state that canonical title matching preserves its raw spelling. A Setext equivalent likewise renders a second H2 and remains outside the stated ATX uniqueness scope. That exclusion can stand if the canonical constraint stays explicit and the evidence claims only its bounded coverage.

## Acceptance evidence

| AC | Verified at the inspected source | Remaining |
| --- | --- | --- |
| AC01 | URI inside or after leading emphasis and ordinary equal-run multi-backtick spans pass. A standalone four-space code block with literal fence markers passes, and a heading only in that block fails as missing. Exact and closing-marker duplicates fail. The test suite retains limits, comments, raw HTML and inactive heading checks. | Correct or resolve the specific findings above. The existing passing suite does not detect them. |
| AC02 | `MEMORY.md:18` uses the fragment-free owning issue that the live connector retrieved during preflight. GitHub's commit-scoped workflow response confirms predecessor Source run 43005531322, Navigation run 43005531193 and Owning run 43005531099 succeeded. It also confirms failed predecessor run 43005531237 and failed Staging admission job 130471958714 at the authentication step. Live PR #192 was open and Draft at predecessor `5c870fc` during this review. | The connector supplied the failed step, with no raw error annotation. The exact candidate had no remote PR head or matching hosted evidence in this review. Rewalk the published candidate before claiming its external handoff gate. |
| AC03 | The documentation delta changes heading and example syntax. The dated handoff's current/next-action separation and the established lifecycle triggers remain intact. | No lifecycle defect found in this delta. |
| AC04 | Existing named continuity test, RI inventory and coupling remain routed. Style subcondition is recorded in the candidate's delta. | Keep Draft pending correction and affected independent review. Verify the final exact-head delivery controls, native checks and applicable maintainer decision separately. |

The canonical bounds, owning issue and existing test allocation remain sufficient. No additional maintainer scope decision is required to preserve the established refusal while admitting the authorized Markdown cases.
