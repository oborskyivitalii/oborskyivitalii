# Issue #188 / PR #192 — affected White-box QA re-review

**Verdict: pass for the affected AC01 and AC04 WHITEBOX checks under the retained column-one fence scope.** W1 and W3 pass their independent GFM controls. W2's nested-fence regression is corrected. The guard conservatively refuses indented fence-like marker lines, including lines that GFM treats as literals in standalone indented code. That scope limit is observable and remains part of this result.

## Source and independence

- Nonauthor role `/root/fix188_whitebox`, continuation of its own earlier White-box QA. First result `issue-188-fix-whitebox.md` remains unchanged at SHA-256 `a2faca4f709d278c06b755452cec02c51af20f425b4440cf02db79581d5a0920`. This is a targeted re-review with continuity from that first result. No peer verdict was consulted.
- Candidate commit `5e680ff5746bd6f1d3dacdd2fa2016fb750f704b`, tree `8a858a5cd53b045beed017905c0abba2195bb9fc`, clean worktree before and after checks. Correction comparison `067f31651649b5393fa71b1b3dc172c52601b0c3`. Legacy comparisons include `5c870fc447ef1ba4cebbfef3cef53834a0af8e2d` and `0394f52c82a34c304c123aeaee023c5ec44a85b0`.
- Packet `fix188-final-review.manifest` SHA-256 `5fe91f124760637624af955d4e66615752dae006600919e7e613b395e8302fc4`. `sha256sum -c` verified all 15 entries. Common reviewer prompt SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`, role prompt SHA-256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.

## Findings rechecked

| Prior finding | Independent probe on the exact candidate | Disposition |
| --- | --- | --- |
| W1, active canonical heading duplicates with interior whitespace | `## Open   work` and `## Next<TAB>session` render the same level-two title tokens as the existing canonical headings, with duplicate IDs `open-work-1` and `next-session-1`. The guard rejects both with the correct duplicate diagnostics. An outer-delimiter duplicate is still refused. Literal headings in a column-one fenced block or ordinary indented code are accepted. | Resolved. The existing CONTINUITY test now exercises both multiword variants. |
| W2, list heuristic and indented fence handling | GFM reports a list-contained fenced block after a two-space paragraph continuation, and at the five-column content offset of `100. Example`. The guard rejects both with its column-one diagnostic. GFM independently confirms that the four-column example after `100. Example`, the example after `* * *`, and the standalone example without either predecessor are indented code blocks containing literal backticks. The guard rejects all three, consistently with the retained lexical fence restriction. An indented `## Snapshot` without fence-looking marker lines is accepted and ignored for heading counting. | Nested-fence regression resolved by withdrawing the list-context heuristic. The narrower guard scope covers column-one fence examples and ordinary indented examples without fence-looking marker lines. The remaining semantic distinction between standalone literal marker text and real nested fences is outside this review's accepted scope. |
| W3, escaped backtick adjacent to code delimiter | A literal escaped backtick followed immediately by a single- or double-backtick code span containing `<details>` yields a GFM Code inline, and the guard accepts both. A raw `<details>` after a valid adjacent span still appears as GFM RawInline and the guard rejects it. A wrong-length run exposing the raw tag is also rejected. URI links inside and after paired emphasis remain accepted. | Resolved. The existing CONTINUITY test now exercises the escaped opener and exposed-tag controls. |

## Execution and accounting

- Direct guard fixtures and `pandoc -f gfm -t json` with Pandoc 3.1.11.1. Exit 0, 16/16 cases matched the asserted guard policy and independent GFM structural expectations. The three standalone fence-looking literal cases in W2 assert conservative refusal as guard policy and literal-code classification as GFM behavior.
- Separate direct guard assertions for 8,192/8,193 UTF-8 bytes with multibyte text, 120/121 lines, and the current MEMORY. Exit 0, 5/5 matched. The worked MEMORY measured 3,418 bytes and 29 lines. Prior exact CRLF boundary checks were reused because the producer's byte calculation, binary read/decode path, and cap configuration are unchanged.
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=tests python3 -m unittest -v test_repository_intelligence.NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail`. Exit 0, one test passed in 0.852 s, exercising the maintained temporary-fixture build and mapped owning CONTINUITY selector.
- Recompiled the default-mode scanner from `git show <ref>:tools/repository_intelligence.py` for all four pinned revisions. Exit 0, 8/8 fixture outcomes identical, including the unmatched comment-bearing code error. `git diff --check 0394f52..HEAD` exited 0.

No repository or remote writes. This review covers the affected guard and test paths. Full RI/CI, external handoff truth, release/admission and other independent gates remain outside the bounded execution.
