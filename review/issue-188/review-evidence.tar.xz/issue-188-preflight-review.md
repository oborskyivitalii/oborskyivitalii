# #188 requirements and acceptance preflight

Independent first result, 2026-11-11. Role: Requirements & Acceptance Reviewer
(`/root/memory_requirements`), preimplementation. **Verdict: requirements are
implementable. Resolve the proposed limit at 8,192 inclusive UTF-8 bytes for
MEMORY.md. Preserve AC01–AC04 and make the section, lifecycle, and evidence
oracles below explicit in the existing owning route.** This is the review
called for by AC01 to resolve the number. The original intake records the
number as a recommendation and supplies no separate historical owner approval.
All four implementation ACs remain pending.

## Exact inputs and limits

- Repository `oborskyivitalii/oborskyivitalii`; clean local HEAD, main and
  origin/main `0394f52c82a34c304c123aeaee023c5ec44a85b0`, tree
  `be90443444b8a7e96ad76eac62a61057d5dc957f`. This tree has only root AGENTS.md.
- Packet SHA-256
  `91cd654f7444ee07ff016ebc84ad82f3db82852016e13549793434489a8b166b`.
  All entries verified, including local intake SHA-256
  `ed0de6408d98b254e88070bc0475ddc3c6eb33362920052d9182592e8309e12f`;
  repository entries were hashed from immutable Git blobs. Common reviewer
  contract blob `26b5d554da6027ff6aff850c2ab6bacb93b9ee38`; role prompt
  blob `3e6330fc4a1a01d33e2dcae6e0f35d3f3471c1e4`.
- Read the complete packet and relevant owners at that base, including README,
  REPOSITORY-MAP, CODE-STYLE and SITE-CHECK-PROFILES; also .gitattributes,
  .github/ri-ci-map.json, navigation/issue-acceptance workflows, RI/coupling/style
  test owners, and the protected routing implementation. The commit identifies
  supplemental source bytes. The packet identifies the formal review inputs.
- Connector readback of [open #188 and its intake](https://github.com/oborskyivitalii/oborskyivitalii/issues/188)
  matched the packet scope and sole Linear linkback. The
  [preserved #187 combined intake](https://github.com/oborskyivitalii/oborskyivitalii/issues/187#issuecomment-6770665091)
  traces original AC03 to local AC01–03 and the continuity-specific original AC06
  to local AC04. The live #187 remains open with its separate animation scope.
  [Closed #189](https://github.com/oborskyivitalii/oborskyivitalii/issues/189)
  records [merged #190](https://github.com/oborskyivitalii/oborskyivitalii/pull/190)
  on this exact main and separately records the reviewed source tree, post-merge
  identity check, 10,516,300 bytes of headroom under the unchanged RI hash limit,
  and no production dispatch for that change. [Closed #184](https://github.com/oborskyivitalii/oborskyivitalii/issues/184)
  records separate actual production source ca756417590b9176f9fc33428321ffe1f64158cc
  and prod-2026-11-10.1 publisher evidence. The latter is prior delivery evidence,
  and its current status should be revalidated at handoff if claimed.
- Ran only the existing focused baseline unittest and three read-only synthetic
  probes of the current guard, as recorded below. No candidate, production,
  deployment, trusted final classifier result, owner merge decision or closure
  observed for #188. No implementation/test edits, peer notes, external writes
  or delegation. First judgment received the assigned packet and ordinary
  platform context, with no author reasoning or peer findings observed.
  Orchestrator records requested/accepted launch parameters; provider model and
  context internals are outside this review's observation.

## Requirements and findings

1. **AC01, confirmed missing enforcement and section false-positive.** The
   current MEMORY blob is 3,968 bytes and 35 lines, so 8,192 bytes allows roughly
   twice the space of this active multi-work handoff. The byte ceiling complements
   the existing 120-line ceiling, which admits a single large line; the general
   RI 2 MB text limit is unrelated to handoff compactness. Define 8 KiB as
   8,192 bytes inclusive of all source bytes including whitespace and final LF;
   8,193 fails even when character count and line count are below the limits.
   Retain the existing 120-line count and five named level-two sections. “Oversize
   lines/bytes” means too many lines or too many whole-file bytes. It introduces
   no separate line-length limit. RI scan reads exact bytes and decodes strict
   UTF-8 at `tools/repository_intelligence.py:175–204`, making the encoded byte
   length of the unmodified decoded body an exact count without a second read.
   At lines 315–322 the current raw line search accepts a required heading inside
   a fence or multiline comment even when the actual section is missing. Three
   local baseline probes confirmed that fences/comments each pass the existing
   check and disappear from the existing `active_markdown` view, and that an
   8,222-byte handoff with a long Cyrillic line passes. Close that bypass in the
   maintained guard using the existing active-markdown view for heading presence
   and the whole original body for its two size bounds. No new validator or
   section order/format requirements are needed.

   Extend `NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail`
   (`tests/test_repository_intelligence.py:757–774`) with true positive and
   negative boundaries, discriminating error assertions, and cases that keep the
   other bounds and section checks valid. Cover 120/121 lines, 8,192/8,193 bytes,
   and a non-ASCII overage whose character count remains below the cap. Cover an
   absent active required heading, preserving the existing AGENTS assertion.
   Check the real configured limit and headings, in addition to exercising
   fixtures, so a passing fixture cannot hide different production settings.
   Preserve CS05's authored LF and final-newline contract.

2. **AC02, intake's stale example has been superseded.** The exact base's
   MEMORY.md already supersedes the old PR186/a9f5769 entry described at intake.
   Its *current* incorrect assertions put #189/PR190 in Draft and main at
   ca756417, and carry forward already resolved #189 blockers. Correct the
   actual stale claims using the current main/PR190 evidence and keep production
   as its separately verified source if relevant. In the worked handoff, a
   reader should identify #188, verified date/ref, current or completed step,
   actual stopping point, pending criteria/blockers and the first concrete next
   action. Link exact current issue/PR/review/check evidence, explicitly stating
   when a planned object has not yet been created. Retain concise concurrent
   pointers such as #187. Superseded detail belongs to its original issue/PR or
   review. Independently follow the links and reconstruct the next action from
   the handoff and live owners. A tested PR, a merged protocol, a dated snapshot
   and a published site are separate observations. Avoid asking a file to embed
   the SHA of its own containing commit; bind that exact candidate externally
   through the PR/check/review evidence.

3. **AC03, canonical trigger gap.** AGENTS.md:85–91 currently covers
   handoff/interruption, and CONTRIBUTING.md:316 onward adds completion.
   .github/ACCEPTANCE.md:40–58 covers session-end handoff and remaining action.
   The accepted lifecycle additionally names meaningful completed progress and
   actual staging/production/closure transitions when they occur. Put the full
   update rule in CONTRIBUTING's continuity owner and keep AGENTS a short route.
   Replace stale material when a verified milestone changes the stopping point
   or next action, at interruption/handoff, and when an actual delivery/closure
   transition changes the snapshot. Record dates and evidence after observation;
   planned acceptance or release remains pending. Existing issue/PR/review and
   acceptance owners retain history, decision wording, actual checkboxes and
   evidence. The repository-only nature of #188 does not require a staging or
   production event to prove the protocol. Review the rule together with a real
   worked handoff and link resumption evidence in the existing versioned record.

4. **AC04, missing owning policy and required exact-source gates.** This base
   has no .github/acceptance/issue-188.json. Add the owning mapping with stable
   IDs and explicit external gates for factual resumption, lifecycle/decision
   truth, the four independent roles/corrections and the applicable maintainer
   merge decision. Deterministic checks support only their automated scope.
   Existing navigation CI already owns the RI test, fresh-source verification,
   coupling and bounded style guard. Code/config style plan before edits:
   CS01 (canonical producer and derived views), CS04 (one configured owner),
   CS05 (focused readable UTF-8/LF code), CS07 (bounds and existing data read),
   CS08 (tests for the failure mechanism and exact outputs), CS09 (bounded
   guard), CS10 (source-bound mapping and unautomated review). Runtime
   presentation/lifecycle rules CS02/03/06 are outside this T4 delta. The #189
   whole-file formatting exception applies only to its recorded delta.
   Map owning check selectors, including
   `test_code_style.CodeStyleRepositoryTests.test_current_repository_guard`
   and `test_ri_ci.RICICouplingTests.test_current_repository_map_and_ci_routes`
   where applicable, and retain current policy validation, full affected RI
   regression, RI build/verify and changed-source allocations.
   Register new paths in the catalog and reflect affected RI/CI inputs and routes;
   regenerate both RI outputs. Preserve before/after test dispositions and exact
   source/results. A source-only technical route is plausible under protected
   main's #189 amendment for the standard RI producers/tests, RI contract/map
   and new owning policy. Generic .github/ACCEPTANCE.md is an executable-trust
   control in `delivery-routing.cjs:186–235` outside the maintenance allowlist
   at lines 654–665, and the general text already handles this task. Reuse it
   unless a specific requirement changes it. Any needed workflow dependency
   predicates must follow the existing positive policy additions and current
   rule. Select using the real complete final delta and both endpoints rather
   than infer the route from T4; preserve protected control-head review and App
   requirements. Keep release/site/animation/archive changes outside #188.

## Acceptance mapping

| Intent / criterion | Observable check or owner gate | Base observation and next evidence |
| --- | --- | --- |
| Original AC03, local AC01 | Existing continuity unittest and RI guard distinguish exact whole-file byte/line boundaries, character-count bypass and absent active sections. This independent preflight resolves the proposed cap. | Existing named test passed, 1 test, with `python3 -B -m unittest discover -s tests -p 'test_repository_intelligence.py' -k test_memory_and_agent_bounds_and_required_sections_fail` on clean base 0394f52. Baseline probes prove missing coverage; updated exact-source check and actual config verification pending. |
| Original AC03, local AC02 | Independent operator resumes using current main/PR/issue/run evidence and clear pending state. | Closed #189/merged #190 contradict active status and main equality in base MEMORY. Current worked handoff and independent factual resumption pending. |
| Original AC03, local AC03 | Canonical rule inspection plus worked checkpoint and distinct decision/future action evidence. | Existing AGENTS/CONTRIBUTING and ACCEPTANCE cover some triggers. Exact amended protocol, handoff and independent review pending. |
| Continuity portion of original AC06, local AC04 | Style/RI/coupling/owning/source checks, final protected selector and applicable lane, four roles/correction, maintainer merge and actual handoff facts. | Existing navigation and acceptance runners available; no #188 policy or candidate at reviewed base. Current-source results, role receipts, decisions and delivery pending. |

No requirements ambiguity remains that blocks a narrowly scoped implementation
after the cap and verification interpretation are recorded and the pre-edit
style/test mapping is made. The closed #189 capacity dependency does not block
work on this base; measure complete-candidate capacity before advancement.
Repeat independent Requirements review on the candidate and after any material
intent or oracle change. All issue checkboxes remain open until their respective
automated and external evidence is current and complete.
