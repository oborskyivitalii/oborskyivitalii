# Issue #188 — independent White-box QA, first result

**Verdict: changes required.** The active-heading invariant fails under the maintained RI build and verify entry points. AC01 is blocked, and the White-box gate for AC04 remains pending. The isolated current-source automated checks pass after providing the pinned style baseline object, but the focused test does not exercise the reproduced false positives.

## Identity and scope

- Reviewer role and task: `/root/memory_whitebox`, separate nonauthor White-box QA, first judgment. This execution received the source packet and task assignment. The orchestrator owns the actual launch-parameter receipt and provider internals are unverified.
- Repository `oborskyivitalii/oborskyivitalii`, issue [#188](https://github.com/oborskyivitalii/oborskyivitalii/issues/188). Base `0394f52c82a34c304c123aeaee023c5ec44a85b0`, candidate `4dd3bddf8d1f105f59714eb973e5f5f347885403`, tree `72c2a223e1b46c89126c6b858e798f823c13c9a3`.
- Packet manifest SHA-256 `a5024bdddd57d4d3f528b1ae056e887ee015474a02ecea9bd8f305040c08736e`. All 13 manifest records verified, including issue intent `7783d15c76da31804ad9df75f901abbae440b780d46ff4c5f82d5352c83d3a29` and full diff `b15a46b33be8a013c7df5825930d0431a1ac9e2f5ccd99f8d80138f37a77c32b`. Git diff --check exited 0.
- Common reviewer prompt `agents/reviewers/README.md` blob `26b5d554da6027ff6aff850c2ab6bacb93b9ee38`, role prompt `agents/reviewers/white-box-qa.md` blob `f3d5e777711d05fa844052a0c49339eb577a06d1`. Read the root instructions, contribution protocol, repo map/continuity entry, owning issue, producer/guard/test, config, acceptance policy, relevant coupling and CI workflows, and QA test allocation. Git lists only the root AGENTS as an applicable instruction file. The full diff has 13 paths, confined to continuity, RI/acceptance, and issue records. Archive verdicts and peer evidence were not inspected.
- Checks ran using Python 3.12.14 in a separate clean detached candidate clone. Negative builds used a separate Git archive of the same candidate and edited only that copy of MEMORY and its generated views. Independent Markdown oracle used Pandoc 3.1.11.1, `-f commonmark -t json`, looking for an actual Header node named Snapshot. No canonical checkout or external writes.

## Finding

**WB-01 — Blocking, AC01 and AC04.** At `tools/repository_intelligence.py:327–330`, the check treats membership in a text projection as proof of an active Markdown heading. The projection in `active_markdown` at lines 94–145 discards fenced code and HTML comments, but retains literal lines within raw HTML blocks and can manufacture an apparent canonical source line by stripping a preceding HTML comment.

Two independent fault inputs replace the sole actual Snapshot heading while leaving the other four sections intact:

~~~markdown
<pre>
## Snapshot
</pre>
~~~

~~~markdown
<!-- note -->## Snapshot
~~~

Pandoc emitted no Snapshot Header node in either case. Both cases returned exit 0 from RI build and exit 0 from RI verify after regenerating the fixture views. The second is also a regression versus checking the exact original source line: the preexisting exact-line predicate cannot see an exact heading on that source line. Current tests at `tests/test_repository_intelligence.py:795–814` cover an entirely missing section, a fence and a standalone HTML comment, so they pass despite both false positives. The protected invariant is five actual active sections even when the file remains within both size caps. Keep the correction scoped to continuity or demonstrate preservation of existing RI Markdown consumers if changing the shared helper. Extend the existing continuity regression with raw-HTML and same-line-comment false positives, verify a genuine heading still succeeds, and re-run the affected checks on the corrected tree.

The direct probe also observed rejection of valid alternate ATX spellings with three leading spaces or trailing hash markers. The previous implementation likewise required exact source spelling, so this is not a new blocker. The maintained canonical formatting rule should guide whether those spellings are intentionally outside the continuity contract.

## Structural risk and allocation

| AC and risk | Scenario and independent oracle | Execution route and disposition |
| --- | --- | --- |
| AC01, inclusive line guard and UTF-8 cap over original bytes | 120/121 lines, 8,192/8,193 bytes, multibyte text and raw CRLF. Source reads binary, decodes UTF-8, checks file before Markdown processing. Re-encoding valid UTF-8 preserves raw byte count including whitespace and line endings. The byte-failure fixture has only nine physical lines and a present Snapshot heading. | Keep `NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail` in the permanent RI suite, owned by .github/REPOSITORY-INTELLIGENCE.md. The navigation workflow's `navigation` job uses discovery for that module and owning workflow's `acceptance` job runs its CONTINUITY selector. Independent CRLF probe confirms exact boundary. |
| AC01/AC04, inactive source creates false pass | Replace only Snapshot with fenced code, comment, raw HTML pre or same-line comment prefix. The accepted criterion requires a real active section. Independent parser and maintained CLI disagree on the latter two. | Extend the same selector/owner and same two existing workflow routes. No additional suite/profile/workflow. Recheck the guard and generated view verification on the corrected source. |
| AC02/AC03, output freshness and lifecycle claims | Inventory and coupling tests verify selected source paths, byte identity and declared check invocation. They cannot verify live facts, usefulness of resumption, or whether an agent actually followed the replacement rule. | Keep existing INVENTORY, AGENT-ROUTE and COUPLING selectors, plus RI verify in navigation. Retain HANDOFF and LIFECYCLE as external gates assigned through the existing owning review protocol. |
| AC04, source binding and release admission | Local policy report must name this clean commit/tree and preserve pending external gates. Trusted full-diff admission, native Actions and actual merge require their source-bound records. | Owning workflow uses the exact head and clean-source options. Local selector results below. Protected admission, native hosted results and merge are not observed here. |

## Executed checks

- `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'`: exit 0, **40/40** in 10.454 seconds, no skipped or failed tests in summary. Follow-up status was clean.
- `python3 tools/check_ri_ci.py verify`: exit 0, **17 checks, 19 layers**, source digest `6d8d349376118858d79211983f28c5085499e5bba50191182306653fa7cdc3e4`, explicitly `live_github_state_verified: false`.
- `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify`: exit 0, context fresh for the unmodified clean candidate.
- `python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-188.json --report <external temporary path> --require-clean --expected-source 4dd3bddf8d1f105f59714eb973e5f5f347885403`: first attempt exit 1, four of five selectors passed, STYLE failed because the isolated shallow clone did not contain required immutable baseline object `aa1cfa97bf42103c0547c9332b885391f0e6fe6b`. Raw report `/tmp/issue-188-whitebox-owning.KJloYZ`, SHA-256 `f8bef5fdfe657e29dbff552651e590c8990997bd9d6cf38a0ccb66cf63276c81`. Confirmed the source repo provides the pinned baseline path, then re-ran with `GIT_ALTERNATE_OBJECT_DIRECTORIES` pointing to its read-only objects. Exit 0, **5/5** selectors, AC01–AC04 automated-pass, all seven external gates pending, closure false. Raw report `/tmp/issue-188-whitebox-owning-resolved.x44NIV`, SHA-256 `58dffc5fda1913a53c6321e7c27f475276d3232fae99000b24c2951c3d9db6ae`. Report identifies exact candidate and tree, source_dirty false, RI input digest `6ec3e0a37d128e1ce06e4f0a61bdf030a077856f5abd5502786becd4452c7053`.

Full CLI fixture results using `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json build` and, for both missed faults, `verify` after build:

| Fixture | Bytes / physical lines | Snapshot Header in independent oracle | Build exit and observation | Verify exit |
| --- | --- | --- | --- | --- |
| Actual candidate MEMORY | 3,019 / 28 | yes | 0, 2,673 files and 285 directories | clean candidate separately verified |
| Fenced Snapshot | 3,029 / 30 | no | 1, Missing continuity section ## Snapshot | — |
| Raw HTML pre Snapshot | 3,032 / 30 | no | 0, generated RI views | 0, context fresh |
| HTML comment prefix Snapshot | 3,032 / 28 | no | 0, generated RI views | 0, context fresh |
| Multibyte CRLF boundary | 8,192 / 9 | yes | 0, generated RI views | — |
| Multibyte CRLF overage | 8,193 / 9 | yes | 1, Continuity UTF-8 byte bound exceeded | — |

A direct guard probe also confirmed standalone HTML comment rejection and tested standard alternate ATX spellings. Structural and fixture checks establish the stated scenarios only. No measured branch coverage, native Actions, protected lane admission, live issue/PR/production facts, site runtime, browser/device, or merge evidence was established in this role.
