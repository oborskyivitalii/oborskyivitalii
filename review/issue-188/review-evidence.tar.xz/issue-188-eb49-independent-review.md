# Independent Code / Artifact review of PR #192

**Verdict: changes requested on AC01.** Two focused Markdown probes disagree with the continuity contract. The affected Code gate in AC04 remains open. The repository delivery path itself is correctly selected by the protected-base policy.

## Source and scope

- Owner: issue #188, PR #192. Protected base `0394f52c82a34c304c123aeaee023c5ec44a85b0` / tree `be90443444b8a7e96ad76eac62a61057d5dc957f`.
- Candidate `eb49a288138c006db3985548158c32f34b0ffca6` / tree `d650a406f92005c5ba67ed12e2ab5b7c346c5230`. Clean detached checkout in `fix188-delivery`. `git ls-remote` independently matched protected `main`, the work branch and `refs/pull/192/head`, and resolved `prod-2026-11-10.1` to `ca756417590b9176f9fc33428321ffe1f64158cc`.
- Original acceptance intake packet SHA-256 `53eb844ab52e59fbeaffdcbf96830c62117fd3b600c65cea880fffae97b75739`. Common and role prompts at the candidate have Git blobs `26b5d554da6027ff6aff850c2ab6bacb93b9ee38` and `2363340a1eaae62fdbd3ab070fda5c6436ec8124`.
- Inspected AGENTS, README, map, CONTRIBUTING, the Code and common reviewer prompts, the style guide, source/acceptance/coupling/ledger deltas, generated projection changes, MEMORY and delivery links. The two review provenance files were opaque to this judgment. I verified the existence of the specifically linked acceptance heading via a boolean-only search. I did not inspect their verdicts, other agent scratch, or live issue narrative. The launch parameters and provider context internals are observable by the orchestrator or provider, rather than established by this result.

## Findings

### P2 — An active ATX heading can repeat a canonical rendered title

`tools/repository_intelligence.py:374–382` only recognizes the configured literal title with optional ASCII whitespace or closing hashes. `CONTRIBUTING.md:320–321` names the five level-two ATX headings by title and directs authors to use each once. `.github/acceptance/issue-188.json:9–10` promises duplicate active canonical heading detection.

Append a blank line and `## *Snapshot*` to exact candidate `MEMORY.md`, leaving the original `## Snapshot`. Invoke `check_continuity` with the repository config and mutated body. The guard returns success. Pandoc 3.1.11.1 in GFM mode renders the original `<h2 id="snapshot">Snapshot</h2>` and a second active `<h2 id="snapshot-1"><em>Snapshot</em></h2>`. The same result holds with `## Snapsho&#116;`, yielding a second unstyled `Snapshot`. Both inputs use ATX and ordinary inline Markdown. A visibly repeated section can send a reader to different content when resuming the task. A Setext heading also bypasses the count, but lies outside the declared ATX convention and is not needed for this finding.

Enforce uniqueness of canonical labels across the supported ATX heading text syntax, or establish and enforce a narrower top-level H2 syntax that excludes ambiguous formatted variants. Add an independent positive/refusal case for the chosen boundary. Merely documenting that the five required source lines are literal does not prevent a competing rendered heading.

### P2 — Comment-marker code examples conflict with documented inline-code support

`CONTRIBUTING.md:322–324` permits inline code inside a paired emphasis paragraph and excludes HTML comment markers from the handoff prose. `tools/repository_intelligence.py:94–109` masks supported single-line code literals correctly for its emphasis check, but `:153–155` then scans the unmasked line and refuses any `<!--`, including inside such a literal. The `active_markdown` docstring at `:113–119` explicitly describes supporting balanced single-line spans and excluding comment markers outside examples.

Append the following paragraph after a blank line to exact candidate `MEMORY.md`:

```markdown
<em>Example `<!--` here</em>
```

The guard raises `HTML comment markers are unsupported in continuity sections: MEMORY.md`. Pandoc GFM renders `<p><em>Example <code>&lt;!--</code> here</em></p>` and retains all five section headings. A plain paragraph `Example ` followed by the same balanced code span and ` here` also fails. This is an example of the marker, with no HTML comment or block. The guard is on RI's normal `build` and `verify` path, so an otherwise valid bounded handoff can block navigation/CI. The added test uses an HTML tag inside an inline code span and a comment marker inside a top-level fenced example, but does not exercise their interaction in a single-line code span.

Honor balanced inline-code literals when identifying actual forbidden markers and retain refusal of active comment syntax, or explicitly document that this particular literal must use a column-one fenced block and align the parser docstring and acceptance. Test the boundary. The observed refusal of escaped literal markers and first-line `---` is already deliberately conservative. This finding concerns a balanced span in the explicitly supported syntax.

## Checks and related observations

| Check | Observed exact-source result |
| --- | --- |
| `python3 -m unittest discover -s tests -p test_repository_intelligence.py` | 40 passed in 80.774 seconds. |
| `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify` | Fresh. `verify` calls `build` in memory and compares the two generated files. |
| `python3 tools/check_ri_ci.py verify` | 17 checks, 19 layers, pass. Digest `caa22b43720b5960d97edfd6dc38d888f461fee7693eefedc3937bcd9f8f95a9`. |
| `git diff --check 0394f52 eb49a28` | Pass. |
| Protected routing source probe | `delivery-observation.cjs` `selection(root, base, head)` resolves both exact commits and reports `repositoryOnly: true`, `technicalRepository: true`, `technical.controlReviewRequired: true`, and no rejected technical paths. The broader advisory analysis reports `proposedLane: website`, as the contract describes. |
| Candidate MEMORY | 29 lines, 3,418 UTF-8 bytes. Production-tag and main claims agree with live refs. The local acceptance anchor and the trusted delivery guide anchor resolve. The workflow supports an owner dispatch on `main` with `pr_number` and `reviewed_sha`, and the delivery guide calls for the subsequent PR description edit. |

The byte count uses bytes round-tripped through strict UTF-8 decode from `scan`, so it retains line endings and BOM for accounting. The existing AGENTS line-only path remains separate via config with no required headings. The default parser used for RI titles, terms and source extraction retains its previous behavior. A heading supplied only as `  ## Snapshot ##` still fails the canonical spelling check. That requirement is inherited from base and separate from newly promised duplicate rejection. No new dependencies, website payload changes, CI definition changes, or executable invocation changes were identified. Actual scanner execution, native CI status, App issuance, owner approval and merge were outside this check. The worked handoff orders Draft review and Ready checks coherently but tells a reader to publish the correction even though this exact head is already published. Making that step conditional would improve AC02 resumption. The external handoff gate still owns verification of workflow evidence and open status beyond the refs checked here.

## Minimal independent reproduction

Run from the exact checkout with Pandoc available. This does not write to the worktree.

```python
from pathlib import Path
import subprocess
from tools import repository_intelligence as ri

root = Path.cwd()
config = ri.load_config(root, ".github/repository-intelligence-config.json")
body = (root / "MEMORY.md").read_text(encoding="utf-8")
for addition in ("## *Snapshot*", "## Snapsho&#116;", "<em>Example `<!--` here</em>"):
    changed = body + "\n" + addition + "\n"
    try:
        ri.check_continuity(config, {"AGENTS.md": (root / "AGENTS.md").read_text(), "MEMORY.md": changed})
        print("PASS", addition)
    except ValueError as error:
        print("FAIL", addition, error)
    html = subprocess.run(["pandoc", "-f", "gfm", "-t", "html"], input=changed,
                          text=True, capture_output=True, check=True).stdout
    print("\n".join(line for line in html.splitlines() if 'id="snapshot' in line or "Example" in line))
```
