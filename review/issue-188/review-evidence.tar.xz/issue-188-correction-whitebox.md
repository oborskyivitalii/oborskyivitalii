# Issue #188 — White-box QA correction review

**Verdict: changes required.** The two WB-01 reproductions now fail through the RI CLI as required. A file-initial UTF-8 BOM still bypasses recognition of raw HTML and Markdown fences, allowing RI build and verify to accept a file with no actual required headings. AC01 and the White-box gate for AC04 remain open.

## Reviewed source

- Role `/root/memory_whitebox`, nonauthor source-bound correction continuation. Reused my first White-box result only, SHA-256 `7a0a3618fa211afe70a54abe8cde7ff28da0a81b8c7de92872ea808c2f2dd799`. This is a correction judgment and does not claim new first-review isolation. No peer notes or archive verdicts inspected.
- Owning issue [#188](https://github.com/oborskyivitalii/oborskyivitalii/issues/188), base `0394f52c82a34c304c123aeaee023c5ec44a85b0`, predecessor `b445fa0b67ba438df253ef06fdc3d2da17dea4be`, candidate `65f51b63d8dbd70f4bb4a17f69fec27614b35037`, candidate tree `455e53b70bf5f619bef62933b7a69ac9ef5cd89c`. Manifest SHA-256 `3814638a40b93bb9cebb96ca84d250927e4aff4302323d64fd6744df62475745`, 13 records verified, full diff SHA-256 `187df7754ae460781e918d03f173a90d543af4b6b670532a20d8b6dead83671e`. Git diff --check passed from the base.
- Common and role prompts remain Git blobs `26b5d554da6027ff6aff850c2ab6bacb93b9ee38` and `f3d5e777711d05fa844052a0c49339eb577a06d1`. Inspected changed guard/test, continuity protocol and worked handoff delta, active_markdown callers, unchanged affected acceptance selector, and RI/CI execution routes.
- Clean detached local candidate clone for source checks, pinned baseline object accessed via read-only Git alternates. Separately exported exact candidate tree for intentional fixture edits. Python 3.12.14. Independent parser Pandoc 3.1.11.1 in CommonMark mode, with YAML metadata extension only for front matter cases. Report and fixture logs are bounded local observations.

## WB-02 — Blocking, AC01 and AC04

`tools/repository_intelligence.py:103–106, 117–125, 156–159, 338–345` strips the initial U+FEFF only in the front matter test. Subsequent fence and raw HTML recognizers continue inspecting the first line with the BOM still present. The exact same body without a BOM correctly triggers those recognizers. Since the BOM is a document signature, an actual Markdown parser processes the immediately following syntax at the beginning of the document.

Reproduced through the actual RI CLI by prepending bytes `EF BB BF` and either `<pre>\n` or three backticks followed by `md\n` to the otherwise unchanged candidate MEMORY. Both open a construct through the end of the document. Pandoc emitted zero actual Snapshot headings. In both cases RI build **exited 0** (generated views) and RI verify **exited 0** (fresh). A third fixture prepended BOM plus `<pre>\n## Snapshot\n    </pre>\n\n` to the original file with its true Snapshot line removed. The independent parser treated Snapshot as raw HTML, but RI again built and verified successfully. A BOM before a genuine first heading also causes a false refusal even though the parser sees that heading. The five-section guard must preserve active Markdown semantics regardless of the UTF-8 signature. The candidate suite contains ordinary front matter and no BOM fixtures. The independent BOM-front-matter probe confirms that its special-case handling works.

Treatment: normalize a single file-initial BOM consistently for plain Markdown detection, or explicitly reject a BOM before entering the existing guard. Keep the original bytes for the byte bound. Add a BOM-prefixed opener negative to the existing `NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail` and a corresponding valid/canonical positive if the decision is to support a BOM. Keep the suite in the navigation job and issue-188 CONTINUITY selector in the owning acceptance job. Recheck the fix on the corrected source.

## Reproduced dispositions

| Oracle scenario | Candidate CLI and independent result |
| --- | --- |
| Original WB-01 raw HTML pre, and pre opener followed by a comment | Build exit 1 with Raw HTML blocks are unsupported. Parser had no Snapshot heading. |
| Original WB-01 comment-prefix synthetic heading, fenced Snapshot, and U+2028 before heading text in the same line | Build exit 1 with Missing continuity section ## Snapshot. Parser had no Snapshot heading. |
| Front matter containing apparent Snapshot, with and without a UTF-8 BOM | Build exit 1 with Front matter is unsupported. Pandoc with YAML metadata extension had no Snapshot heading. |
| Raw HTML opening at three spaces | Build exit 1 with Raw HTML blocks are unsupported. Parser had no Snapshot heading. |
| Genuine candidate, genuine headings alongside comments/autolinks/fenced and indented samples, and inline HTML | Build exit 0. Parser reported the genuine Snapshot heading. |
| Multibyte CRLF byte boundary | 8,192 bytes and nine lines pass, 8,193 bytes and nine lines exit 1 with the UTF-8 byte bound. Both have a genuine Snapshot heading. |
| File-initial BOM before raw HTML or fence, or before genuine Snapshot | Three false accepts and one false refusal, detailed in WB-02. |

Default-mode `active_markdown` has the same operation when `plain=False`: `splitlines` remains the source split, both rejections stay gated and projected text always appends. Independently compared the extracted function definitions before/after over 65 tracked candidate Markdown files outside review and six synthetic inputs covering glossary/registry/title behavior, comments, fences, U+2028 and error behavior. No differences in results or errors. Current config has no real glossary or registry sources, so their coverage here is synthetic. Canonical literal headings remain the documented scope.

## Current-source execution and limits

- `python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'`: exit 0, **40/40** in 8.779 seconds. Detached candidate checkout remained clean.
- `python3 tools/check_ri_ci.py verify`: exit 0, 17 checks/19 layers, digest `1a9813f8a6af62dbc20d4bfcb456383b4dffa8cd250037ab8a1c5339c4bba0f3`. Local check explicitly reports live GitHub state unverified.
- `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify`: exit 0 on unmodified candidate. Source-bound acceptance report RI input digest `928d2771475cdcc4e63870a8454cc9a052134a3abe757294137e9aaad6e20a25`.
- Owning policy with `--require-clean --expected-source 65f51b63d8dbd70f4bb4a17f69fec27614b35037`: exit 0 and **5/5** selectors. AC01–AC04 automated-pass, seven external gates pending, closure false. Raw report `/tmp/issue-188-whitebox-r2-owning.iRpHDm`, SHA-256 `77696c71d3f314efcea1a35d22dfa3be353a440a28193c2847a97a0487e64399`.
- Actual CLI fault probe and result logs `/tmp/issue-188-whitebox-r2-probe.py` (SHA-256 `fac6bcf9cec917e258e5a17b39022a0101c14f1cd77123b6ace5f4838431cd1c`) and `/tmp/issue-188-whitebox-r2-probe.log` (SHA-256 `b93daeed5294ec237c04dda6dee243c4870c27ddaf936f9ee21796009248f62d`). Fixture runs intentionally change only MEMORY and its generated views on the exact source archive. Their exit codes and parser observations are in the table and finding above.

No measured branch coverage, native Actions, protected admission, live GitHub/production facts, browser or merge evidence was established in this role.
