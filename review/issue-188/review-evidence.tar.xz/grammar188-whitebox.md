# Issue #188 independent White-box QA

## First judgment

**Changes required.** On candidate `4aded857a634a0b26aa5bc914df465385b92d936`, the targeted unit test and intended ATX, inline-link and comment-marker correction cases pass. Two independent renderers still expose an extra top-level section accepted by the guard, and the raw-HTML restriction stated in the candidate guide is broader than its implementation.

- **P2, AC01 / AC04 — Additional rendered section admitted.** Append a blank line, `Snapshot` and `--------` to the otherwise valid five-section fixture. Pandoc GFM and markdown-it CommonMark both render a sixth top-level H2 named Snapshot. The continuity guard accepts it because its section projection inspects only ATX syntax at `tools/repository_intelligence.py:376`. AC01 retains five active sections. The bounded guard can reserve standalone Setext marker lines outside fences. Keep a negative fixture proving the source rejection and a positive fenced example proving literals survive.
- **P2, AC01 / AC04 — Stated raw-HTML restriction admits a block inside a Markdown container.** Append `> <pre>\n> Literal\n> </pre>` to the valid fixture. Both renderers produce a blockquote containing actual raw HTML, and the guard accepts it. `CONTRIBUTING.md:323` excludes raw HTML blocks from prose, while the detector at `tools/repository_intelligence.py:149` only considers an angle bracket after zero to three spaces. The same mismatch holds for `- <pre>Literal</pre>`. Either implement the stated restriction within the supported grammar or document which line-leading forms the validator rejects and distinguish authoring guidance. These specimens leave the canonical top-level headings visible, so the finding concerns policy-to-guard scope.
- **Contract clarification, AC01 — Low-indentation line inside a list.** Both `- ## Nested` and `- item\n\n  ## Nested` render a nested list H2 and leave the five top-level headings intact. Only the second form fails the candidate guard. Document conservative treatment of low-indentation standalone ATX-looking lines if intentional. No hidden canonical headings were observed in the tested container cases.

## Source binding and execution limits

- Repository `oborskyivitalii/oborskyivitalii`, issue #188, PR #192. Base `0394f52c82a34c304c123aeaee023c5ec44a85b0`, predecessor `eb49a288138c006db3985548158c32f34b0ffca6`, candidate `4aded857a634a0b26aa5bc914df465385b92d936`, tree `592fcdb72a246699d4eb679e0c7e83faecdd94f2`. Detached checkout clean on both sides of the focused unit check.
- Common reviewer prompt blob `26b5d554da6027ff6aff850c2ab6bacb93b9ee38`. White-box prompt blob `f3d5e777711d05fa844052a0c49339eb577a06d1`. Issue intake SHA-256 `53eb844ab52e59fbeaffdcbf96830c62117fd3b600c65cea880fffae97b75739`. Correction diff SHA-256 `b79ea745df333cb6c52ac46579280671cce5b9ef3edff229df8c6d0bd1a2e443`. Candidate file manifest SHA-256 `640f04a0276d2ff16073f3711867069e2a7a1c8b0a79c9eaf3f3dbb411942bde`. All nine listed file hashes verified. GitHub issue intake is the supplied dated artifact. This review does not independently attest live GitHub state.
- Inspected root instructions, README, REPOSITORY-MAP, MEMORY, relevant CONTRIBUTING, .github/ACCEPTANCE.md, issue-188 policy and check-profile mapping. Scoped code inspection covered continuity and its shared active-Markdown function, the existing focused test and ownership consumer. Agent task `/root/grammar188_whitebox`. No historical or peer verdict file inspected. Provider context injection and actual launch request parameters are for the orchestrator's receipt. The first renderer mismatches were sent to the orchestrator before it reported its intended remedy and the requirements adjudication.
- Commands ran read-only against the pinned checkout or against candidate bytes loaded from Git. No browser, release or coverage measurement was performed. UI and delivery evidence are outside this structural test. The orchestrator runs broader suites. No accepted test or implementation was edited.

## Risk-to-test mapping

| AC and structural risk | Independent oracle and case | Check disposition |
| --- | --- | --- |
| AC01, limits weakened or calculated on characters | Independent `wc -l` and `wc -c` over generated LF fixtures, including 120/121 lines and multibyte 8,192/8,193 bytes | Executed. Retain in existing focused navigation unit and issue-188 CONTINUITY. |
| AC01, count or literal syntax drifts | Render each ATX and Setext mutation with Pandoc GFM and markdown-it CommonMark, then inspect top-level rendered H2 tokens | Executed. Existing focused tests cover the ATX correction. Add Setext negative and fenced positive in the existing case matrix. |
| AC01, fence state drops or leaks headings and examples | Both renderers inspect opener type, closer length, and code content after canonical headings | Executed. Existing navigation test and CONTINUITY retain ownership. |
| AC01, HTML-emphasis masking hides raw tags | Both renderers check URI links, literal inline code and backtick-bearing Markdown link destinations. Inspect independently for raw block tokens and unescaped raw tags | Executed. Keep existing cases and settle container scope in CONTRIBUTING and focused tests if enforcement changes. |
| AC01, inline/indented marker misclassified as prose/fence | Both renderers distinguish fenced, inline, indented and quoted comment content, while policy determines which source locations are permitted | Executed. Existing navigation test and CONTINUITY retain ownership. |
| AC04, default active-Markdown behavior regresses | Check non-plain ownership behavior and line-only config independently. Candidate default branch is structurally unchanged from predecessor | Executed. Retain existing enduring ownership tests and the focused navigation case. |
| AC02 / AC03 | Guard outcomes prove format only. Source-bound resumption and lifecycle judgment remain with the owning review roles | Out of this campaign. |

Mapped to SITE-CHECK-PROFILES repository navigation row R and D01–D03. The test is a permanent Navigation regression and is selected explicitly by the owning policy. Cases do not establish branch-coverage metrics. Unenumerated extension syntax, all possible container forms and parser runtime saturation were outside the bounded campaign.

## Focused repository check

`PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=tests python3 -m unittest -v test_repository_intelligence.NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail`

Exit 0. Ran 1 test, 1 passed, zero failures/errors/skips. Runtime 1.018 seconds.

## Independent local campaign

`PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -` with candidate guard and config loaded via `git show <exact-sha>:<path>`. Used `wc -l`, `wc -c`, Pandoc 3.1.11.1 `--from=gfm --to=html`, markdown-it-py 3.0.0 CommonMark tokens/rendering, and expected error prefixes derived from the policy. The CLI's stdin convenience attempt failed before corpus execution, and the supported Python package API replaced it. The completed run and condensed raw results follow.

```text
line inclusive | wc -l=120 | ACCEPT
line overage | wc -l=121 | Continuity line bound exceeded: MEMORY.md; move detail to its owner
UTF-8 inclusive with CRLF | wc -c=8192 | ACCEPT
UTF-8 one-byte overage | wc -c=8193 | Continuity UTF-8 byte bound exceeded: MEMORY.md; move detail to its owner
real authored file | top-level H2 Pandoc=5, markdown-it=5 | ACCEPT
literal duplicate | top-level H2 Pandoc=6, markdown-it=6 | Duplicate continuity section ## Snapshot: MEMORY.md
indented ATX and closing hashes | top-level H2 Pandoc=6, markdown-it=6 | Noncanonical continuity section '  ## Snapshot ###': MEMORY.md
ATX inline emphasis | top-level H2 Pandoc=6, markdown-it=6 | Noncanonical continuity section '## *Snapshot*': MEMORY.md
ATX character reference | top-level H2 Pandoc=6, markdown-it=6 | Noncanonical continuity section '## Snapsho&#116;': MEMORY.md
ATX empty | top-level H2 Pandoc=6, markdown-it=6 | Noncanonical continuity section '##': MEMORY.md
ATX unrelated | top-level H2 Pandoc=6, markdown-it=6 | Noncanonical continuity section '## History': MEMORY.md
missing section | top-level H2 Pandoc=4, markdown-it=4 | Missing continuity section ## Snapshot: MEMORY.md
missing Unicode separator | top-level H2 Pandoc=4, markdown-it=4 | Missing continuity section ## Snapshot: MEMORY.md
backtick fence, short pseudo-closer | top-level H2 Pandoc=5, markdown-it=5 | ACCEPT
tilde fence, nested markup | top-level H2 Pandoc=5, markdown-it=5 | ACCEPT
unclosed fence hides missing section | top-level H2 Pandoc=4, markdown-it=4 | Missing continuity section ## Snapshot: MEMORY.md
paired emphasis with literal brackets | top-level H2 Pandoc=5, markdown-it=5 | ACCEPT
literal angle bracket escape | top-level H2 Pandoc=5, markdown-it=5 | ACCEPT
ordinary link with destination backtick | top-level H2 Pandoc=5, markdown-it=5 | ACCEPT
paired emphasis with link destination backtick and raw tag | top-level H2 Pandoc=5, markdown-it=5 | Raw HTML blocks are unsupported in continuity sections: MEMORY.md
comment marker in paired emphasis inline code | top-level H2 Pandoc=5, markdown-it=5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
indented code comment marker | top-level H2 Pandoc=5, markdown-it=5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
quoted actual comment marker | top-level H2 Pandoc=5, markdown-it=5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
nested list heading on marker line | top-level H2 Pandoc=5, markdown-it=5 | ACCEPT
Campaign exit 1.
```

The exit-1 corpus stopped after 24 observations. The next fixture exposed an oracle harness defect: the Pandoc HTML line-based counter incorrectly classified a nested heading serialized at column one as top-level. Its output contained `<ul><li>…<h2 id="nested">Nested</h2></li></ul>`. The guard was not evaluated by that aborted loop for the remaining cases. The earlier successful targeted renderer probe separately established the Setext and quote findings shown above. The v2 correction artifact uses Pandoc's document AST and markdown-it nesting levels for root-heading counts. Default-mode and no-heading probes are accounted in the v2 correction artifact rather than in the aborted v1 corpus.
