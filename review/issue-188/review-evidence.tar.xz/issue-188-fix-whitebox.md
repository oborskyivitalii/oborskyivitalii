# Issue #188 / PR #192 correction — independent White-box QA

**Verdict: correction blocked for AC01 and the WHITEBOX gate of AC04.** The pinned candidate accepts two canonical ATX duplicates and an actual nested fence. It rejects standalone indented code in two valid contexts and inline code adjacent to an escaped backtick. The current MEMORY passes the maintained guard and both caps; this judgment concerns guard behavior on subsequent handoffs.

## Source and execution identity

- Role execution `/root/fix188_whitebox`, first judgment for this correction. No prior or peer verdict was consulted. Provider context internals and orchestration launch parameters are outside this execution's observation.
- Candidate `067f31651649b5393fa71b1b3dc172c52601b0c3`, tree `b912049fd533609377c24c9590b896987066426b`, clean worktree before and after checks. Compared correction predecessor `5c870fc447ef1ba4cebbfef3cef53834a0af8e2d` and full base `0394f52c82a34c304c123aeaee023c5ec44a85b0`. The native local tracking ref showed the predecessor. Remote state was outside this scoped execution.
- Packet `fix188-review.manifest` SHA-256 `e704f603691c90f7ec369a3dd3cd591d23bb43daa5386c54a7d7d875d0c905fd`, with all 15 entries verified by `sha256sum -c`. Common prompt SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`, White-box prompt SHA-256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`. The root guide, README, repository map, MEMORY, contributing protocol, intake, acceptance policy, producer, config, and mapped continuity test informed the checks.
- Used Pandoc 3.1.11.1 with `pandoc -f gfm -t json` as an independent block/inline syntax oracle. The repository policy supplies which Markdown constructs the guard should accept or reject. Fixtures were appended after a minimal document with all five configured headings unless stated otherwise. The guard call was `check_continuity(config, {"MEMORY.md": body})` using the production section contract, with an AGENTS fixture when supplying the complete repository config.

## Findings

### W1 — Major — alternate whitespace allows two copies of the same active heading

`tools/repository_intelligence.py:379–388` checks exact presence and interpolates the fixed title into its duplicate regex. After all five canonical headings, append `## Open   work` or `## Next<TAB>session`, with a literal tab in the latter. Both candidates passed. GFM reports a second level-two Header with the same inline title tokens as the canonical section and IDs `open-work-1` and `next-session-1` respectively. The positive control `  ##<TAB>Snapshot ##` reports a duplicate, while the same literal heading in either a fenced or an indented code example passes. The new duplicate detection closes the tested outer-delimiter variation, while interior Markdown whitespace remains a bypass. Preserve the configured canonical spelling requirement for primary presence and normalize horizontal title whitespace when counting active ATX equivalents. Extend the existing CONTINUITY test with both multiword cases. AC01 and AC04 remain open.

### W2 — Major — list context accepts a nested fence and rejects standalone indented code

`tools/repository_intelligence.py:135–146` bases the classification of indented lines on a Boolean for the last nonblank, non-four-space line. These are exact independent fixtures, separated from the five headings by one blank line.

~~~~markdown
- Example
  continuation

    ```markdown
    ## Snapshot
    ```
~~~~

Pandoc reports one BulletList item with a paragraph and a fenced CodeBlock with class `markdown`. The candidate accepts. The two-space continuation clears `in_list`, so the actual nested fence bypasses the column-one refusal. The predecessor rejected the same input.

~~~~markdown
100. Example

    ```markdown
    ## Snapshot
    ```
~~~~

Pandoc reports an OrderedList followed by a separate top-level indented CodeBlock whose contents include the literal backticks. The four-space indent falls below the list item's five-column content indent. The candidate rejects with `Code fences must start at column one in continuity sections: MEMORY.md`. Increasing each code line to five spaces moves it into the list, at which point the oracle reports a nested fenced CodeBlock and the same guard rejection is correct. Replacing the first line of the four-space case with `* * *` yields a GFM thematic break plus a standalone indented CodeBlock, and the guard again rejects the literal example. The false rejections predate the correction and persist.

Track actual container continuation and marker width, with thematic-break precedence, or use a bounded source recognizer that distinguishes these forms. Add a matched standalone/nested width pair and a continued-list case to CONTINUITY. AC01's supported Markdown and AC04's WHITEBOX gate remain open.

### W3 — Moderate — escape before an adjacent code opener causes false refusal

`tools/repository_intelligence.py:94–105,153–158` masks the escaped backtick, but its opening run's negative lookbehind still sees the original escaped backtick directly before the run.

~~~~markdown
<em>\``<details>`</em>
<em>\```<details>``</em>
~~~~

Run each line separately at paragraph start. In both cases GFM emits paired raw inline emphasis tags enclosing a literal backtick and one Code inline containing `<details>`. The guard rejects both as raw HTML blocks. The predecessor also refused these cases. Ordinary equal-length spans, including a double-delimited span with a single interior tick, are accepted. The exposed `<details>` control and the wrong-length delimiter control are still rejected. Recognize escaped ticks and the following delimiter as consecutive tokens while retaining raw-tag refusal. Add one adjacent-escape case plus the existing exposed-tag controls to CONTINUITY. This affects AC01's documented inline-code support and the WHITEBOX gate.

## Risk-to-test and observed accounting

| Risk and AC | Independent oracle and executed partition | Current result and maintained route |
| --- | --- | --- |
| AC01 byte/line boundary or wrong measurement | Python UTF-8 byte counts and physical LF/CRLF fixture counts. Tested 8,192/8,193 bytes with multibyte UTF-8 and CRLF, and 120/121 lines. | 6/6 matched. Existing Navigation RI suite and the owning CONTINUITY selector. |
| AC01 false section presence or duplicate | GFM AST for ATX variants and code blocks. Additional missing-heading probes put the required heading only in top-level tilde-fenced or indented code. | Outer delimiters and code-literal cases matched. Two active duplicates passed as described in W1. Add cases to Navigation RI/CONTINUITY. |
| AC01 literal or unsafe inline HTML | GFM AST for links inside/after paired emphasis, equal-length code spans with other tick runs and tag-looking literals, real raw tags, unmatched runs, escaped opener and comment cases. | Supported ordinary cases and refusal controls matched. Two escaped-tick code cases failed as described in W3. Add one to Navigation RI/CONTINUITY. |
| AC01 nested or literal fence | GFM AST for a top-level fence, standalone indented code, an ordered-list pair straddling the content column, bullet-list continuation, and thematic-break context. Direct quote and initial BOM fence probes used the guard policy. | Three contextual mismatches in W2. Direct nested and standalone controls matched. Add cases to Navigation RI/CONTINUITY. |
| AC01 inactive sections and unsupported block/marker syntax | Byte-preserving fixtures for a first-line front-matter marker, raw HTML block, escaped HTML comment marker, fenced literal comment, active paragraph comment and first-line BOM fence. | Expected refusals and fenced-literal acceptance observed. |
| AC02 worked handoff admission | `MEMORY.md` passed the same guard at 3,388 UTF-8 bytes and 29 lines. | Live pointers and lifecycle remain within the separately owned HANDOFF/LIFECYCLE judgments. |
| AC04 legacy scanner behavior | `git show <ref>:tools/repository_intelligence.py` then `compile` for all three pinned revisions. Compared default-mode results for ordinary/indented fences, multiline comments, comment inside code, unmatched comment-bearing code, BOM/Unicode line splitting, raw HTML, and front matter. | 8/8 identical across base, predecessor and candidate, including the expected unmatched-code error. Navigation RI regressions remain the existing integration route. |

Executed `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=tests python3 -m unittest -v test_repository_intelligence.NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail`. Exit 0, one test passed in 0.941 s. This test runs a temporary-fixture RI build and currently misses W1–W3. The Pandoc/guard probe ran 21 fixture pairs and exited 0 while printing observations, with 14 expected matches and seven mismatches listed above. The separate asserted guard and legacy script exited 0, with 14/14 guard observations and 8/8 cross-revision observations matching. A seven-case predecessor/current probe confirmed the correction now catches the outer-delimiter duplicate, regresses the continued-list fence, and retains the other reported mismatches. `git diff --check 0394f52..HEAD` exited 0.

This execution measured fixture outcomes. It did not measure branch coverage, run the complete RI/CI suite, validate remote or hosted state, adjudicate all Markdown extensions, or accept the other role or delivery gates. The scoped review changed no repository source, tests, or remote state.
