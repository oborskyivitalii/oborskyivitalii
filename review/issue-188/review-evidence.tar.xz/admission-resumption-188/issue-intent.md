## Original intent — 10 November 2026

The maintainer wants MEMORY.md to be a concise, continuously updated starting point for a new chat: current task, completed work, stopping point and next action. It must have a fixed size rather than accumulate a task diary.

Explicitly split from the original combined #187 at the maintainer's request. [Preserved original intake](https://github.com/oborskyivitalii/oborskyivitalii/issues/187#issuecomment-6770665091). Transfers original **AC03** and the MEMORY-specific obligations of **AC06**, preserving intent; this issue's stable AC IDs below are its local mapping. No implementation/acceptance has occurred.

## Baseline and scope

Inspected main ca756417590b9176f9fc33428321ffe1f64158cc; revalidate before implementation. MEMORY is 2,236 bytes / 40 lines. A 120-line cap and five sections already exist. However, its PR186 staging/a9f5769 handoff is stale after production delivery. The primary defect is lifecycle freshness.

Own T4 continuity changes: MEMORY.md; AGENTS.md/CONTRIBUTING.md where maintenance is specified; continuity configuration in .github/repository-intelligence-config.json; existing tests/test_repository_intelligence.py and relevant acceptance/RI/CI companions. Read README, AGENTS, CONTRIBUTING, REPOSITORY-MAP, MEMORY and applicable owners before editing. Generated views are regenerated, not hand-edited.

Keep Snapshot, Decisions, Open work, Next session, Maintenance and the existing 120-line hard cap. Proposed additional cap: **8 KiB UTF-8**, to stop long lines bypassing the budget. This number is a recommendation to validate during requirements/source review, not a previously accepted maintainer limit.

At meaningful completed work steps, interruption/handoff and observed staging/production/closure transitions, replace obsolete entries with:
- verified date/source ref and owning issue/active PR;
- concise completed/current step and material decisions;
- blockers or remaining acceptance;
- next concrete action and exact issue/PR/review/check pointers.

Preserve a few useful pointers to concurrent active work. Detailed logs, experiments and older states stay in their existing issue/PR/versioned review artifact. Do not append a diary, duplicate every issue, create another handoff file/service, or make MEMORY a source of live authority. Correct existing stale claims from freshly retrieved live sources.

## Acceptance criteria

### AC01 — Enforced bounded format
- [x] Five existing sections and <=120 lines are retained. The reviewed byte cap is enforced on UTF-8 bytes. Oversize lines/bytes and missing sections fail the maintained guard, including exact-boundary/non-ASCII cases where relevant.
Checks: extend existing NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail rather than create a parallel validator.
External gate: requirements review resolves the proposed byte cap.

### AC02 — Useful and current worked handoff
- [x] Actual worked MEMORY identifies current owner/ref, completed/current step, stopping point, blockers/open AC and next concrete action with durable evidence pointers. Obsolete PR186/staging/main claims are replaced after live verification; concurrent work retains sufficient pointers.
Checks: compare handoff against exact current issue/PR/ref/run evidence.
External gate: independent review can resume the task from the handoff; format tests alone cannot prove truth.

### AC03 — Lifecycle maintenance in the existing protocol
- [x] Canonical instructions require concise replacement during meaningful progress, interruption/handoff and actual delivery/closure transitions; stale entries are removed. Historical detail remains with the existing owners; no accumulating or competing memory mechanism is introduced.
Checks: applicable existing protocol/acceptance tests and independent review of the real handoff workflow.
External gate: maintainers' existing decisions remain distinct from planned next steps.

### AC04 — Reviewed exact-source delivery
- [ ] Applicable CODE-STYLE IDs and bounded guard are mapped before code/config edits. Existing acceptance policy, RI/catalog/CI companions and test-impact allocations are updated where affected; RI build/verify and relevant continuity/coupling checks pass on the exact candidate. Required four independent roles and correction review are recorded. Delivery uses the trusted route selected for the full diff; completion distinguishes merged protocol from actual handoff facts.
Checks: tests/test_repository_intelligence.py, affected RI/CI/style/owning checks; website work only if the actual ownership requires it.
External gates: source-bound four-role review and applicable merge decision.

## Plan and dependencies

Recommended order within the three-way split: repository intelligence/capacity first, this MEMORY issue second, reusable article animation #187 third. RI/capacity owner: [#189](https://github.com/oborskyivitalii/oborskyivitalii/issues/189).

The MEMORY task is logically independent of the animation. Capacity recovery is an execution prerequisite only if the complete candidate/check evidence cannot fit under current RI bounds. RI work should deliver minimum safe headroom first, rather than force MEMORY to wait for optional archive cleanup. Rebase on its accepted canonical navigation/config before updating shared continuity configuration.

1. Revalidate live state and obtain requirements review; inspect the actual continuity consumers.
2. Make the bounded protocol/guard correction and update the real task handoff.
3. Review test impact, run affected checks and independent reviews; deliver separately.
4. At handoff refresh MEMORY and this issue's actual acceptance state.

Separate owning PR with Refs to this issue. No article-motion changes, broad RI redesign, archive batch, website staging or production activation bundled into this scope.


