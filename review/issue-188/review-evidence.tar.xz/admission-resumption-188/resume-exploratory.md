# #188 / PR #192 — independent Exploratory / Interaction QA

First result, 2026-11-11. **Needs correction for AC02 and the AC04 review gate.** A successful issuer run can expose the same-named, exact-attempt `Staging admission` aggregate before the required PR-event conditional check exists. The handoff leaves the operator without an identity criterion for deciding whether the refresh is already complete.

## Input and scope

| Evidence | Identity |
| --- | --- |
| Repository and owner | `oborskyivitalii/oborskyivitalii`, issue #188, PR #192 |
| Protected base | `0394f52c82a34c304c123aeaee023c5ec44a85b0` |
| Predecessor | `e220fdd` |
| Candidate | `084f3f8ba93681cfccca4bac80b4b66cd623b8e5` |
| Candidate tree | `e8f4c191732aedaf47d4a447a6d6d7ffc18d754e` |
| Predecessor-to-candidate binary delta SHA-256 | `d5524b8ad7fc5ca6a446acd191b84083d6fc6df9ba72f3907d8532dfd683be81` |
| Supplied intent SHA-256 | `cebc093fab86eb0de972b6a946471047d820ca46f6745f1fe4e52a214a34391d` |
| Common reviewer prompt SHA-256 | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| Exploratory prompt SHA-256 | `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a` |
| Candidate `MEMORY.md` SHA-256 | `c1d285a6b8585ebf18f55ed24aa3d483909aa543b2a3c4c9ad58275115c888cf` |

Charter covered up to 12 operator states in one bounded desktop-free pass. I started from the candidate handoff and used its linked staging and continuity guidance, then cross-checked the available workflow, check and artifact identities in the protected source. The protected controller and workflow files read here have identical bytes at base and candidate. The supplied live snapshot placed PR #192 at open Draft on `e220fdd`, with correction publication pending. I did not read historical verdicts, the live issue thread or peer output. No owner action, native dispatch, live check result, Ready transition, merge or production activity was observed by this execution. No website interaction is implicated by this change to operator prose.

## Tabletop execution

| Case | Expected next action | Observed reading of exact candidate |
| --- | --- | --- |
| 1. Open Draft at predecessor, intended correction unpublished | Keep Draft, finish review and affected local checks, then publish the correction. | Pass. Steps 1–3 resolve to the existing PR, then wait for reviewed exact publication before Ready. |
| 2. Ready, exact reviewed source, no current issuer attempt | Dispatch once as owner from `main` for PR #192 with the full reviewed head. | Pass. Steps 4/4a establish those inputs and require recording the run link. |
| 3. Matching issuer queued or running with dispatch record | Wait, even if an old green or no dedicated App check is visible. | Pass. Step 4a directs waiting and names the dispatch link or owner record as the bridge to pre-check visibility. |
| 4. Matching issuer cancelled, failed, or completed with an App refusal | Diagnose and resolve before a retry. A green workflow with a failed App decision remains a refusal. | Pass with the linked owner guide at `guides/SITE-STAGING.md:168–173`. Step 4a asks for both the issuer and the dedicated App check. |
| 5. Current issuer valid; only the issuer aggregate is green; conditional refresh absent | Reuse the issuer result and make the one owner PR description edit. | Fail. The green issuer aggregate is named `Staging admission` and carries the same head, base, App issuer run and attempt. Step 4b supplies no criterion to disqualify it, so an operator can skip the edit. |
| 6. Matching PR-event conditional refresh queued or running | Wait for the existing refresh and the associated latest Owning run. | Pass when the conditional workflow run has been identified. Step 4b directs waiting and step 4c waits for the latest Owning result. |
| 7. Matching PR-event conditional refresh failed or cancelled | Diagnose the precise run and its dependencies before retry. | Pass when the run is correctly identified. An earlier Ready job that ran before the current App result, or an older attempt's failed refresh, does not describe failure of the current refresh. The handoff needs the discriminator in the finding below to make this operational. |
| 8. Conditional check green; latest edit-triggered Owning run pending or failed | Hold merge until current Owning succeeds. | Pass. Step 4c explicitly includes the Owning run triggered by the description edit. |
| 9. Current genuine conditional and latest Owning both green | Reuse current proof. Authorized protected merge with expected-head lease. | Pass when the genuine run has been established. The linked guide supplies the expected-head lease and normal two-parent repository route. No repeat dispatch or edit is called for. |
| 10. Live head or protected `main` moved | Re-enter source comparison and current exact review/check route. | Pass. Steps 2–4 route back to source review, update from current `main` if needed, and refuse stale evidence. |
| 11. Merged | Verify actual merge commit, reviewed tree and unchanged public bytes, then refresh the dated handoff. | Pass. Step 1 goes directly to step 5. The guide and `.github/workflows/site-staging-merge.yml` expose the merge identity route. |
| 12. Closed without merge | Stop admission and confirm the next action with #188. | Pass. Step 1 is explicit. |

## Finding and treatment

**Medium, blocking this handoff’s operator resumption check.** `MEMORY.md:28–29` uses “conditional” and “matching” without an observable distinction between the PR-event consumer and the issuer’s aggregate. Reproduction on paper uses current head `H`, base `B`, issuer run `R/1`, the dedicated App check for `R/1`, successful current Source/Navigation/Owning, and no description edit. The issuer itself calls `beginChangeAdmission` and `finishChangeAdmission` (`.github/workflows/change-admission.yml:63–73,151–164`). It creates an Actions App 15368 check literally named `Staging admission` at `H` with external identity `change-admission/R/1/192/B`, then marks it successful (`tools/staging/admission.cjs:364–399,401–437`). Hence a name, App, head, base, attempt and green-status match can all hold before a valid conditional result. `guides/SITE-STAGING.md:264–270` directs a description edit, but the candidate asks the operator to skip it if a matching conditional result is present and does not show how to identify one. This is a human action selection failure. The outcome of a protected merge attempt in that state was not tested.

Require the eligible PR-event `pr-admission` job in `.github/workflows/site-color-review.yml:33–80` and the `staging-admission.json` artifact whose `check`, `run`, `attempt`, and `protectedMain` refer to the current dedicated App result (`tools/staging/admission.cjs:336–354`, `tools/quality/delivery-admission.cjs:509–539`). Preserve the one-edit route when that consumer is absent. A PR-event job queued for the recorded owner edit can be correlated before its artifact exists. If the issuer inventory is ambiguous before check creation, confirm the owner dispatch record before treating the attempt as absent. Keeping the two run links in the existing dated checkpoint is sufficient.

## Executed checks and dispositions

- `node --test tests/delivery-admission.test.cjs tests/prototype-admission.test.cjs` on Node `v24.22.1`: 34 passed, 0 failed, 0 cancelled, 0 skipped. The tested files and relevant controller/workflow inputs matched the pinned candidate. In particular, `tests/prototype-admission.test.cjs:596–640` confirms that the dispatch can complete its own aggregate without a PR-event refresh. These are existing permanent `pr-targeted`, `staging`, and `production` suites under `tools/quality/test-profiles.json:1727,2806`. Keep both suites and their existing changed-source allocation.
- Re-run the human case in the next AC02 tabletop using the two producer identities and a genuine PR-event artifact as contrasting fixtures, including both-green reuse. This is a manual independent review case under #188 and the test-impact protocol. A prose keyword test would not exercise the ambiguity. Native exact-head ownership and protected merge remain external AC04 gates.
- The candidate had 34 lines and 4,768 bytes. This is a direct size observation, not an independent validation of the Markdown/RI guard or full AC01 acceptance. AC03’s replacement route is visible in step 5 and Maintenance. This review does not attest the full candidate’s acceptance, hosted behavior, or completed delivery.
