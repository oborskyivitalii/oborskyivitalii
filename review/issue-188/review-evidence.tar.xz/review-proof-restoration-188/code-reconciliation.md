# Code / Artifact reconciliation — issue #188, PR #192

Candidate `f67242ebbaa8a3c2c1b526a1d887b4e671c3a386`, tree `ce2f8849eac518ab700193fe2be8e0e73fc64d08`, compared with protected base `0394f52c82a34c304c123aeaee023c5ec44a85b0`.

I preserved the first independent judgment in `code.md` with SHA-256 `49cae27bbe584de37e90555598a848dc92c313c7b1e79881019c22c2acb5b4cb` before reading the GitHub issue body or its embedded historical review summaries. After preserving that result, I read the issue body to reconcile the finding with the original scope and saw historical summaries in that follow-up read. This is a reconciliation of the first judgment.

The reproduction stands. A fixture with 120 LF-terminated physical lines and a U+2028 inside a prose line has 121 lines under Python `str.splitlines()` and fails the guard. The Markdown lexer uses CRLF, CR and LF for heading detection. The protected base has the same `len(body.splitlines())` cap check and therefore the same refusal. The issue’s original scope says to keep the existing 120-line hard cap, AC01 says the 120-line cap is retained, and the accepted decision adds an inclusive 8,192-byte cap alongside it. The protected base supplies the preserved line-count convention. The new lexer’s Markdown line convention does not change that existing behavior.

**Disposition:** Revise the first judgment’s AC01 objection to a nonblocking clarification under the owning scope. No parser correction is required. An optional documentation clarification can state that the cap counts Python-recognized line separators, while heading detection recognizes CRLF, CR and LF. No change to the independent AC02, AC03 or pending AC04 delivery observations follows from this reconciliation.
