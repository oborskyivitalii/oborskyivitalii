# Exploratory / Interaction QA affected correction — E01, #188 / PR #192

**E01 resolved on the local corrected candidate.** The correction removes my AC02/AC03 operator-protocol objection. AC04 remains pending exact-source review, native admission and protected delivery. This is an affected recheck by the same nonauthor reviewer after the first judgment.

## Source and scope

- Native detached checkout `/workspace/scratch/665981ee9898/review192-evidence`, clean. Correction `718e1893318d5c7e51b19f9a6be0bf2634231bb1`, tree `6e498191bc2ee3a2ca1bd7f878247cd610a991df`, predecessor `f67242ebbaa8a3c2c1b526a1d887b4e671c3a386`, protected comparator `0394f52c82a34c304c123aeaee023c5ec44a85b0`. Independently computed predecessor-to-correction binary diff SHA-256 `04d9b49dd0e17702038ac3d4272c14d1b008fa7b24ee6477483f5a4939255dd7`.
- Original first result `/tmp/issue188-receipts-12/exploratory.md` remains intact, SHA-256 `1d9c7a543565453fa2390c9806f0c7a7c54526ae86b0061f3e3ac7b06708d354`. Common and role prompt blobs are unchanged at `26b5d554da6027ff6aff850c2ab6bacb93b9ee38` and `8b07e0a4c59c81b4efc8806c1043c631775eed32`.
- The affected semantic surface is the new canonical lifecycle paragraph at `CONTRIBUTING.md:344–351`. Rewalked the unchanged routes in `AGENTS.md:85–90` and `MEMORY.md:18,23–30` against the workflow and control sources inspected in the first result. README, AGENTS, MEMORY, issue policy, RI guard, classifier, admission modules and workflows are unchanged across the correction. The diff also contains two generated/coverage changes and two review-evidence changes. Their contents were outside this E01 operator judgment. No peer verdict, issue/PR body or comment read was needed.

## Affected operator walkthrough

| Checkpoint or interruption | Expected and observed in the corrected route |
| --- | --- |
| No matching issuer, or the issuer is running | Check the current PR/head/base/attempt. Reconcile unclear work with the owner, dispatch once if missing, and wait for matching in-flight work. Keep a dated checkpoint comment and the tracked handoff at its reviewed identity. |
| Owner admission succeeded and the session ends before refresh | Record the bound App check, run and attempt in the linked PR checkpoint. The canonical rule now explicitly keeps tracked MEMORY unchanged during this interval. Resume by checking for matching conditional evidence, then have the owner edit the description once only if refresh is missing. A checkpoint comment is the worked recording destination and the description edit is the refresh trigger. |
| Owner refresh was requested but queued, failed or cancelled | Record the interruption in the checkpoint while preserving the reviewed source. Reconcile and wait for matching active work, or diagnose a failed/cancelled current attempt before retrying. The exception does not authorize using older evidence or requesting a duplicate. |
| Matching refresh and latest Owning acceptance succeeded, then interruption | Record the result in the checkpoint and preserve the exact head. The next session checks current App/base/attempt and Owning results and reuses them if current. A new source commit merely to refresh MEMORY is no longer called for. |
| The pointer needs repair, candidate head moves, or protected main moves | Correct the tracked handoff when an actual pointer/source change requires it, then revalidate the new head. Base movement independently requires revalidation. The existing return to source verification and protected controller checks continue to apply. |
| Delivery has been observed | Record verified delivery promptly in the dated checkpoint and reconcile the tracked handoff against the observed result. The exception ends at delivery and does not displace the ordinary progress/interruption/closure lifecycle. |

The previously ambiguous instruction had two plausible actions after a successful bound owner step. The correction identifies the interim record, states when to preserve tracked MEMORY, and says when to refresh it even if that requires fresh evidence. No remaining E01 issue observed in the scoped walkthrough.

## Execution and limits

- `git diff --check` passed, RI verify reported fresh, and RI/CI coupling passed 17 checks across 19 layers (source digest `e45951e850f4e2f5fc9521853203f45303d303c2a87008a062660bc0d23d70b9`). The existing HANDOFF/LIFECYCLE manual gates own these tabletop cases. No new automated campaign was introduced.
- At 05:30:34 UTC, read-only `git ls-remote` still showed the live PR at the predecessor and main at the protected comparator. Thus earlier native checks remain observations about the predecessor. This correction walkthrough demonstrates the amended operator instructions against the exact local source. It supplies neither correction-head native admission, a maintainer decision, nor merge/postmerge evidence. AC01's earlier Markdown results were reused based on unchanged MEMORY and guard bytes.
