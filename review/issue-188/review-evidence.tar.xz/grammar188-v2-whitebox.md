# Issue #188 independent White-box QA correction recheck

## Verdict

**Pass within the bounded structural scope.** The prior Setext blocker is fixed, the candidate detects comment markers in both supported fence opener types, and the documented raw-HTML and low-indentation ATX scopes match tested behavior. None of the rechecked positive Markdown specimens lost its top-level canonical section structure.

## Source and scope

- Repository `oborskyivitalii/oborskyivitalii`, issue #188, PR #192. Base `0394f52c82a34c304c123aeaee023c5ec44a85b0`, prior reviewed candidate `4aded857a634a0b26aa5bc914df465385b92d936`, recheck candidate `69b6e7f7aa85bfbf93bb969a648ea22a71d7e8ab`, tree `5b9c58bb6a2ad5d0baacbfde1afc4d63bb142939`. Detached checkout clean.
- Common contract blob `26b5d554da6027ff6aff850c2ab6bacb93b9ee38`. Role prompt blob `f3d5e777711d05fa844052a0c49339eb577a06d1`. Issue intake SHA-256 `53eb844ab52e59fbeaffdcbf96830c62117fd3b600c65cea880fffae97b75739`. Correction diff SHA-256 `113b754e053372bd1697b84c625f50791047e70944e0006eeb7b9ee0203c5c25`. Candidate manifest SHA-256 `a01edd58ba1d5bda8f6ff99b92b706d16a712219b76575aa8f0df9e5a7e3bc54`. All nine manifest entries verified.
- Agent task `/root/grammar188_whitebox`, continuation after own first judgment. The orchestrator communicated the Requirements adjudication of Setext and reported the fence-info risk before this recheck. Prior report preserved in `grammar188-whitebox.md`. No peer output file or historical verdict was opened. The orchestrator owns launch receipt and assurance about provider context internals.
- Inspected the delta to CONTRIBUTING, acceptance policy, continuity producer and existing tests. No repository edits, external writes, coverage measurement or claims about live GitHub, delivery or merge. Current authored MEMORY render is exercised. Its facts and ability to resume remain with AC02/HANDOFF.

## Findings and check allocation

| AC and risk | Observable result | Disposition |
| --- | --- | --- |
| AC01, a Setext H2 adds a duplicate or extra section | Both renderers produce a sixth H2 for the indented hyphen underline, and the candidate rejects it before ATX counting. Equals underlines are reserved, and standalone `***` still renders a horizontal rule. | Existing navigation unit and issue-188 CONTINUITY. |
| AC01, comment marker in a fence opener is accidentally skipped as fenced content | Both renderers classify backtick and tilde opener info as metadata. The guard rejects the marker before opening fence state. Once in fenced content, the guard retains literals, ignores their heading syntax and follows delimiter kind and minimum length. | Existing navigation unit and issue-188 CONTINUITY. |
| AC01, stated and observed raw-HTML/ATX boundaries differ | Line-leading raw block forms reject. Nested list and quoted raw blocks still render and pass, consistent with the documented automated scope and separate authoring restriction. The documented conservative low-indentation ATX rule rejects a list continuation even when the render shows a nested H2. | Verified through local independent renderers. This result does not certify general Markdown or raw-HTML parsing. |
| AC01, correct structural rejection accidentally broadens beyond the supported grammar | Regular Markdown links remain accepted. Paired HTML emphasis with literal brackets and URI autolink remains accepted. Inline/indented comment markers reject. | Independent reruns of representative unchanged cases. |
| AC01 / AC04, collateral regression in bounds or default ownership path | Inclusive and over-limit boundaries pass/fail at independently counted bytes and lines. Shared ownership continues to preserve code literals, ignore comments and reject unmatched comment-bearing code. The AGENTS line-only fallback does not run MEMORY's grammar. | Existing Navigation focused test, enduring ownership selector and local probes. |

The correction changes the opener/marker order and adds a Setext preflight. The exact-byte line and byte checks, inline emphasis mask and final ATX classifier are unchanged from the previous source. Their prior evidence was reused alongside representative exact-candidate rechecks. Navigation profile row R and D01–D03 own the unit-level cases. No further test is requested from this role for the examined grammar.

## Command evidence

- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=tests python3 -m unittest -v test_repository_intelligence.NavigationSafetyTests.test_memory_and_agent_bounds_and_required_sections_fail test_issue_acceptance.IssueAcceptanceTests.test_selector_inline_code_comment_literals_cannot_change_owner` exited 1. The focused continuity test passed. The second selector failed at lookup because the supplied class name was wrong. No candidate behavior failed in the loaded test.
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=tests python3 -m unittest -v test_issue_acceptance.AcceptanceRunnerTests.test_selector_inline_code_comment_literals_cannot_change_owner` exited 0, one test passed in 0.320 seconds with no failures/errors/skips. Candidate SHA/tree and clean status rechecked afterward.
- The first independent v1 corpus stopped at its Pandoc HTML line-based counter because Pandoc puts a nested heading at column one in serialized HTML. The affected V2 corpus counts direct root Header nodes from Pandoc's GFM JSON AST and CommonMark's level-zero heading tokens. It renders to HTML separately for case fragments.

```text
actual MEMORY | H2 5/5 | ACCEPT
Setext duplicate with single hyphen and indentation | H2 6/6 | Setext underline markers are unsupported in continuity sections: MEMORY.md
Setext duplicate with many hyphens | H2 6/6 | Setext underline markers are unsupported in continuity sections: MEMORY.md
Setext equals title | H2 5/5 | Setext underline markers are unsupported in continuity sections: MEMORY.md
standalone asterisk rule | H2 5/5 | ACCEPT
ATX section inside list continuation | H2 5/5 | Noncanonical continuity section '  ## Nested': MEMORY.md
ATX section on list marker line | H2 5/5 | ACCEPT
backtick info comment marker | H2 5/5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
tilde info comment marker | H2 5/5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
comment, Setext, and ATX literals in backtick body | H2 5/5 | ACCEPT
comment and Setext literals in tilde body | H2 5/5 | ACCEPT
marker immediately after closing fence | H2 5/5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
nested fence unsupported | H2 5/5 | Code fences must start at column one in continuity sections: MEMORY.md
fence still hides missing section | H2 4/4 | Missing continuity section ## Snapshot: MEMORY.md
raw leading HTML at indentation zero | H2 5/5 | Raw HTML blocks are unsupported in continuity sections: MEMORY.md
raw leading HTML with three spaces | H2 5/5 | Raw HTML blocks are unsupported in continuity sections: MEMORY.md
raw block in quote, outside automated opener scope | H2 5/5 | ACCEPT
raw block in list, outside automated opener scope | H2 5/5 | ACCEPT
quoted comment still rejected | H2 5/5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
inline marker still rejected | H2 5/5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
indented marker still rejected | H2 5/5 | HTML comment markers are unsupported in continuity sections: MEMORY.md
normal Markdown link | H2 5/5 | ACCEPT
paired emphasis with safe bracket literals | H2 5/5 | ACCEPT
raw tag after link destination backtick | H2 5/5 | Raw HTML blocks are unsupported in continuity sections: MEMORY.md
line inclusive | wc -l=120 | ACCEPT
line overage | wc -l=121 | Continuity line bound exceeded: MEMORY.md; move detail to its owner
CRLF UTF-8 inclusive | wc -c=8192 | ACCEPT
CRLF UTF-8 overage | wc -c=8193 | Continuity UTF-8 byte bound exceeded: MEMORY.md; move detail to its owner
default inline literal | '`<!--`\nRefs #188'
default actual comment | '\n\n\nRefs #188'
default indented marker | 'Refs #188'
default indented fence with comment info | 'Refs #188'
default unmatched comment-bearing span | Unsupported comment-bearing multiline/unmatched code span
missing headings fallback | ACCEPT
empty headings fallback | ACCEPT
TOTAL 35 probes: 24 dual-renderer, 4 independent bounds, 5 default-mode and 2 no-heading fallback. All observed expected outcomes.
Campaign exit 0.
```
