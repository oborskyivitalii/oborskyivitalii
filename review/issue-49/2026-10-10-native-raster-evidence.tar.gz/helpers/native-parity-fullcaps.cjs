'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root='/workspace/scratch/c645f383c871/author-site';
process.env.SITE_PUBLIC_DIR='/workspace/scratch/c645f383c871/issue49-baseline/public';
const pw=require(root+'/tools/quality/toolchain/node_modules/playwright');
const wk='/root/.cache/ms-playwright/webkit-2359/minibrowser-wpe';
const sources=[fs.readFileSync('/workspace/scratch/c645f383c871/baseline-texture.cjs','utf8'),fs.readFileSync(root+'/site/effects/embedded-texture.cjs','utf8')];
const factories=sources.map(s=>s.slice(s.indexOf('module.exports = ')+17).trim().replace(/;$/,''));
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
async function main(){
 const {server,url}=await require(root+'/tools/quality/serve.cjs').start();
 const browser=await pw.webkit.launch({executablePath:wk+'/bin/MiniBrowser',env:{...process.env,LD_LIBRARY_PATH:'/workspace/scratch/c645f383c871/browser-deps/usr/lib/x86_64-linux-gnu:/workspace/scratch/c645f383c871/browser-deps/lib/x86_64-linux-gnu:'+wk+'/lib:'+wk+'/sys/lib',WEBKIT_EXEC_PATH:wk+'/bin',WEBKIT_INJECTED_BUNDLE_PATH:wk+'/lib',WEBKIT_INSPECTOR_RESOURCES_PATH:wk+'/share',WEBKIT_FORCE_COMPLEX_TEXT:'1'}});
 const rows=[];
 try{
  for(const spec of [{route:'research',width:1024,height:1366,theme:'light'},{route:'research',width:1366,height:1024,theme:'light'},{route:'research',width:1366,height:1024,theme:'dark'},{route:'index',width:1366,height:1024,theme:'light'},{route:'index',width:1024,height:1366,theme:'dark'},{route:'writing',width:1024,height:1366,theme:'light'}]){
   const context=await browser.newContext({viewport:{width:spec.width,height:spec.height},deviceScaleFactor:2,isMobile:true,hasTouch:true});
   const page=await context.newPage();
   try{
    await page.goto(url+'/'+spec.route+'.html');
    await require(root+'/tools/quality/color-browser.cjs').settled(page,spec.route);
    await page.waitForTimeout(600);
    await page.evaluate(theme=>{const c=document.getElementById('theme-mode');c.value=theme;c.dispatchEvent(new Event('change',{bubbles:true}));},spec.theme);
    await page.evaluate(()=>{const c=document.getElementById('fragment-flight-preview');c.checked=false;c.dispatchEvent(new Event('change',{bubbles:true}));});
    await page.evaluate(()=>{const c=document.getElementById('space-motion');if(c.getAttribute('aria-pressed')==='true') c.click();});
    await page.waitForTimeout(500);
    const samples=await page.evaluate(async factories=>{
     const original=Object.getOwnPropertyDescriptor(HTMLImageElement.prototype,'src');
     const samples=[];const lengths=[];
     Object.defineProperty(HTMLImageElement.prototype,'src',{...original,set(value){if(value.startsWith('data:image/svg+xml;')) lengths.push(value.length);original.set.call(this,value);}});
     try{
      for(const source of factories){
       const firstImage=lengths.length;
       const adapter=Function('return ('+source+')')()();
       const timings=[];const failures=[];
       const asset=await adapter.captureField(document.getElementById('site-content'),{width:innerWidth,height:innerHeight,dpr:1,preparationMs:160,acquisitionMs:80,caps:{owners:32,descendants:1500,textBytes:32768,layerPixels:8000000},onTiming:t=>timings.push(t),onReject:r=>failures.push(r)});
       if(!asset){samples.push({pass:false,svgCharacters:lengths[firstImage],svgCaptures:lengths.slice(firstImage),timings,failures});continue;}
       try{const bytes=asset.canvas.getContext('2d').getImageData(0,0,asset.canvas.width,asset.canvas.height).data;const digest=await crypto.subtle.digest('SHA-256',bytes);samples.push({pass:true,svgCharacters:lengths[firstImage],svgCaptures:lengths.slice(firstImage),timings,failures,width:asset.canvas.width,height:asset.canvas.height,pixelSha256:[...new Uint8Array(digest)].map(v=>v.toString(16).padStart(2,'0')).join(''),png:asset.canvas.toDataURL('image/png')});}finally{asset.dispose();}
      }
     }finally{Object.defineProperty(HTMLImageElement.prototype,'src',original);}
     return samples;
    },factories);
    for(let i=0;i<samples.length;i++){const s=samples[i];if(s.png){fs.writeFileSync('/workspace/scratch/c645f383c871/parity-'+spec.route+'-'+spec.width+'-'+spec.theme+'-'+i+'.png',Buffer.from(s.png.split(',')[1],'base64'));delete s.png;}}
    rows.push({...spec,samples,pixelParity:samples.every(s=>s.pass)&&samples[0].pixelSha256===samples[1].pixelSha256});
   }catch(e){rows.push({...spec,error:e.message,pixelParity:false});}
   finally{await context.close();}
  }
 }finally{await browser.close();server.close();}
 fs.writeFileSync('/workspace/scratch/c645f383c871/native-parity-fullcaps.json',JSON.stringify({kind:'bounded-warm-native-paint-parity',browser:'webkit',factoryHashes:sources.map(hash),baselineArtifact:JSON.parse(fs.readFileSync('/workspace/scratch/c645f383c871/issue49-baseline/artifact.json')),rows},null,2));
 console.log(JSON.stringify(rows.map(r=>({...r,samples:r.samples?.map(s=>({pass:s.pass,svgCharacters:s.svgCharacters,pixelSha256:s.pixelSha256,failures:s.failures}))})),null,2));
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
