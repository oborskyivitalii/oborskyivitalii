'use strict';
const root='/workspace/scratch/c645f383c871/author-site';
const pw=require(root+'/tools/quality/toolchain/node_modules/playwright');
const wk='/root/.cache/ms-playwright/webkit-2359/minibrowser-wpe';
const options={
  executablePath:wk+'/bin/MiniBrowser',
  env:{...process.env,
    LD_LIBRARY_PATH:'/workspace/scratch/c645f383c871/browser-deps/usr/lib/x86_64-linux-gnu:/workspace/scratch/c645f383c871/browser-deps/lib/x86_64-linux-gnu:'+wk+'/lib:'+wk+'/sys/lib',
    WEBKIT_EXEC_PATH:wk+'/bin', WEBKIT_INJECTED_BUNDLE_PATH:wk+'/lib',
    WEBKIT_INSPECTOR_RESOURCES_PATH:wk+'/share', WEBKIT_FORCE_COMPLEX_TEXT:'1'
  }
};
require(root+'/tools/quality/color-browser.cjs').main({tablet:true,launch:()=>pw.webkit.launch(options)}).catch(e=>{console.error(e.stack);process.exitCode=1;});
