'use strict';
const fs=require('node:fs');
const repo='/workspace/scratch/fa77374a3907/author-site',dir='/tmp/issue49-fractal-final-candidate',output='/workspace/scratch/fa77374a3907/issue49-fractal-final';
process.env.SITE_PUBLIC_DIR=dir+'/public';process.env.SITE_ARTIFACT_MANIFEST=dir+'/artifact.json';
const pw=require(repo+'/tools/quality/toolchain/node_modules/playwright');
const artifact=JSON.parse(fs.readFileSync(process.env.SITE_ARTIFACT_MANIFEST));
fs.mkdirSync(output,{recursive:true});
const result={scope:'Actual Chromium138 local frozen candidate; CSS tablet viewport+DPR2 emulation. Lean front-area sums are coverage burden, not polygon-union coverage; front-only excludes back/bevel. No physical iPad or whole performance admission.',artifact,rows:[]};
function observe() {
  window.__visualFrames = [];
  window.__visualStages = [];
  window.SiteEngineStages = true;
  const area = points => points.length < 3 ? 0 : Math.abs(points.reduce((sum, a, index) => {
    const b = points[(index + 1) % points.length];
    return sum + a[0] * b[1] - b[0] * a[1];
  }, 0)) / 2;
  const clip = (points, axis, boundary, positive) => {
    const result = [];
    for (let index = 0; index < points.length; index++) {
      const a = points[(index + points.length - 1) % points.length];
      const b = points[index];
      const insideA = positive ? a[axis] >= boundary : a[axis] <= boundary;
      const insideB = positive ? b[axis] >= boundary : b[axis] <= boundary;
      if (insideA !== insideB) {
        const fraction = (boundary - a[axis]) / (b[axis] - a[axis]);
        result.push(a.map((value, coordinate) => value + (b[coordinate] - value) * fraction));
      }
      if (insideB) result.push(b);
    }
    return result;
  };
  window.__frontMetrics = d => {
    const routes = {};
    for (const bank of d.bank || []) {
      const ids = new Set(bank.groups.flatMap(group => group.ids));
      const faces = d.faces.filter(face => ids.has(face.id));
      const fronts = faces.filter(face => face.face === 'front' && face.alpha > 0);
      const spans = [];
      const visibleSpans = [];
      let areaSum = 0, visibleAreaSum = 0, maxArea = 0, maxVisibleArea = 0;
      let alphaWeightedVisibleAreaSum = 0;
      for (const front of fronts) {
        const points = front.points;
        const span = Math.max(...[0, 1].map(axis =>
          Math.max(...points.map(point => point[axis])) - Math.min(...points.map(point => point[axis]))));
        spans.push(span);
        const fullArea = area(points);
        areaSum += fullArea;
        maxArea = Math.max(maxArea, fullArea);
        let clipped = points;
        for (const boundary of [[0, 0, true], [0, innerWidth, false], [1, 0, true], [1, innerHeight, false]])
          clipped = clip(clipped, ...boundary);
        const visibleArea = area(clipped);
        visibleAreaSum += visibleArea;
        maxVisibleArea = Math.max(maxVisibleArea, visibleArea);
        alphaWeightedVisibleAreaSum += front.alpha * visibleArea;
        if (visibleArea > 0) visibleSpans.push(span);
      }
      visibleSpans.sort((a, b) => a - b);
      const middle = Math.floor(visibleSpans.length / 2);
      const medianSpan = !visibleSpans.length ? 0 : visibleSpans.length % 2
        ? visibleSpans[middle] : (visibleSpans[middle - 1] + visibleSpans[middle]) / 2;
      routes[bank.route] = {
        host: bank.host, faces: faces.length, fronts: fronts.length,
        alpha: faces.reduce((sum, face) => sum + face.alpha, 0) / Math.max(1, faces.length),
        frontCoverage: {
          count: fronts.length, visibleCount: visibleSpans.length,
          opaqueCount: fronts.filter(front => front.alpha >= 0.95).length,
          areaSum, visibleAreaSum, maxArea, maxVisibleArea,
          alphaWeightedVisibleAreaSum, maxSpan: Math.max(0, ...spans), medianSpan,
          visibleAtLeast8px: visibleSpans.filter(span => span >= 8).length,
          visibleAtLeast16px: visibleSpans.filter(span => span >= 16).length,
        },
      };
    }
    return routes;
  };
  window.SiteEngineProbe = sample => {
    if (sample.kind === 'stage') {
      if (sample.part.startsWith('draw-')) window.__visualStages.push({at: performance.now(), part: sample.part, duration: sample.duration});
      return;
    }
    if (sample.kind !== 'paint') return;
    const d = window.SiteEffects?.embedded?.diagnostics();
    if (!d) return;
    window.__visualFrames.push({
      at: performance.now(), clock: d.clock, page: document.body.dataset.page,
      camera: sample.current, phase: d.phase, travelProgress: d.travelProgress,
      progress: d.progress, handoff: d.handoff, pendingRoute: d.pendingRoute,
      residentRoutes: d.residentRoutes, residentReveals: d.residentReveals,
      residentUsage: d.residentUsage, captureTimings: d.captureTimings, lastFailure: d.lastFailure,
      routes: window.__frontMetrics(d),
      nativeOpacity: getComputedStyle(document.getElementById('site-content')).opacity,
    });
    if (window.__visualFrames.length > 1200) window.__visualFrames.shift();
    if (window.__visualStages.length > 6000) window.__visualStages.splice(0, 20);
  };
}
async function quietReady(page,current,next){await page.waitForFunction(([current,next])=>{const d=window.SiteEffects?.embedded?.diagnostics();return d?.residentRoutes.includes(current)&&(!next||d.residentRoutes.includes(next))&&!d.pendingRoute&&!d.phase&&d.residentReveals?.every(x=>x.progress===1)},[current,next],{timeout:15000});}
(async()=>{let browser,server;try{require(repo+'/tools/quality/artifact.cjs').verify(process.env.SITE_PUBLIC_DIR,artifact);const setup=await require(repo+'/tools/quality/serve.cjs').start();server=setup.server;browser=await pw.chromium.launch({headless:true,executablePath:'/tmp/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});result.engine=browser.version();for(const viewport of [{width:1024,height:1366},{width:1366,height:1024}]){const row={viewport,dpr:2,errors:[],journeys:[]};result.rows.push(row);const context=await browser.newContext({viewport,deviceScaleFactor:2,isMobile:true,hasTouch:true,reducedMotion:'no-preference'});let page;try{await context.addInitScript(()=>{localStorage.setItem('vo.motion','on');localStorage.setItem('vo.content-flight','on');localStorage.setItem('vo.fragment-preview','on');localStorage.setItem('vo.theme','light');});await context.addInitScript(observe);page=await context.newPage();page.on('pageerror',e=>row.errors.push(String(e)));await page.goto(setup.url+'/index.html',{waitUntil:'domcontentloaded'});await quietReady(page,'index','research');row.initial=await page.evaluate(()=>(()=>{const d=window.SiteEffects.embedded.diagnostics();return {timeOrigin:performance.timeOrigin,d,routes:window.__frontMetrics(d)}})());await page.screenshot({path:output+'/'+viewport.width+'-before.png'});for(const [from,to,theme,next] of [['index','research','light','writing'],['research','index','light','research'],['index','writing','light','talks'],['writing','research','dark','writing']]){if(theme==='dark'){await page.evaluate(mode=>{const control=document.getElementById('theme-mode');control.value=mode;control.dispatchEvent(new Event('change',{bubbles:true}))},theme);await quietReady(page,from,'talks');}const journey={from,to,theme,images:[],errors:[]};row.journeys.push(journey);const prefix=[viewport.width,theme,from,to].join('-');await page.evaluate(()=>{window.__visualFrames=[];window.__visualStages=[]});const session=await context.newCDPSession(page);let frame=0;const acknowledgements=[];session.on('Page.screencastFrame',event=>{const file=prefix+'-'+String(frame++).padStart(3,'0')+'.jpg';fs.writeFileSync(output+'/'+file,Buffer.from(event.data,'base64'));journey.images.push({file,timestamp:event.metadata.timestamp});acknowledgements.push(session.send('Page.screencastFrameAck',{sessionId:event.sessionId}));});await session.send('Page.startScreencast',{format:'jpeg',quality:85,maxWidth:viewport.width,maxHeight:viewport.height,everyNthFrame:1});await page.locator('body > .site-header nav a[href="'+(to==='index'?'./':to+'.html')+'"]').tap();await page.waitForFunction(id=>document.body.dataset.page===id&&!document.querySelector('#site-content').hasAttribute('aria-busy')&&!window.SiteEffects?.embedded?.diagnostics().phase,to,{timeout:10000});await quietReady(page,to,next);await page.waitForTimeout(120);await session.send('Page.stopScreencast');await Promise.allSettled(acknowledgements);await session.detach();journey.frames=await page.evaluate(()=>window.__visualFrames);journey.stages=await page.evaluate(()=>window.__visualStages);journey.final=await page.evaluate(()=>{const d=window.SiteEffects.embedded.diagnostics();return{phase:d.phase,residentRoutes:d.residentRoutes,residentReveals:d.residentReveals,lastFailure:d.lastFailure,captureTimings:d.captureTimings,residentUsage:d.residentUsage}});await page.screenshot({path:output+'/'+prefix+'-after.png'});console.log(JSON.stringify({viewport,from,to,theme,images:journey.images.length,frames:journey.frames.length,final:journey.final}));fs.writeFileSync(output+'/result.json',JSON.stringify(result,null,2));}row.pass=true;}catch(error){row.pass=false;row.error=String(error.stack||error);row.failureState=await page?.evaluate(()=>({d:window.SiteEffects?.embedded?.diagnostics(),scene:document.querySelector('.space-scene')?.dataset})).catch(()=>null);if(page)await page.screenshot({path:output+'/'+viewport.width+'-failed.png'}).catch(()=>null);console.log(JSON.stringify({viewport,error:row.error,reason:row.failureState?.d?.lastFailure}));}finally{await context.close();fs.writeFileSync(output+'/result.json',JSON.stringify(result,null,2));}} }catch(error){result.error=String(error.stack||error);console.error(result.error)}finally{await browser?.close();if(server)await new Promise(r=>server.close(r));fs.writeFileSync(output+'/result.json',JSON.stringify(result,null,2));console.log(output+'/result.json')}})();
