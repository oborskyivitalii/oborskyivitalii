"use strict";
// Private, bounded diagnostic; no repo owner, browser launch, or release claim.
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const categories = "devtools.timeline,v8.execute,blink.user_timing,cc";
const digest = (bytes) =>
  crypto.createHash("sha256").update(bytes).digest("hex");
const identity = {
  fullGate: false,
  nativeDevice: false,
  nativeDeviceProof: false,
};
const definition = {
  window:
    "issue49-input through issue49-ready + 400 ms on the same renderer main thread",
  nativeWork:
    "Clipped durations of outermost RunTask or qualified ::RunTask spans; inclusive native work",
  percentile:
    "Sort ascending; index min(n - 1, floor(n * p)), matching motion.cjs",
  unions:
    "Merge overlapping intervals within each metric/thread; never sum nested spans",
  scope:
    "One transition in one exact-artifact paired diagnostic; tracing perturbs timings",
};
async function begin(cdp) {
  await cdp.send("Tracing.start", {
    categories,
    transferMode: "ReturnAsStream",
  });
}
async function finish(cdp, file) {
  let timer, listener;
  const completion = new Promise((resolve, reject) => {
    timer = setTimeout(
      () => reject(Error("CDP trace completion timed out")),
      15000,
    );
    listener = resolve;
    cdp.once("Tracing.tracingComplete", listener);
  });
  let stream;
  try {
    await cdp.send("Tracing.end");
    stream = (await completion).stream;
  } finally {
    clearTimeout(timer);
    cdp.removeListener("Tracing.tracingComplete", listener);
  }
  if (!stream) throw Error("Missing CDP trace stream");
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const fd = fs.openSync(file, "w");
  try {
    let result;
    do {
      result = await cdp.send("IO.read", { handle: stream, size: 1048576 });
      fs.writeSync(
        fd,
        Buffer.from(result.data, result.base64Encoded ? "base64" : "utf8"),
      );
    } while (!result.eof);
  } finally {
    fs.closeSync(fd);
    await cdp.send("IO.close", { handle: stream });
  }
  const bytes = fs.readFileSync(file);
  return {
    ...identity,
    file,
    bytes: bytes.length,
    sha256: digest(bytes),
    categories,
    definition,
  };
}
const key = (event) => event.pid + ":" + event.tid;
const task = (span) =>
  span.name === "RunTask" || String(span.name).endsWith("::RunTask");
function intervals(events) {
  const spans = [],
    stacks = new Map();
  for (const event of [...events].sort((a, b) => a.ts - b.ts)) {
    if (event.ph === "X" && Number.isFinite(event.dur) && event.dur > 0)
      spans.push({ ...event, end: event.ts + event.dur });
    else if (event.ph === "B") {
      const stack = stacks.get(key(event)) || [];
      stack.push(event);
      stacks.set(key(event), stack);
    } else if (event.ph === "E") {
      const start = stacks.get(key(event))?.pop();
      if (start && event.ts > start.ts) spans.push({ ...start, end: event.ts });
    }
  }
  return spans;
}
function clip(spans, start, end) {
  return spans
    .filter((s) => s.end > start && s.ts < end)
    .map((s) => ({
      ...s,
      start: Math.max(start, s.ts),
      stop: Math.min(end, s.end),
    }));
}
function unionMs(spans) {
  const sorted = [...spans].sort(
    (a, b) => a.start - b.start || b.stop - a.stop,
  );
  let total = 0,
    start,
    end;
  for (const span of sorted) {
    if (start === undefined) [start, end] = [span.start, span.stop];
    else if (span.start <= end) end = Math.max(end, span.stop);
    else {
      total += end - start;
      [start, end] = [span.start, span.stop];
    }
  }
  return (total + (start === undefined ? 0 : end - start)) / 1000;
}
function outerTasks(spans) {
  const sorted = spans
    .filter(task)
    .sort((a, b) => a.ts - b.ts || b.end - a.end);
  let enclosingEnd = -Infinity;
  return sorted.filter((span) => {
    if (span.end <= enclosingEnd) return false;
    enclosingEnd = span.end;
    return true;
  });
}
function metrics(spans) {
  const durationsMs = spans
    .map((s) => (s.stop - s.start) / 1000)
    .sort((a, b) => a - b);
  const quantile = (p) =>
    durationsMs.length
      ? durationsMs[
          Math.min(durationsMs.length - 1, Math.floor(durationsMs.length * p))
        ]
      : null;
  return {
    count: spans.length,
    durationsMs,
    p50Ms: quantile(0.5),
    p95Ms: quantile(0.95),
    maxMs: durationsMs.at(-1) ?? null,
    unionMs: unionMs(spans),
    spans: spans.map((s) => ({
      name: s.name,
      startUs: s.start,
      endUs: s.stop,
      originalStartUs: s.ts,
      originalEndUs: s.end,
      durationMs: (s.stop - s.start) / 1000,
    })),
  };
}
function summarize(file) {
  const bytes = fs.readFileSync(file),
    errors = [];
  const result = {
    ...identity,
    file,
    bytes: bytes.length,
    sha256: digest(bytes),
    categories,
    definition,
    valid: false,
    errors,
    nativeWork: null,
    layout: null,
    paint: null,
    otherThreads: [],
  };
  let events;
  try {
    events = JSON.parse(bytes).traceEvents;
  } catch (error) {
    errors.push("Trace JSON parse failed: " + error.message);
    return result;
  }
  if (!Array.isArray(events)) {
    errors.push("Missing traceEvents");
    return result;
  }
  const mark = (name) =>
    events.filter((e) => e.name === name && Number.isFinite(e.ts));
  const inputs = mark("issue49-input"),
    ready = mark("issue49-ready");
  const boundary = mark("issue49-trace-boundary");
  result.markers = { inputs, ready, boundary };
  if (inputs.length !== 1 || ready.length !== 1) {
    errors.push("Expected exactly one input and one ready marker");
    return result;
  }
  const input = inputs[0],
    arrival = ready[0],
    end = arrival.ts + 400000;
  if (key(input) !== key(arrival) || arrival.ts <= input.ts) {
    errors.push(
      "Input/ready markers must be ordered on the same renderer thread",
    );
    return result;
  }
  result.window = {
    startUs: input.ts,
    readyUs: arrival.ts,
    endUs: end,
    durationMs: (end - input.ts) / 1000,
    pid: input.pid,
    tid: input.tid,
  };
  if (
    boundary.length !== 1 ||
    key(boundary[0]) !== key(input) ||
    boundary[0].ts < end
  )
    errors.push("Missing boundary marker proving ready + 400 ms was collected");
  const threadNames = new Map(
    events
      .filter((e) => e.ph === "M" && e.name === "thread_name")
      .map((e) => [key(e), e.args?.name || "unknown"]),
  );
  result.window.threadName = threadNames.get(key(input)) || "unknown";
  if (!/RendererMain/i.test(result.window.threadName))
    errors.push(
      "Marker thread is not identified as renderer main in trace metadata",
    );
  const spans = intervals(events),
    renderer = spans.filter((s) => key(s) === key(input));
  const runTasks = clip(outerTasks(renderer), input.ts, end);
  if (!runTasks.length)
    errors.push("No native RunTask spans; native cost condition is deferred");
  else result.nativeWork = metrics(runTasks);
  result.layout = metrics(
    clip(
      renderer.filter((s) => ["Layout", "UpdateLayoutTree"].includes(s.name)),
      input.ts,
      end,
    ),
  );
  result.paint = metrics(
    clip(
      renderer.filter((s) => ["Paint", "PrePaint"].includes(s.name)),
      input.ts,
      end,
    ),
  );
  const grouped = new Map();
  for (const span of clip(spans, input.ts, end)) {
    if (key(span) === key(input)) continue;
    const threadName = threadNames.get(key(span)) || "unknown";
    const kind = /Raster|TileWorker/i.test(threadName)
      ? "raster"
      : /Compositor/i.test(threadName)
        ? "compositor"
        : /RasterTask|RasterizerTask/i.test(span.name)
          ? "raster"
          : /Compositor|CompositeLayers/i.test(span.name)
            ? "compositor"
            : null;
    if (!kind) continue;
    const groupKey = key(span) + ":" + kind;
    const group = grouped.get(groupKey) || {
      pid: span.pid,
      tid: span.tid,
      threadName,
      kind,
      spans: [],
    };
    group.spans.push(span);
    grouped.set(groupKey, group);
  }
  result.otherThreads = [...grouped.values()].map(
    ({ spans: rows, ...thread }) => ({
      ...thread,
      eventCount: rows.length,
      unionMs: unionMs(rows),
      eventNames: [...new Set(rows.map((s) => s.name))],
    }),
  );
  result.valid = errors.length === 0;
  return result;
}
module.exports = { begin, finish, summarize };
