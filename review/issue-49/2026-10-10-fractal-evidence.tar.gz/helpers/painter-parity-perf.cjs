'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const performance = require('node:perf_hooks').performance;
const root = '/workspace/scratch/fa77374a3907/author-site';
const math = require(root + '/site/engine/math.cjs')();
const fragments = require(root + '/site/effects/fragment-plan.cjs')(math);
const routes = require(root + '/site/routes.json').routes;
const definitions = {
  ...require(root + '/site/scenes/paths.json'),
  routeOrder: routes.map((route) => route.id),
  initialPoses: Object.fromEntries(routes.map((route) => [route.id, route.initialPose])),
};
const projection = require(root + '/site/engine/projection.cjs')(math, definitions);
const models = require(root + '/site/scenes/world.cjs')(math);
const input = { ...math, loopTransform: projection.loopTransform };
const beforeFile = '/tmp/issue49-render-plan-before.cjs';
const afterFile = root + '/site/effects/embedded-plan.cjs';
const before = require(beforeFile)(input);
const after = require(afterFile)(input);
const digest = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const colors = { paper: '#101923', sheet: '#f2f6fa', cyan: '#73defa', amber: '#ffb56b' };
const surface = { width: 997, height: 701 };
const pose = (route) => projection.routePose(route, definitions.poses[definitions.initialPoses[route]]);
const corpus = [];
for (const [width, height] of [[1024, 1366], [1366, 1024], [390, 844]]) {
  const compact = width <= 640;
  const count = compact ? 13 : 32;
  const rect = { x: 0, y: 78, width, height: height - 78 };
  const cells = fragments.partition(rect, { count, seed: 49 }, { maxPieces: count });
  for (const [host, route] of [['index', 'research'], ['research', 'writing']]) {
    const branches = models.worldFor(host, compact).objects.filter((branch) => branch.depth === 2 && branch.root <= 2 && branch.points?.length);
    const members = cells.map((_, index) => {
      const candidates = branches.filter((branch) => branch.root === index % 3);
      const branch = candidates[(37 + Math.floor(index / 3) * 7) % candidates.length];
      return { ...branch, attachment: [...branch.points[(37 + index * 11) % branch.points.length]] };
    });
    const config = { id: host + ':' + route, rect, cells, pose: pose(route), width, height, members, hostOffset: projection.roomOffset(host) };
    const prepared = before.prepare(config);
    for (const time of [0, 1650, 9000])
      for (const progress of [0, 0.025, 0.12, 0.3, 0.5, 0.65, 0.8, 0.975, 1])
        for (const mode of [{}, { forwardPath: true }, { departing: true }]) {
          const camera = math.mix(pose(host), pose(route), math.smooth(progress));
          const requested = math.clamp((progress - 0.12) / 0.88);
          const progresses = cells.map((_, index) => math.clamp((requested - 0.2 * index / (count - 1)) / (1 - 0.2 * index / (count - 1))));
          corpus.push(...before.sample(prepared, { ...mode, pose: camera, width, height, time, progress, clearance: true, progresses }));
        }
  }
}
const trace = (plan, shape) => {
  const calls = [];
  const context = new Proxy({}, {
    get: (target, property) => property in target ? target[property] : (...args) => calls.push([property, ...args]),
    set: (target, property, value) => { target[property] = value; calls.push(['set', property, value]); return true; },
  });
  plan.paint(context, shape, surface, colors);
  return calls;
};
let submissions = 0;
for (const shape of corpus) {
  const original = trace(before, shape);
  const candidate = trace(after, shape);
  assert.deepEqual(candidate, original);
  submissions += original.filter(([kind]) => kind === 'drawImage').length;
}
const context = Object.fromEntries(['save', 'restore', 'beginPath', 'closePath', 'moveTo', 'lineTo', 'clip', 'transform', 'drawImage', 'fill'].map((key) => [key, () => {}]));
const measured = (plan) => {
  const start = performance.now();
  for (const shape of corpus) plan.paint(context, shape, surface, colors);
  return performance.now() - start;
};
measured(before);
measured(after);
const pairs = [];
for (let trial = 0; trial < 6; trial++) {
  const pair = { trial, order: trial % 2 ? 'candidate/baseline' : 'baseline/candidate' };
  for (const key of trial % 2 ? ['after', 'before'] : ['before', 'after']) pair[key] = measured(key === 'before' ? before : after);
  pair.savedPercent = (1 - pair.after / pair.before) * 100;
  pairs.push(pair);
}
const median = (values) => [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)];
const result = { pass: true, shapes: corpus.length, unchangedDrawSubmissions: submissions, beforeSha256: digest(beforeFile), afterSha256: digest(afterFile), pairs, medianBeforeMs: median(pairs.map((pair) => pair.before)), medianAfterMs: median(pairs.map((pair) => pair.after)), medianSavedPercent: median(pairs.map((pair) => pair.savedPercent)), scope: 'Fixed original28dde shapes across three widths/two rooms/three times/rest-forward-departure. Exact Canvas command parity; CPU-only no-op Canvas backend isolates painter JS work, not browser/GPU/iPad or paired whole-effect acceptance.' };
fs.writeFileSync('/tmp/issue49-painter-parity-perf.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
