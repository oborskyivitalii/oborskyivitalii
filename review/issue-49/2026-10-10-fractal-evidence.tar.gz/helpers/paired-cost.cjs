"use strict";
// Temporary exact-artifact diagnostic. No repository, deployment or metadata writes.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

function argumentsFor(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index++) {
    const flag = argv[index];
    assert.ok(
      [
        "--repo",
        "--artifact",
        "--out",
        "--source",
        "--chromium",
        "--plan",
        "--allow-dirty-diagnostic",
      ].includes(flag),
    );
    const key = flag.slice(2);
    assert.ok(!Object.hasOwn(result, key), "duplicate " + flag);
    if (key === "plan" || key === "allow-dirty-diagnostic") result[key] = true;
    else {
      assert.ok(
        argv[index + 1] && !argv[index + 1].startsWith("--"),
        "missing " + flag,
      );
      result[key] = argv[++index];
    }
  }
  for (const key of ["repo", "artifact", "out", "source"])
    assert.ok(result[key], "required --" + key);
  assert.match(result.source, /^[a-f0-9]{40}$/);
  return result;
}

const profiles = {
  desktop: {
    width: 1440,
    height: 900,
    deviceScaleFactor: 1.5,
    cpuRate: 1,
    theme: "dark",
  },
  compact: {
    width: 390,
    height: 844,
    deviceScaleFactor: 3,
    cpuRate: 4,
    theme: "dark",
  },
};
const cases = [
  {
    id: "desktop-forward-cold",
    profile: "desktop",
    from: "index",
    to: "writing",
    sourcePosition: "portrait-center",
    atEnd: false,
    pictureDeparture: true,
  },
  {
    id: "compact-forward-cold",
    profile: "compact",
    from: "index",
    to: "writing",
    sourcePosition: "portrait-center",
    atEnd: false,
    pictureDeparture: true,
  },
  {
    id: "desktop-reverse-portrait-arrival",
    profile: "desktop",
    from: "research",
    to: "index",
    sourcePosition: "top",
    atEnd: false,
    portraitArrival: true,
  },
  {
    id: "compact-reverse-bottom",
    profile: "compact",
    from: "research",
    to: "index",
    sourcePosition: "top",
    atEnd: true,
    pictureDeparture: true,
    deferred:
      "Original real picture-bearing reverse departure is unavailable in current canonical Research content. No image is injected and route direction is unchanged.",
  },
];
const orders = [
  ["legacy", "fragments"],
  ["fragments", "legacy"],
  ["legacy", "fragments"],
];
const incremental = {
  desktopPreparationMs: 30,
  compactPreparationMs: 50,
  desktopInclusiveWorkP95Ms: 8,
  compactInclusiveWorkP95Ms: 12,
  inputToReadyMs: 100,
};
const protocol = {
  authority:
    "review/issue-49/2026-10-08-analysis.md: Measurement and economical verification",
  pairsPerCase: 3,
  measuredTransitions: 24,
  orders,
  cache:
    "Fresh Chromium process/context per arm; HTTP cache disabled; gzip no-store loopback; no test model prewarm or previous navigation. Endogenous fragment neighbor warming is retained and startup cost is recorded.",
  motion:
    "Motion on; content flight on in both arms; fragment preview off/on before first goto; stationary reading camera; no forced quality, camera or cadence.",
  startupIdleMs: 4000,
  sourcePositionSettleMs: 300,
  arrivalTailMs: 400,
  input:
    "One canonical SiteNavigation.go call; atEnd=false gives native top, atEnd=true preserves canonical native-bottom endpoint.",
  nativePosition:
    "Forward departures center the real Home portrait figure using bounded native scroll. Research departures begin at native top. Record exact scroll and visible owner/media rectangles before input and after landing.",
  workDefinition:
    "Native inclusive transition-work p95 is the clipped outermost renderer-main RunTask duration distribution in the CDP marker window navigation-start through navigation-ready+400ms. Layout/paint and compositor/raster unions are retained separately; JavaScript callback timings are never substituted for this native metric.",
  preparationDefinition:
    "Union of existing model/layout/route preparation spans and elapsed embedded.prime/prepareDeparture spans, clipped to input through ready+400ms. Nested preparation spans are merged, never summed. All capture failures and asynchronous waits remain in the recorded spans.",
  percentile: "sorted[min(n-1,floor(n*p))], matching motion.cjs",
  tracing:
    "Same devtools.timeline,v8.execute,blink.user_timing,cc categories in every arm. Tracing perturbs timings; this is a bounded diagnostic and has no physical-device or whole-gate authority.",
  incremental,
};

function digest(file) {
  return crypto
    .createHash("sha256")
    .update(fs.readFileSync(file))
    .digest("hex");
}
function median(values) {
  const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
  if (!sorted.length) return null;
  const index = Math.floor(sorted.length / 2);
  return sorted.length % 2
    ? sorted[index]
    : (sorted[index - 1] + sorted[index]) / 2;
}
function initializeArm(arm) {
  localStorage.setItem(
    "vo.fragment-preview",
    arm === "fragments" ? "on" : "off",
  );
  localStorage.setItem("vo.content-flight", "on");
  localStorage.setItem("vo.motion", "on");
}
function installRuntimeRecorder() {
  window.__issue49PaintStates = [];
  window.__issue49Preparations = [];
  const observe = window.SiteEngineProbe;
  if (typeof observe !== "function")
    throw Error("Missing existing engine probe");
  window.SiteEngineProbe = (event) => {
    observe?.(event);
    if (event.kind === "navigation-start") performance.mark("issue49-input");
    if (event.kind === "navigation-ready") performance.mark("issue49-ready");
    if (event.kind !== "paint") return;
    const data = document.querySelector(".space-scene")?.dataset;
    if (!data) return;
    window.__issue49PaintStates.push({
      time: performance.now(),
      page: document.body.dataset.page,
      quality: data.quality,
      cadence: data.cadence,
      geometry: data.geometry,
      travel: data.travel,
      embeddedPhase: data.embeddedPhase || null,
      bank: data.embeddedBank || "",
      failureStage: data.embeddedFailureStage || null,
      failureRoute: data.embeddedFailureRoute || null,
      failureReason: data.embeddedFailureReason || null,
      failureLimit: data.embeddedFailureLimit || null,
    });
  };
  const bridge = window.SiteEffects?.embedded;
  for (const name of ["prime", "prepareDeparture"]) {
    if (typeof bridge?.[name] !== "function") continue;
    const prepare = bridge[name];
    bridge[name] = async function (...args) {
      const start = performance.now();
      let outcome = null,
        failure = null;
      try {
        outcome = await prepare.apply(this, args);
        return outcome;
      } catch (error) {
        failure = error.message;
        throw error;
      } finally {
        const time = performance.now();
        const event = {
          kind: "diagnostic-preparation",
          part: "embedded." + name,
          time,
          start,
          duration: time - start,
          outcome: outcome === true,
          failure,
        };
        window.__issue49Preparations.push(event);
        window.SiteEngineProbe(event);
      }
    };
  }
}
async function nativeSnapshot(page) {
  return page.evaluate(() => {
    const rectangle = (rect) => ({
      left: rect.left,
      top: rect.top,
      width: rect.width,
      height: rect.height,
    });
    const visible = (node) => {
      const rect = node.getBoundingClientRect(),
        style = getComputedStyle(node);
      return (
        rect.width > 0 &&
        rect.height > 0 &&
        rect.bottom > 0 &&
        rect.top < innerHeight &&
        rect.right > 0 &&
        rect.left < innerWidth &&
        style.visibility !== "hidden" &&
        style.display !== "none"
      );
    };
    const content = document.getElementById("site-content");
    const data = document.querySelector(".space-scene").dataset;
    const embedded = window.SiteEffects?.embedded?.diagnostics?.() || null;
    return {
      page: document.body.dataset.page,
      viewport: [innerWidth, innerHeight],
      dpr: devicePixelRatio,
      scroll: [scrollX, scrollY],
      maximumY: Math.max(
        0,
        document.documentElement.scrollHeight - innerHeight,
      ),
      quality: data.quality,
      cadence: data.cadence,
      camera: data.camera,
      state: data.state,
      nativeOpacity: Number(getComputedStyle(content).opacity),
      nativeVisibility: getComputedStyle(content).visibility,
      nativeInert: content.inert,
      transientPieces: document.querySelectorAll(".fragment-piece").length,
      transientLayers: document.querySelectorAll(".fragment-layer").length,
      controls: {
        contentFlight: window.SiteNavigation?.contentFlight?.(),
        fragments: window.SiteNavigation?.fragmentPreview?.(),
        motion: document.getElementById("space-motion")?.textContent,
      },
      owners: [...content.querySelectorAll("h1,h2,h3,p,li,figure")]
        .filter(visible)
        .slice(0, 80)
        .map((node) => ({
          tag: node.tagName,
          id: node.id,
          class: node.className,
          rect: rectangle(node.getBoundingClientRect()),
          text: node.textContent.trim().slice(0, 200),
        })),
      media: [...content.querySelectorAll("img,svg")]
        .filter(visible)
        .map((node) => ({
          tag: node.tagName,
          class: node.getAttribute("class"),
          src: node.getAttribute("src"),
          rect: rectangle(node.getBoundingClientRect()),
          complete: node.complete ?? null,
          naturalWidth: node.naturalWidth ?? null,
        })),
      embedded: embedded && {
        phase: embedded.phase,
        route: embedded.route,
        pendingRoute: embedded.pendingRoute,
        lastFailure: embedded.lastFailure,
        captureTimings: embedded.captureTimings,
        residentRoutes: embedded.residentRoutes,
        residentUsage: embedded.residentUsage,
        texturePixels: embedded.texturePixels,
        caps: embedded.caps,
      },
    };
  });
}
async function positionSource(page, specification) {
  await page.evaluate((position) => {
    let y = 0;
    if (position === "portrait-center") {
      const portrait = document.querySelector(".portrait-composition");
      if (!portrait) throw Error("Missing real Home portrait owner");
      const rect = portrait.getBoundingClientRect();
      y = scrollY + rect.top + rect.height / 2 - innerHeight / 2;
    }
    scrollTo({
      left: 0,
      top: Math.max(
        0,
        Math.min(document.documentElement.scrollHeight - innerHeight, y),
      ),
      behavior: "instant",
    });
  }, specification.sourcePosition);
}
function freezeMatch(before, after) {
  const close = (a, b) =>
    Number.isFinite(a) && Number.isFinite(b) && Math.abs(a - b) <= 0.75;
  return (
    before.page === after.page &&
    JSON.stringify(before.viewport) === JSON.stringify(after.viewport) &&
    before.dpr === after.dpr &&
    before.quality === after.quality &&
    before.cadence === after.cadence &&
    before.camera === after.camera &&
    close(before.scroll[1], after.scroll[1]) &&
    JSON.stringify(
      before.owners.map((owner) => [owner.tag, owner.id, owner.text]),
    ) ===
      JSON.stringify(
        after.owners.map((owner) => [owner.tag, owner.id, owner.text]),
      ) &&
    before.owners.every((owner, index) =>
      ["left", "top", "width", "height"].every((key) =>
        close(owner.rect[key], after.owners[index]?.rect[key]),
      ),
    ) &&
    JSON.stringify(before.media.map((item) => [item.tag, item.src])) ===
      JSON.stringify(after.media.map((item) => [item.tag, item.src]))
  );
}

async function main(options) {
  const repository = path.resolve(options.repo);
  const plan = orders.flatMap((order, pair) =>
    cases.flatMap((specification) =>
      order.map((arm) => ({
        id: specification.id + "/pair-" + (pair + 1) + "/" + arm,
        pair: pair + 1,
        arm,
        specification,
      })),
    ),
  );
  if (options.plan)
    return {
      status: "planned",
      pass: null,
      protocol,
      profiles,
      cases,
      rows: plan,
      sourceCommit: options.source,
      dirtyDiagnosticExplicitlyAllowed: !!options["allow-dirty-diagnostic"],
      fullGate: false,
      nativeDeviceProof: false,
      deploymentAuthorized: false,
    };
  if (options.chromium)
    process.env.SITE_AUDIT_CHROME = path.resolve(options.chromium);
  const artifact = require(path.join(repository, "tools/quality/artifact.cjs"));
  const common = require(path.join(repository, "tools/quality/common.cjs"));
  const probe = require(
    path.join(repository, "tools/quality/writing-probe.cjs"),
  );
  const diagnostic = require(
    path.join(repository, "tools/quality/writing-diagnosis.cjs"),
  );
  const motion = require(path.join(repository, "tools/quality/motion.cjs"));
  const nativeTrace = require("/tmp/issue49-paired-trace.cjs");
  const { trackResponses, drainResponses } = require(
    path.join(repository, "tools/quality/local-browser.cjs"),
  );
  const input = path.resolve(options.artifact),
    publicDir = path.join(input, "public");
  const manifest = JSON.parse(
    fs.readFileSync(path.join(input, "artifact.json")),
  );
  assert.equal(
    manifest.sourceCommit,
    options.source,
    "unexpected exact source",
  );
  assert.equal(
    manifest.candidateCommit,
    options.source,
    "candidate/source mismatch",
  );
  assert.equal(
    typeof manifest.sourceDirty,
    "boolean",
    "missing source dirty binding",
  );
  assert.ok(
    !manifest.sourceDirty || options["allow-dirty-diagnostic"] === true,
    "dirty artifact requires explicit --allow-dirty-diagnostic",
  );
  assert.match(manifest.sourceTree, /^[a-f0-9]{40}$/);
  const variant = common.variant(manifest);
  assert.equal(variant.id, "color");
  assert.deepEqual(variant.effects, ["travel"]);
  assert.equal(
    manifest.components.engine,
    variant.fingerprint,
    "engine/variant mismatch",
  );
  artifact.verify(publicDir, manifest);
  const output = path.resolve(options.out);
  assert.ok(
    output !== repository && !output.startsWith(repository + path.sep),
    "report must stay outside checkout",
  );
  assert.ok(
    !fs.existsSync(path.join(output, "issue49-paired-cost.json")),
    "retain prior observations; choose a new output directory",
  );
  fs.mkdirSync(output, { recursive: true });
  const helperPaths = [
    "tools/quality/writing-probe.cjs",
    "tools/quality/writing-diagnosis.cjs",
    "tools/quality/motion.cjs",
    "tools/quality/validate.cjs",
    "tools/quality/budgets.json",
    "tools/quality/common.cjs",
    "tools/quality/local-browser.cjs",
    "tools/quality/artifact.cjs",
  ];
  const ownerPaths = [
    "site/effects/embedded-plan.cjs",
    "site/effects/embedded-scene.cjs",
    "site/effects/embedded-texture.cjs",
    "site/effects/flight.cjs",
    "site/effects/fragment-plan.cjs",
    "site/engine/math.cjs",
    "site/engine/lifecycle.cjs",
    "site/engine/navigation.js",
  ];
  const ownerHashes = Object.fromEntries(
    ownerPaths.map((file) => [file, digest(path.join(repository, file))]),
  );
  const runtimeName = "runtime/" + variant.fingerprint + "/space.js";
  const runtimeBytes = fs.readFileSync(path.join(publicDir, runtimeName));
  assert.equal(
    artifact.digest(runtimeBytes),
    manifest.files[runtimeName]?.sha256,
    "served runtime binding",
  );
  const factoryHashes = Object.fromEntries(
    ["embedded-plan", "embedded-scene", "embedded-texture"].map((name) => {
      const factory = require(
        path.join(repository, "site/effects/" + name + ".cjs"),
      );
      assert.ok(
        runtimeBytes.includes(Buffer.from(factory.toString())),
        "serialized runtime differs from current owner: " + name,
      );
      return [
        name,
        crypto.createHash("sha256").update(factory.toString()).digest("hex"),
      ];
    }),
  );
  const record = {
    schema: 1,
    kind: "issue49-same-source-paired-diagnostic",
    protocol,
    profiles,
    cases,
    source: {
      sourceCommit: manifest.sourceCommit,
      sourceTree: manifest.sourceTree,
      candidateCommit: manifest.candidateCommit,
      sourceDirty: manifest.sourceDirty,
      artifactDigest: manifest.artifactDigest,
      variant,
      engine: manifest.components.engine,
      derivation: manifest.derivation,
      cleanSourceBound: manifest.sourceDirty === false,
      description: manifest.sourceDirty
        ? "Dirty frozen snapshot based on this commit/tree; current owner and factory hashes bind changed runtime. This is not clean-commit evidence."
        : "Clean exact-commit artifact.",
    },
    dirtyDiagnosticExplicitlyAllowed: !!options["allow-dirty-diagnostic"],
    ownerHashes,
    factoryHashes,
    serializedFactoryBinding: {
      runtimeName,
      runtimeSHA256: artifact.digest(runtimeBytes),
      exactLiteralMatch: true,
    },
    cleanRebindingCondition:
      "Only a later clean artifact with byte-for-byte equal public files, engine and serialized runtime may refer to these observations; commit labels alone cannot rebind dirty measurements.",
    collectors: Object.fromEntries(
      helperPaths.map((file) => [file, digest(path.join(repository, file))]),
    ),
    runnerDigest: digest(__filename),
    traceCollectorDigest: digest("/tmp/issue49-paired-trace.cjs"),
    environment: common.environment(),
    browserExecutable: process.env.SITE_AUDIT_CHROME || null,
    browserExecutableDigest: process.env.SITE_AUDIT_CHROME
      ? digest(process.env.SITE_AUDIT_CHROME)
      : null,
    fullGate: false,
    nativeDeviceProof: false,
    deploymentAuthorized: false,
    rows: [],
    complete: false,
    pending: [
      "Original reverse picture-bearing departure",
      "Physical iPad/native device",
      "Whole AC06/G-PERFORMANCE admission",
      "Visual/glyph/occlusion/accessibility admission",
      "Production/stable/merge",
    ],
  };
  const reportFile = path.join(output, "issue49-paired-cost.json");
  const save = () => common.writeJson(reportFile, record);
  save();
  const served = await probe.serve({ candidate: { publicDir } });
  try {
    for (const planned of plan) {
      const row = {
        ...planned,
        status: "collecting",
        originalBudgetPass: null,
      };
      record.rows.push(row);
      save();
      let session,
        tracing = false;
      const traceFile = path.join(
        output,
        row.id.replaceAll("/", "-") + ".trace.json",
      );
      try {
        session = await diagnostic.prepareBrowser(
          profiles[row.specification.profile],
          { contentFlight: true, fineStages: true },
        );
        const { browser, context, page, cdp, errors } = session;
        await context.addInitScript(initializeArm, row.arm);
        row.browser = browser.version();
        const checkedFiles = new Set();
        const responseChecks = trackResponses(
          page,
          served.url + "/candidate",
          manifest,
          checkedFiles,
          errors,
        );
        await page.goto(
          served.url + "/candidate/" + row.specification.from + ".html",
          { waitUntil: "domcontentloaded" },
        );
        await probe.ready(page, row.specification.from);
        await page.evaluate(installRuntimeRecorder);
        row.startup = await diagnostic.snapshot(page);
        row.startupNative = await nativeSnapshot(page);
        row.idle = await motion.collect(page, "idle", protocol.startupIdleMs);
        row.startupPaintStates = await page.evaluate(
          () => window.__issue49PaintStates,
        );
        row.startupPreparations = await page.evaluate(
          () => window.__issue49Preparations,
        );
        row.afterIdle = await nativeSnapshot(page);
        row.idleBudgetPass =
          row.idle.paints >= 1 &&
          row.idle.paintCallbackMs.p95 <= 33 &&
          row.idle.callbackBusyPercent <= 20;
        await probe.reset(page);
        await positionSource(page, row.specification);
        await page.waitForTimeout(protocol.sourcePositionSettleMs);
        row.positioning = await diagnostic.snapshot(page);
        row.before = await nativeSnapshot(page);
        assert.equal(row.before.controls.contentFlight, true);
        assert.equal(row.before.controls.fragments, row.arm === "fragments");
        assert.equal(row.before.nativeOpacity, 1);
        assert.equal(row.before.nativeVisibility, "visible");
        assert.equal(row.before.nativeInert, false);
        row.pictureDepartureObserved = row.before.media.some(
          (item) =>
            item.tag === "IMG" && item.complete && item.naturalWidth > 0,
        );
        if (row.specification.pictureDeparture && !row.specification.deferred)
          assert.equal(
            row.pictureDepartureObserved,
            true,
            "required real picture departure not visible",
          );
        await nativeTrace.begin(cdp);
        tracing = true;
        row.action = await page.evaluate(({ to, atEnd }) => {
          window.__qualityMotion.frames = [];
          window.__qualityMotion.longTasks = [];
          window.__qualityMotion.events = [];
          window.__writingStates = [];
          window.__issue49PaintStates = [];
          window.__issue49Preparations = [];
          window.__qualityStart = performance.now();
          const accepted = window.SiteNavigation.go(to, { atEnd });
          return { accepted, inputAt: window.__qualityStart, to, atEnd };
        }, row.specification);
        assert.equal(
          row.action.accepted,
          true,
          "canonical navigation rejected",
        );
        await probe.ready(page, row.specification.to);
        const arrivalEnd = await page.evaluate(() => {
          const ready = window.__qualityMotion.events.find(
            (event) => event.kind === "navigation-ready",
          );
          if (!ready) throw Error("Missing navigation-ready marker");
          let end = ready.time;
          for (const frame of window.__qualityMotion.frames)
            if (
              frame.started < ready.time &&
              frame.started + frame.duration > ready.time
            )
              end = Math.max(end, frame.started + frame.duration);
          return end + 400;
        });
        await page.waitForFunction(
          (end) => performance.now() >= end,
          arrivalEnd,
          { polling: 20, timeout: 3000 },
        );
        await page.evaluate(() => performance.mark("issue49-trace-boundary"));
        row.raw = await diagnostic.snapshot(page);
        row.measurements = diagnostic.splitFlight(row.raw);
        row.preparations = await page.evaluate(
          () => window.__issue49Preparations,
        );
        row.inclusivePreparationUnionMs = diagnostic.unionDuration(
          [...row.measurements.inclusive.rawPreparation, ...row.preparations],
          row.measurements.inclusive.window.startMs,
          row.measurements.inclusive.window.endMs,
        );
        row.after = await nativeSnapshot(page);
        row.paintStates = await page.evaluate(
          () => window.__issue49PaintStates,
        );
        row.embeddedObserved = row.paintStates.some((state) =>
          ["departing", "assembling"].includes(state.embeddedPhase),
        );
        const failureFrames = [
          ...row.startupPaintStates,
          ...row.paintStates,
        ].filter((state) => state.failureReason);
        row.coldPreparationFailures = [
          ...new Map(
            failureFrames.map((state) => [
              JSON.stringify([
                state.failureStage,
                state.failureRoute,
                state.failureReason,
                state.failureLimit,
              ]),
              state,
            ]),
          ).values(),
        ];
        row.captureFailureSnapshots = [
          row.startupNative,
          row.afterIdle,
          row.before,
          row.after,
        ]
          .map((state) => state.embedded?.lastFailure)
          .filter(Boolean);
        row.portraitArrivalObserved = row.after.media.some(
          (item) =>
            item.tag === "IMG" && item.complete && item.naturalWidth > 0,
        );
        row.nativeLandingPass = row.specification.atEnd
          ? Math.abs(row.after.scroll[1] - row.after.maximumY) <= 2
          : Math.abs(row.after.scroll[1]) <= 2;
        row.nativeCleanupPass =
          row.after.nativeOpacity === 1 &&
          row.after.nativeVisibility === "visible" &&
          row.after.nativeInert === false &&
          row.after.transientPieces === 0 &&
          row.after.transientLayers === 0;
        row.fragmentPreparationBudgetPass =
          row.preparations.every((span) => span.duration <= 160) &&
          row.coldPreparationFailures.length === 0 &&
          row.captureFailureSnapshots.length === 0;
        row.originalBudgetPass =
          row.measurements.normal.budgetPass &&
          row.idleBudgetPass &&
          row.nativeLandingPass &&
          row.nativeCleanupPass &&
          row.fragmentPreparationBudgetPass;
        if (row.specification.portraitArrival)
          row.originalBudgetPass &&= row.portraitArrivalObserved;
        row.trace = await nativeTrace.finish(cdp, traceFile);
        tracing = false;
        await drainResponses(responseChecks);
        row.checkedFiles = [...checkedFiles].sort();
        row.errors = errors;
        assert.deepEqual(errors, []);
        row.status = "collected";
      } catch (error) {
        row.status = "failed";
        row.error = error.stack || error.message;
        if (session) {
          row.rawFailure = await diagnostic
            .snapshot(session.page)
            .catch((failure) => ({ error: failure.message }));
          row.nativeFailure = await nativeSnapshot(session.page).catch(
            (failure) => ({ error: failure.message }),
          );
        }
      } finally {
        if (tracing && session)
          row.trace = await nativeTrace
            .finish(session.cdp, traceFile)
            .catch((error) => ({ error: error.message }));
        if (session) await session.browser.close();
      }
      if (row.trace?.sha256) row.nativeWork = nativeTrace.summarize(traceFile);
      save();
      console.log(
        JSON.stringify({
          id: row.id,
          status: row.status,
          originalBudgetPass: row.originalBudgetPass,
          callbackP95Ms: row.measurements?.normal.paintCallbackMs.p95,
          gapMaxMs: row.measurements?.normal.paintIntervalsMs.max,
          embeddedObserved: row.embeddedObserved,
          error: row.error?.split("\n")[0] || null,
        }),
      );
    }
    record.pairs = cases.flatMap((specification) =>
      orders.map((_, index) => {
        const rows = record.rows.filter(
          (row) =>
            row.specification.id === specification.id && row.pair === index + 1,
        );
        const baseline = rows.find((row) => row.arm === "legacy"),
          candidate = rows.find((row) => row.arm === "fragments");
        const result = {
          case: specification.id,
          pair: index + 1,
          order: rows.map((row) => row.arm),
          complete:
            baseline?.status === "collected" &&
            candidate?.status === "collected",
          originalPictureCondition: specification.deferred
            ? "unmet/deferred"
            : "required where specified",
        };
        if (!result.complete) return result;
        result.frozenInputMatched = freezeMatch(
          baseline.before,
          candidate.before,
        );
        result.sameQualityAndCadenceTrace =
          JSON.stringify([
            ...new Set(
              baseline.raw.states.map((state) =>
                [state.quality, state.cadence, state.geometry].join("/"),
              ),
            ),
          ]) ===
          JSON.stringify([
            ...new Set(
              candidate.raw.states.map((state) =>
                [state.quality, state.cadence, state.geometry].join("/"),
              ),
            ),
          ]);
        const work = (row) =>
          row.nativeWork?.valid ? row.nativeWork.nativeWork?.p95Ms : null;
        result.nativeWorkAvailable =
          Number.isFinite(work(baseline)) && Number.isFinite(work(candidate));
        result.delta = {
          preparationMs:
            candidate.inclusivePreparationUnionMs -
            baseline.inclusivePreparationUnionMs,
          inclusiveNativeWorkP95Ms: result.nativeWorkAvailable
            ? work(candidate) - work(baseline)
            : null,
          inputToReadyMs:
            candidate.measurements.inputToReadyMs -
            baseline.measurements.inputToReadyMs,
          callbackP95Ms:
            candidate.measurements.normal.paintCallbackMs.p95 -
            baseline.measurements.normal.paintCallbackMs.p95,
          idleBusyPercentagePoints:
            candidate.idle.callbackBusyPercent -
            baseline.idle.callbackBusyPercent,
        };
        result.observableFragments = candidate.embeddedObserved;
        result.originalBudgetsPass =
          baseline.originalBudgetPass && candidate.originalBudgetPass;
        return result;
      }),
    );
    record.addedCost = cases.map((specification) => {
      const pairs = record.pairs.filter(
        (pair) => pair.case === specification.id,
      );
      const deltas = Object.fromEntries(
        ["preparationMs", "inclusiveNativeWorkP95Ms", "inputToReadyMs"].map(
          (metric) => [
            metric,
            median(pairs.map((pair) => pair.delta?.[metric])),
          ],
        ),
      );
      const limits = {
        preparationMs: specification.profile === "desktop" ? 30 : 50,
        inclusiveNativeWorkP95Ms: specification.profile === "desktop" ? 8 : 12,
        inputToReadyMs: 100,
      };
      const comparable =
        pairs.length === 3 &&
        pairs.every(
          (pair) =>
            pair.complete &&
            pair.frozenInputMatched &&
            pair.sameQualityAndCadenceTrace &&
            pair.nativeWorkAvailable &&
            pair.observableFragments &&
            pair.originalBudgetsPass,
        );
      return {
        case: specification.id,
        medians: deltas,
        limits,
        comparable,
        numericPartialDiagnosticPass:
          comparable &&
          Object.keys(limits).every(
            (metric) =>
              Number.isFinite(deltas[metric]) &&
              deltas[metric] <= limits[metric],
          ),
        originalPictureDepartureDeferred: !!specification.deferred,
        wholeAdmission: false,
      };
    });
    record.complete =
      record.rows.length === 24 &&
      record.rows.every((row) => row.status === "collected");
    record.counts = {
      planned: 24,
      collected: record.rows.filter((row) => row.status === "collected").length,
      failed: record.rows.filter((row) => row.status === "failed").length,
      originalBudgetPass: record.rows.filter((row) => row.originalBudgetPass)
        .length,
    };
    record.wholeAdmission = false;
    save();
    record.ownerHashesUnchanged = ownerPaths.every(
      (file) => digest(path.join(repository, file)) === ownerHashes[file],
    );
    record.artifactStillVerified = artifact.verify(publicDir, manifest);
    assert.equal(
      record.ownerHashesUnchanged,
      true,
      "runtime owners changed during serial collection",
    );
    save();
    return {
      reportFile,
      complete: record.complete,
      counts: record.counts,
      addedCost: record.addedCost,
      fullGate: false,
      nativeDeviceProof: false,
      deploymentAuthorized: false,
      wholeAdmission: false,
    };
  } finally {
    served.server.close();
  }
}
if (require.main === module)
  main(argumentsFor(process.argv.slice(2)))
    .then((result) => console.log(JSON.stringify(result)))
    .catch((error) => {
      console.error(error.stack);
      process.exitCode = 1;
    });
module.exports = {
  argumentsFor,
  profiles,
  cases,
  orders,
  incremental,
  protocol,
  median,
  freezeMatch,
  main,
};
