'use strict';
const fs = require('node:fs');
const repo = '/workspace/scratch/fa77374a3907/author-site';
const [artifactDir, output] = process.argv.slice(2);
process.env.SITE_PUBLIC_DIR = artifactDir + '/public';
process.env.SITE_ARTIFACT_MANIFEST = artifactDir + '/artifact.json';
const pw = require(repo + '/tools/quality/toolchain/node_modules/playwright');
const artifact = JSON.parse(fs.readFileSync(process.env.SITE_ARTIFACT_MANIFEST));
const result = { scope: 'One portrait Chromium138 touch/DPR2 context; fixed Home/Research round trip and short resting windows; diagnostic, not native iPad or performance acceptance', artifact, observations: [] };
function observe() {
  window.__cost = { frames: [], stages: [], draws: 0, submittedPixels: 0 };
  const original = CanvasRenderingContext2D.prototype.drawImage;
  CanvasRenderingContext2D.prototype.drawImage = function (...args) {
    window.__cost.draws++;
    const sourceWidth = args.length === 9 ? args[3] : args[0].width;
    const sourceHeight = args.length === 9 ? args[4] : args[0].height;
    window.__cost.submittedPixels += sourceWidth * sourceHeight;
    return original.apply(this, args);
  };
  window.SiteEngineStages = true;
  window.SiteEngineProbe = (sample) => {
    if (sample.kind === 'stage' && sample.part.startsWith('draw-')) {
      window.__cost.stages.push({ at: performance.now(), part: sample.part, duration: sample.duration });
    } else if (sample.kind === 'paint') {
      window.__cost.frames.push({ at: performance.now(), duration: sample.duration, part: document.querySelector('.space-scene')?.dataset.embeddedPhase || 'idle', draws: window.__cost.draws, submittedPixels: window.__cost.submittedPixels });
      window.__cost.draws = 0;
      window.__cost.submittedPixels = 0;
    }
  };
}
function stats(values) {
  const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
  const at = (p) => sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * p))];
  return { count: sorted.length, min: at(0), p50: at(0.5), p95: at(0.95), max: at(1) };
}
(async () => {
  let browser, server;
  try {
    require(repo + '/tools/quality/artifact.cjs').verify(process.env.SITE_PUBLIC_DIR, artifact);
    const setup = await require(repo + '/tools/quality/serve.cjs').start();
    server = setup.server;
    browser = await pw.chromium.launch({ headless: true, executablePath: '/tmp/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    result.engine = browser.version();
    const context = await browser.newContext({ viewport: { width: 1024, height: 1366 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, reducedMotion: 'no-preference' });
    await context.addInitScript(() => {
      localStorage.setItem('vo.motion', 'on');
      localStorage.setItem('vo.content-flight', 'on');
      localStorage.setItem('vo.fragment-preview', 'on');
      localStorage.setItem('vo.theme', 'light');
    });
    await context.addInitScript(observe);
    const page = await context.newPage();
    result.errors = [];
    page.on('pageerror', (error) => result.errors.push(String(error)));
    async function ready(current, next) {
      await page.waitForFunction(([current, next]) => {
        const d = window.SiteEffects?.embedded?.diagnostics();
        return d?.residentRoutes.includes(current) && d.residentRoutes.includes(next) && !d.pendingRoute && !d.phase && d.residentReveals?.every((item) => item.progress === 1);
      }, [current, next], { timeout: 15000 });
    }
    async function reset() {
      await page.evaluate(() => { window.__cost = { frames: [], stages: [], draws: 0, submittedPixels: 0 }; });
    }
    async function collect(name) {
      const measured = await page.evaluate(() => ({ cost: window.__cost, diagnostics: window.SiteEffects.embedded.diagnostics(), scene: { ...document.querySelector('.space-scene').dataset } }));
      const summary = Object.fromEntries(['draw-project', 'draw-effects', 'draw-sort', 'draw-paint'].map((part) => [part, stats(measured.cost.stages.filter((item) => item.part === part).map((item) => item.duration))]));
      summary.submissions = stats(measured.cost.frames.map((item) => item.draws));
      summary.submittedPixels = stats(measured.cost.frames.map((item) => item.submittedPixels));
      result.observations.push({ name, summary, ...measured });
      fs.writeFileSync(output, JSON.stringify(result, null, 2));
      console.log(JSON.stringify({ name, summary, phase: measured.diagnostics.phase, residentUsage: measured.diagnostics.residentUsage, lastFailure: measured.diagnostics.lastFailure }));
    }
    await page.goto(setup.url + '/index.html', { waitUntil: 'domcontentloaded' });
    await ready('index', 'research');
    await reset();
    await page.waitForTimeout(1800);
    await collect('Home resting');
    for (const [target, next] of [['research', 'writing'], ['index', 'research']]) {
      await reset();
      await page.locator('body > .site-header nav a[href="' + (target === 'index' ? './' : target + '.html') + '"]').tap();
      await page.waitForFunction((target) => document.body.dataset.page === target && !document.querySelector('#site-content').hasAttribute('aria-busy') && !window.SiteEffects.embedded.diagnostics().phase, target, { timeout: 10000 });
      await collect('Flight to ' + target);
      await ready(target, next);
      await reset();
      await page.waitForTimeout(1800);
      await collect(target + ' resting');
    }
    result.pass = true;
    await context.close();
  } catch (error) {
    result.pass = false;
    result.error = String(error.stack || error);
    console.error(result.error);
  } finally {
    await browser?.close();
    if (server) await new Promise((resolve) => server.close(resolve));
    fs.writeFileSync(output, JSON.stringify(result, null, 2));
  }
})();
