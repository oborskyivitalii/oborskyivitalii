const fs=require('node:fs');
const root='/workspace/scratch/d9096dfa4c16/author-site';
process.env.SITE_PUBLIC_DIR='/tmp/issue49-baseline/public';
const pw=require(root+'/tools/quality/toolchain/node_modules/playwright');
const wk='/root/.cache/ms-playwright/webkit-2359/minibrowser-wpe';
const launch={executablePath:wk+'/bin/MiniBrowser',env:{...process.env,LD_LIBRARY_PATH:'/workspace/scratch/c645f383c871/browser-deps/usr/lib/x86_64-linux-gnu:/workspace/scratch/c645f383c871/browser-deps/lib/x86_64-linux-gnu:'+wk+'/lib:'+wk+'/sys/lib',WEBKIT_EXEC_PATH:wk+'/bin',WEBKIT_INJECTED_BUNDLE_PATH:wk+'/lib',WEBKIT_INSPECTOR_RESOURCES_PATH:wk+'/share',WEBKIT_FORCE_COMPLEX_TEXT:'1'}};
(async()=>{
const {server,url}=await require(root+'/tools/quality/serve.cjs').start();
let browser;const rows=[];
try{
for(const hint of ['default','load-only','sync']){
browser=await pw.webkit.launch(launch);
const c=await browser.newContext({viewport:{width:1024,height:1366}});const page=await c.newPage();
await page.addInitScript(()=>{localStorage.setItem('vo.fragment-preview','off');localStorage.setItem('vo.motion','off');});
await page.goto(url+'/research.html');await page.waitForFunction(()=>document.fonts.status==='loaded');
const factory=fs.readFileSync(root+'/site/effects/embedded-texture.cjs','utf8').split('module.exports = ')[1].replace(/;\s*$/,'');
const row=await page.evaluate(async({hint,factory})=>{
const button=document.getElementById('space-motion');if(button?.getAttribute('aria-pressed')==='true')button.click();
const original=Object.getOwnPropertyDescriptor(HTMLImageElement.prototype,'src');const decode=HTMLImageElement.prototype.decode;
const events=[];let zero=performance.now();let polls=[];
Object.defineProperty(HTMLImageElement.prototype,'src',{...original,set(value){if(value.startsWith('data:image/svg+xml;')){if(hint==='sync')this.decoding='sync';const self=this;zero=performance.now();original.set.call(this,value);events.push({event:'src',time:performance.now()-zero,complete:self.complete,width:self.naturalWidth,characters:value.length});queueMicrotask(()=>events.push({event:'microtask',time:performance.now()-zero,complete:self.complete,width:self.naturalWidth}));let steps=0;const timer=setInterval(()=>{steps++;if(self.complete||steps>60){events.push({event:'complete',time:performance.now()-zero,complete:self.complete,width:self.naturalWidth});clearInterval(timer);}},2);polls.push(timer);}else original.set.call(this,value);}});
HTMLImageElement.prototype.decode=hint==='load-only'?undefined:function(){const self=this;return decode.call(this).then(()=>{events.push({event:'decode',time:performance.now()-zero,complete:self.complete,width:self.naturalWidth});});};
const failures=[],timings=[];let asset;
try{const adapter=Function('return ('+factory+')')()();asset=await adapter.captureField(document.getElementById('site-content'),{width:innerWidth,height:innerHeight,dpr:1,caps:{owners:32,descendants:1500,textBytes:32768,layerPixels:8000000},onReject:r=>failures.push(r),onTiming:t=>timings.push(t)});return{hint,pass:!!asset,events,failures,timings};}
finally{asset?.dispose();polls.forEach(clearInterval);Object.defineProperty(HTMLImageElement.prototype,'src',original);HTMLImageElement.prototype.decode=decode;}
},{hint,factory});rows.push(row);await c.close();await browser.close();}
}finally{await browser.close();server.close();}
fs.writeFileSync('/tmp/issue49-cold-readiness.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});