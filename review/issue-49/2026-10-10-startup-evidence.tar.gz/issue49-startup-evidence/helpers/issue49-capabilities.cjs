'use strict';
const root='/workspace/scratch/d9096dfa4c16/author-site';
const pw=require(root+'/tools/quality/toolchain/node_modules/playwright');
const wk='/root/.cache/ms-playwright/webkit-2359/minibrowser-wpe';
const options={
  executablePath:wk+'/bin/MiniBrowser',
  env:{...process.env,
    LD_LIBRARY_PATH:'/workspace/scratch/c645f383c871/browser-deps/usr/lib/x86_64-linux-gnu:/workspace/scratch/c645f383c871/browser-deps/lib/x86_64-linux-gnu:'+wk+'/lib:'+wk+'/sys/lib',
    WEBKIT_EXEC_PATH:wk+'/bin', WEBKIT_INJECTED_BUNDLE_PATH:wk+'/lib',
    WEBKIT_INSPECTOR_RESOURCES_PATH:wk+'/share', WEBKIT_FORCE_COMPLEX_TEXT:'1'
  }
};
(async()=>{const b=await pw.webkit.launch(options);const p=await b.newPage();console.log(await p.evaluate(()=>({idle:typeof requestIdleCallback,cancelIdle:typeof cancelIdleCallback,decode:typeof Image.prototype.decode,version:navigator.userAgent})));await b.close();})().catch(console.error);