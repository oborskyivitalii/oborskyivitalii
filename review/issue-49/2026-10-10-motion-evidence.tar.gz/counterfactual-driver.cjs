'use strict';
const fs=require('node:fs');
const root='/workspace/scratch/d9096dfa4c16/author-site';
process.env.SITE_PUBLIC_DIR='/tmp/issue49-motion-synchronised/public';
const pw=require(root+'/tools/quality/toolchain/node_modules/playwright');
const wk='/root/.cache/ms-playwright/webkit-2359/minibrowser-wpe';
const opts={executablePath:wk+'/bin/MiniBrowser',env:{...process.env,LD_LIBRARY_PATH:'/tmp/issue49-motion-deps/usr/lib/x86_64-linux-gnu:'+wk+'/lib:'+wk+'/sys/lib',WEBKIT_EXEC_PATH:wk+'/bin',WEBKIT_INJECTED_BUNDLE_PATH:wk+'/lib',WEBKIT_INSPECTOR_RESOURCES_PATH:wk+'/share',WEBKIT_FORCE_COMPLEX_TEXT:'1'}};
async function init(){
 try { localStorage.setItem('vo.theme','light');localStorage.setItem('vo.motion','on');localStorage.setItem('vo.content-flight','on');localStorage.setItem('vo.fragment-preview','on'); } catch {}
 window.SiteEngineStages=true;window.__motion=[];window.__stages={};window.__raf=[];
 const raf=window.requestAnimationFrame;
 window.requestAnimationFrame=(callback)=>raf(t=>{const t0=performance.now(),n=window.__motion.length;callback(t);if(window.__motion.length>n)window.__raf.push({t,duration:performance.now()-t0});});
 window.SiteEngineProbe=s=>{
  if(!window.__record)return;
  if(s.kind==='stage'){window.__stages[s.part]=s.duration;return;}
  if(s.kind!=='paint')return;
  const d=window.SiteEffects?.embedded?.diagnostics();
  window.__motion.push({t:performance.now(),clock:s.ambientTime,camera:s.current,journey:s.journey?{elapsed:s.journey.elapsed,duration:s.journey.duration,progressStart:s.journey.progressStart}:null,phase:d?.phase,travelProgress:d?.travelProgress,progress:d?.progress,handoff:d?.handoff,physical:d?.physicalProgress,failure:d?.lastFailure,cadence:document.querySelector('.space-scene')?.dataset.cadence,quality:document.querySelector('.space-scene')?.dataset.quality,fronts:d?.faces.filter(f=>f.face==='front'&&d.ids.includes(f.id)),nativeOpacity:document.getElementById('site-content').style.opacity,stages:window.__stages});window.__stages={};
 };
}
(async()=>{
 const {server,url}=await require(root+'/tools/quality/serve.cjs').start();
 const browser=await pw.webkit.launch(opts);
 try{
  const video=process.argv.includes('--video');
  const ctx=await browser.newContext({viewport:{width:1024,height:1366},deviceScaleFactor:2,isMobile:true,hasTouch:true,...(video?{recordVideo:{dir:'/tmp/issue49-motion-video',size:{width:1024,height:1366}}}:{})});
  await ctx.addInitScript(init);const p=await ctx.newPage();
  p.on('pageerror',e=>console.error('pageerror',e.message));
  await p.goto(url,{waitUntil:'networkidle'});
  await p.waitForFunction(()=>{const d=window.SiteEffects?.embedded?.diagnostics();return d?.ready&&!d.pendingRoute&&d.residentRoutes.includes('research');},{},{timeout:20000});
  console.log('initial',JSON.stringify(await p.evaluate(()=>window.SiteEffects?.embedded?.diagnostics()).then(d=>({ready:d.ready,route:d.route,resident:d.residentRoutes,failure:d.lastFailure,timings:d.captureTimings}))));await p.waitForTimeout(400);
  await p.evaluate(()=>{window.__record=true;window.__motion=[];window.__raf=[];});
  const journeys=[];
  for(const [from,to] of [['index','research'],['research','index']]){
   await p.evaluate(()=>{window.__motion=[];window.__raf=[];});
   await p.locator('body > .site-header nav a[href="'+(to==='index'?'./':to+'.html')+'"]').tap();
   await p.waitForFunction(v=>document.body.dataset.page===v&&!window.SiteEffects?.embedded?.active()&&document.querySelector('.space-scene')?.dataset.travel==='settled'&&!document.getElementById('site-content').hasAttribute('aria-busy'),to,{timeout:20000});
   await p.waitForTimeout(300);
   journeys.push({from,to,...await p.evaluate(()=>({frames:window.__motion,raf:window.__raf}))});
   await p.screenshot({path:'/tmp/issue49-motion-'+to+(video?'-video':'')+'.png'});
   if(to==='research')await p.waitForTimeout(600);
  }
  const out='/tmp/issue49-motion-counterfactual-webkit-'+(video?'video':'plain')+'.json';fs.writeFileSync(out,JSON.stringify({diagnosticCounterfactual:true,source:'50eb63d31466c6975a533f45671419ce6b824a4b',baselinePublicDigest:'054fde357fa04044f51b3942cc8038904b27e688bc481fd35d047c73866fe2fe',video,journeys}));
  console.log(JSON.stringify({out,journeys:journeys.map(j=>({from:j.from,to:j.to,frames:j.frames.length,ms:j.frames.at(-1).t-j.frames[0].t,maxRaf:Math.max(...j.raf.map(f=>f.duration)),maxEffects:Math.max(...j.frames.map(f=>f.stages['draw-effects']||0)),maxPaint:Math.max(...j.frames.map(f=>f.stages['draw-paint']||0))}))}));
  const vid=p.video();await ctx.close();if(vid)console.log('video',await vid.path());
 }finally{await browser.close();server.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
