'use strict';
(()=>{window.SiteEffects={...window.SiteEffects,contract:1};
const flightPose=function flightPose(progress, direction, departure = { z: 0, opacity: 1 }) {
  const clamp = (t) => Math.max(0, Math.min(1, t)),
    smooth = (t) => {
      t = clamp(t);
      return t * t * (3 - 2 * t);
    };
  progress = clamp(progress);
  if (progress === 1) return { stage: 'settled', z: 0, opacity: 1 };
  if (progress < 0.5) {
    const t = clamp(progress / 0.46),
      eased = smooth(t),
      end = direction === 'forward' ? 1050 : -3600;
    return {
      stage: 'depart',
      z: departure.z + (end - departure.z) * eased,
      opacity: departure.opacity * (1 - smooth((t - 0.22) / 0.78)),
    };
  }
  const t = clamp((progress - 0.5) / 0.5),
    near = direction === 'backward' ? 1020 : -4200;
  return {
    stage: 'arrive',
    z: near * (1 - smooth(t)),
    opacity: Math.min(0.999, smooth((t - 0.02) / 0.98)),
  };
};
const fragmentPlan=function ({ cameraView }) {
  // Fragment policy is shared by every route and both presentation directions.
  // Pixel dimensions describe native paint; depth describes scene world units.
  const settings = Object.freeze({
    preparationMs: 160,
    acquisitionMs: 80,
    allocationMs: 110,
    nativeDepth: 12,
    facetGutterPx: 36,
    arrivalDurationMs: 1800,
    departureEndProgress: 0.46,
    departureReleaseProgress: 0.2,
    depthHaze: 22,
    motion: Object.freeze({
      forwardDepartureDepths: 2.5,
      backwardDepartureDepths: 3,
      reverseArrivalDepths: 0.65,
      minimumScale: 0.08,
      curvedSpread: 0.65,
      arrivalVisibleFraction: 0.2,
      departureFadeFraction: 0.25,
    }),
    shard: Object.freeze({
      minSizePx: 2,
      textWidthPx: 28,
      imageWidthPx: 72,
      maxOwnerPieces: 32,
      thicknessMinPx: 2,
      thicknessMaxPx: 14,
      rollRadians: 1.8,
      tiltRadians: 1.6,
    }),
    caps: Object.freeze({
      compact: Object.freeze({
        pieces: 40,
        owners: 20,
        descendants: 600,
        textBytes: 12288,
        layerPixels: 3000000,
      }),
      full: Object.freeze({
        pieces: 96,
        owners: 32,
        descendants: 1500,
        textBytes: 32768,
        layerPixels: 8000000,
      }),
    }),
  });
  const finiteVector = (value, length) =>
    Array.isArray(value) && value.length === length && value.every(Number.isFinite);
  const validRect = (rect) =>
    rect &&
    ['x', 'y', 'width', 'height'].every((key) => Number.isFinite(rect[key])) &&
    rect.width > 0 &&
    rect.height > 0 &&
    Number.isFinite(rect.x + rect.width) &&
    Number.isFinite(rect.y + rect.height);
  const blend = (a, b, progress) => a.map((value, index) => value + (b[index] - value) * progress);
  const center = (points) =>
    points[0].map((_, index) =>
      points.reduce((sum, point) => sum + point[index] / points.length, 0)
    );
  const smooth = (progress) => progress * progress * (3 - 2 * progress);
  const arrivalDurationMs = settings.arrivalDurationMs;

  function pieceCount(rect, { image = false, lineHeight = 28 } = {}) {
    if (!validRect(rect) || !Number.isFinite(lineHeight) || lineHeight <= 0) return 0;
    const targetArea = image
      ? settings.shard.imageWidthPx ** 2
      : settings.shard.textWidthPx * lineHeight;
    return Math.max(
      1,
      Math.min(settings.shard.maxOwnerPieces, Math.ceil((rect.width * rect.height) / targetArea))
    );
  }

  function arrivalWindow(elapsedMs, preparedMs) {
    if (![elapsedMs, preparedMs].every((value) => Number.isFinite(value) && value >= 0)) return 0;
    // Reserve a painted-frame/ready-task margin inside the existing 3200ms
    // admission gate. A late reverse arrival still gets at least one full second.
    const availableMs = Math.min(arrivalDurationMs, 2900 - elapsedMs - preparedMs);
    return availableMs >= 1000 ? availableMs : 0;
  }

  function arrivalSchedule(groups, durationMs = arrivalDurationMs) {
    if (
      !Number.isFinite(durationMs) ||
      durationMs < 1000 ||
      durationMs > arrivalDurationMs ||
      !Array.isArray(groups) ||
      !groups.length ||
      groups.length > 32 ||
      groups.some(
        (group) =>
          !group ||
          !validRect(group.rect) ||
          !Array.isArray(group.cells) ||
          !group.cells.length ||
          group.cells.some((cell) => !validRect(cell))
      )
    )
      return null;
    const arrivalPieceMs = durationMs / 2;
    const ordered = groups
      .map((group, owner) => ({ ...group, owner }))
      .sort((a, b) => a.rect.y - b.rect.y || a.rect.x - b.rect.x);
    const tiles = [];
    for (const group of ordered) {
      const cells = group.cells
        .map((cell, index) => ({ cell, index }))
        .sort((a, b) => a.cell.y - b.cell.y || a.cell.x - b.cell.x);
      for (const { cell, index } of cells) {
        if (!validRect(cell) || tiles.length >= 96) return null;
        tiles.push({ owner: group.owner, index });
      }
    }
    const result = groups.map((group) => group.cells.map(() => null));
    for (let rank = 0; rank < tiles.length; rank++) {
      const { owner, index } = tiles[rank];
      result[owner][index] = {
        delayMs: ((durationMs - arrivalPieceMs) * rank) / Math.max(1, tiles.length - 1),
        durationMs: arrivalPieceMs,
      };
    }
    return result;
  }

  function departureSchedule(groups) {
    const arrivals = arrivalSchedule(groups);
    if (!arrivals) return null;
    return arrivals.map((cells) =>
      cells.map(({ delayMs }) => ({
        delayProgress: (delayMs / arrivalDurationMs) * settings.departureReleaseProgress * 2,
        durationProgress: settings.departureEndProgress - settings.departureReleaseProgress,
      }))
    );
  }

  function randomSource(seed) {
    let state = seed >>> 0;
    return () => {
      state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
      return state / 4294967296;
    };
  }

  function admit(usage, caps) {
    if (!usage || !caps) return false;
    const keys = Object.keys(caps);
    return (
      keys.length > 0 &&
      keys.length <= 8 &&
      Object.keys(usage).length === keys.length &&
      keys.every(
        (key) =>
          Object.prototype.hasOwnProperty.call(usage, key) &&
          Number.isFinite(caps[key]) &&
          caps[key] > 0 &&
          Number.isFinite(usage[key]) &&
          usage[key] >= 0 &&
          usage[key] <= caps[key]
      )
    );
  }

  const polygonArea = (points) =>
    Math.abs(
      points.reduce((sum, point, index) => {
        const next = points[(index + 1) % points.length];
        return sum + point[0] * next[1] - next[0] * point[1];
      }, 0)
    ) / 2;

  function polygonBounds(points) {
    const x = Math.min(...points.map((point) => point[0]));
    const y = Math.min(...points.map((point) => point[1]));
    return {
      x,
      y,
      width: Math.max(...points.map((point) => point[0])) - x,
      height: Math.max(...points.map((point) => point[1])) - y,
    };
  }

  function convexPolygon(points) {
    let orientation = 0;
    for (let index = 0; index < points.length; index++) {
      const a = points[index];
      const b = points[(index + 1) % points.length];
      const c = points[(index + 2) % points.length];
      if (Math.hypot(b[0] - a[0], b[1] - a[1]) < 1e-8) return false;
      const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
      if (Math.abs(cross) < 1e-8) continue;
      const sign = Math.sign(cross);
      if (orientation && sign !== orientation) return false;
      orientation = sign;
    }
    // Front silhouettes and prism side winding use screen-clockwise vertices.
    return orientation === 1;
  }

  function cutPolygon(points, normal, offset, side) {
    const result = [];
    for (let index = 0; index < points.length; index++) {
      const a = points[index];
      const b = points[(index + 1) % points.length];
      const da = a[0] * normal[0] + a[1] * normal[1] - offset;
      const db = b[0] * normal[0] + b[1] * normal[1] - offset;
      if (da * side >= 0) result.push(a);
      if ((da < 0 && db > 0) || (da > 0 && db < 0)) {
        const progress = da / (da - db);
        result.push([a[0] + (b[0] - a[0]) * progress, a[1] + (b[1] - a[1]) * progress]);
      }
    }
    return result;
  }

  function splitPolygon(points, random, minSize, fine) {
    const bounds = polygonBounds(points);
    for (let attempt = 0; attempt < 12; attempt++) {
      const fineCut = fine && attempt < 6;
      const angle =
        (bounds.width >= bounds.height ? 0 : Math.PI / 2) +
        (random() - 0.5) * (fineCut ? 0.16 : 1.5);
      const normal = [Math.cos(angle), Math.sin(angle)];
      const distances = points.map((point) => point[0] * normal[0] + point[1] * normal[1]);
      const low = Math.min(...distances);
      const fraction = fineCut ? 0.04 + random() * 0.16 : 0.18 + random() * 0.64;
      const offset = low + (Math.max(...distances) - low) * fraction;
      const candidate = [
        cutPolygon(points, normal, offset, 1),
        cutPolygon(points, normal, offset, -1),
      ];
      if (
        candidate.every((part) => {
          const box = polygonBounds(part);
          return (
            part.length >= 3 &&
            part.length <= 10 &&
            box.width >= minSize &&
            box.height >= minSize &&
            polygonArea(part) >= minSize * minSize
          );
        })
      )
        return candidate;
    }
    return null;
  }

  function partition(
    rect,
    { count, seed = 1, minSize = settings.shard.minSizePx },
    { maxPieces, usedPieces = 0 }
  ) {
    // Validate the combined transaction allowance before reading/cloning an owner.
    if (
      !Number.isInteger(maxPieces) ||
      maxPieces < 1 ||
      maxPieces > 96 ||
      !Number.isInteger(usedPieces) ||
      usedPieces < 0 ||
      !Number.isInteger(count) ||
      count < 1 ||
      count + usedPieces > maxPieces ||
      !Number.isInteger(seed) ||
      !Number.isFinite(minSize) ||
      minSize < 0.5
    )
      return null;
    if (!validRect(rect)) return null;
    const cells = [
      [
        [rect.x, rect.y],
        [rect.x + rect.width, rect.y],
        [rect.x + rect.width, rect.y + rect.height],
        [rect.x, rect.y + rect.height],
      ],
    ];
    const random = randomSource(seed);
    while (cells.length < count) {
      let chosen = -1;
      const smallLeaf = cells.length % 4 === 0;
      const ranked = [];
      for (let index = 0; index < cells.length; index++) {
        const cell = polygonBounds(cells[index]);
        const area = polygonArea(cells[index]) * (0.65 + random() * 0.7);
        const priority = smallLeaf ? -area : area;
        if (cell.width >= minSize * 2 || cell.height >= minSize * 2)
          ranked.push({ index, priority });
      }
      ranked.sort((a, b) => b.priority - a.priority);
      let halves = null;
      for (const item of ranked) {
        halves = splitPolygon(cells[item.index], random, minSize, cells.length % 3 === 0);
        if (halves) {
          chosen = item.index;
          break;
        }
      }
      if (!halves) return null;
      cells.splice(chosen, 1, ...halves);
    }
    return cells.map((cell) => ({
      ...polygonBounds(cell),
      polygon: cell,
      seed: Math.floor(random() * 4294967296),
    }));
  }

  function view(pose, width, height, compact = width <= 640) {
    if (
      !pose ||
      !finiteVector(pose.position, 3) ||
      !finiteVector(pose.target, 3) ||
      !Number.isFinite(width) ||
      !Number.isFinite(height) ||
      width <= 0 ||
      height <= 0 ||
      Math.hypot(...pose.target.map((value, index) => value - pose.position[index])) < 1e-6
    )
      return null;
    const result = cameraView(pose, width, height, compact);
    if (
      !['right', 'up', 'forward'].every((key) => finiteVector(result[key], 3)) ||
      !finiteVector(result.origin, 2) ||
      !Number.isFinite(result.focal) ||
      result.focal <= 0 ||
      Math.hypot(...result.up) < 0.5
    )
      return null;
    return { ...result, position: [...pose.position], width, height };
  }

  function unproject(camera, point, depth) {
    if (!camera || !finiteVector(point, 2) || !Number.isFinite(depth) || depth <= 0.5) return null;
    const x = ((point[0] - camera.origin[0]) * depth) / camera.focal;
    const y = ((camera.origin[1] - point[1]) * depth) / camera.focal;
    const result = camera.position.map(
      (value, index) =>
        value + camera.right[index] * x + camera.up[index] * y + camera.forward[index] * depth
    );
    return finiteVector(result, 3) ? result : null;
  }

  function quad(camera, rect, depth = settings.nativeDepth) {
    if (!validRect(rect)) return null;
    const { x, y, width, height } = rect;
    const corners = [
      [x, y],
      [x + width, y],
      [x + width, y + height],
      [x, y + height],
    ].map((point) => unproject(camera, point, depth));
    return corners.every(Boolean) ? corners : null;
  }

  function projectQuad(camera, corners, { near = 0.5 } = {}) {
    if (
      !camera ||
      !Array.isArray(corners) ||
      corners.length !== 4 ||
      !corners.every((point) => finiteVector(point, 3)) ||
      !Number.isFinite(near) ||
      near < 0.5
    )
      return null;
    const transformed = corners.map(camera.camera);
    // Cull the entire decorative tile before a corner crosses the near plane.
    if (transformed.some((point) => !finiteVector(point, 3) || point[2] <= near)) return null;
    const points = transformed.map(camera.project);
    const limit = Math.max(camera.width, camera.height) * 8;
    if (
      points.some(
        (point) => !finiteVector(point, 2) || point.some((value) => Math.abs(value) > limit)
      )
    )
      return null;
    const area =
      Math.abs(
        points.reduce((sum, point, index) => {
          const next = points[(index + 1) % points.length];
          return sum + point[0] * next[1] - next[0] * point[1];
        }, 0)
      ) / 2;
    if (area < 1e-6 || !Number.isFinite(area)) return null;
    const nearest = Math.min(...transformed.map((point) => point[2]));
    return {
      points,
      depth: transformed.reduce((sum, point) => sum + point[2] / 4, 0),
      opacity: Math.min(1, (nearest - near) / near),
    };
  }

  function piece(rect, camera, { depth = settings.nativeDepth, seed = rect?.seed ?? 1 } = {}) {
    if (!Number.isInteger(seed)) return null;
    const corners = quad(camera, rect, depth);
    if (!corners || !projectQuad(camera, corners)) return null;
    const polygon = rect.polygon ?? [
      [rect.x, rect.y],
      [rect.x + rect.width, rect.y],
      [rect.x + rect.width, rect.y + rect.height],
      [rect.x, rect.y + rect.height],
    ];
    if (
      !Array.isArray(polygon) ||
      polygon.length < 3 ||
      polygon.length > 10 ||
      polygon.some(
        (point) =>
          !finiteVector(point, 2) ||
          point[0] < rect.x - 1e-8 ||
          point[1] < rect.y - 1e-8 ||
          point[0] > rect.x + rect.width + 1e-8 ||
          point[1] > rect.y + rect.height + 1e-8
      ) ||
      polygonArea(polygon) < 1e-6 ||
      !convexPolygon(polygon)
    )
      return null;
    const random = randomSource(seed);
    return {
      rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
      corners,
      right: [...camera.right],
      up: [...camera.up],
      forward: [...camera.forward],
      depth,
      polygon: polygon.map((point) => [
        (point[0] - rect.x) / rect.width,
        (point[1] - rect.y) / rect.height,
      ]),
      thickness:
        (Math.min(
          settings.shard.thicknessMaxPx,
          Math.max(
            settings.shard.thicknessMinPx,
            Math.min(rect.width, rect.height) * (0.1 + random() * 0.22)
          )
        ) *
          depth) /
        camera.focal,
      scatter: [(random() - 0.5) * depth, (random() - 0.5) * depth, (random() - 0.5) * depth * 0.3],
      roll: (random() - 0.5) * settings.shard.rollRadians,
      tilt: (random() - 0.5) * settings.shard.tiltRadians,
      pitch: (random() - 0.5) * settings.shard.tiltRadians,
    };
  }

  function scatterCenter(origin, prepared, amount) {
    return origin.map(
      (value, index) =>
        value +
        amount *
          (prepared.right[index] * prepared.scatter[0] +
            prepared.up[index] * prepared.scatter[1] +
            prepared.forward[index] * prepared.scatter[2])
    );
  }

  function turn(corners, origin, basis, roll, tilt, pitch, scale) {
    const source = center(corners);
    return corners.map((point) => {
      const delta = point.map((value, index) => value - source[index]);
      const u = delta.reduce((sum, value, index) => sum + value * basis.right[index], 0);
      const v = delta.reduce((sum, value, index) => sum + value * basis.up[index], 0);
      const x = (u * Math.cos(roll) - v * Math.sin(roll)) * scale;
      const y = (u * Math.sin(roll) + v * Math.cos(roll)) * scale;
      const z = -x * Math.sin(tilt);
      const turnedY = y * Math.cos(pitch) - z * Math.sin(pitch);
      const turnedZ = y * Math.sin(pitch) + z * Math.cos(pitch);
      return origin.map(
        (value, index) =>
          value +
          basis.right[index] * x * Math.cos(tilt) +
          basis.up[index] * turnedY +
          basis.forward[index] * turnedZ
      );
    });
  }

  function facets(prepared, corners, camera, amount) {
    if (amount <= 1e-8) return [];
    const u = corners[1].map((value, index) => value - corners[0][index]);
    const v = corners[3].map((value, index) => value - corners[0][index]);
    const normal = [
      u[1] * v[2] - u[2] * v[1],
      u[2] * v[0] - u[0] * v[2],
      u[0] * v[1] - u[1] * v[0],
    ];
    const length = Math.hypot(...normal);
    if (length < 1e-9) return [];
    const offset = normal.map((value) => (value * prepared.thickness * amount) / length);
    const front = prepared.polygon.map(([x, y]) =>
      corners[0].map((value, index) => value + u[index] * x + v[index] * y)
    );
    const back = front.map((point) => point.map((value, index) => value + offset[index]));
    const result = [];
    for (let index = 0; index < front.length; index++) {
      const next = (index + 1) % front.length;
      const projected = projectQuad(camera, [front[index], front[next], back[next], back[index]]);
      if (!projected) continue;
      // Only the sides outside the front silhouette can be seen. The back stays
      // behind its native-paint face and never adds a second text copy.
      const [a, b, c] = projected.points;
      const facing = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
      if (facing < -1e-8)
        result.push({
          points: projected.points,
          light: b[1] - a[1] < b[0] - a[0],
        });
    }
    return result;
  }

  function sample(
    prepared,
    { phase, progress, view: camera, anchor = null, sourceAnchor = null, direction = 'forward' }
  ) {
    if (
      !prepared ||
      !camera ||
      !Number.isFinite(progress) ||
      progress < 0 ||
      progress > 1 ||
      !['depart', 'arrive'].includes(phase) ||
      !['forward', 'backward'].includes(direction)
    )
      return null;
    const eased = smooth(progress);
    let corners;
    if (phase === 'depart') {
      const nativeCenter = center(prepared.corners);
      // Admit the source against the captured departure plane once. Rechecking
      // against a moving camera would switch destinations halfway through a tile.
      const anchorDepth = finiteVector(sourceAnchor, 3)
        ? sourceAnchor.reduce(
            (depth, value, index) =>
              depth + (value - nativeCenter[index]) * prepared.forward[index],
            prepared.depth
          )
        : -Infinity;
      const end =
        direction === 'forward'
          ? nativeCenter.map(
              (value, index) =>
                value -
                prepared.forward[index] * prepared.depth * settings.motion.forwardDepartureDepths
            )
          : anchorDepth >= prepared.depth
            ? sourceAnchor
            : nativeCenter.map(
                (value, index) =>
                  value +
                  prepared.forward[index] * prepared.depth * settings.motion.backwardDepartureDepths
              );
      const origin = scatterCenter(
        blend(nativeCenter, end, eased),
        prepared,
        Math.sin(progress * Math.PI)
      );
      corners = turn(
        prepared.corners,
        origin,
        prepared,
        prepared.roll * eased,
        prepared.tilt * eased,
        prepared.pitch * eased,
        direction === 'backward' ? 1 - eased * (1 - settings.motion.minimumScale) : 1
      );
    } else {
      if (direction === 'forward' && !finiteVector(anchor, 3)) return null;
      const target = quad(camera, prepared.rect, prepared.depth);
      if (!target) return null;
      const start =
        direction === 'backward'
          ? camera.position.map(
              (value, index) =>
                value -
                camera.forward[index] * prepared.depth * settings.motion.reverseArrivalDepths
            )
          : anchor;
      // Forward arrivals leave the real room; reverse arrivals cross the camera
      // from behind. Both close at the same exact native reading rectangle.
      const origin = scatterCenter(
        blend(start, center(target), eased),
        prepared,
        Math.sin(progress * Math.PI) * settings.motion.curvedSpread
      );
      corners = turn(
        target,
        origin,
        camera,
        prepared.roll * (1 - eased),
        prepared.tilt * (1 - eased),
        prepared.pitch * (1 - eased),
        direction === 'backward'
          ? 1
          : settings.motion.minimumScale + eased * (1 - settings.motion.minimumScale)
      );
    }
    const result = projectQuad(camera, corners);
    if (!result) return null;
    const visibility =
      phase === 'arrive'
        ? Math.min(1, progress / settings.motion.arrivalVisibleFraction)
        : Math.min(1, (1 - progress) / settings.motion.departureFadeFraction);
    // World-space attenuation changes with the actual painted camera, so two
    // equally timed pieces at different depths do not have the same opacity.
    const depthOpacity = Math.exp(
      -Math.max(0, result.depth - prepared.depth - 1e-8) / settings.depthHaze
    );
    return {
      ...result,
      opacity: result.opacity * visibility * depthOpacity,
      facets: facets(prepared, corners, camera, Math.sin(progress * Math.PI)),
    };
  }

  return {
    settings,
    pieceCount,
    departureSchedule,
    arrivalDurationMs,
    arrivalWindow,
    arrivalSchedule,
    admit,
    partition,
    view,
    unproject,
    quad,
    projectQuad,
    piece,
    sample,
  };
};
const embeddedPlan=function ({ cameraView, depthVisibility, loopTransform }) {
  const settings = Object.freeze({
    nativeDepth: 12,
    maxPieces: 32,
    maxVertices: 10,
    thicknessMinPx: 18,
    thicknessMaxPx: 64,
    embeddedScale: 2.2,
    restExtrusion: 2.4,
    chipRadiusMax: 0.9,
    chipBranchRadius: 0.85,
    chipThickness: 0.22,
    departureBreakup: 0.26,
    forwardLateralStop: 0.5,
    forwardOrientationStop: 0.65,
    forwardGrowthStart: 0.35,
    returnStop: 0.4,
    contentVisibilityFloor: 1,
    textureErrorPx: 1,
    textureTriangles: 8,
    near: 0.5,
  });
  const vector = (value, length) =>
    Array.isArray(value) && value.length === length && value.every(Number.isFinite);
  const validRect = (rect) =>
    rect &&
    ['x', 'y', 'width', 'height'].every((key) => Number.isFinite(rect[key])) &&
    rect.width > 0 &&
    rect.height > 0 &&
    Number.isFinite(rect.x + rect.width) &&
    Number.isFinite(rect.y + rect.height);
  const add = (a, b) => a.map((value, index) => value + b[index]);
  const sub = (a, b) => a.map((value, index) => value - b[index]);
  const dot = (a, b) => a.reduce((sum, value, index) => sum + value * b[index], 0);
  const cross = (a, b) => [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
  const scale = (a, amount) => a.map((value) => value * amount);
  const normalize = (a) => {
    const length = Math.hypot(...a);
    return length > 1e-9 ? scale(a, 1 / length) : null;
  };
  const blend = (a, b, progress) =>
    progress === 1 ? [...b] : a.map((value, index) => value + (b[index] - value) * progress);
  const center = (points) =>
    points[0].map((_, index) =>
      points.reduce((sum, point) => sum + point[index] / points.length, 0)
    );
  const smooth = (progress) => progress * progress * (3 - 2 * progress);
  const light = normalize([-0.55, 0.85, 1]);
  let paletteKey = '';
  let palette = null;
  const layouts = new WeakMap();

  function faceNormal(points) {
    // Convex canonical cells may begin with collinear boundary vertices.
    // Newell's normal uses the full polygon rather than one fragile corner.
    const normal = [0, 0, 0];
    for (let index = 0; index < points.length; index++) {
      const a = points[index];
      const b = points[(index + 1) % points.length];
      normal[0] += (a[1] - b[1]) * (a[2] + b[2]);
      normal[1] += (a[2] - b[2]) * (a[0] + b[0]);
      normal[2] += (a[0] - b[0]) * (a[1] + b[1]);
    }
    return normalize(normal);
  }

  function view(pose, width, height) {
    if (
      !pose ||
      !vector(pose.position, 3) ||
      !vector(pose.target, 3) ||
      !Number.isFinite(width) ||
      !Number.isFinite(height) ||
      width <= 0 ||
      height <= 0 ||
      Math.hypot(...sub(pose.target, pose.position)) < 1e-6
    )
      return null;
    const result = cameraView(pose, width, height);
    if (
      !['right', 'up', 'forward'].every((key) => vector(result[key], 3)) ||
      !vector(result.origin, 2) ||
      !Number.isFinite(result.focal) ||
      result.focal <= 0 ||
      Math.hypot(...result.up) < 0.5
    )
      return null;
    return { ...result, position: [...pose.position], width, height };
  }

  function unproject(camera, point, depth) {
    const x = ((point[0] - camera.origin[0]) * depth) / camera.focal;
    const y = ((camera.origin[1] - point[1]) * depth) / camera.focal;
    return camera.position.map(
      (value, index) =>
        value + camera.right[index] * x + camera.up[index] * y + camera.forward[index] * depth
    );
  }

  function rotate(point, angles) {
    const [pitch, yaw, roll] = angles;
    const y = point[1] * Math.cos(pitch) - point[2] * Math.sin(pitch);
    const z = point[1] * Math.sin(pitch) + point[2] * Math.cos(pitch);
    const x = point[0] * Math.cos(yaw) + z * Math.sin(yaw);
    const Z = -point[0] * Math.sin(yaw) + z * Math.cos(yaw);
    return [x * Math.cos(roll) - y * Math.sin(roll), x * Math.sin(roll) + y * Math.cos(roll), Z];
  }

  function basis(camera) {
    // Local z faces the viewer, giving a proper right-handed object basis.
    return [camera.right, camera.up, scale(camera.forward, -1)];
  }

  function quaternion(columns) {
    const [x, y, z] = columns;
    const trace = x[0] + y[1] + z[2];
    let q;
    if (trace > 0) {
      const s = Math.sqrt(trace + 1) * 2;
      q = [(y[2] - z[1]) / s, (z[0] - x[2]) / s, (x[1] - y[0]) / s, s / 4];
    } else if (x[0] > y[1] && x[0] > z[2]) {
      const s = Math.sqrt(1 + x[0] - y[1] - z[2]) * 2;
      q = [s / 4, (y[0] + x[1]) / s, (z[0] + x[2]) / s, (y[2] - z[1]) / s];
    } else if (y[1] > z[2]) {
      const s = Math.sqrt(1 + y[1] - x[0] - z[2]) * 2;
      q = [(y[0] + x[1]) / s, s / 4, (z[1] + y[2]) / s, (z[0] - x[2]) / s];
    } else {
      const s = Math.sqrt(1 + z[2] - x[0] - y[1]) * 2;
      q = [(z[0] + x[2]) / s, (z[1] + y[2]) / s, s / 4, (x[1] - y[0]) / s];
    }
    return normalize(q);
  }

  function turn(point, q) {
    const x = (q[1] * point[2] - q[2] * point[1]) * 2;
    const y = (q[2] * point[0] - q[0] * point[2]) * 2;
    const z = (q[0] * point[1] - q[1] * point[0]) * 2;
    return [
      point[0] + (x * q[3] + (q[1] * z - q[2] * y)),
      point[1] + (y * q[3] + (q[2] * x - q[0] * z)),
      point[2] + (z * q[3] + (q[0] * y - q[1] * x)),
    ];
  }

  function orientation(from, to, progress) {
    if (progress === 1) return to;
    const target = dot(from, to) < 0 ? scale(to, -1) : to;
    return normalize(blend(from, target, progress));
  }
  function compose(a, b) {
    return [
      a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
      a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
      a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
      a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
    ];
  }

  function validCell(cell, rect) {
    if (
      !cell ||
      !Array.isArray(cell.polygon) ||
      cell.polygon.length < 3 ||
      cell.polygon.length > settings.maxVertices ||
      cell.polygon.some(
        (point) =>
          !vector(point, 2) ||
          point[0] < rect.x - 1e-7 ||
          point[0] > rect.x + rect.width + 1e-7 ||
          point[1] < rect.y - 1e-7 ||
          point[1] > rect.y + rect.height + 1e-7
      )
    )
      return false;
    let area = 0;
    for (let index = 0; index < cell.polygon.length; index++) {
      const a = cell.polygon[index];
      const b = cell.polygon[(index + 1) % cell.polygon.length];
      const c = cell.polygon[(index + 2) % cell.polygon.length];
      if (Math.hypot(...sub(b, a)) < 1e-8) return false;
      const turn = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
      if (turn < -1e-7) return false;
      area += a[0] * b[1] - b[0] * a[1];
    }
    return area > 1e-6;
  }
  function validSurface(member) {
    if (member.radius === undefined && member.surfaceAxes === undefined) return true;
    const axes = member.surfaceAxes;
    return (
      Number.isFinite(member.radius) &&
      member.radius > 0 &&
      Array.isArray(axes) &&
      axes.length === 3 &&
      axes.every((axis) => vector(axis, 3) && Math.abs(Math.hypot(...axis) - 1) < 1e-6) &&
      Math.abs(dot(axes[0], axes[1])) < 1e-6 &&
      dot(cross(axes[0], axes[1]), axes[2]) > 1 - 1e-6
    );
  }
  const validMembers = (members, count) =>
    typeof loopTransform === 'function' &&
    Array.isArray(members) &&
    members.length === count &&
    members.every(
      (member) =>
        member &&
        vector(member.center, 3) &&
        vector(member.rootCenter, 3) &&
        vector(member.attachment, 3) &&
        Number.isFinite(member.phase) &&
        Number.isFinite(member.root) &&
        validSurface(member)
    );
  const copyMember = (member) =>
    member
      ? Object.freeze({
          name: member.name,
          parent: member.parent,
          center: Object.freeze([...member.center]),
          rootCenter: Object.freeze([...member.rootCenter]),
          attachment: Object.freeze([...member.attachment]),
          root: member.root,
          phase: member.phase,
          ...(member.surfaceAxes
            ? {
                radius: member.radius,
                surfaceAxes: Object.freeze(
                  member.surfaceAxes.map((axis) => Object.freeze([...axis]))
                ),
              }
            : {}),
        })
      : null;

  function layoutFor(shard) {
    const count = shard.uv.length;
    const faces = [
      { face: 'front', indices: Array.from({ length: count }, (_, index) => count - index - 1) },
      { face: 'back', indices: Array.from({ length: count }, (_, index) => count + index) },
      ...shard.uv.map((_, index) => {
        const next = (index + 1) % count;
        return { face: 'side', indices: [index, next, count + next, count + index] };
      }),
    ];
    return {
      uv: shard.uv,
      centroid: shard.centroid,
      offsets: shard.uv.map(([u, v]) => [u - shard.centroid[0], shard.centroid[1] - v]),
      faces: Object.freeze(
        faces.map((face) => Object.freeze({ ...face, indices: Object.freeze(face.indices) }))
      ),
    };
  }

  function sampleState(camera, rect, depth) {
    return {
      orientation: quaternion(basis(camera)),
      size: [(rect.width * depth) / camera.focal, (rect.height * depth) / camera.focal],
      transforms: new Map(),
    };
  }

  function memberTransform(member, time, state, key = member) {
    if (!member) return null;
    if (!state) return { transform: loopTransform(member, time) };
    let result = state.transforms.get(key);
    if (!result) {
      result = { transform: loopTransform(member, time) };
      state.transforms.set(key, result);
    }
    return result;
  }

  function restShape(uv, centroid, rect, depth, camera, member, thickness) {
    const size = [rect.width, rect.height].map(
      (value) => (value * depth * settings.embeddedScale) / camera.focal
    );
    if (!member?.surfaceAxes) return { size, thickness: thickness * settings.restExtrusion };
    const radius = Math.min(settings.chipRadiusMax, member.radius * settings.chipBranchRadius);
    const restThickness = Math.min(
      thickness * settings.restExtrusion,
      radius * settings.chipThickness
    );
    const faceRadius = Math.sqrt(radius * radius - restThickness * restThickness);
    const extent = Math.max(
      ...uv.map(([u, v]) => Math.hypot((u - centroid[0]) * size[0], (centroid[1] - v) * size[1]))
    );
    return { size: scale(size, faceRadius / extent), thickness: restThickness, radius };
  }
  function branchMotion(shard, time, state, layout) {
    const key = layout.member === shard.member ? layout.memberKey : shard.member;
    const transformed = memberTransform(shard.member, time, state, key);
    const transform = transformed?.transform;
    if (transform && !transformed.orientation)
      transformed.orientation = quaternion(
        [
          [transform.matrix[0], transform.matrix[3], transform.matrix[6]],
          [transform.matrix[1], transform.matrix[4], transform.matrix[7]],
          [transform.matrix[2], transform.matrix[5], transform.matrix[8]],
        ].map((column) => scale(column, 1 / transform.scale))
      );
    return transformed;
  }

  function prepare({
    id,
    rect,
    cells,
    pose,
    width,
    height,
    embeddedAnchor,
    anchor,
    depth = 12,
    members = null,
    hostOffset = 0,
    returnMembers = null,
    returnOffset = 0,
  }) {
    const restAnchor = embeddedAnchor || anchor;
    if (
      typeof id !== 'string' ||
      !id ||
      !validRect(rect) ||
      !Array.isArray(cells) ||
      !cells.length ||
      cells.length > settings.maxPieces ||
      (!members && !vector(restAnchor, 3)) ||
      (members && !validMembers(members, cells.length)) ||
      (returnMembers && !validMembers(returnMembers, cells.length)) ||
      !Number.isFinite(hostOffset) ||
      !Number.isFinite(returnOffset) ||
      !Number.isFinite(depth) ||
      depth <= settings.near
    )
      return null;
    const camera = view(pose, width, height);
    if (!camera || cells.some((cell) => !validCell(cell, rect))) return null;
    const axes = basis(camera);
    const branches = new Map();
    const branchKey = (member) => {
      if (!member) return null;
      // Attachments differ between shards. The shared loop depends only on
      // this exact immutable branch descriptor, and lives for one sample.
      const key = [member.center, member.rootCenter, member.root, member.phase].join(':');
      if (!branches.has(key)) branches.set(key, member);
      return branches.get(key);
    };
    const shards = cells.map((cell, index) => {
      const uv = cell.polygon.map(([x, y]) => [
        (x - rect.x) / rect.width,
        (y - rect.y) / rect.height,
      ]);
      const rearAxis = Math.min(...uv.map(([u]) => u)) + Math.max(...uv.map(([u]) => u));
      const centroid = center(uv);
      const seed = (cell.seed ?? index + 1) >>> 0;
      const fraction = (shift) => ((Math.imul(seed ^ shift, 2654435761) >>> 0) % 65536) / 65536;
      const angles = [
        (fraction(13) - 0.5) * 1.1,
        (fraction(31) - 0.5) * 1.45,
        (fraction(47) - 0.5) * 1.3,
      ];
      const restAxes = [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1],
      ].map((axis) => {
        const turned = rotate(axis, angles);
        return axes[0].map((_, coordinate) =>
          turned.reduce((sum, value, axisIndex) => sum + value * axes[axisIndex][coordinate], 0)
        );
      });
      const spread = [
        (centroid[0] - 0.5) * 10 + (fraction(59) - 0.5) * 2,
        (0.5 - centroid[1]) * 7 + (fraction(71) - 0.5) * 2,
        (fraction(83) - 0.5) * 7,
      ];
      const member = members?.[index];
      const restOrientation = quaternion(member?.surfaceAxes || restAxes);
      const restCenter = (members ? members[index].attachment : restAnchor).map(
        (value, coordinate) =>
          value +
          (members
            ? 0
            : spread.reduce(
                (sum, amount, axisIndex) => sum + amount * axes[axisIndex][coordinate],
                0
              ))
      );
      const span = Math.min(cell.width, cell.height);
      const thicknessPx = Math.min(
        settings.thicknessMaxPx,
        Math.max(settings.thicknessMinPx, span * (0.18 + fraction(97) * 0.2))
      );
      const thickness = (thicknessPx * depth) / camera.focal;
      const rest = restShape(uv, centroid, rect, depth, camera, member, thickness);
      const contact = members ? turn([0, 0, rest.thickness], restOrientation) : [0, 0, 0];
      const shard = {
        id: `${id}:${index}`,
        uv,
        rearUv: uv.map(([u, v]) => [rearAxis - u, v]),
        centroid,
        restCenter: add(restCenter, contact),
        restOrientation,
        restSize: rest.size,
        restThickness: rest.thickness,
        chipRadius: rest.radius || null,
        thickness,
        departureOffset: [
          (centroid[0] - 0.5) * 9 + (fraction(113) - 0.5) * 2,
          (0.5 - centroid[1]) * 7 + (fraction(127) - 0.5) * 2,
          5 + fraction(139) * 21,
        ],
        forwardDepth: 24 + fraction(151) * 32,
        member: copyMember(members?.[index]),
        hostOffset,
        returnMember: copyMember(returnMembers?.[index]),
        returnOffset,
        color: index % 3 === 0 ? 'amber' : 'cyan',
      };
      shard.uv.forEach(Object.freeze);
      Object.freeze(shard.uv);
      Object.freeze(shard.centroid);
      layouts.set(shard, {
        ...layoutFor(shard),
        member: shard.member,
        memberKey: branchKey(shard.member),
        returnMember: shard.returnMember,
        returnKey: branchKey(shard.returnMember),
      });
      return shard;
    });
    return {
      id,
      rect: { ...rect },
      pose: { position: [...pose.position], target: [...pose.target] },
      width,
      height,
      depth,
      shards,
    };
  }

  function returnCenter(shard, time, state = null, layout = null) {
    const key = layout?.returnMember === shard.returnMember ? layout.returnKey : shard.returnMember;
    const { transform } = memberTransform(shard.returnMember, time, state, key);
    return add(transform(shard.returnMember.attachment), [0, 0, shard.returnOffset]);
  }
  function arrivalCenter(
    shard,
    camera,
    worldCenter,
    targetCenter,
    { forwardPath, waypoint, progress, amount, lateralAmount }
  ) {
    if (forwardPath) {
      // Separate axial travel from lateral assembly. This fixed world
      // corridor has real seeded depth; it never follows the live
      // camera's near plane. Lateral alignment finishes while distant.
      const delta = sub(targetCenter, worldCenter);
      const longitudinal = dot(delta, camera.forward);
      const transverse = sub(delta, scale(camera.forward, longitudinal));
      const depthSpread = shard.forwardDepth * 4 * amount * (1 - amount);
      return add(
        add(worldCenter, scale(transverse, lateralAmount)),
        scale(camera.forward, longitudinal * amount + depthSpread)
      );
    }
    if (!waypoint) return blend(worldCenter, targetCenter, amount);
    if (progress <= settings.returnStop)
      return blend(worldCenter, waypoint, smooth(progress / settings.returnStop));
    return blend(
      waypoint,
      targetCenter,
      smooth((progress - settings.returnStop) / (1 - settings.returnStop))
    );
  }
  function geometry(
    shard,
    {
      view: camera,
      rect,
      depth,
      progress = 0,
      time = 0,
      returnPath = false,
      forwardPath = false,
      departing = false,
    },
    state = null
  ) {
    if (
      !shard ||
      !camera ||
      !validRect(rect) ||
      !Number.isFinite(progress) ||
      progress < 0 ||
      progress > 1 ||
      !Number.isFinite(depth) ||
      depth <= settings.near
    )
      return null;
    const storedLayout = layouts.get(shard);
    const layout =
      storedLayout?.uv === shard.uv && storedLayout.centroid === shard.centroid
        ? storedLayout
        : layoutFor(shard);
    const frame = state || sampleState(camera, rect, depth);
    const amount = smooth(progress);
    const targetCenter = unproject(
      camera,
      [rect.x + rect.width * shard.centroid[0], rect.y + rect.height * shard.centroid[1]],
      depth
    );
    let origin;
    let rotation;
    let size;
    let extrusion;
    if (departing) {
      // Break at the source plane, then leave the solids in world space. The
      // advancing camera crosses them; they never chase its near plane or
      // collapse toward a previous room behind the source camera.
      const breakup = smooth(Math.min(1, (1 - progress) / settings.departureBreakup));
      const axes = [camera.right, camera.up, camera.forward];
      const transformed = branchMotion(shard, time, frame, layout);
      const transform = transformed?.transform;
      const loopOffset = transform
        ? sub(transform(shard.member.attachment), shard.member.attachment)
        : [0, 0, 0];
      origin = add(
        targetCenter,
        axes[0].map(
          (_, coordinate) =>
            shard.departureOffset.reduce(
              (sum, distance, axis) => sum + distance * axes[axis][coordinate] * breakup,
              0
            ) +
            loopOffset[coordinate] * breakup
        )
      );
      rotation = orientation(
        frame.orientation,
        compose(transformed?.orientation || [0, 0, 0, 1], shard.restOrientation),
        breakup
      );
      size = blend(
        frame.size,
        shard.restSize.map((value) => value * (transform?.scale || 1)),
        breakup
      );
      extrusion =
        1 + ((shard.restThickness / shard.thickness) * (transform?.scale || 1) - 1) * breakup;
    } else if (progress === 1) {
      // The native endpoint is independent of branch motion or return paths.
      origin = targetCenter;
      rotation = frame.orientation;
      size = frame.size;
      extrusion = 1;
    } else {
      const transformed = branchMotion(shard, time, frame, layout);
      const transform = transformed?.transform;
      const restCenter = transform ? transform(shard.restCenter) : shard.restCenter;
      const worldCenter = add(restCenter, [0, 0, shard.hostOffset || 0]);
      const motion = transformed?.orientation || [0, 0, 0, 1];
      const waypoint =
        returnPath && shard.returnMember ? returnCenter(shard, time, frame, layout) : null;
      const lateralAmount = forwardPath
        ? smooth(Math.min(1, progress / settings.forwardLateralStop))
        : amount;
      const rotationAmount = forwardPath
        ? smooth(Math.min(1, progress / settings.forwardOrientationStop))
        : amount;
      const growthAmount = forwardPath
        ? smooth(
            Math.max(
              0,
              (progress - settings.forwardGrowthStart) / (1 - settings.forwardGrowthStart)
            )
          )
        : amount;
      origin = arrivalCenter(shard, camera, worldCenter, targetCenter, {
        forwardPath,
        waypoint,
        progress,
        amount,
        lateralAmount,
      });
      rotation = orientation(
        compose(motion, shard.restOrientation),
        frame.orientation,
        rotationAmount
      );
      size = blend(
        shard.restSize.map((value) => value * (transform?.scale || 1)),
        frame.size,
        growthAmount
      );
      extrusion =
        ((shard.restThickness / shard.thickness) * (1 - growthAmount) + growthAmount) *
        ((transform?.scale || 1) * (1 - growthAmount) + growthAmount);
    }
    const front = layout.offsets.map(([x, y]) =>
      add(origin, turn([x * size[0], y * size[1], 0], rotation))
    );
    const back = layout.offsets.map(([x, y]) =>
      add(
        origin,
        turn([x * size[0] * 0.9, y * size[1] * 0.9, -shard.thickness * extrusion], rotation)
      )
    );
    return { id: shard.id, vertices: [...front, ...back], faces: layout.faces };
  }

  function phaseForClearance(
    shard,
    {
      view: target,
      camera,
      rect,
      depth,
      progress,
      time = 0,
      returnPath = false,
      forwardPath = false,
    },
    state = null
  ) {
    if (!Number.isFinite(progress) || progress < 0 || progress > 1) return NaN;
    if (forwardPath) return progress;
    if (progress === 0) return 0;
    const layout = layouts.get(shard);
    const key = layout?.member === shard.member ? layout.memberKey : shard.member;
    const transform = memberTransform(shard.member, time, state, key)?.transform;
    const moving = transform ? transform(shard.restCenter) : shard.restCenter;
    const rest = add(moving, [0, 0, shard.hostOffset || 0]);
    const endpoint = unproject(
      target,
      [rect.x + rect.width * shard.centroid[0], rect.y + rect.height * shard.centroid[1]],
      depth
    );
    const waypoint =
      returnPath && shard.returnMember ? returnCenter(shard, time, state, layout) : null;
    const first = waypoint && progress <= settings.returnStop;
    const start = waypoint && !first ? settings.returnStop : 0;
    const span = waypoint ? (first ? settings.returnStop : 1 - settings.returnStop) : 1;
    const local = (progress - start) / span;
    const a = camera.camera(waypoint && !first ? waypoint : rest)[2];
    const b = camera.camera(first ? waypoint : endpoint)[2];
    const difference = b - a;
    if (Math.abs(difference) < 1e-9) return progress;
    const boundary = Math.max(0, Math.min(1, (depth - a) / difference));
    const amount =
      difference > 0 ? Math.max(smooth(local), boundary) : Math.min(smooth(local), boundary);
    if (amount === 0 || amount === 1) return start + span * amount;
    // Only phase changes along the existing world path. Reverse destinations
    // pass their own deep branch before collecting toward the native plane.
    let left = 0,
      right = 1;
    for (let index = 0; index < 20; index++) {
      const middle = (left + right) / 2;
      if (smooth(middle) < amount) left = middle;
      else right = middle;
    }
    return start + (span * (left + right)) / 2;
  }

  function projectSolid(solid, camera) {
    const world = solid.vertices;
    const vertices = world.map(camera.camera);
    // Cull a complete solid before any vertex enters the near plane. Texture
    // clips cannot stretch through a near intersection or submit huge bitmaps.
    if (vertices.some((point) => !vector(point, 3) || point[2] <= settings.near)) return null;
    const points = vertices.map(camera.project);
    // With every vertex in front of the near plane, a face cannot extend past
    // the complete solid's projected bounds. This uses the same viewport test
    // as each face, so it only skips solids whose every face is invisible.
    if (points.every((point) => vector(point, 2)) && !camera.visible(points)) return null;
    return { world, vertices, points, nearest: Math.min(...vertices.map((point) => point[2])) };
  }

  function projectFace(face, projected, camera, limit) {
    const world = face.indices.map((index) => projected.world[index]);
    const normal = faceNormal(world);
    if (!normal || dot(normal, sub(camera.position, world[0])) <= 1e-9) return null;
    const vertices = face.indices.map((index) => projected.vertices[index]);
    const points = face.indices.map((index) => projected.points[index]);
    if (
      points.some((point) => !vector(point, 2) || point.some((value) => Math.abs(value) > limit)) ||
      !camera.visible(points)
    )
      return null;
    return {
      points,
      cameraPoints: vertices,
      normal,
      depth: center(vertices)[2],
      nearest: projected.nearest,
    };
  }
  function faceVisibility(face, depth, nearest, progress) {
    const nearFade = Math.min(1, (nearest - settings.near) / 2);
    if (face !== 'side') return nearFade;
    const haze = depthVisibility(depth);
    return (haze + (1 - haze) * smooth(progress)) * nearFade;
  }
  function faceShape(shard, face, surface, amount) {
    const { points, normal, depth, nearest } = surface;
    const textured = face.face !== 'side';
    const coordinates = face.face === 'back' ? shard.rearUv : shard.uv;
    return {
      kind: 'embedded-face',
      id: shard.id,
      face: face.face,
      points,
      depth,
      normal,
      tint: Math.min(0.63, 0.42 * (0.65 + 0.5 * Math.abs(dot(normal, light)))),
      color: shard.color,
      alpha: faceVisibility(face.face, depth, nearest, amount),
      textureMix: Number(textured),
      progress: amount,
      uv: textured ? face.indices.map((index) => coordinates[index % shard.uv.length]) : null,
      cameraPoints: textured ? surface.cameraPoints : null,
    };
  }

  function sample(
    prepared,
    {
      pose,
      width,
      height,
      progress = 0,
      progresses = null,
      time = 0,
      rect = prepared?.rect,
      targetPose = prepared?.pose,
      clearance = false,
      returnPath = false,
      forwardPath = false,
      departing = false,
    }
  ) {
    if (!prepared || !validRect(rect)) return [];
    if (
      progresses &&
      (!Array.isArray(progresses) ||
        progresses.length !== prepared.shards.length ||
        progresses.some((amount) => !Number.isFinite(amount) || amount < 0 || amount > 1))
    )
      return [];
    const camera = view(pose, width, height);
    const targetView = view(targetPose, width, height);
    if (!camera || !targetView) return [];
    const state = sampleState(targetView, rect, prepared.depth);
    const shapes = [];
    const limit = Math.max(width, height) * 8;
    for (const [index, shard] of prepared.shards.entries()) {
      const requested = progresses ? progresses[index] : progress;
      const amount =
        clearance && !departing
          ? phaseForClearance(
              shard,
              {
                view: targetView,
                camera,
                rect,
                depth: prepared.depth,
                progress: requested,
                returnPath,
                forwardPath,
                time,
              },
              state
            )
          : requested;
      const solid = geometry(
        shard,
        {
          view: targetView,
          rect,
          depth: prepared.depth,
          progress: amount,
          time,
          returnPath,
          forwardPath,
          departing,
        },
        state
      );
      if (!solid) return [];
      const projected = projectSolid(solid, camera);
      if (!projected) continue;
      for (const face of solid.faces) {
        const surface = projectFace(face, projected, camera, limit);
        if (!surface) continue;
        shapes.push(faceShape(shard, face, surface, amount));
      }
    }
    return shapes;
  }

  function path(ctx, points) {
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (let index = 1; index < points.length; index++)
      ctx.lineTo(points[index][0], points[index][1]);
    ctx.closePath();
  }

  function paintTriangle(ctx, surface, source, points, seam = false) {
    const [p, q, r] = source;
    const [P, Q, R] = points;
    const dx = q[0] - p[0];
    const dy = q[1] - p[1];
    const ex = r[0] - p[0];
    const ey = r[1] - p[1];
    const denominator = dx * ey - dy * ex;
    if (Math.abs(denominator) < 1e-9) return;
    const a = ((Q[0] - P[0]) * ey - (R[0] - P[0]) * dy) / denominator;
    const c = ((R[0] - P[0]) * dx - (Q[0] - P[0]) * ex) / denominator;
    const b = ((Q[1] - P[1]) * ey - (R[1] - P[1]) * dy) / denominator;
    const d = ((R[1] - P[1]) * dx - (Q[1] - P[1]) * ex) / denominator;
    ctx.save();
    try {
      // The outer face clip remains exact. A small internal overlap avoids
      // antialiased hairlines between adjacent samples of this one solid.
      const middle = seam ? center(points) : null;
      const clip = seam
        ? points.map((point) => {
            const distance = Math.hypot(...sub(point, middle));
            return distance > 1e-9 ? blend(middle, point, 1 + 0.35 / distance) : point;
          })
        : points;
      path(ctx, clip);
      ctx.clip();
      ctx.transform(a, b, c, d, P[0] - a * p[0] - c * p[1], P[1] - b * p[0] - d * p[1]);
      // Submit only the shard's source bounding rectangle, with a one-pixel
      // filter neighbourhood; all shards reuse the one bounded owner bitmap.
      const left = Math.max(0, Math.floor(Math.min(p[0], q[0], r[0])) - 1);
      const top = Math.max(0, Math.floor(Math.min(p[1], q[1], r[1])) - 1);
      const right = Math.min(surface.width, Math.ceil(Math.max(p[0], q[0], r[0])) + 1);
      const bottom = Math.min(surface.height, Math.ceil(Math.max(p[1], q[1], r[1])) + 1);
      if (right > left && bottom > top)
        ctx.drawImage(
          surface,
          left,
          top,
          right - left,
          bottom - top,
          left,
          top,
          right - left,
          bottom - top
        );
    } finally {
      ctx.restore();
    }
  }

  function textureTriangle(vertices) {
    let edge = -1;
    let error = settings.textureErrorPx;
    let point = null;
    for (let index = 0; index < 3; index++) {
      const a = vertices[index];
      const b = vertices[(index + 1) % 3];
      const depthSum = a.depth + b.depth;
      const x = (a.point[0] * a.depth + b.point[0] * b.depth) / depthSum;
      const y = (a.point[1] * a.depth + b.point[1] * b.depth) / depthSum;
      const difference = Math.hypot(
        x - (a.point[0] + (b.point[0] - a.point[0]) * 0.5),
        y - (a.point[1] + (b.point[1] - a.point[1]) * 0.5)
      );
      if (difference > error) {
        edge = index;
        error = difference;
        point = [x, y];
      }
    }
    if (edge === -1) return { vertices, error, edge, middle: null };
    const a = vertices[edge];
    const b = vertices[(edge + 1) % 3];
    return {
      vertices,
      error,
      edge,
      middle: {
        source: blend(a.source, b.source, 0.5),
        point,
        depth: (a.depth + b.depth) / 2,
      },
    };
  }

  function textureTriangles(shape, surface) {
    const source = shape.uv.map(([u, v]) => [u * surface.width, v * surface.height]);
    const vertices = source.map((point, index) => ({
      source: point,
      point: shape.points[index],
      depth: shape.cameraPoints?.[index]?.[2],
    }));
    const triangles = [];
    for (let index = 1; index < vertices.length - 1; index++)
      triangles.push([vertices[0], vertices[index], vertices[index + 1]]);
    if (!vertices.every((vertex) => Number.isFinite(vertex.depth) && vertex.depth > settings.near))
      return triangles;
    const depths = vertices.map((vertex) => vertex.depth);
    if (Math.max(...depths) - Math.min(...depths) < 1e-8) return triangles;
    if (triangles.length >= settings.textureTriangles) return triangles;
    // A triangle's projected edge errors do not change during this paint.
    // Cache them until that triangle is split instead of rescanning every
    // surviving edge at each refinement. Midpoints remain projective.
    const candidates = triangles.map(textureTriangle);
    while (candidates.length < settings.textureTriangles) {
      let selected = null;
      let triangleIndex = -1;
      for (let index = 0; index < candidates.length; index++) {
        const candidate = candidates[index];
        if (candidate.error > (selected?.error || settings.textureErrorPx)) {
          selected = candidate;
          triangleIndex = index;
        }
      }
      if (!selected) break;
      const triangle = selected.vertices;
      const a = triangle[selected.edge];
      const b = triangle[(selected.edge + 1) % 3];
      const c = triangle[(selected.edge + 2) % 3];
      candidates.splice(
        triangleIndex,
        1,
        textureTriangle([a, selected.middle, c]),
        textureTriangle([selected.middle, b, c])
      );
    }
    return candidates.map((candidate) => candidate.vertices);
  }

  function paint(ctx, shape, surface, colors) {
    if (shape.kind !== 'embedded-face') return false;
    if (shape.alpha === 0) return true;
    const key = `${colors.paper}:${colors.cyan}:${colors.amber}`;
    if (key !== paletteKey) {
      paletteKey = key;
      palette = Object.fromEntries(
        ['paper', 'cyan', 'amber'].map((color) => [
          color,
          colors[color]
            .slice(1)
            .match(/.{2}/g)
            .map((value) => parseInt(value, 16)),
        ])
      );
    }
    const paper = palette.paper;
    const ink = palette[shape.color];
    const fill = paper.map((value, index) => Math.round(value + (ink[index] - value) * shape.tint));
    const textureMix = surface ? shape.textureMix : 0;
    ctx.save();
    try {
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = `rgb(${fill.join(',')})`;
      // Fragments are material solids. Transparent pixels in the native atlas
      // reveal a palette substrate while broken, rather than glass-like holes.
      // The substrate is gone at the exact native endpoint.
      ctx.globalAlpha =
        shape.alpha * (shape.face !== 'side' ? 1 - smooth(shape.progress) * textureMix : 1);
      path(ctx, shape.points);
      ctx.fill();
      if (shape.face !== 'side' && surface && shape.uv) {
        ctx.globalAlpha = shape.alpha * shape.textureMix;
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        const overlap = shape.alpha === 1 && shape.progress < 0.98;
        if (overlap) ctx.clip();
        // Refine only where actual perspective bends the native texture, with
        // the same eight-submission bound as the largest canonical face fan.
        for (const triangle of textureTriangles(shape, surface))
          paintTriangle(
            ctx,
            surface,
            triangle.map((vertex) => vertex.source),
            triangle.map((vertex) => vertex.point),
            overlap
          );
      }
    } finally {
      ctx.restore();
    }
    return true;
  }

  return { settings, view, prepare, geometry, phaseForClearance, sample, paint };
};
const embeddedTexture=function () {
  const settings = Object.freeze({
    selector: '.archive-intro > .hero-description',
    maxCharacters: 1024,
    maxLines: 16,
    maxPixels: 1000000,
    maxDpr: 2,
    decodeTimeoutMs: 1500,
  });
  const textProperties = Object.freeze([
    'font-family',
    'font-size',
    'font-weight',
    'font-style',
    'font-stretch',
    'font-variant',
    'line-height',
    'letter-spacing',
    'word-spacing',
    'text-align',
    'white-space',
    'word-break',
    'overflow-wrap',
    'hyphens',
    'direction',
    'writing-mode',
    'color',
    'padding-top',
    'padding-right',
    'padding-bottom',
    'padding-left',
  ]);
  const systemFamilies = new Set([
    'system-ui',
    '-apple-system',
    'blinkmacsystemfont',
    'segoe ui',
    'sans-serif',
  ]);
  const escapeXML = (value) =>
    String(value).replace(/[&<>"']/g, (character) => {
      const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' };
      return entities[character];
    });
  const value = (style, property) => style.getPropertyValue(property).trim();
  const number = (style, property) => {
    const source = value(style, property);
    return /^-?(?:\d+(?:\.\d*)?|\.\d+)px$/.test(source) ? parseFloat(source) : NaN;
  };
  const inactive = (style) => ['none', 'normal', ''].includes(value(style, 'content'));
  const finiteRect = (rect) =>
    rect &&
    ['left', 'top', 'right', 'bottom', 'width', 'height'].every((key) =>
      Number.isFinite(rect[key])
    ) &&
    rect.width > 0 &&
    rect.height > 0;
  function copyRect(rect, offsetX, offsetY) {
    return {
      left: rect.left - offsetX,
      top: rect.top - offsetY,
      right: rect.right - offsetX,
      bottom: rect.bottom - offsetY,
      width: rect.width,
      height: rect.height,
    };
  }
  function supportedPaint(style) {
    if (
      !['none', ''].includes(value(style, 'transform')) ||
      !['none', ''].includes(value(style, 'filter')) ||
      !['none', ''].includes(value(style, 'backdrop-filter')) ||
      !['none', ''].includes(value(style, 'background-image')) ||
      !['none', ''].includes(value(style, 'box-shadow')) ||
      !['normal', ''].includes(value(style, 'mix-blend-mode'))
    )
      return false;
    return ['top', 'right', 'bottom', 'left'].every(
      (side) => !parseFloat(value(style, 'border-' + side + '-width'))
    );
  }
  function supportedText(style) {
    if (!supportedPaint(style) || value(style, 'opacity') !== '1') return false;
    if (value(style, 'display') !== 'block' || value(style, 'writing-mode') !== 'horizontal-tb')
      return false;
    if (
      value(style, 'direction') !== 'ltr' ||
      value(style, 'white-space') !== 'normal' ||
      value(style, 'text-transform') !== 'none' ||
      value(style, 'text-shadow') !== 'none' ||
      !['none', ''].includes(value(style, 'text-decoration-line')) ||
      !['normal', ''].includes(value(style, 'font-feature-settings')) ||
      !['normal', ''].includes(value(style, 'font-variation-settings'))
    )
      return false;
    return value(style, 'font-family')
      .split(',')
      .every((family) =>
        systemFamilies.has(
          family
            .trim()
            .replace(/^['"]|['"]$/g, '')
            .toLowerCase()
        )
      );
  }
  function backgroundRect(rect, style) {
    if (
      !['""', "''"].includes(value(style, 'content')) ||
      value(style, 'position') !== 'absolute' ||
      value(style, 'display') === 'none' ||
      !supportedPaint(style)
    )
      return null;
    const left = number(style, 'left');
    const top = number(style, 'top');
    let width = number(style, 'width');
    let height = number(style, 'height');
    if (value(style, 'box-sizing') !== 'border-box') {
      for (const side of ['left', 'right']) width += number(style, 'padding-' + side);
      for (const side of ['top', 'bottom']) height += number(style, 'padding-' + side);
    }
    const opacity = Number(value(style, 'opacity'));
    if (![left, top, width, height, opacity].every(Number.isFinite) || opacity <= 0 || opacity > 1)
      return null;
    const box = {
      left: rect.left + left,
      top: rect.top + top,
      right: rect.left + left + width,
      bottom: rect.top + top + height,
      width,
      height,
    };
    return finiteRect(box) ? box : null;
  }
  function fontsReady(document, style, text, cache) {
    if (!document.fonts || document.fonts.status !== 'loaded') return false;
    const families = value(style, 'font-family');
    // SVG image documents cannot borrow a page's web-font resources.
    let eligible = cache?.facesEligible;
    if (eligible === undefined) {
      eligible = true;
      if (typeof document.fonts[Symbol.iterator] === 'function') {
        for (const face of document.fonts) {
          const name = String(face.family)
            .replace(/^['"]|['"]$/g, '')
            .toLowerCase();
          if (systemFamilies.has(name)) {
            eligible = false;
            break;
          }
        }
      }
      if (cache) cache.facesEligible = eligible;
    }
    if (!eligible) return false;
    // With no registered faces, this validated system-font list cannot trigger
    // a font load. FontFaceSet.check has the same true result without repeating
    // native font matching for every text run in this synchronous acquisition.
    if (cache && document.fonts.size === 0) return true;
    return document.fonts.check(value(style, 'font-size') + ' ' + families, text);
  }
  function measure(root, options) {
    const document = root?.ownerDocument;
    const view = document?.defaultView;
    if (!root?.isConnected || !view || typeof view.Image !== 'function') return null;
    const candidates = root.querySelectorAll(settings.selector);
    if (candidates.length !== 1) return null;
    const owner = candidates[0];
    if (
      owner.localName !== 'p' ||
      !owner.childNodes.length ||
      [...owner.childNodes].some((node) => node.nodeType !== 3)
    )
      return null;
    const text = owner.textContent;
    if (!text.trim() || text.length > settings.maxCharacters) return null;
    const style = view.getComputedStyle(owner);
    const before = view.getComputedStyle(owner, '::before');
    const after = view.getComputedStyle(owner, '::after');
    if (!supportedText(style) || !inactive(after) || !fontsReady(document, style, text))
      return null;
    // Hidden staging may suppress visibility, but cannot alter inherited geometry.
    for (let ancestor = owner.parentElement; ancestor; ancestor = ancestor.parentElement) {
      const ancestorStyle = view.getComputedStyle(ancestor);
      if (
        !['none', ''].includes(value(ancestorStyle, 'transform')) ||
        !['none', ''].includes(value(ancestorStyle, 'perspective')) ||
        !['none', ''].includes(value(ancestorStyle, 'filter'))
      )
        return null;
      if (ancestor === root) break;
    }
    const offsetX = options.offsetX ?? 0;
    const offsetY = options.offsetY ?? 0;
    const dpr = options.dpr ?? view.devicePixelRatio ?? 1;
    if (
      ![options.width, options.height, offsetX, offsetY, dpr].every(Number.isFinite) ||
      options.width <= 0 ||
      options.height <= 0 ||
      dpr <= 0 ||
      dpr > settings.maxDpr
    )
      return null;
    const nativeRect = owner.getBoundingClientRect();
    if (!finiteRect(nativeRect)) return null;
    const rect = copyRect(nativeRect, offsetX, offsetY);
    if (
      rect.right <= 0 ||
      rect.left >= options.width ||
      rect.bottom <= 0 ||
      rect.top >= options.height
    )
      return null;
    const material = backgroundRect(rect, before);
    if (!material) return null;
    const envelope = {
      left: Math.min(rect.left, material.left),
      top: Math.min(rect.top, material.top),
      right: Math.max(rect.right, material.right),
      bottom: Math.max(rect.bottom, material.bottom),
    };
    envelope.width = envelope.right - envelope.left;
    envelope.height = envelope.bottom - envelope.top;
    const pixelWidth = Math.ceil(envelope.width * dpr);
    const pixelHeight = Math.ceil(envelope.height * dpr);
    if (pixelWidth * pixelHeight > settings.maxPixels) return null;
    const range = document.createRange();
    let lines;
    try {
      range.selectNodeContents(owner);
      lines = [...range.getClientRects()].map((line) => copyRect(line, offsetX, offsetY));
    } finally {
      range.detach?.();
    }
    if (!lines.length || lines.length > settings.maxLines || !lines.every(finiteRect)) return null;
    return {
      document,
      view,
      owner,
      style,
      before,
      text,
      rect,
      material,
      envelope,
      lines,
      dpr,
      pixelWidth,
      pixelHeight,
    };
  }
  function serialize(measured, context) {
    const { rect, material, envelope, style, before, text, pixelWidth, pixelHeight } = measured;
    function color(source) {
      context.fillStyle = '#010203';
      context.fillStyle = source;
      const first = context.fillStyle;
      context.fillStyle = '#030201';
      context.fillStyle = source;
      return first === context.fillStyle ? first : null;
    }
    const textColor = color(value(style, 'color'));
    const paper = color(value(before, 'background-color'));
    const ownPaper = color(value(style, 'background-color'));
    if (!textColor || !paper || !ownPaper) return null;
    const paragraph = textProperties.map(
      (property) => property + ':' + (property === 'color' ? textColor : value(style, property))
    );
    paragraph.push(
      'position:absolute',
      'box-sizing:border-box',
      'margin:0',
      'left:' + (rect.left - envelope.left) + 'px',
      'top:' + (rect.top - envelope.top) + 'px',
      'width:' + rect.width + 'px',
      'height:' + rect.height + 'px',
      'background-color:' + ownPaper
    );
    const backdrop = [
      'position:absolute',
      'box-sizing:border-box',
      'left:' + (material.left - envelope.left) + 'px',
      'top:' + (material.top - envelope.top) + 'px',
      'width:' + material.width + 'px',
      'height:' + material.height + 'px',
      'background-color:' + paper,
      'opacity:' + value(before, 'opacity'),
      'border-radius:' + value(before, 'border-radius'),
    ];
    const css = [...paragraph, ...backdrop].join(';');
    if (/url\s*\(|var\s*\(|@import/i.test(css)) return null;
    return (
      '<svg xmlns="http://www.w3.org/2000/svg" width="' +
      pixelWidth +
      '" height="' +
      pixelHeight +
      '" viewBox="0 0 ' +
      envelope.width +
      ' ' +
      envelope.height +
      '">' +
      '<foreignObject width="' +
      envelope.width +
      '" height="' +
      envelope.height +
      '">' +
      '<div xmlns="http://www.w3.org/1999/xhtml" style="position:relative;width:100%;height:100%">' +
      '<div style="' +
      escapeXML(backdrop.join(';')) +
      '"></div>' +
      '<p style="' +
      escapeXML(paragraph.join(';')) +
      '">' +
      escapeXML(text) +
      '</p>' +
      '</div></foreignObject></svg>'
    );
  }
  const nativeProperties = Object.freeze([
    ...textProperties,
    'font-feature-settings',
    'font-variation-settings',
    'box-sizing',
    'display',
    'position',
    'top',
    'right',
    'bottom',
    'left',
    'width',
    'height',
    'min-width',
    'max-width',
    'min-height',
    'max-height',
    'margin-top',
    'margin-right',
    'margin-bottom',
    'margin-left',
    'text-indent',
    'text-transform',
    'text-shadow',
    'text-decoration',
    'vertical-align',
    'list-style-type',
    'list-style-position',
    'flex',
    'order',
    'flex-direction',
    'flex-wrap',
    'align-items',
    'align-self',
    'justify-content',
    'justify-items',
    'justify-self',
    'align-content',
    'grid-template-columns',
    'grid-template-rows',
    'grid-auto-flow',
    'grid-auto-columns',
    'grid-auto-rows',
    'grid-column',
    'grid-row',
    'gap',
    'row-gap',
    'column-gap',
    'object-fit',
    'object-position',
    'appearance',
    '-webkit-appearance',
    'color-scheme',
    'background-color',
    'background-image',
    'background-position',
    'background-size',
    'background-repeat',
    'background-origin',
    'background-clip',
    'box-shadow',
    'border-top',
    'border-right',
    'border-bottom',
    'border-left',
    'border-radius',
    'outline',
    'outline-offset',
    'box-decoration-break',
    '-webkit-box-decoration-break',
    'isolation',
    'z-index',
    'opacity',
    'overflow',
    'overflow-x',
    'overflow-y',
    'transform',
    'transform-origin',
    'transform-box',
  ]);
  const vectorProperties = Object.freeze([
    'fill',
    'fill-opacity',
    'fill-rule',
    'stroke',
    'stroke-opacity',
    'stroke-width',
    'stroke-dasharray',
    'stroke-dashoffset',
    'stroke-linecap',
    'stroke-linejoin',
    'stroke-miterlimit',
    'vector-effect',
    'paint-order',
  ]);
  const nativeTags = new Set([
    'main',
    'footer',
    'nav',
    'header',
    'section',
    'article',
    'aside',
    'div',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6',
    'p',
    'span',
    'a',
    'strong',
    'em',
    'small',
    'time',
    'ul',
    'ol',
    'li',
    'dl',
    'dt',
    'dd',
    'figure',
    'figcaption',
    'blockquote',
    'pre',
    'code',
    'br',
    'img',
    'button',
    'label',
    'form',
    'select',
    'option',
    'optgroup',
    'b',
    'i',
    'sup',
    'sub',
    'hr',
  ]);
  const vectorTags = new Set([
    'svg',
    'g',
    'polygon',
    'polyline',
    'path',
    'rect',
    'circle',
    'ellipse',
    'line',
    'title',
    'desc',
  ]);
  const vectorAttributes = new Set([
    'viewBox',
    'preserveAspectRatio',
    'points',
    'd',
    'x',
    'y',
    'x1',
    'x2',
    'y1',
    'y2',
    'cx',
    'cy',
    'r',
    'rx',
    'ry',
    'width',
    'height',
    'transform',
    'fill',
    'fill-rule',
    'fill-opacity',
    'stroke',
    'stroke-width',
    'stroke-opacity',
    'stroke-linecap',
    'stroke-linejoin',
    'stroke-miterlimit',
    'stroke-dasharray',
    'stroke-dashoffset',
    'vector-effect',
  ]);
  function safeCSS(source) {
    return !/(?:url|var)\s*\(|@|[<>{}]/i.test(source);
  }
  function visiblePaper(style, pseudo = false) {
    if (pseudo && inactive(style)) return false;
    if (value(style, 'display') === 'none' || value(style, 'opacity') === '0') return false;
    const color = value(style, 'background-color');
    return (
      (!!color && !['transparent', 'rgba(0, 0, 0, 0)'].includes(color)) ||
      !['none', ''].includes(value(style, 'background-image')) ||
      !['none', ''].includes(value(style, 'box-shadow')) ||
      (pseudo &&
        ['top', 'right', 'bottom', 'left'].some(
          (side) => parseFloat(value(style, 'border-' + side + '-width')) > 0
        ))
    );
  }
  function nativeAncestorSupported(node, style) {
    const vector = node.namespaceURI === 'http://www.w3.org/2000/svg';
    if (!(vector ? vectorTags : nativeTags).has(node.localName)) return false;
    if (node.localName === 'select' && (node.multiple || node.size > 1)) return false;
    if (
      ['filter', 'backdrop-filter', 'clip-path', 'mask-image', 'perspective'].some(
        (property) => !['none', ''].includes(value(style, property))
      ) ||
      !['normal', ''].includes(value(style, 'mix-blend-mode')) ||
      !['none', ''].includes(value(style, 'animation-name')) ||
      !['none', ''].includes(value(style, 'translate')) ||
      !['none', ''].includes(value(style, 'rotate')) ||
      !['none', ''].includes(value(style, 'scale'))
    )
      return false;
    if (!vector && !['none', ''].includes(value(style, 'transform'))) return false;
    return (
      vector ||
      (['horizontal-tb', ''].includes(value(style, 'writing-mode')) &&
        ['ltr', ''].includes(value(style, 'direction')))
    );
  }
  function nativeSupported(node, style) {
    if (!nativeAncestorSupported(node, style)) return false;
    if (!safeCSS(nativeProperties.map((property) => value(style, property)).join(';')))
      return false;
    if (node.namespaceURI !== 'http://www.w3.org/2000/svg') return true;
    return (
      safeCSS(vectorProperties.map((property) => value(style, property)).join(';')) &&
      [...node.attributes].every(
        ({ name, value: source }) =>
          !/^(?:href|xlink:href|on.+)$/i.test(name) && !/url\s*\(/i.test(source)
      )
    );
  }
  function fullyClipped(style) {
    return /^inset\(50%(?:\s+50%){0,3}\)$/.test(value(style, 'clip-path'));
  }
  function nativeStyle(view, node, pseudo, options) {
    let styles = options.styleCache.get(node);
    if (!styles) {
      styles = new Map();
      options.styleCache.set(node, styles);
    }
    const key = pseudo || '';
    if (!styles.has(key)) {
      const resolved = view.getComputedStyle(node, pseudo);
      const properties = new Map();
      styles.set(key, {
        getPropertyValue(property) {
          if (!properties.has(property))
            properties.set(property, resolved.getPropertyValue(property));
          return properties.get(property);
        },
      });
    }
    return styles.get(key);
  }
  function nativeRect(node, options) {
    if (!options.rectCache.has(node))
      options.rectCache.set(node, copyRect(node.getBoundingClientRect(), 0, 0));
    return options.rectCache.get(node);
  }
  function invisibleNative(node, owner, view, options) {
    for (let current = node; current; current = current.parentElement) {
      const style = nativeStyle(view, current, undefined, options);
      if (
        current.hasAttribute('hidden') ||
        value(style, 'display') === 'none' ||
        value(style, 'opacity') === '0' ||
        fullyClipped(style)
      )
        return true;
      if (current === owner) break;
    }
    return false;
  }
  function extendBounds(bounds, box, style) {
    if (!finiteRect(box)) return;
    bounds.left = Math.min(bounds.left, box.left);
    bounds.top = Math.min(bounds.top, box.top);
    bounds.right = Math.max(bounds.right, box.right);
    bounds.bottom = Math.max(bounds.bottom, box.bottom);
    if (!['none', ''].includes(value(style, 'outline-style'))) {
      const outset =
        (parseFloat(value(style, 'outline-width')) || 0) +
        (parseFloat(value(style, 'outline-offset')) || 0);
      bounds.left = Math.min(bounds.left, box.left - outset);
      bounds.top = Math.min(bounds.top, box.top - outset);
      bounds.right = Math.max(bounds.right, box.right + outset);
      bounds.bottom = Math.max(bounds.bottom, box.bottom + outset);
    }
    for (const part of value(style, 'box-shadow').split(/,(?![^()]*\))/)) {
      if (/\binset\b/.test(part)) continue;
      const lengths = (part.match(/[-+]?(?:\d*\.)?\d+px/g) || []).map(parseFloat);
      if (lengths.length < 2) continue;
      const spread = Math.max(0, (lengths[2] || 0) * 2 + (lengths[3] || 0));
      bounds.left = Math.min(bounds.left, box.left + lengths[0] - spread);
      bounds.top = Math.min(bounds.top, box.top + lengths[1] - spread);
      bounds.right = Math.max(bounds.right, box.right + lengths[0] + spread);
      bounds.bottom = Math.max(bounds.bottom, box.bottom + lengths[1] + spread);
    }
  }
  function pseudoBox(rect, style, pseudo) {
    if (inactive(pseudo) || value(pseudo, 'display') === 'none') return undefined;
    const content = value(pseudo, 'content');
    if (
      !/^(?:"[^"\\]*"|'[^'\\]*')$/.test(content) ||
      !['none', ''].includes(value(pseudo, 'transform')) ||
      !['none', ''].includes(value(pseudo, 'filter')) ||
      !['none', ''].includes(value(pseudo, 'backdrop-filter')) ||
      !safeCSS(nativeProperties.map((property) => value(pseudo, property)).join(';'))
    )
      return null;
    // Bounded inline generated text (the native topic-list slash separators)
    // participates in its parent's normal layout, without an absolute outset.
    if (value(pseudo, 'position') !== 'absolute')
      return ['static', 'relative', ''].includes(value(pseudo, 'position')) ? undefined : null;
    let width = number(pseudo, 'width');
    let height = number(pseudo, 'height');
    if (value(pseudo, 'box-sizing') !== 'border-box') {
      for (const side of ['left', 'right'])
        width +=
          (parseFloat(value(pseudo, 'padding-' + side)) || 0) +
          (parseFloat(value(pseudo, 'border-' + side + '-width')) || 0);
      for (const side of ['top', 'bottom'])
        height +=
          (parseFloat(value(pseudo, 'padding-' + side)) || 0) +
          (parseFloat(value(pseudo, 'border-' + side + '-width')) || 0);
    }
    const left =
      rect.left + (parseFloat(value(style, 'border-left-width')) || 0) + number(pseudo, 'left');
    const top =
      rect.top + (parseFloat(value(style, 'border-top-width')) || 0) + number(pseudo, 'top');
    const result = { left, top, right: left + width, bottom: top + height, width, height };
    if (!Object.values(result).every(Number.isFinite) || width < 0 || height < 0) return null;
    if (width === 0 || height === 0) return emptyPseudoPaint(pseudo) ? undefined : null;
    return result;
  }
  function emptyPseudoPaint(style) {
    return (
      ['""', "''"].includes(value(style, 'content')) &&
      ['none', ''].includes(value(style, 'box-shadow')) &&
      (['none', ''].includes(value(style, 'outline-style')) || number(style, 'outline-width') === 0)
    );
  }
  function nativeFontSupported(document, style, text, options) {
    const families = value(style, 'font-family');
    const cache = options.fontCache;
    if (!cache.families.has(families))
      cache.families.set(
        families,
        families.split(',').every((family) =>
          systemFamilies.has(
            family
              .trim()
              .replace(/^['"]|['"]$/g, '')
              .toLowerCase()
          )
        )
      );
    // Only the synchronous acquisition shares family/face eligibility. The
    // browser still checks every actual text independently, including pseudos.
    return cache.families.get(families) && fontsReady(document, style, text, cache);
  }
  function rejectNative(options, code, tag, extra = {}) {
    try {
      options.onReject?.({ reason: code, path: options.ownerPath || [], tag, ...extra });
    } catch {
      // Optional public diagnostics cannot change capture or cleanup behavior.
    }
    return null;
  }
  function timingStart(options) {
    return options.fieldCapture && typeof options.onTiming === 'function' ? options.clock() : null;
  }
  function reportTiming(options, stage, started, owners) {
    if (started === null || started === undefined) return;
    const milliseconds = options.clock() - started;
    if (!Number.isFinite(milliseconds) || milliseconds < 0) return;
    const detail = { stage, milliseconds };
    if (Number.isInteger(owners) && owners >= 0 && owners <= options.caps.owners)
      detail.owners = owners;
    try {
      options.onTiming(detail);
    } catch {
      // Optional bounded diagnostics cannot change admission or disposal.
    }
  }
  function extendNativeNodeBounds(node, owner, style, bounds, options) {
    if (options.decoration) return;
    if (node !== owner && node.localName !== 'svg' && !visiblePaper(style)) return;
    const boxes = node.getClientRects ? [...node.getClientRects()] : [nativeRect(node, options)];
    for (const original of boxes)
      extendBounds(bounds, copyRect(original, options.offsetX, options.offsetY), style);
  }
  function inspectNativePseudo(document, box, style, pseudo, bounds, options, tag) {
    const material = pseudoBox(box, style, pseudo);
    if (material === null) return rejectNative(options, 'unsupported-pseudo-paint', tag);
    if (material) extendBounds(bounds, material, pseudo);
    if (inactive(pseudo)) return 0;
    const content = value(pseudo, 'content');
    if (content.length > 2 && !nativeFontSupported(document, pseudo, content.slice(1, -1), options))
      return rejectNative(options, 'unsupported-pseudo-font', tag);
    return Math.max(0, content.length - 2) * 3;
  }
  function inspectNativeNode(node, owner, document, view, options, bounds) {
    const style = nativeStyle(view, node, undefined, options);
    const before = nativeStyle(view, node, '::before', options);
    const after = nativeStyle(view, node, '::after', options);
    if (!nativeSupported(node, style))
      return rejectNative(options, 'unsupported-native-paint', node.localName);
    const box = copyRect(nativeRect(node, options), options.offsetX, options.offsetY);
    extendNativeNodeBounds(node, owner, style, bounds, options);
    let textBytes = 0;
    for (const pseudo of [before, after]) {
      const bytes = inspectNativePseudo(
        document,
        box,
        style,
        pseudo,
        bounds,
        options,
        node.localName
      );
      if (bytes === null) return null;
      textBytes += bytes;
    }
    const hasDirectText = [...node.childNodes].some(
      (child) => child.nodeType === 3 && child.textContent.trim()
    );
    if (hasDirectText && !nativeFontSupported(document, style, node.textContent, options))
      return rejectNative(options, 'unsupported-native-font', node.localName);
    if (
      node.localName === 'img' &&
      (!node.complete || !node.naturalWidth || !node.naturalHeight || !node.currentSrc)
    )
      return rejectNative(options, 'native-image-not-decoded', node.localName);
    if (node.namespaceURI === 'http://www.w3.org/2000/svg')
      textBytes += [...node.attributes].reduce(
        (sum, attribute) => sum + (attribute.name.length + attribute.value.length + 4) * 3,
        0
      );
    const control = node.localName === 'select' ? selectedControl(node) : null;
    return { node, style, before, after, box, textBytes, control };
  }
  function inspectNative(owner, ownerPath, document, view, options, caps, decoration = false) {
    const descendants = decoration ? [] : [...owner.querySelectorAll('*')];
    const text = decoration ? '' : owner.textContent || '';
    const ownerOptions = { ...options, ownerPath, decoration };
    if (descendants.length + 1 > caps.descendants || text.length * 3 > caps.textBytes)
      return rejectNative(ownerOptions, 'native-owner-capacity', owner.localName);
    const rect = copyRect(nativeRect(owner, options), options.offsetX, options.offsetY);
    const bounds = decoration
      ? nativeBorderBounds(rect, nativeStyle(view, owner, undefined, options), options)
      : { ...rect };
    if (!bounds) return false;
    const nodes = [];
    const skippedNodes = new Set();
    let textBytes = text.length * 3;
    for (const node of [owner, ...descendants]) {
      if (options.clock() > options.acquisitionDeadline)
        return rejectNative(ownerOptions, 'acquisition-deadline', node.localName);
      if (node !== owner && invisibleNative(node, owner, view, options)) {
        skippedNodes.add(node);
        continue;
      }
      const record = inspectNativeNode(node, owner, document, view, ownerOptions, bounds);
      if (!record) return null;
      textBytes += record.textBytes;
      if (textBytes > caps.textBytes)
        return rejectNative(ownerOptions, 'native-text-capacity', node.localName);
      nodes.push(record);
    }
    const envelope = {
      left: Math.max(0, bounds.left),
      top: Math.max(options.occludedTop || 0, bounds.top),
      right: Math.min(options.width, bounds.right),
      bottom: Math.min(options.height, bounds.bottom),
    };
    envelope.width = envelope.right - envelope.left;
    envelope.height = envelope.bottom - envelope.top;
    if (!finiteRect(envelope)) return false;
    // A complete visible paper may be larger than one texture at high DPR.
    // Reduce sampling inside the original per-texture pixel ceiling.
    const area = envelope.width * envelope.height;
    const dpr = Math.min(options.dpr, Math.sqrt(settings.maxPixels / area));
    const pixelWidth = Math.max(1, Math.floor(envelope.width * dpr));
    const pixelHeight = Math.max(1, Math.floor(envelope.height * dpr));
    if (pixelWidth * pixelHeight > settings.maxPixels)
      return rejectNative(ownerOptions, 'native-texture-capacity', owner.localName);
    const range = document.createRange();
    let lines;
    try {
      lines = [];
      if (!decoration) {
        range.selectNodeContents(owner);
        lines = [...range.getClientRects()]
          .map((line) => copyRect(line, options.offsetX, options.offsetY))
          .filter(finiteRect);
      }
    } finally {
      range.detach?.();
    }
    return {
      document,
      view,
      owner,
      ownerPath,
      nodes,
      skippedNodes,
      rect,
      envelope,
      lines,
      text,
      decoration,
      paintRects: decoration
        ? nativeBorderBoxes(rect, nativeStyle(view, owner, undefined, options), options)
        : [envelope],
      paintFingerprint: nativePaintFingerprint(nodes, text),
      descendants: descendants.length,
      textBytes,
      dpr,
      pixelWidth,
      pixelHeight,
    };
  }
  function nativeDimensions(style, box, vector) {
    if (vector || ['inline', 'contents', 'none'].includes(value(style, 'display'))) return [];
    let width = box.width;
    let height = box.height;
    if (value(style, 'box-sizing') !== 'border-box') {
      for (const side of ['left', 'right'])
        width -=
          (parseFloat(value(style, 'padding-' + side)) || 0) +
          (parseFloat(value(style, 'border-' + side + '-width')) || 0);
      for (const side of ['top', 'bottom'])
        height -=
          (parseFloat(value(style, 'padding-' + side)) || 0) +
          (parseFloat(value(style, 'border-' + side + '-width')) || 0);
    }
    return width > 0 && height > 0 ? ['width:' + width + 'px', 'height:' + height + 'px'] : [];
  }
  function selectedControl(node) {
    const index = Number.isInteger(node.selectedIndex) ? node.selectedIndex : 0;
    const selected = node.selectedOptions?.[0] || node.options?.[index] || node.children[index];
    return { selectedIndex: index, text: selected?.textContent || '' };
  }
  function nativeControls(measured) {
    if (measured.decoration) return [];
    return (measured.nodes || [])
      .filter(({ node }) => node.localName === 'select')
      .map(({ node, control }) => {
        const path = [];
        for (let current = node; current !== measured.owner; current = current.parentElement) {
          path.unshift([...current.parentElement.children].indexOf(current));
        }
        return { ownerPath: [...(measured.ownerPath || []), ...path], ...control };
      });
  }
  function nativePaintFingerprint(nodes, text) {
    let hash = 2166136261;
    function append(source) {
      for (let index = 0; index < source.length; index++)
        hash = Math.imul(hash ^ source.charCodeAt(index), 16777619);
      hash = Math.imul(hash ^ 0, 16777619);
    }
    append(text);
    for (const { node, style, before, after, control } of nodes) {
      append(node.localName);
      for (const paint of [style, before, after]) {
        // Inactive pseudo boxes produce no native paint. A later generated
        // box changes this marker and receives the complete paint fingerprint.
        if (paint !== style && inactive(paint)) {
          append('inactive:' + value(paint, 'content'));
          continue;
        }
        append(
          [...nativeProperties, ...vectorProperties, 'content']
            .map((name) => value(paint, name))
            .join(';')
        );
      }
      if (node.namespaceURI === 'http://www.w3.org/2000/svg')
        for (const attribute of node.attributes)
          if (vectorAttributes.has(attribute.name)) append(attribute.name + ':' + attribute.value);
      if (node.localName === 'img')
        append([node.currentSrc, node.naturalWidth, node.naturalHeight].join(':'));
      if (control) append(control.selectedIndex + ':' + control.text);
    }
    return (hash >>> 0).toString(16);
  }
  function nativeBorderBoxes(rect, style, options) {
    const boxes = [];
    for (const side of ['top', 'right', 'bottom', 'left']) {
      const width = parseFloat(value(style, 'border-' + side + '-width')) || 0;
      if (!width || value(style, 'border-' + side + '-style') === 'none') continue;
      const box = { ...rect };
      if (side === 'top') box.bottom = rect.top + width;
      if (side === 'bottom') box.top = rect.bottom - width;
      if (side === 'left') box.right = rect.left + width;
      if (side === 'right') box.left = rect.right - width;
      box.left = Math.max(0, box.left);
      box.top = Math.max(options.occludedTop || 0, box.top);
      box.right = Math.min(options.width, box.right);
      box.bottom = Math.min(options.height, box.bottom);
      if (box.right <= box.left || box.bottom <= box.top) continue;
      boxes.push(box);
    }
    return boxes;
  }
  function nativeBorderBounds(rect, style, options) {
    const boxes = nativeBorderBoxes(rect, style, options);
    if (!boxes.length) return null;
    return {
      left: Math.min(...boxes.map((box) => box.left)),
      top: Math.min(...boxes.map((box) => box.top)),
      right: Math.max(...boxes.map((box) => box.right)),
      bottom: Math.max(...boxes.map((box) => box.bottom)),
    };
  }
  function fieldAncestorSupported(style) {
    return (
      ['1', ''].includes(value(style, 'opacity')) &&
      ['auto', ''].includes(value(style, 'z-index')) &&
      ['overflow-x', 'overflow-y'].every((property) =>
        ['visible', ''].includes(value(style, property))
      )
    );
  }
  function unmodifiedOcclusionStyle(style, hidden = false) {
    const opacity = value(style, 'opacity');
    return (
      (hidden
        ? opacity !== '' &&
          Number.isFinite(Number(opacity)) &&
          Number(opacity) >= 0 &&
          Number(opacity) <= 1
        : opacity === '1') &&
      !['none', 'contents'].includes(value(style, 'display')) &&
      (hidden
        ? ['visible', 'hidden'].includes(value(style, 'visibility'))
        : value(style, 'visibility') === 'visible') &&
      [
        'transform',
        'translate',
        'rotate',
        'scale',
        'perspective',
        'filter',
        'backdrop-filter',
        'clip-path',
        'mask-image',
        '-webkit-mask-image',
        'mask-border-source',
        '-webkit-mask-box-image-source',
        'animation-name',
      ].every((property) => ['none', ''].includes(value(style, property))) &&
      ['auto', ''].includes(value(style, 'clip')) &&
      ['normal', ''].includes(value(style, 'mix-blend-mode'))
    );
  }
  function nativeOccludedTop(root, document, view, options) {
    const body = document.body;
    const viewport = document.documentElement;
    const header = document.querySelector?.('.site-header');
    if (
      !options.fieldCapture ||
      !body ||
      !viewport ||
      !header ||
      header.parentElement !== body ||
      !Number.isFinite(viewport.clientWidth) ||
      viewport.clientWidth <= 0
    )
      return 0;
    const sourceStyle = nativeStyle(view, root, undefined, options);
    const staged = root.classList?.contains('embedded-stage');
    if (
      !finiteRect(nativeRect(root, options)) ||
      !(
        (root.id === 'site-content' && value(sourceStyle, 'isolation') === 'isolate') ||
        (staged && value(sourceStyle, 'position') === 'fixed')
      )
    )
      return 0;
    const style = nativeStyle(view, header, undefined, options);
    const zIndex = value(style, 'z-index');
    const color = value(style, 'background-color');
    const opaque =
      /^rgb\(\s*\d+(?:\.\d+)?\s*,\s*\d+(?:\.\d+)?\s*,\s*\d+(?:\.\d+)?\s*\)$/.test(color) ||
      /^rgba\(\s*\d+(?:\.\d+)?\s*,\s*\d+(?:\.\d+)?\s*,\s*\d+(?:\.\d+)?\s*,\s*1(?:\.0+)?\s*\)$/.test(
        color
      );
    if (
      !unmodifiedOcclusionStyle(style) ||
      !['sticky', 'fixed'].includes(value(style, 'position')) ||
      !/^\d+$/.test(zIndex) ||
      !Number.isSafeInteger(Number(zIndex)) ||
      Number(zIndex) <= 0 ||
      !opaque ||
      value(style, 'background-image') !== 'none' ||
      value(style, 'background-clip') !== 'border-box' ||
      !['none', ''].includes(value(style, 'box-shadow')) ||
      !['top-left', 'top-right', 'bottom-left', 'bottom-right'].every((corner) =>
        /^(?:0|0px)(?:\s+(?:0|0px))*$/.test(value(style, 'border-' + corner + '-radius'))
      )
    )
      return 0;
    let reachedBody = false;
    for (let node = root, depth = 0; node; node = node.parentElement, depth++) {
      if (depth > 16 || options.clock() > options.acquisitionDeadline) return 0;
      const ancestor = nativeStyle(view, node, undefined, options);
      const stacking = value(ancestor, 'z-index');
      if (
        !unmodifiedOcclusionStyle(ancestor, node === root) ||
        !(
          ['auto', ''].includes(stacking) ||
          (/^-?\d+$/.test(stacking) && Number(stacking) < Number(zIndex))
        )
      )
        return 0;
      if (node === body) {
        reachedBody = true;
        break;
      }
    }
    const rect = nativeRect(header, options);
    if (
      !finiteRect(rect) ||
      rect.left > 0 ||
      rect.right < viewport.clientWidth ||
      rect.top > 0 ||
      rect.bottom <= 0
    )
      return 0;
    if (
      !reachedBody ||
      ![body, viewport].every((node) => {
        const common = nativeStyle(view, node, undefined, options);
        if (
          !unmodifiedOcclusionStyle(common) ||
          /(?:^|\s)(?:paint|strict|content)(?:\s|$)/.test(value(common, 'contain'))
        )
          return false;
        const clipped = ['x', 'y'].filter(
          (axis) => !['visible', ''].includes(value(common, 'overflow-' + axis))
        );
        if (!clipped.length) return true;
        if (
          clipped.some((axis) => !['clip', 'hidden'].includes(value(common, 'overflow-' + axis))) ||
          !['top-left', 'top-right', 'bottom-left', 'bottom-right'].every((corner) =>
            /^(?:0|0px)(?:\s+(?:0|0px))*$/.test(value(common, 'border-' + corner + '-radius'))
          )
        )
          return false;
        const box = nativeRect(node, options);
        if (!finiteRect(box)) return false;
        const border = (side) => parseFloat(value(common, 'border-' + side + '-width')) || 0;
        return (
          (!clipped.includes('x') ||
            (box.left + border('left') <= 0 &&
              box.right - border('right') >= viewport.clientWidth)) &&
          (!clipped.includes('y') ||
            (box.top + border('top') <= 0 && box.bottom - border('bottom') >= rect.bottom))
        );
      })
    )
      return 0;
    return Math.max(0, Math.min(options.height, rect.bottom - options.offsetY));
  }
  function nativeImageDimensions(measured, node, box) {
    const scale = Math.min(
      1,
      Math.max(
        (box.width * measured.dpr) / node.naturalWidth,
        (box.height * measured.dpr) / node.naturalHeight
      ),
      Math.sqrt(settings.maxPixels / (node.naturalWidth * node.naturalHeight))
    );
    if (!Number.isFinite(scale) || scale <= 0) throw new Error('Native image capacity');
    return {
      width: Math.max(1, Math.floor(node.naturalWidth * scale)),
      height: Math.max(1, Math.floor(node.naturalHeight * scale)),
    };
  }
  function nativeImageSource(measured, node, box) {
    const { document } = measured;
    const bitmap = document.createElement('canvas');
    try {
      const dimensions = nativeImageDimensions(measured, node, box);
      bitmap.width = dimensions.width;
      bitmap.height = dimensions.height;
      const context = bitmap.getContext('2d');
      if (!context) throw new Error('Native image raster unavailable');
      context.drawImage(node, 0, 0, bitmap.width, bitmap.height);
      const source = bitmap.toDataURL('image/png');
      if (!/^data:image\/png;base64,/.test(source)) throw new Error('Native image not local');
      return source;
    } finally {
      bitmap.width = 0;
      bitmap.height = 0;
    }
  }
  function sharedNativeStyle(owners, pseudo = null) {
    const common = new Map();
    let first = true;
    function intersect(style) {
      if (first) {
        for (const property of nativeProperties) {
          const resolved = value(style, property);
          if (resolved) common.set(property, resolved);
        }
        first = false;
        return;
      }
      for (const [property, resolved] of common) {
        if (value(style, property) !== resolved) common.delete(property);
      }
    }
    for (const owner of owners) {
      for (const record of owner.nodes) {
        const style = record[pseudo || 'style'];
        if (pseudo && inactive(style)) continue;
        intersect(style);
      }
    }
    // Only values identical in every captured element enter this SVG-local
    // rule. Node overrides, dimensions and owner pseudos keep their precedence.
    const declarations = [...common].map(([property, resolved]) => property + ':' + resolved);
    const selector = '.embedded-native-paint' + (pseudo ? '::' + pseudo : '');
    return { common, css: selector + '{' + declarations.join(';') + '}' };
  }
  function sharedNativeStyles(owners) {
    return {
      style: sharedNativeStyle(owners),
      before: sharedNativeStyle(owners, 'before'),
      after: sharedNativeStyle(owners, 'after'),
      declarations: new Map(),
    };
  }
  function nativeMarkup(measured, prefix, shared) {
    const { nodes, rect, envelope } = measured;
    const records = new Map(nodes.map((record, index) => [record.node, { ...record, index }]));
    const css = [];
    function declarations(style, properties, common = null) {
      return properties
        .map((property) => {
          const resolved = value(style, property);
          return resolved && common?.get(property) !== resolved ? property + ':' + resolved : '';
        })
        .filter(Boolean);
    }
    function render(node) {
      if (node.nodeType === 3) return escapeXML(node.textContent);
      if (node.nodeType !== 1) return '';
      if (measured.skippedNodes?.has(node)) return '';
      const record = records.get(node);
      if (!record) throw new Error('Native texture tree changed');
      const { style, before, after, index, box } = record;
      const className = 'embedded-node-' + prefix + index;
      const vector = node.namespaceURI === 'http://www.w3.org/2000/svg';
      const properties = vector ? [...nativeProperties, ...vectorProperties] : nativeProperties;
      const styles = declarations(style, properties, shared.style.common);
      styles.push('visibility:visible', 'animation:none', 'transition:none');
      styles.push(...nativeDimensions(style, box, vector));
      if (node === measured.owner) {
        styles.push(
          'position:absolute',
          'margin:0',
          'left:' + (rect.left - envelope.left) + 'px',
          'top:' + (rect.top - envelope.top) + 'px',
          'right:auto',
          'bottom:auto'
        );
      }
      for (const [name, pseudo] of [
        ['before', before],
        ['after', after],
      ]) {
        if (inactive(pseudo)) continue;
        css.push(
          '.' +
            className +
            '::' +
            name +
            '{' +
            [
              ...declarations(pseudo, nativeProperties, shared[name].common),
              'content:' + value(pseudo, 'content'),
              'visibility:visible',
            ].join(';') +
            '}'
        );
      }
      const declaration = styles.join(';');
      let paintClass = shared.declarations.get(declaration);
      if (!paintClass) {
        paintClass = 'embedded-paint-' + shared.declarations.size;
        shared.declarations.set(declaration, paintClass);
        css.push('.' + paintClass + '{' + declaration + '}');
      }
      const attributes = [
        'class="embedded-native-paint ' + className + ' ' + paintClass + '"',
        'style=""',
      ];
      if (vector) {
        if (node.localName === 'svg') attributes.push('xmlns="http://www.w3.org/2000/svg"');
        for (const attribute of node.attributes) {
          if (vectorAttributes.has(attribute.name))
            attributes.push(attribute.name + '="' + escapeXML(attribute.value) + '"');
        }
      }
      if (node.localName === 'img')
        attributes.push('src="' + nativeImageSource(measured, node, box) + '"');
      const selected = record.control;
      const children = measured.decoration
        ? ''
        : selected
          ? '<option selected="selected">' + escapeXML(selected.text) + '</option>'
          : [...node.childNodes].map(render).join('');
      const tag = node.localName;
      if (['img', 'br', 'hr'].includes(tag)) return '<' + tag + ' ' + attributes.join(' ') + '/>';
      return '<' + tag + ' ' + attributes.join(' ') + '>' + children + '</' + tag + '>';
    }
    return { content: render(measured.owner), css };
  }
  function nativeSVG(measured, markup) {
    const { envelope, pixelWidth, pixelHeight } = measured;
    const { content, css } = markup;
    // Keep the SVG viewport at bitmap size. WebKit can leave positioned HTML
    // unscaled by an SVG viewBox; scale its native CSS plane instead, using the
    // same independent rounded axes as Canvas readback and owner exclusion.
    return (
      '<svg xmlns="http://www.w3.org/2000/svg" width="' +
      pixelWidth +
      '" height="' +
      pixelHeight +
      '" preserveAspectRatio="none" viewBox="0 0 ' +
      pixelWidth +
      ' ' +
      pixelHeight +
      '"><foreignObject width="' +
      pixelWidth +
      '" height="' +
      pixelHeight +
      '"><div xmlns="http://www.w3.org/1999/xhtml" style="position:relative;width:' +
      envelope.width +
      'px;height:' +
      envelope.height +
      'px;transform-origin:0 0;transform:scale(' +
      pixelWidth / envelope.width +
      ',' +
      pixelHeight / envelope.height +
      ')">' +
      '<style>' +
      escapeXML(css.join('')) +
      '</style>' +
      content +
      '</div></foreignObject></svg>'
    );
  }
  function serializeNative(measured) {
    const shared = sharedNativeStyles([measured]);
    const markup = nativeMarkup(measured, '', shared);
    return nativeSVG(measured, {
      ...markup,
      css: [shared.style.css, shared.before.css, shared.after.css, ...markup.css],
    });
  }
  function serializeField(measured) {
    const shared = sharedNativeStyles(measured.fieldOwners);
    const fragments = measured.fieldOwners.map((owner) => {
      const fragment = nativeMarkup(
        { ...owner, dpr: measured.dpr },
        owner.ownerIndex + '-',
        shared
      );
      const placement = [
        'position:absolute',
        'overflow:hidden',
        'isolation:isolate',
        'left:' + (owner.envelope.left - measured.envelope.left) + 'px',
        'top:' + (owner.envelope.top - measured.envelope.top) + 'px',
        'width:' + owner.envelope.width + 'px',
        'height:' + owner.envelope.height + 'px',
      ].join(';');
      return {
        css: fragment.css,
        content: '<div style="' + escapeXML(placement) + '">' + fragment.content + '</div>',
      };
    });
    return nativeSVG(measured, {
      css: [
        shared.style.css,
        shared.before.css,
        shared.after.css,
        ...fragments.flatMap((fragment) => fragment.css),
      ],
      content: fragments.map((fragment) => fragment.content).join(''),
    });
  }
  function decodeNativeImages(root, view, options) {
    const { signal } = options;
    const images = [...root.querySelectorAll('img')].filter(
      (image) =>
        (!image.complete || !image.naturalWidth || !image.naturalHeight) &&
        value(view.getComputedStyle(image), 'display') !== 'none' &&
        (() => {
          const rect = copyRect(image.getBoundingClientRect(), options.offsetX, options.offsetY);
          return (
            finiteRect(rect) &&
            rect.right > -64 &&
            rect.left < options.width + 64 &&
            rect.bottom > -64 &&
            rect.top < options.height + 64
          );
        })()
    );
    if (!images.length) return true;
    if (images.some((image) => typeof image.decode !== 'function')) return false;
    return new Promise((resolve) => {
      let finished = false;
      let timeout;
      function finish(success) {
        if (finished) return;
        finished = true;
        view.clearTimeout(timeout);
        signal?.removeEventListener('abort', abort);
        resolve(success);
      }
      function abort() {
        finish(false);
      }
      signal?.addEventListener('abort', abort, { once: true });
      timeout = view.setTimeout(abort, Math.max(1, options.deadline - options.clock()));
      if (signal?.aborted) return abort();
      Promise.all(images.map((image) => Promise.resolve().then(() => image.decode()))).then(
        () =>
          finish(
            images.every((image) => image.complete && image.naturalWidth && image.naturalHeight)
          ),
        abort
      );
    });
  }
  function measureNativeOwners(root, document, view, normalized, caps) {
    const clock = normalized.clock;
    // Each synchronous acquisition owns its cache; media decode finishes
    // before this snapshot, and later captures always read fresh native styles.
    normalized.styleCache = new WeakMap();
    normalized.rectCache = new WeakMap();
    normalized.fontCache = { families: new Map() };
    // A proven opaque header covers this part of the native viewport. Keep
    // source geometry unchanged; only visible native paint belongs to the atlas.
    // These fresh style reads share the original acquisition deadline.
    normalized.occludedTop = nativeOccludedTop(root, document, view, normalized);
    const measured = [];
    const usage = { owners: 0, descendants: 0, textBytes: 0, layerPixels: 0 };
    const semantic = new Set([
      'h1',
      'h2',
      'h3',
      'h4',
      'h5',
      'h6',
      'p',
      'img',
      'figure',
      'li',
      'dt',
      'dd',
      'figcaption',
      'blockquote',
      'pre',
      'a',
      'button',
      'label',
      'select',
      'span',
      'time',
      'strong',
      'small',
    ]);
    function fail(code, path, node, extra) {
      rejectNative({ ...normalized, ownerPath: path }, code, node.localName, extra);
      throw new Error('Native capture rejected');
    }
    function admit(item, path, node) {
      const increment = {
        owners: 1,
        descendants: item.descendants,
        textBytes: item.textBytes,
        layerPixels: item.pixelWidth * item.pixelHeight,
      };
      for (const name of Object.keys(usage)) {
        usage[name] += increment[name];
        if (usage[name] > caps[name])
          fail('shared-texture-capacity', path, node, {
            limit: name,
            usage: usage[name],
            maximum: caps[name],
          });
      }
      item.ownerIndex = measured.length;
      measured.push(item);
    }
    function admitFieldDecoration(node, path, style, box) {
      if (!normalized.fieldCapture) return;
      if (!fieldAncestorSupported(style)) fail('unsupported-field-ancestor', path, node);
      if (!nativeBorderBounds(box, style, normalized)) return;
      const decoration = inspectNative(node, path, document, view, normalized, caps, true);
      if (decoration === false) return;
      if (!decoration) fail('unsupported-field-decoration', path, node);
      admit(decoration, path, node);
    }
    function visit(node, path) {
      if (clock() > normalized.acquisitionDeadline) fail('acquisition-deadline', path, node);
      if (node.hasAttribute('hidden')) return;
      const style = nativeStyle(view, node, undefined, normalized);
      if (
        value(style, 'display') === 'none' ||
        value(style, 'opacity') === '0' ||
        fullyClipped(style)
      )
        return;
      if (value(style, 'display') === 'contents') {
        if (!nativeAncestorSupported(node, style)) fail('unsupported-native-ancestor', path, node);
        if (normalized.fieldCapture && !fieldAncestorSupported(style))
          fail('unsupported-field-ancestor', path, node);
        [...node.children].forEach((child, index) => visit(child, [...path, index]));
        return;
      }
      const native = nativeRect(node, normalized);
      if (!finiteRect(native)) return;
      const box = copyRect(native, normalized.offsetX, normalized.offsetY);
      if (
        box.right <= -64 ||
        box.left >= normalized.width + 64 ||
        box.bottom <= -64 ||
        box.top >= normalized.height + 64
      )
        return;
      // Structural ancestors are never serialized. Validate their inherited
      // layout effects here; complete resolved paint admission belongs to each
      // captured owner, avoiding a full style clone for every unpainted wrapper.
      if (!nativeAncestorSupported(node, style)) fail('unsupported-native-ancestor', path, node);
      const before = nativeStyle(view, node, '::before', normalized);
      const after = nativeStyle(view, node, '::after', normalized);
      const atomic =
        visiblePaper(style) ||
        visiblePaper(before, true) ||
        visiblePaper(after, true) ||
        ['figure', 'svg'].includes(node.localName);
      const inlineGroup =
        node.localName === 'div' &&
        node.children.length > 0 &&
        [...node.children].every((child) =>
          ['span', 'time', 'strong', 'small'].includes(child.localName)
        );
      if (atomic || semantic.has(node.localName) || inlineGroup) {
        if (normalized.fieldCapture && !['auto', ''].includes(value(style, 'z-index')))
          fail('unsupported-field-stacking', path, node);
        const item = inspectNative(node, path, document, view, normalized, caps);
        if (item === false) return;
        if (!item) fail('unsupported-visible-native-paint', path, node);
        admit(item, path, node);
        return;
      }
      admitFieldDecoration(node, path, style, box);
      [...node.children].forEach((child, index) => visit(child, [...path, index]));
    }
    visit(root, []);
    return { measured, usage };
  }
  function nativeTransientPixels(measured, ownerPixels) {
    const images = measured.flatMap((item) =>
      item.nodes
        .filter(({ node }) => node.localName === 'img')
        .map(({ node, box }) => {
          const dimensions = nativeImageDimensions(item, node, box);
          return dimensions.width * dimensions.height;
        })
    );
    // Known bitmap surfaces: owner canvases and decoded SVG images, each
    // inlined PNG decode, and the largest sequential PNG encoding canvas.
    return (
      ownerPixels * 2 + images.reduce((sum, pixels) => sum + pixels, 0) + Math.max(0, ...images)
    );
  }
  function nativeCaptureContext(root, options, onReject) {
    const document = root?.ownerDocument;
    const view = document?.defaultView;
    if (!root?.isConnected || !view || typeof view.Image !== 'function' || options.signal?.aborted)
      return rejectNative({ ...options, onReject }, 'native-capture-unavailable', root?.localName);
    const clock = () => view.performance?.now() ?? Date.now();
    const started = clock();
    const normalized = {
      ...options,
      offsetX: options.offsetX ?? 0,
      offsetY: options.offsetY ?? 0,
      dpr: options.dpr ?? view.devicePixelRatio ?? 1,
      occludedTop: 0,
      clock,
      deadline: Math.min(
        started + Math.min(160, options.preparationMs ?? 160),
        options.deadline ?? Infinity
      ),
      onReject,
    };
    if (
      ![
        normalized.width,
        normalized.height,
        normalized.offsetX,
        normalized.offsetY,
        normalized.dpr,
        normalized.deadline,
      ].every(Number.isFinite) ||
      normalized.width <= 0 ||
      normalized.height <= 0 ||
      normalized.dpr <= 0 ||
      normalized.dpr > settings.maxDpr
    )
      return rejectNative(normalized, 'invalid-capture-geometry', root.localName);
    const caps = options.caps;
    if (
      !caps ||
      ['owners', 'descendants', 'textBytes', 'layerPixels'].some(
        (name) => !Number.isFinite(caps[name]) || caps[name] < 0
      )
    )
      return rejectNative(normalized, 'invalid-capture-capacity', root.localName);
    return { document, view, normalized, started };
  }
  async function captureAll(root, options = {}) {
    const assets = [];
    let controller;
    let externalAbort;
    let reported = false;
    const onReject = (detail) => {
      if (reported) return;
      reported = true;
      options.onReject?.(detail);
    };
    try {
      const context = nativeCaptureContext(root, options, onReject);
      if (!context) return null;
      const { document, view, normalized } = context;
      const clock = normalized.clock;
      const caps = options.caps;
      if (typeof view.AbortController !== 'function')
        return rejectNative(normalized, 'native-cancellation-unavailable', root.localName);
      controller = new view.AbortController();
      externalAbort = () => controller.abort();
      options.signal?.addEventListener('abort', externalAbort, { once: true });
      normalized.signal = controller.signal;
      if (options.signal?.aborted) controller.abort();
      const decoded = decodeNativeImages(root, view, normalized);
      if (!(typeof decoded === 'boolean' ? decoded : await decoded))
        return rejectNative(normalized, 'native-media-decode-failed', 'img');
      normalized.acquisitionDeadline = Math.min(
        normalized.deadline,
        clock() + Math.min(80, options.acquisitionMs ?? 80)
      );
      const { measured, usage } = measureNativeOwners(root, document, view, normalized, caps);
      const transientPixels = options.fieldCapture
        ? nativeTransientPixels(measured, usage.layerPixels)
        : usage.layerPixels;
      if (transientPixels > caps.layerPixels)
        return rejectNative(normalized, 'field-decode-capacity', root.localName, {
          limit: 'layerPixels',
          usage: transientPixels,
          maximum: caps.layerPixels,
        });
      const captured = await Promise.all(
        measured.map(async (item) => {
          const asset = await raster(item, normalized, serializeNative);
          if (asset) assets.push(asset);
          else controller.abort();
          return asset;
        })
      );
      const expired = clock() > normalized.deadline;
      if (expired) rejectNative(normalized, 'preparation-deadline', root.localName);
      if (captured.some((asset) => !asset) || normalized.signal.aborted || expired)
        throw new Error('Native texture capture failed');
      assets.sort((a, b) => a.ownerIndex - b.ownerIndex);
      assets.transientPixels = transientPixels;
      return assets;
    } catch {
      rejectNative({ ...options, onReject }, 'native-capture-failed', root?.localName);
      controller?.abort();
      for (const asset of assets) asset.dispose();
      return null;
    } finally {
      options.signal?.removeEventListener('abort', externalAbort);
    }
  }
  async function capture(root, options = {}) {
    let measured;
    try {
      measured = measure(root, options);
    } catch {
      return null;
    }
    return raster(measured, options, serialize);
  }
  function canvasDisposer(canvas) {
    let disposed = false;
    return () => {
      if (disposed) return;
      disposed = true;
      canvas.width = 0;
      canvas.height = 0;
    };
  }
  function fieldEnvelope(assets) {
    const envelope = {
      left: Math.min(...assets.map((asset) => asset.envelope.left)),
      top: Math.min(...assets.map((asset) => asset.envelope.top)),
      right: Math.max(...assets.map((asset) => asset.envelope.right)),
      bottom: Math.max(...assets.map((asset) => asset.envelope.bottom)),
    };
    envelope.width = envelope.right - envelope.left;
    envelope.height = envelope.bottom - envelope.top;
    return envelope;
  }
  function fieldDimensions(envelope, dpr, available) {
    if (!finiteRect(envelope) || available < 1) return null;
    const sampling = Math.min(
      dpr,
      Math.sqrt(Math.min(settings.maxPixels, available) / (envelope.width * envelope.height))
    );
    const width = Math.max(1, Math.floor(envelope.width * sampling));
    const height = Math.max(1, Math.floor(envelope.height * sampling));
    return width * height <= available ? { width, height, dpr: sampling } : null;
  }
  function fieldAsset(root, assets, canvas, envelope, dpr) {
    return {
      canvas,
      owner: root,
      ownerPath: [],
      ownerIndex: 0,
      rect: envelope,
      envelope,
      lines: [],
      dpr,
      pixelCount: canvas.width * canvas.height,
      descendants: assets.reduce((sum, asset) => sum + asset.descendants, 0),
      textBytes: assets.reduce((sum, asset) => sum + asset.textBytes, 0),
      sourceOwners: assets
        .filter((asset) => !asset.decoration)
        .map(
          ({
            ownerPath,
            rect,
            lines,
            envelope: sourceEnvelope,
            textContent,
            controls,
            paintFingerprint,
          }) => ({
            ownerPath,
            rect,
            lines,
            envelope: sourceEnvelope,
            textContent,
            controls,
            paintFingerprint,
          })
        ),
      decorations: assets
        .filter((asset) => asset.decoration)
        .map(({ ownerPath, rect, envelope: sourceEnvelope, paintFingerprint }) => ({
          ownerPath,
          rect,
          envelope: sourceEnvelope,
          paintFingerprint,
        })),
      dispose: canvasDisposer(canvas),
    };
  }
  function sameNativeRect(first, second) {
    return (
      !!second &&
      ['left', 'top', 'width', 'height'].every((key) => Math.abs(first[key] - second[key]) <= 0.75)
    );
  }
  function sameNativeSource(current, previous) {
    return (
      JSON.stringify(current.ownerPath) === JSON.stringify(previous.ownerPath) &&
      current.text === previous.textContent &&
      current.paintFingerprint === previous.paintFingerprint &&
      sameNativeRect(current.rect, previous.rect) &&
      sameNativeRect(current.envelope, previous.envelope) &&
      current.lines.length === previous.lines.length &&
      current.lines.every((line, index) => sameNativeRect(line, previous.lines[index])) &&
      JSON.stringify(nativeControls(current)) === JSON.stringify(previous.controls || [])
    );
  }
  function matchesField(root, sourceOwners, options = {}) {
    try {
      const document = root?.ownerDocument;
      const view = document?.defaultView;
      if (!root?.isConnected || !view || !Array.isArray(sourceOwners) || !options.caps)
        return false;
      const clock = () => view.performance?.now() ?? Date.now();
      const deadline = clock() + Math.min(80, options.acquisitionMs ?? 80);
      const normalized = {
        ...options,
        offsetX: options.offsetX ?? 0,
        offsetY: options.offsetY ?? 0,
        dpr: options.dpr ?? view.devicePixelRatio ?? 1,
        fieldCapture: true,
        clock,
        deadline,
        acquisitionDeadline: deadline,
      };
      if (![options.width, options.height, normalized.dpr, deadline].every(Number.isFinite))
        return false;
      const { measured } = measureNativeOwners(root, document, view, normalized, options.caps);
      const semantic = measured.filter((item) => !item.decoration);
      if (
        semantic.length !== sourceOwners.length ||
        !semantic.every((item, index) => sameNativeSource(item, sourceOwners[index]))
      )
        return false;
      const decorations = measured.filter((item) => item.decoration);
      if (
        options.decorations &&
        (decorations.length !== options.decorations.length ||
          !decorations.every((item, index) => {
            const previous = options.decorations[index];
            return (
              JSON.stringify(item.ownerPath) === JSON.stringify(previous.ownerPath) &&
              item.paintFingerprint === previous.paintFingerprint &&
              sameNativeRect(item.rect, previous.rect) &&
              sameNativeRect(item.envelope, previous.envelope)
            );
          }))
      )
        return false;
      return clock() <= deadline;
    } catch {
      return false;
    }
  }
  function fieldSource(owner) {
    return {
      ownerPath: owner.ownerPath,
      rect: owner.rect,
      lines: owner.lines,
      envelope: owner.envelope,
      textContent: owner.text,
      controls: nativeControls(owner),
      paintFingerprint: owner.paintFingerprint,
      decoration: owner.decoration,
      descendants: owner.descendants,
      textBytes: owner.textBytes,
    };
  }
  function fieldPixelBox(box, measured) {
    const scaleX = measured.pixelWidth / measured.envelope.width;
    const scaleY = measured.pixelHeight / measured.envelope.height;
    return {
      left: Math.max(0, Math.floor((box.left - measured.envelope.left) * scaleX)),
      top: Math.max(0, Math.floor((box.top - measured.envelope.top) * scaleY)),
      right: Math.min(
        measured.pixelWidth,
        Math.ceil((box.right - measured.envelope.left) * scaleX)
      ),
      bottom: Math.min(
        measured.pixelHeight,
        Math.ceil((box.bottom - measured.envelope.top) * scaleY)
      ),
    };
  }
  function subtractFieldBox(box, cover) {
    const left = Math.max(box.left, cover.left);
    const top = Math.max(box.top, cover.top);
    const right = Math.min(box.right, cover.right);
    const bottom = Math.min(box.bottom, cover.bottom);
    if (left >= right || top >= bottom) return [box];
    return [
      { ...box, bottom: top },
      { ...box, top: bottom },
      { left: box.left, right: left, top, bottom },
      { left: right, right: box.right, top, bottom },
    ].filter((part) => part.left < part.right && part.top < part.bottom);
  }
  function fieldBoxesOverlap(first, second) {
    return (
      first.left < second.right &&
      first.right > second.left &&
      first.top < second.bottom &&
      first.bottom > second.top
    );
  }
  function fieldInkOwners(measured) {
    return measured.fieldOwners.map((owner) => {
      const boxes = owner.paintRects.map((box) => fieldPixelBox(box, measured));
      return {
        owner,
        boxes,
        bounds: {
          left: Math.min(...boxes.map((box) => box.left)),
          top: Math.min(...boxes.map((box) => box.top)),
          right: Math.max(...boxes.map((box) => box.right)),
          bottom: Math.max(...boxes.map((box) => box.bottom)),
        },
      };
    });
  }
  function exclusiveFieldBoxes(item, owners, options) {
    let boxes = item.boxes;
    for (const other of owners) {
      if (options.clock() > options.deadline) return null;
      if (other === item || !fieldBoxesOverlap(item.bounds, other.bounds)) continue;
      for (const cover of other.boxes) {
        if (options.clock() > options.deadline) return null;
        if (!boxes.some((box) => fieldBoxesOverlap(box, cover))) continue;
        // Outward floor/ceil excludes all peer pixels, including fractional
        // edges. Keep an adjacent one-pixel native border observable.
        boxes = boxes.flatMap((box) => subtractFieldBox(box, cover));
      }
    }
    return boxes;
  }
  function fieldBoxHasInk(box, pixels, width) {
    for (let y = box.top; y < box.bottom; y++)
      for (let x = box.left; x < box.right; x++)
        if (pixels[(y * width + x) * 4 + 3] > 0) return true;
    return false;
  }
  function ambiguousDecoration(item, owners) {
    if (!item.owner.decoration) return false;
    const others = owners.filter(
      (other) => other !== item && fieldBoxesOverlap(item.bounds, other.bounds)
    );
    // Isolation can resolve rounding at adjoining borders. It cannot prove
    // which native owner contributed ink inside genuinely overlapping paint.
    if (
      others.some((other) =>
        item.owner.paintRects.some((rect) =>
          other.owner.paintRects.some((cover) => fieldBoxesOverlap(rect, cover))
        )
      )
    )
      return false;
    return others.some(
      (other) =>
        other.owner.decoration &&
        item.boxes.some((box) => other.boxes.some((cover) => fieldBoxesOverlap(box, cover)))
    );
  }
  async function fieldHasNativeInk(context, measured, options) {
    if (options.signal?.aborted || options.clock() > options.deadline) {
      reportTiming(options, 'readback', options.readbackStarted);
      rejectNative(options, 'preparation-deadline', measured.owner.localName);
      return false;
    }
    let pixels;
    try {
      pixels = context.getImageData(0, 0, measured.pixelWidth, measured.pixelHeight).data;
    } finally {
      reportTiming(options, 'readback', options.readbackStarted);
    }
    const proofStarted = timingStart(options);
    let isolatedProofs = 0;
    let proofReported = false;
    const finishProof = () => {
      if (proofReported) return;
      proofReported = true;
      options.signal?.removeEventListener('abort', finishProof);
      reportTiming(options, 'proof', proofStarted, isolatedProofs);
    };
    if (proofStarted !== null)
      options.signal?.addEventListener('abort', finishProof, { once: true });
    try {
      const owners = fieldInkOwners(measured);
      for (const item of owners) {
        const owner = item.owner;
        const boxes = exclusiveFieldBoxes(item, owners, options);
        if (!boxes || options.signal?.aborted || options.clock() > options.deadline) {
          rejectNative(options, 'preparation-deadline', measured.owner.localName);
          return false;
        }
        if (!boxes.some((box) => fieldBoxHasInk(box, pixels, measured.pixelWidth))) {
          // Fractional adjacent borders may legitimately share one raster pixel.
          // Prove that owner's native paint in isolation instead of borrowing
          // its neighbour's alpha. Both the composite and isolated paint need ink.
          if (
            ambiguousDecoration(item, owners) &&
            item.boxes.some((box) => fieldBoxHasInk(box, pixels, measured.pixelWidth))
          ) {
            isolatedProofs++;
            // Nested proof decoding belongs to the inclusive ownership-proof
            // stage, never a second main-field decode or total observation.
            const proof = await raster(owner, { ...options, onTiming: undefined }, serializeNative);
            if (proof) {
              proof.dispose();
              if (!options.signal?.aborted && options.clock() <= options.deadline) continue;
              rejectNative(options, 'preparation-deadline', measured.owner.localName);
              return false;
            }
          }
          rejectNative(
            { ...options, ownerPath: owner.ownerPath },
            'native-owner-raster-blank',
            owner.owner.localName
          );
          return false;
        }
      }
      return true;
    } finally {
      finishProof();
    }
  }
  async function captureField(root, options = {}) {
    let reported = false;
    const onReject = (detail) => {
      if (reported) return;
      reported = true;
      options.onReject?.(detail);
    };
    let capture;
    let timingOptions;
    let captureStarted;
    let complete = false;
    const fieldOptions = { ...options, onReject, fieldCapture: true };
    try {
      const retained = options.retainedPixels ?? 0;
      if (!Number.isFinite(retained) || retained < 0)
        return rejectNative(fieldOptions, 'invalid-field-retained-capacity', root?.localName);
      fieldOptions.caps = { ...options.caps, layerPixels: options.caps?.layerPixels - retained };
      const context = nativeCaptureContext(root, fieldOptions, onReject);
      if (!context) return null;
      const { document, view, normalized } = context;
      timingOptions = normalized;
      captureStarted = context.started;
      if (typeof view.AbortController !== 'function')
        return rejectNative(normalized, 'native-cancellation-unavailable', root.localName);
      const decoded = decodeNativeImages(root, view, normalized);
      if (!(typeof decoded === 'boolean' ? decoded : await decoded))
        return rejectNative(normalized, 'native-media-decode-failed', 'img');
      normalized.acquisitionDeadline = Math.min(
        normalized.deadline,
        normalized.clock() + Math.min(80, options.acquisitionMs ?? 80)
      );
      let measured;
      const measureStarted = timingStart(normalized);
      try {
        measured = measureNativeOwners(root, document, view, normalized, normalized.caps).measured;
      } finally {
        reportTiming(normalized, 'measure', measureStarted, measured?.length || 0);
      }
      if (!measured.length) return rejectNative(normalized, 'native-field-empty', root.localName);
      const envelope = fieldEnvelope(measured);
      const dimensions = fieldDimensions(envelope, normalized.dpr, settings.maxPixels);
      if (!dimensions) return rejectNative(normalized, 'native-texture-capacity', root.localName);
      const fieldOwners = measured.map((owner) => ({ ...owner, dpr: dimensions.dpr }));
      const pixelCount = dimensions.width * dimensions.height;
      // One SVG decode, its destination canvas, and the bounded ownership-alpha
      // readback coexist. PNG decode and sequential encoding surfaces remain charged.
      const borderProofPixels = Math.max(
        0,
        ...fieldOwners
          .filter((owner) => owner.decoration)
          .map((owner) => owner.pixelWidth * owner.pixelHeight * 3)
      );
      const peak = nativeTransientPixels(fieldOwners, pixelCount) + pixelCount + borderProofPixels;
      if (peak > normalized.caps.layerPixels)
        return rejectNative(normalized, 'field-peak-capacity', root.localName, {
          limit: 'layerPixels',
          usage: retained + peak,
          maximum: options.caps.layerPixels,
        });
      const measuredField = {
        document,
        view,
        owner: root,
        ownerPath: [],
        ownerIndex: 0,
        rect: envelope,
        envelope,
        lines: [],
        text: '',
        dpr: dimensions.dpr,
        pixelWidth: dimensions.width,
        pixelHeight: dimensions.height,
        fieldOwners,
      };
      capture = await raster(measuredField, normalized, serializeField);
      if (!capture) return null;
      if (normalized.signal?.aborted || normalized.clock() > normalized.deadline)
        return rejectNative(normalized, 'preparation-deadline', root.localName);
      // Decode may yield to changes in the header. Never hide native content
      // using a field that omitted paint newly exposed during that await.
      const fresh = {
        ...normalized,
        styleCache: new WeakMap(),
        rectCache: new WeakMap(),
        acquisitionDeadline: normalized.deadline,
      };
      const occludedTop = nativeOccludedTop(root, document, view, fresh);
      if (normalized.signal?.aborted || normalized.clock() > normalized.deadline)
        return rejectNative(normalized, 'preparation-deadline', root.localName);
      if (occludedTop !== normalized.occludedTop)
        return rejectNative(normalized, 'native-occlusion-changed', root.localName);
      const asset = fieldAsset(
        root,
        measured.map(fieldSource),
        capture.canvas,
        envelope,
        dimensions.dpr
      );
      complete = true;
      return asset;
    } catch {
      return rejectNative(fieldOptions, 'native-field-composite-failed', root?.localName);
    } finally {
      if (!complete) capture?.dispose();
      if (typeof timingOptions?.onTiming === 'function')
        reportTiming(timingOptions, 'total', captureStarted);
    }
  }
  function raster(measured, options, serializer) {
    if (!measured || options.signal?.aborted) return Promise.resolve(null);
    let canvas;
    let context;
    let image;
    let source;
    let proofController;
    const nativeOptions = { ...options, ownerPath: measured.ownerPath };
    const serializeStarted = timingStart(options);
    try {
      canvas = measured.document.createElement('canvas');
      canvas.width = measured.pixelWidth;
      canvas.height = measured.pixelHeight;
      // This temporary atlas is read back for native ownership before use.
      // Keep the scene's drawing context separate from this CPU-read preference.
      context = canvas.getContext('2d', { willReadFrequently: true });
      source = context && serializer(measured, context);
      if (source) image = new measured.view.Image();
      if (source && measured.fieldOwners) proofController = new measured.view.AbortController();
    } catch {
      source = null;
    } finally {
      reportTiming(options, 'serialize', serializeStarted);
    }
    if (!source) {
      rejectNative(
        nativeOptions,
        context ? 'raster-serialization-failed' : 'native-canvas-unavailable',
        measured.owner.localName
      );
      if (canvas) {
        canvas.width = 0;
        canvas.height = 0;
      }
      return Promise.resolve(null);
    }
    return new Promise((resolve) => {
      let finished = false;
      let timeout;
      let painting = false;
      const decodeStarted = timingStart(options);
      let decodeReported = false;
      function finishDecode() {
        if (decodeReported) return;
        decodeReported = true;
        reportTiming(options, 'decode', decodeStarted);
      }
      function finish(success, code) {
        if (finished) return;
        finished = true;
        finishDecode();
        measured.view.clearTimeout(timeout);
        options.signal?.removeEventListener('abort', abort);
        image.onload = null;
        image.onerror = null;
        image.removeAttribute?.('src');
        if (!success) {
          rejectNative(nativeOptions, code || 'native-raster-failed', measured.owner.localName);
          // A failed field must cancel its pending isolated proof before the
          // caller can begin another capture against the same pixel capacity.
          proofController?.abort();
          canvas.width = 0;
          canvas.height = 0;
          resolve(null);
          return;
        }
        let disposed = false;
        resolve({
          canvas,
          owner: measured.owner,
          rect: measured.rect,
          envelope: measured.envelope,
          lines: measured.lines,
          dpr: measured.dpr,
          pixelCount: measured.pixelWidth * measured.pixelHeight,
          ownerPath: measured.ownerPath,
          ownerIndex: measured.ownerIndex,
          descendants: measured.descendants || 0,
          textBytes: measured.textBytes || measured.text.length * 3,
          textContent: measured.text,
          paintFingerprint: measured.paintFingerprint,
          controls: nativeControls(measured),
          decoration: !!measured.decoration,
          dispose() {
            if (disposed) return;
            disposed = true;
            canvas.width = 0;
            canvas.height = 0;
          },
        });
      }
      function abort() {
        finish(false, options.signal?.aborted ? 'capture-aborted' : 'raster-decode-failed');
      }
      async function paintReady() {
        // SVG decode can make the bitmap usable before its queued load event.
        // Both readiness paths share one draw/proof and the original deadline.
        if (finished || painting) return;
        painting = true;
        finishDecode();
        try {
          if (options.signal?.aborted) return abort();
          if (options.deadline !== undefined && options.clock() > options.deadline)
            return finish(false, 'preparation-deadline');
          if (!image.naturalWidth || !image.naturalHeight)
            return finish(false, 'native-raster-empty');
          const readbackStarted = timingStart(options);
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          if (measured.fieldOwners)
            return finish(
              await fieldHasNativeInk(context, measured, {
                ...options,
                signal: proofController.signal,
                readbackStarted,
              }),
              'native-raster-blank'
            );
          // A loaded image may silently omit foreignObject on an unsupported engine.
          const sample = context.getImageData(
            Math.floor(canvas.width / 2),
            Math.floor(canvas.height / 2),
            1,
            1
          );
          if (sample.data[3] > 0) return finish(true);
          // Headings and decoded cutouts may have a transparent center. Admit
          // their raster only after observing actual ink somewhere in its bound.
          const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
          finish(
            pixels.some((alpha, index) => index % 4 === 3 && alpha > 0),
            'native-raster-blank'
          );
        } catch {
          finish(false, 'native-raster-readback-failed');
        }
      }
      image.onload = paintReady;
      image.onerror = abort;
      options.signal?.addEventListener('abort', abort, { once: true });
      const timeoutMs =
        options.deadline === undefined
          ? settings.decodeTimeoutMs
          : Math.min(settings.decodeTimeoutMs, options.deadline - options.clock());
      if (timeoutMs <= 0) return finish(false, 'preparation-deadline');
      timeout = measured.view.setTimeout(() => finish(false, 'preparation-deadline'), timeoutMs);
      if (options.signal?.aborted) return abort();
      try {
        image.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(source);
        if (!finished && typeof image.decode === 'function') {
          // Engines that reject SVG decode may still support ordinary onload.
          // Rejection leaves that existing capability/deadline path in charge.
          try {
            Promise.resolve(image.decode()).then(paintReady, () => {});
          } catch {
            // Retain onload when this optional readiness API throws.
          }
        }
      } catch {
        abort();
      }
    });
  }
  return { capture, captureAll, captureField, matchesField, settings };
};
const embeddedScene=function (api, { fragmentPlan, embeddedPlan, embeddedTexture }) {
  const geometry = fragmentPlan({ cameraView: api.cameraView });
  const solids = embeddedPlan({
    cameraView: api.cameraView,
    depthVisibility: api.depthVisibility,
    loopTransform: api.loopTransform,
  });
  const textures = embeddedTexture();
  const statusOwner = document.getElementById?.('space-canvas')?.parentElement;
  const bank = new Map();
  const surfaces = new Map();
  const settings = Object.freeze({
    entries: 3,
    arrivalStart: 0.12,
    skippedHostSpan: 0.7,
    stagger: 0.2,
    handoffMs: 180,
    residentRevealMs: 420,
  });
  let generation = 0;
  let state = null;
  let incoming = null;
  let outgoing = null;
  let phase = null;
  let context = null;
  let travelProgress = 0;
  let progress = 0;
  let handoff = 0;
  let tailStarted = null;
  let pending = null;
  let pendingRoute = null;
  let queuedPrime = null;
  let hidden = [];
  let faces = [];
  let departureFaces = [];
  let paintedEntries = [];
  let lastFailure = null;
  let lastCaptureTimings = null;
  let publishedStatus = null;
  const clamp = (amount) => Math.max(0, Math.min(1, amount));
  const validRoute = (route) => api.routeOrder.includes(route);
  const caps = () => geometry.settings.caps[state?.compact ? 'compact' : 'full'];
  const rectangle = (rect) => ({
    x: rect.left,
    y: rect.top,
    width: rect.width,
    height: rect.height,
  });
  function reject(stage, route, detail) {
    if (lastFailure) return;
    const token = (value) =>
      typeof value === 'string' && /^[a-zA-Z0-9-]{1,64}$/.test(value) ? value : null;
    const report = typeof detail === 'string' ? { reason: detail } : detail || {};
    lastFailure = {
      stage,
      route: validRoute(route) ? route : null,
      reason: token(report.reason) || 'adapter-rejected',
    };
    for (const key of ['tag', 'limit', 'property']) {
      const value = token(report[key]);
      if (value) lastFailure[key] = value;
    }
    if (
      Array.isArray(report.path) &&
      report.path.length <= 32 &&
      report.path.every((index) => Number.isInteger(index) && index >= 0 && index <= 4096)
    )
      lastFailure.path = [...report.path];
  }
  function restore() {
    for (const { owner, visibility, opacity } of hidden) {
      if (visibility) owner.style.visibility = visibility;
      else owner.style.removeProperty('visibility');
      if (opacity) owner.style.opacity = opacity;
      else owner.style.removeProperty('opacity');
    }
    hidden = [];
    for (const entry of bank.values()) for (const group of entry.groups) group.native = null;
  }
  function dispose(entry) {
    if (!entry || entry.disposed) return;
    entry.disposed = true;
    for (const group of entry.groups) {
      group.asset.dispose();
      surfaces.delete(group.key);
    }
  }
  function releaseSession() {
    restore();
    phase = null;
    context = null;
    incoming = null;
    outgoing = null;
    travelProgress = 0;
    progress = 0;
    handoff = 0;
    tailStarted = null;
    faces = [];
    departureFaces = [];
    paintedEntries = [];
  }
  function cancel() {
    generation++;
    pending?.abort();
    pending = null;
    pendingRoute = null;
    queuedPrime = null;
    releaseSession();
  }
  function invalidate() {
    cancel();
    for (const entry of bank.values()) dispose(entry);
    bank.clear();
  }
  function usage(entry) {
    const result = Object.fromEntries(Object.keys(caps()).map((key) => [key, 0]));
    for (const { asset, model, sources } of entry?.groups || []) {
      result.pieces += model.shards.length;
      result.owners++;
      result.descendants += asset.descendants || 0;
      result.textBytes +=
        asset.textBytes ||
        sources.reduce((total, owner) => total + owner.textContent.length * 3, 0);
      result.layerPixels += asset.pixelCount;
    }
    return result;
  }
  function totalUsage(entries) {
    const total = Object.fromEntries(Object.keys(caps()).map((key) => [key, 0]));
    let count = 0;
    for (const entry of entries) {
      count++;
      const own = entry.paintedUsage || usage(entry);
      for (const key of Object.keys(total)) total[key] += own[key];
    }
    return count ? total : null;
  }
  function reservation() {
    return totalUsage(bank.values());
  }
  function resident(entry) {
    return !!entry && !entry.disposed && bank.get(entry.route) === entry;
  }
  function touch(entry) {
    bank.delete(entry.route);
    bank.set(entry.route, entry);
  }
  function remove(route) {
    const entry = bank.get(route);
    if (entry) {
      // An evicted field still owns pixels in the last Canvas paint. Preserve
      // only its diagnostic record, releasing its full model and bitmap now.
      paintedEntries = paintedEntries.map((painted) =>
        painted === entry
          ? {
              paintedBank: {
                route: entry.route,
                host: entry.host,
                groups: groupDiagnostics(entry),
              },
              paintedUsage: usage(entry),
            }
          : painted
      );
      dispose(entry);
    }
    bank.delete(route);
    if (incoming === entry) incoming = null;
    if (outgoing === entry) outgoing = null;
  }
  function makeRoom(route, protectedRoutes) {
    // A replacement temporarily shares capacity with its resident predecessor.
    // Failed acquisition must never erase an already painted native field.
    const protectedFields = new Set([
      route,
      document.body.dataset.page,
      ...(phase ? [incoming?.route, outgoing?.route] : []),
      ...protectedRoutes,
    ]);
    while (bank.size >= settings.entries) {
      const oldest = [...bank.keys()].find((name) => !protectedFields.has(name));
      if (!oldest) return false;
      remove(oldest);
    }
    return true;
  }
  function commit(entry) {
    const previous = bank.get(entry.route);
    const wasIncoming = incoming === previous;
    const wasOutgoing = outgoing === previous;
    // Surface keys are route-owned. Release old keys before installing their
    // replacement, and retain its last-painted diagnostic record until repaint.
    remove(entry.route);
    for (const group of entry.groups) {
      surfaces.set(group.key, group.asset.canvas);
      group.asset.owner = null;
    }
    bank.set(entry.route, entry);
    if (wasIncoming) incoming = entry;
    if (wasOutgoing) outgoing = entry;
  }
  function remainingBudget() {
    const retained = reservation() || {};
    return Object.fromEntries(
      Object.entries(caps()).map(([key, value]) => [key, Math.max(0, value - (retained[key] || 0))])
    );
  }
  function targetPose(route) {
    const pose = api.poses[api.initialPoses[route]];
    if (!pose) return null;
    return api.routePose
      ? api.routePose(route, pose)
      : {
          position: pose.position.map(
            (value, index) =>
              value + (index === 2 ? -api.roomSpacing * api.routeOrder.indexOf(route) : 0)
          ),
          target: pose.target.map(
            (value, index) =>
              value + (index === 2 ? -api.roomSpacing * api.routeOrder.indexOf(route) : 0)
          ),
        };
  }
  function hostFor(route) {
    return api.routeOrder[Math.max(0, api.routeOrder.indexOf(route) - 1)];
  }
  function branchSurface(branch, world, position) {
    if (!Number.isFinite(branch.radius) || branch.radius <= 0 || !branch.faceCount) return null;
    let best = null;
    for (const face of world.faces.slice(branch.firstFace, branch.firstFace + branch.faceCount)) {
      const points = face.points;
      if (
        face.object !== branch.name ||
        points.length < 3 ||
        !points.every(
          (point) => Array.isArray(point) && point.length === 3 && point.every(Number.isFinite)
        )
      )
        continue;
      const plane = api.facePlane(points).slice(0, 3);
      if (Math.hypot(...plane) < 1e-9) continue;
      let normal = api.normalize(plane);
      const center = points[0].map((_, axis) =>
        points.reduce((sum, point) => sum + point[axis] / points.length, 0)
      );
      const facing = api.dot(normal, api.normalize(api.sub(position, center)));
      if (best && facing <= best.facing) continue;
      let tangent = null;
      let longest = 0;
      for (let index = 0; index < points.length; index++) {
        const edge = api.sub(points[(index + 1) % points.length], points[index]);
        const alongNormal = api.dot(edge, normal);
        const projected = edge.map((value, axis) => value - normal[axis] * alongNormal);
        const length = Math.hypot(...projected);
        if (length > longest) {
          longest = length;
          tangent = projected;
        }
      }
      if (longest < 1e-9) continue;
      tangent = api.normalize(tangent);
      // The actual facet owns the orientation. Only its front/back choice
      // follows the host view; no camera-facing or seeded substitute plane.
      if (facing < 0) normal = normal.map((value) => -value);
      best = {
        points,
        facing,
        axes: [tangent, api.normalize(api.cross(normal, tangent)), normal],
      };
    }
    return best;
  }
  function branchMembers(host, cells, seed, root = null) {
    const world = api.worldForRoom?.(host);
    const objects = world?.objects || [];
    const position = api.poses[api.initialPoses[host]]?.position;
    if (!position || !world?.faces) return null;
    const candidates = objects.filter(
      (object) =>
        (object.depth === 1 || object.depth === 2) &&
        (root === null ? object.root <= 2 : object.root === root) &&
        object.points?.length &&
        object.faceCount
    );
    const pools = new Map();
    for (const branch of candidates) {
      const surface = branchSurface(branch, world, position);
      if (!surface) continue;
      const key = `${branch.depth}:${branch.root}`;
      if (!pools.has(key)) pools.set(key, { members: [], used: 0 });
      pools.get(key).members.push({ branch, surface });
    }
    const divisor = (a, b) => {
      while (b) [a, b] = [b, a % b];
      return a;
    };
    for (const pool of pools.values()) {
      let stride = Math.max(1, Math.floor(pool.members.length * 0.618));
      while (divisor(stride, pool.members.length) !== 1) stride++;
      pool.stride = stride;
    }
    const members = [];
    for (let index = 0; index < cells.length; index++) {
      // Repeated branches at three actual tunnel depths form the content
      // structure. Every fourth chip uses its actual larger parent level;
      // a coprime stride spreads each pool without duplicating attachments.
      const level = root === null ? index % 3 : root;
      const depth = index % 4 === 3 ? 1 : 2;
      const pool = pools.get(`${depth}:${level}`);
      if (!pool || pool.used >= pool.members.length) return null;
      const { branch, surface } =
        pool.members[
          (seed + level * 11 + depth * 17 + pool.used++ * pool.stride) % pool.members.length
        ];
      const attachment = surface.points[(seed + index * 11) % surface.points.length];
      members.push({
        name: branch.name,
        parent: branch.parent || null,
        center: [...branch.center],
        rootCenter: [...branch.rootCenter],
        root: branch.root,
        phase: branch.phase,
        attachment: [...attachment],
        radius: branch.radius,
        surfaceAxes: surface.axes.map((axis) => [...axis]),
      });
    }
    return members;
  }
  function sourceMetadata(asset) {
    return (
      asset.sourceOwners || [
        {
          ownerPath: asset.ownerPath || [],
          rect: asset.rect,
          lines: asset.lines || [],
          envelope: asset.envelope,
          textContent: asset.owner?.textContent || '',
        },
      ]
    ).map((owner) => ({
      ownerPath: [...owner.ownerPath],
      rect: { ...owner.rect },
      envelope: { ...owner.envelope },
      lines: owner.lines.map((line) => ({ ...line })),
      textContent: owner.textContent,
      paintFingerprint: owner.paintFingerprint,
      controls: (owner.controls || []).map((control) => ({
        ...control,
        ownerPath: [...control.ownerPath],
      })),
    }));
  }
  function build(assets, route, limits, stage) {
    const pose = targetPose(route);
    const host = hostFor(route);
    const maximum = Math.min(Math.floor(caps().pieces / settings.entries), limits.pieces);
    if (!assets?.length || !pose || assets.length > maximum) {
      reject(stage, route, 'capture-unavailable');
      return null;
    }
    const counts = assets.map(() => 1);
    for (let extra = maximum - assets.length; extra > 0; extra--) {
      const index = counts.reduce(
        (best, count, candidate) =>
          count < (solids.settings?.maxPieces || 32) && count < counts[best] ? candidate : best,
        0
      );
      if (counts[index] >= (solids.settings?.maxPieces || 32)) break;
      counts[index]++;
    }
    const groups = [];
    for (const [index, asset] of assets.entries()) {
      const rect = rectangle(asset.envelope);
      const cells = geometry.partition(
        rect,
        { count: counts[index], seed: 49 + index * 997 },
        { maxPieces: counts[index] }
      );
      const members = branchMembers(host, cells, index * 19 + api.routeOrder.indexOf(route) * 37);
      if (!members) {
        reject(stage, route, 'world-membership-unavailable');
        return null;
      }
      const key = `${route}:${textures.captureField ? 'field' : asset.ownerPath?.join('.') || index}`;
      const model = solids.prepare({
        id: key,
        rect,
        cells,
        pose,
        width: state.width,
        height: state.height,
        members,
        returnMembers:
          host !== route
            ? branchMembers(route, cells, index * 19 + api.routeOrder.indexOf(route) * 37, 3)
            : null,
        returnOffset: api.roomOffset
          ? api.roomOffset(route)
          : -api.roomSpacing * api.routeOrder.indexOf(route),
        hostOffset: api.roomOffset
          ? api.roomOffset(host)
          : -api.roomSpacing * api.routeOrder.indexOf(host),
      });
      if (!model) {
        reject(stage, route, 'model-geometry');
        return null;
      }
      groups.push({ key, asset, model, cells, sources: sourceMetadata(asset), native: null });
    }
    const entry = { route, host, groups, pose, disposed: false, landingKey: null };
    const allocated = usage(entry);
    if (!geometry.admit(allocated, limits)) {
      reject(stage, route, {
        reason: 'model-capacity',
        limit: Object.keys(limits).find((key) => allocated[key] > limits[key]),
      });
      return null;
    }
    return entry;
  }
  const landingKey = (landing) =>
    JSON.stringify([landing?.position || [0, 0], landing?.hash || '', landing?.search || '']);
  const nativeLandingKey = () =>
    landingKey({
      position: [window.scrollX || 0, window.scrollY || 0],
      search: window.location?.search || '',
      hash: window.location?.hash || '',
    });
  function scrollInset(node, property) {
    const value = window.getComputedStyle?.(node)?.getPropertyValue(property) || '0px';
    if (value === 'auto') return 0;
    if (!/^-?(?:\d+\.?\d*|\.\d+)px$/.test(value)) return null;
    const amount = Number.parseFloat(value);
    return Number.isFinite(amount) ? amount : null;
  }
  function place(stage, top, landing) {
    const extent = Math.max(stage.getBoundingClientRect().height, stage.scrollHeight || 0);
    const maximum = Math.max(0, top + extent - state.height);
    let scroll = Array.isArray(landing?.position) ? landing.position[1] : 0;
    if (landing?.position === 'end') scroll = maximum;
    else if (!landing?.position && landing?.hash) {
      let id;
      try {
        id = decodeURIComponent(landing.hash.slice(1));
      } catch {
        return false;
      }
      const target = [...stage.querySelectorAll('[id]')].find((node) => node.id === id);
      if (!target) return false;
      const padding = scrollInset(document.documentElement, 'scroll-padding-top');
      const margin = scrollInset(target, 'scroll-margin-top');
      if (padding === null || margin === null) return false;
      scroll = Math.min(
        maximum,
        Math.max(0, target.getBoundingClientRect().top - padding - margin)
      );
    }
    if (!Number.isFinite(scroll) || scroll < 0) return false;
    scroll = Math.min(maximum, scroll);
    stage.style.setProperty('--embedded-stage-top', top - scroll + 'px');
    return true;
  }
  function captureOptions(controller, limits, stage, route, own) {
    const timings = { stage, route };
    lastCaptureTimings = timings;
    return {
      width: state.width,
      height: state.height,
      dpr: state.compact ? 1 : Math.min(1.5, window.devicePixelRatio || 1),
      signal: controller.signal,
      caps: limits,
      preparationMs: geometry.settings.preparationMs,
      acquisitionMs: geometry.settings.acquisitionMs,
      onTiming(detail) {
        if (
          own !== generation ||
          timings !== lastCaptureTimings ||
          pending !== controller ||
          controller.signal.aborted ||
          !['measure', 'serialize', 'decode', 'readback', 'proof', 'total'].includes(
            detail?.stage
          ) ||
          !Number.isFinite(detail.milliseconds) ||
          detail.milliseconds < 0
        )
          return;
        const key = detail.stage + 'Ms';
        const amount =
          detail.stage === 'total'
            ? detail.milliseconds
            : (timings[key] || 0) + detail.milliseconds;
        if (!Number.isFinite(amount)) return;
        timings[key] = amount;
        if (Number.isInteger(detail.owners) && detail.owners >= 0 && detail.owners <= caps().owners)
          timings[detail.stage + 'Owners'] = detail.owners;
      },
      onReject(detail) {
        if (own === generation) reject(stage, route, detail);
      },
    };
  }
  async function acquire(root, options) {
    if (textures.captureField) {
      const asset = await textures.captureField(root, options);
      return asset ? [asset] : null;
    }
    if (textures.captureAll) return textures.captureAll(root, options);
    const asset = await textures.capture(root, options);
    return asset ? [asset] : null;
  }
  async function prime(data, top, landing = null, options = {}) {
    const from = document.body.dataset.page;
    const residentOnly = options.residentOnly === true;
    const neighbor = api.routeOrder[api.routeOrder.indexOf(from) + 1];
    if (
      !validRoute(from) ||
      !validRoute(data.page) ||
      from === data.page ||
      options.signal?.aborted ||
      (residentOnly && data.page !== neighbor) ||
      (phase && (!residentOnly || !canPrepareNeighbor(data.page)))
    )
      return false;
    if (
      !state ||
      state.width !== (window.innerWidth || state.width) ||
      state.height !== (window.innerHeight || state.height)
    ) {
      queuedPrime = { data, top, landing, options };
      return false;
    }
    const key = landingKey(landing);
    const cached = bank.get(data.page);
    // A returned field must keep its actual captured scroll/content. Only real
    // navigation may replace it to satisfy a different destination landing.
    if (cached && (options.reuseResident || cached.landingKey === key)) {
      if (!residentOnly) incoming = cached;
      touch(cached);
      return true;
    }
    if (pending || !window.SiteScene?.canTravel() || options.signal?.aborted) return false;
    // Speculative work during a flight may use its empty third slot, but cannot
    // evict source, destination or an intermediate corridor's painted field.
    if (!makeRoom(data.page, phase ? [...bank.keys()] : [from])) return false;
    const own = ++generation;
    lastFailure = null;
    const controller = new AbortController();
    const abort = () => controller.abort();
    options.signal?.addEventListener('abort', abort, { once: true });
    pending = controller;
    pendingRoute = data.page;
    const stage = document.createElement('div');
    stage.className = 'embedded-stage';
    stage.inert = true;
    stage.setAttribute('aria-hidden', 'true');
    stage.setAttribute('data-embedded-route', data.page);
    stage.style.setProperty('--embedded-stage-width', document.documentElement.clientWidth + 'px');
    stage.style.setProperty('--embedded-stage-top', top + 'px');
    stage.append(document.importNode(data.main, true));
    if (data.footer) stage.append(document.importNode(data.footer, true));
    document.body.append(stage);
    let assets = null;
    try {
      window.SiteArchive?.preparePreview?.(stage, {
        search: landing?.search || '',
        hash: landing?.hash || '',
      });
      window.SiteEffects.preparePreview?.(stage, data.page);
      if (!place(stage, top, landing)) {
        reject('incoming', data.page, 'landing-unavailable');
        return false;
      }
      const limits = remainingBudget();
      assets = await acquire(stage, captureOptions(controller, limits, 'incoming', data.page, own));
      if (own !== generation || controller.signal.aborted || document.body.dataset.page !== from)
        return false;
      const entry = build(assets, data.page, limits, 'incoming');
      if (!entry) return false;
      entry.landingKey = key;
      entry.residentReveal = options.revealResident && !cached ? { startedAt: null } : null;
      entry.residentVisibility = entry.residentReveal ? 0 : 1;
      commit(entry);
      if (!residentOnly) incoming = entry;
      assets = null;
      return true;
    } catch {
      if (own === generation) reject('incoming', data.page, 'capture-exception');
      return false;
    } finally {
      for (const asset of assets || []) asset.dispose();
      stage.remove();
      options.signal?.removeEventListener('abort', abort);
      if (own === generation) {
        pending = null;
        pendingRoute = null;
      }
    }
  }
  function resolve(content, path) {
    let owner = content;
    for (const index of path) owner = owner?.children?.[index];
    return owner || null;
  }
  const sameRect = (rect, original) =>
    ['left', 'top', 'width', 'height'].every((key) => Math.abs(rect[key] - original[key]) <= 0.75);
  function matching(entry, content) {
    if (!content) return false;
    const managed = hidden.find(({ owner }) => owner === content);
    const current = managed && {
      visibility: content.style.visibility,
      opacity: content.style.opacity,
    };
    function appearance(snapshot) {
      for (const key of ['visibility', 'opacity']) {
        if (snapshot[key]) content.style[key] = snapshot[key];
        else content.style.removeProperty(key);
      }
    }
    // The native oracle sees ordinary layout during this synchronous read.
    // A lifecycle-owned crossfade must not invalidate its own captured paint.
    if (managed) appearance(managed);
    try {
      if (typeof textures.matchesField === 'function') {
        // The complete native oracle already proves source text, geometry,
        // wrapping, controls and paint. A second per-owner pass repeats layout
        // reads without adding coverage; older adapters retain the narrow path.
        return entry.groups.every((group) =>
          textures.matchesField(content, group.sources, {
            width: state.width,
            height: state.height,
            dpr: state.compact ? 1 : Math.min(1.5, window.devicePixelRatio || 1),
            caps: caps(),
            acquisitionMs: geometry.settings.acquisitionMs,
            decorations: group.asset.decorations,
          })
        );
      }
      return entry.groups.every((group) =>
        group.sources.every((source) => {
          const owner = resolve(content, source.ownerPath);
          return (
            owner &&
            owner.textContent === source.textContent &&
            sameRect(owner.getBoundingClientRect(), source.rect) &&
            source.controls.every((control) => {
              const node = resolve(content, control.ownerPath);
              return (
                node &&
                node.selectedIndex === control.selectedIndex &&
                (!control.text || node.selectedOptions?.[0]?.textContent === control.text)
              );
            })
          );
        })
      );
    } finally {
      if (current) appearance(current);
    }
  }
  async function prepareDeparture(content, options = {}) {
    const route = document.body.dataset.page;
    // A failed revalidation may retain old pixels, but cannot authorize hiding
    // changed native content for a new departure.
    if (!options.cacheOnly) outgoing = null;
    if (!resident(incoming) || phase || pending || options.signal?.aborted) {
      reject('departure', route, 'source-not-ready');
      return false;
    }
    if (
      (content.style?.transform && content.style.transform !== 'none') ||
      (content.style?.opacity && Number(content.style.opacity) !== 1)
    ) {
      reject('departure', route, 'source-plane-interrupted');
      return false;
    }
    const cached = bank.get(route);
    const nativeLanding = nativeLandingKey();
    const sourceViewport = { width: state.width, height: state.height };
    // A changed viewport cannot match its previous native atlas. Skip that
    // guaranteed-failing style/layout scan, then capture under the same limits.
    if (cached?.landingKey === nativeLanding && matching(cached, content)) {
      if (!options.cacheOnly) {
        outgoing = cached;
        for (const group of cached.groups) group.native = content;
      }
      touch(cached);
      return true;
    }
    if (!makeRoom(route, [incoming.route])) return false;
    const own = generation;
    lastFailure = null;
    const controller = new AbortController();
    const abort = () => controller.abort();
    options.signal?.addEventListener('abort', abort, { once: true });
    pending = controller;
    let assets = null;
    try {
      const limits = remainingBudget();
      assets = await acquire(content, captureOptions(controller, limits, 'departure', route, own));
      if (own !== generation || controller.signal.aborted) return false;
      if (
        document.body.dataset.page !== route ||
        state.width !== sourceViewport.width ||
        state.height !== sourceViewport.height ||
        (window.innerWidth || state.width) !== sourceViewport.width ||
        (window.innerHeight || state.height) !== sourceViewport.height ||
        nativeLandingKey() !== nativeLanding
      ) {
        reject('departure', route, 'source-landing-changed');
        return false;
      }
      const entry = build(assets, route, limits, 'departure');
      if (!entry) return false;
      entry.landingKey = nativeLanding;
      commit(entry);
      if (!options.cacheOnly) {
        for (const group of entry.groups) group.native = content;
        outgoing = entry;
      }
      assets = null;
      return true;
    } catch {
      if (own === generation) reject('departure', route, 'capture-exception');
      return false;
    } finally {
      for (const asset of assets || []) asset.dispose();
      options.signal?.removeEventListener('abort', abort);
      if (own === generation) pending = null;
    }
  }
  function hide(owner) {
    hidden.push({ owner, visibility: owner.style.visibility, opacity: owner.style.opacity });
    owner.style.visibility = 'hidden';
  }
  function begin(next) {
    if (
      pending ||
      !resident(incoming) ||
      !resident(outgoing) ||
      incoming.route !== next.to ||
      outgoing.route !== next.from ||
      next.from === next.to ||
      incoming.landingKey !== landingKey(next.landing)
    ) {
      reject('begin', next.to, 'paired-session-unavailable');
      cancel();
      return false;
    }
    context = next;
    phase = 'departing';
    travelProgress = 0;
    progress = 0;
    handoff = 0;
    tailStarted = null;
    for (const entry of [incoming, outgoing]) {
      entry.residentReveal = null;
      entry.residentVisibility = 1;
    }
    hide(outgoing.groups[0].native);
    return true;
  }
  function land(content) {
    if (phase !== 'departing') return;
    restore();
    if (!matching(incoming, content)) {
      reject('landing', incoming.route, 'native-geometry-mismatch');
      cancel();
      return;
    }
    for (const group of incoming.groups) group.native = content;
    hide(content);
    phase = 'assembling';
  }
  function present(amount) {
    if (phase && Number.isFinite(amount)) travelProgress = clamp(amount);
  }
  function groupDiagnostics(entry) {
    return (entry?.groups || []).map(({ key, asset, model, cells, sources }) => ({
      key,
      route: entry.route,
      host: entry.host,
      ownerPath: [],
      sourceOwners: sources,
      rect: asset.rect,
      lines: asset.lines || [],
      envelope: asset.envelope,
      ids: model.shards.map(({ id }) => id),
      pieces: model.shards.length,
      pixels: asset.pixelCount,
      descendants: asset.descendants || 0,
      textBytes: asset.textBytes || 0,
      members: model.shards.map((shard) => ({
        id: shard.id,
        name: shard.member?.name,
        parent: shard.member?.parent,
        root: shard.member?.root,
        rootCenter: shard.member?.rootCenter,
        attachment: shard.member?.attachment,
        radius: shard.member?.radius,
        surfaceAxes: shard.member?.surfaceAxes,
        hostOffset: shard.hostOffset,
        worldCenter: shard.member
          ? api
              .loopTransform(
                shard.member,
                state?.ambientTime || 0
              )(shard.restCenter)
              .map((value, index) => value + (index === 2 ? shard.hostOffset : 0))
          : shard.restCenter,
      })),
      topology: {
        closed: true,
        fronts: cells.length,
        rears: cells.length,
        sides: cells.reduce((sum, cell) => sum + cell.polygon.length, 0),
      },
    }));
  }
  const faceDiagnostics = (items) =>
    items.map(({ id, face, points, alpha, textureMix, progress: amount }) => ({
      id,
      face,
      points,
      alpha,
      textureMix,
      progress: amount,
    }));
  function refresh() {
    invalidate();
    if (window.CustomEvent)
      window.dispatchEvent(new window.CustomEvent('site:embedded-invalidated'));
  }
  function canPrepareNeighbor(route) {
    const native = document.body.dataset.page;
    const neighbor = api.routeOrder[api.routeOrder.indexOf(native) + 1];
    return (
      !!phase &&
      native === context?.to &&
      validRoute(neighbor) &&
      (route === undefined || route === neighbor) &&
      bank.size < settings.entries &&
      !pending &&
      window.SiteScene?.canTravel() === true
    );
  }
  const bridge = {
    prime,
    prepareDeparture,
    begin,
    land,
    present,
    cancel,
    invalidate,
    refresh,
    canPrepareNeighbor,
    active: () => phase !== null,
    nativeOpacity: () => (phase === 'assembling' ? handoff : 1),
    owner: () => hidden[0]?.owner || null,
    owners: () => hidden.map(({ owner }) => owner),
    complete() {
      if (!phase) return true;
      if (phase !== 'assembling' || travelProgress < 1 || handoff < 1) return false;
      const arrival = incoming;
      // A separately owned successor capture may outlast the native handoff.
      // Finishing this session must not abort or invalidate that bounded task.
      releaseSession();
      incoming = arrival;
      touch(arrival);
      const crossed = bank.get(arrival.host);
      if (crossed && crossed !== arrival) touch(crossed);
      return true;
    },
    reservation,
    diagnostics: () => ({
      ready: !!incoming,
      pendingRoute,
      lastFailure,
      captureTimings: lastCaptureTimings && { ...lastCaptureTimings },
      route: incoming?.route || null,
      phase,
      progress,
      physicalProgress: faces
        .filter((face) => face.ownerKey === incoming?.groups[0]?.key && face.face === 'front')
        .reduce((maximum, face) => Math.max(maximum, face.progress), 0),
      travelProgress,
      arrivalStart: arrivalStart(),
      handoff,
      clock: state?.ambientTime || 0,
      // These faces describe the last Canvas paint. An asynchronous acquisition
      // may already have evicted a bitmap; its painted ownership remains until
      // the existing scene clock replaces those pixels. Admission stays live.
      texturePixels: totalUsage(faces.length ? paintedEntries : bank.values())?.layerPixels || 0,
      residentUsage: reservation(),
      residentRoutes: [...bank.keys()],
      residentRevealMs: settings.residentRevealMs,
      residentReveals: [...bank.values()].map((entry) => ({
        route: entry.route,
        progress: entry.residentVisibility ?? 1,
      })),
      nativeRect: incoming?.groups[0]?.asset.rect || null,
      nativeLines: incoming?.groups[0]?.asset.lines || [],
      envelope: incoming?.groups[0]?.asset.envelope || null,
      ids: incoming?.groups.flatMap(({ model }) => model.shards.map(({ id }) => id)) || [],
      groups: groupDiagnostics(incoming),
      bank: (faces.length ? paintedEntries : [...bank.values()]).map(
        (entry) =>
          entry.paintedBank || {
            route: entry.route,
            host: entry.host,
            groups: groupDiagnostics(entry),
          }
      ),
      coverage: {
        expected: incoming?.groups.reduce((sum, group) => sum + group.sources.length, 0) || 0,
        selected: incoming?.groups.reduce((sum, group) => sum + group.sources.length, 0) || 0,
        complete: !!incoming,
      },
      caps: caps(),
      faces: faceDiagnostics(faces),
      departure: {
        ready: !!outgoing,
        progress: travelProgress,
        groups: groupDiagnostics(outgoing),
        faces: faceDiagnostics(departureFaces),
      },
    }),
  };
  window.SiteEffects.embedded = bridge;
  for (const name of ['resize', 'beforeprint', 'pagehide'])
    window.addEventListener(name, invalidate);
  window.addEventListener(
    'scroll',
    () => {
      if (phase === 'assembling' && incoming && !matching(incoming, hidden[0]?.owner)) cancel();
    },
    { passive: true }
  );
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) invalidate();
    else refresh();
  });
  window.addEventListener('afterprint', refresh);
  window
    .matchMedia?.('(prefers-reduced-transparency: reduce)')
    .addEventListener?.('change', refresh);
  document.fonts?.addEventListener?.('loadingdone', refresh);
  window.addEventListener('site:motion-preference', () => {
    if (!window.SiteScene?.canTravel()) invalidate();
    else refresh();
  });
  new window.MutationObserver(refresh).observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['data-theme'],
  });
  function arrivalAmount() {
    const start = arrivalStart();
    return clamp((travelProgress - start) / (1 - start));
  }
  function arrivalStart() {
    if (!context || !incoming) return settings.arrivalStart;
    const from = api.routeOrder.indexOf(context.from);
    const to = api.routeOrder.indexOf(context.to);
    const host = api.routeOrder.indexOf(incoming.host);
    const hostFraction = to > from ? clamp((host - from) / (to - from)) : 0;
    // Start before the camera crosses the field's last host. A skipped room
    // remains in its own world instead of following the departing camera.
    return settings.arrivalStart + settings.skippedHostSpan * hostFraction;
  }
  function sample(entry, frame, amount) {
    const produced = [];
    for (const group of entry.groups) {
      const progresses = group.model.shards.map((_, index) => {
        if (amount <= 0 || amount >= 1) return amount;
        const delay = (settings.stagger * index) / Math.max(1, group.model.shards.length - 1);
        return clamp((amount - delay) / (1 - delay));
      });
      const shapes = solids.sample(group.model, {
        pose: frame.current,
        width: frame.width,
        height: frame.height,
        progress: amount,
        progresses,
        time: frame.ambientTime,
        clearance: phase && (entry === incoming || entry === outgoing),
        returnPath:
          phase &&
          entry === incoming &&
          context?.direction === 'backward' &&
          entry.host !== entry.route,
        forwardPath: phase && entry === incoming && context?.direction === 'forward',
        departing: phase && entry === outgoing && context?.direction === 'forward',
      });
      for (const shape of shapes) {
        shape.ownerKey = group.key;
        produced.push(shape);
      }
    }
    return produced;
  }
  function advanceHandoff(frame) {
    if (phase !== 'assembling' || travelProgress !== 1 || !incoming) return;
    const aligned =
      incoming.pose.position.every((value, index) => value === frame.current.position[index]) &&
      incoming.pose.target.every((value, index) => value === frame.current.target[index]);
    if (!aligned) return;
    if (tailStarted === null) tailStarted = frame.ambientTime;
    handoff = clamp(
      ((frame.ambientTime - tailStarted + api.LOOP_MS) % api.LOOP_MS) / settings.handoffMs
    );
    for (const entry of hidden) {
      entry.owner.style.visibility = handoff > 0 ? entry.visibility || 'visible' : 'hidden';
      entry.owner.style.opacity = String(handoff);
    }
  }
  function residentVisibility(entry, frame) {
    if (!entry.residentReveal) return 1;
    const reveal = entry.residentReveal;
    if (reveal.startedAt === null) reveal.startedAt = frame.ambientTime;
    const elapsed = (frame.ambientTime - reveal.startedAt + api.LOOP_MS) % api.LOOP_MS;
    const amount = clamp(elapsed / settings.residentRevealMs);
    if (amount === 1) entry.residentReveal = null;
    return amount * amount * (3 - 2 * amount);
  }
  function applyFieldVisibility(entry, shapes) {
    if (entry.residentVisibility < 1)
      for (const shape of shapes) shape.alpha *= entry.residentVisibility;
    if (phase && entry === incoming && handoff > 0)
      for (const shape of shapes) shape.alpha *= 1 - handoff;
    else if (phase === 'assembling' && entry !== incoming && entry.host !== context.to)
      for (const shape of shapes) shape.alpha *= 1 - handoff;
  }
  function publishStatus() {
    if (!statusOwner?.dataset) return;
    const routes = [...bank.keys()].join(' ');
    const failure = lastFailure || {};
    const signature = [
      routes,
      phase,
      pendingRoute,
      failure.stage,
      failure.route,
      failure.reason,
      failure.tag,
      failure.limit,
    ].join('|');
    if (signature === publishedStatus) return;
    publishedStatus = signature;
    const values = {
      embeddedBank: routes,
      embeddedPhase: phase || 'idle',
      embeddedPending: pendingRoute,
      embeddedFailureStage: failure.stage,
      embeddedFailureRoute: failure.route,
      embeddedFailureReason: failure.reason,
      embeddedFailureTag: failure.tag,
      embeddedFailureLimit: failure.limit,
    };
    for (const [key, value] of Object.entries(values)) {
      if (value) statusOwner.dataset[key] = value;
      else delete statusOwner.dataset[key];
    }
  }
  return {
    preparing: () => !!pending && !phase,
    collect(frame) {
      state = frame;
      if (queuedPrime) {
        const queued = queuedPrime;
        queuedPrime = null;
        Promise.resolve().then(() =>
          prime(queued.data, queued.top, queued.landing, queued.options)
        );
      }
      faces = [];
      departureFaces = [];
      paintedEntries = [...bank.values()];
      if (phase) {
        travelProgress = frame.journey
          ? frame.journey.progressStart + (1 - frame.journey.progressStart) * clamp(frame.journey.elapsed / frame.journey.duration)
          : 1;
        progress = arrivalAmount();
      }
      advanceHandoff(frame);
      const native = document.body.dataset.page;
      for (const entry of paintedEntries) {
        // Settled chips belong to the fractal room that is actually painted.
        // Retention still serves reverse flights without painting a distant
        // page field over a host that is absent from the current reading room.
        if (!phase && entry.host !== frame.page) continue;
        let amount = 0;
        if (phase && entry === incoming) amount = progress;
        else if (phase && entry === outgoing) amount = 1 - travelProgress;
        else if (entry.route === native) continue;
        const shapes = sample(entry, frame, amount);
        entry.residentVisibility = residentVisibility(entry, frame);
        applyFieldVisibility(entry, shapes);
        if (phase && entry === outgoing) departureFaces = shapes;
        faces.push(...shapes);
      }
      publishStatus();
      return faces;
    },
    paint: (ctx, shape) => solids.paint(ctx, shape, surfaces.get(shape.ownerKey), state?.colors),
  };
};
window.SiteEffects.scene=(api)=>embeddedScene(api,{fragmentPlan,embeddedPlan,embeddedTexture});
window.SiteEffects.registerView=(view)=>{window.SiteEffects.cameraView=view;};
window.SiteEffects.navigation=function createPresentation(content) {
  let contentFlight = true,
    fragmentPreview = true,
    useSolids = false,
    journeyDirection = 'forward';
  try {
    contentFlight = localStorage.getItem('vo.content-flight') !== 'off';
    fragmentPreview = localStorage.getItem('vo.fragment-preview') !== 'off';
  } catch {
    /* In-tab preference is sufficient. */
  }
  function setPlane(pose) {
    if (content.dataset.flightStage !== pose.stage) {
      const top = window.SiteEffects?.nativePlaneTop;
      content.style.transformOrigin =
        '50% ' +
        (window.scrollY +
          window.innerHeight * 0.5 -
          (typeof top === 'number' ? top : content.offsetTop)) +
        'px';
    }
    content.dataset.flightStage = pose.stage;
    content.dataset.flightDepth = String(pose.z);
    content.dataset.flightMode = 'fade';
    content.style.opacity = String(pose.opacity);
    if (contentFlight) content.style.transform = 'perspective(1200px) translateZ(' + pose.z + 'px)';
    else content.style.removeProperty('transform');
  }
  function nativeSolidPlane() {
    content.dataset.flightMode = 'solids';
    content.style.opacity = String(window.SiteEffects.embedded?.nativeOpacity?.() ?? 1);
    content.style.transform = 'none';
  }
  return {
    mountAt: 0.5,
    layoutStableDuringTravel: true,
    mount() {
      const frame = document.createElement('div');
      frame.id = 'site-content-frame';
      content.before(frame);
      frame.append(content);
    },
    canTravel: () => window.CSS?.supports?.('overflow', 'clip') === true,
    clear() {
      const embedded = window.SiteEffects.embedded;
      // A completed handoff already released native ownership. Ordinary text
      // cleanup must not cancel its separately signalled successor warm-up.
      if (embedded?.active?.() !== false) embedded?.cancel();
      useSolids = false;
      content.style.removeProperty('transform-origin');
      delete content.dataset.flightStage;
      delete content.dataset.flightDepth;
      delete content.dataset.flightMode;
    },
    departure: () => ({
      opacity: Number(content.style.opacity || 1),
      z: Number(content.dataset.flightDepth || 0),
    }),
    restoreDeparture(departure) {
      if (departure.z || departure.opacity < 1) setPlane({ stage: 'depart', ...departure });
      content.style.opacity = String(departure.opacity);
      content.inert = departure.opacity < 1;
    },
    prepareMount() {
      content.style.transform = 'none';
      content.style.opacity = '0';
      content.style.removeProperty('transform-origin');
      delete content.dataset.flightStage;
    },
    begin(animate, context = {}) {
      journeyDirection = context?.direction || 'forward';
      const enabled = animate && contentFlight && fragmentPreview;
      useSolids =
        enabled &&
        window.SiteEffects.embedded?.begin({ ...context, direction: journeyDirection }) === true;
      if (!enabled) window.SiteEffects.embedded?.invalidate();
      // Only a fully admitted world session owns native paint. A failed or
      // unsupported capture uses the existing plane fade, with no DOM shards
      // or second capture attempt while the camera is travelling.
      if (useSolids) nativeSolidPlane();
      else content.dataset.flightMode = 'fade';
    },
    mounted() {
      if (!useSolids) return;
      window.SiteEffects.embedded?.land(content);
      if (window.SiteEffects.embedded?.active?.() !== false) {
        nativeSolidPlane();
        return;
      }
      useSolids = false;
      content.dataset.flightMode = 'fade';
    },
    present(progress, direction, departure, snapshot) {
      const painted = snapshot && { ...snapshot, direction: journeyDirection };
      window.SiteEffects.embedded?.present?.(progress, painted);
      const lastPose = flightPose(progress, journeyDirection, departure);
      if (snapshot?.active === false) {
        window.SiteEffects.embedded?.invalidate();
        useSolids = false;
      }
      if (useSolids && window.SiteEffects.embedded?.active?.() === false) useSolids = false;
      if (useSolids) {
        nativeSolidPlane();
        if (progress === 1) return window.SiteEffects.embedded?.complete() !== false;
        return;
      }
      setPlane(lastPose);
    },
    contentFlight(value) {
      if (typeof value === 'boolean') {
        contentFlight = value;
        if (!value) {
          window.SiteEffects.embedded?.invalidate();
          useSolids = false;
        } else window.SiteEffects.embedded?.refresh();
        if (content.dataset.flightStage)
          setPlane({
            stage: content.dataset.flightStage,
            z: Number(content.dataset.flightDepth || 0),
            opacity: Number(content.style.opacity || 1),
          });
      }
      return contentFlight;
    },
    fragmentPreview(value) {
      if (typeof value === 'boolean') {
        fragmentPreview = value;
        if (!value) {
          window.SiteEffects.embedded?.invalidate();
          useSolids = false;
        } else window.SiteEffects.embedded?.refresh();
        try {
          localStorage.setItem('vo.fragment-preview', value ? 'on' : 'off');
        } catch {
          /* In-tab preference is sufficient. */
        }
      }
      return fragmentPreview;
    },
    canPrepareNext: () => contentFlight && fragmentPreview,
    canPrepareNeighbor: (route) =>
      contentFlight &&
      fragmentPreview &&
      useSolids &&
      window.SiteEffects.embedded?.canPrepareNeighbor?.(route) === true,
    async prepareTransition(data, context, signal) {
      if (!contentFlight || !fragmentPreview) return;
      const embedded = window.SiteEffects.embedded;
      if (!embedded) return;
      try {
        for (const neighbor of context.corridor || []) {
          await embedded.prime(neighbor, content.offsetTop, null, { signal });
          if (signal?.aborted) return;
        }
        const ready = await embedded.prime(data, content.offsetTop, context.landing, { signal });
        // A missing destination cannot admit the pair. Avoid decoding a source
        // that the settled native fade will never consume.
        if (!ready || signal?.aborted) return;
        await embedded.prepareDeparture?.(content, { signal });
      } catch {
        embedded.invalidate();
      }
    },
    async prepareNext(data, signal) {
      if (!contentFlight || !fragmentPreview) return;
      const embedded = window.SiteEffects.embedded;
      const residentOnly = embedded?.active?.() === true;
      if (residentOnly && embedded.canPrepareNeighbor?.(data.page) !== true) return;
      // First-load capture must not compete with the initial layout and scene
      // build. This is one cancellable idle task, not another animation clock;
      // the adapter still owns its unchanged acquisition/decode deadlines.
      if (!residentOnly) {
        await new Promise((resolve) => {
          let ticket;
          const idle = typeof window.requestIdleCallback === 'function';
          const finish = () => {
            if (idle) window.cancelIdleCallback?.(ticket);
            else window.clearTimeout(ticket);
            signal?.removeEventListener('abort', finish);
            resolve();
          };
          ticket = idle
            ? window.requestIdleCallback(finish, { timeout: 500 })
            : window.setTimeout(finish, 500);
          signal?.addEventListener('abort', finish, { once: true });
          if (signal?.aborted) finish();
        });
      }
      if (signal?.aborted || !contentFlight || !fragmentPreview) return;
      if (
        await embedded?.prime(data, content.offsetTop, null, {
          signal,
          reuseResident: true,
          residentOnly,
          revealResident: true,
        })
      ) {
        if (!signal?.aborted && !residentOnly && embedded.active?.() !== true)
          await embedded.prepareDeparture?.(content, { signal, cacheOnly: true });
      }
    },
  };
};
window.SiteEffects.measure=function measurePlane(read) {
  const plane = document.getElementById('site-content'),
    transform = plane?.style.transform;
  if (transform) plane.style.transform = 'none';
  try {
    const result = read();
    // Reuse the same native layout snapshot when presentation resumes. Reading
    // offsetTop after mount restores root styles would force a second flush.
    if (plane) window.SiteEffects.nativePlaneTop = plane.offsetTop;
    return result;
  } finally {
    if (transform) plane.style.transform = transform;
  }
};
})();
/* Generated from site/engine and site/scenes by tools/site/build.cjs. */
(()=>{
"use strict";
const math=(function () {
  const add = (a, b) => a.map((v, i) => v + b[i]);
  const sub = (a, b) => a.map((v, i) => v - b[i]);
  const dot = (a, b) => a.reduce((n, v, i) => n + v * b[i], 0);
  const cross = (a, b) => [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
  const normalize = (a) => {
    const n = Math.hypot(...a);
    return n > 1e-9 ? a.map((v) => v / n) : [0, 0, 1];
  };
  const lerp = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
  const mix = (a, b, t) => ({
    position: lerp(a.position, b.position, t),
    target: lerp(a.target, b.target, t),
  });
  const clamp = (v) => Math.max(0, Math.min(1, v));
  const spline = (a, b, c, d, t) =>
    b.map(
      (v, i) =>
        0.5 *
        (2 * v +
          (-a[i] + c[i]) * t +
          (2 * a[i] - 5 * v + 4 * c[i] - d[i]) * t * t +
          (-a[i] + 3 * v - 3 * c[i] + d[i]) * t * t * t)
    );
  const LOOP_MS = 24000;
  const rates = [30, 20, 15, 12, 10, 7.5];
  const owns = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
  const smooth = (v) => {
    const t = clamp(v);
    return t * t * (3 - 2 * t);
  };
  // Atmospheric perspective: a continuous loss of contrast into the page's
  // background, shared by surfaces, seams and outlines; no per-face blur/filter.
  // Exactly the accepted reference slider at 70: blend visibility curves,
  // not uniform opacity and not a second fog pass.
  const depthVisibility = (z) =>
    0.3 * (1 - 0.94 * smooth((z - 12) / 88)) + 0.7 * (1 - 0.975 * smooth((z - 8) / 56));
  const atmosphereState = (time) => {
    const phase = ((((time % LOOP_MS) + LOOP_MS) % LOOP_MS) / LOOP_MS) * Math.PI * 2;
    return { x: 6 * Math.sin(phase), y: 3 * Math.cos(phase), light: 0.015 * Math.sin(phase) };
  };
  const followCamera = (from, to, dt) => mix(from, to, 1 - Math.exp(-Math.max(0, dt) / 32));
  // World, formula and ribbon geometry share this right-handed camera contract.
  // Clipping distances and material payloads remain the caller's responsibility.
  function cameraView(current, width, height, compact = width <= 640) {
    const forward = normalize(sub(current.target, current.position)),
      right = normalize(cross(forward, [0, 1, 0])),
      up = cross(right, forward);
    const focal = (compact ? Math.min(height, width * 1.15) : height) / (2 * Math.tan(Math.PI / 8)),
      origin = [width * (compact ? 0.42 : 0.66), height * 0.48];
    const camera = (point) => {
      const x = point[0] - current.position[0],
        y = point[1] - current.position[1],
        z = point[2] - current.position[2];
      return [
        x * right[0] + y * right[1] + z * right[2],
        x * up[0] + y * up[1] + z * up[2],
        x * forward[0] + y * forward[1] + z * forward[2],
      ];
    };
    const project = (point) => {
      const x = origin[0] + (point[0] * focal) / point[2],
        y = origin[1] - (point[1] * focal) / point[2];
      // Ordinary geometry allocates its original two-coordinate output only.
      // Ribbon material carries the payload from the clipped camera vertex.
      return point.length > 3 ? [x, y, ...point.slice(3)] : [x, y];
    };
    const visible = (points) =>
      !points.every((point) => point[0] < -8) &&
      !points.every((point) => point[0] > width + 8) &&
      !points.every((point) => point[1] < -8) &&
      !points.every((point) => point[1] > height + 8);
    return { forward, right, up, camera, project, visible, focal, origin };
  }
  // Semantic headings set interior waypoints. The actual scroll range owns
  // both endpoints, including unmarked trailing blocks and the footer.
  function fitScrollStops(markers, end) {
    const unique = [];
    for (const marker of markers) {
      const previous = unique.at(-1);
      if (
        Number.isFinite(marker.y) &&
        (!previous || (marker.y > previous.y + 0.5 && marker.id !== previous.id))
      )
        unique.push({ ...marker });
    }
    if (end <= 0.5 || unique.length < 2) return unique.slice(0, 1);
    const middle = unique.slice(1, -1).filter((marker) => marker.y > 0.5 && marker.y < end - 0.5);
    return [{ ...unique[0], y: 0 }, ...middle, { ...unique.at(-1), y: end }];
  }
  // A short introductory segment begins at the first native scroll. The
  // remainder still follows the visible archive, including a filtered reflow.
  function writingProgress(y, { start, end }, anchor = null) {
    if (y <= 0) return 0;
    if (y >= end) return 1;
    const intro = start > 0 ? 0.12 : 0;
    const ordinary = () =>
      y < start
        ? intro * clamp(y / start)
        : intro + (1 - intro) * clamp((y - start) / (end - start));
    // A previous bottom/top cannot remain an interior endpoint after reflow.
    if (!anchor || anchor.y <= 0 || anchor.y >= end || anchor.progress <= 0 || anchor.progress >= 1)
      return ordinary();
    const knots = [[0, 0]];
    if (start > 0 && start < anchor.y)
      knots.push([start, Math.min(intro, (anchor.progress * start) / anchor.y)]);
    knots.push([anchor.y, anchor.progress]);
    if (start > anchor.y && start < end)
      knots.push([
        start,
        Math.max(
          intro,
          anchor.progress + ((1 - anchor.progress) * (start - anchor.y)) / (end - anchor.y)
        ),
      ]);
    knots.push([end, 1]);
    for (let i = 1; i < knots.length; i++) {
      const [a, p] = knots[i - 1],
        [b, q] = knots[i];
      if (y <= b) return clamp(p + (q - p) * clamp((y - a) / (b - a)));
    }
    return 1;
  }
  const cadenceFor = (cost, compact, camera = false) =>
    rates.find(
      (rate) => cost * rate <= (camera ? (compact ? 0.4 : 0.55) : compact ? 0.17 : 0.38) * 1000
    ) || rates.at(-1);
  function nextDeadline(deadline, time, interval) {
    const next = (deadline ?? time) + interval;
    return next <= time + 0.5 ? time + interval : next;
  }
  function clipSegment(a, b, near = 0.5) {
    if (a[2] < near && b[2] < near) return null;
    if (a[2] < near) a = lerp(a, b, (near - a[2]) / (b[2] - a[2]));
    else if (b[2] < near) b = lerp(b, a, (near - b[2]) / (a[2] - b[2]));
    return [a, b];
  }
  function clipPolygon(points, near = 0.5) {
    const result = [];
    for (let i = 0; i < points.length; i++) {
      const a = points[i],
        b = points[(i + 1) % points.length],
        insideA = a[2] >= near,
        insideB = b[2] >= near;
      if (insideA) result.push(a);
      if (insideA !== insideB) result.push(lerp(a, b, (near - a[2]) / (b[2] - a[2])));
    }
    return result;
  }
  function facePlane(points) {
    // Cache Newell's plane in immutable world coordinates, including concave glyphs.
    let x = 0,
      y = 0,
      z = 0;
    for (let i = 0; i < points.length; i++) {
      const a = points[i],
        b = points[(i + 1) % points.length];
      x += (a[1] - b[1]) * (a[2] + b[2]);
      y += (a[2] - b[2]) * (a[0] + b[0]);
      z += (a[0] - b[0]) * (a[1] + b[1]);
    }
    return [x, y, z, x * points[0][0] + y * points[0][1] + z * points[0][2]];
  }
  return {
    add,
    sub,
    dot,
    cross,
    normalize,
    lerp,
    mix,
    clamp,
    spline,
    LOOP_MS,
    rates,
    owns,
    smooth,
    depthVisibility,
    atmosphereState,
    followCamera,
    cameraView,
    fitScrollStops,
    writingProgress,
    cadenceFor,
    nextDeadline,
    clipSegment,
    clipPolygon,
    facePlane,
  };
})();
const definitions={
  "poses": {
    "overview": {
      "position": [
        6,
        4,
        24
      ],
      "target": [
        0,
        0,
        -5
      ]
    },
    "researchOverview": {
      "position": [
        5,
        4,
        23
      ],
      "target": [
        0,
        0,
        -5
      ]
    },
    "control": {
      "position": [
        -1,
        1,
        3
      ],
      "target": [
        -2,
        1,
        -25
      ]
    },
    "help": {
      "position": [
        2,
        -1,
        -14
      ],
      "target": [
        -2,
        1,
        -33
      ]
    },
    "feedback": {
      "position": [
        -1,
        -2,
        -32
      ],
      "target": [
        2,
        -1,
        -55
      ]
    },
    "context": {
      "position": [
        3,
        1,
        -45
      ],
      "target": [
        1,
        0,
        -69
      ]
    },
    "closing": {
      "position": [
        -2,
        2,
        -64
      ],
      "target": [
        0,
        0,
        -82
      ]
    },
    "verification": {
      "position": [
        2,
        2,
        4
      ],
      "target": [
        -2,
        1,
        -26
      ]
    },
    "verificationEnd": {
      "position": [
        -1,
        2,
        -60
      ],
      "target": [
        0,
        0,
        -80
      ]
    },
    "controller": {
      "position": [
        4,
        2,
        22
      ],
      "target": [
        0,
        0,
        -5
      ]
    },
    "controllerEnd": {
      "position": [
        1,
        -2,
        -63
      ],
      "target": [
        0,
        0,
        -81
      ]
    },
    "library": {
      "position": [
        5,
        3,
        24
      ],
      "target": [
        0,
        0,
        -5
      ]
    },
    "libraryMid": {
      "position": [
        -1,
        1,
        -18
      ],
      "target": [
        -2,
        1,
        -35
      ]
    },
    "libraryEnd": {
      "position": [
        2,
        -1,
        -63
      ],
      "target": [
        0,
        0,
        -81
      ]
    },
    "signal": {
      "position": [
        5,
        3,
        24
      ],
      "target": [
        0,
        0,
        -5
      ]
    },
    "signalEnd": {
      "position": [
        -1,
        1,
        -28
      ],
      "target": [
        2,
        -1,
        -55
      ]
    },
    "network": {
      "position": [
        5,
        4,
        24
      ],
      "target": [
        0,
        0,
        -5
      ]
    },
    "networkEnd": {
      "position": [
        1,
        -1,
        -30
      ],
      "target": [
        2,
        -1,
        -54
      ]
    }
  },
  "topicPaths": {
    "all": [
      "library",
      "control",
      "libraryMid",
      "feedback",
      "libraryEnd"
    ],
    "strategy": [
      "library",
      "help",
      "closing"
    ],
    "systems": [
      "researchOverview",
      "control",
      "feedback",
      "closing"
    ],
    "delivery": [
      "library",
      "verification",
      "libraryMid",
      "verificationEnd"
    ],
    "leadership": [
      "controller",
      "help",
      "controllerEnd"
    ]
  },
  "roomSpacing": 128,
  "pageStops": {
    "index": {
      "hero": "overview",
      "help": "control",
      "research": "help",
      "writing": "feedback",
      "acknowledgements": "context",
      "about": "closing",
      "contact": "closing"
    },
    "research": {
      "intro": "researchOverview",
      "research": "verification",
      "lenses": "help",
      "topics": "feedback",
      "acknowledgements": "closing"
    },
    "talks": {
      "intro": "signal",
      "talks": "signalEnd",
      "continue": "closing"
    },
    "credits": {
      "intro": "network",
      "preferences": "networkEnd",
      "contact": "closing"
    }
  },
  "initialPoses": {
    "index": "overview",
    "research": "researchOverview",
    "writing": "library",
    "talks": "signal",
    "credits": "network"
  },
  "routeOrder": [
    "index",
    "research",
    "writing",
    "talks",
    "credits"
  ]
};
const world=(function (math) {
  const { add, normalize, facePlane, owns } = math;
  // Finite symbol/detail templates are shared by every room. No route models
  // or browser objects live here; the vocabulary bounds this immutable cache.
  const templates = new Map();
  // Finite recursive grammars use modeled symbols as their terminal geometry.
  // Immutable geometry is built once; every animated pose is evaluated from it.
  function worldFor(page, compact = false) {
    const faces = [],
      lines = [],
      objects = [];
    const rotate = (p, r) => {
      let [x, y, z] = p,
        [a, b, c] = r;
      [y, z] = [y * Math.cos(a) - z * Math.sin(a), y * Math.sin(a) + z * Math.cos(a)];
      [x, z] = [x * Math.cos(b) + z * Math.sin(b), -x * Math.sin(b) + z * Math.cos(b)];
      return [x * Math.cos(c) - y * Math.sin(c), x * Math.sin(c) + y * Math.cos(c), z];
    };
    let detail = 0,
      metadata = {};
    function object(name, center, rotation, scale, band, build) {
      const firstFace = faces.length,
        firstLine = lines.length;
      const key = Number(compact) + ':' + metadata.symbol + ':' + detail;
      if (templates.has(key)) {
        instance(templates.get(key));
        return;
      }
      // Build each symbol/detail vocabulary once in local coordinates. Every
      // repetition transforms its shared vertices once, not once per facet.
      const point = (p) => p;
      const face = (points, color = 'cyan', tone = 0.2, edge = 0.36, closed = false) =>
        faces.push({
          points: points.map(point),
          color,
          band,
          opacity: 1,
          tone,
          edgeAlpha: edge,
          object: name,
          ...(compact && closed ? { oneSided: true } : {}),
        });
      const line = (a, b, color = 'cyan', alpha = 0.58, width = 1, minScale = 0) =>
        lines.push({
          a: point(a),
          b: point(b),
          color,
          band,
          opacity: alpha,
          width,
          object: name,
          ...(minScale ? { minScale } : {}),
        });
      const path = (points, color = 'cyan', alpha = 0.58, width = 1, minScale = 0) => {
        for (let i = 1; i < points.length; i++)
          if (!compact || !points[i].every((v, j) => v === points[i - 1][j]))
            line(points[i - 1], points[i], color, alpha, width, minScale);
      };
      const poly = (points, depth, color = 'cyan', tone = 0.24) => {
        if (
          compact &&
          points.reduce(
            (sum, p, i) =>
              sum +
              p[0] * points[(i + 1) % points.length][1] -
              points[(i + 1) % points.length][0] * p[1],
            0
          ) < 0
        )
          points = points.slice().reverse();
        const front = points.map(([x, y]) => [x, y, depth / 2]),
          back = points.map(([x, y]) => [x, y, -depth / 2]);
        face(back.slice().reverse(), color, tone * 0.7, 0.36, true);
        face(front, color, tone, 0.36, true);
        for (let i = 0; i < points.length; i++) {
          const j = (i + 1) % points.length;
          face([front[i], back[i], back[j], front[j]], color, tone * 1.7, 0.36, true);
        }
      };
      const box = (c, size, color = 'cyan', tone = 0.2) => {
        const corners = [
          [-1, -1, -1],
          [1, -1, -1],
          [1, 1, -1],
          [-1, 1, -1],
          [-1, -1, 1],
          [1, -1, 1],
          [1, 1, 1],
          [-1, 1, 1],
        ].map((p) =>
          add(
            c,
            p.map((v, i) => (v * size[i]) / 2)
          )
        );
        for (const ix of [
          [0, 3, 2, 1],
          [4, 5, 6, 7],
          [0, 1, 5, 4],
          [2, 3, 7, 6],
          [1, 2, 6, 5],
          [3, 0, 4, 7],
        ])
          face(
            ix.map((i) => corners[i]),
            color,
            tone,
            0.36,
            true
          );
      };
      const ring = (
        center,
        radius,
        tube,
        rotation = [0, 0, 0],
        color = 'cyan',
        arc = Math.PI * 2
      ) => {
        const n = compact ? (detail ? 4 : 8) : detail ? 8 : 20,
          sides = 3;
        const at = (i, j) =>
          add(
            center,
            rotate(
              [
                (radius + tube * Math.cos((j / sides) * 2 * Math.PI)) * Math.cos((i / n) * arc),
                (radius + tube * Math.cos((j / sides) * 2 * Math.PI)) * Math.sin((i / n) * arc),
                tube * Math.sin((j / sides) * 2 * Math.PI),
              ],
              rotation
            )
          );
        for (let i = 0; i < n; i++)
          for (let j = 0; j < sides; j++)
            face([at(i, j), at(i + 1, j), at(i + 1, j + 1), at(i, j + 1)], color, 0.29, 0.12, true);
        path(
          Array.from({ length: n + 1 }, (_, i) => at(i, 0)),
          color,
          0.66
        );
        path(
          Array.from({ length: n + 1 }, (_, i) => at(i, 2)),
          color,
          0.52
        );
      };
      const ball = (center, r, color = 'amber') => {
        const vertices = [
          [r, 0, 0],
          [-r, 0, 0],
          [0, r, 0],
          [0, -r, 0],
          [0, 0, r],
          [0, 0, -r],
        ].map((p) => add(p, center));
        for (const ix of [
          [0, 2, 4],
          [2, 1, 4],
          [1, 3, 4],
          [3, 0, 4],
          [2, 0, 5],
          [1, 2, 5],
          [3, 1, 5],
          [0, 3, 5],
        ])
          face(
            ix.map((i) => vertices[i]),
            color,
            0.32,
            0.3,
            true
          );
      };
      const paper = (center, w, h, bend = 0.25, tilt = 0, color = 'cyan', text = true) => {
        const at = (x, y) =>
          add(
            center,
            rotate([x, y, bend * Math.sin((y / h + 0.5) * Math.PI) + 0.08 * x * x], [0, tilt, 0])
          );
        const n = compact ? (detail ? 1 : 3) : detail ? 2 : 5;
        for (let i = 0; i < n; i++) {
          const y = -h / 2 + (h * i) / n,
            Y = y + h / n;
          face([at(-w / 2, y), at(w / 2, y), at(w / 2, Y), at(-w / 2, Y)], color, 0.055, 0);
        }
        path(
          [
            at(-w / 2, -h / 2),
            ...Array.from({ length: n + 1 }, (_, i) => at(-w / 2, -h / 2 + (h * i) / n)),
            at(w / 2, h / 2),
            ...Array.from({ length: n + 1 }, (_, i) => at(w / 2, h / 2 - (h * i) / n)),
            at(-w / 2, -h / 2),
          ],
          color,
          0.55
        );
        if (text)
          for (let row = 0; row < (compact && detail ? 2 : 6); row++) {
            const y = h * 0.28 - row * h * 0.095;
            line(
              add(at(-w * 0.32, y), [0, 0, 0.015]),
              add(at(w * (row === 5 ? 0.03 : 0.29), y), [0, 0, 0.015]),
              color,
              row === 0 ? 0.48 : 0.2,
              row === 0 ? 1.5 : 0.8
            );
          }
      };
      build({ face, line, path, poly, box, ring, ball, paper });
      const template = {
          faces: faces.splice(firstFace),
          lines: lines.splice(firstLine),
          points: [],
        },
        lookup = new Map();
      const index = (p) => {
        const key = p.join(',');
        if (!lookup.has(key)) {
          lookup.set(key, template.points.length);
          template.points.push(p);
        }
        return lookup.get(key);
      };
      for (const f of template.faces) f.indices = f.points.map(index);
      for (const line of template.lines) line.indices = [index(line.a), index(line.b)];
      template.radius = Math.max(...template.points.map((p) => Math.hypot(...p)));
      templates.set(key, template);
      instance(template);
      function instance(template) {
        const [a, b, c] = rotation,
          ca = Math.cos(a),
          sa = Math.sin(a),
          cb = Math.cos(b),
          sb = Math.sin(b),
          cc = Math.cos(c),
          sc = Math.sin(c);
        const m = [
          cc * cb,
          cc * sb * sa - sc * ca,
          cc * sb * ca + sc * sa,
          sc * cb,
          sc * sb * sa + cc * ca,
          sc * sb * ca - cc * sa,
          -sb,
          cb * sa,
          cb * ca,
        ];
        const points = template.points.map((p) => [
          center[0] + scale * (m[0] * p[0] + m[1] * p[1] + m[2] * p[2]),
          center[1] + scale * (m[3] * p[0] + m[4] * p[1] + m[5] * p[2]),
          center[2] + scale * (m[6] * p[0] + m[7] * p[1] + m[8] * p[2]),
        ]);
        for (const f of template.faces)
          faces.push({ ...f, points: f.indices.map((i) => points[i]), band, object: name });
        for (const line of template.lines)
          lines.push({
            ...line,
            a: points[line.indices[0]],
            b: points[line.indices[1]],
            band,
            object: name,
          });
        // Culling uses the actual animated centre and uniform pulse scale.
        // A fixed 2.3-world-unit motion pad inflated tiny copies by several
        // times and needlessly projected objects outside the viewport.
        objects.push({
          name,
          center,
          scale,
          band,
          ...metadata,
          firstFace,
          faceCount: template.faces.length,
          firstLine,
          lineCount: template.lines.length,
          points,
          radius: template.radius * scale + 1e-6,
        });
      }
    }
    const bookHalf = ({ face, line, path }, sign, n, rows, segments) => {
      const at = (t, y, leaf) => [
        sign * t * 2.65,
        y,
        0.58 * t + 0.3 * Math.sin(t * Math.PI) - leaf * 0.062,
      ];
      // Boards, page block and individual curled leaves; the central gutter is real depth.
      const board = (t, y) => [sign * t * 2.83, y, 0.58 * t + 0.3 * Math.sin(t * Math.PI) - 0.34];
      for (let i = 0; i < n; i++) {
        face(
          [
            board(i / n, -2.2),
            board((i + 1) / n, -2.2),
            board((i + 1) / n, 2.2),
            board(i / n, 2.2),
          ],
          'cyan',
          0.31,
          0
        );
        face(
          [
            board(i / n, -2.2),
            board((i + 1) / n, -2.2),
            add(board((i + 1) / n, -2.2), [0, 0, -0.08]),
            add(board(i / n, -2.2), [0, 0, -0.08]),
          ],
          'cyan',
          0.48,
          0.15
        );
      }
      path(
        Array.from({ length: n + 1 }, (_, i) => board(i / n, 2.2)),
        'cyan',
        0.6
      );
      path(
        Array.from({ length: n + 1 }, (_, i) => board(i / n, -2.2)),
        'cyan',
        0.6
      );
      for (const leaf of detail ? [2, 0] : [4, 2, 0]) {
        const edge = Array.from({ length: n + 1 }, (_, i) => at(i / n, -2.05, leaf));
        path(edge, 'cyan', 0.3, 0.8);
        path(
          Array.from({ length: n + 1 }, (_, i) => at(i / n, 2.05, leaf)),
          'cyan',
          0.28,
          0.8
        );
        line(at(1, -2.05, leaf), at(1, 2.05, leaf), 'cyan', 0.34, 0.8);
      }
      for (let i = 0; i < n; i++)
        face(
          [
            at(i / n, -2.05, 0),
            at((i + 1) / n, -2.05, 0),
            at((i + 1) / n, 2.05, 0),
            at(i / n, 2.05, 0),
          ],
          'cyan',
          0.04,
          0
        );
      for (let row = 0; row < rows; row++) {
        const y = 1.45 - row * 0.29,
          end = 0.88;
        path(
          Array.from({ length: segments + 1 }, (_, i) =>
            add(at(0.14 + ((end - 0.14) * i) / segments, y, 0), [0, 0, 0.018])
          ),
          'cyan',
          row === 0 ? 0.46 : 0.23,
          row === 0 ? 1.8 : 0.8
        );
      }
      if (sign === 1)
        face(
          [
            at(0.76, 2.12, -0.25),
            at(0.85, 2.12, -0.25),
            at(0.85, -2.55, -0.25),
            at(0.805, -2.38, -0.25),
            at(0.76, -2.55, -0.25),
          ],
          'amber',
          0.43,
          0.55
        );
    };
    const openBook = ({ face, line, path }) => {
      const n = compact ? (detail ? 1 : 3) : detail ? 2 : 5;
      const rows = compact && detail ? 2 : detail ? 3 : 5,
        segments = compact && detail ? 1 : 3;
      for (const sign of [-1, 1]) bookHalf({ face, line, path }, sign, n, rows, segments);
      line([0, -2.18, -0.2], [0, 2.18, -0.2], 'amber', 0.65, 1.4);
    };
    const letters = ({ poly, box }) => {
      // Separate solid strokes leave the A's counter genuinely open in 3D.
      poly(
        [
          [-1.25, -1.65],
          [-0.76, -1.65],
          [0.08, 1.17],
          [-0.1, 1.8],
          [-0.43, 1.8],
        ],
        0.3,
        'amber',
        0.37
      );
      poly(
        [
          [0.72, -1.65],
          [1.23, -1.65],
          [0.14, 1.8],
          [-0.34, 1.8],
        ],
        0.3,
        'amber',
        0.37
      );
      box([-0.03, -0.48, 0], [1.28, 0.25, 0.3], 'amber', 0.42);
      box([-1.0, -1.64, 0], [0.9, 0.18, 0.4], 'amber', 0.37);
      box([0.97, -1.64, 0], [0.9, 0.18, 0.4], 'amber', 0.37);
    };
    const sheets = ({ paper }) => {
      paper([-0.24, -0.22, -0.5], 2.5, 3.25, 0.35, -0.16, 'cyan', false);
      paper([0.15, 0, -0.22], 2.5, 3.25, 0.42, 0.06, 'cyan', false);
      paper([0.45, 0.24, 0.12], 2.5, 3.25, 0.6, 0.28, 'cyan');
    };
    const compass = ({ ring, face, line, ball }) => {
      ring([0, 0, 0], 2.35, 0.09);
      ring([0, 0, -0.22], 2.12, 0.035);
      const marks = compact ? (detail ? 8 : 16) : 32;
      for (let i = 0; i < marks; i++) {
        const a = (i * Math.PI * 2) / marks,
          r = i % (marks / 8) ? 2.13 : 1.93;
        line(
          [r * Math.sin(a), r * Math.cos(a), 0.03],
          [2.26 * Math.sin(a), 2.26 * Math.cos(a), 0.03],
          'cyan',
          i % (marks / 8) ? 0.27 : 0.65
        );
      }
      for (let i = 0; i < 4; i++) {
        const a = (i * Math.PI) / 2,
          tip = [Math.sin(a) * 1.86, Math.cos(a) * 1.86, 0.04],
          left = [Math.sin(a - 0.8) * 0.47, Math.cos(a - 0.8) * 0.47, 0.04],
          right = [Math.sin(a + 0.8) * 0.47, Math.cos(a + 0.8) * 0.47, 0.04];
        face([left, tip, [0, 0, 0.38]], i === 0 ? 'amber' : 'cyan', 0.26);
        face([tip, right, [0, 0, 0.38]], i === 0 ? 'amber' : 'cyan', 0.48);
      }
      ball([0, 0, 0.42], 0.13, 'amber');
    };
    const steps = ({ box, line }) => {
      for (let i = 0; i < 7; i++) {
        const y = -2.6 + i * 0.62,
          x = -2.2 + i * 0.72,
          z = Math.sin(i * 0.45) * 0.6;
        box([x, y, z], [1.25, 0.2, 1.9], i === 6 ? 'amber' : 'cyan', 0.2);
        line([x - 0.58, y + 0.12, z + 0.91], [x + 0.58, y + 0.12, z + 0.91], 'amber', 0.42);
      }
    };
    const arch = ({ box, face, line }) => {
      box([-1.5, -1.15, 0], [0.4, 3.5, 0.65], 'cyan', 0.22);
      box([1.5, -1.15, 0], [0.4, 3.5, 0.65], 'cyan', 0.22);
      const segments = compact ? (detail ? 4 : 8) : 14;
      for (let i = 0; i < segments; i++) {
        const a = (i / segments) * Math.PI,
          b = ((i + 1) / segments) * Math.PI;
        const section = (z) => [
          [1.7 * Math.cos(a), 0.6 + 1.7 * Math.sin(a), z],
          [1.7 * Math.cos(b), 0.6 + 1.7 * Math.sin(b), z],
          [1.3 * Math.cos(b), 0.6 + 1.3 * Math.sin(b), z],
          [1.3 * Math.cos(a), 0.6 + 1.3 * Math.sin(a), z],
        ];
        face(
          section(0.325),
          i === Math.floor(segments / 2) - 1 ? 'amber' : 'cyan',
          0.27,
          0.36,
          true
        );
        face(section(-0.325).reverse(), 'cyan', 0.18, 0.36, true);
        face(
          [section(0.325)[0], section(-0.325)[0], section(-0.325)[1], section(0.325)[1]],
          'cyan',
          0.33,
          0.36,
          true
        );
        face(
          [section(0.325)[2], section(-0.325)[2], section(-0.325)[3], section(0.325)[3]],
          'cyan',
          0.3,
          0.36,
          true
        );
      }
      line([-1.5, -2.8, 0], [1.5, -2.8, 0], 'amber', 0.35);
    };
    const gyroscope = ({ ring, line, ball }) => {
      ring([0, 0, 0], 2.75, 0.075, [0, 0, 0]);
      ring([0, 0, 0], 2.35, 0.085, [0.72, 0.4, 0.22]);
      ring([0, 0, 0], 1.85, 0.08, [-0.63, 0.9, 0], 'amber');
      line([0, -3.1, 0], [0, 3.1, 0], 'cyan', 0.52);
      ball([0, 0, 0], 0.54, 'amber');
      for (const y of [-2.75, 2.75]) ball([0, y, 0], 0.12, 'cyan');
    };
    const hypotheses = ({ line, ball }) => {
      function grow(start, dir, length, depth) {
        const end = add(
          start,
          normalize(dir).map((x) => x * length)
        );
        line(start, end, depth % 2 ? 'cyan' : 'amber', 0.56, depth ? 1.35 : 0.85);
        if (!depth) {
          ball(end, 0.085, 'cyan');
          return;
        }
        for (const sign of [-1, 1])
          grow(
            end,
            [dir[0] * 0.5 + sign * 0.85, dir[1] * 0.7 + 0.25, dir[2] + sign * 0.35],
            length * 0.69,
            depth - 1
          );
      }
      grow([0, -2.8, 0], [0, 1, 0], 2, detail ? 1 : 2);
    };
    const microphone = ({ face, path, line, box, ring }) => {
      // A capsule grille inside a separate yoke; not an audio visualization.
      const n = compact ? (detail ? 4 : 8) : detail ? 6 : 12,
        levels = [
          [-1.25, 0.28],
          [-1.1, 0.58],
          [-0.85, 0.72],
          [0.85, 0.72],
          [1.1, 0.58],
          [1.25, 0.28],
        ];
      const at = (level, j) => [
        levels[level][1] * Math.cos((j / n) * Math.PI * 2),
        levels[level][0] + 0.9,
        levels[level][1] * Math.sin((j / n) * Math.PI * 2),
      ];
      for (let k = 0; k < levels.length - 1; k++)
        for (let j = 0; j < n; j++) {
          const panel = [at(k, j), at(k, j + 1), at(k + 1, j + 1), at(k + 1, j)];
          face(compact ? panel.reverse() : panel, 'cyan', 0.26, 0.1, true);
        }
      for (let j = 0; j < n; j++)
        path(
          levels.map((_, k) => at(k, j)),
          'cyan',
          0.37,
          0.85
        );
      for (let y = -0.55; y <= 1.65; y += compact && detail ? 0.73 : detail ? 0.44 : 0.22) {
        const r = y < -0.18 ? 0.57 : y > 1.68 ? 0.57 : 0.735;
        path(
          Array.from({ length: n + 1 }, (_, j) => [
            r * Math.cos((j / n) * 2 * Math.PI),
            y,
            r * Math.sin((j / n) * 2 * Math.PI),
          ]),
          'cyan',
          0.4,
          0.8
        );
      }
      box([-1.04, -0.25, 0], [0.18, 1.8, 0.25], 'amber', 0.37);
      box([1.04, -0.25, 0], [0.18, 1.8, 0.25], 'amber', 0.37);
      box([0, -1.12, 0], [2.2, 0.2, 0.25], 'amber', 0.36);
      box([0, -2, 0], [0.19, 1.7, 0.19], 'cyan', 0.32);
      ring([0, -2.87, 0], 1.05, 0.12, [Math.PI / 2, 0, 0]);
      line([0, -2.8, 0], [0, -1.15, 0], 'cyan', 0.6);
    };
    const soundwaves = ({ face, path }) => {
      for (let k = 0; k < 4; k++) {
        const r = 1.15 + k * 0.7,
          z = -k * 0.35,
          n = compact ? (detail ? 3 : 8) : detail ? 6 : 12;
        const at = (i, inner) => {
          const a = -0.92 + (i / n) * 1.84;
          return [Math.cos(a) * (r - inner), Math.sin(a) * (r - inner), z];
        };
        for (let i = 0; i < n; i++)
          face(
            [at(i, 0), at(i + 1, 0), at(i + 1, 0.1), at(i, 0.1)],
            k === 1 ? 'amber' : 'cyan',
            0.28,
            0.05
          );
        path(
          Array.from({ length: n + 1 }, (_, i) => at(i, 0)),
          k === 1 ? 'amber' : 'cyan',
          0.55
        );
      }
    };
    const screen = ({ box, face, line }) => {
      box([0, 0.35, 0], [4.15, 2.65, 0.18], 'cyan', 0.12);
      for (const x of [-2.13, 2.13]) box([x, 0.35, 0.06], [0.15, 2.88, 0.24], 'cyan', 0.3);
      for (const y of [-1.05, 1.76]) box([0, y, 0.06], [4.4, 0.14, 0.24], 'cyan', 0.3);
      face(
        [
          [-0.3, -0.18, 0.16],
          [-0.3, 1, 0.16],
          [0.72, 0.4, 0.16],
        ],
        'amber',
        0.4,
        0.6
      );
      box([0, -1.85, -0.1], [0.16, 1.5, 0.16], 'cyan', 0.22);
      line([-1.55, -2.68, -0.1], [1.55, -2.68, -0.1], 'cyan', 0.58);
    };
    const quotes = ({ poly }) => {
      for (const x of [-1.05, 0.95])
        poly(
          [
            [x - 0.55, 0.1],
            [x + 0.45, 0.1],
            [x + 0.45, 1.32],
            [x - 0.7, 1.32],
            [x - 0.7, 0.2],
            [x - 0.4, -0.6],
            [x + 0.1, -1.15],
            [x + 0.52, -0.94],
            [x + 0.05, -0.4],
          ],
          0.38,
          'amber',
          0.33
        );
    };
    const links = ({ face, path }) => {
      function link(center, rotation, color) {
        const n = compact ? (detail ? 6 : 10) : detail ? 8 : 18,
          outer = [],
          inner = [];
        for (let i = 0; i < n; i++) {
          const a = (i / n) * Math.PI * 2,
            c = Math.cos(a),
            s = Math.sin(a);
          outer.push(add(center, rotate([c * 1.55, s * 0.9, 0], rotation)));
          inner.push(add(center, rotate([c * 1.23, s * 0.57, 0], rotation)));
        }
        for (let i = 0; i < n; i++) {
          const j = (i + 1) % n,
            front = (p) => add(p, rotate([0, 0, 0.14], rotation)),
            back = (p) => add(p, rotate([0, 0, -0.14], rotation));
          face(
            [front(outer[i]), front(outer[j]), front(inner[j]), front(inner[i])],
            color,
            0.26,
            0.1,
            true
          );
          face(
            [back(outer[i]), back(outer[j]), front(outer[j]), front(outer[i])],
            color,
            0.39,
            0.07,
            true
          );
          const innerWall = [back(inner[i]), back(inner[j]), front(inner[j]), front(inner[i])];
          face(compact ? innerWall.reverse() : innerWall, color, 0.39, 0.07, true);
        }
        path(
          [...outer, outer[0]].map((p) => add(p, rotate([0, 0, 0.14], rotation))),
          color,
          0.6
        );
        path(
          [...inner, inner[0]].map((p) => add(p, rotate([0, 0, 0.14], rotation))),
          color,
          0.56
        );
      }
      link([-0.95, 0.3, 0.1], [0, 0, -0.3], 'cyan');
      link([0.95, -0.3, 0], [-0.65, -0.25, 0.15], 'amber');
    };
    const sourceTabs = ({ paper, box, face }) => {
      paper([0, 0, 0], 2.45, 3.05, 0.07, 0, 'cyan');
      face(
        [
          [0.45, 1.57, 0.05],
          [1, 1.57, 0.05],
          [1, 0.62, 0.1],
          [0.72, 0.85, 0.1],
          [0.45, 0.62, 0.1],
        ],
        'amber',
        0.45
      );
      box([-1.25, 0, -0.14], [0.09, 3.3, 0.12], 'cyan', 0.25);
    };
    const closedBook = ({ box, line }) => {
      box([0, 0, 0], [2.35, 3.15, 0.5], 'cyan', 0.045);
      for (const z of [-0.32, 0.32]) box([0, 0, z], [2.55, 3.35, 0.12], 'cyan', 0.32);
      box([-1.22, 0, 0], [0.2, 3.35, 0.7], 'amber', 0.34);
      for (const y of [-1, -0.75, 0.8, 1.05])
        line([-1.34, y, 0.36], [-1.08, y, 0.36], 'amber', 0.65);
    };
    const scroll = ({ paper, ring }) => {
      paper([0, 0, 0], 2.2, 2.7, 0.24, 0);
      for (const y of [-1.35, 1.35]) ring([0, y, 0.1], 0.34, 0.1, [0, Math.PI / 2, 0], 'amber');
    };
    const bracket = ({ poly }) => {
      for (const sign of [-1, 1])
        poly(
          [
            [sign * 0.6, -1.5],
            [sign * 1.1, -1.5],
            [sign * 1.1, 1.5],
            [sign * 0.6, 1.5],
            [sign * 0.6, 1.22],
            [sign * 0.84, 1.22],
            [sign * 0.84, -1.22],
            [sign * 0.6, -1.22],
          ],
          0.22,
          'amber',
          0.3
        );
    };
    const quill = ({ face, line }) => {
      face(
        [
          [0, -1.8, 0],
          [-0.85, 0.3, 0.1],
          [-0.55, 1.7, 0.22],
          [0.45, 1.15, 0.22],
          [0.66, 0.35, 0.1],
        ],
        'cyan',
        0.065,
        0.6
      );
      line([0, -2, 0], [-0.22, 1.65, 0.28], 'amber', 0.75, 1.5);
      for (let i = 0; i < 4; i++)
        line([-0.1, -0.2 + i * 0.4, 0.17], [-0.7, 0.12 + i * 0.38, 0.18], 'cyan', 0.3);
    };
    const prism = ({ face, line }) => {
      const a = [
          [-1.3, -1, 0],
          [1.3, -1, 0],
          [0, 1.5, 0],
        ],
        b = a.map((p) => add(p, [0, 0, -1]));
      face(a, 'cyan', 0.12);
      face(b.slice().reverse(), 'cyan', 0.2);
      for (let i = 0; i < 3; i++)
        face([a[i], b[i], b[(i + 1) % 3], a[(i + 1) % 3]], i === 0 ? 'amber' : 'cyan', 0.32);
      line([-2.2, 0, 0.5], [2.2, 0, 0.5], 'amber', 0.5);
    };
    const lens = ({ ring, face }) => {
      ring([0, 0, 0], 1.55, 0.12);
      ring([0, 0, -0.3], 1.45, 0.06, [0, 0, 0], 'amber');
      for (let i = 0; i < 8; i++) {
        const a = (i * Math.PI) / 4,
          b = ((i + 1) * Math.PI) / 4;
        face(
          [
            [0, 0, 0.34],
            [1.4 * Math.cos(a), 1.4 * Math.sin(a), 0],
            [1.4 * Math.cos(b), 1.4 * Math.sin(b), 0],
          ],
          'cyan',
          0.075,
          0
        );
      }
    };
    const balance = ({ box, line, face }) => {
      box([0, -0.3, 0], [0.14, 2.8, 0.2], 'cyan', 0.3);
      box([0, 1, 0], [3.5, 0.12, 0.2], 'amber', 0.3);
      for (const x of [-1.4, 1.4]) {
        line([x, 1, 0], [x, -0.3, 0]);
        face(
          [
            [x - 0.65, -0.3, 0],
            [x + 0.65, -0.3, 0],
            [x, -0.75, 0.2],
          ],
          'cyan',
          0.2
        );
      }
    };
    const bridge = ({ box }) => {
      box([0, 0, 0], [3.8, 0.22, 1.1], 'cyan', 0.25);
      for (const x of [-1.5, 1.5]) box([x, -0.9, 0], [0.22, 1.8, 1.1], 'amber', 0.28);
    };
    const bubble = ({ poly }) =>
      poly(
        [
          [-1.6, -0.65],
          [-0.65, -0.65],
          [-1.2, -1.35],
          [0.2, -0.65],
          [1.6, -0.65],
          [1.6, 1.2],
          [-1.6, 1.2],
        ],
        0.28,
        'cyan',
        0.08
      );
    const slide = ({ paper, face }) => {
      paper([0, 0, 0], 3.1, 2, 0.05, 0);
      face(
        [
          [-0.35, -0.4, 0.12],
          [-0.35, 0.6, 0.12],
          [0.55, 0.1, 0.12],
        ],
        'amber',
        0.4
      );
    };
    const podium = ({ box }) => {
      box([0, 0, 0], [1.8, 2.6, 0.7], 'cyan', 0.2);
      box([0, 1.4, 0.2], [2.45, 0.2, 1.3], 'amber', 0.3);
    };
    const asterisk = ({ box }) => {
      box([0, 0, 0], [0.2, 2.6, 0.22], 'amber', 0.34);
      box([0, 0, 0], [2.6, 0.2, 0.22], 'amber', 0.34);
      box([0, 0, 0], [0.2, 0.2, 2.6], 'cyan', 0.3);
    };
    const footnote = ({ box }) => {
      box([0, 0, 0], [0.3, 2.4, 0.24], 'amber', 0.33);
      box([-0.3, 1.04, 0], [0.7, 0.24, 0.24], 'amber', 0.33);
      box([0, -1.2, 0], [1.25, 0.24, 0.24], 'amber', 0.33);
    };
    const vocabulary = {
      index: [
        ['arch', arch],
        ['stairs', steps],
        ['bridge', bridge],
        ['compass', compass],
        ['book', closedBook],
        ['lens', lens],
        ['prism', prism],
        ['threshold', bracket],
      ],
      research: [
        ['lens', lens],
        ['prism', prism],
        ['feedback', gyroscope],
        ['hypotheses', hypotheses],
        ['balance', balance],
        ['gate', bracket],
        ['aperture', compass],
        ['evidence', sourceTabs],
      ],
      writing: [
        ['open-book', openBook],
        ['closed-book', closedBook],
        ['pages', sheets],
        ['scroll', scroll],
        ['letter-A', letters],
        ['quill', quill],
        ['parenthesis', bracket],
        ['quotation', quotes],
      ],
      talks: [
        ['slide', slide],
        ['speech', bubble],
        ['wave', soundwaves],
        ['microphone', microphone],
        ['podium', podium],
        ['screen', screen],
        ['word', letters],
        ['dialogue', quotes],
      ],
      credits: [
        ['source', sourceTabs],
        ['citation', quotes],
        ['link', links],
        ['footnote', footnote],
        ['reference', bracket],
        ['asterisk', asterisk],
        ['edition', closedBook],
        ['excerpt', scroll],
      ],
    };
    const words = vocabulary[page] || vocabulary.index;
    const roots = [
      [0, 0, -5],
      [-2, 1, -31],
      [2, -1, -57],
      [0, 0, -83],
    ];
    // Each parent repeats a smaller two/three-way spatial figure. Fixed depth,
    // fixed topology and deterministic substitutions: no per-frame growth/randomness.
    function grow(center, scale, depth, angle, root, index, parent = null) {
      const symbolIndex =
          depth === 0
            ? (index + root) % 2
            : depth === 1
              ? 2 + ((index + root) % 2)
              : 4 + ((index + root) % 4),
        [symbol, build] = words[symbolIndex];
      detail = depth || root > 0 ? 1 : 0;
      const name = `${symbol}-${root}-${objects.length}`;
      metadata = {
        family: 'thematic',
        symbol,
        depth,
        root,
        rootCenter: roots[root],
        parent,
        phase: index * 0.71 + root * 1.9,
      };
      object(
        name,
        center,
        [0.16 * Math.sin(angle), 0.32 * Math.cos(angle), angle - Math.PI / 2],
        scale,
        root > 1 ? 'distant' : depth === 0 ? 'near' : 'middle',
        build
      );
      if (depth === 2) return;
      const branches = 2,
        step = depth === 0 ? 1.12 : 0.85;
      for (let j = 0; j < branches; j++) {
        const a = angle + (j - (branches - 1) / 2) * step;
        const distance = scale * (depth === 0 ? 3.6 : 3.2);
        const next = add(center, [
          Math.cos(a) * distance,
          Math.sin(a) * distance,
          Math.sin(a * 2 + root) * scale * 0.85,
        ]);
        grow(next, scale * 0.43, depth + 1, a, root, index * 3 + j + 1, name);
      }
    }
    for (let root = 0; root < roots.length; root++) {
      const n = 7; // Macro positions and IDs survive all quality tiers.
      for (let i = 0; i < n; i++) {
        let a = (i / n) * Math.PI * 2 + root * 0.24,
          r = 6.5,
          x,
          y,
          z;
        if (page === 'writing') {
          a = -0.15 * Math.PI + (i / (n - 1)) * 1.3 * Math.PI;
          x = Math.cos(a) * r;
          y = Math.sin(a) * r * 0.87;
          z = Math.cos(a * 2) * 0.7;
        } else if (page === 'research') {
          x = Math.cos(a) * r;
          y = Math.sin(a) * r * (i % 2 ? 0.88 : 1.12);
          z = Math.sin(a * 2) * 1.7;
        } else if (page === 'talks') {
          a = -0.35 * Math.PI + (i / (n - 1)) * 1.7 * Math.PI;
          x = Math.cos(a) * r * 1.18;
          y = Math.sin(a) * r * 0.65;
          z = Math.sin(a * 2) * 2.6;
        } else if (page === 'credits') {
          x = Math.cos(a) * r;
          y = Math.sin(a * 2) * r * 0.57;
          z = Math.sin(a) * 2.1;
        } else {
          a = -0.12 * Math.PI + (i / (n - 1)) * 1.24 * Math.PI;
          x = Math.cos(a) * r;
          y = Math.sin(a) * r;
          z = Math.cos(a) * 1.6;
        }
        grow(add(roots[root], [x, y, z]), root === 0 ? 0.82 : 0.9, 0, a, root, i);
      }
    }
    sharedGeometry();
    // A common angular grammar threads every thematic room. Each branch uses
    // the same finite 1 + 2 + 4 hierarchy and clear camera corridor.
    function sharedGeometry() {
      // Replace shared terminals, keeping the same bounded 56-object hierarchy.
      const brain = ({ path, face, poly, box }) => {
        // Two closed lobes, a real fissure, cortical folds and a stem. The small
        // fixed mesh carries volume; the grooves carry the recognisable silhouette.
        const n = detail ? 5 : compact ? 6 : 8;
        for (const side of [-1, 1]) {
          const at = (lat, i) => {
            const a = (i / n) * Math.PI * 2,
              r = 1 + 0.065 * Math.cos(3 * a + lat * 2);
            return [
              side * 1.02 + 0.94 * Math.cos(lat) * Math.cos(a) * r,
              0.24 + 1.76 * Math.sin(lat),
              0.94 * Math.cos(lat) * Math.sin(a) * r,
            ];
          };
          const rings = [-0.92, 0, 0.92].map((lat) =>
            Array.from({ length: n }, (_, i) => at(lat, i))
          );
          for (let i = 0; i < n; i++) {
            const j = (i + 1) % n;
            face([[side * 1.02, -1.52, 0], rings[0][i], rings[0][j]], 'cyan', 0.19, 0.13, true);
            face([[side * 1.02, 2, 0], rings[2][j], rings[2][i]], 'cyan', 0.19, 0.13, true);
            for (let k = 0; k < 2; k++)
              face(
                [rings[k + 1][i], rings[k + 1][j], rings[k][j], rings[k][i]],
                'cyan',
                0.16,
                0.12,
                true
              );
          }
          for (let fold = 0; fold < 4; fold++)
            path(
              Array.from({ length: 7 }, (_, i) => {
                const x = 0.27 + i * 0.27,
                  y = 1.45 - fold * 0.72 + 0.18 * Math.sin(i * 1.7 + fold);
                return [
                  side * x,
                  y,
                  0.12 +
                    0.96 *
                      Math.sqrt(
                        Math.max(0.03, 1 - ((x - 1.02) / 1.05) ** 2 - ((y - 0.24) / 1.88) ** 2)
                      ),
                ];
              }),
              'amber',
              0.88,
              1.45,
              fold % 2 ? 7 : 0
            );
        }
        path(
          [
            [0, 1.88, 0.2],
            [-0.09, 1.12, 0.6],
            [0.07, 0.5, 0.83],
            [-0.07, -0.15, 0.75],
            [0, -1.23, 0.25],
          ],
          'amber',
          0.95,
          1.8
        );
        poly(
          [
            [-0.62, -1.38],
            [-0.84, -1.62],
            [-0.62, -1.93],
            [0, -2.06],
            [0.62, -1.93],
            [0.84, -1.62],
            [0.62, -1.38],
          ],
          0.65,
          'cyan',
          0.23
        );
        box([0, -2.12, -0.12], [0.36, 0.65, 0.42], 'amber', 0.32);
        for (let row = 0; row < 2; row++)
          path(
            [
              [-0.6, -1.58 - row * 0.2, 0.35],
              [0, -1.74 - row * 0.2, 0.37],
              [0.6, -1.58 - row * 0.2, 0.35],
            ],
            'amber',
            0.68,
            1.15,
            7
          );
      };
      const axes = ({ path, line }) => {
        path(
          [
            [-2.15, 1.8, 0],
            [-2.15, -1.65, 0],
            [2.2, -1.65, 0],
          ],
          'cyan',
          0.85,
          1.5
        );
        path(
          [
            [-2.15, -1.65, 0],
            [-2.15, -1.65, -1.25],
            [2.2, -1.65, -1.25],
          ],
          'cyan',
          0.42,
          1,
          7
        );
        path(
          [
            [-2.32, 1.53, 0],
            [-2.15, 1.8, 0],
            [-1.98, 1.53, 0],
          ],
          'cyan',
          0.85,
          1.5,
          7
        );
        path(
          [
            [1.94, -1.48, 0],
            [2.2, -1.65, 0],
            [1.94, -1.82, 0],
          ],
          'cyan',
          0.85,
          1.5,
          7
        );
        for (let y = -0.8; y < (detail ? -0.7 : 1.6); y += 0.8)
          line([-2.15, y, -0.35], [2, y, -0.35], 'cyan', 0.22, 0.7, 7);
      };
      const lineChart = (h) => {
        axes(h);
        const points = [
          [-1.8, -1.05, 0.3],
          [-1.1, -0.2, 0.3],
          [-0.45, -0.55, 0.3],
          [0.25, 0.5, 0.3],
          [0.85, 0.22, 0.3],
          [1.72, 1.48, 0.3],
        ];
        h.path(points, 'amber', 0.98, 2.3);
        for (let i = 1; i < points.length; i++)
          h.face(
            [
              points[i - 1],
              points[i],
              add(points[i], [0, -0.18, -0.15]),
              add(points[i - 1], [0, -0.18, -0.15]),
            ],
            'amber',
            0.36,
            0
          );
        for (const [x, y, z] of points)
          h.path(
            detail
              ? [
                  [x - 0.09, y - 0.09, z + 0.02],
                  [x, y + 0.09, z + 0.02],
                  [x + 0.09, y - 0.09, z + 0.02],
                ]
              : [
                  [x - 0.09, y, z + 0.02],
                  [x, y + 0.09, z + 0.02],
                  [x + 0.09, y, z + 0.02],
                  [x, y - 0.09, z + 0.02],
                  [x - 0.09, y, z + 0.02],
                ],
            'amber',
            0.95,
            1.3,
            7
          );
        h.path(
          [
            [-1.8, 0.9, -0.6],
            [-1.1, 0.45, -0.6],
            [-0.45, 0.2, -0.6],
            [0.25, -0.3, -0.6],
            [0.85, -0.62, -0.6],
            [1.72, -0.83, -0.6],
          ],
          'cyan',
          0.82,
          1.5
        );
      };
      const barChart = (h) => {
        axes(h);
        for (const [i, height] of [1.05, 2.25, 1.65, 3.05].entries()) {
          h.box(
            [-1.45 + i * 0.9, -1.6 + height / 2, -0.28],
            [0.58, height, 1.05],
            i % 2 ? 'amber' : 'cyan',
            0.32
          );
          h.line(
            [-1.74 + i * 0.9, -1.6 + height, 0.27],
            [-1.16 + i * 0.9, -1.6 + height, 0.27],
            'amber',
            0.98,
            1.8
          );
        }
      };
      const scatterChart = (h) => {
        axes(h);
        const points = [
          [-1.6, -0.9],
          [-1.15, -0.4],
          [-0.7, -0.8],
          [-0.35, 0.2],
          [0.25, 0.05],
          [0.8, 0.85],
          [1.35, 0.4],
          [1.75, 1.25],
        ];
        points.forEach(([x, y], i) => {
          const z = i % 2 ? 0.45 : -0.65,
            r = 0.13;
          h.path(
            [
              [x - r, y, z],
              [x, y + r, z],
              [x + r, y, z],
              [x, y - r, z],
              [x - r, y, z],
            ],
            i % 2 ? 'amber' : 'cyan',
            0.96,
            1.8
          );
          if (!detail) h.line([x, y, z], [x, -1.6, z], 'cyan', 0.22, 0.7, 7);
        });
        h.path(
          [
            [-1.8, -1.1, 0.15],
            [1.85, 1.25, 0.15],
          ],
          'amber',
          0.68,
          1.2
        );
      };
      // Stroke glyphs are world geometry, built once per detail tier.
      const glyphs = {
        D: '0,0 0,6 3,6 4,5 4,1 3,0 0,0',
        F: '0,0 0,6 4,6|0,3 3,3',
        G: '4,5 3,6 1,6 0,5 0,1 1,0 4,0 4,3 2,3',
        H: '0,0 0,6|4,0 4,6|0,3 4,3',
        K: '0,0 0,6|4,6 0,3 4,0',
        L: '0,6 0,0 4,0',
        M: '0,0 0,6 2,3 4,6 4,0',
        O: '1,0 0,1 0,5 1,6 3,6 4,5 4,1 3,0 1,0',
        P: '0,0 0,6 3,6 4,5 4,4 3,3 0,3',
        Q: '1,0 0,1 0,5 1,6 3,6 4,5 4,1 3,0 1,0|2,2 4,-1',
        S: '4,5 3,6 1,6 0,5 0,4 4,2 4,1 3,0 1,0 0,1',
        T: '0,6 4,6|2,6 2,0',
        V: '0,6 2,0 4,6',
        X: '0,6 4,0|4,6 0,0',
        Z: '0,6 4,6 0,0 4,0',
        A: '0,0 2,6 4,0|1,2 3,2',
        '=': '0,2 4,2|0,4 4,4',
        '-': '0,3 4,3',
        '/': '0,0 4,6',
        '(': '3,6 1,5 0,3 1,1 3,0',
        ')': '1,6 3,5 4,3 3,1 1,0',
        Σ: '4,6 0,6 3,3 0,0 4,0',
        '√': '0,2 1,0 2,6 4,6',
        '·': '1,3 2,3',
        d: '4,6 4,0 1,0 0,1 0,3 1,4 4,4',
        ᵀ: '0,8 3,8|1.5,8 1.5,5',
      };
      Object.assign(glyphs, {
        e: '0,2 4,2 4,3 3,4 1,4 0,3 0,1 1,0 4,0',
        i: '2,0 2,4|2,6 2,6.2',
        j: '3,4 3,-1 2,-2 0,-2|3,6 3,6.2',
        k: '0,0 0,6|4,4 0,2 4,0',
        p: '0,-2 0,4 3,4 4,3 4,1 3,0 0,0',
        z: '0,4 4,4 0,0 4,0',
      });
      const formula =
        (kind) =>
        ({ path, line }) => {
          // Fraction bars and genuinely raised/lowered exponents replace flattened
          // all-caps strings. A sparse rear rail gives depth without duplicate text.
          const text = (value, x, y, unit = 0.2, color = 'amber') => {
            for (let i = 0; i < value.length; i++)
              for (const stroke of glyphs[value[i]].split('|'))
                path(
                  stroke.split(' ').map((pair) => {
                    const [a, b] = pair.split(',').map(Number);
                    return [x + (i * 5 + a) * unit, y + b * unit, 0.28];
                  }),
                  color,
                  0.97,
                  1.8
                );
          };
          if (kind === 'attention') {
            text('A=', -4.8, -0.55, 0.19);
            text('SOFTMAX', -2.7, -0.3, 0.13);
            text('(', 1.93, -0.95, 0.29);
            text('QK', 2.43, 0.32, 0.18);
            text('T', 4.0, 1.02, 0.1);
            line([2.38, 0.13, 0.28], [4.28, 0.13, 0.28], 'amber', 0.98, 1.8);
            text('√d', 2.58, -1.22, 0.18);
            text('k', 4.05, -1.42, 0.1);
            text(')', 4.38, -0.95, 0.29);
            text('V', 5.62, -0.5, 0.19);
          } else if (kind === 'softmax') {
            text('p', -2.6, -0.25, 0.25);
            text('i', -1.5, -0.65, 0.13);
            text('=', -0.73, -0.4, 0.22);
            text('e', 1.1, 0.52, 0.28);
            text('z', 2.45, 1.2, 0.15);
            text('i', 3.1, 1.02, 0.09);
            line([0.63, 0.26, 0.28], [3.65, 0.26, 0.28], 'amber', 0.98, 1.8);
            text('Σ', 0.7, -1.3, 0.23);
            text('j', 1.07, -1.95, 0.1);
            text('e', 2, -1.28, 0.25);
            text('z', 3.16, -0.7, 0.13);
            text('j', 3.75, -0.87, 0.09);
          } else {
            text('H=-', -3.85, -0.5, 0.22);
            text('Σ', -0.4, -0.62, 0.26);
            text('i', 0.15, -1.2, 0.12);
            text('p', 1.15, -0.45, 0.22);
            text('i', 2.12, -0.85, 0.11);
            text('LOG', -1.1, -2.35, 0.2);
            text('(', 2, -2.42, 0.22);
            text('p', 2.94, -2.35, 0.22);
            text('i', 3.9, -2.7, 0.1);
            text(')', 4.38, -2.42, 0.22);
          }
          const ends = kind === 'attention' ? [-4.9, 6.4] : [-3.9, 5.3],
            y = kind === 'entropy' ? -3.1 : -2.2;
          line([ends[0], y, -0.55], [ends[1], y, -0.55], 'cyan', 0.55, 1.2, 7);
          if (!detail)
            for (const x of ends)
              path(
                [
                  [x, y + 0.38, -0.55],
                  [x, y, -0.55],
                  [x, y, 0.32],
                  [x, y + 0.38, 0.32],
                ],
                'cyan',
                0.65,
                1.2,
                7
              );
        };
      const formulas = {
        attention: 'A = softmax(QKᵀ/√dₖ)V',
        softmax: 'pᵢ = exp(zᵢ)/Σⱼ exp(zⱼ)',
        entropy: 'H = −Σᵢ pᵢ log(pᵢ)',
      };
      const geometry = [
        ['brain', brain],
        ['attention', formula('attention')],
        ['line-chart', lineChart],
        ['bar-chart', barChart],
        ['softmax', formula('softmax')],
        ['entropy', formula('entropy')],
        ['cube', (h) => h.box([0, 0, 0], [2, 2, 2], 'cyan', 0.23)],
        [
          'triangle',
          (h) =>
            h.poly(
              [
                [-1.3, -1],
                [1.3, -1],
                [0, 1.4],
              ],
              0.65,
              'amber',
              0.28
            ),
        ],
        ['scatter-chart', scatterChart],
        ['octahedron', (h) => h.ball([0, 0, 0], 1.45, 'cyan')],
        [
          'hexagon',
          (h) =>
            h.poly(
              Array.from({ length: 6 }, (_, i) => [
                1.35 * Math.cos((i * Math.PI) / 3),
                1.35 * Math.sin((i * Math.PI) / 3),
              ]),
              0.7,
              'amber',
              0.2
            ),
        ],
      ];
      function branch(center, scale, depth, root, index, parent = null) {
        const slot = depth === 0 ? root * 2 + (index === 8 ? 1 : 0) : index + root * 3;
        const [symbol, build] = geometry[slot % geometry.length],
          name = `shared-${root}-${index}`;
        detail = depth ? 1 : 0;
        metadata = {
          family: 'shared',
          symbol,
          ...(formulas[symbol] ? { formula: formulas[symbol] } : {}),
          depth,
          root,
          rootCenter: roots[root],
          parent,
          phase: index * 0.71 + root * 1.9,
        };
        const readable = symbol === 'brain' || symbol.includes('chart') || owns(formulas, symbol);
        object(
          name,
          center,
          readable ? [0.12, -0.18, 0.08 * Math.sin(index + root)] : [0.3, 0.45, index * 0.6],
          scale,
          root > 1 ? 'distant' : 'middle',
          build
        );
        if (depth === 2) return;
        for (let j = 0; j < 2; j++)
          branch(
            add(center, [(j ? 1 : -1) * scale * 2.6, scale * 1.7, -scale * 1.4]),
            scale * 0.43,
            depth + 1,
            root,
            index * 2 + j + 1,
            name
          );
      }
      for (let root = 0; root < roots.length; root++)
        for (let side = 0; side < 2; side++)
          branch(
            add(roots[root], [(side ? 1 : -1) * 10, side ? -3 : 3, -9]),
            1.2,
            0,
            root,
            side ? 8 : 0
          );
    }
    const light = normalize([-0.55, 0.85, 1]);
    for (const f of faces) prepareFace(f, light);
    // One extruded landmark sits midway between the first two book/page
    // fractals. Its living transform stays centred at that world position,
    // sharing the existing clock and forward camera journey on every viewport.
    const formulaCenter = roots[0].map((coordinate, index) => (coordinate + roots[1][index]) / 2);
    const formulas =
      page === 'writing'
        ? [
            {
              id: 'writing-paradigm',
              center: formulaCenter,
              rootCenter: formulaCenter,
              root: 0,
              phase: 0,
              width: 12,
              aspect: 1380 / 240,
              rotation: [0.08, -0.22, 0.08],
              extrusion: 0.1,
            },
          ]
        : [];
    return { faces, lines, objects, formulas };
  }
  function prepareFace(f, light) {
    // Preserve the original cross/normalize/dot arithmetic without allocating
    // two edge vectors, a cross vector and a normalized vector for every face.
    const a = f.points[0],
      b = f.points[1],
      c = f.points[2];
    const ax = b[0] - a[0],
      ay = b[1] - a[1],
      az = b[2] - a[2];
    const bx = c[0] - a[0],
      by = c[1] - a[1],
      bz = c[2] - a[2];
    let nx = ay * bz - az * by,
      ny = az * bx - ax * bz,
      nz = ax * by - ay * bx;
    const length = Math.hypot(nx, ny, nz);
    if (length > 1e-9) {
      nx /= length;
      ny /= length;
      nz /= length;
    } else {
      nx = 0;
      ny = 0;
      nz = 1;
    }
    const lightDot = 0 + nx * light[0] + ny * light[1] + nz * light[2];
    const shade = 0.65 + 0.5 * Math.abs(lightDot);
    f.tint = Math.min(0.63, f.tone * shade);
    if (f.oneSided) f.plane = facePlane(f.points);
    // Paper catches neutral light in both themes; metal keeps its cyan/bronze tint.
    if (f.tone < 0.1) {
      f.fillColor = 'sheet';
      f.tint = 0.6 + shade * 0.1;
    }
  }
  return { worldFor };
})(math);
const projection=(function (math, definitions) {
  const {
    add,
    dot,
    lerp,
    clamp,
    spline,
    LOOP_MS,
    smooth,
    depthVisibility,
    clipSegment,
    clipPolygon,
    cameraView,
  } = math;
  const { poses, initialPoses, routeOrder, roomSpacing } = definitions;
  // Authored spline waypoints pass through the open centres of successive structures.
  function journeyPose(ids, progress) {
    const path = ids.map((id) => poses[id]);
    return curveThrough(path, progress);
  }
  function curveThrough(path, progress) {
    if (path.length === 1) return path[0];
    const p = clamp(progress) * (path.length - 1),
      i = Math.min(path.length - 2, Math.floor(p)),
      t = p - i;
    if (t === 0) return path[i];
    if (t === 1) return path[i + 1];
    const indices = [Math.max(0, i - 1), i, i + 1, Math.min(path.length - 1, i + 2)];
    return {
      position: spline(...indices.map((j) => path[j].position), t),
      target: spline(...indices.map((j) => path[j].target), t),
    };
  }
  function loopTransform(object, time = 0) {
    const phase = ((((time % LOOP_MS) + LOOP_MS) % LOOP_MS) / LOOP_MS) * Math.PI * 2;
    const root = object.rootCenter,
      center = object.center,
      p = object.phase;
    const breathe = 1 + 0.065 * Math.sin(phase + object.root * 0.8);
    const pulse = 1 + 0.04 * Math.sin(phase * 2 + object.root * 0.8);
    const a = 0.045 * Math.sin(phase + object.root * 1.2),
      b = 0.065 * Math.sin(phase * 2 + p);
    const ca = Math.cos(a),
      sa = Math.sin(a),
      cb = Math.cos(b),
      sb = Math.sin(b);
    const dx = 0.12 * Math.sin(phase * 2 + p),
      dy = 0.16 * Math.cos(phase + p),
      dz = 0.12 * Math.sin(phase + p);
    // Absolute transforms of immutable points: closure holds for position and
    // velocity, and geometry cannot drift or accumulate integration error.
    const X = (center[0] - root[0]) * breathe + dx,
      Y = (center[1] - root[1]) * breathe + dy;
    const animatedCenter = [
      root[0] + X * ca - Y * sa,
      root[1] + X * sa + Y * ca,
      root[2] + (center[2] - root[2]) * breathe + dz,
    ];
    const matrix = [
      pulse * ca * cb,
      -pulse * sa,
      pulse * ca * sb,
      pulse * sa * cb,
      pulse * ca,
      pulse * sa * sb,
      -pulse * sb,
      0,
      pulse * cb,
    ];
    const transform = (point) => {
      const x = point[0] - center[0],
        y = point[1] - center[1],
        z = point[2] - center[2];
      return [
        animatedCenter[0] + matrix[0] * x + matrix[1] * y + matrix[2] * z,
        animatedCenter[1] + matrix[3] * x + matrix[4] * y + matrix[5] * z,
        animatedCenter[2] + matrix[6] * x + matrix[8] * z,
      ];
    };
    transform.matrix = matrix;
    transform.center = animatedCenter;
    transform.scale = pulse;
    transform.inverse = (point) => {
      const X = point[0] - animatedCenter[0],
        Y = point[1] - animatedCenter[1];
      const x = (X * ca + Y * sa) / pulse,
        y = (-X * sa + Y * ca) / pulse,
        z = (point[2] - animatedCenter[2]) / pulse;
      return [center[0] + x * cb - z * sb, center[1] + y, center[2] + x * sb + z * cb];
    };
    return transform;
  }
  function cameraVertices(o, transform, center, right, up, forward) {
    // Compose the object and camera matrices once. Each shared rest vertex
    // produces one camera-space vector rather than a temporary world vector.
    const a = transform.matrix,
      m = [];
    for (const axis of [right, up, forward])
      for (let j = 0; j < 3; j++) m.push(axis[0] * a[j] + axis[1] * a[j + 3] + axis[2] * a[j + 6]);
    return o.points.map((p) => {
      const x = p[0] - o.center[0],
        y = p[1] - o.center[1],
        z = p[2] - o.center[2];
      return [
        center[0] + m[0] * x + m[1] * y + m[2] * z,
        center[1] + m[3] * x + m[4] * y + m[5] * z,
        center[2] + m[6] * x + m[7] * y + m[8] * z,
      ];
    });
  }
  function projectedWorld(
    world,
    current,
    width,
    height,
    time = 0,
    tier = 0,
    prune = false,
    sort = true
  ) {
    const { forward, right, up, camera, project, visible, focal, origin } = cameraView(
      current,
      width,
      height
    );
    const [cx, cy] = origin;
    const shapes = [];
    // Exact animated-centre sphere bounds; the eight-pixel viewport margin
    // includes stroke coverage. No extra world-space motion pad is needed.
    const planes = [
      [-1, 0, (width + 8 - cx) / focal],
      [1, 0, (cx + 8) / focal],
      [0, -1, (cy + 8) / focal],
      [0, 1, (height + 8 - cy) / focal],
    ].map((p) => ({ normal: p, length: Math.hypot(...p) }));
    for (const o of world.objects) {
      const transform = loopTransform(o, time),
        center = camera(transform.center),
        radius = o.radius * transform.scale;
      const depth = center[2],
        size = (o.scale * transform.scale * focal) / Math.max(0.5, depth);
      const threshold =
        o.depth === 2 ? (width <= 640 ? 3.4 : 3) * (tier + 1) : o.depth === 1 ? 2 : 0;
      if (
        depth + radius < 0.5 ||
        size < threshold ||
        planes.some((p) => dot(p.normal, center) < -radius * p.length)
      )
        continue;
      const vertices = cameraVertices(o, transform, center, right, up, forward);
      const projected = vertices.map((p) => (p[2] >= 0.5 ? project(p) : null));
      const fade = threshold ? smooth((size - threshold) / 2) : 1;
      appendObject(
        world,
        o,
        vertices,
        projected,
        project,
        visible,
        fade,
        shapes,
        transform.inverse(current.position),
        prune ? (width <= 640 ? 0.5 : 0.35) : 0,
        prune ? size : Infinity
      );
    }
    appendFormulas(world, current, width, height, time, shapes);
    return sort ? shapes.sort((a, b) => b.depth - a.depth) : shapes;
  }
  function appendFormulas(world, current, width, height, time, shapes) {
    for (const anchor of world.formulas || []) {
      const shape = projectedFormula(anchor, current, width, height, time);
      if (shape) shapes.push(shape);
    }
  }
  function formulaWorldPoint(anchor, time, u, v, z = 0) {
    const [a, b, c] = anchor.rotation,
      ca = Math.cos(a),
      sa = Math.sin(a),
      cb = Math.cos(b),
      sb = Math.sin(b),
      cc = Math.cos(c),
      sc = Math.sin(c);
    const x = (u - 0.5) * anchor.width,
      y = ((0.5 - v) * anchor.width) / anchor.aspect;
    const Y = y * ca - z * sa,
      Z = y * sa + z * ca,
      X = x * cb + Z * sb;
    return loopTransform(
      anchor,
      time
    )(add(anchor.center, [X * cc - Y * sc, X * sc + Y * cc, -x * sb + Z * cb]));
  }
  function projectFormulaPoint(anchor, current, width, height, time, u, v, z = 0) {
    const view = cameraView(current, width, height),
      point = view.camera(formulaWorldPoint(anchor, time, u, v, z));
    return point[2] > 0.5 ? view.project(point) : null;
  }
  function projectedFormula(anchor, current, width, height, time = 0) {
    const view = cameraView(current, width, height),
      uv = [
        [0, 0],
        [1, 0],
        [1, 1],
        [0, 1],
      ],
      worldCorners = uv.map(([u, v]) => formulaWorldPoint(anchor, time, u, v)),
      cameraCorners = worldCorners.map(view.camera);
    const depth = view.camera(loopTransform(anchor, time).center)[2],
      nearest = Math.min(...cameraCorners.map((p) => p[2]));
    // Fade the entire plane before the camera crosses it. A near-plane clip
    // would discard part of the expression and stretch the raster unboundedly.
    if (nearest <= 0.5 || depth >= 105) return null;
    const points = cameraCorners.map(view.project),
      xs = points.map((p) => p[0]),
      ys = points.map((p) => p[1]);
    const left = Math.min(...xs),
      right = Math.max(...xs),
      top = Math.min(...ys),
      bottom = Math.max(...ys),
      span = right - left;
    if (right < 0 || left > width || bottom < 0 || top > height || span < 24) return null;
    const coverage = Math.min(right, width - left, bottom, height - top),
      alpha =
        depthVisibility(depth) *
        smooth((nearest - 0.5) / 3) *
        smooth((105 - depth) / 14) *
        smooth((span - 24) / 80) *
        smooth(coverage / 32);
    if (alpha <= 0) return null;
    // Three slices make the outlined glyphs visibly extruded. Each slice is
    // a genuine tilted world plane, not a screen-space translated banner.
    const cameraLayers = [-anchor.extrusion, -anchor.extrusion / 2, 0].map((z) =>
      uv.map(([u, v]) => view.camera(formulaWorldPoint(anchor, time, u, v, z)))
    );
    const transform = loopTransform(anchor, time);
    return {
      kind: 'formula',
      object: anchor.id,
      asset: anchor.id,
      points,
      cameraCorners,
      cameraLayers,
      focal: view.focal,
      origin: view.origin,
      depth,
      alpha,
      projection: {
        worldCenter: transform.center,
        rootCenter: anchor.rootCenter,
        worldCorners,
        corners: points,
        depth,
        pulse: transform.scale,
        clock: time,
        extrusion: anchor.extrusion,
        strategy: 'perspective-extruded',
        layers: 3,
        strips: 4,
      },
    };
  }
  function projectedFace(f, vertices, screen, project) {
    // Clipping changes vertex count. Sorting uses the continuous original face
    // centroid so an extra near-plane intersection cannot reorder it abruptly.
    const points = [],
      z = f.indices.reduce((sum, index) => sum + vertices[index][2], 0) / f.indices.length;
    for (const index of f.indices) {
      if (!screen[index]) {
        const clipped = clipPolygon(f.indices.map((j) => vertices[j]));
        if (clipped.length < 3) return null;
        return { points: clipped.map(project), depth: z };
      }
      points.push(screen[index]);
    }
    return { points, depth: z };
  }
  function appendObject(
    world,
    o,
    vertices,
    screen,
    project,
    visible,
    fade,
    shapes,
    eye,
    minArea = 0,
    pixelScale = Infinity
  ) {
    appendFaces(world, o, vertices, screen, project, visible, fade, shapes, eye, minArea);
    appendLines(world, o, vertices, screen, project, visible, fade, shapes, minArea, pixelScale);
  }
  function insignificantFace(points, alpha, minArea) {
    if (!minArea) return false;
    if (alpha < 1 / 512) return true;
    let area = 0;
    for (let j = 0; j < points.length; j++) {
      const a = points[j],
        b = points[(j + 1) % points.length];
      area += a[0] * b[1] - b[0] * a[1];
    }
    // A distant translucent facet can cover several pixels yet contribute less
    // than one pixel of ink. Bound effective coverage, retaining nearby volume.
    return Math.abs(area) * alpha < minArea * 2;
  }
  function appendFaces(world, o, vertices, screen, project, visible, fade, shapes, eye, minArea) {
    for (let i = o.firstFace; i < o.firstFace + o.faceCount; i++) {
      const f = world.faces[i],
        plane = f.plane;
      if (plane && plane[0] * eye[0] + plane[1] * eye[1] + plane[2] * eye[2] <= plane[3]) continue;
      const face = projectedFace(f, vertices, screen, project);
      if (!face) continue;
      const z = face.depth,
        projected = face.points;
      if (!visible(projected)) continue;
      const haze = depthVisibility(z) * fade;
      if (insignificantFace(projected, (f.opacity ?? 0.82) * haze, minArea)) continue;
      shapes.push({
        kind: 'face',
        points: projected,
        depth: z,
        color: f.color,
        band: f.band,
        object: f.object,
        material: i,
        tint: f.tint,
        fillColor: f.fillColor,
        alpha: (f.opacity ?? 0.82) * haze,
        edgeAlpha: (f.edgeAlpha ?? 0.36) * haze,
        lineWidth: z < 12 ? 1.25 : 0.85,
      });
    }
  }
  function appendLines(
    world,
    o,
    vertices,
    screen,
    project,
    visible,
    fade,
    shapes,
    minArea,
    pixelScale
  ) {
    for (let i = o.firstLine; i < o.firstLine + o.lineCount; i++) {
      const line = world.lines[i];
      // Only authored secondary marks fade below seven CSS pixels per model
      // unit. Main folds, every formula glyph and all series/points remain.
      const detailFade =
        line.minScale && pixelScale !== Infinity ? smooth(pixelScale - line.minScale) : 1;
      if (detailFade === 0) continue;
      const [a, b] = line.indices,
        unclipped = screen[a] && screen[b],
        clipped = unclipped ? [vertices[a], vertices[b]] : clipSegment(vertices[a], vertices[b]);
      if (!clipped) continue;
      const projected = unclipped ? [screen[a], screen[b]] : clipped.map(project),
        z = (clipped[0][2] + clipped[1][2]) / 2;
      if (!visible(projected)) continue;
      if (
        minArea &&
        Math.hypot(projected[1][0] - projected[0][0], projected[1][1] - projected[0][1]) < 0.5
      )
        continue;
      shapes.push({
        kind: 'line',
        points: projected,
        depth: z,
        object: line.object,
        color: line.color,
        material: i,
        alpha: (line.opacity ?? 0.65) * depthVisibility(z) * fade * detailFade,
        lineWidth: line.width ?? 1,
        arrow: line.arrow,
      });
    }
  }
  function blendColor(a, b, t) {
    const rgb = (hex) =>
      hex
        .replace('#', '')
        .match(/.{2}/g)
        .map((v) => parseInt(v, 16));
    return (
      '#' +
      lerp(rgb(a), rgb(b), t)
        .map((v) => Math.round(v).toString(16).padStart(2, '0'))
        .join('')
    );
  }
  const roomOffset = (page) => -Math.max(0, routeOrder.indexOf(page)) * roomSpacing;
  const translatePose = (pose, z) => ({
    position: add(pose.position, [0, 0, z]),
    target: add(pose.target, [0, 0, z]),
  });
  const routePose = (page, pose) => translatePose(pose, roomOffset(page));
  function routeDirection(from, to, paintedPose = null) {
    const sourceIndex = routeOrder.indexOf(from),
      targetIndex = routeOrder.indexOf(to);
    if (sourceIndex < 0 || targetIndex < 0) return null;
    const sourceDepth = paintedPose?.position?.[2],
      targetDepth = routePose(to, poses[initialPoses[to]]).position[2];
    // Retargets start at the last real paint, which may still be between rooms.
    // Equal depth uses the same ordered route contract as ordinary navigation.
    if (Number.isFinite(sourceDepth) && sourceDepth !== targetDepth)
      return targetDepth < sourceDepth ? 'forward' : 'backward';
    return targetIndex > sourceIndex ? 'forward' : 'backward';
  }
  return {
    loopTransform,
    cameraVertices,
    projectedWorld,
    projectedFace,
    projectedFormula,
    formulaWorldPoint,
    projectFormulaPoint,
    journeyPose,
    blendColor,
    routePose,
    routeDirection,
    roomOffset,
    translatePose,
  };
})(math,definitions);
const renderer=(function (artwork = null, createSurface = null) {
  // Exactly one immutable bitmap serves every Writing room/detail model. Its
  // intrinsic size never follows viewport/DPR, and no resource owns a clock.
  let formulaSurface = null,
    formulaAttempted = false,
    formulaBuilds = 0,
    formulaPaints = 0,
    formulaFailures = 0,
    formulaVisible = 0,
    formulaLastPaints = 0,
    formulaSubmissions = 0,
    formulaLastSubmissions = 0,
    formulaProjection = null;
  function formulaBitmap() {
    if (formulaAttempted) return formulaSurface;
    formulaAttempted = true;
    formulaBuilds++;
    try {
      if (!artwork || artwork.width !== 1380 || artwork.height !== 240)
        throw Error('bounded formula artwork unavailable');
      const surface = createSurface ? createSurface() : document.createElement('canvas');
      surface.width = artwork.width;
      surface.height = artwork.height;
      const target = surface.getContext('2d');
      if (!target) throw Error('formula cache unavailable');
      const gradient = target.createLinearGradient(...artwork.gradient.line);
      for (const [offset, color] of artwork.gradient.stops) gradient.addColorStop(offset, color);
      target.strokeStyle = gradient;
      target.lineCap = 'round';
      target.lineJoin = 'round';
      for (const glyph of artwork.paths) {
        target.beginPath();
        target.lineWidth = glyph.stroke;
        for (const [kind, ...values] of glyph.commands) {
          if (kind === 'M') target.moveTo(...values);
          else if (kind === 'L') target.lineTo(...values);
          else if (kind === 'C') target.bezierCurveTo(...values);
          else throw Error('unsupported compiled formula command');
        }
        target.stroke();
      }
      formulaSurface = surface;
    } catch {
      formulaFailures++;
      formulaSurface = null;
    }
    return formulaSurface;
  }
  function paintFormula(ctx, shape) {
    formulaVisible++;
    formulaProjection = shape.projection || null;
    const surface = formulaBitmap();
    if (!surface) return;
    let saved = false;
    try {
      ctx.save();
      saved = true;
      ctx.globalAlpha = shape.alpha;
      ctx.globalCompositeOperation = 'source-over';
      // Warped glyphs are minified; request the native high-quality sampling
      // path rather than the default bilinear texture sampling.
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      // A fixed four-strip mesh follows the projected world plane. Three
      // z-slices give the actual tilted glyphs thickness, using the same single
      // cache. This is one landmark with at most 24 native submissions, not
      // viewport-sized caches, per-glyph geometry or another animation clock.
      for (let layer = 0; layer < shape.cameraLayers.length; layer++) {
        // Shared world haze is sufficient. Extra translucent rear copies created
        // a pale halo around every stroke instead of a definite solid edge.
        ctx.globalAlpha = shape.alpha;
        const corners = shape.cameraLayers[layer];
        const at = (u, v) => {
          const top = corners[0].map((value, i) => value + (corners[1][i] - value) * u),
            bottom = corners[3].map((value, i) => value + (corners[2][i] - value) * u),
            p = top.map((value, i) => value + (bottom[i] - value) * v);
          return [
            shape.origin[0] + (p[0] * shape.focal) / p[2],
            shape.origin[1] - (p[1] * shape.focal) / p[2],
          ];
        };
        for (let strip = 0; strip < 4; strip++) {
          const u = strip / 4,
            U = (strip + 1) / 4,
            source = [
              [u * surface.width, 0],
              [U * surface.width, 0],
              [U * surface.width, surface.height],
              [u * surface.width, surface.height],
            ],
            points = [at(u, 0), at(U, 0), at(U, 1), at(u, 1)];
          for (const triangle of [
            [0, 1, 2],
            [0, 2, 3],
          ])
            paintFormulaTriangle(
              ctx,
              surface,
              triangle.map((i) => source[i]),
              triangle.map((i) => points[i])
            );
        }
      }
      formulaPaints++;
      formulaLastPaints++;
    } catch {
      formulaFailures++;
      formulaSurface = null;
    } finally {
      if (saved) ctx.restore();
    }
  }
  function paintFormulaTriangle(ctx, surface, source, points) {
    const [p, q, r] = source,
      [P, Q, R] = points,
      dx = q[0] - p[0],
      dy = q[1] - p[1],
      ex = r[0] - p[0],
      ey = r[1] - p[1],
      den = dx * ey - dy * ex;
    const a = ((Q[0] - P[0]) * ey - (R[0] - P[0]) * dy) / den,
      c = ((R[0] - P[0]) * dx - (Q[0] - P[0]) * ex) / den;
    const b = ((Q[1] - P[1]) * ey - (R[1] - P[1]) * dy) / den,
      d = ((R[1] - P[1]) * dx - (Q[1] - P[1]) * ex) / den;
    // Bound native resampling to this strip while keeping a two-CSS-pixel
    // neighbourhood in source x. The inverse affine x row is [d,-c]/det;
    // singular or extremely minified transforms safely use the whole bitmap.
    const determinant = Math.abs(a * d - b * c),
      guard =
        determinant > 1e-12
          ? Math.min(surface.width, Math.ceil((2 * Math.hypot(c, d)) / determinant))
          : surface.width;
    const left = Math.max(0, Math.min(p[0], q[0], r[0]) - guard),
      right = Math.min(surface.width, Math.max(p[0], q[0], r[0]) + guard);
    ctx.save();
    try {
      path(ctx, points);
      ctx.closePath();
      ctx.clip();
      ctx.transform(a, b, c, d, P[0] - a * p[0] - c * p[1], P[1] - b * p[0] - d * p[1]);
      ctx.drawImage(
        surface,
        left,
        0,
        right - left,
        surface.height,
        left,
        0,
        right - left,
        surface.height
      );
      formulaSubmissions++;
      formulaLastSubmissions++;
    } finally {
      ctx.restore();
    }
  }
  function formulaDiagnostics() {
    const width = formulaSurface?.width || 0,
      height = formulaSurface?.height || 0;
    return {
      status: formulaSurface ? 'ready' : formulaAttempted ? 'failed' : 'unused',
      cacheBuilds: formulaBuilds,
      width,
      height,
      bytes: width * height * 4,
      paintCount: formulaPaints,
      failures: formulaFailures,
      visibleCount: formulaVisible,
      lastPaintCount: formulaLastPaints,
      drawSubmissions: formulaSubmissions,
      lastDrawSubmissions: formulaLastSubmissions,
      projection: formulaProjection,
      attempts: formulaBuilds,
      builds: formulaSurface ? formulaBuilds : 0,
      failed: formulaFailures > 0,
      draws: formulaPaints,
      visible: formulaVisible > 0,
    };
  }
  function facePalette(faces, colors, cache) {
    const rgb = Object.fromEntries(
      Object.entries(colors).map(([key, hex]) => [
        key,
        hex
          .slice(1)
          .match(/.{2}/g)
          .map((value) => parseInt(value, 16)),
      ])
    );
    const paper = rgb.paper;
    return faces.map((face) => {
      const ink = rgb[face.fillColor || face.color],
        tint = face.tint;
      const red = Math.round(paper[0] + (ink[0] - paper[0]) * tint);
      const green = Math.round(paper[1] + (ink[1] - paper[1]) * tint);
      const blue = Math.round(paper[2] + (ink[2] - paper[2]) * tint);
      // Lighting tints vary continuously; the actual six-digit RGB result has
      // far fewer values. Cache that exact result without quantizing geometry,
      // tint arithmetic or the colors submitted to Canvas.
      const key = red * 65536 + green * 256 + blue;
      if (!cache.has(key)) {
        cache.set(key, '#' + key.toString(16).padStart(6, '0'));
        if (cache.size > 16384) cache.delete(cache.keys().next().value);
      }
      return cache.get(key);
    });
  }
  function path(ctx, points) {
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (let i = 1; i < points.length; i++) ctx.lineTo(points[i][0], points[i][1]);
  }
  function setPaintState(ctx, state, property, value) {
    if (state[property] === value) return;
    ctx[property] = value;
    state[property] = value;
  }
  function invalidatePaintState(state) {
    state.fillStyle = state.strokeStyle = state.lineWidth = state.globalAlpha = undefined;
  }
  function drawLineRun(ctx, shapes, index, colors, state) {
    const first = shapes[index],
      alpha = first.alpha;
    ctx.beginPath();
    setPaintState(ctx, state, 'lineWidth', first.lineWidth);
    setPaintState(ctx, state, 'strokeStyle', colors[first.color]);
    setPaintState(ctx, state, 'globalAlpha', alpha);
    let end = index;
    while (end < shapes.length) {
      const shape = shapes[end];
      if (
        shape.kind !== 'line' ||
        shape.arrow ||
        shape.color !== first.color ||
        shape.lineWidth !== first.lineWidth ||
        Math.abs(shape.alpha - alpha) > 1 / 256
      )
        break;
      const [from, to] = shape.points;
      ctx.moveTo(from[0], from[1]);
      ctx.lineTo(to[0], to[1]);
      end++;
    }
    ctx.stroke();
    return end - 1;
  }
  function paintShapes(ctx, shapes, colors, paintCustom = null) {
    formulaVisible = 0;
    formulaLastPaints = 0;
    formulaLastSubmissions = 0;
    formulaProjection = null;
    // Every paint starts unknown: resize or external drawing may reset native
    // state. A declining custom painter must leave the context untouched.
    const state = {};
    for (let index = 0; index < shapes.length; index++) {
      const shape = shapes[index];
      if (paintCustom?.(ctx, shape)) {
        invalidatePaintState(state);
        continue;
      }
      if (shape.kind === 'formula') {
        paintFormula(ctx, shape);
        invalidatePaintState(state);
        continue;
      }
      // Depth order is unchanged. Only adjacent compatible lines are batched.
      if (shape.kind === 'line' && !shape.arrow) {
        index = drawLineRun(ctx, shapes, index, colors, state);
        continue;
      }
      const points = shape.points,
        from = points[0],
        to = points[1];
      path(ctx, points);
      if (shape.kind === 'face') {
        const fill = shape.room.faceColors[shape.material];
        ctx.closePath();
        setPaintState(ctx, state, 'fillStyle', fill);
        setPaintState(ctx, state, 'globalAlpha', shape.alpha);
        ctx.fill();
        if (shape.edgeAlpha === 0) {
          setPaintState(ctx, state, 'strokeStyle', fill);
          setPaintState(ctx, state, 'lineWidth', 0.65);
          ctx.stroke();
        }
        // Explicit silhouettes survive; faint internal mesh edges are omitted
        // on desktop as on mobile. Thousands of invisible strokes cost time.
        else if (shape.room.world.faces[shape.material].edgeAlpha > 0.12) {
          setPaintState(ctx, state, 'lineWidth', shape.lineWidth);
          setPaintState(ctx, state, 'strokeStyle', colors[shape.color]);
          setPaintState(ctx, state, 'globalAlpha', shape.edgeAlpha);
          ctx.stroke();
        }
      } else {
        setPaintState(ctx, state, 'lineWidth', shape.lineWidth);
        setPaintState(ctx, state, 'strokeStyle', colors[shape.color]);
        setPaintState(ctx, state, 'globalAlpha', shape.alpha);
        ctx.stroke();
      }
      if (shape.arrow) {
        const dx = to[0] - from[0],
          dy = to[1] - from[1],
          length = Math.hypot(dx, dy);
        if (length < 10) continue;
        const size = 5,
          ux = dx / length,
          uy = dy / length;
        ctx.beginPath();
        ctx.moveTo(to[0] - ux * size - uy * size * 0.55, to[1] - uy * size + ux * size * 0.55);
        ctx.lineTo(...to);
        ctx.lineTo(to[0] - ux * size + uy * size * 0.55, to[1] - uy * size - ux * size * 0.55);
        ctx.stroke();
      }
    }
    setPaintState(ctx, state, 'globalAlpha', 1);
  }
  return {
    paintShapes,
    facePalette,
    formulaDiagnostics,
    prepareFormula: formulaBitmap,
    formulaReady: () => !!formulaSurface,
    formulaDrawn: () => formulaLastPaints > 0,
  };
})({
  "width": 1380,
  "height": 240,
  "gradient": {
    "line": [
      50,
      0,
      1330,
      0
    ],
    "stops": [
      [
        0,
        "#ff2535"
      ],
      [
        0.34,
        "#ff008e"
      ],
      [
        0.64,
        "#8500ff"
      ],
      [
        1,
        "#0063ff"
      ]
    ]
  },
  "paths": [
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          57,
          95
        ],
        [
          "C",
          54,
          125,
          53,
          158,
          72,
          159
        ],
        [
          "C",
          91,
          160,
          108,
          119,
          118,
          94
        ],
        [
          "M",
          118,
          94
        ],
        [
          "C",
          107,
          134,
          93,
          177,
          78,
          192
        ],
        [
          "C",
          68,
          202,
          57,
          201,
          50,
          194
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          163,
          116
        ],
        [
          "L",
          215,
          116
        ],
        [
          "M",
          160,
          141
        ],
        [
          "L",
          212,
          141
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          326,
          68
        ],
        [
          "C",
          304,
          54,
          287,
          73,
          281,
          100
        ],
        [
          "L",
          265,
          177
        ],
        [
          "C",
          262,
          194,
          253,
          199,
          243,
          193
        ],
        [
          "M",
          261,
          109
        ],
        [
          "L",
          311,
          109
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          363,
          62
        ],
        [
          "C",
          336,
          83,
          325,
          109,
          325,
          134
        ],
        [
          "C",
          325,
          159,
          334,
          181,
          349,
          196
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          382,
          99
        ],
        [
          "C",
          398,
          91,
          407,
          111,
          413,
          132
        ],
        [
          "C",
          420,
          154,
          432,
          168,
          446,
          158
        ],
        [
          "M",
          444,
          100
        ],
        [
          "C",
          426,
          118,
          403,
          145,
          381,
          162
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          474,
          62
        ],
        [
          "C",
          491,
          79,
          499,
          101,
          499,
          125
        ],
        [
          "C",
          499,
          153,
          484,
          179,
          459,
          196
        ]
      ]
    },
    {
      "stroke": 10,
      "commands": [
        [
          "M",
          546,
          128
        ],
        [
          "L",
          671,
          128
        ],
        [
          "M",
          650,
          109
        ],
        [
          "L",
          672,
          128
        ],
        [
          "L",
          650,
          147
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          711,
          95
        ],
        [
          "C",
          708,
          125,
          707,
          158,
          726,
          159
        ],
        [
          "C",
          745,
          160,
          762,
          119,
          772,
          94
        ],
        [
          "M",
          772,
          94
        ],
        [
          "C",
          761,
          134,
          747,
          177,
          732,
          192
        ],
        [
          "C",
          722,
          202,
          711,
          201,
          704,
          194
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          813,
          133
        ],
        [
          "C",
          824,
          112,
          836,
          115,
          848,
          128
        ],
        [
          "C",
          860,
          141,
          872,
          144,
          884,
          123
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          917,
          167
        ],
        [
          "L",
          940,
          64
        ],
        [
          "L",
          970,
          64
        ],
        [
          "C",
          1007,
          64,
          1018,
          112,
          975,
          122
        ],
        [
          "L",
          929,
          122
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          1058,
          62
        ],
        [
          "C",
          1031,
          83,
          1020,
          109,
          1020,
          134
        ],
        [
          "C",
          1020,
          159,
          1029,
          181,
          1044,
          196
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          1081,
          95
        ],
        [
          "C",
          1078,
          125,
          1077,
          158,
          1096,
          159
        ],
        [
          "C",
          1115,
          160,
          1132,
          119,
          1142,
          94
        ],
        [
          "M",
          1142,
          94
        ],
        [
          "C",
          1131,
          134,
          1117,
          177,
          1102,
          192
        ],
        [
          "C",
          1092,
          202,
          1081,
          201,
          1074,
          194
        ]
      ]
    },
    {
      "stroke": 10,
      "commands": [
        [
          "M",
          1175,
          79
        ],
        [
          "L",
          1175,
          180
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          1210,
          99
        ],
        [
          "C",
          1226,
          91,
          1235,
          111,
          1241,
          132
        ],
        [
          "C",
          1248,
          154,
          1260,
          168,
          1274,
          158
        ],
        [
          "M",
          1272,
          100
        ],
        [
          "C",
          1254,
          118,
          1231,
          145,
          1209,
          162
        ]
      ]
    },
    {
      "stroke": 14,
      "commands": [
        [
          "M",
          1304,
          62
        ],
        [
          "C",
          1321,
          79,
          1329,
          101,
          1329,
          125
        ],
        [
          "C",
          1329,
          153,
          1314,
          179,
          1289,
          196
        ]
      ]
    }
  ]
});
const api={...math,...definitions,...world,...projection,...renderer};
if(typeof module!=="undefined"&&module.exports)module.exports=api;
(function (api) {
  const {
    sub,
    mix,
    clamp,
    LOOP_MS,
    rates,
    owns,
    atmosphereState,
    cadenceFor,
    nextDeadline,
    cameraView,
    poses,
    initialPoses,
    routeOrder,
    roomSpacing,
    worldFor,
    projectedWorld,
    paintShapes,
    routePose,
    routeDirection,
    roomOffset,
    translatePose,
  } = api;
  if (typeof document === 'undefined') return;
  // The serialized route source also serves native navigation without Canvas.
  window.SiteRoutes = Object.freeze({
    order: Object.freeze([...routeOrder]),
    direction: routeDirection,
  });
  const canvas = document.getElementById('space-canvas');
  const control = document.getElementById('space-motion');
  if (!canvas || !control || !window.matchMedia || !window.requestAnimationFrame) return;
  let ctx;
  try {
    ctx = canvas.getContext('2d');
  } catch {
    return;
  }
  if (!ctx) return;
  const scene = canvas.parentElement;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const narrow = window.matchMedia('(max-width: 640px)');
  let page = document.body.dataset.page;
  const key = 'vo.motion';
  let choice = null;
  try {
    choice = localStorage.getItem(key);
  } catch {
    /* In-tab controls remain useful. */
  }
  let enabled = choice !== 'off' && !reduced.matches,
    printing = false,
    pending = null,
    initialized = false,
    failed = false;
  // Deferred scripts run while readyState is interactive. Archive filtering
  // and the navigation content plane must finish before the first layout read.
  let domReady = document.readyState !== 'loading' && document.readyState !== 'interactive';
  let width = 1,
    height = 1,
    ratio = 1;
  const initial = initialPoses[page] || 'overview';
  const rooms = new Map();
  let compact = narrow.matches,
    ambientTime = 0,
    lastFrame = null,
    nextDraw = null;
  let preparationDrawDeadline = null;
  let layoutDirty = true,
    layoutReasons = new Set(['initial']),
    layoutPasses = 0;
  let idleRate = 30,
    costAverage = 0,
    costSamples = 0,
    cadenceSlow = 0,
    cadenceFast = 0,
    lastCadenceChange = 0,
    detailTier = 0,
    displayedTier = 0;
  let tier = 0,
    slow = 0,
    fast = 0,
    lastQualityChange = 0,
    hold = false;
  const clock = () => window.performance?.now() ?? Date.now();
  let current = routePose(page, poses[initial]),
    displayedTime = 0,
    displayedCamera = current,
    displayedWidth = width,
    displayedHeight = height,
    displayedCompact = compact,
    painted = false,
    displayedProgress = 0,
    journey = null;
  let travelUpdate = null;
  let travelAnchor = null;
  let travelSourceAnchor = null;
  let travelSourcePage = page;
  let travelStartedAt = 0;
  let colors = { cyan: '#075d7b', amber: '#895710', paper: '#f8f7f3' };
  let paletteRevision = 0,
    colorFills = new Map();
  const settledPose = () => routePose(page, poses[initialPoses[page] || 'overview']);
  const effects = window.SiteEffects;
  if (effects && effects.contract !== 1) throw Error('Incompatible scene effect contract');
  effects?.registerView?.(cameraView);
  const sceneEffects = effects?.scene?.({
    ...api,
    // Content belongs to the same immutable branch descriptors and bounded
    // room cache as the projected fractal, under its existing ambient clock.
    worldForRoom: (route) => roomFor(route).world,
  });
  // The decorative mobile bitmap uses one physical pixel per CSS pixel.
  // Text and controls retain their native resolution; timing is independent.
  const pixelRatio = () =>
    Math.min(compact || tier === 2 ? 1 : tier === 1 ? 1.25 : 1.5, window.devicePixelRatio || 1);
  function measure() {
    const read = () => measureNative();
    if (effects?.measure) return effects.measure(read);
    return read();
  }
  function measureNative() {
    let stage = window.SiteEngineStages ? clock() : 0;
    const span = (part) => {
      if (stage) {
        const time = clock();
        diagnostic('stage', { part, start: stage, duration: time - stage });
        stage = time;
      }
    };
    layoutPasses++;
    width = Math.max(1, window.innerWidth);
    height = Math.max(1, window.innerHeight);
    ratio = pixelRatio();
    const maxScroll = Math.max(0, document.documentElement.scrollHeight - height);
    window.SiteNavigation?.reconcileEndpoint?.(maxScroll);
    span('layout-range');
  }
  function flushLayout() {
    if (!initialized || !layoutDirty || failed) return;
    // During departure the engine already owns the next route, while the old
    // DOM is still shown. Its geometry cannot describe the destination.
    if (document.body.dataset.page !== page) return;
    layoutDirty = false;
    const reasons = [...layoutReasons];
    layoutReasons.clear();
    const start = window.SiteEngineProbe ? clock() : 0;
    measure();
    if (window.SiteEngineProbe)
      diagnostic('layout', {
        reasons,
        passes: layoutPasses,
        start,
        duration: clock() - start,
      });
    // Native landing and layout belong to the router. Neither reading position
    // nor content reflow can change the route's settled camera or flight target.
    nextDraw = null;
  }
  function invalidateLayout(reason) {
    layoutDirty = true;
    layoutReasons.add(reason);
    if (failed) {
      window.SiteNavigation?.reconcileEndpoint?.();
      return;
    }
    if (!initialized) {
      initialize();
      return;
    }
    if (!failed) schedule();
  }
  // Opt-in measurements emit no timing/JSON work on an ordinary visitor path.
  function diagnostic(kind, detail) {
    window.SiteEngineProbe?.({ kind, time: clock(), page, ...detail });
  }
  function readColors() {
    const css = window.getComputedStyle(document.documentElement);
    const next = {
      cyan: css.getPropertyValue('--accent').trim(),
      amber: css.getPropertyValue('--systems').trim(),
      paper: css.getPropertyValue('--paper').trim(),
      sheet: (css.getPropertyValue('--scene-sheet') || '#fffefa').trim(),
    };
    if (!Object.values(next).every((v) => /^#[0-9a-f]{6}$/i.test(v))) return false;
    colors = next;
    paletteRevision++;
    colorFills.clear();
    return true;
  }
  function paintColors(room) {
    const start = window.SiteEngineStages ? clock() : 0;
    room.faceColors = api.facePalette(room.world.faces, colors, colorFills);
    room.paletteRevision = paletteRevision;
    if (start)
      diagnostic('stage', {
        part: 'model-color',
        route: room.name,
        start,
        duration: clock() - start,
      });
  }
  function roomFor(name, detail = compact || detailTier >= 0.5) {
    // Reduce actual model/paint work on a slow desktop as well as on mobile.
    // The same motif IDs, macro positions and recursive topology survive.
    if (!rooms.has(name)) {
      while (rooms.size >= 3) {
        const oldest = [...rooms.keys()].find((id) => id !== page && id !== name);
        rooms.delete(oldest);
      }
      rooms.set(name, new Map());
    }
    const variants = rooms.get(name);
    if (!variants.has(detail)) {
      const start = window.SiteEngineProbe ? clock() : 0;
      const room = {
        world: worldFor(name, detail),
        name,
        compact: detail,
        faceColors: [],
      };
      variants.set(detail, room);
      // Prepare once during the existing room work, never inside timed paint.
      if (name === 'writing') api.prepareFormula?.();
      if (window.SiteEngineStages)
        diagnostic('stage', {
          part: 'model-build',
          route: name,
          start,
          duration: clock() - start,
        });
      paintColors(room);
      if (window.SiteEngineProbe)
        diagnostic('model', {
          route: name,
          compact: detail,
          start,
          duration: clock() - start,
          objects: room.world.objects.length,
          vertices: room.world.objects.reduce((n, o) => n + o.points.length, 0),
          faces: room.world.faces.length,
          lines: room.world.lines.length,
        });
    }
    rooms.delete(name);
    rooms.set(name, variants);
    while (rooms.size > 3) {
      const oldest = [...rooms.keys()].find((id) => id !== page && id !== name);
      rooms.delete(oldest);
    }
    const room = variants.get(detail);
    if (room.paletteRevision !== paletteRevision) paintColors(room);
    return room;
  }
  function schedule() {
    if (initialized && !failed && pending === null && !document.hidden && !printing)
      pending = window.requestAnimationFrame(frame);
  }
  function cancel() {
    if (pending !== null) window.cancelAnimationFrame(pending);
    pending = null;
    lastFrame = null;
    nextDraw = null;
    preparationDrawDeadline = null;
    ambientTime = displayedTime;
    current = displayedCamera;
    detailTier = displayedTier;
    if (journey) {
      rebaseJourney(journey.to, displayedProgress);
      journey.started = false;
    }
  }
  function visibleRooms() {
    if (!journey) {
      const room = roomFor(page);
      const shapes = projectedWorld(
        room.world,
        translatePose(current, -roomOffset(page)),
        width,
        height,
        ambientTime,
        detailTier,
        true,
        false
      );
      for (const shape of shapes) shape.room = room;
      return shapes;
    }
    // Render at most the two rooms around the camera, including intermediate
    // rooms on a multi-page flight. Models are lazy and the cache is bounded.
    const near = Math.max(
      0,
      Math.min(routeOrder.length - 1, Math.floor((24 - current.position[2]) / roomSpacing))
    );
    const names = [routeOrder[near], routeOrder[Math.min(near + 1, routeOrder.length - 1)]];
    const active = [...new Set(names)];
    const shapes = active.flatMap((name) => {
      // Entire room envelope behind the camera cannot contribute geometry.
      const local = translatePose(current, -roomOffset(name));
      const forward = api.normalize(sub(local.target, local.position));
      if (api.dot(sub([0, 0, -48], local.position), forward) + 110 < 0.5) return [];
      const room = roomFor(name);
      return projectedWorld(
        room.world,
        translatePose(current, -roomOffset(name)),
        width,
        height,
        ambientTime,
        detailTier,
        true,
        false
      ).map((shape) => {
        shape.room = room;
        return shape;
      });
    });
    return shapes;
  }
  function draw() {
    let stage = window.SiteEngineStages ? clock() : 0;
    const span = (part) => {
      if (stage) {
        const time = clock();
        diagnostic('stage', { part, start: stage, duration: time - stage });
        stage = time;
      }
    };
    // Resize only inside the protected paint, retaining the last valid bitmap.
    const w = Math.round(width * ratio),
      h = Math.round(height * ratio);
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, width, height);
    const state = {
      current,
      width,
      height,
      ambientTime,
      compact,
      scene,
      detailTier,
      page,
      colors,
      journey,
    };
    const geometry = visibleRooms();
    span('draw-project');
    const custom = sceneEffects?.collect(state) || [];
    span('draw-effects');
    const shapes = geometry.concat(custom).sort((a, b) => b.depth - a.depth);
    span('draw-sort');
    paintShapes(ctx, shapes, colors, sceneEffects?.paint);
    span('draw-paint');
    const air = atmosphereState(ambientTime);
    scene.style?.setProperty('--air-x', air.x.toFixed(3) + 'px');
    scene.style?.setProperty('--air-y', air.y.toFixed(3) + 'px');
    scene.style?.setProperty('--air-light', air.light.toFixed(5));
    ctx.globalAlpha = 1;
    scene.dataset.ready = 'true';
    displayedTime = ambientTime;
    displayedCamera = current;
    displayedWidth = width;
    displayedHeight = height;
    displayedCompact = compact;
    painted = true;
    displayedTier = detailTier;
    displayedProgress = journeyProgress();
    scene.dataset.phase = String(ambientTime);
    scene.dataset.camera = JSON.stringify(current);
    scene.dataset.detail = String(detailTier);
    scene.dataset.route = page;
    scene.dataset.travel = journey ? 'flying' : 'settled';
    scene.dataset.rooms = String(rooms.size);
    scene.dataset.geometry = compact || detailTier >= 0.5 ? 'compact' : 'full';
    scene.dataset.roomModels = String(
      [...rooms.values()].reduce((count, variants) => count + variants.size, 0)
    );
    span('draw-state');
    if (window.SiteEngineProbe) {
      diagnostic('paint', {
        current,
        ambientTime,
        width,
        height,
        compact,
        detailTier,
        journey,
        ordinaryShapes: geometry.length,
        customShapes: custom.length,
      });
    }
  }
  function fail() {
    failed = true;
    cancel();
    delete scene.dataset.ready;
    scene.dataset.state = 'fallback';
    control.hidden = false;
    control.disabled = true;
    control.setAttribute('aria-pressed', 'false');
    control.textContent = 'Motion: unavailable';
    reportTravel(1);
  }
  function reportTravel(progress) {
    scene.dataset.progress = String(progress);
    const update = travelUpdate;
    if (!update) return;
    const active = enabled && !hold && !failed && !printing && !document.hidden && !reduced.matches;
    const capturedAt = clock();
    // Route notification may precede a paint or complete an unavailable scene.
    // Snapshot only the last successful paint, never a newer layout/solver state.
    // The router's callback closure owns the transaction; this adds no clock/cache.
    const pose = Object.freeze({
      position: Object.freeze([...displayedCamera.position]),
      target: Object.freeze([...displayedCamera.target]),
    });
    const projection = cameraView(pose, displayedWidth, displayedHeight, displayedCompact);
    for (const axis of ['forward', 'right', 'up', 'origin']) Object.freeze(projection[axis]);
    const completed = update(
      progress,
      Object.freeze({
        progress,
        pose,
        width: displayedWidth,
        height: displayedHeight,
        compact: displayedCompact,
        projection: Object.freeze(projection),
        anchor: travelAnchor,
        sourceAnchor: travelSourceAnchor,
        fromRoute: travelSourcePage,
        toRoute: page,
        direction: scene.dataset.direction,
        remainingMs: journey ? Math.max(0, journey.duration - journey.elapsed) : 0,
        capturedAt,
        travelElapsedMs: Math.max(0, capturedAt - travelStartedAt),
        painted,
        active,
      })
    );
    // The existing painted clock may own a bounded presentation tail after the
    // camera has settled. Legacy callbacks retain their immediate completion.
    if (progress === 1 && (completed !== false || !active) && travelUpdate === update)
      travelUpdate = null;
  }
  function adaptCadence(cost, time) {
    // Ignore the one-time initial paint for cadence estimation. Adapt to actual
    // cost before considering a slower detail tier; retain a strict mobile idle
    // share with headroom. Sustained votes/cooldown prevent threshold oscillation.
    if (costSamples++ > 0) {
      costAverage = costAverage === 0 ? cost : costAverage * 0.8 + cost * 0.2;
      const desired = cadenceFor(costAverage, compact);
      if (desired < idleRate) {
        cadenceSlow++;
        cadenceFast = 0;
      } else if (desired > idleRate && costAverage * desired < (compact ? 0.145 : 0.32) * 1000) {
        cadenceFast++;
        cadenceSlow = 0;
      } else cadenceSlow = cadenceFast = 0;
      if (cadenceSlow >= 5 && time - lastCadenceChange >= 400) {
        idleRate = desired;
        lastCadenceChange = time;
        cadenceSlow = cadenceFast = 0;
        nextDraw = null;
      } else if (cadenceFast >= 60 && time - lastCadenceChange >= 2500) {
        idleRate = rates[rates.indexOf(idleRate) - 1];
        lastCadenceChange = time;
        cadenceSlow = cadenceFast = 0;
        nextDraw = null;
      }
    }
  }
  function quality(cost, time) {
    adaptCadence(cost, time);
    scene.dataset.cadence = String(idleRate);
    if (cost > 25) {
      slow++;
      fast = 0;
    } else if (cost < 10) {
      fast++;
      slow = Math.max(0, slow - 1);
    } else {
      slow = Math.max(0, slow - 1);
      fast = 0;
    }
    if (time - lastQualityChange < 2500) return;
    if (slow >= 8 && tier < 2) {
      tier++;
      slow = fast = 0;
      lastQualityChange = time;
      ratio = pixelRatio();
    } else if (slow >= 16 && tier === 2 && cost > 50) {
      const arrival = journey?.to;
      hold = true;
      cancel();
      // A device hold completes an explicitly requested route with one still
      // destination paint. User Off/hidden/print still freeze the exact frame.
      if (arrival) {
        current = arrival;
        journey = null;
        schedule();
      } else if (travelUpdate) reportTravel(1);
      updateControl();
    } else if (fast >= 100 && tier > 0) {
      tier--;
      ratio = pixelRatio();
      slow = fast = 0;
      lastQualityChange = time;
    }
    scene.dataset.quality = hold ? 'still' : String(tier);
  }
  function journeyProgress() {
    return journey
      ? journey.progressStart +
          (1 - journey.progressStart) * clamp(journey.elapsed / journey.duration)
      : 1;
  }
  function rebaseJourney(target, progress = journeyProgress()) {
    // Pause/cancellation resumes from the actual displayed camera, preserving
    // the remaining flight duration and monotonically painted progress.
    const segment = clamp(
        (progress - journey.progressStart) / Math.max(1e-12, 1 - journey.progressStart)
      ),
      remaining = Math.max(1, journey.duration * (1 - segment));
    journey = {
      from: current,
      to: target,
      elapsed: 0,
      duration: remaining,
      progressStart: progress,
      started: journey.started,
    };
  }
  function advanceJourney(delta, living) {
    if (journey && living) {
      // A cold room preparation cannot consume the new flight before its first
      // displayed frame. Ambient time still advances on the shared RAF clock.
      if (journey.started) journey.elapsed += delta;
      else journey.started = true;
      const t = clamp(journey.elapsed / journey.duration);
      // Eased suffix of the original global progress. Cancelling its squared
      // remaining factor avoids numerical division near arrival and keeps
      // retargets moving instead of restarting smooth() at zero velocity.
      const remainder = 1 - journey.progressStart,
        v = 1 - t,
        eased = 1 - (v * v * (3 - 2 * remainder * v)) / (3 - 2 * remainder);
      current = mix(journey.from, journey.to, eased);
      if (t === 1) {
        current = journey.to;
        journey = null;
      }
    }
  }
  function frame(time) {
    pending = null;
    if (document.hidden || printing || !initialized || failed) return;
    try {
      flushLayout();
    } catch {
      fail();
      return;
    }
    const living = enabled && !hold && owns(initialPoses, page);
    if (painted && living && !reduced.matches && !journey && sceneEffects?.preparing?.()) {
      // A settled frame remains visible while native paint is captured. The
      // same RAF observes completion without charging capture wall time to
      // the ambient clock or competing with its bounded raster work.
      lastFrame = time;
      if (preparationDrawDeadline === null) preparationDrawDeadline = time + 100;
      if (time < preparationDrawDeadline) {
        schedule();
        return;
      }
      // Stalled or chained captures still receive an ordinary paint at least
      // once per 100ms burst plus the existing RAF/rendering interval.
      preparationDrawDeadline = time + 100;
      nextDraw = null;
    } else preparationDrawDeadline = null;
    const delta = lastFrame === null ? 0 : Math.min(80, Math.max(0, time - lastFrame));
    lastFrame = time;
    if (living) {
      ambientTime = (ambientTime + delta) % LOOP_MS;
      detailTier += (tier - detailTier) * (1 - Math.exp(-delta / 180));
    }
    advanceJourney(delta, living);
    // Camera response gets a temporary, cost-bounded higher cadence. Deadlines
    // retain fractional phase instead of rounding every frame down to 20/15Hz.
    const cameraRate = Math.min([30, 20, 15][tier], cadenceFor(costAverage, compact, true));
    const interval = 1000 / (journey || window.SiteEffects?.embedded?.active?.() ? Math.max(idleRate, cameraRate) : idleRate);
    if (nextDraw === null || time + 0.5 >= nextDraw || !living) {
      const start = clock();
      try {
        draw();
      } catch {
        fail();
        return;
      }
      const renderCost = clock() - start;
      // Text follows the painted camera, including skipped frames and stalls.
      if (travelUpdate) reportTravel(journeyProgress());
      nextDraw = nextDeadline(nextDraw, time, interval);
      // Decorative quality responds to rendering cost. The entire callback,
      // including route mount, is still measured by the outer frame/ready gate.
      if (living) quality(renderCost, time);
    }
    if (living && !hold) schedule();
  }
  function updateControl() {
    if (failed) return;
    control.hidden = false;
    control.disabled = reduced.matches;
    control.setAttribute('aria-pressed', String(enabled && !hold));
    control.textContent = reduced.matches
      ? 'Motion: reduced'
      : !enabled
        ? 'Motion: off'
        : hold
          ? 'Motion: still (device)'
          : 'Motion: on';
  }
  function preferenceChanged() {
    const was = enabled;
    enabled = choice !== 'off' && !reduced.matches;
    if (enabled && !was) {
      lastFrame = null;
    }
    if (!enabled) {
      if (was) cancel();
    }
    updateControl();
    schedule();
    if (window.dispatchEvent) window.dispatchEvent(new CustomEvent('site:motion-preference'));
  }
  control.addEventListener('click', () => {
    choice = enabled ? 'off' : 'on';
    if (choice === 'on' && hold) {
      hold = false;
      slow = fast = 0;
      lastFrame = null;
    }
    try {
      localStorage.setItem(key, choice);
    } catch {
      /* In-tab preference still applies. */
    }
    preferenceChanged();
  });
  const resize = () => {
    if (failed) return;
    if (compact !== narrow.matches) compact = narrow.matches;
    if (!initialized) {
      initialize();
      return;
    }
    invalidateLayout('resize');
  }; // Layout never changes a frozen camera/ambient phase or starts a flight.
  window.addEventListener('site:archive-layout', resize);
  window.addEventListener('resize', resize, { passive: true });
  window.addEventListener('load', resize, { once: true });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) cancel();
    else resize();
  });
  window.addEventListener('beforeprint', () => {
    printing = true;
    cancel();
  });
  window.addEventListener('afterprint', () => {
    printing = false;
    resize();
  });
  if (reduced.addEventListener) reduced.addEventListener('change', preferenceChanged);
  window.addEventListener('storage', (event) => {
    if (event.key === key || event.key === null) {
      try {
        choice = localStorage.getItem(key);
      } catch {
        choice = null;
      }
      preferenceChanged();
    }
  });
  if (window.MutationObserver)
    new window.MutationObserver(() => {
      if (!initialized) {
        initialize();
        return;
      }
      if (!failed && readColors()) schedule();
    }).observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['data-theme'],
    });
  const observer = window.ResizeObserver
    ? new window.ResizeObserver(() => invalidateLayout('size'))
    : null;
  const contentObserver = window.MutationObserver
    ? new window.MutationObserver(() => invalidateLayout('content'))
    : null;
  let observedMain = null;
  function observeLayout() {
    const main = document.querySelector('main');
    if (main === observedMain) return;
    observedMain = main;
    observer?.disconnect();
    contentObserver?.disconnect();
    // Body also covers an expanded footer/header. Subtree edits cover moving
    // interior waypoints even when the total main height stays unchanged.
    observer?.observe(document.body);
    observer?.observe(main);
    contentObserver?.observe(main, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['hidden', 'class', 'style', 'data-space-stop'],
    });
  }
  observeLayout();
  document.fonts?.addEventListener?.('loadingdone', resize);
  window.SiteScene = {
    managesLayout: true,
    canTravel: () =>
      initialized &&
      !failed &&
      enabled &&
      !reduced.matches &&
      !hold &&
      !printing &&
      !document.hidden,
    direction: (next) => routeDirection(document.body.dataset.page, next, displayedCamera),
    navigate(next, animate = true, update = null) {
      if (!owns(initialPoses, next)) return;
      travelStartedAt = clock();
      // Media-query state can change before its queued change event is delivered.
      if (reduced.matches && enabled) {
        enabled = false;
        cancel();
        updateControl();
      }
      const from = displayedCamera,
        sourcePage = document.body.dataset.page;
      page = next;
      const travelling = animate && this.canTravel(),
        target = settledPose();
      current = from;
      displayedProgress = 0;
      scene.dataset.direction = routeDirection(sourcePage, page, from);
      if (travelling) {
        journey = {
          from,
          to: target,
          elapsed: 0,
          duration: Math.min(1700, 1000 + Math.abs(target.position[2] - from.position[2]) * 2),
          progressStart: 0,
          started: false,
        };
      } else {
        journey = null;
        current = target;
      }
      scene.dataset.travel = journey ? 'flying' : 'settled';
      travelUpdate = update;
      travelAnchor = null;
      travelSourceAnchor = null;
      travelSourcePage = sourcePage;
      // Prepare the bounded source/target working set at its settled detail
      // before either can be painted in flight. Avoid a visible downgrade and
      // post-arrival rebuild; mobile/adaptive compact detail still applies.
      // Probe costs remain part of input-to-ready evidence.
      if (journey) {
        try {
          const sourceRoot = roomFor(sourcePage).world.objects.find(
            (object) => object.rootCenter
          )?.rootCenter;
          if (sourceRoot)
            travelSourceAnchor = Object.freeze([
              sourceRoot[0],
              sourceRoot[1],
              sourceRoot[2] + roomOffset(sourcePage),
            ]);
          const root = roomFor(page).world.objects.find((object) => object.rootCenter)?.rootCenter;
          if (root) travelAnchor = Object.freeze([root[0], root[1], root[2] + roomOffset(page)]);
        } catch {
          fail();
          return;
        }
      }
      reportTravel(journey ? 0 : 1);
      observeLayout();
      nextDraw = null;
      schedule();
    },
    refresh({ sync = false, reason = 'mount' } = {}) {
      observeLayout();
      invalidateLayout(reason);
      if (sync) flushLayout();
    },
    formulaDiagnostics: () => api.formulaDiagnostics?.() || null,
    diagnostics() {
      return {
        rooms: [...rooms].map(([route, variants]) => ({
          route,
          models: [...variants].map(([compact, room]) => ({
            compact,
            serializedChars: JSON.stringify(room.world).length,
            formulaAnchors: room.world.formulas?.length || 0,
          })),
        })),
        paletteEntries: colorFills.size,
        layoutPasses,
        formula: api.formulaDiagnostics?.() || null,
      };
    },
    detachTravel() {
      travelUpdate = null;
    },
  };
  // Stylesheet load/error is authoritative, including early WebKit deferral.
  function initialize() {
    if (!domReady || initialized || failed || !readColors()) return;
    measure();
    layoutDirty = false;
    layoutReasons.clear();
    initialized = true;
    scene.dataset.state = 'active';
    updateControl();
    schedule();
  }
  const stylesheet = document.querySelector('link[rel="stylesheet"]');
  stylesheet?.addEventListener?.('load', initialize, { once: true });
  stylesheet?.addEventListener?.(
    'error',
    () => {
      if (!initialized) fail();
    },
    { once: true }
  );
  canvas.addEventListener?.('contextlost', fail);
  if (!domReady)
    document.addEventListener(
      'DOMContentLoaded',
      () => {
        domReady = true;
        initialize();
      },
      { once: true }
    );
  initialize();
})(api);
})();
