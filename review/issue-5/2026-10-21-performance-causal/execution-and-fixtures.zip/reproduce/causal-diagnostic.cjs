'use strict';
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const os = require('node:os');
const { createRequire } = require('node:module');
const { pathToFileURL } = require('node:url');
const { execFileSync } = require('node:child_process');
const base = '/workspace/scratch/38e8b0c92238';
const source = path.join(base, 'pr79-perf-final');
const input = path.join(base, 'pr79-perf-artifact/public');
const out = path.join(base, 'pr79-perf-causal-diagnostic');
if (fs.existsSync(out)) throw Error('Fresh output directory required');
fs.mkdirSync(out);
const sha = (data) => crypto.createHash('sha256').update(data).digest('hex');
const git = (...args) => execFileSync('git', args, {cwd:source, encoding:'utf8'}).trim();
const req = createRequire(path.join(base, 'pr79/tools/quality/toolchain/package.json'));
const { start } = require(path.join(source, 'tools/quality/serve.cjs'));
const article = 'articles/ai-changes-both-sides-of-software-engineering.html';
const original = fs.readFileSync(path.join(input, article), 'utf8');
const cases = {
  baseline: (s) => s,
  'lazy-images': (s) => s.replace(/<img\b/g, '<img loading="lazy"'),
  'without-scene': (s) => s.replace(/<script\b[^>]*src="[^"]*\/space\.js"[^>]*><\/script>/g, ''),
  'without-navigation': (s) => s.replace(/<script\b[^>]*src="[^"]*\/navigation\.js"[^>]*><\/script>/g, ''),
};
const manifest = JSON.parse(fs.readFileSync(path.join(base, 'pr79-perf-artifact/artifact.json')));
const state = {
  schema:1, role:'Causal diagnostic only; altered temporary fixtures are not verified release artifacts or acceptance PASS',
  sourceCommit:git('rev-parse','HEAD'), sourceTree:git('rev-parse','HEAD^{tree}'), sourceDirtyBefore:!!git('status','--porcelain'),
  measuredFrozenSite:{commit:manifest.sourceCommit, tree:manifest.sourceTree, publicDigest:manifest.artifactDigest},
  startedAt:new Date().toISOString(), scriptSha256:sha(fs.readFileSync(__filename)),
  browser:'/tmp/chromium',browserSha256:sha(fs.readFileSync('/tmp/chromium')),node:process.version,
  cpus:os.availableParallelism(), scenarioDefinitions:{
    baseline:'Exact unchanged frozen article and assets',
    'lazy-images':'Only add loading=lazy to all8 article img tags; this blanket diagnostic is not the final responsive/visible-image policy',
    'without-scene':'Remove only space.js script tag; deliberately loses interactive scene, for attribution only, not proposed visual acceptance',
    'without-navigation':'Remove only navigation.js script tag; deliberately loses reader/router enhancements, for attribution only, not proposed acceptance',
  },
  declaredOrder:[['baseline','lazy-images','without-scene','without-navigation'],['without-navigation','without-scene','lazy-images','baseline'],['lazy-images','baseline','without-navigation','without-scene']],
  noAutomaticRetries:true, trials:[], fixtures:{},
};
if(state.sourceDirtyBefore)throw Error('Source dirty');
const save=()=>fs.writeFileSync(path.join(out,'execution.json'),JSON.stringify(state,null,2)+'\n');
async function main(){
  const {default:lighthouse}=await import(pathToFileURL(req.resolve('lighthouse')).href);
  const launcher=await import(pathToFileURL(req.resolve('chrome-launcher')).href);
  const running={};
  try{
    for(const [name,transform] of Object.entries(cases)){
      const publicDir=path.join(out,'fixtures',name);
      fs.cpSync(input,publicDir,{recursive:true});
      const html=transform(original);if(name!=='baseline'&&html===original)throw Error('No mutation '+name);
      fs.writeFileSync(path.join(publicDir,article),html);
      state.fixtures[name]={articleSha256:sha(html),originalSha256:sha(original),imgTags:(html.match(/<img\b/g)||[]).length};
      running[name]=await start({publicDir,localOnly:true});
    }
    save();
    for(let round=0;round<state.declaredOrder.length;round++)for(const name of state.declaredOrder[round]){
      const row={scenario:name,round:round+1,startedAt:new Date().toISOString()};
      state.trials.push(row);save();
      const chrome=await launcher.launch({chromePath:'/tmp/chromium',chromeFlags:['--headless','--no-sandbox','--disable-dev-shm-usage']});
      try{
        const result=await lighthouse(running[name].url+'/'+article,{port:chrome.port,output:'json',logLevel:'error',onlyCategories:['performance','accessibility','best-practices']});
        const label=name+'-'+(round+1);const lhr=result.lhr;
        fs.writeFileSync(path.join(out,label+'.json'),JSON.stringify(lhr,null,2)+'\n');
        for(const key of ['Trace','DevtoolsLog'])fs.writeFileSync(path.join(out,label+'-'+key.toLowerCase()+'.json.gz'),zlib.gzipSync(JSON.stringify(result.artifacts[key])+'\n'));
        const metrics=Object.fromEntries(['first-contentful-paint','largest-contentful-paint','total-blocking-time','cumulative-layout-shift','speed-index'].map(k=>[k,lhr.audits[k].numericValue]));
        Object.assign(row,{finishedAt:new Date().toISOString(),metrics,performanceScore:lhr.categories.performance.score,warnings:lhr.runWarnings,runtimeError:lhr.runtimeError??null,configSettings:lhr.configSettings,lighthouseVersion:lhr.lighthouseVersion,environment:lhr.environment,report:label+'.json'});
        console.log(JSON.stringify({scenario:name,round:round+1,...metrics}));
      }finally{await chrome.kill();save();}
    }
    state.complete=true;
  }catch(error){state.error=error.stack;throw error;}
  finally{
    for(const v of Object.values(running))v.server.close();
    state.sourceDirtyAfter=!!git('status','--porcelain');state.finishedAt=new Date().toISOString();save();
  }
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
