'use strict';
// Hosting additions stay outside docs/ and cannot silently rewrite tested bytes.
const assert = require('node:assert/strict'),
  fs = require('node:fs'),
  path = require('node:path');
const artifact = require('../quality/artifact.cjs'),
  snapshot = require('../site/snapshot.cjs');
const publicFiles = [
  '.nojekyll',
  'index.html',
  'research.html',
  'writing.html',
  'talks.html',
  'credits.html',
  'styles.css',
  'theme.js',
  'space.js',
  'archive.js',
  'navigation.js',
  'assets/favicon.svg',
  'assets/vitalii-oborskyi.jpg',
  'assets/vitalii-oborskyi-cutout.webp',
].sort();
const headers = `/*
  X-Robots-Tag: noindex, nofollow
  Cache-Control: no-cache, max-age=0, must-revalidate
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=()
  Content-Security-Policy: base-uri 'self'; frame-ancestors 'none'; object-src 'none'
/runtime/*
  ! Cache-Control
  Cache-Control: public, max-age=31536000, immutable
/media/*
  ! Cache-Control
  Cache-Control: public, max-age=31536000, immutable
/snapshots/*
  ! Cache-Control
  Cache-Control: public, max-age=31536000, immutable
/article-media/*
  ! Cache-Control
  Cache-Control: public, max-age=31536000, immutable
/article-snapshots/*
  ! Cache-Control
  Cache-Control: public, max-age=31536000, immutable
`;
const legacyHeaders = headers.slice(0, headers.indexOf('/article-media/*'));
const notFound =
  '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Page not found · Vitalii Oborskyi</title><link rel="stylesheet" href="/styles.css"><main class="wrap" id="main"><h1>Page not found</h1><p>This address does not exist in this review version.</p><p><a href="/">Home</a> · <a href="/research.html">Research</a> · <a href="/writing.html">Writing</a> · <a href="/talks.html">Talks</a> · <a href="/credits.html">Credits</a></p></main></html>\n';
const identityKeys = ['sourceCommit', 'sourceTree', 'candidateCommit', 'artifactDigest'];
const hostPolicies = Object.freeze({
  legacy: 'legacy',
  snapshotProxy: 'immutable-snapshot-proxy-v1',
});
function selectedHostPolicy(value) {
  assert.ok(Object.values(hostPolicies).includes(value), 'unknown staging host policy');
  return value;
}
function snapshotProxyRules(source) {
  const names = Object.keys(source.files);
  snapshot.inventory(
    names,
    snapshot.legacyMediaFiles,
    source.edition?.id,
    source.components?.articles || {}
  );
  const immutable = names
    .filter((name) => name.startsWith('snapshots/') && snapshot.immutable(name))
    .sort();
  assert.ok(immutable.length > 0, 'missing admitted immutable snapshot HTML');
  return (
    immutable
      .map((name) => {
        // Proxy to the existing canonical lookup, not back to an .html path.
        // The index lookup requires its directory to avoid another redirect.
        const destination = name.endsWith('/index.html')
          ? name.slice(0, -'index.html'.length)
          : name.slice(0, -'.html'.length);
        return '/' + name + ' /' + destination + ' 200';
      })
      .join('\n') + '\n'
  );
}
function sourceGate(source, gate, expected = {}) {
  assert.equal(source.schema, 1);
  assert.equal(source.sourceDirty, false, 'dirty source');
  assert.match(source.sourceCommit, /^[0-9a-f]{40}$/);
  assert.match(source.sourceTree, /^[0-9a-f]{40}$/);
  assert.equal(source.candidateCommit, source.sourceCommit, 'candidate/source mismatch');
  snapshot.inventory(
    Object.keys(source.files),
    snapshot.legacyMediaFiles,
    source.edition?.id,
    source.components?.articles || {}
  );
  assert.equal(gate.schema, 1);
  assert.equal(gate.pass, true, 'Source package proof did not pass');
  if (gate.kind === 'package-gate') {
    assert.equal(gate.profile, 'package');
    assert.equal(gate.sourceTestsRun, false);
    for (const key of ['fullGate', 'productionEligible', 'deploymentAuthorized'])
      assert.equal(gate[key], false, 'package proof cannot authorize ' + key);
    assert.deepEqual(gate.checks, [
      'generated source',
      'artifact snapshot integrity',
      'size budgets',
    ]);
  } else {
    assert.equal(gate.kind, 'pr-gate');
    assert.notEqual(gate.profile, 'package', 'package profile requires its narrow proof kind');
  }
  for (const key of identityKeys) assert.equal(gate[key], source[key], 'gate identity ' + key);
  for (const job of gate.kind === 'package-gate' || gate.profile === 'local'
    ? ['build']
    : ['build', 'static', 'linux'])
    assert.equal(gate.jobs[job]?.result, 'success', 'missing successful ' + job);
  if (expected.sourceCommit)
    assert.equal(source.sourceCommit, expected.sourceCommit, 'wrong candidate');
  if (expected.publicDigest)
    assert.equal(source.artifactDigest, expected.publicDigest, 'wrong public digest');
  if (expected.artifactId)
    assert.equal(
      String(gate.githubArtifact?.id),
      String(expected.artifactId),
      'wrong tested artifact ID'
    );
  if (expected.uploadDigest)
    assert.equal(
      gate.githubArtifact?.uploadDigest,
      expected.uploadDigest,
      'wrong tested archive digest'
    );
}
function additions(source, hostPolicy = hostPolicies.legacy) {
  selectedHostPolicy(hostPolicy);
  const revision = {
    schema: 1,
    scope: 'staging only; not production release',
    sourceCommit: source.sourceCommit,
    sourceTree: source.sourceTree,
    publicDigest: source.artifactDigest,
  };
  return {
    _headers: Object.keys(source.files).some((file) =>
      /^(?:article-media|article-snapshots)\//.test(file)
    )
      ? headers
      : legacyHeaders,
    ...(source.files['404.html'] ? {} : { '404.html': notFound }),
    '_staging/revision.json': JSON.stringify(revision, null, 2) + '\n',
    ...(hostPolicy === hostPolicies.snapshotProxy
      ? { _redirects: snapshotProxyRules(source) }
      : {}),
  };
}
function policyHeaders(name) {
  if (/^(?:snapshots|article-snapshots)\/[a-f0-9]{64}\/[a-z][a-z0-9-]*$/.test(name)) {
    name += '.html';
  }
  const common = Object.fromEntries(
    headers
      .split('/runtime/*')[0]
      .trim()
      .split('\n')
      .slice(1)
      .map((line) => {
        const i = line.indexOf(':');
        return [line.slice(0, i).trim(), line.slice(i + 1).trim()];
      })
  );
  if (snapshot.immutable(name)) common['Cache-Control'] = 'public, max-age=31536000, immutable';
  return common;
}
function checkLinks(dir) {
  const admitted = Object.keys(artifact.manifest(dir).files);
  for (const document of admitted.filter((name) => name.endsWith('.html'))) {
    const html = fs.readFileSync(path.join(dir, document), 'utf8');
    for (const match of html.matchAll(/\b(?:href|src)="([^"]+)"/g)) {
      const url = new URL(match[1].replaceAll('&amp;', '&'), 'https://staging.invalid/' + document);
      if (url.origin !== 'https://staging.invalid') continue;
      const file = decodeURIComponent(url.pathname).replace(/^\//, '') || 'index.html';
      assert.ok(admitted.includes(file), 'unknown local destination ' + file);
      assert.ok(fs.existsSync(path.join(dir, file)), 'missing local destination ' + file);
      if (url.hash && file.endsWith('.html')) {
        const target = decodeURIComponent(url.hash.slice(1)),
          destination = fs.readFileSync(path.join(dir, file), 'utf8');
        assert.ok(
          destination.includes('id="' + target + '"'),
          'missing fragment ' + file + url.hash
        );
      }
    }
  }
}
function publicationRequired(source, revision) {
  // Derive the discriminator from verified public bytes. Optional manifest
  // metadata cannot relabel a licensed Color artifact as a historical family.
  const motion = require('../quality/color-motion-contract.cjs');
  const licensed = [
    'issue5-reader-deferred-media-plain',
    'issue5-reader-deferred-media-staging',
    'issue5-reader-deferred-media-production',
    'issue5-reader-loading-plain',
    'issue5-reader-loading-staging',
    'issue5-reader-loading-production',
    'issue5-reader-paper-plain',
    'issue5-reader-paper-staging',
    'issue5-reader-paper-production',
    'issue5-reader-fast-media-plain',
    'issue5-reader-fast-media-staging',
    'issue5-reader-fast-media-production',
    'issue5-reader-staging-plain',
    'issue5-reader-staging-staging',
    'issue5-reader-staging-production',
    'issue5-reader-motion-plain',
    'issue5-reader-motion-staging',
    'issue5-reader-motion-production',
    'issue5-reader-interactions-plain',
    'issue5-reader-interactions-staging',
    'issue5-reader-interactions-production',
    'issue5-reader-visible-blocks-plain',
    'issue5-reader-visible-blocks-staging',
    'issue5-reader-visible-blocks-production',
    'issue5-reader-block-elements-plain',
    'issue5-reader-block-elements-staging',
    'issue5-reader-block-elements-production',
    'issue5-reader-blocks-plain',
    'issue5-reader-blocks-staging',
    'issue5-reader-blocks-production',
    'issue5-editorial-reader-plain',
    'issue5-editorial-reader-staging',
    'issue5-editorial-reader-production',
    'issue5-calm-reader-plain',
    'issue5-calm-reader-staging',
    'issue5-calm-reader-production',
    'issue5-reader-mode-plain',
    'issue5-reader-mode-staging',
    'issue5-reader-mode-production',
    'issue5-real-article-plain',
    'issue5-real-article-staging',
    'issue5-real-article-production',
    'issue5-delivery-main-plain',
    'issue5-delivery-main-staging',
    'issue5-delivery-main-production',
    'issue5-delivery-plain',
    'issue5-delivery-staging',
    'issue5-delivery-production',
    'issue5-reader-orbit-plain',
    'issue5-reader-orbit-staging',
    'issue5-reader-orbit-production',
    'issue5-reader-native-history-plain',
    'issue5-reader-native-history-staging',
    'issue5-reader-native-history-production',
    'issue5-reader-flight-plain',
    'issue5-reader-flight-staging',
    'issue5-reader-flight-production',
    'issue106-reader-corrections-plain',
    'issue106-reader-corrections-staging',
    'issue106-reader-corrections-production',
    'issue106-reader-materials-plain',
    'issue106-reader-materials-staging',
    'issue106-reader-materials-production',
    'issue5-publication-tags-plain',
    'issue5-publication-tags-staging',
    'issue5-publication-tags-production',
    'issue5-tag-history-plain',
    'issue5-tag-history-staging',
    'issue5-tag-history-production',
    'issue5-generic-reader-plain',
    'issue5-generic-reader-staging',
    'issue5-generic-reader-production',
    'issue5-reader-resources-plain',
    'issue5-reader-resources-staging',
    'issue5-reader-resources-production',
    'issue5-reconciled-plain',
    'issue5-reconciled-staging',
    'issue5-reconciled-production',
    'issue39-licensed-plain',
    'issue39-licensed-staging',
    'issue39-licensed-production',
    'issue39-licensed-compact-plain',
    'issue39-licensed-compact-staging',
    'issue39-licensed-compact-production',
    'issue39-writing-tbt-plain',
    'issue39-writing-tbt-staging',
    'issue39-writing-tbt-production',
    'issue39-css-clock-plain',
    'issue39-css-clock-staging',
    'issue39-css-clock-production',
  ].map(motion.reviewedRuntime);
  const knownBytes = licensed.some(
    (runtime) =>
      runtime.variant.fingerprint === revision.engine ||
      Object.entries(runtime.files).every(
        ([name, sha256]) => source.files?.[name]?.sha256 === sha256
      )
  );
  const actual = { components: revision };
  if (!knownBytes && require('../quality/common.cjs').variant(actual).id !== 'color') return false;
  const candidate = { ...source, components: revision };
  const runtime = motion.select(candidate);
  return licensed.some((reviewed) => reviewed.id === runtime.id);
}
function publicationRights(publicDirectory, source, report, revision) {
  const actualRevision = revision || snapshot.verify(publicDirectory, source);
  if (!publicationRequired(source, actualRevision) && report === undefined) return null;
  assert.ok(report, 'licensed publication rights record required');
  assert.deepEqual(source.components, actualRevision, 'publication runtime metadata differs');
  const rights = require('../release/rights-record.cjs');
  rights.publication(source, report);
  rights.copies(publicDirectory, source, report);
  return report;
}
function build(input, out, expected = {}, options = {}) {
  assert.ok(options && typeof options === 'object' && !Array.isArray(options));
  assert.ok(
    Object.keys(options).every((key) =>
      ['hostPolicy', 'publication', 'requireCheckout'].includes(key)
    ),
    'unknown host policy option'
  );
  for (const key of ['publication', 'requireCheckout'])
    if (Object.hasOwn(options, key)) assert.equal(typeof options[key], 'boolean');
  const hostPolicy = selectedHostPolicy(
    Object.hasOwn(options, 'hostPolicy') ? options.hostPolicy : hostPolicies.legacy
  );
  const source = JSON.parse(fs.readFileSync(path.join(input, 'artifact.json'))),
    gate = JSON.parse(fs.readFileSync(path.join(input, 'gate/release-manifest.json')));
  sourceGate(source, gate, expected);
  artifact.verify(path.join(input, 'public'), source);
  const revision = snapshot.verify(path.join(input, 'public'), source);
  checkLinks(path.join(input, 'public'));
  const rightsFile = path.join(input, 'rights.json');
  const rights =
    options.publication || publicationRequired(source, revision)
      ? require('../release/rights.cjs').readPublication(input, source, undefined, {
          verifySource: true,
          requireCheckout: options.requireCheckout === true,
        })
      : publicationRights(
          path.join(input, 'public'),
          source,
          fs.existsSync(rightsFile) ? JSON.parse(fs.readFileSync(rightsFile)) : undefined,
          revision
        );
  fs.mkdirSync(out, { recursive: true });
  assert.equal(fs.readdirSync(out).length, 0, 'staging output must be empty');
  const target = path.join(out, 'public');
  fs.cpSync(path.join(input, 'public'), target, { recursive: true });
  const extra = additions(source, hostPolicy);
  for (const [name, text] of Object.entries(extra)) {
    const file = path.join(target, name);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, text);
  }
  const combined = artifact.manifest(target),
    record = {
      schema: 1,
      kind: 'staging-package',
      ...(hostPolicy === hostPolicies.snapshotProxy ? { hostPolicy } : {}),
      source,
      gate,
      hostFiles: Object.keys(extra).sort(),
      files: combined.files,
      packageDigest: combined.artifactDigest,
      ...(rights ? { rights, rightsDigest: rights.inventoryDigest } : {}),
    };
  fs.writeFileSync(path.join(out, 'staging-package.json'), JSON.stringify(record, null, 2) + '\n');
  verify(out, record, expected);
  return record;
}
function verify(dir, record, expected = {}) {
  assert.equal(record.schema, 1);
  assert.equal(record.kind, 'staging-package');
  const hostPolicy = Object.hasOwn(record, 'hostPolicy')
    ? selectedHostPolicy(record.hostPolicy)
    : hostPolicies.legacy;
  if (Object.hasOwn(record, 'hostPolicy'))
    assert.equal(hostPolicy, hostPolicies.snapshotProxy, 'legacy host policy must remain implicit');
  sourceGate(record.source, record.gate, expected);
  if (Object.hasOwn(record, 'rights') || Object.hasOwn(record, 'rightsDigest')) {
    assert.equal(
      record.rightsDigest,
      record.rights?.inventoryDigest,
      'staging rights digest differs'
    );
    require('../release/rights-record.cjs').publication(record.source, record.rights);
  }
  const target = path.join(dir, 'public'),
    actual = artifact.manifest(target),
    extra = additions(record.source, hostPolicy);
  assert.equal(actual.artifactDigest, record.packageDigest, 'staging package changed');
  assert.deepEqual(actual.files, record.files);
  assert.deepEqual(record.hostFiles, Object.keys(extra).sort());
  assert.deepEqual(
    Object.keys(actual.files).sort(),
    [...Object.keys(record.source.files), ...Object.keys(extra)].sort(),
    'unrecorded deployment input'
  );
  for (const file of Object.keys(record.source.files))
    assert.deepEqual(
      actual.files[file],
      record.source.files[file],
      'rewritten tested public file ' + file
    );
  for (const [file, text] of Object.entries(extra))
    assert.equal(
      fs.readFileSync(path.join(target, file), 'utf8'),
      text,
      'host configuration changed ' + file
    );
  const revision = snapshot.verify(target, record.source);
  publicationRights(target, record.source, record.rights, revision);
  checkLinks(target);
  return true;
}
function expectedEnvironment() {
  return {
    sourceCommit: process.env.SITE_CANDIDATE_SHA,
    publicDigest: process.env.SITE_EXPECTED_PUBLIC_DIGEST,
    artifactId: process.env.SITE_ARTIFACT_ID,
    uploadDigest: process.env.SITE_UPLOAD_DIGEST,
  };
}
if (require.main === module) {
  const [mode, input, out] = process.argv.slice(2),
    expected = expectedEnvironment();
  if (mode === 'build')
    console.log(
      JSON.stringify(
        build(path.resolve(input), path.resolve(out), expected, {
          hostPolicy: hostPolicies.snapshotProxy,
          publication: true,
          requireCheckout: true,
        })
      )
    );
  else if (mode === 'verify')
    verify(
      path.resolve(input),
      JSON.parse(fs.readFileSync(path.join(input, 'staging-package.json'))),
      expected
    );
  else throw Error('Usage: package.cjs build INPUT EMPTY_OUTPUT | verify OUTPUT');
}
module.exports = {
  publicFiles,
  headers,
  policyHeaders,
  notFound,
  hostPolicies,
  snapshotProxyRules,
  sourceGate,
  publicationRequired,
  publicationRights,
  additions,
  checkLinks,
  build,
  verify,
  expectedEnvironment,
};
