from pathlib import Path
import subprocess,json,datetime,os,sys,hashlib
root=Path('/workspace/scratch/38e8b0c92238/pr79-opt');base=root.parent;out=base/'pr79-opt-r20-functional-execution';out.mkdir(exist_ok=False)
q=os.environ['OPT_SOURCE']
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==q and git('status','--porcelain')==''
env={**os.environ,'OPT_ARTIFACT_DIR':str(base/'pr79-opt-r20-artifact'),'OPT_RESULTS_DIR':str(base/'pr79-opt-r20-functional'),'SITE_AUDIT_TOOLS':str(root/'tools/quality/toolchain'),'SITE_AUDIT_CHROME':'/tmp/chromium'}
commands=[('functional',['node',str(base/'pr79-opt-r20-browser-smoke.cjs')]),('print-inspection',[os.environ.get('CODEX_PRIMARY_RUNTIME_PYTHON','python3'),str(base/'pr79-opt-print-inspect.py'),str(base/'pr79-opt-r20-functional')]),('maintained-article-journey',['node',str(base/'pr79-opt-r20-article-journey.cjs')])]
rows=[]
for name,cmd in commands:
 row={'name':name,'command':cmd,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row)
 (out/'execution.json').write_text(json.dumps({'source':q,'tree':git('rev-parse','HEAD^{tree}'),'sourceDirty':bool(git('status','--porcelain')),'rows':rows,'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:sys.exit(r.returncode)
assert git('status','--porcelain')==''
print('Exact-source functional and maintained journeys passed',flush=True)
