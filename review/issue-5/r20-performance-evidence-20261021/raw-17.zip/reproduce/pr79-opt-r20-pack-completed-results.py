from pathlib import Path
import json, hashlib, zipfile, zlib, datetime, subprocess

base = Path('/workspace/scratch/38e8b0c92238')
root = base / 'pr79-opt'
dest = base / 'pr79-opt-r20-evidence-prepared'
q = '3e12e47953bc8c81316544b1da206a956a337307'
tree = '728b7aee4dcdc3627b1327f90d8df64971d2d816'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == q
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) == b''
execution = json.loads((base / 'pr79-opt-r20-continuation/execution.json').read_text())
assert 'finishedAt' in execution
assert execution['sourceCommit'] == q and execution['sourceTree'] == tree
dest.mkdir(exist_ok=False)
files = {}

def add(path, name):
    assert path.is_file(), str(path)
    assert name not in files, name
    files[name] = path

# Retain complete raw attempts, diagnostic fixtures and exact generated inputs.
for folder in sorted(base.glob('pr79-opt-r20-*')):
    if not folder.is_dir() or folder.name in {'pr79-opt-checkout-temp', dest.name}:
        continue
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            add(path, folder.name.removeprefix('pr79-opt-') + '/' + path.relative_to(folder).as_posix())
for path in sorted(base.glob('pr79-opt-r20-*')):
    if path.is_file() and path.suffix in {'.log', '.json', '.py', '.cjs', '.md'}:
        add(path, ('reproduce/' if path.suffix in {'.py', '.cjs'} else 'preparation/') + path.name)
add(Path('/tmp/pr79-opt-browser-smoke.cjs'), 'reproduce/reader-loading-functional.cjs')
add(base/'pr79-opt-independent-resume-review.md','preparation/independent-resume-review.md')
add(base/'pr79-opt-native-readback/independent-native-readback.json','preparation/q4-native-readback.json')
for name in [
    'tools/quality/performance.cjs', 'tools/quality/lighthouse.cjs', 'tools/quality/motion.cjs',
    'tools/quality/reader-performance.cjs', 'tools/quality/validate.cjs', 'tools/quality/budgets.json',
    'tools/quality/color-motion-contract.cjs', 'tools/quality/article-browser.cjs',
    'tools/site/reader.cjs', 'tools/staging/package.cjs', 'site/engine/navigation.js',
    'site/engine/renderer.cjs', 'review/issue-5/2026-10-21-reader-loading.md',
]:
    add(root / name, 'source/' + name)
manifest = {
    'schema': 2, 'sourceCommit': q, 'sourceTree': tree,
    'priorEvidenceCommit': '4c021989b43a9c748f6c29fcb34c1e713abd3557',
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'deduplication': 'Every logical file maps to a byte-identical ZIP member by SHA256; no trial or result is dropped.',
    'archives': [], 'members': [], 'files': [],
}
archive = None
estimated = 0
index = 0
maximum = 3500000
by_hash = {}
for name, path in sorted(files.items()):
    data = path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    if sha in by_hash:
        member = by_hash[sha]
        assert len(data) == member['bytes']
    else:
        estimate = len(zlib.compress(data, 9)) + len(name.encode()) * 2 + 180
        assert estimate + 22 <= maximum, (name, estimate)
        if archive is None or estimated + estimate > maximum:
            if archive:
                archive.close()
            index += 1
            archive = zipfile.ZipFile(dest / f'raw-{index:02d}.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9)
            estimated = 22
        info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data, compresslevel=9)
        estimated += estimate
        member = {'path': name, 'archive': f'raw-{index:02d}.zip', 'bytes': len(data), 'sha256': sha}
        manifest['members'].append(member)
        by_hash[sha] = member
    manifest['files'].append({'path': name, 'archive': member['archive'], 'member': member['path'], 'bytes': len(data), 'sha256': sha})
if archive:
    archive.close()
for path in sorted(dest.glob('raw-*.zip')):
    data = path.read_bytes()
    assert len(data) <= maximum
    manifest['archives'].append({'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    with zipfile.ZipFile(path) as zipped:
        assert zipped.testzip() is None
        expected = [member for member in manifest['members'] if member['archive'] == path.name]
        assert zipped.namelist() == [member['path'] for member in expected]
        for member in expected:
            data = zipped.read(member['path'])
            assert len(data) == member['bytes'] and hashlib.sha256(data).hexdigest() == member['sha256']
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'archives': len(manifest['archives']), 'uniqueMembers': len(manifest['members']), 'allLogicalFiles': len(manifest['files']), 'compressedBytes': sum(item['bytes'] for item in manifest['archives'])}))
