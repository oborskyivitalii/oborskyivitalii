from pathlib import Path
import subprocess,json,datetime,os,hashlib,sys
root=Path('/workspace/scratch/38e8b0c92238/pr79-opt'); artifact=root.parent/'pr79-opt-r20-artifact'; out=root.parent/'pr79-opt-r20-performance'; q=os.environ['OPT_SOURCE']
def git(*a): return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==q and git('status','--porcelain')==''
m=json.loads((artifact/'artifact.json').read_text());assert m['sourceCommit']==q and not m['sourceDirty']
assert json.loads((root.parent/'pr79-opt-r20-source-checks/execution.json').read_text())['rows'][-1]['name']=='python-toolchain'
assert json.loads((root.parent/'pr79-opt-r20-article-journey/article-journey.json').read_text())['pass']
assert json.loads((root.parent/'pr79-opt-r20-functional/functional.json').read_text())['pass']
out.mkdir(exist_ok=False)
env={**os.environ,'SITE_PUBLIC_DIR':str(artifact/'public'),'SITE_ARTIFACT_MANIFEST':str(artifact/'artifact.json'),'SITE_REPORT_DIR':str(out),'SITE_AUDIT_TOOLS':str(root/'tools/quality/toolchain'),'SITE_AUDIT_CHROME':'/tmp/chromium'}
record={'sourceCommit':q,'sourceTree':git('rev-parse','HEAD^{tree}'),'sourceDirtyBefore':False,'artifactDigest':m['artifactDigest'],'artifactManifestSha256':hashlib.sha256((artifact/'artifact.json').read_bytes()).hexdigest(),'command':['node','tools/quality/performance.cjs'],'environment':{k:env[k] for k in ['SITE_PUBLIC_DIR','SITE_ARTIFACT_MANIFEST','SITE_REPORT_DIR','SITE_AUDIT_TOOLS','SITE_AUDIT_CHROME']},'browserSha256':hashlib.sha256(Path('/tmp/chromium').read_bytes()).hexdigest(),'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print('Declared complete performance matrix started: '+q,flush=True)
with (out/'wrapper.log').open('x') as log:r=subprocess.run(record['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceDirtyAfter=bool(git('status','--porcelain')))
(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);sys.exit(r.returncode)
