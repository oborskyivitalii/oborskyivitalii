from pathlib import Path
import json, hashlib

base=Path('/workspace/scratch/38e8b0c92238')
p=base/'pr79-opt-r20-performance'
load=lambda f:json.loads(f.read_text())
a=load(p/'lighthouse/lighthouse.json');m=load(p/'motion/motion.json');r=load(p/'reader-performance/reader-performance.json');s=load(p/'performance-suite.json');e=load(p/'execution.json')
assert s['pass'] and a['pass'] and m['pass'] and r['pass']
assert e['sourceCommit']=='3e12e47953bc8c81316544b1da206a956a337307' and not e['sourceDirtyBefore'] and not e['sourceDirtyAfter']
metric=lambda row,k:row['metrics'][k]['numericValue']
rows=a['rows']+r['rows'];medians=a['medians']+r['lighthouse']['medians']
for row in medians:
 group=[x for x in rows if x['route']==row['route'] and x['formFactor']==row['profile']]
 row['maxLcpMs']=max(metric(x,'largest-contentful-paint') for x in group)
 row['maxTbtMs']=max(metric(x,'total-blocking-time') for x in group)
profiles=[]
for width,rate in [(1440,1),(390,1),(390,4)]:
 group=[x for x in m['samples']+r['samples'] if x['width']==width and x['rate']==rate]
 profiles.append({'width':width,'rate':rate,'samples':len(group),'maxPaintP95Ms':max(x['paintCallbackMs']['p95'] for sample in group for x in sample['measurements'][:2]),'maxIdleBusyPercent':max(x['measurements'][0]['callbackBusyPercent'] for x in group),'zeroCallbacks':sum(x['callbacks'] for sample in group for x in sample['measurements'][2:]),'zeroPaints':sum(x['paints'] for sample in group for x in sample['measurements'][2:])})
flights=[]
for j in m['journeys']:
 flights.append({'width':j['width'],'rate':j['rate'],'flights':len(j['rows']),'paintP95MaxMs':max(x['paintCallbackMs']['p95'] for x in j['rows']),'paintMaxMs':max(x['paintCallbackMs']['max'] for x in j['rows']),'preparationMaxMs':max(x['preparationMs']['max'] for x in j['rows']),'paintGapMaxMs':max(x['paintIntervalsMs']['max'] for x in j['rows']),'readyMaxMs':max(x['readyMs'] for x in j['rows']),'equivalentReadyMaxMs':max(x['equivalentReadyMs'] for x in j['rows']),'cycles':j['cycles'],'before':j['before'],'after':j['after']})
network=[]
for raw in sorted((p/'reader-performance').glob('lighthouse-reader-*.json')):
 d=load(raw);items=d['audits']['network-requests']['details']['items']
 network.append({'path':raw.name,'sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'images':len([x for x in items if x.get('resourceType')=='Image']),'imageTransferBytes':sum(x.get('transferSize',0) for x in items if x.get('resourceType')=='Image'),'totalTransferBytes':sum(x.get('transferSize',0) for x in items),'warnings':d['runWarnings']})
soak={k:v for k,v in m['soak'].items() if k not in ['chunks','off']}
soak['chunks']=len(m['soak']['chunks']);soak['observedSeconds']=sum(x['elapsedMs'] for x in m['soak']['chunks'])/1000;soak['off']={k:m['soak']['off'][k] for k in ['callbacks','paints','elapsedMs']}
summary={'sourceCommit':e['sourceCommit'],'sourceTree':e['sourceTree'],'artifactDigest':e['artifactDigest'],'variant':s['variant'],'pass':True,'execution':e,'counts':{'lighthouse':len(rows),'shortMotionWindows':sum(len(x['measurements']) for x in m['samples']+r['samples']),'flights':sum(len(j['rows']) for j in m['journeys']),'retentionCycles':sum(j['cycles'] for j in m['journeys']),'zeroWorkWindows':sum(len(x['measurements'][2:]) for x in m['samples']+r['samples'])},'medians':medians,'motionProfiles':profiles,'flights':flights,'soak':soak,'readerNetwork':network,'readerMobileLcpValues':[metric(x,'largest-contentful-paint') for x in r['rows'] if x['formFactor']=='mobile'],'singleTbtBudgetExceedances':[{'route':x['route'],'formFactor':x['formFactor'],'run':x['run'],'tbtMs':metric(x,'total-blocking-time')} for x in rows if metric(x,'total-blocking-time')>200]}
(base/'pr79-opt-r20-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
fmt=lambda x:f'{x:.3f}'.rstrip('0').rstrip('.')
table='| Сторінка / профіль | LCP median, мс | LCP max, мс | TBT median / max, мс | CLS median | Score median |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'
for x in medians:
 z=x['metrics'];table+=f"| {x['route']} / {x['profile']} | {fmt(z['largest-contentful-paint'])} | {fmt(x['maxLcpMs'])} | {fmt(z['total-blocking-time'])} / {fmt(x['maxTbtMs'])} | {z['cumulative-layout-shift']:.6f} | {round(x['performance']*100)} |\n"
mt='| Ширина / CPU | Профілі | Максимальний paint p95, мс | Максимальний idle busy | Off / Reduced callbacks та paints |\n| --- | ---: | ---: | ---: | --- |\n'
for x in profiles:mt+=f"| {x['width']} / ×{x['rate']} | {x['samples']} | {fmt(x['maxPaintP95Ms'])} | {fmt(x['maxIdleBusyPercent'])}% | {x['zeroCallbacks']} / {x['zeroPaints']} |\n"
ft='| Ширина / CPU | Перельоти | paint p95 / max, мс | preparation max, мс | gap max, мс | ready фактичний / equivalent max, мс | nodes до → після | listeners до → після |\n| --- | ---: | ---: | ---: | ---: | ---: | --- | --- |\n'
for x in flights:ft+=f"| {x['width']} / ×{x['rate']} | {x['flights']} | {fmt(x['paintP95MaxMs'])} / {fmt(x['paintMaxMs'])} | {fmt(x['preparationMaxMs'])} | {fmt(x['paintGapMaxMs'])} | {fmt(x['readyMaxMs'])} / {fmt(x['equivalentReadyMaxMs'])} | {x['before']['nodes']} → {x['after']['nodes']} | {x['before']['jsEventListeners']} → {x['after']['jsEventListeners']} |\n"
(base/'pr79-opt-r20-result-tables.md').write_text(table+'\n'+mt+'\n'+ft)
print(json.dumps({'counts':summary['counts'],'mobileLcp':summary['readerMobileLcpValues'],'soakObservedSeconds':soak['observedSeconds']}))
