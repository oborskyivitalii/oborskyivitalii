from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

base = Path('/workspace/scratch/38e8b0c92238')
root = base / 'pr79-opt'
prior = base / 'pr79-opt-r20-performance'
out = base / 'pr79-opt-r20-continuation'
original = json.loads((prior / 'execution.json').read_text())
env = {**os.environ, **original['environment']}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

assert git('rev-parse', 'HEAD') == original['sourceCommit']
assert git('status', '--porcelain') == ''
assert hashlib.sha256(Path(env['SITE_AUDIT_CHROME']).read_bytes()).hexdigest() == original['browserSha256']
assert hashlib.sha256(Path(env['SITE_ARTIFACT_MANIFEST']).read_bytes()).hexdigest() == original['artifactManifestSha256']
lh = json.loads((prior / 'lighthouse/lighthouse.json').read_text())
assert lh['pass'] and len(lh['rows']) == 30
assert lh['sourceCommit'] == original['sourceCommit']
out.mkdir(exist_ok=False)
record = {
    'sourceCommit': original['sourceCommit'], 'sourceTree': original['sourceTree'],
    'artifactDigest': original['artifactDigest'], 'sourceDirtyBefore': False,
    'startedAt': now(), 'priorAttempt': str(prior),
    'reason': 'Prior process disappeared without completion receipt after 30 Lighthouse trials, 15 motion samples and one flight profile. Preserve all prior files; reuse only completed Lighthouse. Restart incomplete motion stage once, then execute reader stage sequentially.',
    'priorWrapperComplete': False, 'rows': [],
    'environment': {k: env[k] for k in original['environment']},
}

def save():
    (out / 'execution.json').write_text(json.dumps(record, indent=2) + '\n')

save()
verification = "const a=require('./tools/quality/artifact.cjs');a.verify(process.env.SITE_PUBLIC_DIR,JSON.parse(require('node:fs').readFileSync(process.env.SITE_ARTIFACT_MANIFEST)));"
subprocess.run(['node', '-e', verification], cwd=root, env=env, check=True)
record['artifactVerifiedBefore'] = True
save()
for check in ['motion', 'reader-performance']:
    folder = out / check
    folder.mkdir()
    check_env = {**env, 'SITE_REPORT_DIR': str(folder)}
    row = {'check': check, 'startedAt': now(), 'command': ['node', f'tools/quality/{check}.cjs']}
    record['rows'].append(row)
    save()
    print('Starting ' + check, flush=True)
    with (folder / 'execution.log').open('x') as log:
        result = subprocess.run(row['command'], cwd=root, env=check_env, stdout=log, stderr=subprocess.STDOUT)
    row.update(exitCode=result.returncode, finishedAt=now())
    save()
    print(json.dumps(row), flush=True)
subprocess.run(['node', '-e', verification], cwd=root, env=env, check=True)
record.update(artifactVerifiedAfter=True, sourceDirtyAfter=bool(git('status', '--porcelain')), finishedAt=now())
record['allStagesExitZero'] = all(row['exitCode'] == 0 for row in record['rows'])
save()
print(json.dumps(record), flush=True)
sys.exit(0 if record['allStagesExitZero'] else 1)
