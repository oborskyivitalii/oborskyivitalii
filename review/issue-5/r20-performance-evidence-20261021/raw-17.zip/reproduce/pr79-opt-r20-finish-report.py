from pathlib import Path
import json, hashlib, statistics

base = Path('/workspace/scratch/38e8b0c92238')
first = base / 'pr79-opt-r20-performance'
resumed = base / 'pr79-opt-r20-continuation'
load = lambda path: json.loads(path.read_text())
a = load(first / 'lighthouse/lighthouse.json')
m = load(resumed / 'motion/motion.json')
r = load(resumed / 'reader-performance/reader-performance.json')
e = load(resumed / 'execution.json')
prior = load(first / 'motion/motion.json')
assert e.get('finishedAt') and e['artifactVerifiedBefore'] and e['artifactVerifiedAfter']
assert not e['sourceDirtyBefore'] and not e['sourceDirtyAfter']
q = '3e12e47953bc8c81316544b1da206a956a337307'
tree = '728b7aee4dcdc3627b1327f90d8df64971d2d816'
assert all(d['sourceCommit'] == q and d['sourceTree'] == tree for d in [a,m,r,e])
rows = a['rows'] + r['rows']
metric = lambda row, name: row['metrics'][name]['numericValue']
reader_medians = []
for route in sorted({x['route'] for x in r['rows']}):
    for profile in ['mobile','desktop']:
        group = [x for x in r['rows'] if x['route']==route and x['formFactor']==profile]
        assert len(group)==3
        reader_medians.append({'route':route,'profile':profile,'metrics':{k:statistics.median(metric(x,k) for x in group)for k in ['largest-contentful-paint','total-blocking-time','cumulative-layout-shift']}})
medians = a['medians'] + reader_medians
for row in medians:
    group = [x for x in rows if x['route'] == row['route'] and x['formFactor'] == row['profile']]
    assert len(group) == 3
    row['maxLcpMs'] = max(metric(x, 'largest-contentful-paint') for x in group)
    row['maxTbtMs'] = max(metric(x, 'total-blocking-time') for x in group)
samples = m['samples'] + r['samples']
counts = {'lighthouse':len(rows), 'motionWindows':sum(len(x['measurements']) for x in samples),
          'flights':sum(len(x['rows']) for x in m['journeys']),
          'retentionCycles':sum(x['cycles'] for x in m['journeys']),
          'zeroWorkWindows':sum(len(x['measurements'][2:]) for x in samples),
          'soakObservedSeconds':sum(x['elapsedMs'] for x in m['soak']['chunks'])/1000}
assert counts['lighthouse']==36 and counts['motionWindows']==72 and counts['flights']==24
assert counts['retentionCycles']==120 and counts['zeroWorkWindows']==36 and counts['soakObservedSeconds']>=300
tails = [{'route':x['route'],'profile':x['formFactor'],'run':x['run'],'tbtMs':metric(x,'total-blocking-time')}
         for x in rows if metric(x,'total-blocking-time')>200]
cpu4 = [z['paintCallbackMs']['p95'] for x in samples if x['rate']==4 for z in x['measurements'][:2]]
prior_misses = [{'route':x['route'],'width':x['width'],'rate':x['rate'],'kind':z['kind'],
                 'p95Ms':z['paintCallbackMs']['p95'],'busyPercent':z['callbackBusyPercent']}
                for x in prior['samples'] if x['width']==390 and x['rate']==4
                for z in x['measurements'][:2]
                if z['paintCallbackMs']['p95']>33 or (z['kind']=='idle' and z['callbackBusyPercent']>20)]
zero_callbacks = sum(z['callbacks'] for x in samples for z in x['measurements'][2:])
zero_paints = sum(z['paints'] for x in samples for z in x['measurements'][2:])
network = []
for path in sorted((resumed/'reader-performance').glob('lighthouse-reader-*.json')):
    d = load(path)
    items = d['audits']['network-requests']['details']['items']
    images = [x for x in items if x.get('resourceType')=='Image']
    network.append({'file':path.name,'images':len(images),'imageTransferBytes':sum(x.get('transferSize',0) for x in images),
                    'totalTransferBytes':sum(x.get('transferSize',0) for x in items),'warnings':d.get('runWarnings',[])})
summary = {'sourceCommit':q,'sourceTree':tree,'artifactDigest':e['artifactDigest'],
           'completedStagesPass':all(x['pass'] for x in [a,m,r]) and e['allStagesExitZero'],
           'originalWrapperComplete':False,'strictSingleUninterruptedRunPass':False,
           'counts':counts,'medians':medians,'readerViolations':r.get('violations',[]),'maxCpu4PaintP95Ms':max(cpu4),
           'zeroCallbacks':zero_callbacks,'zeroPaints':zero_paints,
           'maxEquivalentReadyMs':max(x['equivalentReadyMs'] for j in m['journeys'] for x in j['rows']),
           'maxActualReadyMs':max(x['readyMs'] for j in m['journeys'] for x in j['rows']),
           'retention':[{'width':j['width'],'rate':j['rate'],'before':j['before'],'after':j['after']}for j in m['journeys']],
           'soakHeapDeltaBytes':m['soak']['deltaBytes'],'priorMotionBudgetMisses':prior_misses,
           'singleTbtBudgetExceedances':tails,'readerNetwork':network,'execution':e}
(base/'pr79-opt-r20-completed-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
table = '| Route / profile | Median LCP, ms | Maximum LCP, ms | Median / max TBT, ms | Median CLS |\n| --- | ---: | ---: | ---: | ---: |\n'
for row in medians:
    v = row['metrics']
    table += f"| {row['route']} / {row['profile']} | {v['largest-contentful-paint']:.3f} | {row['maxLcpMs']:.3f} | {v['total-blocking-time']:.3f} / {row['maxTbtMs']:.3f} | {v['cumulative-layout-shift']:.6f} |\n"
reader = next(x for x in medians if x['profile']=='mobile' and x['route'] not in ['index','research','writing','talks','credits'])
values = [metric(x,'largest-contentful-paint') for x in r['rows'] if x['formFactor']=='mobile']
report = f'''# R20 exact-source performance completion, 21 October 2026

Owner: [issue 5](https://github.com/oborskyivitalii/oborskyivitalii/issues/5) / [Draft PR79](https://github.com/oborskyivitalii/oborskyivitalii/pull/79).
Measured source `{q}`, tree `{tree}`, Color public digest `{e['artifactDigest']}`.
Runtime, article R20, original budgets and collectors were unchanged during this completion.

## Verdict and execution boundary

**Completed stage coverage: {'PASS' if summary['completedStagesPass'] else 'FAIL'}.** This is an explicitly assembled result: the completed original 30-trial Lighthouse stage plus one restart of the incomplete motion stage and the subsequent reader stage. It is **not** a successful single uninterrupted `performance.cjs` invocation. The original wrapper remains incomplete and its false final-verification checkpoint is retained.

The original process disappeared without a terminal execution receipt. Its cause is unknown. Its retained motion data contains 15 short profiles and one flight profile, without soak or reader. Intermediate `motion.pass:true` cannot admit that attempt. Home 390px / CPU×4 already missed the 33ms paint budget (idle45.6ms, scroll38.8ms) and 20% idle-busy budget (21.65%). These observed misses are retained, not excused as environment noise and not erased by the continuation.

The recovery recipe reused only the complete original Lighthouse stage. It ran unchanged `motion.cjs`, then `reader-performance.cjs`, serially on the same frozen artifact/browser. Artifact verification passed before and after; source remained clean. The repeated motion stage is justified by its missing completion, not by an attempt to replace failed samples. No original files were rewritten. All reports, attempts, inputs, recipes and source/check receipts are retained in the raw manifest accompanying this report.

## Completed results

{counts['lighthouse']} Lighthouse trials; {counts['motionWindows']} short motion windows; {counts['flights']} primary-route flights; {counts['retentionCycles']} retention cycles; {counts['soakObservedSeconds']:.3f}s soak. Eleven of twelve page/profile groups pass all original median-of-three LCP2500ms, TBT200ms and CLS0.1 budgets. **Reader mobile fails TBT: median204ms >200ms**; individual184.5/225.5/204ms. Every group passes LCP and CLS. All motion checks in the completed continuation pass; the interrupted attempt retains its separate misses. The4ms TBT overrun is a failure, not rounded away.

Reader mobile LCP median **{reader['metrics']['largest-contentful-paint']:.3f}ms**; individual values {', '.join(f'{v:.3f}' for v in values)}ms. Its median budget margin is {2500-reader['metrics']['largest-contentful-paint']:.3f}ms.

{table}
Individual TBT exceedances (Writing group median passes; reader group median fails): `{json.dumps(tails)}`. R19's earlier claim that every individual TBT was below200ms does not apply to R20.

Completed CPU×4 maximum paint p95 **{max(cpu4):.3f}/33ms**. All {counts['zeroWorkWindows']} Off/Reduced windows have {zero_callbacks} callbacks / {zero_paints} paints. Equivalent flight readiness max **{summary['maxEquivalentReadyMs']:.3f}/3200ms**; actual readiness max {summary['maxActualReadyMs']:.3f}ms is a separate quantity. DOM/listener before/after counters are retained in the summary. Forced-GC soak heap change **{m['soak']['deltaBytes']} bytes**, a bounded observation, not proof of leak absence or presence.

## Remaining finding and next diagnostic

Reader mobile CPU blocking is unresolved. Two of three TBT trials exceed200ms. The completed strict result is FAIL; an unchanged-source repeat to obtain a pass is not proposed. Preserve all six reader trace/log pairs and inspect the long main-thread tasks, script evaluation and synchronous reader/router/layout work before a bounded CPU correction. In failing trial2, the Lighthouse long-tasks audit attributes129/120/91ms tasks to `space.js`; trial3 includes a103ms `navigation.js` task and89/83/76ms `space.js` tasks. These are audit-level task attributions, not proof of a specific function-level cause or of a simple sum equal to TBT. Original Home CPU×4 paint misses and Writing235ms TBT are additional observed tails. Their cause is not established, and passing continuation samples do not establish that these tails disappeared.

## Causal attribution and preserved scope

The prior same-content R18 diagnostics remain the causal evidence: deferring seven offscreen images4202.360→2027.178ms; active-clone control3377.345→2401.136ms with an inert cache. Final R19 and R20 contain fewer selected illustrations than R18; their total difference from R18 must not be attributed exclusively to optimization. R20 editorial files and Q4 runtime/producer/collector/budget bytes were preserved by integration3e12e479.

Previously recorded exact-source owning12/12, formatting/lint, RI28/28, RI-CI20/20 and toolchain checks pass. Five maintained reader journeys plus five supplementary browser cases pass; native/Back/SPA at1440/390 observe the complete four-image inventory with one initial image request. Cold native print has22pages and all four original images. These are separate source/browser receipts, not newly executed performance checks or an editorial PDF export.

## Acceptance and limits

| Scope | Outcome | Remaining boundary |
| --- | --- | --- |
| AC08 reader behavior | Exact-source source/browser/native-print receipts pass | Whole feature/editorial/rights/device/publication gates remain open |
| AC11 implementation/style/review | Prior independent source review and mapped source checks retained | This completion changes no implementation source |
| AC12 performance evidence | Complete assembled coverage FAIL: reader mobile TBT204/200ms; original interrupted attempt retained | CPU correction and fresh affected evidence pending; no R20 performance clearance |

Local Linux explicit Chromium153.0.8010.0 override and the repository gzip HTTP fixture were used. These results are not managed CI, CDN, field INP/RUM or physical iPad acceptance. Budgets/aggregation/timeouts remain unchanged. Independent evidence review is linked alongside the report. No new whole-AC tick, merge, permanent-staging promotion or production activation is established. Permanent staging remains historical R18/source283b32f.

Refs #5
'''
(base/'pr79-opt-r20-final-report.md').write_text(report)
print(json.dumps({k:summary[k] for k in ['completedStagesPass','counts','maxCpu4PaintP95Ms','maxEquivalentReadyMs','singleTbtBudgetExceedances']},indent=2))
