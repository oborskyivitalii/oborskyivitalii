# Independent interruption-recovery verification

Reviewer: `/root/perf_resume_review`, separate from the implementation author.
Date: 21 October 2026. Owning work: issue5 / Draft PR79.

## Remote Q4 archive native readback — PASS

Live native Git `ls-remote` returned evidence branch head
`4c021989b43a9c748f6c29fcb34c1e713abd3557`, tree
`40319ba95d18f0d3896a014a5188280e609ba680`, parent
`aade77a24d60987d272a2d8f46118d14b3b04c9b`.

All 58 declared uploaded paths were independently read from that immutable
commit and verified against their declared byte lengths, SHA256 values and
native Git blob OIDs. Six already-downloaded files were reused only after
hash/OID verification. Remaining objects were fetched natively, in a batch
without updating refs. The verification did not change the implementation
worktree or index, which was concurrently preparing the R20 integration.

All 52 ZIP lengths/SHA256s and CRCs pass. The complete 753 unique regular-file
members match the manifest in order, bytes and SHA256; all 2212 logical aliases
resolve to the declared bytes. Total compressed bytes: 159318993. All 39 earlier
evidence-tree entries are preserved exactly, and the new tree contains exactly
those prior paths plus the 58 declared uploads.

The remote-readback restoration script was then run into a fresh independent
directory. Independently enumerating and hashing its result confirms exactly
2212 files, all expected byte lengths and SHA256s, with no missing or extra
files. No failed/partial/repeated trial was discarded.

Machine receipt:
`pr79-opt-native-readback/independent-native-readback.json`, SHA256
`d97df800bf7a6b096942e20b62a24124642b49a07ea43e436c671a376a531691`.

No remaining blocker within this bounded archive/readback scope. This confirms
the published Q4 evidence, not performance acceptance of concurrent R20, current
hosted staging, a physical device, field metrics, merge, or production release.

## R20 integration source review — PASS to freeze and test

Exact reviewed prepared tree:
`49c8e6a7fea02bbdf21251aa0c22ca77d24e9b25`, intended parents Q4
`7fbb0bc2320b2758f70c806057275878cb263c54` and R20
`f2dfe2c87bc5e136eecc2da6e74df389d490fa10`. No unstaged diff; the tree stayed
fixed through this verification. The originally supplied tree `de3b9e4c` was
superseded by the factual MEMORY correction before review; no approval was
issued for that stale identity.

I independently inspected both-parent diffs and blob identities. All nine
nonmetadata R20 files are byte-identical to its authored commit: manuscript,
profile, publication, blueprint, edition, media tests, historical draft pointer,
editorial review and portable review ZIP. Relative to Q4, every other path is
unchanged except the five catalog/derived/handoff metadata files and the
appended existing issue5 implementation record. Thus the complete reviewed Q4
runtime, lifecycle, cache, producer, collectors, validators, budgets, generated
runtime and existing evidence remain byte-identical. The unaffected Q4
implementation review is reused with its prior declared limits.

The catalog adds exactly the three R20 paths to Q4, with definitions identical
to R20. Every Q4 entry remains unchanged. The sixteen entries absent from R20's
older catalog are obsolete generated paths which do not exist in this candidate;
their removal is correct and does not delete physical historical evidence.
The generated map adds the same three entries. RI freshness, fifteen-check
RI/CI coupling, bounded style guard and whitespace checks pass. No new browser,
scanner or performance run was performed by this reviewer.

The Q4 result and native readback receipts match immutable evidence and clearly
limit PASS to tested R19. MEMORY now accurately records completed readback,
pending actual PR-head publication and pending fresh R20 checks. It retains
historical R18 stable staging, original budgets and open whole-feature gates.

No remaining blocking finding in this integration scope. May append this
verbatim receipt, regenerate deterministic RI identities, freeze the successor,
then run the fresh mapped source, browser and strict performance checks on that
one exact source. This review does not claim R20 performance PASS, hosted or
device acceptance, readiness, main merge or production authorization.

Verbatim short receipt suitable for the existing versioned review artifact:

> Independent R20 integration review PASS to freeze/test at prepared tree
> 49c8e6a7fea02bbdf21251aa0c22ca77d24e9b25, parents Q4 7fbb0bc and R20 f2dfe2c.
> All9 nonmetadata R20 files are byte-identical; all other Q4 paths remain
> unchanged except catalog/derived metadata, MEMORY and the appended issue5
> receipt. All Q4 runtime/producer/collector/validator/budget bytes are preserved.
> Catalog is exactly Q4 plus3 R20 entries;16 removed older R20 entries are
> nonexistent obsolete generated paths. RI freshness, RI/CI15 checks, bounded
> style and whitespace pass. Q4/native-readback claims are exact-source qualified;
> R20 source/browser/performance and actual PR-head publication stay pending.
> No blocking finding. May freeze successor after verbatim receipt/RI refresh,
> then execute fresh mapped checks and the declared strict suite once. No
> benchmark, browser or scanner was run by this independent reviewer.
