# AI Changes the Delivery System and the Product Itself — distribution review candidate

Full content edition: pmday-two-shifts-en-review-20261012
Source provenance: working-tree-review
Canonical: pending: verify the accepted live site page first

Review wording, heading sources, table row labels, captions and credits against the manuscript.
Open <platform>-copy-ready.html, select the article body, and paste into the native editor.
Copy-ready images preserve reviewer bytes; native-editor image transfer must be checked.

Medium: upload each ordered image below manually at its matching figure position.
Do not assume pasted embedded images survive. Recheck caption, alt text, credit and source link.
Use the canonical only after accepted live-site verification; otherwise leave publication pending.
LinkedIn: inspect the selected adaptation or equivalent rendition, including every heading source.
Record actual native-editor changes and observed publication as a separate event.

images/01-control-path.png — Figure 1. One schematic control path for the illustrative access-recovery assistant. Semantic checking is fallible and separate from permissions. Delivered, denied and fallback outcomes inform authorized intervention; a closed loop does not establish correctness. (Original explanatory diagram for this article, based on PMDay v35 slide 12.)

Rights: New explanatory prose and original diagram prepared for Vitalii Oborskyi. Reuse license is not selected. Linked deck, reports and repository materials retain their own rights; no site-wide license or publication acceptance is inferred.
