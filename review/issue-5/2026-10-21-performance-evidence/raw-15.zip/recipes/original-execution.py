import datetime, hashlib, json, os, pathlib, subprocess, time
root=pathlib.Path('/workspace/scratch/38e8b0c92238/pr79-perf')
out=pathlib.Path('/workspace/scratch/38e8b0c92238/pr79-perf-results'); out.mkdir(exist_ok=True)
env=os.environ.copy(); env.update(SITE_AUDIT_TOOLS='/workspace/scratch/38e8b0c92238/pr79/tools/quality/toolchain',SITE_AUDIT_CHROME='/tmp/chromium',SITE_PUBLIC_DIR='/workspace/scratch/38e8b0c92238/pr79-perf-artifact/public',SITE_ARTIFACT_MANIFEST='/workspace/scratch/38e8b0c92238/pr79-perf-artifact/artifact.json',SITE_REPORT_DIR=str(out))
for key in ['SITE_TEST_BASE_URL','SITE_TEST_PROFILE']: env.pop(key,None)
now=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
state={'schema':1,'run':'20261021-pr79-strict-01','scope':'existing complete performance worker; lab fixture of frozen staging bytes','startedAt':now(),'hostedNetworkMeasurement':False,'productionEligible':False,'managedBrowserDownload':'unavailable: HTML response instead of ZIP','chromeOverride':{'path':'/tmp/chromium','version':'153.0.8010.0','sha256':hashlib.sha256(pathlib.Path('/tmp/chromium').read_bytes()).hexdigest()},'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceTree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'artifactZipSha256':'9116977727fc050c3845dcfba0cefc522a4e6c444eb07c8aecd0ea0828e25a62','steps':[]}
def save(): (out/'suite-execution.json').write_text(json.dumps(state,indent=2)+'\n')
save()
steps=[('artifact-before',['node','tools/quality/artifact.cjs','verify',env['SITE_PUBLIC_DIR'],env['SITE_ARTIFACT_MANIFEST']],120),('lighthouse',['node','tools/quality/lighthouse.cjs'],3000),('motion',['node','tools/quality/motion.cjs'],3000),('artifact-after',['node','tools/quality/artifact.cjs','verify',env['SITE_PUBLIC_DIR'],env['SITE_ARTIFACT_MANIFEST']],120)]
for name,cmd,timeout in steps:
    row={'name':name,'command':cmd,'startedAt':now()}; state['steps'].append(row); save(); started=time.monotonic()
    with (out/(name+'.log')).open('w') as log:
        try: row['exitCode']=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired: row.update(exitCode=124,error='timeout')
    row.update(finishedAt=now(),elapsedSeconds=round(time.monotonic()-started,3)); save(); print(json.dumps(row),flush=True)
    if name=='artifact-before' and row['exitCode']!=0: break
state['finishedAt']=now(); state['pass']=len(state['steps'])==4 and all(s['exitCode']==0 for s in state['steps']); save()
print(json.dumps({'finishedAt':state['finishedAt'],'pass':state['pass']}),flush=True)
