import datetime, json, os, pathlib, subprocess, time
root=pathlib.Path('/workspace/scratch/38e8b0c92238/pr79-perf-harness')
base=root.parent
out=base/'pr79-perf-source-checks'; out.mkdir(exist_ok=True)
reader=base/'pr79-perf-reader-results'; reader.mkdir(exist_ok=True)
now=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
state={'schema':1,'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceTree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'steps':[],'waitingForOriginalMatrix':True}; file=out/'execution.json'
def save():file.write_text(json.dumps(state,indent=2)+'\n')
save()
while True:
    s=json.loads((base/'pr79-perf-results/suite-execution.json').read_text())
    if 'finishedAt' in s:break
    time.sleep(3)
state.update(waitingForOriginalMatrix=False,primaryPass=s['pass'],startedAt=now());save()
env=os.environ.copy();env.update(SITE_AUDIT_TOOLS=str(base/'pr79/tools/quality/toolchain'),SITE_AUDIT_CHROME='/tmp/chromium',SITE_REPORT_DIR=str(out))
for key in ['SITE_TEST_BASE_URL','SITE_TEST_PROFILE']:env.pop(key,None)
artifact=base/'pr79-perf-harness-artifact'
steps=[('artifact',['node','tools/quality/artifact.cjs','build',str(artifact)],180),('basic',['node','tools/quality/local.cjs'],180),('focused',['node','--test','tests/performance-suite.test.cjs','tests/quality.test.cjs','tests/quality-sources.test.cjs','tests/staging-regression.test.cjs'],180),('style',['python3','tools/check_code_style.py'],180),('ri',['python3','tools/repository_intelligence.py','--config','.github/repository-intelligence-config.json','verify'],180),('ri-ci',['python3','tools/check_ri_ci.py','verify'],180),('python',['python3','-m','unittest','discover','-s','tests','-p','test_ri_ci.py'],180),('lint',['node','tools/quality/scanners.cjs','lint'],180)]
for name,cmd,timeout in steps:
    if name!='artifact':env.update(SITE_PUBLIC_DIR=str(artifact/'public'),SITE_ARTIFACT_MANIFEST=str(artifact/'artifact.json'))
    row={'name':name,'command':cmd,'startedAt':now()};state['steps'].append(row);save();started=time.monotonic()
    with (out/(name+'.log')).open('w') as log:
        try: row['exitCode']=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired:row.update(exitCode=124,error='timeout')
    row.update(finishedAt=now(),elapsedSeconds=round(time.monotonic()-started,3));save();print(json.dumps(row),flush=True)
    if row['exitCode']!=0:state.update(stoppedBeforeReader=True,finishedAt=now());save();raise SystemExit(1)
state['sourceChecksPass']=True;save()
env.update(SITE_PUBLIC_DIR=str(base/'pr79-perf-artifact/public'),SITE_ARTIFACT_MANIFEST=str(base/'pr79-perf-artifact/artifact.json'),SITE_REPORT_DIR=str(reader))
row={'name':'reader-performance','command':['node','tools/quality/reader-performance.cjs'],'startedAt':now()};state['steps'].append(row);save();started=time.monotonic()
with (reader/'execution.log').open('w') as log:
    try:row['exitCode']=subprocess.run(row['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1500).returncode
    except subprocess.TimeoutExpired:row.update(exitCode=124,error='timeout')
row.update(finishedAt=now(),elapsedSeconds=round(time.monotonic()-started,3));state['finishedAt']=now();save();print(json.dumps(row),flush=True)
