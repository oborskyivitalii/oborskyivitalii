import pathlib,subprocess,datetime,json,os,time
root=pathlib.Path('/workspace/scratch/38e8b0c92238/pr79-perf-final');base=root.parent;out=base/'pr79-perf-final-source-checks';out.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='92b671f9d94b1be2e7ab9735e6fe267deb6c4aff';assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
state={'schema':1,'sourceCommit':head,'sourceTree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'sourceDirtyBefore':False,'startedAt':now(),'localSourceChecks':True,'steps':[],'performanceOutcome':'FAIL: frozen staged reader mobile LCP4202.636ms/2500ms; these source checks do not change that result.'}
env=os.environ.copy();env.update(SITE_AUDIT_TOOLS=str(base/'pr79/tools/quality/toolchain'),SITE_AUDIT_CHROME='/tmp/chromium',SITE_REPORT_DIR=str(out))
for key in ['SITE_TEST_BASE_URL','SITE_TEST_PROFILE','SITE_PUBLIC_DIR','SITE_ARTIFACT_MANIFEST']:env.pop(key,None)
artifact=base/'pr79-perf-final-source-artifact';save=lambda:(out/'execution.json').write_text(json.dumps(state,indent=2)+'\n');save()
steps=[('artifact',['node','tools/quality/artifact.cjs','build',str(artifact)],180),('owning-acceptance',['python3','tools/issue_acceptance.py','run','--policy','.github/acceptance/issue-5.json','--report',str(out/'issue-5-acceptance.json'),'--require-clean','--expected-source',head],420),('focused',['node','--test','tests/performance-suite.test.cjs','tests/quality.test.cjs','tests/quality-sources.test.cjs','tests/staging-regression.test.cjs'],180),('style-tests',['python3','-m','unittest','discover','-s','tests','-p','test_code_style.py'],180),('ri-tests',['python3','-m','unittest','discover','-s','tests','-p','test_repository_intelligence.py'],180),('ri-ci-tests',['python3','-m','unittest','discover','-s','tests','-p','test_ri_ci.py'],180),('lint',['node','tools/quality/scanners.cjs','lint'],180)]
for name,cmd,timeout in steps:
 if name!='artifact':env.update(SITE_PUBLIC_DIR=str(artifact/'public'),SITE_ARTIFACT_MANIFEST=str(artifact/'artifact.json'))
 row={'name':name,'command':cmd,'startedAt':now()};state['steps'].append(row);save();start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  try:row['exitCode']=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:row.update(exitCode=124,error='timeout')
 row.update(finishedAt=now(),elapsedSeconds=round(time.monotonic()-start,3));save();print(json.dumps(row),flush=True)
 if name=='artifact' and row['exitCode']!=0:break
state.update(sourceDirtyAfter=subprocess.check_output(['git','status','--porcelain'],cwd=root)!=b'',finishedAt=now());state['pass']=len(state['steps'])==len(steps) and all(r['exitCode']==0 for r in state['steps']) and not state['sourceDirtyAfter'];save();print(json.dumps({'pass':state['pass'],'sourceDirtyAfter':state['sourceDirtyAfter']}),flush=True)
