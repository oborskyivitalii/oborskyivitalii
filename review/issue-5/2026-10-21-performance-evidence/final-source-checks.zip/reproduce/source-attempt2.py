import datetime,json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/scratch/38e8b0c92238/pr79-perf-final')
out=root.parent/'pr79-perf-final-source-checks'
source='92b671f9d94b1be2e7ab9735e6fe267deb6c4aff'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
env=dict(os.environ,SITE_AUDIT_TOOLS=str(root.parent/'pr79/tools/quality/toolchain'),SITE_AUDIT_CHROME='/tmp/chromium',SITE_PUBLIC_DIR=str(root.parent/'pr79-perf-final-source-artifact/public'),SITE_ARTIFACT_MANIFEST=str(root.parent/'pr79-perf-final-source-artifact/artifact.json'),SITE_REPORT_DIR=str(out))
env.pop('SITE_TEST_BASE_URL',None);env.pop('SITE_TEST_PROFILE',None)
command=['python3','tools/issue_acceptance.py','run','--policy','.github/acceptance/issue-5.json','--report',str(out/'issue-5-acceptance.json'),'--require-clean','--expected-source',source]
receipt={'schema':1,'sourceCommit':git('rev-parse','HEAD'),'sourceTree':git('rev-parse','HEAD^{tree}'),'sourceDirtyBefore':bool(git('status','--porcelain')),'startedAt':now(),'command':command,'reason':'Repeat owning source policy once after material environment correction; original failed attempt retained; no performance reruns.'}
assert receipt['sourceCommit']==source and not receipt['sourceDirtyBefore']
start=time.monotonic()
with (out/'owning-acceptance-attempt2.log').open('w') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt.update(exitCode=r.returncode,elapsedSeconds=round(time.monotonic()-start,3),finishedAt=now(),sourceDirtyAfter=bool(git('status','--porcelain')),performanceMeasurementsRepeated=False)
(out/'execution-attempt2.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
raise SystemExit(r.returncode)
