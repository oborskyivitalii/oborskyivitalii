"""Reconstruct the retained QA variants without running Node or altering the repo.

Run from this evidence directory. The two retained candidate snapshots and the
original probe drivers determine every tested mutant exactly. This script checks
their source hashes against the native TAP receipts; it is not a new test run.
"""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
sha = lambda text: hashlib.sha256(text.encode()).hexdigest()


def variants(source):
    return {
        "candidate": source,
        "shared-realm": source.replace(
            "function visit(options = {}) {",
            "const sharedBrowserContext = vm.createContext(vm.constants.DONT_CONTEXTIFY);\nfunction visit(options = {}) {",
            1,
        ).replace(
            "const browserContext = vm.createContext(vm.constants.DONT_CONTEXTIFY);",
            "const browserContext = sharedBrowserContext;",
            1,
        ),
        "host-global": source.replace(
            "Object.assign(browserContext, { document, window, localStorage });",
            "Object.assign(browserContext, { document, window, localStorage, process });",
            1,
        ),
        "host-intrinsics": source.replace(
            "Object.assign(browserContext, { document, window, localStorage });",
            "Object.assign(browserContext, { document, window, localStorage, Math, Array, Object });",
            1,
        ),
        "shared-storage": source.replace(
            "function visit(options = {}) {",
            "let sharedStorage;\nfunction visit(options = {}) {",
            1,
        ).replace(
            "Object.assign(browserContext, { document, window, localStorage });",
            "Object.assign(browserContext, { document, window, localStorage: sharedStorage || (sharedStorage = localStorage) });",
            1,
        ),
    }


checked = []
for label, directory, receipt in [
    ("before", HERE, "mutation-matrix-before.json"),
    ("after", HERE / "after", "mutation-matrix-after.json"),
]:
    source = (directory / "candidate.test.cjs").read_text()
    matrix = json.loads((directory / receipt).read_text())
    assert sha(source) == matrix["candidate_sha256"]
    generated = variants(source)
    for row in matrix["variants"]:
        assert sha(generated[row["name"]]) == row["mutation_sha256"], row["name"]
        raw = (directory / (row["name"] + ".tap")).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row["tap_sha256"]
        checked.append({"phase": label, "variant": row["name"], "source_sha256": row["mutation_sha256"], "tap_sha256": row["tap_sha256"]})

source = (HERE / "after/candidate.test.cjs").read_text()
boot = {
    "runtime-executed": source,
    "runtime-bypassed": source.replace(
        "  script.runInContext(browserContext);",
        "  // Deliberate QA fault: runtime execution bypassed.",
        1,
    ),
}
for row in json.loads((HERE / "boot-probe.json").read_text()):
    assert sha(boot[row["name"]]) == row["source_sha256"]
    raw = (HERE / (row["name"] + ".tap")).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row["tap_sha256"]
    checked.append({"phase": "boot", "variant": row["name"], "source_sha256": row["source_sha256"], "tap_sha256": row["tap_sha256"]})

print(json.dumps({"variants_reconstructed": len(checked), "source_and_tap_hashes_verified": True, "checks": checked}, indent=2))
