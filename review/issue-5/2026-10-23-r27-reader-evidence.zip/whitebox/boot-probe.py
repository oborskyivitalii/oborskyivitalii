from pathlib import Path
import subprocess, json, hashlib, re, time, os
ROOT=Path('/workspace/scratch/c91ea22e72f1/author-site');OUT=Path('/tmp/r27-whitebox')
source=(ROOT/'tests/space.test.cjs').read_text();sha=lambda b:hashlib.sha256(b).hexdigest()
pattern='^articles retain common Off and reduced-motion behavior across document changes$'
rows=[]
for name, text in [('runtime-executed',source),('runtime-bypassed',source.replace('  script.runInContext(browserContext);','  // Deliberate QA fault: runtime execution bypassed.',1))]:
 path=OUT/(name+'.test.cjs');path.write_text(text)
 cmd=['node','--test','--test-reporter=tap','--test-name-pattern='+pattern,str(path)]
 t=time.monotonic();run=subprocess.run(cmd,cwd=ROOT,env=dict(os.environ,SITE_SPACE_SOURCE=str(ROOT/'docs/space.js')),capture_output=True,text=True,timeout=30)
 (OUT/(name+'.tap')).write_text(run.stdout);(OUT/(name+'.stderr')).write_text(run.stderr)
 row={'name':name,'source_sha256':sha(text.encode()),'command':cmd,'returncode':run.returncode,'wall_seconds':time.monotonic()-t,'counts':{k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$',run.stdout,re.M)},'named_case_present':bool(re.search(r'^# Subtest: articles retain common Off',run.stdout,re.M)),'tap_sha256':sha(run.stdout.encode())}
 rows.append(row);print(json.dumps(row))
(OUT/'boot-probe.json').write_text(json.dumps(rows,indent=2)+'\n')
