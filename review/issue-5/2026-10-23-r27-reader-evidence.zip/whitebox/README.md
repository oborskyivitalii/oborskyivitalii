# Independent R27 White-box evidence

This directory retains independent native selected-case TAP and bounded fault
injections for the R27 Space fixture change. It is review evidence, not a
replacement for the repository's complete acceptance run.

- `mutation-matrix-before.json` records the first candidate, SHA-256 `b2ba67b61d501c109b15c829388a372af8c994aaafcb4b475d5603915b853f14`. The shared-storage fault unexpectedly passed and exposed the original guard gap.
- `after/mutation-matrix-after.json` records the corrected candidate, SHA-256 `4a7691344008723ad8d1971890e8a488d40b6ce2e286656a38690053e4a7c939`. The unmodified guard passed, and all four deliberate isolation faults failed on their intended assertions.
- `boot-probe.json` records an original behavior case on the corrected candidate: real runtime execution passed; removing the runtime invocation caused the original case to fail.
- Each receipt is accompanied by its actual native `.tap` and `.stderr`. Expected negative failures have exit code 1 and exactly one failed named case. Their failures are the intended detection result. A wrapper-only exit 0 does not satisfy the required accounting.
- `candidate.test.cjs` and `after/candidate.test.cjs` retain the two exact source snapshots. Other variant copies are omitted because their complete transformations and hashes are retained.
- `probe.py`, `probe-after.py`, and `boot-probe.py` are the original execution drivers. They read the live checkout at their hard-coded path; do not rerun them assuming the current checkout is the historical before snapshot. Replay must use the matching retained snapshot and runtime digest.
- `reconstruct-mutations.py` can be run from this directory without Node. It reconstructs all 12 recorded variants from the two retained snapshots, verifies their source and raw TAP hashes, and prints the reconstruction proof. `mutation-reconstruction.json` retains that successful output.
- Node probes used `SITE_SPACE_SOURCE` pointing to the unchanged `docs/space.js`, SHA-256 `ac43775efbe45fba9fa7554aaaa2ceb313f63faf35d037115c9f426a4dd8162f`, under Node 24.19.0. The recorded commands selected an exact named case. Native process execution was required because the managed default sandbox's file-wrapper-only TAP was not accepted as evidence.
- `source-observations.json` and `publication-static.json` are independent source and identity checks. `artifacts.py`, `artifact-check.stdout`, and `artifact-observations.json` inspect the actual public ZIP, native kit, actual PDF and prior R26 ZIP.

No repository source was changed by these probes. No confidential correspondence,
credentials, temporary repository tree or symlink fixture is included. The
independent conclusion and evidence bounds are in `r27-whitebox-qa.md` alongside
the evidence archive's role receipts.
