from pathlib import Path
import subprocess, json, hashlib, re, time, os
ROOT = Path('/workspace/scratch/c91ea22e72f1/author-site')
OUT = Path('/tmp/r27-whitebox/after')
OUT.mkdir(exist_ok=True)
source = (ROOT/'tests/space.test.cjs').read_text()
sha = lambda b: hashlib.sha256(b).hexdigest()
variants = {
 'candidate': source,
 'shared-realm': source.replace('function visit(options = {}) {', 'const sharedBrowserContext = vm.createContext(vm.constants.DONT_CONTEXTIFY);\nfunction visit(options = {}) {', 1).replace('const browserContext = vm.createContext(vm.constants.DONT_CONTEXTIFY);', 'const browserContext = sharedBrowserContext;', 1),
 'host-global': source.replace('Object.assign(browserContext, { document, window, localStorage });', 'Object.assign(browserContext, { document, window, localStorage, process });', 1),
 'host-intrinsics': source.replace('Object.assign(browserContext, { document, window, localStorage });', 'Object.assign(browserContext, { document, window, localStorage, Math, Array, Object });', 1),
 'shared-storage': source.replace('function visit(options = {}) {', 'let sharedStorage;\nfunction visit(options = {}) {', 1).replace('Object.assign(browserContext, { document, window, localStorage });', 'Object.assign(browserContext, { document, window, localStorage: sharedStorage || (sharedStorage = localStorage) });', 1),
}
result = {'baseline_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'candidate_sha256':sha(source.encode()), 'runtime_sha256':sha((ROOT/'docs/space.js').read_bytes()), 'node':subprocess.check_output(['node','--version'],text=True).strip(), 'selection':'^simulated pages retain isolated globals, intrinsics and injected browser fixtures$', 'variants':[]}
for name, text in variants.items():
 if name != 'candidate': assert text != source, name
 path = OUT/(name+'.test.cjs'); path.write_text(text)
 command=['node','--test','--test-reporter=tap','--test-name-pattern='+result['selection'],str(path)]
 env=dict(os.environ,SITE_SPACE_SOURCE=str(ROOT/'docs/space.js'))
 started=time.monotonic()
 run=subprocess.run(command,cwd=ROOT,env=env,text=True,capture_output=True,timeout=30)
 elapsed=time.monotonic()-started
 (OUT/(name+'.tap')).write_text(run.stdout)
 (OUT/(name+'.stderr')).write_text(run.stderr)
 counts={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$',run.stdout,re.M)}
 row={'name':name,'mutation_sha256':sha(text.encode()),'command':command,'returncode':run.returncode,'wall_seconds':elapsed,'counts':counts,'named_case_present':bool(re.search(r'^# Subtest: simulated pages retain isolated globals',run.stdout,re.M)),'tap_sha256':sha(run.stdout.encode()),'tap_bytes':len(run.stdout.encode())}
 result['variants'].append(row)
 print(json.dumps(row),flush=True)
(OUT/'mutation-matrix-after.json').write_text(json.dumps(result,indent=2)+'\n')
