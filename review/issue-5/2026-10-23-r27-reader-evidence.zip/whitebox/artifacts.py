from pathlib import Path
from html.parser import HTMLParser
import json, hashlib, re, zipfile, fitz
ROOT=Path('/workspace/scratch/c91ea22e72f1/author-site')
KIT=ROOT/'dist/publications/pmday-ai-both-sides/3deebdbf052a2ad3616ae6ba7ea70d35c4e4c09a2e75713379f0aedfb82e154e'
PUBLIC=ROOT/'review/issue-2/r27-20261023'
BASE='The_Sum_of_Our_Technology_R27_2026-10-23'
OLDZIP=ROOT/'review/issue-2/r26-20261023/The_Sum_of_Our_Technology_R26_2026-10-23_Native_Review_Kit.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((KIT/'manifest.json').read_text())
article=(ROOT/'site/publications/pmday-ai-both-sides/manuscript.en.md').read_text()
def numeric_markdown_pairs(text):
 pairs=[]
 for match in re.finditer(r'\\\[(\d+)\\\]\]\(',text):
  start=match.end();depth=1;end=start
  while end<len(text):
   if text[end]=='(':depth+=1
   elif text[end]==')':
    depth-=1
    if depth==0:break
   end+=1
  assert depth==0,('unclosed Markdown target',start)
  url=re.sub(r'\\([()])',r'\1',text[start:end])
  assert url.startswith('https://'),url
  pairs.append((match[1],url))
 return pairs
expected=numeric_markdown_pairs(article)
assert len(expected)==49,len(expected)
provenance='Olivier Leturcq contributed feedback on the balance between innovation and sustainable operating costs, and suggested examining how architecture affects the context needed for human review and maintenance. These comments are recorded for editorial consideration.'
history="R27: Olivier's feedback recorded; substantive editorial proposals remain under review."
normalize=lambda t:re.sub(r'\s+',' ',t).strip()
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.a=None;self.text=[];self.images=[];self.tables=0;self.ids=[];self.h=[];self.hh=None;self.suppress=0
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if t in ['style','script']:self.suppress+=1
  if t=='a':self.a={'text':'','url':a.get('href','')}
  if t=='img':self.images.append(a)
  if t=='table':self.tables+=1
  if 'id' in a:self.ids.append(a['id'])
  if t in ['h1','h2','h3','h4']:self.hh=''
 def handle_data(self,s):
  if self.suppress:return
  self.text.append(s)
  if self.a is not None:self.a['text']+=s
  if self.hh is not None:self.hh+=s
 def handle_endtag(self,t):
  if t in ['style','script']:self.suppress-=1
  if t=='a' and self.a is not None:self.links.append(self.a);self.a=None
  if t in ['h1','h2','h3','h4'] and self.hh is not None:self.h.append(self.hh);self.hh=None
  if t in ['p','li','div','h1','h2','h3','h4','section']:self.text.append('\n')
def parse(b):
 p=Parser();p.feed(b.decode());return p
actual=sorted(p.relative_to(KIT).as_posix() for p in KIT.rglob('*') if p.is_file())
assert actual==sorted([x['path'] for x in manifest['outputs']]+['manifest.json'])
for out in manifest['outputs']:
 b=(KIT/out['path']).read_bytes();assert len(b)==out['bytes'] and sha(b)==out['sha256'],out['path']
archive=PUBLIC/(BASE+'_Native_Review_Kit.zip')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.namelist()==actual
 assert all(z.read(n)==(KIT/n).read_bytes() for n in actual)
assert (PUBLIC/(BASE+'.md')).read_bytes()==(KIT/'article.md').read_bytes()==article.encode()
assert (PUBLIC/(BASE+'.pdf')).read_bytes()==(KIT/'article.pdf').read_bytes()
assert (KIT/'launch-post.md').read_bytes()==(ROOT/'site/publications/pmday-ai-both-sides/launch-post.en.md').read_bytes()
results={}
old=zipfile.ZipFile(OLDZIP)
for name in ['article.html','print.html','linkedin.html','medium.html','linkedin-copy-ready.html','medium-copy-ready.html']:
 p=parse((KIT/name).read_bytes());q=parse(old.read(name))
 pairs=[(re.search(r'\[(\d+)\]',a['text'])[1],a['url']) for a in p.links if re.search(r'\[\d+\]',a['text'])]
 assert pairs==expected,(name,pairs)
 text=normalize(''.join(p.text));before=normalize(''.join(q.text))
 assert provenance in text,(name,'provenance')
 assert history in text,(name,'history')
 compare=normalize(text.replace(provenance,'').replace(history,'').replace('R27','R26').replace('pmday-ai-both-sides-en-review-20261023-r27','pmday-ai-both-sides-en-review-20261023-r26'))
 assert compare==before,(name,'unchanged baseline text')
 assert len(p.images)==4,(name,'images')
 assert p.tables==(2 if name in ['article.html','print.html'] else 0),(name,'tables')
 assert p.h==q.h,(name,'headings')
 results[name]={'numericLinks':len(pairs),'allCitationDestinationsOrderedExact':True,'images':len(p.images),'tables':p.tables,'provenanceAndHistoryPresent':True,'priorTextEquivalentAfterAuthorizedDelta':True}
for name in ['article.md','article.txt','review.md','linkedin.md','medium.md','linkedin.txt','medium.txt']:
 text=(KIT/name).read_text();before=old.read(name).decode()
 if name.endswith('.txt'):
  pairs=re.findall(r'\[(\d+)\]\s+\((https://[^\s]+)\)',text)
  flat=text;oldflat=before
 else:
  pairs=numeric_markdown_pairs(text)
  flat=text.replace('**','');oldflat=before.replace('**','')
 assert pairs==expected,(name,len(pairs))
 assert provenance in flat,(name,'provenance');assert history in flat,(name,'history')
 compare=flat.replace(provenance+'\n\n','').replace('- '+history+'\n','').replace('R27','R26')
 assert compare==oldflat,(name,'full text outside declared changes')
 results[name]={'numericLinks':len(pairs),'allCitationDestinationsOrderedExact':True,'provenanceAndHistoryPresent':True,'priorTextEquivalentAfterAuthorizedDelta':True}
for suffix in ['html','md','txt','copy-ready.html']:
 name=lambda platform:platform+('-' if suffix=='copy-ready.html' else '.')+suffix
 assert (KIT/name('linkedin')).read_bytes()==(KIT/name('medium')).read_bytes(),suffix
for platform in ['linkedin','medium']:
 assert len((KIT/(platform+'.txt')).read_text())==50323
assert (KIT/'article.txt').read_bytes()==(KIT/'linkedin.txt').read_bytes()
pm=json.loads((KIT/'article.manifest.json').read_text());assert pm['render']['browser']['managedBrowser'] is False and pm['render']['browser']['reviewOnly'] is True
pdf=fitz.open(PUBLIC/(BASE+'.pdf'));pdfpairs=[];internal=[]
for i,page in enumerate(pdf):
 for l in page.get_links():
  if l.get('uri'):
   label=page.get_text('text',clip=l['from']+(-1,-1,1,1)).strip().replace('\n',' ')
   m=re.search(r'\[(\d+)\]',label)
   if m:pdfpairs.append((m[1],l['uri']))
  elif l.get('kind') in {fitz.LINK_GOTO,fitz.LINK_NAMED} and 'page' in l:
   assert 0<=l['page']<len(pdf),l
   internal.append({'page':i+1,'targetPage':l['page']+1,'namedDestination':l.get('nameddest')})
assert pdfpairs==expected,(len(pdfpairs),pdfpairs)
assert len(pdf)==21 and len(internal)==23
pdftext=normalize(' '.join(page.get_text() for page in pdf));assert provenance in pdftext
oldpdf=fitz.open(stream=old.read('article.pdf'),filetype='pdf')
assert pdf.get_toc()==oldpdf.get_toc()
result={'artifactId':manifest['artifactId'],'kitFiles':len(actual),'hashVerifiedManifestOutputs':len(manifest['outputs']),'publicArchive':{'file':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(actual),'everyMemberEqualsNativeKit':True},'sourceByteExact':True,'launchByteExact':True,'outputs':results,'sameFormatPlatformPairsByteIdentical':True,'genericAndPlatformTextFilesByteIdentical':True,'platformTextCodePoints':50323,'limit':51000,'pdf':{'sha256':sha((PUBLIC/(BASE+'.pdf')).read_bytes()),'bytes':(PUBLIC/(BASE+'.pdf')).stat().st_size,'pages':len(pdf),'numericCitationTargets':len(pdfpairs),'numericCitationSequenceExact':True,'contentsLinks':len(internal),'provenanceTextPresent':True,'outlineUnchangedFromR26':True,'outline':pdf.get_toc()},'managedBrowser':False,'reviewOnly':True,'scope':'Structural/text/link verification; visual and real-editor acceptance remain separate.'}
Path('/tmp/r27-whitebox/artifact-observations.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['outputs','pdf']},indent=2));print(json.dumps({k:v for k,v in result['pdf'].items() if k!='outline'},indent=2))
