# R27 bounded diagnostic and independent QA evidence

Recorded 23 October 2026; baseline c60aaa2e71d1ed53763f41764c62faa89090f139.
Issue 5 / Draft PR79; article owner issue 2.
Owning review: review/issue-2/2026-10-23-r27-feedback-and-reader.md.

This archive preserves the original small reports, source snapshots, profiling,
native TAP, deliberate fault results, native artifact observations and local
browser/clipboard observations. manifest.json lists exact identities and original
temporary paths. Reports in the owning review preserve their authors' conclusions.

The implementation directory retains initial invalid native-accounting diagnostics
as superseded evidence. Only native-baseline/native-regular-global TAP and the
native-comparison.json/profile summary establish the correctly accounted 40.246738 /
16.029075 second same-case pair. The 70/70 Space receipt belongs to intermediate
source b2ba67b, before the two storage guard assertions. It does not establish the
full suite on final 4a769134. White-box before/after matrices preserve the initial
escaping fault and its correction; expected negative failures are not product passes.

This is not the final clean whole-policy report. Its current source/result and
remote delivery are recorded at the stable PR checkpoint:
https://github.com/oborskyivitalii/oborskyivitalii/pull/79#issuecomment-6372368959

The separate delivered R27 native ZIP contains all 34 native publication files.
This evidence ZIP includes the independent all-page observation receipt and exact
PDF identity, plus compact link/browser results and the actual provenance screenshot.
It does not duplicate all 21 reproducible page renders. The original final PDF is
available beside its own native ZIP. Source/producer digests, limits and the two
known native outline cosmetics remain recorded in the publication evidence.

Temporary absolute paths in original drivers/receipts describe the execution
environment; relocate them explicitly before reproducing a diagnostic. Do not run
all diagnostics as an unattended suite. No private correspondence is included.
