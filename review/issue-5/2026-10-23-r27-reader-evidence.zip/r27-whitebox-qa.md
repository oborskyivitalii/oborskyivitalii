# R27 independent White-box QA — 23 October 2026

Reviewer: `/root/r27_whitebox_qa`. Role: White-box QA only. Baseline: `c60aaa2e71d1ed53763f41764c62faa89090f139`. This reviewer did not author or modify repository code, the new regression test, article prose, edition metadata, or delivered artifacts. All injected faults were confined to temporary copies under `/tmp/r27-whitebox`.

## Independent conclusion

**PASS for the bounded White-box QA scope on the corrected candidate identified below.** The VM change retains a fresh realm and the original fixtures for each simulated visit; all 69 pre-existing Space case bodies remain byte-identical, the production runtime and acceptance wrapper remain unchanged, and the new guard rejects shared realms, exposed Node globals, host intrinsics, and shared actual storage. An original behavior case also rejects bypassing runtime execution. Independent QA found a real false-negative in the first storage guard; the implementation author added the two required assertions, and the same negative case now fails for the intended assertion.

The actual R27 public ZIP closes over exactly 34 native-kit files and all 33 declared output hashes. Source and launch bytes match their canonical inputs. The actual PDF and textual exports preserve the 49 ordered citation targets; the article argument, references, prompts, figures, tables, historical editions, and review-only state remain within the agreed delta. No unresolved blocking defect was found in this inspected scope.

This conclusion is bound to Space SHA-256 `4a7691344008723ad8d1971890e8a488d40b6ce2e286656a38690053e4a7c939`, manuscript SHA-256 `d52ae574eacc669a3d7a6658b3ba084de0f528c11321304d8057250185083835`, and native kit `3deebdbf052a2ad3616ae6ba7ea70d35c4e4c09a2e75713379f0aedfb82e154e`. It is not a substitute for the required final exact-clean 12/12 issue policy, independent visual/editorial checks, or human/publication acceptance. Those conclusions must use their own evidence and source identity.

## Inputs and risk derivation

Read the actual repository instructions and owners: `AGENTS.md`, `CONTRIBUTING.md`, relevant `CODE-STYLE.md` and acceptance sections, the dated issue-5 intake `6372120716`, the versioned R27 review, the original Space fixture and tests, the complete candidate diff, the acceptance wrapper/policy, current manuscript and publication identities, and actual native/public package bytes. The test-profile registry retains Space in its maintained profiles. The relevant CI workflows use Node 24.19.0, matching the native probe runtime.

The runtime is trusted repository code. The test harness formerly evaluated the cached `vm.Script` in a new contextified global. The candidate creates a fresh `vm.createContext(vm.constants.DONT_CONTEXTIFY)`, assigns the same `document`, `window`, and `localStorage` objects, and calls `script.runInContext`. It exposes that context only through the test fixture's returned API so that the guard can inspect the actual execution realm. The new API does not replace or bypass runtime execution.

The relevant distinction is ordinary fresh VM globals versus the contextified-global wrapper, not host execution or context reuse. The official [Node VM documentation](https://nodejs.org/api/vm.html) describes this option. VM contexts are not security mechanisms for untrusted code; the verified claim here is fixture state and intrinsic separation under the tested operations, plus absence of direct Node globals. Host-created fixture objects and functions remain as before. No hostile-code isolation claim is made.

| Risk derived from the change | Independent oracle | Observed result and scope |
| --- | --- | --- |
| Visits reuse a realm or state survives into another visit | Distinct context objects; mutate first context global/Math/Array prototype; temporary shared-realm fault | Correct candidate PASS; shared-realm variant FAIL on the identity assertion |
| Native Node globals become directly visible | Guard checks `process`, `require`, `module`, `Buffer`; inject `process` in a temporary variant | Correct candidate PASS; exposed-process variant FAIL on the named host-global assertion |
| Browser globals use host intrinsics | Math/Array/Object must differ between both visits and host; inject host values in a temporary variant | Correct candidate PASS; host-intrinsics variant FAIL on non-identity assertion |
| Actual injected storage is shared while fixture closures look independent | Compare actual storage identity and read the actual second context after a first-context write; deliberately share injected storage | Initial guard falsely PASS; corrected guard rejects the same fault |
| Exposing `browserContext` lets tests succeed without running the application | Select an original behavior case; bypass only `script.runInContext` in a temporary variant | Real execution PASS 1/1; bypass FAIL 1/1 at the original `canTravel` behavior access |
| Speed is gained by deleting cases or weakening acceptance | Byte comparison of original 69 bodies, wrapper and policy; narrow source diff | Original bodies identical; 70 current Space cases; original ten-file READER list, 180-second timeout and six-count oracle unchanged |
| Publication identity changes while substantive argument drifts | Byte comparison through complete sources/reference block, independent semantic digest, old-edition checks | Only provenance/history/citation-version delta; 20 prior edition/R26 artifact files unchanged |
| Export appears current but contains stale or incomplete content | Actual ZIP member bytes and hashes; compare each text/HTML output to old R26 after removing only declared delta | All 34 members match the kit; all 33 output digests close; export content matches the authorized change |
| Citations, figures, tables or PDF navigation regress during regeneration | Independent Markdown/HTML/PDF parsing and exact ordered target comparison | 49 ordered targets preserved; native HTML/print retains 2 tables, platform HTML 0 tables, all 4 figures; PDF has 23 valid internal contents targets |

## Findings, fixes and independent retest

### WBF01 — stale R26 source hash in the current-edition test: resolved

The first update changed the article-media test name and edition ID to R27 but retained the R26 source hash. This would fail on the actual new source. The implementation owner changed the expected hash to the independently observed canonical R27 hash. The oracle remains a fixed literal, not a value computed from the object being tested.

### WBF02 — unrelated formatting churn in article-media: resolved

A broad formatter run initially rewrote the existing test file. This was reported as unnecessary scope expansion. The owner restored the baseline formatting; the final diff contains exactly the three intended name, edition ID and source-hash replacements. The corrected file SHA-256 is `afc17f6a0c3908dc2f85a7013bcab68f69f890a216120f8abb3f6c2745903511`.

### WBF03 — shared-storage fault escaped the new guard: resolved

The initial guard wrote through `first.browserContext.localStorage`, then checked `second.stored()`. That second helper closed over the fixture's unused private storage, so it could report `off` even when the actual browser contexts shared one injected storage object. A temporary fault demonstrated this exact false-negative on intermediate Space SHA-256 `b2ba67b61d501c109b15c829388a372af8c994aaafcb4b475d5603915b853f14`.

The implementation author added two assertions: the actual injected storage objects must differ, and the actual second context must still return `off` after the first context writes `on`. White-box QA then reran the same five-variant matrix on corrected SHA-256 `4a7691344008723ad8d1971890e8a488d40b6ce2e286656a38690053e4a7c939`. The positive variant passed, and all four deliberate faults failed on their intended isolation assertions. No assertion was removed or weakened.

| Native selected execution | Before storage correction | After storage correction |
| --- | --- | --- |
| Unmodified candidate | PASS 1/1 | PASS 1/1 |
| Shared realm | Expected FAIL 1/1 | Expected FAIL 1/1 |
| Injected host `process` | Expected FAIL 1/1 | Expected FAIL 1/1 |
| Injected host Math/Array/Object | Expected FAIL 1/1 | Expected FAIL 1/1 |
| Shared actual injected storage | **Unexpected PASS 1/1; defect found** | Expected FAIL 1/1 |

Separate original-case check: `articles retain common Off and reduced-motion behavior across document changes` passed 1/1 on corrected source. The same case failed 1/1 when the sole runtime execution call was removed in a temporary copy. This is a behavioral negative control independent of the added realm guard.

Every selected invocation used native Node 24.19.0 TAP and was checked for the actual named subtest plus all six final counters. No selected run had a skip, cancellation or todo. Expected negative cases have one failure and a nonzero exit code; they are successful fault-detection evidence, not passing product runs. The earlier false-pass is retained in the before matrix. A file-wrapper-only exit-0 result would not satisfy this evidence rule.

## Source and edition invariants

`source-observations.json` records the exact digests and comparisons. The unchanged wrapper SHA-256 is `60305565f93ec694f1945c67dc63cc1e085f2d3ae3c13fcebdc80bf35e082aae`; the unchanged policy SHA-256 is `27ad8e1dd6f328c5cfeebd48b572abc365e9fdd9c3296be06ea6bd0f4c451429`. The unchanged runtime SHA-256 is `ac43775efbe45fba9fa7554aaaa2ceb313f63faf35d037115c9f426a4dd8162f`.

All original 69 Space test bodies are byte-identical. The sole new case increases that module to 70. Its fixture delta changes context construction and returns the context for inspection; it does not alter DOM fixtures, interaction loops, expected behavior, or exception handling. The acceptance wrapper still runs its original complete ten-module list with the original 180-second deadline and rejects nonzero failures, skipped, cancelled and todo cases.

The argument from the cover through the complete sources/reference section is byte-identical to R26. The three main parts, 12 standalone prompts, four canonical figures and 36 references remain. Forty-seven standalone numeric links plus the opening Slides [1]/Recording [2] links yield 49 ordered citation occurrences. Both context-dependent [31] destinations remain their distinct original URLs. The launch remains a separate authored file and adds its own bounded acknowledgment.

The R27 edition source pin matches the manuscript. Its semantic digest was independently recomputed as `21d29d8504a8a9fb44e863021b2a8144fb1fb2fc2f93be21dbe4cf64d6b3b724`, matching the declared identity. The launch hash matches the canonical launch bytes. Article state remains `review`, rights remain `review-pending`, the canonical URL remains null, and accepted commit/blob values remain null. Both review text limits remain 51,000. Twenty historical edition and R26 public-package files match the baseline byte-for-byte. A separate comparison of 150 tracked default/runtime/publisher files found zero changes.

These observations support the provenance-only article delta. They do not accept substantive editorial proposals or claim that the correspondent reviewed an exact R27/R26 PDF.

## Actual public artifact verification

Checked the actual `review/issue-2/r27-20261023/The_Sum_of_Our_Technology_R27_2026-10-23_Native_Review_Kit.zip`, not only the working output directory:

| Identity/check | Observed value |
| --- | --- |
| Native artifact ID | `3deebdbf052a2ad3616ae6ba7ea70d35c4e4c09a2e75713379f0aedfb82e154e` |
| Public ZIP | 6,517,105 bytes; 34 exact members; integrity test passed |
| Public ZIP SHA-256 | `1ba55facb646824c34018e644fc7329bcfd806f1c66b4217bd338b0461fd3069` |
| Manifest closure | 33 declared outputs plus manifest; every output byte length and SHA-256 independently verified |
| Canonical inputs | Public/kit Markdown equals the canonical source; kit launch equals canonical launch; public PDF equals native PDF |
| PDF | 1,412,004 bytes; 21 pages |
| PDF SHA-256 | `2f5fde5749b6cc294f1026d293df5aa0c9cc645ea7d3cba0ca3c5e9194414ad6` |
| Citation links | All 49 ordered numeric targets match in actual PDF and checked HTML/MD/TXT outputs |
| PDF contents | 23 internal destinations resolve to valid document pages |
| Native HTML/print | Four article images and two tables in each |
| LinkedIn/Medium HTML | Four article images and flattened-table output in each |
| Platform equivalence | Same-format LinkedIn and Medium outputs are byte-identical |
| Emitted text | `article.txt`, `linkedin.txt` and `medium.txt` are byte-identical; 50,323 code points each, below 51,000 |
| Producer boundary | `managedBrowser:false`, `reviewOnly:true` retained |

Thirteen textual/HTML outputs were compared with their R26 equivalents after removing only the added provenance paragraph/history bullet and replacing the version/edition identifier with R26. All remaining text matched. HTML headings match their prior counterparts. The actual PDF contains the new provenance paragraph and its complete outline equals the prior R26 outline.

The two inherited doubled bookmark labels, `III. What If Not?III. What If Not?` and `Review provenanceReview provenance`, are unchanged. They are a bounded pre-existing cosmetic publisher issue, not evidence of a new R27 link regression. A future publisher change can address them separately; this review does not expand the current provenance/harness change to edit the print engine.

The independent parser was corrected during development to handle balanced/escaped parentheses in DOI targets, the lowercase edition identifier, and PDF named destinations. Those were QA-checker assumptions; no product output was altered to satisfy them. Final structural/text checks passed. This report does not replace visual inspection of rendered pages or testing in real platform editors.

## Reused evidence, residual limits and delivery gate

The implementation author's native full-Space receipt reports 70/70, zero failures/skips/cancellations/todo, in 101.139 seconds. That receipt is bound to intermediate source `b2ba67…`, before the two added storage assertions, and is not represented here as a full run of corrected `4a7691…`. The original case bodies and context implementation did not change between those two sources; this review directly reran the changed guard and an original behavior case on final `4a7691…`.

The implementation author's valid paired same-case profile reports 40.246738 seconds versus 16.029075 seconds, with one real named case in each run. This is evidence about that controlled case and environment, not a universal performance promise. Earlier wrapper-only timings must remain diagnostic-only. White-box QA did not rerun full suites or interfere with the coordinated heavy-test slot.

At this report's boundary, the required final exact-clean policy, delivery commit/tree, remote readback and other independent role conclusions are owned by the parent. This report authorizes no merge, publication, canonical activation, rights acceptance or blanket issue closure. If the bound source, fixture semantics, acceptance selection, or native artifacts change, review the relevant delta before reusing this conclusion.

## Retained raw evidence

`/tmp/r27-whitebox-raw-inventory.json` explicitly lists the small evidence files and their SHA-256 values for the durable issue-5 evidence ZIP. It includes both mutation matrices, all raw selected TAP/stderr, the runtime-bypass receipt, the original probe drivers, the before/after candidate snapshots, independent static/artifact observations, and a reconstruction checker. It excludes duplicate full mutant files and any temporary repository/symlink tree.

`reconstruct-mutations.py` reconstructs all 12 recorded source variants from the two retained candidate snapshots and verifies every variant/source and TAP digest without running Node. Its successful output is `mutation-reconstruction.json`. Thus the intermediate false-negative remains reproducible even though the corrected candidate supersedes it. The permanent regression guard lives in the maintained Space suite; these bounded fault injections are review evidence, not a new unattended test runner.
