const test = require('node:test');
const assert = require('node:assert/strict');
test('sentinel pass', () => assert.equal(1, 1));
test('sentinel expected failure', () => assert.equal(1, 2));
