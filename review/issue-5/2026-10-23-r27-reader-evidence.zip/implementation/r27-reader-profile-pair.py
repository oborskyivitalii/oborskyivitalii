from pathlib import Path
import json, hashlib, subprocess, time, re, collections
root = Path('/workspace/scratch/c91ea22e72f1/author-site')
probe = Path('/tmp/r27-reader-probe')
meta = json.loads((probe/'comparison.json').read_text())
meta['execution'] = 'unsandboxed approved; native named test accounting required'
meta['runs'] = []
profiles = {}
for variant in ('baseline', 'regular-global'):
    prof = probe/('cpu-native-'+variant)
    prof.mkdir(exist_ok=True)
    assert not list(prof.glob('*.cpuprofile'))
    cmd = ['node', '--cpu-prof', '--cpu-prof-dir='+str(prof), '--test', '--test-reporter=tap', '--test-name-pattern='+meta['pattern'], str(probe/'tests'/f'{variant}.test.cjs')]
    before = time.monotonic()
    result = subprocess.run(cmd, cwd=root, capture_output=True, text=True, timeout=180)
    wall = time.monotonic() - before
    (probe/f'native-{variant}.tap').write_text(result.stdout)
    (probe/f'native-{variant}.stderr').write_text(result.stderr)
    counts = {k: int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$', result.stdout, re.M)}
    subtests = re.findall(r'^# Subtest: (.+)$', result.stdout, re.M)
    report = {'variant': variant, 'command': cmd, 'returncode': result.returncode, 'wall_seconds': wall, 'counts': counts, 'subtests': subtests, 'stdout_sha256': hashlib.sha256(result.stdout.encode()).hexdigest(), 'stderr_sha256': hashlib.sha256(result.stderr.encode()).hexdigest()}
    meta['runs'].append(report)
    (probe/'native-comparison.json').write_text(json.dumps(meta, indent=2)+'\n')
    print(json.dumps(report), flush=True)
    assert result.returncode == 0
    assert counts == {'tests': 1, 'pass': 1, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
    assert subtests == ['all direct route flights paint only their journey rooms through the last transit frames']
    scene_profiles = []
    for file in prof.glob('*.cpuprofile'):
        raw = file.read_bytes()
        data = json.loads(raw)
        if any(node['callFrame']['url'].endswith('/docs/space.js') for node in data['nodes']):
            scene_profiles.append((file, raw, data))
    assert len(scene_profiles) == 1
    file, raw, data = scene_profiles[0]
    nodes = {node['id']: node for node in data['nodes']}
    costs = collections.Counter()
    for sample, delta in zip(data['samples'], data['timeDeltas']):
        frame = nodes[sample]['callFrame']
        costs[(frame['functionName'], frame['url'], frame['lineNumber']+1)] += delta
    profiles[variant] = {'profile': str(file), 'sha256': hashlib.sha256(raw).hexdigest(), 'duration_seconds': (data['endTime']-data['startTime'])/1e6, 'functions': [{'name': key[0], 'url': key[1], 'line': key[2], 'sampled_seconds': value/1e6} for key,value in costs.most_common()]}
    (probe/'native-profile-summary.json').write_text(json.dumps(profiles, indent=2)+'\n')
