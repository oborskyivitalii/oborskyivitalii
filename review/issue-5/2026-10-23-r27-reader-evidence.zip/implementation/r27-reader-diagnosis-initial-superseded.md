**SUPERSEDED DIAGNOSTIC: the first paired run used sandboxed Node execution that returned only a file-wrapper TAP row. Its native case accounting was invalid. Statements below claiming a selected case pass are withdrawn; use r27-reader-diagnosis.md and native-comparison.json. No source or policy acceptance relies on this initial report.**

# R27 READER fixture diagnosis — implementation analysis

## Scope and source

The accepted user request is to correct the previous READER failure without weakening the check. Read-only inspection used clean PR79 commit `c60aaa2e71d1ed53763f41764c62faa89090f139`. The owning criterion is issue5 AC13 (READER plus WRITING-CATALOG); the independent Requirements reviewer approved this bounded fixture proposal before implementation. This is implementer evidence, not independent QA.

- Node: `v24.19.0`; repository workflows and toolchain documentation pin Node24.19.0.
- Original `tests/space.test.cjs` SHA256: `72e2b0ada3dcc84904927b0fa5d8168b7ba1e559d7f7e39860f8f5921e52065a`.
- Unchanged `docs/space.js` SHA256: `ac43775efbe45fba9fa7554aaaa2ceb313f63faf35d037115c9f426a4dd8162f`.
- Original READER single180s wrapper, ten selected files, all69Space cases and all264 original reader cases remain required.

## Failure mechanism and controlled comparison

`visit()` already compiles the generated scene once into a cached `vm.Script`. It then executes the complete scene in a newly **contextified** global object for each simulated page. Source repeatedly accesses realm globals such as Math in its rendering hot loops. A native ordinary global in a new VM realm avoids Node's additional contextification wrapper while retaining fresh realm isolation and the exact same injected document/window/localStorage fixtures.

Temporary variant files in `/tmp/r27-reader-probe` differ only in the three-line VM boot replacement. Relative docs/review resolution is held equal through the same symlink targets. No production or repository test file was edited for this measurement. Both runs used the same selected expensive test, **all direct route flights paint only their journey rooms through the last transit frames**, which includes all20directed route pairs at both desktop/mobile widths, unchanged simulated frames and assertions. Both ran with the same CPU profiler flags. Runs were sequential baseline then candidate; this single controlled pair is not a general performance guarantee.

| Variant | Wall seconds | Result | clamp sampled seconds | loopTransform sampled seconds | GC sampled seconds |
| --- | ---: | --- | ---: | ---: | ---: |
| Original contextified global | 48.974704562 | 1/1 selected case PASS | 12.404890 | 3.847 | 1.911 |
| Fresh ordinary VM global | 15.526356338 | 1/1 selected case PASS | 0.041555 | 0.422 | 2.019 |

Measured wall reduction is 68.30% for this profiled case. The profiler itself changes runtime; these wall values cannot be compared directly with historical unprofiled27s timings. Sample times locate expensive work but are not exact instruction accounting. This supports contextified-global lookup overhead as a removable cause of excessive fixture CPU, not a claim that every earlier timeout was environment-only or that browser production performance improves.

Node's documented `vm.constants.DONT_CONTEXTIFY` creates an ordinary global within a new context, exposes that context's own builtins, and was supported before the repository's Node24.19.0 pin. Primary documentation: https://nodejs.org/api/vm.html#vmconstantsdont_contextify . The runtime was locally checked to expose the constant as a symbol.

## Proposed bounded correction and retained gates

Use fresh `vm.createContext(vm.constants.DONT_CONTEXTIFY)` per `visit`, inject the same fixtures, and execute the alreadycompiled `vm.Script` through `runInContext`. Verify actual visit realms have distinct globals/intrinsics, injected fixtures remain the same objects, Node host globals remain absent, and a mutation in one realm does not reach another or the host. All original case bodies, assertions, matrices, simulated frames, productionbytes and wrapper180s remain unchanged. Add one isolation regression (70Space/265READER total).

The maintained source-runner documentation also describes capped scheduling and separate Space/rest batches. Replacing this acceptance wrapper wholesale would change its currently single180s process observation into two180s batches; that is not the chosen correction. Do not silently broaden deadline/scope.

Pending before acceptance: implement after issue scope anchor; independent Code/White-box/Exploratory review; unchanged full READER and exact-clean-head full issue policy. A selected-case pass is not a whole-policy pass.

## Retained raw evidence

- `/tmp/r27-reader-probe/comparison.json`: exact commands, durations, return codes and source hashes.
- `/tmp/r27-reader-probe/profile-summary.json`: perfunction sampled totals and raw profile SHA256.
- `/tmp/r27-reader-probe/baseline.tap`, `/tmp/r27-reader-probe/regular-global.tap`: complete selected-case TAP.
- `/tmp/r27-reader-probe/cpu-baseline/CPU.20261023.203403.14.0.001.cpuprofile`: baseline CPU profile, SHA256 `e07c78a4c604ef89b28ee9860f8a69e4911520e6eedf6c0bc30a55942257b3f0`.
- `/tmp/r27-reader-probe/cpu-regular-global/CPU.20261023.203452.28.0.001.cpuprofile`: candidate CPU profile, SHA256 `1f5c2b5c3cd538fa16cf6ddb01e3c647cfa6ee2238eceb522b3ab79382c70984`.
