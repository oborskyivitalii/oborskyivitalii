# R27 READER fixture correction — implementer evidence

## Outcome and exact prepared source

The inherited Space browser-simulation fixture was doing avoidable work through Node's contextified global wrapper. It now creates a fresh ordinary global inside a separate VM realm for each simulated visit, injects the same browser fixtures, and runs the same precompiled scene. All original 69 Space cases, their assertions and simulated frames remain byte-identical. One new isolation case makes 70 Space cases and 265 original-plus-new cases in the unchanged ten-file READER selection.

This is implementation evidence for issue 5 / PR79, not an independent quality review or a whole-policy pass. The approved scope anchor is https://github.com/oborskyivitalii/oborskyivitalii/issues/5#issuecomment-6372120716 . Requirements preflight accepted this limited treatment before implementation. Full current-clean-source issue policy remains the root agent's separate gate.

- Baseline head: `c60aaa2e71d1ed53763f41764c62faa89090f139`.
- Final prepared `tests/space.test.cjs` SHA256: `4a7691344008723ad8d1971890e8a488d40b6ce2e286656a38690053e4a7c939`.
- Original file SHA256: `72e2b0ada3dcc84904927b0fa5d8168b7ba1e559d7f7e39860f8f5921e52065a`.
- Exact inverse-edit proof reconstructs original file byte-for-byte after removing the new guard and reverting the VM boot/API additions.
- Unchanged generated runtime SHA256: `ac43775efbe45fba9fa7554aaaa2ceb313f63faf35d037115c9f426a4dd8162f`.
- Unchanged issue 5 policy SHA256: `27ad8e1dd6f328c5cfeebd48b572abc365e9fdd9c3296be06ea6bd0f4c451429`.
- Unchanged acceptance wrapper SHA256: `60305565f93ec694f1945c67dc63cc1e085f2d3ae3c13fcebdc80bf35e082aae`.
- Node: `v24.19.0`. The repository pins this version; `vm.constants.DONT_CONTEXTIFY` exists in this runtime.

## Controlled native comparison

The proper comparison ran the exact same named case, `all direct route flights paint only their journey rooms through the last transit frames`, over all 20 directed route pairs at both desktop/mobile widths. The temporary variants differ only in the three-line VM creation/run replacement. Both use the same runtime bytes, fixtures, simulated frames and case assertions. Both were sequential, baseline then candidate, under the same CPU-profiler flags and approved unsandboxed process execution, without competing heavy jobs. Native TAP proves the named case actually executed: 1 test, 1 pass, 0 fail/skip/cancel/todo in each run.

| Observation | Original contextified global | Fresh ordinary VM global |
| --- | ---: | ---: |
| Profiled wall seconds | 40.246738365 | 16.029075352 |
| Native named case count | 1/1 PASS | 1/1 PASS |
| `clamp` sampled seconds | 10.144441 | 0.074929 |
| `loopTransform` sampled seconds | 2.556786 | 0.517361 |
| Garbage collector sampled seconds | 2.103210 | 1.512422 |

Measured wall reduction: **60.17%** for this profiled case. `clamp` uses repeated `Math.max/min` access; the large reduction in that hotspot is consistent with eliminating the Node-specific contextification lookup overhead. The ordinary global is still in a new realm; the fix does not share the host's Math / Array / Object.

This is one sequential paired diagnostic, not a universal speed guarantee. Profiler overhead means they cannot be compared directly with historical unprofiled runs. Sampled CPU locations are not exact instruction accounting. The result identifies a concrete removable fixture cost; it does not prove every earlier timeout's complete cause, improve actual browser performance, or establish full issue acceptance.

The primary API documentation describes ordinary globals and separate-context builtins: https://nodejs.org/api/vm.html#vmconstantsdont_contextify . Node VM is not a security mechanism; this correction claims test state/realm isolation only.

## Complete source-suite observation and guard correction

The actual repository Space suite ran with complete native TAP under its unchanged 180 s deadline:

- **70/70 PASS**, zero failed/skipped/cancelled/todo, exit 0, wall **101.138542777 s**.
- Command: `node --test --test-reporter=tap tests/space.test.cjs`.
- Prepared source SHA256 for this observation: `b2ba67b61d501c109b15c829388a372af8c994aaafcb4b475d5603915b853f14`.
- Raw TAP SHA256: `be75e987c8f8160e5ebd907deff7e2fcbdd72a9cffa3b36d6fc964fd059f8333`.

This 70-case observation preceded the final two-assertion strengthening of the new isolation guard; it must not be described as a full run of final SHA `4a7691344008723ad8d1971890e8a488d40b6ce2e286656a38690053e4a7c939`. The original 69 test bodies and fixture boot remain unchanged across that correction.

Independent White-box QA `/root/r27_whitebox_qa` found a real defect in the first new guard: `second.stored()` reads its private fixture closure, so it alone could miss two VM contexts sharing the actual injected storage object. The implementer added an assertion that the injected storage objects differ and an assertion that the second VM's actual `getItem()` still returns its own value after a write in the first.

QA then executed the corrected actual isolation case on final SHA `4a7691344008723ad8d1971890e8a488d40b6ce2e286656a38690053e4a7c939`: **1/1 PASS**. All four independently injected faults correctly failed 1/1: shared realm, host process global injection, shared host Math / Array / Object, and shared actual storage. The agent's original raw results are `/tmp/r27-whitebox/after/mutation-matrix-after.json`; these are its independent observations, not claimed implementer tests. QA retains the initial escaping shared-storage mutation as historical failure evidence.

The new guard also checks exact window/document fixture references, separate globals/intrinsics, absence of process/require/module/Buffer, and no global/prototype leakage into another visit or the host. The production scene execution remains unconditional.

## Initial accounting failure — retained and superseded

The first diagnostic attempts ran inside the tool sandbox. A two-case sentinel showed that this environment collapses Node child-test reporting to a file-wrapper row; it reported 1 file wrapper instead of the actual 1 passing and 1 deliberately failing named cases. Approved unsandboxed execution correctly reported 2 named tests, 1 pass and 1 fail.

Accordingly, the initial profiled wall pair 48.974705 s / 15.526356 s and initial full-file 87.650410 s exit 0 are **invalid native case accounting**, not 1/1 or 70/70 test passes. They are retained only as superseded diagnostics. The valid native paired comparison above supersedes that initial causal-evidence table. No acceptance checkbox or completed-test claim may rely on the sandbox file-wrapper output.

## Scope, style and remaining gate

Only `tests/space.test.cjs` was edited by this implementation role. No production code, generated runtime, acceptance policy, test list, assertion in an existing case, simulated frame count, 180 s timeout, minimum count or zero-skip rule was weakened. The existing source-runner batching alternative was deliberately not introduced: its two 180 s batches would change the current single-process READER observation.

Applicable style rules: CS01 (test ownership), CS05 (readable focused edit), CS07 (measured avoidable fixture work), CS08 (meaningful isolation/negative checks) and CS10 (issue/evidence mapping). The exact pinned Prettier 3.6.2 command with `--config tools/quality/prettier.config.json --check tests/space.test.cjs` passes; `git diff --check` passes. A preliminary direct Prettier invocation omitted the repository configuration and was not a valid repository-format judgment; it did not modify files.

The existing permanent suite remains selected by its own changed path, `pr-targeted`, `staging` and `production` profiles, plus issue 5's unchanged ten-file READER check. There is no new test module or standalone runner. Root owns current RI refresh, the full final issue policy and remote handoff. Do not tick AC13 before its required READER and WRITING-CATALOG checks both pass on the current exact committed source.

## Evidence inventory

`/tmp/r27-reader-evidence-inventory.json` enumerates exact files, bytes and SHA256 for the implementation diagnostics. The core receipts are:

- `/tmp/r27-reader-source-preservation.json`: original 69 body/fixture proof and source identities.
- `/tmp/r27-reader-space-result.json`, `/tmp/r27-reader-space.tap`, `/tmp/r27-reader-space.stderr`: complete 70-case observation at its stated prepared source.
- `/tmp/r27-reader-probe/native-comparison.json`: exact paired commands, wall times, native counts and names.
- `/tmp/r27-reader-probe/native-profile-summary.json`: exact per-function sampled totals and raw profile identities.
- `/tmp/r27-reader-probe/native-baseline.tap`, `/tmp/r27-reader-probe/native-regular-global.tap`: native named-case output.
- `/tmp/r27-reader-profile-pair.py`: reproducible bounded comparison driver.
- `/tmp/r27-reader-space-sandbox-file-wrapper.*`, `/tmp/r27-reader-probe/comparison.json` and first profiles: retained invalid-accounting diagnostics.
- `/tmp/r27-whitebox/after/mutation-matrix-after.json`: separate QA correction evidence; copy the QA agent's own receipt for independent conclusions.
