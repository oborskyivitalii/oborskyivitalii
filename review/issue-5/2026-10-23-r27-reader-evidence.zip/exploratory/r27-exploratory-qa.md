# R27 independent Exploratory / Interaction QA receipt

Date: 23 October 2026 UTC. Reviewer: `/root/r27_exploratory_qa`, independent of the manuscript, READER fixture correction, native export producer and artifact packaging implementation. No repository source, test, generated PDF or delivered kit was edited by this reviewer.

**Disposition: PASS for the bounded author-review artifact and local interaction charter. No new blocking defect observed.** Two previously disclosed cosmetic native PDF outline labels remain duplicated; their destinations and the visible document headings are correct. This receipt does not accept publication, a managed-browser print gate, READER performance, an exact-clean repository run, the remote PR head, rights, or native LinkedIn/Medium editor behavior.

## Inputs, authority and artifact binding

Independently inspected the user request and supplied feedback, actual `AGENTS.md`, `CONTRIBUTING.md`, relevant README/site instructions, `guides/ARTICLE-WORKFLOW.md`, `guides/SITE-CONTENT-REVIEW.md`, `.github/ACCEPTANCE.md`, `guides/SITE-CHECK-PROFILES.md`, current manuscript/profile/edition/launch sources, and `review/issue-2/2026-10-23-r27-feedback-and-reader.md`. Read the PDF skill for visual inspection. Historical memory was treated as context only. Independently retrieved the live issue 5 acceptance comment [6372120716](https://github.com/oborskyivitalii/oborskyivitalii/issues/5#issuecomment-6372120716); relevant obligations are R27.2, R27.4 and R27.5, with explicit limits for R27.1/R27.6.

Baseline: `c60aaa2e71d1ed53763f41764c62faa89090f139`. Reviewed candidate is the prepared R27 working-tree content and its actual immutable native export, not a claimed committed or published edition.

| Binding | Observed value |
| --- | --- |
| Content edition | `pmday-ai-both-sides-en-review-20261023-r27` |
| Native kit directory ID | `3deebdbf052a2ad3616ae6ba7ea70d35c4e4c09a2e75713379f0aedfb82e154e` |
| Source SHA256 | `d52ae574eacc669a3d7a6658b3ba084de0f528c11321304d8057250185083835` |
| Semantic SHA256 | `21d29d8504a8a9fb44e863021b2a8144fb1fb2fc2f93be21dbe4cf64d6b3b724` |
| Separately authored launch SHA256 | `4004f504dc9ade52d4d364bafce10645510f48c9cfe435688eba6c894d5a5003` |
| PDF SHA256 | `2f5fde5749b6cc294f1026d293df5aa0c9cc645ea7d3cba0ca3c5e9194414ad6` |
| PDF size / pages | 1,412,004 bytes / 21 pages |
| Delivered ZIP SHA256 | `1ba55facb646824c34018e644fc7329bcfd806f1c66b4217bd338b0461fd3069` |
| Delivered ZIP size / files | 6,517,105 bytes / 34 files |

The actual delivered folder is `review/issue-2/r27-20261023/`. Its separately delivered PDF and Markdown match the native kit bytes exactly. Independently compared every one of the 34 ZIP members, including manifests and the immutable PDF artifact record, with its corresponding native file: all identical. Opened the ZIP-extracted HTML for the interaction checks below. `article.md` matches the canonical manuscript byte for byte, and `launch-post.md` matches the separate authored launch file byte for byte.

The manifest truthfully declares `working-tree-review`, null source commit/blob, review selection, null canonical, and Chromium `153.0.8010.0` with `managedBrowser:false` / `reviewOnly:true`; Playwright is `1.63.0`. Existing copyright/figure credits and pending per-item publication clearance remain present in the instructions. These declarations were observed rather than promoted to stronger acceptance.

## Independently designed charter and execution

Case bound: all 21 actual PDF pages; all six HTML forms; all 49 numeric citation destinations in each; all 23 Contents targets; 24 native outline destinations; two actual contextual `[31]` link clicks; two real local rich-text copy/paste transfers; all 34 archive members. Scope was selected from the risks of a new provenance paragraph, edition/citation/history drift, export divergence, broken navigation and reflow at the article end. No extra platform/device matrix was introduced.

| Case / AC | Action and independent oracle | Executed result |
| --- | --- | --- |
| E1 / R27.4–5: actual PDF presentation | Rasterized every page and personally inspected every resulting page image. Expected complete text, coherent page transitions, visible captions/credits, no cut-off table content, and readable new provenance/citation/history. | PASS: all 21 pages inspected. No new visual blocker or clipping/overlap observed. |
| E2 / R27.2, R27.5: truthful provenance and edition | Inspected p. 20 citation/BibTeX, p. 21 provenance/history, six HTML forms, text/Markdown variants and separate launch. Expected all three contributors, retained author responsibility, R27/date consistency, and Olivier's suggestions explicitly pending. | PASS. Olivier appears once in each article HTML form; all retain the exact recorded-for-editorial-consideration status and R27 history. No reviewed-R26, endorsement, coauthorship or incorporated-proposal claim was introduced. |
| E3 / R27.5: preserved argument and source notes | Compared the canonical source span from the opening argument through all source notes against `git show c60aaa2:.../manuscript.en.md`. Independently counted structure. | PASS: argument and all source notes are byte-identical to R26; three parts, 12 explicit prompts and 36 numbered references remain. |
| E4 / R27.4–5: citations and contents | Independently parsed balanced Markdown link targets, compared all numeric destination pairs to PDF annotations and all six HTML files, inspected PDF destination pages, then actually clicked all 23 HTML Contents entries. | PASS: 49 ordered citation number/URL pairs match exactly in PDF and each HTML form; all Contents clicks set the expected hash and show the target heading in the viewport. All 23 PDF Contents destinations and all 24 outline destinations reach their intended heading pages. |
| E5 / R27.5: contextual source 31 | Clicked each actual `[31]` anchor in the delivered article; intercepted and aborted external requests while recording the requested URL. Independently compared PDF annotations. | PASS: title context requests `https://english.lem.pl/works/essays/summa-technologiae` (PDF p. 2); quotation context requests `https://existentialtech.antikythera.org/` (PDF p. 13). No external source availability or content re-verification is implied. |
| E6 / R27.4–5: images and table equivalence | Loaded `article.html`, `print.html`, LinkedIn/Medium HTML and both copy-ready forms in local Chromium. Checked decoded dimensions/alt text and independent table-cell content. | PASS: four figures decode in all six forms; article/print retain two tables. All 24 header/value cell pairs survive the declared labeled-row fallback in all four platform forms. No horizontal document overflow or page error observed at 1100 × 900. |
| E7 / R27.4–5: usable local copy-ready body | Selected the real article body, sent Ctrl+C, focused a new local rich-text target, then sent Ctrl+V for each copy-ready file. Expected images, citation links and new provenance/history to survive. | PASS for both: four embedded images, all 49 exact numeric URLs, three contributors, author responsibility, pending editorial status and R27 history retained. Pasted body text length is 43,468 characters in each. This is local clipboard transfer only. |
| E8 / R27.4: delivered bytes | Compared delivered PDF/MD and every ZIP member with native output; inspected extracted manifests and launched extracted HTML. | PASS: exact PDF/MD identity and 34/34 ZIP member identity; review-only producer/source status preserved. |

The independent citation scanner initially produced a false mismatch because a naive URL regex stopped at the first closing parenthesis in the DOI for source 16. A balanced-parenthesis scanner resolved that diagnostic error. Numeric labels were normalized separately from descriptive labels on the opening Slides/Recording anchors. The corrected oracle establishes the 49 exact ordered pairs; no product/export correction was needed.

## Actual visual observations

Page 1 has a complete, readable Contents panel and consistent R27 label. The four figures on pages 2, 4, 9 and 12 are sharp and retain readable explanatory captions and source credits. The first table on page 9 remains intact. The second table crosses pages 13–14 at row boundaries with the header repeated; text wraps inside the intended columns without clipping. Body and references remain legible throughout pages 2–20. Page 20's R27 citation and BibTeX fit within the layout. Page 21 presents Maximiliano Armesto, Pasquale Langella and Olivier Leturcq in separate paragraphs, followed by the author's responsibility statement and a legible revision history. The new paragraph and list entry create no final-page overflow.

Viewed the live HTML provenance/history screenshot after actual Contents navigation as a separate browser observation. It presents the same pending status, names, author responsibility and R27 history as the PDF.

Two existing native outline cosmetics remain:

- `III. What If Not?III. What If Not?` points to the correct single visible heading on page 13.
- `Review provenanceReview provenance` points to the correct single visible heading on page 21.

The visible page headings and Contents labels are not duplicated. These are retained disclosed limitations of this native review producer, not new R27 content failures. No manual PDF patch was applied. A renderer change to eliminate them belongs with a separately reproduced native-print case; it is unnecessary to establish this provenance update's correctness.

## Regression and CI handoff

E1/E2/E4/E5/E7 remain retained manual/agent-observed checks for this exact artifact: page judgment, truthful editorial status, actual navigation and clipboard transfer are not substituted by a source-level pass. The original raw records and receipt are available for the owning review artifact. No new permanent test is proposed because this charter found no new implementation defect and the render/template/link pipeline is unchanged.

E3/E6/E8 have existing maintained owners: `tests/publishing.test.cjs` covers source-bound complete kits, semantic identity, headings and equivalent forms; `tests/publishing-profile.test.cjs` covers separate launch pins and source-owner boundaries; `tests/publishing-print.test.cjs` covers print resource/provenance integrity and rejection of mismatched/alternate managed evidence. `tests/article-media.test.cjs` owns current source/asset identity and corruption negatives. These are permanent suites in `tools/quality/test-profiles.json`, owned by `guides/SITE-CHECK-PROFILES.md`, with `pr-targeted`, `staging`, `production` and (where registered) `content` selectors. The surviving source route is `node tools/quality/source-tests.cjs --profile production`; admitted PR checks use `.github/workflows/site-checks.yml`, job `checks`, through `tools/quality/local.cjs`. Publication/source input paths select the appropriate registered suites; this receipt does not claim those suites or remote jobs were run by this QA agent. Current Draft workflow deferral and full exact-clean policy completion remain separate.

No new CI LLM role, registry entry, browser matrix, budget increase or additional test file is requested. Root and the white-box reviewer own the READER fixture isolation/performance regression and exact-clean acceptance, with their own original evidence.

## Retained evidence and limits

- `/tmp/r27-exploratory/static.json`: PDF links/outline, corrected independent citation oracle, source/launch identity, exact archive comparison, table-fallback checks and inspected-page record.
- `/tmp/r27-exploratory/browser.json`: all six delivered HTML forms, real Contents interactions, intercepted `[31]` requests and clipboard results.
- `/tmp/r27-exploratory-browser.mjs`: original bounded browser procedure.
- `/tmp/r27-exploratory/page-01.png` through `page-21.png`: actual PDF page renders inspected by this reviewer.
- `/tmp/r27-exploratory/browser-provenance.png`: actual delivered HTML after navigation; visually inspected.
- `/tmp/r27-exploratory/pdf-text.txt`: independent PDF text extraction used with the page images and annotation checks.

Not observed: hosted staging/production, native LinkedIn/Medium paste or image upload, public publication, physical devices, browser performance, full READER policy, remote CI and exact pushed-head identity. No claim is made that local automation establishes human usability, rights clearance, author acceptance or release readiness. The private correspondence was used only to assess the bounded neutral attribution; its private earlier material is not reproduced here.
