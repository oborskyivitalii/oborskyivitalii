import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {chromium} from '/workspace/scratch/c91ea22e72f1/author-site/tools/publishing/toolchain/node_modules/playwright/index.mjs';
import sparticuz from '/tmp/r24-chromium/node_modules/@sparticuz/chromium/build/index.js';

const dir='/tmp/r27-exploratory/delivered-kit';
const expected=JSON.parse(await fs.readFile('/tmp/r27-exploratory/static.json','utf8')).expectedNumeric;
const browser=await chromium.launch({executablePath:'/tmp/chromium',headless:true,args:sparticuz.args});
const context=await browser.newContext({viewport:{width:1100,height:900}});
const results={browser:browser.version(),source:'Actual delivered ZIP extracted after byte comparison of all 34 members',files:[],navigation:[],copy:[],externalClicks:[]};
try {
 for(const name of ['article.html','print.html','linkedin.html','medium.html','linkedin-copy-ready.html','medium-copy-ready.html']) {
  const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('file://'+path.join(dir,name));
  await page.waitForFunction(()=>Array.from(document.images).every(i=>i.complete));
  const details=await page.evaluate(()=>{
   const body=document.querySelector('.article-print-body');
   const text=body.innerText;
   return {
    title:document.title,lang:document.documentElement.lang,
    figures:Array.from(body.querySelectorAll('figure')).map(f=>({caption:f.querySelector('figcaption')?.textContent,image:{naturalWidth:f.querySelector('img').naturalWidth,naturalHeight:f.querySelector('img').naturalHeight,srcType:f.querySelector('img').src.startsWith('data:')?'data':'file',alt:f.querySelector('img').alt}})),
    numeric:Array.from(body.querySelectorAll('a')).filter(a=>/\[\d+\]/.test(a.textContent)).map(a=>({text:a.textContent.match(/\[\d+\]/)[0],url:a.href})),
    tables:body.querySelectorAll('table').length,overflow:document.documentElement.scrollWidth>innerWidth,
    contributors:['Maximiliano Armesto','Pasquale Langella','Olivier Leturcq'].map(name=>({name,count:text.split(name).length-1})),
    provenanceStatus:text.includes('These comments are recorded for editorial consideration.'),
    historyR27:text.includes("R27: Olivier's feedback recorded; substantive editorial proposals remain under review."),
    responsibility:text.includes('Vitalii Oborskyi retains editorial responsibility.'),
    citeR27:text.includes('Editorial draft R27, 23 October 2026'),
    bodyCharacters:Array.from(text).length
   };
  });
  assert.deepEqual(details.numeric,expected,name+' numeric destinations');
  assert.equal(details.figures.length,4,name+' figures');
  assert(details.figures.every(f=>f.image.naturalWidth>0&&f.image.naturalHeight>0&&f.image.alt),name+' images decoded and alt');
  assert(details.contributors.every(c=>c.count===1),name+' contributors');
  assert(details.provenanceStatus&&details.historyR27&&details.responsibility&&details.citeR27,name+' R27 status');
  assert.equal(errors.length,0,name+' page errors');
  results.files.push({name,...details,errors});
  if(name==='article.html') {
   const tocs=await page.locator('.article-print-toc a').evaluateAll(as=>as.map(a=>({href:a.getAttribute('href'),text:a.textContent})));
   assert.equal(tocs.length,23);
   for(const a of tocs) {
    await page.locator('.article-print-toc a').filter({hasText:a.text}).first().click();
    const state=await page.evaluate(href=>({hash:location.hash,targetExists:!!document.querySelector(href),top:document.querySelector(href)?.getBoundingClientRect().top}),a.href);
    assert.equal(state.hash,a.href);assert(state.targetExists&&state.top>=-1&&state.top<=900,a.text+' scroll');
    results.navigation.push({text:a.text,...state});
   }
   await page.locator('#review-provenance').scrollIntoViewIfNeeded();
   await page.screenshot({path:'/tmp/r27-exploratory/browser-provenance.png'});
   for(const href of ['https://english.lem.pl/works/essays/summa-technologiae','https://existentialtech.antikythera.org/']) {
    const matching=page.locator('.article-print-body a').filter({hasText:'[31]'});
    const idx=await matching.evaluateAll((as,href)=>as.findIndex(a=>a.href===href),href);
    let seen=null;const route=async r=>{seen=r.request().url();await r.abort();};
    await page.route(href,route);await matching.nth(idx).click({noWaitAfter:true});
    await page.waitForTimeout(200);results.externalClicks.push({label:'[31]',expected:href,observed:seen,pass:href===seen});
    assert.equal(seen,href);await page.unroute(href,route);await page.goto('file://'+path.join(dir,name));
   }
  }
  if(name.endsWith('copy-ready.html')) {
   await page.evaluate(()=>{const r=document.createRange();r.selectNodeContents(document.querySelector('.article-print-body'));const s=getSelection();s.removeAllRanges();s.addRange(r);});
   await page.keyboard.press('Control+c');
   await page.evaluate(()=>{const target=document.createElement('div');target.id='qa-paste-target';target.contentEditable='true';target.setAttribute('style','position:fixed;top:0;left:0;width:600px;height:500px;background:white;overflow:auto;z-index:99999');document.body.appendChild(target);target.focus();});
   await page.keyboard.press('Control+v');await page.waitForTimeout(150);
   const pasted=await page.locator('#qa-paste-target').evaluate(el=>({textLength:el.innerText.length,images:el.querySelectorAll('img').length,numeric:Array.from(el.querySelectorAll('a')).filter(a=>/\[\d+\]/.test(a.textContent)).map(a=>({text:a.textContent.match(/\[\d+\]/)[0],url:a.href})),contributors:['Maximiliano Armesto','Pasquale Langella','Olivier Leturcq'].every(n=>el.innerText.includes(n)),status:el.innerText.includes('These comments are recorded for editorial consideration.'),historyR27:el.innerText.includes("R27: Olivier's feedback recorded; substantive editorial proposals remain under review."),responsibility:el.innerText.includes('Vitalii Oborskyi retains editorial responsibility.'),imageData:Array.from(el.querySelectorAll('img')).every(i=>i.src.startsWith('data:image/'))}));
   assert.equal(pasted.images,4);assert.deepEqual(pasted.numeric,expected);assert(pasted.contributors&&pasted.status&&pasted.historyR27&&pasted.responsibility&&pasted.imageData);
   results.copy.push({name,...pasted});
  }
  await page.close();
 }
 await fs.writeFile('/tmp/r27-exploratory/browser.json',JSON.stringify(results,null,2)+'\n');
 console.log(JSON.stringify({browser:results.browser,files:results.files.map(({name,figures,numeric,...r})=>({name,figures:figures.length,numeric:numeric.length,...r})),navigationCount:results.navigation.length,copy:results.copy.map(({numeric,...r})=>({...r,numeric:numeric.length})),externalClicks:results.externalClicks},null,2));
} finally {await context.close();await browser.close();}
