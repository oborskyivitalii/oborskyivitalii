# R27 independent Code/Artifact review — artifact and guard delta

Reviewer: `/root/r27_code_review`, independent nonauthoring Code/Artifact role.
Recorded 23 October 2026. Execution: issue 5 / Draft PR79; editorial/publication: issue 2.
Baseline: `c60aaa2e71d1ed53763f41764c62faa89090f139` / tree `41c206ff8f3a19da51d2bd5bf37f06bbe29c592a`.
Candidate: prepared working tree; no exact-clean full-policy pass is inferred.
This is the actual follow-up execution to the initial source review, not reuse of its conclusion without reinspection.

## Conclusion

**PASS for the inspected source correction, native artifact identity and publication/provenance delta.**

The corrected storage guard now observes the actual injected storage references and the second realm's actual storage value, closing the White-box finding. All original Space behavior tests, simulated work and assertions remain unchanged. The revised profiling evidence has proper native named-case accounting and accurately preserves the earlier invalid-accounting observations as superseded diagnostics.

The public R27 ZIP exactly contains the native kit of 34 files, its unmodified manifests/resources and the correct R27 manuscript, launch and 21-page PDF. Every declared source and producer input hash matches the inspected repository. All eight platform renditions carry the new provenance accurately; like-format LinkedIn/Medium outputs are byte-identical. The 49 numeric citation texts and URLs are identical to the retained R26 native article.

Final visual/link review wording and the clarified current P1 recommendation must agree with their actual completed receipts. Current RI/catalog/metadata reconciliation and the full required policy on the final exact clean commit remain separate delivery gates. This source/artifact pass does not supply those results, author acceptance, hosted/device admission or publication approval.

## Reviewed identity

The 11-file source/deliverable manifest is `/tmp/r27-code-final-source-manifest.json`, aggregate SHA256 **cf4080e43560ea1623a4a33711ea52411ff90cfc69b1128278c1705780ea9c93**. It contains the eight substantive authoring/test files reviewed previously plus the three actual public deliverables. Metadata/review receipts can still be completed; no future uninspected material change is accepted by this manifest.

- Final `tests/space.test.cjs`: `4a7691344008723ad8d1971890e8a488d40b6ce2e286656a38690053e4a7c939`.
- Manuscript: `d52ae574eacc669a3d7a6658b3ba084de0f528c11321304d8057250185083835`, 50,045 bytes.
- Semantic edition: `21d29d8504a8a9fb44e863021b2a8144fb1fb2fc2f93be21dbe4cf64d6b3b724`.
- Native kit: `3deebdbf052a2ad3616ae6ba7ea70d35c4e4c09a2e75713379f0aedfb82e154e`.
- PDF: `2f5fde5749b6cc294f1026d293df5aa0c9cc645ea7d3cba0ca3c5e9194414ad6`, 1,412,004 bytes, 21 pages.
- Public ZIP: `1ba55facb646824c34018e644fc7329bcfd806f1c66b4217bd338b0461fd3069`, 6,517,105 bytes, 34 members.
- Separately authored launch: `4004f504dc9ade52d4d364bafce10645510f48c9cfe435688eba6c894d5a5003`.

## Actual independent actions and results

1. Read the final code diff, final edition/profile/launch, public package README/evidence, native manifest and print sidecar. Re-read the implementation diagnosis, proper native paired-comparison JSON and both raw TAP files. Read independent White-box mutation results directly, keeping their execution attributed to that QA role.
2. Executed the unchanged native `verifyKit(directory)` and `verifyPrintPair(article.pdf)` functions directly. Both succeeded; source SHA, working-tree-review status, producer and PDF identities agree. The verification result is retained in `/tmp/r27-code-native-verification.json`.
3. Opened the actual public ZIP with Python zipfile, checked CRCs, exact ordered member inventory, safe relative names and byte equality against every native directory file. All 34 members match; there are no added correspondence/private input files.
4. Recomputed all 34 retained native inventory hashes/sizes, all 11 input hashes, all 16 producer-input hashes and all three public delivery file hashes. Every comparison passes. The manuscript equals both native `article.md` and the public Markdown; the launch equals native `launch-post.md`; the public PDF equals native `article.pdf`.
5. Compared `.html`, `.md`, `.txt` and `-copy-ready.html` between LinkedIn and Medium: all four corresponding pairs are byte-identical. Each of the eight files contains exactly one Olivier contribution and its pending/editorial-consideration wording. The review Markdown and separate launch also preserve the intended contribution status.
6. Parsed the actual native R26 and R27 article HTML links. All 49 numeric link labels and destinations match in order, including both distinct contextual [31] URLs. This is direct rendered-artifact evidence, beyond the source preservation proof.
7. Parsed the actual PDF with PyMuPDF: 21 pages, R27 revision text, Olivier's name and pending-consideration text are present. The two known native outline-label duplications remain at the expected destinations: Part III / page 13 and Review provenance / page 21. This parsing is not claimed as an all-page visual review.

Machine observations are retained in `/tmp/r27-code-artifact-inspection.json` and `/tmp/r27-code-artifact-links.json`.

## Guard correction and test evidence assessment

The White-box reviewer correctly distinguished private fixture closure state from the storage object actually injected into the VM. The original new test could miss shared injected storage because `second.stored()` observed its independent closure even if the VM received another object's storage. The correction adds both an object-identity inequality and an actual `second.browserContext.localStorage.getItem()` assertion after the first realm writes. These test the intended invariant rather than accepting the implementation's own bookkeeping.

I inspected the exact diff and QA matrix on final source 4a769134. The matrix records the real candidate isolation case 1/1 PASS and four deliberate faults 1/1 FAIL: shared realm, injected host process, shared host intrinsics and shared actual storage. The faults are relevant to the revised fixture design. These are QA's actual executions, not tests claimed as executed by this reviewer.

The proper profiling pair now records the intended named route-flight test, 1/1 PASS with zero fail/skip/cancel/todo in both runs, using the same profiling flags and runtime bytes: 40.246738365 s original / 16.029075352 s ordinary global. A single sequential pair supports a concrete removable fixture cost; it does not demonstrate a universal speedup or establish every earlier timeout's whole cause. Initial sandbox file-wrapper outputs are correctly retained but excluded from accepted case evidence.

The 70/70 complete Space observation, 101.138542777 s, belongs to source b2ba67b before the two added storage assertions. The final guard 4a769134 has its separately executed candidate/mutation evidence. The implementation report accurately distinguishes them. Final full 265-case READER acceptance still needs the unchanged owning policy on the delivered clean source; I have not rerun it in this Code role.

## Editorial proposal clarification

P1's original historical wording ends with “production mandate.” A bounded canary can itself run in production, so that phrase can accidentally imply a pre-production/production boundary that the article's argument does not require. The current recommendation should end with **“A pilot can earn another bounded stage without yet earning a wider rollout.”** This preserves the intended difference between bounded learning and expanded exposure.

This is a clarification to the proposed paragraph in the decision analysis, not an authorized insertion into the article. Preserve the independent original proposal as historical source and make the current recommended wording explicit. If the author later adopts P1/P2 after R27 is frozen, create the next substantive revision; do not rewrite the frozen R27 edition or claim its provenance incorporated those ideas retroactively.

The actual R27 manuscript remains provenance-only relative to R26. It accurately records Olivier's contribution without claiming a known exact reviewed edition/date or endorsement. Existing Maximiliano/Pasquale attribution and author's editorial responsibility remain. No confidential earlier correspondence or unapproved upstream doctrine change entered the kit.

## Remaining metadata and visual disposition

At this review's initial package read, artifact-evidence.json still labels independent visual/link review pending, while README anticipates that review being recorded. Root has identified this as pending completion text. Before delivery, replace both with the actual completed source-bound visual/link result and disclose the two observed native outline-label duplications. Do not infer an all-page visual pass from this metadata parser or from PDF generation.

The same explicit review producer as R26 is used: Chromium 153.0.8010.0 / Playwright 1.63.0, `managedBrowser:false`, `reviewOnly:true`. The prior managed download failure was not rerun or represented as current managed admission. Article status remains review, rights review-pending, canonical null and accepted commit/blob null.

No production code, shared print component, generated browser source or publisher implementation changed. Prior source, semantic and 53-file historical preservation findings remain valid under the inspected delta. Current catalog/RI/CI, final frozen source readback and exact-clean full-policy evidence must still be reconciled before the delivery claims are finalized. Metadata-only receipt addition can be checked against these exact source/artifact hashes; a substantive source/proposal/oracle change requires renewed review.

The reviewer did not author or modify repository source, tests, article, policy or delivered artifacts. Only read-only validation and this separate review evidence were produced.
