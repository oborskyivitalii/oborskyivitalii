# R27 requirements and acceptance preflight — 23 October 2026

Independent role: Requirements & Acceptance Reviewer, `/root/r27_requirements`.
Execution owner: issue 5 / existing Draft PR79. Editorial/publication owner: issue 2.
Inspected baseline: `c60aaa2e71d1ed53763f41764c62faa89090f139`, tree
`41c206ff8f3a19da51d2bd5bf37f06bbe29c592a`; working tree was clean at inspection.
Live connector readback independently confirms the same PR head, open Draft state,
`merged:false`, `mergeable:false`, and both issues open. The merge conflict is a
separate existing condition, not evidence that this increment has been delivered.

## Original request, interpretation and limits

The author asks to fix the previously reported problem, add a new provenance
record, and analyze what is worth changing or retaining. The previous handoff
identifies READER exceeding its existing 180-second process deadline as the
remaining failed automated check; all other named checks passed. The author did
not request a wholesale rewrite, release, merge, or production activation.

The parent clarified the bounded implementation: repair the READER fault; add
the requested provenance/history/edition update as R27 and regenerate equivalent
native artifacts; preserve the article argument; put detailed editorial analysis
and proposed wording in the review artifact for author choice. This is consistent
with the request and the repository's research-intake-before-substantive-change
rule. The user has already authorized these reversible repository/PR operations;
no extra permission request is necessary to complete them.

The supplied file is a private conversation export. Its latest substantive
feedback recognizes the continuing cost and capacity of human review, asks to
retain the innovation-versus-sustainability tension, finds the diagrams useful,
and proposes examining the context humans need to safely understand changes when
choosing abstraction or duplication. This is editorial/conceptual feedback, not
new empirical evidence. The earlier working note explicitly restricts sharing.
Neither that note nor raw correspondence belongs in the public repository.

The export shows R18 and R23 filenames sent and a final reply after the R23
message. It does not prove the exact PDF bytes the reviewer opened and does not
show R26 review or acceptance. Relative TODAY/TUESDAY labels and June dates do
not establish absolute message dates/year. Use 23 October 2026 as the date this
input was recorded, not an invented correspondence timestamp. A neutral
contribution summary can name Olivier Leturcq as requested without claiming
coauthorship, formal validation, endorsement, or acceptance of the new edition.

## Proposed stable bounded subcriteria

These are subconditions of existing issue ACs, not replacements or renumbering
of the issue's original acceptance criteria. Record them in the same versioned
review artifact and the owning issue's dated scope anchor before implementation.

| ID | Observable obligation | Existing mapping | Oracle and remaining limit |
| --- | --- | --- | --- |
| R27.1 READER correction | Diagnose the slow path and correct its owner while retaining the complete ten-file READER selection, original 180-second process deadline, nonzero test accounting and zero failures/skips/cancellations/todo. Full exact-clean issue5 policy passes all 12 named checks on the delivered commit. | #5 AC04, AC08, AC11–AC13; READER/BASIC/STYLE-GUARD | Same-source old/new evidence and independent inspection establish mechanism; focused passes alone do not replace the final full policy. Do not raise the deadline, reduce cases, alter expected runtime behavior, suppress failures or claim causality from an uncontrolled timing comparison. |
| R27.2 Honest provenance | Add a concise contribution-focused Olivier entry and accurate R27 history/citation metadata. Earlier Maximiliano/Pasquale contributions and author's editorial responsibility remain. | #2 AC01–AC02; #5 AC06–AC07 | Direct comparison with the supplied final feedback; no confidential note, transcript, unproven exact review edition/date, quotation, validation or endorsement claim. |
| R27.3 Bounded editorial analysis | Record the input, its scope/limits, all affected article passages, what is already covered, proposed include/narrow/defer/no-change decisions and their reasons. Separate hypotheses/recommendations from evidence. | #2 AC01–AC02; #5 AC06 | Review artifact contains a decision matrix and candidate wording; substantive argument stays unchanged pending author choice. No changes to canonical UA/Subprime meaning. |
| R27.4 Edition and artifact fidelity | Create a new immutable review edition and regenerate through the native publisher/print pipeline. Equivalent outputs include the new contribution; prior editions and R26 delivered files remain byte-identical. | #2 AC03; #5 AC02–AC03, AC07, AC09–AC10, AC18 | Source/semantic/producer identity, complete kit verification, actual PDF visual inspection and export comparison; no fabricated accepted/canonical/publication state. |
| R27.5 Preservation and safety of scope | Preserve three article parts, 12 standalone prompts, 36 references and qualifications, two tables, four figures, ordered citation destinations including both contextual [31] targets, separate authored launch, and existing review/rights boundaries. Runtime source and generated browser bytes stay unchanged if the fix is test-harness-only. | #2 AC01–AC03; #5 AC02–AC03, AC06–AC10 | Normalized source diff and actual artifacts; attribution-only changes must not accidentally amend the argument or qualification notes. Review producer limitations remain explicit. |
| R27.6 Reviewable delivery | Preserve issue5/PR79 route and one canonical Refs #5; record all four independently completed roles, current RI/CI/catalog identity, exact clean policy and remote readback. Reconcile actual AC checkboxes from current evidence. | #5 AC11–AC12 | CS01/CS04–CS08/CS10 as applicable plus bounded guard, behavioral and independent review; open human/hosted/platform/rights gates remain open. A source correction alone does not resolve merge conflict or publication readiness. |

## READER mechanism acceptance constraints

`tests/test_issue5_acceptance.py::run_node_contracts` directly runs raw
`node --test --test-reporter=tap` and enforces 180 seconds. Its READER method names
the ten complete modules including `tests/space.test.cjs` and checks complete TAP
accounting. `space.test.cjs` caches one compiled `vm.Script`, then each `visit`
uses `script.runInNewContext({ document, window, localStorage })` with fresh
browser/storage fixtures. All 69 Space cases and the baseline 264 READER cases
are relevant evidence, not options to silently omit.

The canonical check-profile guide already describes bounded file-worker scheduling
and expensive-suite-first ordering, while this acceptance wrapper bypasses that
runner. This is an observed orchestration inconsistency worth inspecting; it does
not by itself prove the measured timeout's cause.

The implementation agent proposes evaluating an ordinary fresh VM realm created
with `vm.createContext(vm.constants.DONT_CONTEXTIFY)` and then the same fixtures
and `runInContext`. That mechanism is not accepted by this preflight. A sound
candidate must demonstrate fresh realms per visit, no state/Node-global leakage,
identical injected fixtures, preserved runtime behavior and error detection, and
full required tests under the original limit. Host `eval`, shared globals, stale
fixture reuse, fewer simulated operations or disabled assertions would fail the
intent even if timing improves. Independent White-box and Code reviewers must
inspect the semantic distinction and source compatibility.

## Editorial decision boundaries grounded in current R26

1. **Already present; retain:** human review as a funded operating dependency,
   full operating cost, simpler alternatives, bounded pilots and insufficient
   evidence blocking expansion; these appear in “Design for real review
   capacity” and the final decision table. Do not add repetitive general warnings.
2. **Worth a focused proposed addition:** distinguish permission to run a bounded
   learning experiment from permission to scale production exposure. Uncertainty
   can be budgeted and staged without promising an exact day-zero lifetime bill
   or making weak controls acceptable. Current pilot and canary language provides
   a natural anchor; preserve the unchanged strict prohibited-action limits.
3. **Worth a qualified proposed addition:** architecture should make critical
   behavior understandable and safely changeable. Compare context spread,
   dependency tracing and change propagation with reuse benefits; local duplication
   can be easier to inspect in some circumstances, while shared policy invariants
   may require one owner. Treat this as a design trade-off/hypothesis, not a finding
   that AI-generated code should generally duplicate logic or reject abstraction.
4. **Retain and narrow interpretation:** the GitClear duplication measure is
   already labelled a warning signal, not proof of cognitive burden or causation.
   The proposal can question proxy interpretation without deleting a qualified
   source or inventing a contradictory empirical conclusion.
5. **Retain:** diagrams received useful feedback, but this is one reader's
   reaction, not user testing or proof of all figure semantics. Current figure
   captions and rights qualifications stay.
6. **Defer:** a new doctrine, universal factorization rule, quantitative context
   budget, or claim that architectural impossibility can always be identified at
   day zero needs its own evidence and owning research decision. Do not expand
   this personal article intake into an upstream framework rewrite.

## Checkbox and completion disposition

Live #5 AC13 is correctly open because its mapped READER gate failed on c60aaa2.
Only after the complete current-source policy verifies READER and WRITING-CATALOG
can AC13 return to checked, with dated evidence and the prior failure preserved.
That is a current criterion reconciliation, not an erasure of the failed R26 run.
All other issue criteria must be assessed against their own mappings and human
gates, not indiscriminately ticked from 12/12 automated checks. Historical #5 AC23
and #2 AC07–AC08 describe independently retained increments; retain their scope.
Issue2 AC01–AC06 remain open absent their editorial/rights/publication decisions.

## Materials and execution limits

Read directly: AGENTS, CONTRIBUTING, README, MEMORY (dated only), relevant site
source contract sections, ACCEPTANCE, issue5 policy, CODE-STYLE, ARTICLE-WORKFLOW,
SITE-CONTENT-REVIEW, relevant SITE-SOURCE-AUDIT/REPOSITORIES/RI/check-profile owners,
review template and R26 review subcriteria, canonical manuscript's affected
argument and provenance/history, blueprint, launch, profile/publication/edition
identities, acceptance wrapper and Space fixture owner. Inspected original
attachment directly. Live connector reads: PR79, issue5, issue2. No test,
production, issue or PR mutation performed by this reviewer. This is requirements
preflight only; final candidate and exact-source completion review remain required.

## Conclusion

**PASS for the bounded requirements plan with the explicit conditions above.**
The requested fix/provenance/analysis can proceed autonomously in existing PR79.
No substantive article-argument change, test-budget weakening, private transcript
publication, edition acceptance, merge or production approval is inferred.
Final R27.1–R27.6 remain pending candidate execution and independent review.
