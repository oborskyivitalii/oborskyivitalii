# R27 independent Code/Artifact review — initial source checkpoint

Reviewer: `/root/r27_code_review`; independent nonauthoring Code/Artifact role.
Date recorded: 23 October 2026. Existing execution: issue 5 / Draft PR79; article owner: issue 2.
Baseline: `c60aaa2e71d1ed53763f41764c62faa89090f139`, tree `41c206ff8f3a19da51d2bd5bf37f06bbe29c592a`.
Candidate: prepared working tree, not a clean committed-source acceptance result.

## Conclusion

**PASS for the inspected corrected source design and bounded editorial delta; artifact and final full-policy review remain pending.**

The VM correction changes only how each simulated page receives its fresh V8 realm. It keeps the cached compiled script, the same document/window/storage fixtures, every original Space test and all simulated operations/assertions. The added test directly exercises realm/intrinsic separation and independent storage. The mechanism is consistent with Node's documented ordinary-global context API and the repository's Node24 toolchain. It does not change production runtime behavior, test selection, the process deadline or the expected outcomes.

The manuscript changes are restricted to requested provenance, revision/history and citation metadata. A separately authored launch acknowledgment accurately describes feedback as under consideration. The substantive argument and the full source/qualification section are byte-identical to R26. New source/semantic/launch pins match, prior review editions and retained assets are unchanged, and publication/rights state remains pending.

Two findings were identified and corrected during this source review. Neither the initial diagnostic process exit nor this source review can substitute for correctly accounted execution of the complete required suites. No final delivery, PDF quality, full-policy success or readiness claim is made at this checkpoint.

## Original request and inspected material

The author asks to fix the found problem, add the new provenance record, and analyze what is worth changing or retaining. I independently read the actual diff and sources, root AGENTS, relevant CONTRIBUTING/quality-agent and research-intake rules, CODE-STYLE, article workflow/edition contract, ownership and acceptance rules, the private supplied input, versioned R27 analysis and preflight, current edition/profile/launch and the issue5 dated intake fetched through GitHub.

Live intake inspected: https://github.com/oborskyivitalii/oborskyivitalii/issues/5#issuecomment-6372120716 . The independently fetched body now explicitly corrects provisional profiler accounting. Input correspondence was read locally for attribution/limits; no raw correspondence was copied into this report or repository.

The source manifest `/tmp/r27-code-source-manifest.json` records eight substantive files and exact hashes. Its aggregate SHA256 is **6c981d876fc311dde66d8e2740d58fd560447853c9584586d510fddfed85aa7d**. The review artifact is still being assembled and is deliberately not represented as a frozen complete candidate.

## Findings and dispositions

| ID | Severity / impact | Source-grounded finding | Disposition |
| --- | --- | --- | --- |
| CR27-01 | Blocking test correctness; R27.1/R27.4 | The first prepared `tests/article-media.test.cjs` changed the expected edition to R27 while retaining the exact R26 source hash. The source/edition pair was inconsistent and would fail the real preview assertion. | Corrected and independently re-read. The test now pins R27 manuscript `d52ae574eacc669a3d7a6658b3ba084de0f528c11321304d8057250185083835` and R27 edition. Its only baseline changes are test title, exact source hash and edition ID; all size/resource/rights and negative assertions remain. |
| CR27-02 | Evidence accuracy; R27.1/R27.6 | Initial49/15-second profiled processes exposed only a file-wrapper TAP result. Exit0 did not establish selected-case accounting, so the initial “both passing” assertion was too strong. | Live intake now labels those observations provisional, retains original logs, and requires correctly accounted comparison/full suites. Final source/report must use the verified results when available. No speed ratio accepted from unverified accounting. |
| CR27-03 | Low; scoped formatting | JSON.stringify temporarily expanded unaffected arrays in profile.json. | Corrected. Profile diff now changes only ID and authored launch hash; article-media formatting was restored to its original file style with the exact three intended replacements. |

## VM design review

`tests/space.test.cjs` still compiles one `vm.Script` from the admitted runtime bytes. Each `visit()` now calls `vm.createContext(vm.constants.DONT_CONTEXTIFY)`, assigns the same three newly constructed browser/storage fixtures, and calls `script.runInContext(browserContext)`. It neither evaluates in the Node host realm nor reuses a context between visits. It does not introduce an importer, host process object, alternate code source, asynchronous runner, changed RAF schedule or removed simulation work.

The new test boots two actual visits with motion off and verifies distinct realm objects, separate Math/Array/Object identities from each other and the host, exact window/document references, absence of directly exposed process/require/module/Buffer, no global/Math/Array-prototype writes leaking into the other page or host, and independent storage mutation. These observations protect test isolation; `node:vm` is not claimed as a security boundary for hostile code. The test manipulates only objects in its own disposable realm. The production source still receives the same host-built mocks as before.

I mechanically normalized only the declared VM block, exposed test-context field and added guard out of the candidate and recovered the entire baseline Space test file byte-for-byte. All original69 case bodies, fixture methods, frame counts, faults and assertions therefore remain exact. There are70 top-level Space tests after the additional isolation case. The ten-file acceptance selection and original180-second subprocess deadline remain unchanged in their owner.

The canonical workflows pin Node24.19.0; the publisher package requires Node>=24.0.0. The official Node24 VM documentation describes DONT_CONTEXTIFY as a new context with an ordinary global object and access to that context's own builtins: https://r2.nodejs.org/docs/latest-v24.x/api/vm.html#vmconstantsdont_contextify . I read this documentation directly. Its semantics support this narrow test-fixture design; they do not establish a numerical performance benefit or browser/runtime optimization.

No remaining source-design blocker was found in this scope. Proper execution and bounded fault-injection results belong to White-box QA and final full-policy evidence; source inspection alone does not supply them.

## Editorial, edition and privacy review

The final supplied feedback supports the neutral Olivier contribution summary: innovation versus sustainable operating cost, and architectural effects on the context needed for human review/maintenance. The actual manuscript and launch do not quote the confidential earlier note, reproduce its named principles, claim Olivier read R26, assign an invented correspondence date, infer coauthorship/endorsement or say the substantive recommendations were incorporated.

The analysis identifies two local optional proposals and preserves uncertainty about their empirical status. It distinguishes them from the already explicit human-capacity/cost treatment and from broad claims about duplication or AI-specific architecture. This meets the user's request for analysis without silently adopting a new doctrine or rewriting the article. If P1/P2 are later accepted after R27 freezes, their incorporation needs the next edition rather than a rewrite of this historical record; the current blueprint already routes substantive changes to a later author decision.

Direct source checks establish:

- Entire article segment from the first cover figure through Sources & references, including all qualification notes, is byte-exact baseline R26.
- The new manuscript SHA256 is `d52ae574eacc669a3d7a6658b3ba084de0f528c11321304d8057250185083835`.
- Independent canonical-JSON recomputation of the semantic identity yields `21d29d8504a8a9fb44e863021b2a8144fb1fb2fc2f93be21dbe4cf64d6b3b724`, matching the new edition record.
- The launch source hash matches profile `4004f504dc9ade52d4d364bafce10645510f48c9cfe435688eba6c894d5a5003`.
- All53 inspected baseline edition/R26-package/article-media files are byte-identical. Existing old editions were not changed.
- `site/engine`, `docs`, `tools/publishing` and `site/assets` have no diff at this checkpoint.
- Status remains review, rights review-pending, canonical null and accepted source commit/blob null.

These checks were performed directly with read-only Git/Python source comparison; detailed observations are in `/tmp/r27-code-source-inspection.json`. They do not establish final export counts, PDF layout or hosted delivery.

## Style, scope and remaining review

CS01/04/05: changes are in canonical article/edition/test owners; there is no duplicate runtime/editorial source or broad format migration. CS06/07: fresh fixture lifecycle and original simulation workload remain, with measured overhead still requiring verified receipts. CS08/10: the new guard protects a meaningful isolation invariant, exact source assertions are retained, and the change stays under issue5/PR79 with separate article acceptance.

The remaining final Code/Artifact delta must inspect the generated native inventory and ZIP/hash closure, PDF metadata and peer visual observations, the final reviewed source manifest, current catalog/RI/CI refresh, and accurate full-policy/evidence accounting. The full required policy must pass on the exact clean delivered commit before R27.1 is accepted. Independent roles, rights/editorial/hosted/platform/device acceptance and any merge/release decision remain separate.

This reviewer authored no repository source, tests, article, policy or artifact. No heavy suite was run during the implementer's reserved CPU window.
