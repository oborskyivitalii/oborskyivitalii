import fs from 'node:fs/promises';
import chromium from '/tmp/r24-chromium/node_modules/@sparticuz/chromium/build/index.js';
import kit from '/workspace/scratch/c91ea22e72f1/author-site/tools/publishing/kit.cjs';
import articleModule from '/workspace/scratch/c91ea22e72f1/author-site/tools/publishing/article.cjs';
import { createReviewProducer, verifyPrintPair } from '/workspace/scratch/c91ea22e72f1/author-site/tools/publishing/print.mjs';

const root = '/workspace/scratch/c91ea22e72f1/author-site';
const printProducer = createReviewProducer({
  executablePath: '/tmp/chromium',
  packagePath: '/tmp/r24-chromium/node_modules/@sparticuz/chromium/package.json',
  archivePath: '/tmp/r24-chromium/sparticuz-chromium-153.0.0.tgz',
  args: chromium.args,
});
const article = articleModule.loadArticle(root, 'pmday-ai-both-sides');
const result = await kit.renderKit(root, 'pmday-ai-both-sides', { pdf: true, printProducer });
const manifest = await kit.verifyKit(result.directory);
const pdf = await verifyPrintPair(result.directory + '/article.pdf');
const counts = {};
for (const platform of ['linkedin', 'medium']) {
  counts[platform] = Array.from(await fs.readFile(result.directory + '/' + platform + '.txt', 'utf8')).length;
}
const summary = {
  directory: result.directory,
  artifactId: manifest.artifactId,
  source: article.source,
  edition: article.edition,
  genericTextCharacters: Array.from(article.text).length,
  emittedTextCharacters: counts,
  pdf: pdf.pdf,
  browser: pdf.render.browser,
  toolchain: pdf.render.toolchain,
  pipeline: 'Unmodified loadArticle/compile -> renderKit -> printArticle -> verifyKit/verifyPrintPair',
};
await fs.writeFile('/tmp/r27-native-result.json', JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
