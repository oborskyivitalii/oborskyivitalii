/* Shared native reading-entry controller. */
window.SiteScrollEntry=(function () {
  const targets = [
    '.hero-copy',
    '.hero-copy > *',
    '.portrait-composition',
    '.shift-intro > p',
    '.research-note > .note-row',
    '.archive-intro > .eyebrow',
    '.archive-intro > h1',
    '.archive-intro > .hero-description',
    '.section-heading',
    '.research-card',
    '.topic-card',
    '.help-grid article',
    '.ack-leads article',
    '.ack-compact article',
    '.ack-grid article',
    '.discussion-row',
    '.about-grid > div',
    '.about-grid > h2',
    '.about-section > .eyebrow',
    '.context-heading',
    '.archive-link',
    '.contact-grid > div',
    '.publication',
    '.credits-page > p',
    '.credits-page > h1',
    '.credits-page > h2',
    '.archive-heading',
    '.archive-count',
    '.empty-state',
    '.year-landing',
    '.archive-landings > .topic-landing',
    '.writing-topic',
    '.year-heading',
    '.section-note',
    '.next-route > p',
    '.next-route > a',
    '.article-intro > *',
    '.article-toc',
    '.reader-introduction > *',
    '.reader-chapter > *',
    '.article-body > .reader-endnote > *',
    '.reader-closing > *',
    '.article-sources',
    '.article-related',
    '.article-list',
  ].join(',');
  const routeTargets = `${targets},.archive-filters,.section-nav,.topic-nav`;
  const separatorTargets = [
    '.shift-intro',
    '.research-note',
    '.section',
    '.section-nav',
    '.research-card',
    '.help-grid article',
    '.ack-leads article',
    '.ack-compact article',
    '.ack-grid article',
    '.topic-card',
    '.publication',
    '.next-route',
    '.discussion-row',
    '.empty-state',
    '.reader-closing',
    '.reader-chapter',
    '.article-toc',
    '.reader-appendices',
  ].join(',');
  const records = new Map();
  const routeUnits = new Map();
  const knownRecords = new Map();
  const separators = new Map();
  const active = new Map();
  const pendingReading = new Map();
  const listeners = [];
  let root = null;
  let footer = null;
  let observer = null;
  let generation = 0;
  let suspended = true;
  let failed = false;
  let reconcileTask = null;
  let previousY = 0;
  let direction = 0;
  let jumpUntil = 0;
  let booted = false;
  let routeGeneration = 0;
  let routePhase = null;
  let routePrepared = null;
  let routePaper = null;
  let holdTask = null;
  let nextUnitId = 0;
  let readingDistance = 0;
  let readingDuration = 700;
  let readingStagger = 80;
  let readingBorders = [];
  const routeActive = new Set();
  const clock = () => window.performance?.now() ?? Date.now();

  function animationMark() {
    const timeline = document.timeline?.currentTime;
    return { started: clock(), timelineStarted: Number.isFinite(timeline) ? timeline : null };
  }
  function animationElapsed(mark) {
    const timeline = document.timeline?.currentTime;
    // CSS events and their start marks share the frame-sampled document clock.
    // Retain a paired wall-clock fallback when either timeline mark is absent.
    return Number.isFinite(mark.timelineStarted) && Number.isFinite(timeline)
      ? timeline - mark.timelineStarted
      : clock() - mark.started;
  }
  function listen(target, name, handler, options) {
    target?.addEventListener?.(name, handler, options);
    listeners.push(() => target?.removeEventListener?.(name, handler, options));
  }
  function clearState(element) {
    clearSeparators('reading', element);
    window.clearTimeout(active.get(element)?.timer);
    active.delete(element);
    pendingReading.delete(element);
    element.removeAttribute('data-scroll-entry');
    element.removeAttribute('data-scroll-delay');
  }
  function finish(element) {
    const record = records.get(element);
    if (!record) return;
    record.done = true;
    clearState(element);
    // Keep the native shell observed: a later complete exit below the viewport
    // arms its next ordinary downward entry without measuring every scroll.
  }
  function disconnect() {
    generation++;
    observer?.disconnect();
    observer = null;
    window.clearTimeout(reconcileTask);
    reconcileTask = null;
  }
  function settle(target = null) {
    cancelRoute();
    for (const element of records.keys()) {
      if (!target || element === target || element.contains(target) || target.contains(element))
        finish(element);
    }
  }
  function suspend() {
    suspended = true;
    disconnect();
    for (const element of records.keys()) {
      if (active.has(element)) finish(element);
      else clearState(element);
    }
  }
  function fail() {
    failed = true;
    suspend();
    settle();
  }
  function guarded(action) {
    return (...args) => {
      try {
        return action(...args);
      } catch {
        fail();
      }
    };
  }
  function guardedPhase(action) {
    return (...args) => {
      try {
        return action(...args);
      } catch {
        fail();
        return Promise.resolve({ completed: false, cancelled: true, completedBy: 'fallback' });
      }
    };
  }
  function enabled() {
    return window.SiteNavigation?.contentFlight?.() !== false;
  }
  function allowed() {
    return (
      !failed &&
      enabled() &&
      !document.hidden &&
      window.SiteScene?.motionState?.().enabled === true &&
      window.IntersectionObserver &&
      window.CSS?.supports?.('translate', '0 1px') &&
      window.CSS?.supports?.('animation-name', 'scroll-entry-rise')
    );
  }
  function routeAllowed() {
    return allowed() && window.CSS?.supports?.('overflow', 'clip');
  }
  function refreshInventory() {
    // Sustained reading stays stationary; document-to-document waves retain their units.
    const candidates = root.matches('.article-reader') ? [] : [...root.querySelectorAll(targets)];
    const units = [...root.querySelectorAll(routeTargets)];
    if (footer) units.push(...footer.querySelectorAll(':scope > p,:scope > a'));
    // A display:contents group has no movable paper or native box. Its visible
    // children own the animation instead; ordinary groups still prune them.
    const boxless = new Set(
      [...new Set([...candidates, ...units])].filter(
        (element) => window.getComputedStyle(element).display === 'contents'
      )
    );
    const shells = (elements) =>
      elements.filter(
        (element) =>
          !boxless.has(element) &&
          !elements.some(
            (other) => other !== element && !boxless.has(other) && other.contains(element)
          )
      );
    const nextRecords = shells(candidates);
    const nextUnits = shells(units);
    const previous = [...records];
    const recordFor = (element) => {
      let record = knownRecords.get(element);
      if (!record) {
        record = { done: false, ink: null, id: String(++nextUnitId) };
        knownRecords.set(element, record);
      }
      // A responsive group first settles visible content read through its
      // parent or children. Below-fold groups keep their repeatable entry.
      if (
        previous.some(
          ([other, state]) =>
            state.done && (other === element || other.contains(element) || element.contains(other))
        )
      )
        record.done = true;
      return record;
    };
    for (const element of records.keys()) {
      if (nextRecords.includes(element)) continue;
      if (active.has(element)) finish(element);
      else clearState(element);
      observer?.unobserve(element);
    }
    for (const element of routeUnits.keys()) {
      if (nextUnits.includes(element)) continue;
      clearRouteUnit(element);
      routeActive.delete(element);
    }
    records.clear();
    routeUnits.clear();
    for (const element of nextRecords) records.set(element, recordFor(element));
    for (const element of nextUnits) routeUnits.set(element, recordFor(element));
    readingBorders = readingBorders.filter((model) => records.has(model.owner));
  }
  function wrapInk(element, record) {
    // Inline text needs one movable layer; publication/grid children stay intact.
    if (!element.matches('p,h1,h2,h3,h4,h5,h6,a')) return;
    const ink = document.createElement('span');
    ink.setAttribute('data-scroll-ink', '');
    ink.append(...element.childNodes);
    element.append(ink);
    record.ink = ink;
  }
  function clearSeparators(mode, owner = null) {
    const released = new Set();
    for (const [source, entry] of separators) {
      if (entry.mode !== mode) continue;
      const removed = entry.layers.filter((layer) => !owner || layer.owner === owner);
      for (const layer of removed) {
        layer.node.remove();
        released.add(layer.owner);
      }
      entry.layers = entry.layers.filter((layer) => owner && layer.owner !== owner);
      for (const side of ['top', 'right', 'bottom', 'left']) {
        if (!entry.layers.some((layer) => layer.side === side))
          source.removeAttribute(`data-entry-border-${side}-owner`);
      }
      if (!entry.layers.length) {
        source.removeAttribute('data-entry-border-source');
        source.removeAttribute('data-entry-border-owner');
        separators.delete(source);
      }
    }
    for (const element of released) {
      if (
        [...separators.values()].some((entry) =>
          entry.layers.some((layer) => layer.owner === element)
        )
      )
        continue;
      element.removeAttribute('data-entry-separator-owner');
      element.removeAttribute('data-entry-border-owner');
      if (element.hasAttribute('data-entry-separator-shell')) {
        element.remove();
        routeUnits.delete(element);
      }
    }
  }
  function separatorSources(units, isolated) {
    const sources = new Set(isolated ? root.querySelectorAll(separatorTargets) : []);
    if (isolated && footer) sources.add(footer);
    for (const { element } of units) {
      let source = element;
      while (source && source !== root?.parentElement && source !== footer?.parentElement) {
        sources.add(source);
        if (source === root || source === footer) break;
        source = source.parentElement;
      }
    }
    return sources;
  }
  function separatorOwner(source, rect, side, width, descendants, isolated) {
    const coordinate = side === 'bottom' ? rect.bottom - width : rect.top;
    const owned = descendants.find(({ element }) => element === source);
    const eligible = owned ? [owned] : descendants.filter((unit) => unit.visible);
    if (isolated && !owned && (coordinate < -32 || coordinate > window.innerHeight + 32))
      return null;
    let owner = [...eligible].sort(
      (a, b) => Math.abs(a.rect.top - coordinate) - Math.abs(b.rect.top - coordinate)
    )[0];
    if (!owner && isolated && coordinate >= 0 && coordinate < window.innerHeight) {
      owner = { element: null, record: null, native: rect, isolated: true };
    }
    // A restored/initial-fold divider already visible above unseen ink stays
    // native. Its below-fold child retains its independent reading entry.
    if (
      owner &&
      !isolated &&
      !owned &&
      coordinate < window.innerHeight &&
      owner.native.top >= window.innerHeight
    )
      return null;
    return owner;
  }
  function separatorModel(source, rect, side, width, paint, color, owner) {
    const horizontal = side === 'top' || side === 'bottom';
    const ownerRect = owner.native;
    const ownerStyle = window.getComputedStyle(owner.element || source);
    const insetLeft = Number.parseFloat(ownerStyle.getPropertyValue('border-left-width')) || 0;
    const insetTop = Number.parseFloat(ownerStyle.getPropertyValue('border-top-width')) || 0;
    const left = side === 'right' ? rect.right - width : rect.left;
    const top = side === 'bottom' ? rect.bottom - width : rect.top;
    const model = {
      source,
      owner: owner.element,
      record: owner.record,
      side,
      width,
      paint,
      color,
      length: horizontal ? rect.width : rect.height,
      left: left - ownerRect.left - insetLeft,
      top: top - ownerRect.top - insetTop,
      isolated: owner.isolated === true,
      native: {
        top,
        bottom: horizontal ? top + width : rect.bottom,
        left,
        right: horizontal ? rect.right : left + width,
        width: horizontal ? rect.width : width,
        height: horizontal ? width : rect.height,
      },
    };
    if (![model.length, model.left, model.top].every(Number.isFinite) || model.length <= 0)
      return null;
    if (owner.rect) {
      owner.rect.top = Math.min(owner.rect.top, top);
      owner.rect.bottom = Math.max(owner.rect.bottom, model.native.bottom);
    }
    return model;
  }
  function measureSeparators(units, isolated = false) {
    const sources = separatorSources(units, isolated);
    const models = [];
    for (const source of sources) {
      if (!source.getBoundingClientRect || !source.getClientRects?.().length) continue;
      const style = window.getComputedStyle(source);
      const rect = source.getBoundingClientRect();
      const descendants = units.filter(
        ({ element }) => element === source || source.contains(element)
      );
      for (const side of ['top', 'right', 'bottom', 'left']) {
        const width = Number.parseFloat(style.getPropertyValue(`border-${side}-width`));
        const paint = style.getPropertyValue(`border-${side}-style`);
        const color = style.getPropertyValue(`border-${side}-color`);
        if (!Number.isFinite(width) || width <= 0 || ['none', 'hidden'].includes(paint)) continue;
        const owner = separatorOwner(source, rect, side, width, descendants, isolated);
        if (!owner) continue;
        const model = separatorModel(source, rect, side, width, paint, color, owner);
        if (model) models.push(model);
      }
    }
    return models;
  }
  function materializeSeparators(models, measured) {
    for (const model of models) {
      if (!model.isolated) continue;
      const shell = document.createElement('span');
      shell.setAttribute('data-entry-separator-shell', '');
      shell.setAttribute('aria-hidden', 'true');
      for (const name of ['left', 'top'])
        shell.style.setProperty(`--entry-separator-shell-${name}`, `${model[name]}px`);
      for (const name of ['width', 'height'])
        shell.style.setProperty(`--entry-separator-shell-${name}`, `${model.native[name]}px`);
      model.source.append(shell);
      model.owner = shell;
      model.record = { done: false, ink: null, id: String(++nextUnitId), isolated: true };
      model.left = 0;
      model.top = 0;
      routeUnits.set(shell, model.record);
      measured.push({
        element: shell,
        record: model.record,
        native: model.native,
        rect: { ...model.native },
        visible: true,
      });
    }
  }
  function attachSeparators(models, mode, owner = null) {
    for (const model of models) {
      if (owner && model.owner !== owner) continue;
      let entry = separators.get(model.source);
      if (!entry) {
        entry = { mode, layers: [] };
        separators.set(model.source, entry);
      }
      const node = document.createElement('span');
      node.setAttribute('data-entry-separator', model.side);
      node.setAttribute(
        'data-entry-separator-source',
        model.source === model.owner ? 'unit' : 'ancestor'
      );
      node.setAttribute('data-entry-border-owner', model.record.id);
      node.setAttribute('aria-hidden', 'true');
      for (const name of ['width', 'length', 'left', 'top'])
        node.style.setProperty(`--entry-separator-${name}`, `${model[name]}px`);
      node.style.setProperty('--entry-separator-style', model.paint);
      node.style.setProperty('--entry-separator-color', model.color);
      model.owner.setAttribute('data-entry-separator-owner', '');
      model.owner.setAttribute('data-entry-border-owner', model.record.id);
      model.source.setAttribute('data-entry-border-source', mode);
      model.source.setAttribute('data-entry-border-owner', model.record.id);
      model.source.setAttribute(`data-entry-border-${model.side}-owner`, model.record.id);
      model.owner.append(node);
      entry.layers.push({ node, owner: model.owner, side: model.side });
    }
  }
  function routeProbe(stage, travelDirection, count = routeActive.size, details = {}) {
    if (!window.SiteEngineProbe) return;
    try {
      window.SiteEngineProbe({
        kind: 'route-block',
        stage,
        direction: travelDirection > 0 ? 'forward' : 'backward',
        time: clock(),
        active: routeActive.size,
        count,
        rows: details.rows ?? 0,
        rowDurationMs: details.rowDurationMs ?? 0,
        rowStepMs: details.rowStepMs ?? 0,
        plannedDurationMs: details.plannedDurationMs ?? 0,
        completedBy: details.completedBy ?? null,
        phase: details.phase ?? null,
        navigationId: Number.isInteger(details.navigationId) ? details.navigationId : null,
        ...(details.attemptedRows === undefined ? {} : { attemptedRows: details.attemptedRows }),
      });
    } catch {
      // Optional diagnostics cannot retain content or interrupt phase promises.
    }
  }
  function routeState(state, travelDirection) {
    for (const container of [root, footer]) {
      if (!container) continue;
      if (state) {
        container.setAttribute('data-route-blocks', state);
        container.setAttribute(
          'data-route-direction',
          travelDirection > 0 ? 'forward' : 'backward'
        );
      } else {
        container.removeAttribute('data-route-blocks');
        container.removeAttribute('data-route-direction');
      }
    }
  }
  function clearRouteUnit(element) {
    clearSeparators('route', element);
    element.removeAttribute('data-route-block');
    element.removeAttribute('data-route-layer');
    element.removeAttribute('data-route-direction');
    element.removeAttribute('data-route-delay');
    element.removeAttribute('data-route-row');
    element.style.removeProperty('--route-block-distance');
    element.style.removeProperty('--route-block-delay');
    element.style.removeProperty('--route-block-duration');
  }
  function clearRoute() {
    window.clearTimeout(holdTask);
    holdTask = null;
    for (const element of routeUnits.keys()) clearRouteUnit(element);
    routeActive.clear();
    clearRoutePaper();
    routePrepared = null;
    routeState(null);
  }
  function cancelRoute(completedBy = 'cancelled') {
    routeGeneration++;
    const phase = routePhase;
    routePhase = null;
    if (phase) window.clearTimeout(phase.timer);
    const travelDirection = phase?.direction || routePrepared?.direction || 1;
    const changed = !!phase || !!routePrepared;
    const timing = phase?.timing || routePrepared?.timing;
    clearRoute();
    if (changed) routeProbe('cancelled', travelDirection, 0, { ...timing, completedBy });
    phase?.resolve({ completed: false, cancelled: true, completedBy });
  }
  function holdRoute(travelDirection, timing, completedBy = null) {
    routeState('holding', travelDirection);
    routePrepared = { direction: travelDirection, timing };
    for (const element of routeActive) element.setAttribute('data-route-block', 'holding');
    // The router normally replaces or releases this state within its finite
    // camera flight. A stalled owner must not leave native content unavailable.
    window.clearTimeout(holdTask);
    const own = routeGeneration;
    holdTask = window.setTimeout(
      guarded(() => {
        if (own === routeGeneration) {
          cancelRoute('watchdog');
          settle();
        }
      }),
      8000
    );
    routeProbe('holding', travelDirection, routeActive.size, { ...timing, completedBy });
  }
  function measureRoute() {
    // One native read batch per phase, including footer leaves. Header and
    // appearance controls belong to the persistent shell, never this inventory.
    clearRoutePaper();
    clearSeparators('route');
    refreshInventory();
    const measured = [...routeUnits].map(([element, record]) => {
      const rect = element.getBoundingClientRect();
      const children = [...(element.children || [])]
        .map((child) => child.getBoundingClientRect())
        .filter((child) => child.width > 0 && child.height > 0);
      const painted = (rect.width > 0 && rect.height > 0) || children.length > 0;
      // Media may intentionally extend beyond its semantic shell (Home's
      // facets do). Move the complete native visual envelope past the edge.
      return {
        element,
        record,
        native: rect,
        rect: {
          top: Math.min(rect.top, ...children.map((child) => child.top)),
          bottom: Math.max(rect.bottom, ...children.map((child) => child.bottom)),
        },
        visible: element.getClientRects().length > 0 && painted,
      };
    });
    const visible = measured.filter(
      (unit) =>
        unit.visible &&
        unit.rect.bottom > 0 &&
        unit.rect.top < window.innerHeight &&
        Number.isFinite(unit.rect.top) &&
        Number.isFinite(unit.rect.bottom)
    );
    measured.separators = measureSeparators(visible, true);
    measured.paper = measureRoutePaper();
    materializeSeparators(measured.separators, measured);
    const style = window.getComputedStyle(document.documentElement);
    measured.duration = Number.parseFloat(style.getPropertyValue('--block-motion-duration'));
    measured.phase = Number.parseFloat(style.getPropertyValue('--block-motion-phase'));
    return measured;
  }
  function clearRoutePaper() {
    if (!routePaper) return;
    routePaper.removeAttribute('data-route-paper');
    for (const name of [
      'left',
      'top',
      'width',
      'height',
      'top-radius',
      'bottom-radius',
      'distance',
      'duration',
      'delay',
    ])
      routePaper.style.removeProperty('--route-paper-' + name);
    routePaper = null;
  }
  function measureRoutePaper() {
    if (!root.matches('.article-reader')) return null;
    const element = root.querySelector?.('.reader-mode');
    if (!element?.getClientRects().length) return null;
    const rect = element.getBoundingClientRect();
    const top = Math.max(0, rect.top),
      bottom = Math.min(window.innerHeight, rect.bottom);
    if (
      ![rect.left, rect.width, top, bottom].every(Number.isFinite) ||
      rect.width <= 0 ||
      bottom <= top
    )
      return null;
    const style = window.getComputedStyle(element);
    const radius = Number.parseFloat(style.getPropertyValue('border-top-left-radius')) || 0;
    return {
      element,
      left: rect.left,
      top,
      width: rect.width,
      height: bottom - top,
      'top-radius': top === rect.top ? radius : 0,
      'bottom-radius': bottom === rect.bottom ? radius : 0,
    };
  }
  function prepareRoutePaper(model, timing, upward, state) {
    if (!model) return;
    routePaper = model.element;
    for (const name of ['left', 'top', 'width', 'height', 'top-radius', 'bottom-radius'])
      routePaper.style.setProperty('--route-paper-' + name, model[name] + 'px');
    const distance = upward
      ? -(model.top + model.height + 32)
      : window.innerHeight - model.top + 32;
    routePaper.style.setProperty('--route-paper-distance', distance + 'px');
    // Paper arrives with the first row and leaves with the last, keeping opaque
    // paint behind the readable blocks throughout the existing wave.
    routePaper.style.setProperty('--route-paper-duration', timing.rowDurationMs + 'ms');
    const delay = state === 'departing' ? timing.plannedDurationMs - timing.rowDurationMs : 0;
    routePaper.style.setProperty('--route-paper-delay', delay + 'ms');
    routePaper.setAttribute('data-route-paper', '');
  }
  function routeTiming(rows, measured, state, navigationId) {
    const specified = measured.duration;
    const specifiedPhase = measured.phase;
    const phaseDuration =
      Number.isFinite(specifiedPhase) && specifiedPhase >= 1000 && specifiedPhase <= 1200
        ? specifiedPhase
        : 1000;
    const duration =
      rows === 1
        ? phaseDuration
        : Number.isFinite(specified) && specified >= 450 && specified <= 700
          ? specified
          : 700;
    // A fixed phase envelope owns latency. Density changes the wave's spacing,
    // while each row retains a visible movement and its directional order.
    return {
      rows,
      rowDurationMs: rows ? duration : 0,
      rowStepMs: rows > 1 ? (phaseDuration - duration) / (rows - 1) : 0,
      plannedDurationMs: rows ? phaseDuration : 0,
      bounded: rows <= 24,
      phase: state === 'departing' ? 'departure' : 'arrival',
      navigationId,
    };
  }
  function prepareRoute(travelDirection, measured, state, navigationId = null) {
    routeActive.clear();
    const selected = measured
      .filter(
        ({ rect, visible }) =>
          visible &&
          Number.isFinite(rect.top) &&
          Number.isFinite(rect.bottom) &&
          rect.bottom > 0 &&
          rect.top < window.innerHeight
      )
      .sort((a, b) => a.native.top - b.native.top);
    const rows = [];
    for (const unit of selected) {
      let row = rows.at(-1);
      if (!row || unit.native.top >= row.bottom - 0.5) {
        row = { top: unit.native.top, bottom: unit.native.bottom, units: [] };
        rows.push(row);
      }
      row.bottom = Math.max(row.bottom, unit.native.bottom);
      row.units.push(unit);
    }
    const timing = routeTiming(
      Math.max(rows.length, measured.paper ? 1 : 0),
      measured,
      state,
      navigationId
    );
    const duration = timing.rowDurationMs;
    // Exceptional geometry falls back to fully native content. Admitted rows
    // keep their identity and share a fixed-duration directional wave.
    if (!timing.bounded) return timing;
    const upward = state === 'departing' ? travelDirection > 0 : travelDirection < 0;
    for (const { element } of measured) clearRouteUnit(element);
    const wholeBlocks = root.matches('.article-reader');
    for (const { element, record } of selected)
      if (!wholeBlocks && !record.ink) wrapInk(element, record);
    attachSeparators(measured.separators, 'route');
    prepareRoutePaper(measured.paper, timing, upward, state);
    for (const [index, row] of rows.entries()) {
      // Wave rows only travel far enough to clear their own complete paint.
      // Native peers share this envelope so ink, paper and dividers stay aligned.
      const distance = upward
        ? -(Math.max(...row.units.map((unit) => unit.rect.bottom)) + 32)
        : window.innerHeight - Math.min(...row.units.map((unit) => unit.rect.top)) + 32;
      for (const { element } of row.units) {
        // Reader components own their background, borders and native markers.
        // Move the complete box once instead of leaving shell paint behind.
        if (wholeBlocks) element.setAttribute('data-route-layer', 'self');
        const order = travelDirection > 0 ? index : rows.length - 1 - index;
        element.style.setProperty('--route-block-distance', `${Math.round(distance)}px`);
        element.style.setProperty('--route-block-delay', `${order * timing.rowStepMs}ms`);
        element.style.setProperty('--route-block-duration', `${duration}ms`);
        element.setAttribute('data-route-direction', travelDirection > 0 ? 'forward' : 'backward');
        element.setAttribute('data-route-row', String(index));
        element.setAttribute('data-route-delay', String(order));
        element.setAttribute('data-route-block', state);
        routeActive.add(element);
      }
    }
    return timing;
  }
  function completeRoute(own, completedBy = 'animationend') {
    const phase = routePhase;
    if (!phase || own !== routeGeneration) return;
    routePhase = null;
    window.clearTimeout(phase.timer);
    if (phase.state === 'departing') {
      // Keep every unit hidden until the router mounts the destination. The
      // finished transform is never reset to a visible old-page flash.
      holdRoute(phase.direction, phase.timing, completedBy);
    } else {
      for (const element of routeActive) finish(element);
      clearRoute();
      routeProbe('settled', phase.direction, phase.count, { ...phase.timing, completedBy });
    }
    phase.resolve({ completed: true, cancelled: false, completedBy });
  }
  function fallbackRoute(travelDirection, timing = null) {
    // Orphan separator shells can exist after the read batch, before paint
    // layers are attached. Release them too when the native-row guard rejects.
    for (const [element, record] of routeUnits) {
      if (!record.isolated) continue;
      element.remove();
      routeUnits.delete(element);
    }
    settle();
    routeProbe('cancelled', travelDirection, 0, {
      ...timing,
      rows: 0,
      rowDurationMs: 0,
      rowStepMs: 0,
      plannedDurationMs: 0,
      attemptedRows: timing?.rows ?? 0,
      completedBy: 'fallback',
    });
    return Promise.resolve({ completed: false, cancelled: true, completedBy: 'fallback' });
  }
  function beginRoute(state, travelDirection, measured, navigationId) {
    const own = ++routeGeneration;
    window.clearTimeout(holdTask);
    holdTask = null;
    const timing = prepareRoute(travelDirection, measured, state, navigationId);
    if (!timing.bounded) return fallbackRoute(travelDirection, timing);
    routeState(state, travelDirection);
    routePrepared = null;
    routeProbe(
      state === 'departing' ? 'departure' : 'arrival',
      travelDirection,
      routeActive.size,
      timing
    );
    return new Promise((resolve) => {
      routePhase = {
        state,
        direction: travelDirection,
        count: routeActive.size,
        pending: new Map(
          [...routeActive].map((element) => [
            element,
            Number.parseFloat(element.style.getPropertyValue('--route-block-delay')) +
              timing.rowDurationMs,
          ])
        ),
        ...animationMark(),
        timing,
        resolve,
        timer: null,
      };
      if (routePaper)
        routePhase.pending.set(
          routePaper,
          Number.parseFloat(routePaper.style.getPropertyValue('--route-paper-duration')) +
            Number.parseFloat(routePaper.style.getPropertyValue('--route-paper-delay'))
        );
      // Missing/cancelled events receive the same finite slack after the fixed
      // wave envelope; page density cannot extend the planned transition.
      routePhase.timer = window.setTimeout(
        guarded(() => completeRoute(own, 'watchdog')),
        timing.plannedDurationMs + 1000
      );
      if (!routePhase.pending.size) completeRoute(own, 'empty');
    });
  }
  function depart(travelDirection = 1, navigationId = null) {
    cancelRoute();
    suspend();
    if (!root || !routeAllowed()) {
      return fallbackRoute(travelDirection, { phase: 'departure', navigationId });
    }
    return beginRoute('departing', travelDirection < 0 ? -1 : 1, measureRoute(), navigationId);
  }
  function prepareArrival(travelDirection = 1, navigationId = null) {
    cancelRoute();
    suspend();
    if (!root || !routeAllowed()) {
      fallbackRoute(travelDirection, { phase: 'arrival', navigationId });
      return false;
    }
    const nextDirection = travelDirection < 0 ? -1 : 1;
    const timing = prepareRoute(nextDirection, measureRoute(), 'holding', navigationId);
    if (!timing.bounded) {
      fallbackRoute(nextDirection, timing);
      return false;
    }
    holdRoute(nextDirection, timing);
    return true;
  }
  function arrive(travelDirection = 1, navigationId = null) {
    if (!root || !routePrepared || !routeAllowed()) {
      return fallbackRoute(travelDirection, { phase: 'arrival', navigationId });
    }
    // Native landing/history restoration may have changed since mount. Re-read
    // once after the camera's rest paint, before any finite layer writes.
    return beginRoute('arriving', travelDirection < 0 ? -1 : 1, measureRoute(), navigationId);
  }
  function cancel() {
    cancelRoute();
    settle();
  }
  function armReading(unit, borders, pageBottom, viewport) {
    const { element, record, native, visible } = unit;
    if (
      !visible ||
      readingDistance <= 0 ||
      native.top < viewport.height ||
      native.bottom + viewport.scrollY + readingDistance + 32 >= pageBottom ||
      (document.activeElement && element.contains(document.activeElement))
    ) {
      finish(element);
      return;
    }
    record.done = false;
    if (!record.ink) wrapInk(element, record);
    attachSeparators(borders, 'reading', element);
    element.setAttribute('data-scroll-entry', 'waiting');
  }
  function startReading(element, index, own) {
    const mark = animationMark();
    element.setAttribute('data-scroll-delay', String(index));
    element.setAttribute('data-scroll-entry', 'entering');
    // An event normally releases the state. This one-shot fallback also
    // releases it if a stylesheet is replaced or an animation is cancelled.
    const timer = window.setTimeout(() => {
      if (own !== generation) return;
      finish(element);
      // A missing animation event releases queued native content too; failure
      // cannot grow into successive watchdog-length waves.
      for (const queued of pendingReading.keys()) finish(queued);
    }, 2000);
    active.set(element, {
      timer,
      ...mark,
      plannedDurationMs: readingDuration + index * readingStagger,
    });
  }
  function drainReading(own) {
    if (own !== generation || suspended || !allowed()) return;
    const measured = [...pendingReading].map(([element, index]) => ({
      element,
      index,
      rect: element.getBoundingClientRect(),
    }));
    for (const { element, index, rect } of measured) {
      if (
        direction <= 0 ||
        clock() < jumpUntil ||
        rect.bottom <= 0 ||
        rect.top >= window.innerHeight
      ) {
        finish(element);
        continue;
      }
      if (active.size >= 6) break;
      pendingReading.delete(element);
      startReading(element, index, own);
    }
  }
  function enter(entries, own) {
    if (own !== generation || suspended || !allowed()) return;
    const pageBottom = document.documentElement.scrollHeight;
    const viewport = { scrollY: window.scrollY, height: window.innerHeight };
    const siblings = new Map();
    for (const entry of entries) {
      const element = entry.target;
      const record = records.get(element);
      if (!record) continue;
      if (!entry.isIntersecting) {
        if (entry.boundingClientRect.top >= viewport.height && direction < 0) {
          clearState(element);
          const rect = entry.boundingClientRect;
          armReading(
            {
              element,
              record,
              native: rect,
              rect: { top: rect.top, bottom: rect.bottom },
              visible: element.getClientRects().length > 0,
            },
            readingBorders,
            pageBottom,
            viewport
          );
        } else if (active.has(element) || pendingReading.has(element)) finish(element);
        continue;
      }
      if (record.done || active.has(element) || pendingReading.has(element)) continue;
      if (direction <= 0 || clock() < jumpUntil) {
        finish(element);
        continue;
      }
      const group = element.parentElement;
      const index = Math.min(2, siblings.get(group) || 0);
      siblings.set(group, index + 1);
      // Dense native rows retain their next reveal instead of permanently
      // consuming excess shells. The existing six-active bound stays intact.
      if (active.size >= 6) pendingReading.set(element, index);
      else startReading(element, index, own);
    }
  }
  function releaseReadingStates() {
    for (const element of records.keys()) {
      if (active.has(element)) finish(element);
      else clearState(element);
    }
  }
  function reconcile() {
    disconnect();
    if (suspended || !root) return;
    refreshInventory();
    if (!allowed()) {
      // Readiness is separate from disabled motion; late scene initialization
      // may still arm untouched below-fold content after its owner notifies us.
      if (enabled() && window.SiteScene?.motionState?.().ready) settle();
      else releaseReadingStates();
      return;
    }
    const style = window.getComputedStyle(root);
    const distance = Number.parseFloat(style.getPropertyValue('--scroll-entry-distance'));
    if (!Number.isFinite(distance) || distance <= 0) return;
    readingDistance = distance;
    const duration = Number.parseFloat(style.getPropertyValue('--block-motion-duration'));
    const stagger = Number.parseFloat(style.getPropertyValue('--block-motion-stagger'));
    readingDuration =
      Number.isFinite(duration) && duration >= 450 && duration <= 700 ? duration : 700;
    readingStagger = Number.isFinite(stagger) && stagger >= 0 && stagger <= 120 ? stagger : 80;
    // Batch native reads before any transient layer/state writes. The last
    // block stays steady when its moving ink/paper would grow scroll overflow.
    releaseReadingStates();
    const viewport = { scrollY: window.scrollY, height: window.innerHeight };
    const pageBottom = document.documentElement.scrollHeight;
    const measured = [...records].map(([element, record]) => {
      const rect = element.getBoundingClientRect();
      return {
        element,
        record,
        rect: {
          top: rect.top,
          bottom: rect.bottom,
          left: rect.left,
          right: rect.right,
          width: rect.width,
          height: rect.height,
        },
        native: rect,
        visible: element.getClientRects().length > 0,
      };
    });
    const borders = measureSeparators(measured);
    // Native side paint and ownership are measured together after cleanup.
    // Repeated crossings reuse them until reflow/theme/layout reconciliation,
    // even while a sibling still suppresses another side of the same source.
    readingBorders = borders;
    const own = generation;
    observer = new window.IntersectionObserver(
      guarded((entries) => enter(entries, own)),
      {
        rootMargin: '0px',
        threshold: 0.001,
      }
    );
    for (const { element, record, rect, native, visible } of measured) {
      if (!visible) {
        clearState(element);
        continue;
      }
      armReading({ element, record, native, rect, visible }, borders, pageBottom, viewport);
      observer.observe(element);
    }
    previousY = viewport.scrollY;
  }
  function deferReconcile() {
    window.clearTimeout(reconcileTask);
    const own = generation;
    // Archive notification precedes synchronous hash landing. Reconcile after
    // that landing, once, rather than on every individual hidden-row mutation.
    reconcileTask = window.setTimeout(
      guarded(() => {
        reconcileTask = null;
        if (own === generation) reconcile();
      }),
      0
    );
  }
  function resume() {
    cancelRoute();
    suspended = false;
    reconcile();
  }
  function refreshPreference() {
    cancelRoute();
    disconnect();
    releaseReadingStates();
    if (!suspended && allowed()) reconcile();
  }
  function destroy() {
    cancelRoute();
    suspend();
    for (const remove of listeners.splice(0)) remove();
    for (const [element, record] of knownRecords) {
      if (record.ink) record.ink.replaceWith(...record.ink.childNodes);
      clearState(element);
    }
    records.clear();
    routeUnits.clear();
    knownRecords.clear();
    clearSeparators('reading');
    clearSeparators('route');
    nextUnitId = 0;
    readingDistance = 0;
    readingBorders = [];
    root = null;
    footer = null;
  }
  function mount(main, options = {}) {
    destroy();
    failed = false;
    if (!main) return;
    root = main;
    footer = options.footer || document.querySelector('.site-footer');
    refreshInventory();
    for (const element of records.keys()) clearState(element);
    for (const element of routeUnits.keys()) clearRouteUnit(element);
    previousY = window.scrollY;
    direction = 0;
    jumpUntil = 0;
    const animationFinished = guarded((event) => {
      if (
        event.animationName === 'route-block-depart' ||
        event.animationName === 'route-block-arrive'
      ) {
        const expected =
          routePhase?.state === 'departing' ? 'route-block-depart' : 'route-block-arrive';
        const element =
          event.target === routePaper && event.pseudoElement === '::before'
            ? routePaper
            : event.target.closest('[data-route-block]');
        if (event.animationName !== expected || !routePhase?.pending.has(element)) return;
        // A queued event from a cancelled animation on this retained node
        // cannot consume its new row before the new planned end has elapsed.
        if (animationElapsed(routePhase) < routePhase.pending.get(element) - 8) return;
        routePhase.pending.delete(element);
        if (!routePhase.pending.size) completeRoute(routeGeneration);
      } else {
        if (event.animationName !== 'scroll-entry-rise') return;
        const element = event.target.closest('[data-scroll-entry]');
        const entry = active.get(element);
        if (entry) {
          // An old queued completion cannot settle this retained shell's new
          // reveal before its own duration and sibling delay have elapsed.
          if (animationElapsed(entry) < entry.plannedDurationMs - 8) return;
          finish(element);
          drainReading(generation);
        }
      }
    });
    listen(root, 'animationend', animationFinished);
    listen(footer, 'animationend', animationFinished);
    const focusSettled = guarded((event) => {
      if (event.target !== root) settle(event.target);
    });
    listen(root, 'focusin', focusSettled);
    listen(footer, 'focusin', focusSettled);
    listen(
      root,
      'beforematch',
      guarded((event) => settle(event.target))
    );
    listen(
      window,
      'scroll',
      guarded(() => {
        const next = window.scrollY;
        const delta = next - previousY;
        // Duplicate browser scroll notifications must not erase the last real
        // direction before the asynchronous observer receives its crossing.
        if (delta !== 0) direction = Math.sign(delta);
        previousY = next;
        if (Math.abs(delta) > Math.max(480, window.innerHeight * 0.75)) {
          jumpUntil = clock() + 250;
          for (const element of active.keys()) finish(element);
          for (const element of pendingReading.keys()) finish(element);
        } else if (direction < 0) {
          for (const element of active.keys()) finish(element);
          for (const element of pendingReading.keys()) finish(element);
        }
      }),
      { passive: true }
    );
    listen(window, 'site:archive-layout', guarded(deferReconcile));
    if (window.MutationObserver) {
      const themeObserver = new window.MutationObserver(
        guarded(() => {
          cancelRoute();
          clearSeparators('reading');
          if (!suspended) deferReconcile();
        })
      );
      themeObserver.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['data-theme'],
      });
      listeners.push(() => themeObserver.disconnect());
    }
    listen(
      window,
      'resize',
      guarded(() => {
        if (routePhase) cancel();
        deferReconcile();
      }),
      { passive: true }
    );
    listen(document.fonts, 'loadingdone', guarded(deferReconcile));
    listen(
      window,
      'site:motion-state',
      guarded(() => {
        if (!enabled()) {
          refreshPreference();
          return;
        }
        if (!allowed() && window.SiteScene?.motionState?.().ready) {
          cancelRoute();
          disconnect();
          settle();
          return;
        }
        if (suspended) return;
        if (allowed()) reconcile();
        else if (window.SiteScene?.motionState?.().ready) {
          disconnect();
          settle();
        }
      })
    );
    listen(
      document,
      'keydown',
      guarded((event) => {
        if ((event.ctrlKey || event.metaKey) && ['f', 'g'].includes(event.key.toLowerCase()))
          settle();
        if (['PageUp', 'PageDown', 'Home', 'End'].includes(event.key)) jumpUntil = clock() + 500;
      })
    );
    listen(
      document,
      'click',
      guarded((event) => {
        const link = event.target.closest?.('a[href]');
        if (link?.getAttribute('href').startsWith('#')) settle();
      }),
      true
    );
    listen(
      window,
      'hashchange',
      guarded(() => {
        settle();
        deferReconcile();
      })
    );
    listen(
      document,
      'visibilitychange',
      guarded(() => {
        if (document.hidden) {
          disconnect();
          settle();
        } else if (!suspended) reconcile();
      })
    );
    listen(
      window,
      'beforeprint',
      guarded(() => {
        disconnect();
        settle();
      })
    );
    listen(
      window,
      'pagehide',
      guarded(() => {
        disconnect();
        settle();
      })
    );
    listen(
      window,
      'pageshow',
      guarded(() => {
        if (!suspended) deferReconcile();
      })
    );
  }
  function boot() {
    if (booted) return;
    booted = true;
    const ready = guarded(() => {
      if (root) return;
      mount(document.querySelector('main'));
      resume();
    });
    if (document.readyState === 'loading' || document.readyState === 'interactive')
      document.addEventListener('DOMContentLoaded', ready, { once: true });
    else ready();
  }
  return {
    boot: guarded(boot),
    mount: guarded(mount),
    suspend: guarded(suspend),
    resume: guarded(resume),
    settle: guarded(settle),
    destroy: guarded(destroy),
    depart: guardedPhase(depart),
    prepareArrival: guarded(prepareArrival),
    arrive: guardedPhase(arrive),
    cancelRoute: guarded(cancelRoute),
    cancel: guarded(cancel),
    refreshPreference: guarded(refreshPreference),
    diagnostics: () => ({
      targets: records.size,
      active: active.size,
      observing: !!observer,
      suspended,
      routeTargets: routeUnits.size,
      routeActive: routeActive.size,
      routeStage: routePhase?.state || (routePrepared ? 'holding' : null),
    }),
  };
})();
window.SiteReader=(function readerMode() {
  let dispose = () => {};
  let snapshot = () => null;
  let restore = () => {};
  function destroy() {
    dispose();
    dispose = () => {};
    snapshot = () => null;
    restore = () => {};
  }
  function mount({ state = null } = {}) {
    destroy();
    const main = document.querySelector('main.article-reader');
    if (!main) return;
    const listeners = [],
      printState = new Map();
    const details = [...main.querySelectorAll('details')];
    const listen = (target, event, handler, options) => {
      target.addEventListener(event, handler, options);
      listeners.push(() => target.removeEventListener(event, handler, options));
    };
    const fragmentId = (hash) => {
      try {
        return decodeURIComponent(hash.slice(1));
      } catch {
        return '';
      }
    };
    const links = [...main.querySelectorAll('.article-toc a')];
    const headings = links
      .map((link) => document.getElementById(fragmentId(link.hash)))
      .filter(Boolean);
    const contents = main.querySelector('.reader-contents');
    const currentLabel = main.querySelector('[data-reader-current]');
    if (contents) {
      contents.open = false;
      contents.setAttribute('data-reader-enhanced', '');
    }
    let activeDialog = null;
    const finishDialog = (record, returnFocus) => {
      if (!record) return;
      if (activeDialog === record) activeDialog = null;
      const trigger = record.trigger;
      record.trigger = null;
      record.reset();
      if (returnFocus && trigger?.isConnected) trigger.focus({ preventScroll: true });
    };
    const closeDialog = (returnFocus = true) => {
      const record = activeDialog;
      if (!record) return;
      activeDialog = null;
      if (record.element.open) record.element.close();
      finishDialog(record, returnFocus);
    };
    const dialog = (selector, reset) => {
      const element = main.querySelector(selector);
      if (
        !element ||
        typeof element.showModal !== 'function' ||
        typeof element.close !== 'function'
      )
        return null;
      const close = element.querySelector('[data-reader-close]');
      if (!close) return null;
      const record = { element, close, reset, trigger: null };
      element.hidden = false;
      listen(close, 'click', () => closeDialog());
      listen(element, 'cancel', (event) => {
        event.preventDefault();
        closeDialog();
      });
      listen(element, 'click', (event) => {
        if (event.target === element) closeDialog();
      });
      listen(element, 'close', () => {
        if (!element.open && activeDialog === record) finishDialog(record, true);
      });
      return record;
    };
    const openDialog = (record, trigger) => {
      if (!record) return false;
      closeDialog(false);
      record.trigger = trigger;
      try {
        record.element.showModal();
      } catch {
        finishDialog(record, false);
        return false;
      }
      activeDialog = record;
      record.close.focus({ preventScroll: true });
      return true;
    };
    const imageStage = main.querySelector('[data-reader-image]');
    const imageCaption = main.querySelector('[data-reader-image-caption]');
    const imageOriginal = main.querySelector('[data-reader-image-original]');
    const zoom = main.querySelector('[data-reader-zoom]');
    const imageDialog =
      imageStage && imageCaption && imageOriginal && zoom
        ? dialog('.reader-image-dialog', () => {
            imageStage.replaceChildren();
            imageCaption.textContent = '';
            imageDialog.element.classList.remove('reader-zoomed');
            zoom.setAttribute('aria-pressed', 'false');
          })
        : null;
    if (imageDialog)
      listen(zoom, 'click', () => {
        const enlarged = imageDialog.element.classList.toggle('reader-zoomed');
        zoom.setAttribute('aria-pressed', String(enlarged));
      });
    const noteBody = main.querySelector('[data-reader-note-body]');
    const noteTitle = main.querySelector('[data-reader-note-title]');
    const noteFull = main.querySelector('[data-reader-note-full]');
    const noteDialog =
      noteBody && noteTitle && noteFull
        ? dialog('.reader-note-dialog', () => noteBody.replaceChildren())
        : null;
    const enhancedLinks = [...main.querySelectorAll('.reader-citation, .reader-image-open')].filter(
      (anchor) => (anchor.classList.contains('reader-citation') ? noteDialog : imageDialog)
    );
    for (const anchor of enhancedLinks) anchor.setAttribute('aria-haspopup', 'dialog');
    const showImage = (anchor) => {
      const image = anchor.querySelector('img');
      if (!imageDialog || !image) return false;
      const copy = image.cloneNode(false);
      copy.removeAttribute('id');
      const caption = anchor.closest('figure')?.querySelector('figcaption > p');
      if (!openDialog(imageDialog, anchor)) return false;
      imageStage.replaceChildren(copy);
      imageCaption.textContent = caption?.textContent || image.alt;
      imageOriginal.href = anchor.href;
      return true;
    };
    const showNote = (anchor, url) => {
      const note = document.getElementById(fragmentId(url.hash));
      if (!noteDialog || !note || !main.contains(note) || !note.closest('.reader-appendix'))
        return false;
      const copy = note.cloneNode(true);
      // Cloned source text retains links and caveats, never duplicate anchors or return controls.
      for (const child of copy.querySelectorAll('.reader-note-returns, [role="doc-backlink"]'))
        child.remove();
      for (const child of copy.querySelectorAll('[id], [aria-labelledby], [aria-describedby]')) {
        child.removeAttribute('id');
        child.removeAttribute('aria-labelledby');
        child.removeAttribute('aria-describedby');
      }
      if (!openDialog(noteDialog, anchor)) return false;
      noteTitle.textContent = anchor.getAttribute('aria-label') || 'Reference';
      noteDialog.element.setAttribute('aria-label', noteTitle.textContent);
      noteBody.replaceChildren(...copy.childNodes);
      noteFull.setAttribute('href', url.hash);
      return true;
    };
    const reveal = (hash) => {
      let target;
      try {
        target = document.getElementById(decodeURIComponent(hash.slice(1)));
      } catch {
        return;
      }
      if (!target || !main.contains(target)) return;
      for (let node = target.parentElement; node && node !== main; node = node.parentElement)
        if (node.tagName === 'DETAILS') node.open = true;
    };
    for (const appendix of main.querySelectorAll('.reader-appendix')) appendix.open = false;
    restore = (saved) => {
      if (
        Array.isArray(saved) &&
        saved.length === details.length &&
        saved.length <= 256 &&
        saved.every((open) => typeof open === 'boolean')
      )
        details.forEach((detail, index) => {
          detail.open = saved[index];
        });
      reveal(window.location.hash);
    };
    snapshot = () => details.map((detail) => printState.get(detail) ?? detail.open);
    restore(state);
    listen(window, 'hashchange', () => {
      closeDialog(false);
      reveal(window.location.hash);
    });
    listen(main, 'click', (event) => {
      if (
        event.defaultPrevented ||
        (event.button !== undefined && event.button !== 0) ||
        event.metaKey ||
        event.ctrlKey ||
        event.shiftKey ||
        event.altKey
      )
        return;
      const anchor = event.target.closest?.('a[href]');
      if (!anchor) return;
      if (anchor.hasAttribute?.('download') || anchor.getAttribute?.('target')) return;
      if (anchor.classList?.contains('reader-image-open') && showImage(anchor)) {
        event.preventDefault();
        return;
      }
      const url = new URL(anchor.href, window.location.href);
      if (
        url.origin !== window.location.origin ||
        url.pathname !== window.location.pathname ||
        url.search !== window.location.search
      )
        return;
      if (anchor.classList?.contains('reader-citation') && showNote(anchor, url)) {
        event.preventDefault();
        return;
      }
      if (anchor === noteFull) closeDialog(false);
      reveal(url.hash);
      if (anchor.closest('.article-toc') && contents) contents.open = false;
    });
    let currentId = null;
    const current = (id) => {
      if (id === currentId) return;
      currentId = id;
      for (const link of links) {
        if (fragmentId(link.hash) === id) link.setAttribute('aria-current', 'location');
        else link.removeAttribute('aria-current');
      }
      if (currentLabel) currentLabel.textContent = document.getElementById(id)?.textContent || '';
    };
    const updateCurrent = () => {
      if (printState.size) return;
      // Intersection callbacks can skip a whole chapter on PageDown, End or history jumps.
      // Search the ordered heading positions, retaining the first heading in the reading band.
      let lower = 0,
        upper = headings.length;
      while (lower < upper) {
        const middle = (lower + upper) >>> 1;
        if (headings[middle].getBoundingClientRect().top < 110) lower = middle + 1;
        else upper = middle;
      }
      const next = headings[lower];
      const active =
        next && next.getBoundingClientRect().top <= Math.max(110, window.innerHeight * 0.4)
          ? next
          : headings[lower - 1];
      current(active?.id || '');
    };
    const observer = window.IntersectionObserver
      ? new window.IntersectionObserver(updateCurrent, {
          rootMargin: '-110px 0px -60% 0px',
          threshold: 0,
        })
      : null;
    for (const heading of headings) observer?.observe(heading);
    listen(window, 'scroll', updateCurrent, { passive: true });
    listen(window, 'resize', updateCurrent);
    updateCurrent();
    listen(window, 'beforeprint', () => {
      closeDialog(false);
      for (const detail of main.querySelectorAll('details')) {
        printState.set(detail, detail.open);
        detail.open = true;
      }
    });
    const restorePrint = () => {
      for (const [detail, open] of printState) detail.open = open;
      printState.clear();
    };
    listen(window, 'afterprint', restorePrint);
    listen(window, 'pagehide', () => closeDialog(false));
    for (const detail of details)
      listen(detail, 'toggle', () => {
        if (!printState.size) window.dispatchEvent(new window.Event('site:reader-state'));
      });
    dispose = () => {
      closeDialog(false);
      contents?.removeAttribute('data-reader-enhanced');
      for (const anchor of enhancedLinks) anchor.removeAttribute('aria-haspopup');
      observer?.disconnect();
      for (const remove of listeners) remove();
      restorePrint();
    };
  }
  return { mount, destroy, snapshot: () => snapshot(), restore: (state) => restore(state) };
})();
/* One document, one header and one canvas. Every route remains ordinary HTML. */
(() => {
  'use strict';
  const scrollEntry = window.SiteScrollEntry;
  scrollEntry?.boot();
  window.SiteReader?.mount({ state: history.state?.site?.reader });
  const routes = ['index', 'research', 'writing', 'talks', 'credits'];
  const bundle = document.getElementById('site-pages');
  const embedded = bundle ? JSON.parse(bundle.textContent) : null;
  const entry = new URL(window.location.href);
  const directory = new URL(
    document.querySelector('meta[name="site-base"]')?.content || '.',
    entry
  );
  const documentIndex = document.getElementById('site-documents');
  const articles = documentIndex ? JSON.parse(documentIndex.textContent) : {};
  function embeddedResources(doc, declared) {
    const urls = new Map();
    if (!declared) return urls;
    for (const element of doc.querySelectorAll('[data-offline-resource]')) {
      const name = element.getAttribute('data-offline-resource');
      const value = element.getAttribute(element.tagName === 'IMG' ? 'src' : 'href');
      if (urls.has(name) && urls.get(name) !== value) return null;
      urls.set(name, value);
    }
    return urls;
  }
  const embeddedAssetURLs = embeddedResources(document, embedded?.assets);
  if (!embeddedAssetURLs) return;
  let embeddedAssetsReady = null;
  if (Object.keys(articles).length > 50) return;
  for (const [key, article] of Object.entries(articles)) {
    if (
      !/^[a-z][a-z0-9-]{0,79}:(?:en|uk)$/.test(key) ||
      !/^articles\/[a-z][a-z0-9-]{0,79}\.html$/.test(article.url) ||
      (article.snapshot &&
        !/^article-snapshots\/[a-f0-9]{64}\/[a-z][a-z0-9-]{0,79}\.html$/.test(article.snapshot))
    )
      return;
  }
  const shellEngine = document.querySelector('meta[name="site-engine"]')?.content;
  const initialVersion = document.querySelector('meta[name="site-route"]')?.content;
  const initialPage = document.body.dataset.article
    ? 'article:' + document.body.dataset.article
    : document.body.dataset.page;
  let pinned = null;
  let page = initialPage,
    historyIndex = Number.isSafeInteger(history.state?.site?.index) ? history.state.site.index : 0,
    serial = 0,
    request = null,
    transition = null,
    scrollSave = null;
  let endpoint = null,
    endpointTimer = null,
    endpointObserver = null,
    inputTail = null,
    lastWheel = -Infinity,
    lastWheelDirection = 0,
    lastKey = null;
  if (
    !(routes.includes(page) || articles[page.slice(8)]) ||
    !window.fetch ||
    !window.DOMParser ||
    !window.history.pushState
  )
    return;
  const cache = new Map();
  const content = document.createElement('div');
  content.id = 'site-content';
  const effects = window.SiteEffects;
  if (effects && effects.contract !== 1) throw Error('Incompatible navigation effect contract');
  const presentation = effects?.navigation?.(content);
  const main = document.querySelector('main'),
    footer = document.querySelector('footer');
  if (!main || !footer) return;
  // History changes the document's base URL. Preserve each persistent header
  // destination, then keep its native relative link correct for every mount.
  const headerURLs = new Map(
    [...document.querySelectorAll('.site-header a[href]')].map((link) => [
      link,
      new URL(link.getAttribute('href'), entry),
    ])
  );
  main.before(content);
  content.append(main, footer);
  const frame = document.createElement('div');
  frame.id = 'site-content-frame';
  content.before(frame);
  frame.append(content);
  presentation?.mount?.();
  const announcement = document.createElement('p');
  announcement.className = 'sr-only';
  announcement.setAttribute('role', 'status');
  announcement.setAttribute('aria-live', 'polite');
  document.body.append(announcement);
  // The exact Home media fallback travels with the verified route head, including
  // CSS-unavailable navigation. Other routes remove it with their prior metadata.
  const metadata =
    'meta[name="description"],meta[property^="og:"],meta[name^="twitter:"],meta[name="robots"],meta[name="site-article"],meta[name="site-route"],link[rel="canonical"],link[rel="alternate"],script[type="application/ld+json"],style[data-critical-media]';
  function resolveResources(data, sourceURL) {
    for (const root of [data.main, data.footer, data.fallback, ...data.metadata])
      for (const element of [root, ...root.querySelectorAll('[href],[src]')])
        for (const attribute of ['href', 'src']) {
          const value = element.getAttribute(attribute);
          if (value && !/^(?:https:|mailto:|#|data:)/.test(value))
            element.setAttribute(attribute, new URL(value, sourceURL).href);
        }
  }
  function rebaseResources(data, url) {
    if (embedded) return;
    const depth = url.pathname.slice(directory.pathname.length).split('/').length - 1;
    for (const root of [data.main, data.footer, data.fallback])
      for (const element of [root, ...root.querySelectorAll('[href],[src]')])
        for (const attribute of ['href', 'src']) {
          const value = element.getAttribute(attribute);
          if (!value || /^(?:mailto:|#|data:)/.test(value)) continue;
          const target = new URL(value, data.sourceURL || entry);
          if (target.origin !== entry.origin || !target.pathname.startsWith(directory.pathname))
            continue;
          const relative =
            '../'.repeat(Math.max(0, depth)) + target.pathname.slice(directory.pathname.length);
          element.setAttribute(attribute, (relative || './') + target.search + target.hash);
        }
  }
  function extract(doc, immutable = false, sourceURL = null) {
    const scene = doc.body.dataset.page;
    const article = doc.body.dataset.article;
    const next = article ? 'article:' + article : scene;
    const main = doc.querySelector('main'),
      footer = doc.querySelector('footer'),
      fallback = doc.querySelector('.space-fallback');
    if (
      !routes.includes(scene) ||
      (article && (!articles[article] || scene !== 'writing')) ||
      !main ||
      !footer ||
      !fallback
    )
      throw Error('Incomplete site route');
    const version = doc.querySelector('meta[name="site-route"]')?.content,
      engine = doc.querySelector('meta[name="site-engine"]')?.content;
    const data = {
      page: next,
      scene,
      article,
      version,
      engine,
      sourceURL: sourceURL || window.location.href,
      title: doc.title,
      lang: doc.documentElement.lang,
      main: main.cloneNode(true),
      footer: footer.cloneNode(true),
      fallback: fallback.cloneNode(true),
      metadata: [...doc.head.querySelectorAll(metadata)].map((node) => node.cloneNode(true)),
    };
    if (immutable) resolveResources(data, sourceURL);
    return data;
  }
  cache.set(page, extract(document));
  let slideSession = null;
  function closeSlides() {
    if (!slideSession) return;
    const { control, host, controller, url } = slideSession;
    slideSession = null;
    controller.abort();
    if (url) URL.revokeObjectURL(url);
    host.replaceChildren();
    host.hidden = true;
    control.removeAttribute('aria-busy');
    control.setAttribute('aria-expanded', 'false');
    control.textContent = 'View slides here';
  }
  async function slideBytes(source, signal) {
    const response = await fetch(source, {
      signal,
      credentials: 'same-origin',
      redirect: 'error',
    });
    if (!response.ok || !response.headers.get('content-type')?.includes('application/pdf')) {
      throw Error('Presentation PDF unavailable');
    }
    const reader = response.body.getReader();
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.length;
        if (size > 2000000) throw Error('Presentation PDF exceeds its byte budget');
        chunks.push(value);
      }
    } finally {
      await reader.cancel();
    }
    return new Uint8Array(await new Blob(chunks).arrayBuffer());
  }
  document.addEventListener('click', async (event) => {
    const control = event.target.closest?.('.article-presentation .presentation-toggle');
    if (
      !control ||
      event.defaultPrevented ||
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey
    )
      return;
    const section = control.closest('.article-presentation');
    const host = section.querySelector('.presentation-viewer');
    if (!host || !page.startsWith('article:')) return;
    event.preventDefault();
    const closing = slideSession?.control === control;
    closeSlides();
    if (closing) return;
    const session = {
      control,
      host,
      controller: new AbortController(),
      url: null,
    };
    slideSession = session;
    control.setAttribute('aria-busy', 'true');
    control.textContent = 'Loading slides…';
    const timeout = window.setTimeout(() => session.controller.abort(), 8000);
    try {
      await pin(session.controller.signal);
      if (embedded) await verifyEmbeddedAssets();
      const source = new URL(control.href);
      const descriptor = pinned.articles[page.slice(8)];
      const name = embedded
        ? control.getAttribute('data-offline-resource')
        : source.pathname.slice(directory.pathname.length);
      if (
        !descriptor.assets.includes(name) ||
        !name.endsWith('.pdf') ||
        (!embedded &&
          (source.origin !== entry.origin ||
            !source.pathname.startsWith(directory.pathname) ||
            source.search ||
            source.hash))
      )
        throw Error('Undeclared presentation resource');
      const bytes = await slideBytes(source.href, session.controller.signal);
      const digest = await window.crypto.subtle.digest('SHA-256', bytes);
      const hash = [...new Uint8Array(digest)].map((x) => x.toString(16).padStart(2, '0')).join('');
      if (hash !== name.split('/')[1]) throw Error('Presentation PDF identity changed');
      if (slideSession !== session || !control.isConnected) return;
      // A verified local Blob retains the host's frame-denial policy for site pages.
      session.url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
      const viewer = document.createElement('iframe');
      viewer.title = section.querySelector('strong')?.textContent || 'Presentation PDF';
      viewer.src = session.url;
      host.replaceChildren(viewer);
      host.hidden = false;
      control.setAttribute('aria-expanded', 'true');
      control.textContent = 'Close slide viewer';
    } catch {
      if (slideSession === session) {
        closeSlides();
        control.textContent = 'Use Open PDF below';
      }
    } finally {
      window.clearTimeout(timeout);
      if (slideSession === session) control.removeAttribute('aria-busy');
    }
  });
  function routeFor(url) {
    if (url.origin !== entry.origin) return null;
    if (embedded) {
      if (url.pathname === entry.pathname)
        return routes.includes(url.searchParams.get('view')) ||
          (url.searchParams.get('view')?.startsWith('article:') &&
            Object.hasOwn(embedded.pages, url.searchParams.get('view')))
          ? url.searchParams.get('view')
          : document.body.dataset.entryPage;
      return (
        Object.keys(embedded.files).find(
          (name) => new URL(embedded.files[name], directory).pathname === url.pathname
        ) || null
      );
    }
    const article = Object.entries(articles).find(([, descriptor]) =>
      [descriptor.url, descriptor.snapshot].filter(Boolean).some((file) => {
        const path = new URL(file, directory).pathname;
        return (
          path === url.pathname ||
          (file === descriptor.url && path.endsWith('.html') && path.slice(0, -5) === url.pathname)
        );
      })
    );
    if (article) return 'article:' + article[0];
    return (
      routes.find((name) =>
        [name, name + '.html', ...(name === 'index' ? ['./'] : [])].some(
          (file) => new URL(file, directory).pathname === url.pathname
        )
      ) || null
    );
  }
  function address(url, next) {
    if (!embedded) {
      if (!next.startsWith('article:')) return url;
      const result = new URL(articles[next.slice(8)].url, directory);
      result.search = url.search;
      result.hash = url.hash;
      return result;
    }
    const result = new URL(entry);
    result.search = url.search;
    result.hash = url.hash;
    result.searchParams.set('view', next);
    return result;
  }
  // The scroll/flight itinerary follows the header; utility links stay accessible.
  const primaryRoutes = Object.freeze(
    [...document.querySelectorAll('.site-header nav a[href]')]
      .map((link) => routeFor(new URL(link.href, entry)))
      .filter((route, index, list) => route && list.indexOf(route) === index)
  );
  function save(fallbackFocus = null) {
    if (departureUnavailable() || routeFor(new URL(window.location.href)) !== page) return;
    try {
      history.replaceState(
        {
          ...history.state,
          site: {
            page,
            index: historyIndex,
            scroll: [window.scrollX, window.scrollY],
            ...(window.SiteReader?.snapshot?.() ? { reader: window.SiteReader.snapshot() } : {}),
            focus:
              document.activeElement?.id ||
              document.activeElement?.getAttribute?.('href') ||
              fallbackFocus ||
              null,
          },
        },
        '',
        window.location.href
      );
    } catch {
      /* Native navigation still works. */
    }
  }
  function departureUnavailable() {
    return (
      content.inert ||
      content.querySelector('main')?.getAttribute('data-route-blocks') === 'departing'
    );
  }
  function departureFocus() {
    // Retargeting an unmounted flight can leave its departure link blurred by
    // visibility or inert. Keep captured focus unless the reader focused a control.
    return departureUnavailable() &&
      history.state?.site?.page === page &&
      (!document.activeElement || document.activeElement === document.body)
      ? history.state.site.focus
      : undefined;
  }
  function departurePosition() {
    const saved =
      departureUnavailable() && history.state?.site?.page === page
        ? history.state.site.scroll
        : null;
    return [saved?.[0] ?? window.scrollX, saved?.[1] ?? window.scrollY];
  }
  function saveDeparture(destination, pop, initial, fallbackFocus) {
    if (!pop && !initial && destination.href !== window.location.href) save(fallbackFocus);
  }
  function push(url) {
    save();
    history.pushState(
      {
        site: {
          page,
          index: ++historyIndex,
          scroll: [window.scrollX, window.scrollY],
        },
      },
      '',
      url
    );
  }
  function revisionValid(revision) {
    if (
      revision?.schema !== 1 ||
      revision.contract !== 1 ||
      revision.navigation?.contract !== 1 ||
      revision.navigation?.articleRenderer !== 1 ||
      Object.keys(revision.navigation).length !== 2 ||
      revision.engine !== shellEngine ||
      Object.keys(revision.routes || {}).length !== routes.length
    )
      return false;
    for (const route of routes) {
      const data = revision.routes[route];
      if (
        !data ||
        !/^[a-f0-9]{64}$/.test(data.version) ||
        !/^[a-f0-9]{64}$/.test(data.sha256) ||
        data.url !== `snapshots/${data.version}/${route}.html`
      )
        return false;
    }
    const articleRows = revision.articles || {};
    if (Object.keys(articleRows).length > 50) return false;
    const aliases = new Set();
    for (const [key, data] of Object.entries(articleRows)) {
      if (
        !/^[a-z][a-z0-9-]{0,79}:(?:en|uk)$/.test(key) ||
        !data ||
        data.scene !== 'writing' ||
        !/^articles\/[a-z][a-z0-9-]{0,79}\.html$/.test(data.alias) ||
        aliases.has(data.alias) ||
        data.articleId !== key.split(':')[0] ||
        !/^[a-z][a-z0-9-]{0,79}$/.test(data.contentEdition) ||
        !/^[a-f0-9]{64}$/.test(data.sourceSha256) ||
        !/^[a-f0-9]{64}$/.test(data.semanticSha256) ||
        !/^[a-f0-9]{64}$/.test(data.version) ||
        !/^[a-f0-9]{64}$/.test(data.sha256) ||
        data.url !== `article-snapshots/${data.version}/${data.alias.split('/').pop()}` ||
        !Array.isArray(data.assets) ||
        data.assets.length > 50 ||
        new Set(data.assets).size !== data.assets.length ||
        data.assets.some(
          (name) => !/^article-media\/[a-f0-9]{64}\/[a-z0-9][a-z0-9._-]*$/.test(name)
        ) ||
        (data.candidate === true && revision.preview !== true)
      )
        return false;
      aliases.add(data.alias);
    }
    if (embedded) {
      if (Object.keys(articleRows).length !== Object.keys(articles).length) return false;
      for (const [key, data] of Object.entries(articleRows))
        if (articles[key]?.url !== data.alias || articles[key]?.snapshot !== data.url) return false;
    }
    const initial = initialPage.startsWith('article:')
      ? articleRows[initialPage.slice(8)]
      : revision.routes[initialPage];
    return initial?.version === initialVersion;
  }
  async function pin(signal) {
    if (pinned) return;
    let revision = embedded?.revision;
    if (!embedded) {
      const response = await fetch(new URL('site-revision.json', directory), {
        signal,
        credentials: 'same-origin',
        cache: 'no-cache',
      });
      if (
        !response.ok ||
        new URL(response.url).origin !== entry.origin ||
        !response.headers.get('content-type')?.includes('application/json')
      )
        throw Error('Revision unavailable');
      const bytes = await response.text();
      if (new TextEncoder().encode(bytes).byteLength > 32000) throw Error('Revision too large');
      revision = JSON.parse(bytes);
    }
    if (signal?.aborted) throw Error('Revision request cancelled');
    // A completed first gesture owns one immutable registry for this session.
    // A concurrent cancelled request cannot replace a newer pinned revision.
    if (pinned) return;
    if (!revisionValid(revision)) throw Error('Site snapshot changed');
    if (!embedded)
      for (const [key, data] of Object.entries(revision.articles || {}))
        articles[key] = { url: data.alias, snapshot: data.url };
    pinned = revision;
  }
  function articleTarget(url) {
    return (
      !embedded &&
      url.origin === entry.origin &&
      url.pathname.startsWith(directory.pathname) &&
      /^articles\/[a-z][a-z0-9-]{0,79}(?:\.html)?$/.test(
        url.pathname.slice(directory.pathname.length)
      )
    );
  }
  async function matchesBytes(html, hash) {
    if (!window.crypto?.subtle || !window.TextEncoder)
      throw Error('Snapshot verification unavailable');
    const digest = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(html));
    return (
      [...new Uint8Array(digest)].map((x) => x.toString(16).padStart(2, '0')).join('') === hash
    );
  }
  async function verifyEmbeddedAssets() {
    if (!embedded?.assets) return;
    if (!embeddedAssetsReady)
      embeddedAssetsReady = (async () => {
        const entries = Object.entries(embedded.assets);
        if (entries.length > 50 || entries.length !== embeddedAssetURLs.size)
          throw Error('Embedded asset inventory differs');
        for (const [name, asset] of entries) {
          const value = embeddedAssetURLs.get(name);
          const mime = name.endsWith('.pdf')
            ? 'application/pdf'
            : name.endsWith('.webp')
              ? 'image/webp'
              : 'image/png';
          const prefix = 'data:' + mime + ';base64,';
          if (
            !/^article-media\/[a-f0-9]{64}\/[a-z0-9][a-z0-9._-]*\.(?:png|webp|pdf)$/.test(name) ||
            asset.mime !== mime ||
            asset.sha256 !== name.split('/')[1] ||
            !Number.isSafeInteger(asset.bytes) ||
            asset.bytes < 1 ||
            asset.bytes > 2000000 ||
            typeof value !== 'string' ||
            !value.startsWith(prefix) ||
            !/^[A-Za-z0-9+/]*={0,2}$/.test(value.slice(prefix.length)) ||
            value.length > 4 * Math.ceil(asset.bytes / 3) + prefix.length
          )
            throw Error('Invalid embedded article resource');
          const raw = window.atob(value.slice(prefix.length));
          if (raw.length !== asset.bytes) throw Error('Embedded asset byte length differs');
          const bytes = Uint8Array.from(raw, (character) => character.charCodeAt(0));
          const digest = await window.crypto.subtle.digest('SHA-256', bytes);
          const hash = [...new Uint8Array(digest)]
            .map((byte) => byte.toString(16).padStart(2, '0'))
            .join('');
          if (hash !== asset.sha256) throw Error('Embedded article asset bytes changed');
        }
      })();
    await embeddedAssetsReady;
  }
  function hydrateEmbeddedImages(result, descriptor) {
    const used = new Set();
    for (const image of result.main.querySelectorAll(
      'img[src],.reader-image-open[href],.article-presentation a[href],#article-materials a[href]'
    )) {
      const attribute = image.tagName === 'IMG' ? 'src' : 'href';
      const name = image.getAttribute(attribute);
      if (!name.startsWith('article-media/')) continue;
      if (!descriptor.assets.includes(name) || !embeddedAssetURLs.has(name))
        throw Error('Unknown embedded article image');
      image.setAttribute(attribute, embeddedAssetURLs.get(name));
      image.setAttribute('data-offline-resource', name);
      used.add(name);
    }
    if (used.size !== descriptor.assets.length)
      throw Error('Embedded article image closure differs');
  }
  async function read(next, signal) {
    await pin(signal);
    if (embedded && next.startsWith('article:')) await verifyEmbeddedAssets();
    if (cache.has(next)) return cache.get(next);
    let html;
    const descriptor = next.startsWith('article:')
      ? pinned.articles[next.slice(8)]
      : pinned.routes[next];
    const sourceURL = new URL(descriptor.url, directory);
    if (embedded) {
      html = embedded.pages[next];
      if (
        typeof html !== 'string' ||
        (next.startsWith('article:') &&
          (new TextEncoder().encode(html).byteLength > 100000 ||
            !(await matchesBytes(html, descriptor.sha256))))
      )
        throw Error('Embedded document bytes changed');
    } else {
      const response = await fetch(sourceURL, {
        signal,
        credentials: 'same-origin',
      });
      if (
        !response.ok ||
        new URL(response.url).origin !== entry.origin ||
        !response.headers.get('content-type')?.includes('text/html')
      )
        throw Error('Route unavailable');
      html = await response.text();
      if (
        new TextEncoder().encode(html).byteLength > 100000 ||
        !(await matchesBytes(html, descriptor.sha256))
      )
        throw Error('Snapshot bytes changed');
    }
    const result = extract(
      new DOMParser().parseFromString(html, 'text/html'),
      !embedded,
      sourceURL
    );
    if (embedded && next.startsWith('article:')) hydrateEmbeddedImages(result, descriptor);
    if (
      result.page !== next ||
      result.engine !== shellEngine ||
      result.version !== descriptor.version
    )
      throw Error('Unexpected route/version');
    cache.set(next, result);
    const cachedArticles = [...cache.keys()].filter((key) => key.startsWith('article:'));
    if (cachedArticles.length > 10) cache.delete(cachedArticles[0]);
    return result;
  }
  function clearText() {
    content.style.removeProperty('opacity');
    content.style.removeProperty('transform');
    presentation?.clear?.();
    content.inert = false;
  }
  function interrupt() {
    closeSlides();
    scrollEntry?.cancelRoute?.();
    scrollEntry?.suspend();
    const travelling = transition !== null;
    releaseEndpoint('interrupt');
    releaseTail();
    request?.abort();
    request = null;
    transition?.cancel?.();
    window.SiteScene?.detachTravel();
    transition?.(1);
    transition = null;
    clearText();
    content.removeAttribute('aria-busy');
    return travelling;
  }
  function motionAllowed() {
    return (
      !document.hidden &&
      window.SiteScene?.canTravel() === true &&
      (!presentation || presentation.canTravel())
    );
  }
  function restoreScroll(left, top) {
    // Explicit instant behavior ignores the reader's smooth anchor preference
    // without mutating the root style and forcing another style flush.
    const start = window.SiteEngineStages ? performance.now() : 0;
    window.scrollTo({ left, top, behavior: 'instant' });
    if (start) {
      const time = performance.now();
      window.SiteEngineProbe?.({
        kind: 'stage',
        part: 'scroll-native',
        time,
        start,
        duration: time - start,
        page,
      });
    }
  }
  function endpointProbe(reason, detail = {}) {
    window.SiteEngineProbe?.({
      kind: 'endpoint',
      time: performance.now(),
      reason,
      token: endpoint?.own,
      page,
      ...detail,
    });
  }
  function releaseEndpoint(reason) {
    if (endpoint) endpointProbe(reason);
    endpoint = null;
    window.clearTimeout(endpointTimer);
    endpointTimer = null;
    endpointObserver?.disconnect();
    endpointObserver = null;
  }
  function releaseTail() {
    inputTail = null;
  }
  function reconcileEndpoint(maxScroll) {
    if (!endpoint || !endpoint.mounted) return false;
    if (endpoint.own !== serial || endpoint.page !== page) {
      releaseEndpoint('stale');
      return false;
    }
    if (maxScroll === undefined) {
      const read = () =>
        reconcileEndpoint(Math.max(0, document.documentElement.scrollHeight - innerHeight));
      return effects?.measure ? effects.measure(read) : read();
    }
    const gap = maxScroll - window.scrollY;
    if (Math.abs(gap) > 2) {
      restoreScroll(0, maxScroll);
      endpointProbe('reflow', { maxScroll, gap });
    }
    return true;
  }
  function mountEndpoint() {
    if (!endpoint || endpoint.own !== serial || endpoint.page !== page) return;
    endpoint.mounted = true;
    // The scene's native measurement invokes reconcileEndpoint before reading
    // waypoints. Only a missing Canvas/layout engine needs a bounded observer.
    if (!window.SiteScene?.managesLayout && window.ResizeObserver) {
      endpointObserver = new ResizeObserver(() => reconcileEndpoint());
      endpointObserver.observe(document.body);
    }
  }
  function arriveEndpoint() {
    if (!endpoint || endpoint.own !== serial) return;
    endpoint.arrived = true;
    window.SiteScene?.refresh({ sync: true, reason: 'arrival-end' });
    reconcileEndpoint();
    // Expiry bounds takeover, it never drives correctness or a render clock.
    const own = endpoint.own;
    endpointTimer = window.setTimeout(() => {
      if (endpoint?.own === own) releaseEndpoint('settled');
    }, 1000);
  }
  window.addEventListener(
    'wheel',
    (event) => {
      // Use input creation time, not delayed main-thread dispatch time. A slow
      // mount cannot turn queued inertia into a supposedly fresh wheel gesture.
      const now =
          event.timeStamp > performance.timeOrigin
            ? event.timeStamp - performance.timeOrigin
            : event.timeStamp,
        direction = Math.sign(event.deltaY);
      const fresh =
        now - lastWheel > 180 ||
        (direction && lastWheelDirection && direction !== lastWheelDirection);
      lastWheel = now;
      if (direction) lastWheelDirection = direction;
      if (!event.isTrusted || !event.deltaY) return;
      if (fresh) {
        releaseEndpoint('wheel');
        releaseTail();
      } else if (
        inputTail?.own === serial &&
        inputTail.type === 'wheel' &&
        !event.ctrlKey &&
        !event.metaKey &&
        !event.altKey &&
        !event.shiftKey &&
        Math.abs(event.deltaY) >= Math.abs(event.deltaX)
      ) {
        // Consume only the accepted gesture's tail. It must not scroll an instant
        // destination before the reader starts a new deliberate gesture.
        if (event.cancelable) event.preventDefault();
      }
    },
    { passive: false }
  );
  window.addEventListener(
    'touchstart',
    (event) => {
      if (event.isTrusted) {
        releaseEndpoint('touch');
        releaseTail();
      }
    },
    { passive: true }
  );
  window.addEventListener(
    'pointerdown',
    (event) => {
      if (event.isTrusted) {
        releaseEndpoint('pointer');
        releaseTail();
      }
    },
    { passive: true }
  );
  window.addEventListener('keydown', (event) => {
    const scrolling = ['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' '].includes(
      event.key
    );
    if (scrolling && !event.repeat) lastKey = event.key;
    if (!event.isTrusted) return;
    if (
      inputTail?.own === serial &&
      inputTail.type === 'key' &&
      event.repeat &&
      event.key === inputTail.key
    ) {
      if (event.cancelable) event.preventDefault();
      return;
    }
    if (scrolling && !event.repeat) {
      releaseEndpoint('key');
      releaseTail();
    }
  });
  window.addEventListener('keyup', (event) => {
    if (inputTail?.type === 'key' && event.key === inputTail.key) releaseTail();
  });
  window.addEventListener('blur', () => {
    releaseEndpoint('blur');
    releaseTail();
  });
  window.addEventListener(
    'resize',
    () => {
      if (!window.SiteScene?.managesLayout) reconcileEndpoint();
    },
    { passive: true }
  );
  document.fonts?.addEventListener?.('loadingdone', () => {
    if (!window.SiteScene?.managesLayout) reconcileEndpoint();
  });
  function flight(next, animate, commit, own, departure, landing = null, documentTravel = null) {
    return new Promise((resolve, reject) => {
      let mounted = false,
        mountTimer = null,
        settled = false,
        lastProgress = 0;
      const mountAt = 0.5;
      const cancelTask = () => {
        if (mountTimer !== null) window.clearTimeout(mountTimer);
        mountTimer = null;
      };
      const cancel = () => {
        if (settled) return;
        settled = true;
        cancelTask();
        if (transition === update) transition = null;
        resolve();
      };
      const fail = (error) => {
        if (settled) return;
        settled = true;
        cancelTask();
        if (transition === update) {
          window.SiteScene?.detachTravel();
          transition = null;
        }
        reject(error);
      };
      function mountNow(task = false) {
        cancelTask();
        if (settled || own !== serial) {
          cancel();
          return;
        }
        if (mounted) return;
        const start = task && window.SiteEngineProbe ? performance.now() : 0;
        try {
          mounted = true;
          commit();
        } finally {
          if (start) {
            const time = performance.now();
            window.SiteEngineProbe?.({
              kind: 'navigation-task',
              part: 'mount-task',
              time,
              start,
              duration: time - start,
              page: next,
            });
          }
        }
      }
      function queueMount() {
        if (mountTimer !== null) return;
        // Outgoing blocks have already left. Yield the completed Canvas paint
        // before native archive construction/layout; the new blocks stay held
        // offscreen until the camera restores its destination reading framing.
        mountTimer = window.setTimeout(() => {
          mountTimer = null;
          if (settled || own !== serial) {
            cancel();
            return;
          }
          try {
            mountNow(true);
            if (!settled) update(lastProgress);
          } catch (error) {
            fail(error);
          }
        }, 0);
      }
      function finish() {
        clearText();
        settled = true;
        cancelTask();
        if (transition === update) transition = null;
        resolve();
      }
      const update = (progress) => {
        if (settled) return;
        if (own !== serial) {
          cancel();
          return;
        }
        try {
          lastProgress = progress;
          if (progress >= mountAt && !mounted) {
            if (animate && progress < 1) queueMount();
            else mountNow(mountTimer !== null);
          }
          if (settled || own !== serial) {
            cancel();
            return;
          }
          // Presentation metadata follows the existing scene clock. Native
          // content has no root opacity/depth transform during camera travel.
          if (progress === 1) finish();
          else presentation?.present?.(progress);
        } catch (error) {
          fail(error);
        }
      };
      update.cancel = cancel;
      transition = update;
      content.inert = true;
      if (window.SiteScene)
        window.SiteScene.navigate(next, animate, transition, landing, {
          navigationId: own,
          ...documentTravel,
        });
      else transition(1);
    });
  }
  function mount(data, url, position, blockDirection = null, navigationId = serial) {
    // History captured the old reading position before this layout-affecting
    // write. Clearing the plane before history's scroll read would flush the
    // old page, then immediately flush the newly mounted archive again.
    presentation?.prepareMount?.();
    // Clear the presentation transform before DOM writes and landing. The
    // nested scene measurement then reuses that same native layout snapshot.
    const run = () => mountNative(data, url, position, blockDirection, navigationId);
    return effects?.measure ? effects.measure(run) : run();
  }
  function mountNative(data, url, position, blockDirection = null, navigationId = serial) {
    let stage = window.SiteEngineStages ? performance.now() : 0;
    const span = (part) => {
      if (stage) {
        const time = performance.now();
        window.SiteEngineProbe?.({
          kind: 'stage',
          part,
          time,
          start: stage,
          duration: time - stage,
          page: data.page,
        });
        stage = time;
      }
    };
    window.SiteArchive?.destroy();
    window.SiteReader?.destroy();
    scrollEntry?.destroy();
    span('mount-unmount');
    if (blockDirection) {
      data.main.setAttribute('data-route-blocks', 'holding');
      data.footer.setAttribute('data-route-blocks', 'holding');
    }
    rebaseResources(data, url);
    content.replaceChildren(data.main, data.footer);
    document.body.dataset.page = data.scene || data.page;
    if (data.article) document.body.dataset.article = data.article;
    else delete document.body.dataset.article;
    page = data.page;
    if (document.documentElement.lang !== data.lang) document.documentElement.lang = data.lang;
    document.title = data.title;
    for (const node of document.head.querySelectorAll(metadata)) node.remove();
    document.head.append(...data.metadata);
    const fallback = document.querySelector('.space-fallback');
    if (fallback) fallback.replaceWith(data.fallback);
    for (const link of document.querySelectorAll('.site-header a')) {
      const target = headerURLs.get(link) || new URL(link.href, window.location.href);
      if (target.origin === entry.origin && target.pathname.startsWith(directory.pathname)) {
        const depth = url.pathname.slice(directory.pathname.length).split('/').length - 1;
        const relative =
          '../'.repeat(Math.max(0, depth)) + target.pathname.slice(directory.pathname.length);
        link.setAttribute('href', (relative || './') + target.search + target.hash);
      }
      if (routeFor(target) === (data.scene || page)) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    }
    span('mount-dom');
    window.dispatchEvent(new CustomEvent('site:page-mount', { detail: { page } }));
    // Apply filters before the native scroll/style flush, so Writing does not
    // lay out the complete archive and immediately lay it out a second time.
    window.SiteArchive?.mount();
    window.SiteReader?.mount({ state: history.state?.site?.reader });
    span('mount-archive');
    if (position === 'end') mountEndpoint();
    if (position === 'end')
      restoreScroll(0, Math.max(0, document.documentElement.scrollHeight - innerHeight));
    else restoreScroll(position?.[0] || 0, position?.[1] || 0);
    span('mount-scroll');
    let target = null;
    try {
      target = url.hash ? document.getElementById(decodeURIComponent(url.hash.slice(1))) : null;
    } catch {
      /* Invalid fragments do not block a page. */
    }
    if (!position && target && target.getClientRects().length)
      target.scrollIntoView({ block: 'start', behavior: 'instant' });
    span('mount-anchor');
    window.SiteScene?.refresh({ sync: true });
    span('mount-layout');
    window.dispatchEvent(new CustomEvent('site:page-ready', { detail: { page } }));
    scrollEntry?.mount(data.main, { footer: data.footer });
    if (blockDirection) scrollEntry?.prepareArrival?.(blockDirection, navigationId);
    span('mount-ready');
  }
  function prepare(data) {
    const start = window.SiteEngineProbe ? performance.now() : 0;
    const clone = (node) => document.importNode(node, true);
    const result = {
      ...data,
      main: clone(data.main),
      footer: clone(data.footer),
      fallback: clone(data.fallback),
      metadata: data.metadata.map(clone),
    };
    if (window.SiteEngineProbe)
      window.SiteEngineProbe({
        kind: 'route',
        time: performance.now(),
        start,
        duration: performance.now() - start,
        page: data.page,
      });
    return result;
  }
  function documentDirection(next, nextScene, currentScene, pop, targetIndex) {
    if (nextScene !== currentScene)
      return routes.indexOf(nextScene) > routes.indexOf(currentScene) ? 1 : -1;
    if (pop && targetIndex !== null && targetIndex !== historyIndex)
      return Math.sign(targetIndex - historyIndex);
    return next === 'writing' ? -1 : 1;
  }
  function contentDirections(fromDocument, next, direction) {
    // Hierarchy controls the block wave independently of camera/history travel.
    return {
      departureDirection: fromDocument.startsWith('article:') ? 1 : direction,
      arrivalDirection: next.startsWith('article:') ? 1 : direction,
    };
  }
  function restoreReadingFocus(pop) {
    const savedFocus = pop ? history.state?.site?.focus : null;
    const focused = savedFocus
      ? document.getElementById(savedFocus) ||
        [...content.querySelectorAll('a[href]')].find(
          (link) => link.getAttribute('href') === savedFocus || link.href === savedFocus
        )
      : null;
    (focused || content.querySelector('main')).focus({
      preventScroll: true,
    });
  }
  async function navigate(
    url,
    { pop = false, position = null, initial = false, input = null } = {}
  ) {
    let next = routeFor(url);
    if (!navigableDestination(url, next)) return;
    const nextScene = routes.includes(next) ? next : 'writing';
    const currentScene = routes.includes(page) ? page : 'writing';
    const targetIndex =
      pop && Number.isSafeInteger(history.state?.site?.index) ? history.state.site.index : null;
    const direction = documentDirection(next, nextScene, currentScene, pop, targetIndex);
    const fromDocument = page;
    const interruptedFocus = departureFocus();
    const interruptedPosition = departurePosition();
    const own = ++serial;
    interrupt();
    if (position === 'end') endpoint = { own, page: next, mounted: false, arrived: false };
    if (input === 'wheel' || input === 'key') {
      inputTail = { own, type: input, key: lastKey };
    }
    window.SiteEngineProbe?.({
      kind: 'navigation-start',
      time: performance.now(),
      from: page,
      to: next,
      navigationId: own,
    });
    const controller = new AbortController();
    request = controller;
    const timeout = window.setTimeout(() => controller.abort(), 8000);
    content.setAttribute('aria-busy', 'true');
    try {
      // Stop a native smooth focus/anchor scroll inherited from activation.
      // Fresh reading input during the asynchronous read still reaches saveDeparture.
      restoreScroll(interruptedPosition[0], interruptedPosition[1]);
      next = await admittedDestination(url, next, controller.signal);
      // Admission resolves article aliases absent from a principal page's boot registry.
      const { departureDirection, arrivalDirection } = contentDirections(
        fromDocument,
        next,
        direction
      );
      const data = await read(next, controller.signal);
      if (own !== serial) return;
      const prepared = prepare(data);
      const destination = address(url, next);
      // Departure visibility and inert can both blur native links. Capture
      // reading state before either owner makes the outgoing content inaccessible.
      saveDeparture(destination, pop, initial, interruptedFocus);
      let animate = !initial && next !== page && motionAllowed();
      let blocks = animate && (presentation?.contentFlight?.() ?? true);
      if (blocks) {
        const result = await scrollEntry?.depart?.(departureDirection, own);
        blocks = result?.completed === true;
      }
      animate = animate && motionAllowed();
      if (own !== serial) return;
      await flight(
        nextScene,
        animate,
        () => {
          const start = window.SiteEngineStages ? performance.now() : 0;
          if (!pop && !initial && destination.href !== window.location.href) {
            history.pushState(
              { site: { page: next, index: ++historyIndex, scroll: [0, 0] } },
              '',
              destination
            );
          } else if (initial)
            history.replaceState(
              { site: { page: next, index: historyIndex, scroll: [0, 0] } },
              '',
              destination
            );
          else if (pop && targetIndex !== null) historyIndex = targetIndex;
          if (start) {
            const time = performance.now();
            window.SiteEngineProbe?.({
              kind: 'stage',
              part: 'mount-history',
              time,
              start,
              duration: time - start,
              page: next,
            });
          }
          mount(prepared, destination, position, blocks ? arrivalDirection : null, own);
        },
        own,
        null,
        { position, hash: url.hash, search: url.search },
        {
          documentChange: next !== fromDocument,
          sameSceneDocument: nextScene === currentScene && nextScene === 'writing',
          fromDocument,
          toDocument: next,
          direction,
        }
      );
      if (own !== serial) return;
      if (blocks && motionAllowed() && (presentation?.contentFlight?.() ?? true))
        await scrollEntry?.arrive?.(arrivalDirection, own);
      else scrollEntry?.cancelRoute?.();
      if (own === serial) {
        arriveEndpoint();
        restoreReadingFocus(pop);
        scrollEntry?.resume();
        announcement.textContent = data.title;
        save();
        window.SiteEngineProbe?.({
          kind: 'navigation-ready',
          time: performance.now(),
          page: next,
          navigationId: own,
        });
      }
    } catch {
      if (own === serial) {
        releaseEndpoint('failed');
        scrollEntry?.cancelRoute?.();
        scrollEntry?.settle();
        releaseTail();
        window.location.assign(nativeDestination(url, next));
      }
    } finally {
      window.clearTimeout(timeout);
      if (own === serial) {
        content.removeAttribute('aria-busy');
        request = null;
        scrollEntry?.cancelRoute?.();
        clearText();
      }
    }
  }
  function navigableDestination(url, next) {
    return next || articleTarget(url);
  }
  async function admittedDestination(url, next, signal) {
    if (next) return next;
    await pin(signal);
    const admitted = routeFor(url);
    if (!admitted) throw Error('Article is absent from the pinned revision');
    return admitted;
  }
  function nativeDestination(url, next) {
    return next ? address(url, next).href : url.href;
  }
  document.body.dataset.entryPage = page;
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  document.addEventListener('click', (event) => {
    const link = event.target.closest?.('a[href]');
    if (
      event.defaultPrevented ||
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey ||
      !link ||
      link.hasAttribute('download') ||
      (link.target && link.target !== '_self')
    )
      return;
    const url = new URL(link.href, window.location.href),
      next = routeFor(url);
    if (!navigableDestination(url, next)) return;
    if (next === page && request) {
      event.preventDefault();
      navigate(url);
      return;
    }
    if (next === page) {
      ++serial;
      if (interrupt()) window.SiteScene?.navigate(page, motionAllowed());
      if (link.getAttribute('href').startsWith('#')) {
        scrollEntry?.resume();
        return;
      }
      event.preventDefault();
      const dest = address(url, next);
      if (dest.href !== window.location.href) push(dest);
      window.dispatchEvent(new PopStateEvent('popstate', { state: history.state }));
      if (dest.hash)
        document.getElementById(dest.hash.slice(1))?.scrollIntoView({ behavior: 'instant' });
      else restoreScroll(0, 0);
      scrollEntry?.resume();
      return;
    }
    event.preventDefault();
    navigate(url);
  });
  window.addEventListener('popstate', (event) => {
    const url = new URL(window.location.href),
      next = routeFor(url);
    if (next && (next !== page || request))
      navigate(url, { pop: true, position: event.state?.site?.scroll || null });
    else {
      if (Number.isSafeInteger(event.state?.site?.index)) historyIndex = event.state.site.index;
      ++serial;
      if (interrupt()) window.SiteScene?.navigate(page, motionAllowed());
      window.SiteReader?.restore(event.state?.site?.reader);
      if (event.state?.site?.scroll)
        restoreScroll(event.state.site.scroll[0], event.state.site.scroll[1]);
      scrollEntry?.resume();
    }
  });
  window.addEventListener('site:reader-state', () => save());
  function finishText() {
    scrollEntry?.cancelRoute?.();
    window.SiteScene?.detachTravel();
    transition?.(1);
    transition = null;
    clearText();
  }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) finishText();
  });
  window.addEventListener('beforeprint', () => {
    releaseEndpoint('print');
    releaseTail();
    finishText();
    window.SiteArchive?.print();
  });
  window.addEventListener('pagehide', () => {
    closeSlides();
    save();
    releaseEndpoint('leave');
    releaseTail();
  });
  // One write after a gesture preserves Forward as well as Back without
  // flooding history APIs or adding an idle timer / another RAF scheduler.
  window.addEventListener(
    'scroll',
    () => {
      window.clearTimeout(scrollSave);
      scrollSave = window.setTimeout(() => {
        scrollSave = null;
        save();
      }, 350);
    },
    { passive: true }
  );
  window.addEventListener('site:motion-preference', () => {
    if (!motionAllowed()) finishText();
  });
  window.SiteNavigation = {
    push,
    primaryRoutes,
    reconcileEndpoint,
    contentFlight(value) {
      const enabled = presentation?.contentFlight?.(value) ?? true;
      if (typeof value === 'boolean') scrollEntry?.refreshPreference?.();
      return enabled;
    },
    go(next, { atEnd = false, input = null } = {}) {
      if (
        next === page ||
        !primaryRoutes.includes(page) ||
        !primaryRoutes.includes(next) ||
        request ||
        transition
      )
        return false;
      navigate(
        new URL(embedded?.files[next] || (next === 'index' ? './' : next + '.html'), directory),
        { position: atEnd ? 'end' : null, input }
      );
      return true;
    },
  };
  const first = embedded ? routeFor(new URL(window.location.href)) : page;
  if (first !== page) navigate(new URL(window.location.href), { initial: true });
  else save();
})();

(function installFlightPreference() {
  function mount() {
    const controls = document.querySelector('.display-controls');
    if (!controls || !window.SiteNavigation?.contentFlight) return;
    const label = document.createElement('label');
    label.className = 'theme-control end-scroll-control';
    label.textContent = 'Block transitions ';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.id = 'content-flight';
    input.checked = window.SiteNavigation.contentFlight();
    input.setAttribute('aria-label', 'Block transitions');
    label.append(input);
    controls.append(label);
    input.addEventListener('change', () => {
      window.SiteNavigation.contentFlight(input.checked);
    });
  }
  if (document.readyState === 'loading')
    document.addEventListener('DOMContentLoaded', mount, { once: true });
  else mount();
})();(function installEndScroll(gateFactory, isEnd, isStart) {
  function mount() {
    const content = document.getElementById('site-content'),
      controls = document.querySelector('.display-controls');
    if (
      !content ||
      !controls ||
      !window.SiteNavigation?.go ||
      document.getElementById('end-scroll')
    )
      return;
    const routes = window.SiteNavigation.primaryRoutes,
      names = ['Home', 'Research', 'Writing', 'Talks'];
    const gate = gateFactory(),
      clock = () => performance.now();
    let enabled = true,
      printing = false,
      touch = null,
      hint = null;
    try {
      enabled = localStorage.getItem('vo.end-scroll') !== 'off';
    } catch {
      /* Works within this tab. */
    }
    const label = document.createElement('label');
    label.className = 'theme-control end-scroll-control';
    label.textContent = 'Scroll between pages ';
    const input = document.createElement('input');
    input.id = 'end-scroll';
    input.type = 'checkbox';
    input.checked = enabled;
    input.setAttribute('aria-label', 'Scroll between pages');
    input.title = 'Continue scrolling at the top or bottom to change section.';
    label.append(input);
    controls.append(label);
    function neighbor(direction) {
      const index = routes.indexOf(document.body.dataset.page);
      return index >= 0 ? routes[index + direction] || null : null;
    }
    function bounds() {
      return {
        top: isStart(scrollY),
        bottom: isEnd(scrollY, document.documentElement.scrollHeight, innerHeight),
      };
    }
    function available(direction = 0) {
      return (
        enabled &&
        !document.body.dataset.article &&
        !!(direction ? neighbor(direction) : neighbor(1) || neighbor(-1)) &&
        !printing &&
        !document.hidden &&
        !content.hasAttribute('aria-busy') &&
        !document.querySelector('.appearance')?.open
      );
    }
    function updateHint() {
      const footer = content.querySelector('footer'),
        route = neighbor(1);
      if (!footer) return;
      hint = footer.querySelector('.scroll-continue');
      if (!route || document.body.dataset.article) {
        hint?.remove();
        hint = null;
        return;
      }
      if (!hint) {
        hint = document.createElement('a');
        hint.className = 'scroll-continue';
        footer.append(hint);
      }
      hint.href = '?view=' + route;
      hint.textContent = 'Keep scrolling for ' + names[routes.indexOf(route)] + ' ↓';
      hint.hidden = !enabled;
    }
    function clear() {
      gate.reset(clock());
      hint?.style.removeProperty('--scroll-intent');
    }
    function discard() {
      touch?.release();
      touch = null;
      clear();
    }
    function routeReady() {
      updateHint();
      if (!touch?.consumed) {
        touch?.release();
        touch = null;
      }
      clear();
      const edge = bounds();
      gate.boundary(edge.bottom, clock(), edge.top);
    }
    function ignored(target) {
      if (
        !(target instanceof Element) ||
        target.closest(
          'input,textarea,select,button,[contenteditable="true"],.appearance,[role="dialog"]'
        )
      )
        return true;
      for (let el = target; el && el !== document.body; el = el.parentElement) {
        if (
          el.scrollHeight > el.clientHeight + 2 &&
          /^(auto|scroll|overlay)$/.test(getComputedStyle(el).overflowY)
        )
          return true;
      }
      return false;
    }
    function offer(type, delta, deliberate = false) {
      const direction = Math.sign(delta);
      if (!direction || !available(direction)) {
        clear();
        return false;
      }
      const accepted = gate.offer({ type, delta, deliberate, ...bounds(), now: clock() });
      hint?.style.setProperty('--scroll-intent', String(direction > 0 ? gate.progress() : 0));
      if (accepted) {
        const route = neighbor(direction);
        if (type === 'touch' && touch) touch.consumed = true;
        clear();
        return route
          ? window.SiteNavigation.go(route, { atEnd: direction < 0, input: type })
          : false;
      }
      return false;
    }
    input.addEventListener('change', () => {
      enabled = input.checked;
      try {
        localStorage.setItem('vo.end-scroll', enabled ? 'on' : 'off');
      } catch {
        /* In-tab preference is enough. */
      }
      routeReady();
    });
    window.addEventListener(
      'wheel',
      (event) => {
        if (
          event.defaultPrevented ||
          event.ctrlKey ||
          event.metaKey ||
          event.altKey ||
          event.shiftKey ||
          Math.abs(event.deltaX) > Math.abs(event.deltaY) ||
          ignored(event.target)
        )
          return;
        const pixels =
          event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? innerHeight : 1);
        if (offer('wheel', pixels) && event.cancelable) event.preventDefault();
      },
      { passive: false }
    );
    window.addEventListener(
      'scroll',
      () => {
        const edge = bounds();
        gate.boundary(edge.bottom, clock(), edge.top);
        if (!edge.bottom) hint?.style.removeProperty('--scroll-intent');
      },
      { passive: true }
    );
    window.addEventListener(
      'touchstart',
      (event) => {
        touch?.release();
        touch = null;
        if (event.touches.length !== 1 || ignored(event.target) || !available()) return;
        const point = event.touches[0],
          target = event.target,
          gesture = {
            id: point.identifier,
            x: point.clientX,
            y: point.clientY,
            started: bounds(),
            consumed: false,
          };
        // Touch events keep their original target after its route DOM is removed;
        // they then stop bubbling to window. Retain only this gesture's listeners
        // so its accepted tail cannot scroll the instantaneous destination.
        const consume = (event) => {
          if (gesture.consumed && event.cancelable) event.preventDefault();
        };
        const release = () => {
          target.removeEventListener('touchmove', consume);
          target.removeEventListener('touchend', release);
          target.removeEventListener('touchcancel', release);
          if (touch === gesture) touch = null;
        };
        gesture.release = release;
        target.addEventListener('touchmove', consume, { passive: false });
        target.addEventListener('touchend', release, { passive: true });
        target.addEventListener('touchcancel', release, { passive: true });
        touch = gesture;
      },
      { passive: true }
    );
    window.addEventListener(
      'touchmove',
      (event) => {
        if (!touch) return;
        if (event.touches.length !== 1) {
          touch.release();
          return;
        }
        if (touch.consumed) {
          if (event.cancelable) event.preventDefault();
          return;
        }
        const point = [...event.touches].find((p) => p.identifier === touch.id);
        if (!point) {
          touch.release();
          return;
        }
        const dy = touch.y - point.clientY,
          dx = touch.x - point.clientX;
        touch.y = point.clientY;
        touch.x = point.clientX;
        const edge = dy < 0 ? 'top' : 'bottom';
        if (touch.started[edge] && bounds()[edge] && Math.abs(dy) > Math.abs(dx)) {
          // Consume only continuation beyond the actual edge. Otherwise an instant
          // route change transfers this same gesture's default scroll to its page.
          if (available(Math.sign(dy)) && event.cancelable) event.preventDefault();
          offer('touch', dy, true);
        }
      },
      { passive: false }
    );
    for (const name of ['touchend', 'touchcancel'])
      window.addEventListener(
        name,
        () => {
          touch?.release();
          touch = null;
        },
        { passive: true }
      );
    window.addEventListener('keydown', (event) => {
      if (
        event.defaultPrevented ||
        event.repeat ||
        event.ctrlKey ||
        event.metaKey ||
        event.altKey ||
        (event.shiftKey && event.key !== ' ') ||
        ignored(event.target) ||
        event.target.closest('a,[role="button"]')
      )
        return;
      const direction =
        ['PageUp', 'ArrowUp'].includes(event.key) || (event.key === ' ' && event.shiftKey)
          ? -1
          : ['PageDown', 'ArrowDown', ' '].includes(event.key)
            ? 1
            : 0;
      if (direction) {
        if (offer('key', direction * (event.key.startsWith('Arrow') ? 40 : 160), true))
          event.preventDefault();
      } else if (['Home', 'End'].includes(event.key)) clear();
    });
    window.addEventListener('site:page-ready', routeReady);
    window.addEventListener('site:page-mount', updateHint);
    if (window.MutationObserver)
      new window.MutationObserver(() => {
        if (!content.hasAttribute('aria-busy')) routeReady();
      }).observe(content, { attributes: true, attributeFilter: ['aria-busy'] });
    window.addEventListener('beforeprint', () => {
      printing = true;
      discard();
    });
    window.addEventListener('afterprint', () => {
      printing = false;
      routeReady();
    });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) discard();
      else routeReady();
    });
    window.addEventListener(
      'resize',
      () => {
        discard();
        const edge = bounds();
        gate.boundary(edge.bottom, clock(), edge.top);
      },
      { passive: true }
    );
    routeReady();
  }
  if (document.readyState === 'loading')
    document.addEventListener('DOMContentLoaded', mount, { once: true });
  else mount();
})(function endScrollGate() {
  let edges = { top: null, bottom: null },
    selected = null,
    ready = 0,
    last = -Infinity,
    total = 0,
    kind = null,
    wheelIntent = false,
    progress = 0;
  function intent() {
    total = 0;
    wheelIntent = false;
    progress = 0;
  }
  function reset(now = 0) {
    edges = { top: null, bottom: null };
    selected = null;
    ready = Math.max(ready, now + 700);
    last = -Infinity;
    kind = null;
    intent();
  }
  function boundary(bottom, now, top = false) {
    for (const [name, at] of [
      ['top', top],
      ['bottom', bottom],
    ]) {
      if (!at) {
        edges[name] = null;
        if (selected === name) intent();
      } else if (edges[name] === null) edges[name] = now;
    }
  }
  function offer(input) {
    const { bottom, top = false, now, delta, type } = input;
    boundary(bottom, now, top);
    const edge = delta < 0 ? 'top' : delta > 0 ? 'bottom' : null;
    if (!edge || edges[edge] === null || now < ready) {
      intent();
      last = now;
      return false;
    }
    if (type !== kind || edge !== selected || now - last > 900) intent();
    selected = edge;
    if (type === 'wheel' && now - last > 180 && now - edges[edge] >= 180) wheelIntent = true;
    const eligible = type === 'wheel' ? wheelIntent : input.deliberate === true;
    kind = type;
    last = now;
    if (!eligible) return false;
    const limit = type === 'touch' ? 84 : 160;
    total += Math.min(limit, Math.abs(delta));
    progress = Math.min(1, total / limit);
    if (total < limit) return false;
    reset(now);
    ready = now + 1000;
    return true;
  }
  reset();
  return { reset, boundary, offer, progress: () => progress };
},function atPageEnd(top, scrollHeight, height) {
  const max = Math.max(0, scrollHeight - height),
    clamped = Math.max(0, Math.min(max, top));
  return max - clamped <= 2;
},function atPageStart(top) {
  return Math.max(0, top) <= 2;
});
