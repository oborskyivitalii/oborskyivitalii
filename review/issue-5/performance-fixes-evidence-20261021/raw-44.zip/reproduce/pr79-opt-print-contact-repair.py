from pathlib import Path
import fitz,json,hashlib
from PIL import Image,ImageDraw
out=Path('/workspace/scratch/38e8b0c92238/pr79-opt-final-functional');pdf=out/'cold-native-print.pdf';doc=fitz.open(pdf);cols=5;tw,th=200,285;rows=(len(doc)+4)//5
contact=Image.new('RGB',(cols*tw,rows*(th+24)),(215,215,215));draw=ImageDraw.Draw(contact)
for i,page in enumerate(doc):
 pix=page.get_pixmap(matrix=fitz.Matrix(.35,.35),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((tw-8,th-8));x=(i%cols)*tw+(tw-im.width)//2;y=(i//cols)*(th+24);contact.paste(im,(x,y+20));draw.text(((i%cols)*tw+8,y+3),str(i+1),fill=(0,0,0))
p=out/'print-contact-verified.jpg';contact.save(p,format='JPEG',quality=85,optimize=True);Image.open(p).verify()
r=json.loads((out/'print-inspection.json').read_text());r['contactSheet']='print-contact-verified.jpg';r['auxiliaryContactIssue']={'file':'print-contact.png','bytes':(out/'print-contact.png').stat().st_size,'error':'PNG incomplete IDAT checksum observed during visual QA; native PDF unchanged. Regenerated verified JPEG contact from the same26 PDF pages.'};r['contactSha256']=hashlib.sha256(p.read_bytes()).hexdigest();(out/'print-inspection.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'pages':len(doc),'repairedPDF':doc.is_repaired,'contactBytes':p.stat().st_size,'contactSHA256':r['contactSha256']}))
