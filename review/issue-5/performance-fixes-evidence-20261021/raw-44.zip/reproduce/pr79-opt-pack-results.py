from pathlib import Path
import json,hashlib,zipfile,zlib,datetime,subprocess
base=Path('/workspace/scratch/38e8b0c92238');root=base/'pr79-opt';dest=base/'pr79-opt-evidence-prepared';dest.mkdir(exist_ok=True)
q='1940cf4442a82a55c31a04d32d73c4e4c3faa596';tree='6ffc7865f7a38683e488b53d3b07badcc50e636f'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==q
assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
assert (base/'pr79-opt-final-performance/execution.json').exists()
assert 'finishedAt' in json.loads((base/'pr79-opt-final-performance/execution.json').read_text())
files={}
def add(path,name):
 path=Path(path)
 assert path.is_file(),str(path)
 assert name not in files,name
 files[name]=path
for dirname in ['pr79-opt-final-performance','pr79-opt-final-source-checks','pr79-opt-final-artifact','pr79-opt-final-build','pr79-opt-final-article-journey','pr79-opt-final-functional','pr79-opt-final-functional-execution','pr79-opt-q1-source-checks','pr79-opt-q2-source-checks','pr79-opt-preflight-browser','pr79-opt-preflight-browser2']:
 folder=base/dirname
 for p in sorted(folder.rglob('*')):
  if p.is_file(): add(p,dirname.removeprefix('pr79-opt-')+'/'+p.relative_to(folder).as_posix())
for dirname in ['pr79-opt-q1-build','pr79-opt-q2-build']:
 for p in sorted((base/dirname).rglob('*')):
  if p.is_file():add(p,dirname.removeprefix('pr79-opt-')+'/'+p.relative_to(base/dirname).as_posix())
for dirname in ['pr79-opt-q1-artifact','pr79-opt-q2-artifact','pr79-opt-prepared-artifact']:
 for name in ['artifact.json','sizes.json','rights.json']:
  p=base/dirname/name
  if p.is_file():add(p,dirname.removeprefix('pr79-opt-')+'/'+name)
for pattern in ['pr79-opt-*.log','pr79-opt-freeze*.json','pr79-opt-historical*.json','pr79-opt-registry-derived.json','pr79-opt-*.py','pr79-opt-*.cjs']:
 for p in sorted(base.glob(pattern)):
  if p.name=='pr79-opt-pack-results.py':continue
  name='reproduce/'+p.name if p.suffix in ['.py','.cjs'] else 'preparation/'+p.name
  if name not in files:add(p,name)
add(Path('/tmp/pr79-opt-browser-smoke.cjs'),'reproduce/reader-loading-functional.cjs')
add(Path(__file__),'reproduce/pack-results.py')
# Exact versioned owners, retained beside the native source commits for offline checks.
for name in ['tools/quality/performance.cjs','tools/quality/lighthouse.cjs','tools/quality/motion.cjs','tools/quality/reader-performance.cjs','tools/quality/validate.cjs','tools/quality/budgets.json','tools/quality/color-motion-contract.cjs','tools/quality/article-browser.cjs','tools/site/reader.cjs','tools/staging/package.cjs']:
 add(root/name,'source/'+name)
manifest={'schema':1,'sourceCommit':q,'sourceTree':tree,'priorEvidenceCommit':'aade77a24d60987d272a2d8f46118d14b3b04c9b','archives':[],'members':[],'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
index=0;archive=None;estimated=0;MAX=3500000
for name,p in sorted(files.items()):
 data=p.read_bytes(); compressed=zlib.compress(data,9); estimate=len(compressed)+len(name.encode())*2+180
 if archive is None or estimated+estimate>MAX:
  if archive:archive.close()
  index+=1; archive=zipfile.ZipFile(dest/f'raw-{index:02d}.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9);estimated=22
 info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
 archive.writestr(info,data,compresslevel=9);estimated+=estimate
 manifest['members'].append({'path':name,'archive':f'raw-{index:02d}.zip','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
if archive:archive.close()
for p in sorted(dest.glob('raw-*.zip')):
 b=p.read_bytes();assert len(b)<=MAX,(p,len(b));manifest['archives'].append({'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  expected=[x for x in manifest['members'] if x['archive']==p.name];assert z.namelist()==[x['path'] for x in expected]
  for row in expected:
   b=z.read(row['path']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archives':len(manifest['archives']),'members':len(manifest['members']),'compressedBytes':sum(x['bytes'] for x in manifest['archives'])}))
