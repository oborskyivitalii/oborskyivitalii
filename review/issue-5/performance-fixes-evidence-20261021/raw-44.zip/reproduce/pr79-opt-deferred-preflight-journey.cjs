'use strict';
const fs=require('node:fs'), path=require('node:path'), cp=require('node:child_process'), crypto=require('node:crypto');
const root='/workspace/scratch/38e8b0c92238/pr79-opt', dir=root+'-deferred-prepared', out=root+'-deferred-preflight-journey';
const {toolRequire}=require(root+'/tools/quality/common.cjs'), artifact=require(root+'/tools/quality/artifact.cjs'), {start}=require(root+'/tools/quality/serve.cjs'), {articleJourney,validateArticleJourney}=require(root+'/tools/quality/article-browser.cjs');
const manifest=JSON.parse(fs.readFileSync(dir+'/artifact.json'));
const git=(...a)=>cp.execFileSync('git',a,{cwd:root,encoding:'utf8'}).trim();
const record={sourceCommit:git('rev-parse','HEAD'),sourceTree:git('rev-parse','HEAD^{tree}'),sourceDirty:!!git('status','--porcelain'),artifactDigest:manifest.artifactDigest,scriptSha256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),startedAt:new Date().toISOString(),verification:{before:false,after:false}};
fs.mkdirSync(out,{recursive:false});const save=()=>fs.writeFileSync(out+'/article-journey.json',JSON.stringify(record,null,2)+'\n');
async function main(){let server,browser;try{
 if(record.sourceCommit!==manifest.sourceCommit)throw Error('source identity mismatch');
 artifact.verify(dir+'/public',manifest); record.verification.before=true; save();
 const host=await start({publicDir:dir+'/public',localOnly:true});server=host.server;record.baseURL=host.url;
 browser=await toolRequire('playwright').chromium.launch({executablePath:'/tmp/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
 record.detail=await articleJourney(host.url,manifest.components.articles,{browser,widths:[390],modes:['normal'],timeout:10000});save();
 record.role='Prepared dirty-source functional regression only; not final acceptance'; record.validation={observations:record.detail.observations.length,requests:Object.fromEntries(Object.entries(record.detail.observations[0].reader.requestDeferral).map(([phase,data])=>[phase,require(root+'/tools/quality/article-browser.cjs').validateDeferredRequests(data)]))};
 artifact.verify(dir+'/public',manifest);record.verification.after=true;record.pass=true;
}catch(e){record.error=e.stack;record.partialObservations=e.articleObservations;record.pass=false;process.exitCode=1;}
finally{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));record.finishedAt=new Date().toISOString();record.sourceDirtyAfter=!!git('status','--porcelain');save();console.log(JSON.stringify({pass:record.pass,validation:record.validation,error:record.error,source:record.sourceCommit}));}}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
