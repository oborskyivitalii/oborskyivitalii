'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const root='/workspace/scratch/38e8b0c92238/pr79-opt',base=path.dirname(root),dir=root+'-final-artifact',out=root+'-reduced-diagnostic';
const motion=require(root+'/tools/quality/motion.cjs'),{toolRequire}=require(root+'/tools/quality/common.cjs'),{start}=require(root+'/tools/quality/serve.cjs');
const manifest=JSON.parse(fs.readFileSync(dir+'/artifact.json'));fs.mkdirSync(out,{recursive:false});
const record={role:'Targeted failure diagnosis; fixed5 Writing390/CPU1 samples, original setup2s deadline, no automatic retry or performance acceptance',source:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),artifactDigest:manifest.artifactDigest,scriptSha256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),startedAt:new Date().toISOString(),trials:[]};
const save=()=>fs.writeFileSync(out+'/execution.json',JSON.stringify(record,null,2)+'\n');
function watch(){const native=window.matchMedia.bind(window),queries=[],events=[];window.__reducedDiagnostic={queries,events};
 window.matchMedia=(query)=>{const mql=native(query);if(query.includes('prefers-reduced-motion')){queries.push({query,mql,created:performance.now()});mql.addEventListener('change',event=>events.push({kind:'query-change',time:performance.now(),matches:event.matches}));}return mql;};
 for(const name of ['site:motion-state','site:motion-preference'])window.addEventListener(name,e=>events.push({kind:name,time:performance.now(),detail:e.detail}));
 document.addEventListener('contextlost',e=>events.push({kind:'contextlost',time:performance.now(),target:e.target.id}),true);
 document.addEventListener('DOMContentLoaded',()=>{const control=document.querySelector('#space-motion');if(control)new MutationObserver(()=>events.push({kind:'control-change',time:performance.now(),text:control.textContent,disabled:control.disabled,hidden:control.hidden})).observe(control,{attributes:true,childList:true,subtree:true});});
}
async function snapshot(page){return page.evaluate(()=>{const w=window.__reducedDiagnostic,c=document.querySelector('#space-motion'),scene=document.querySelector('.space-scene');return {time:performance.now(),visibility:document.visibilityState,focus:document.hasFocus(),freshQuery:matchMedia('(prefers-reduced-motion: reduce)').matches,queries:w.queries.map(x=>({query:x.query,created:x.created,matches:x.mql.matches})),events:w.events,control:c?{text:c.textContent,disabled:c.disabled,hidden:c.hidden,pressed:c.getAttribute('aria-pressed')}:null,scene:scene?.dataset,diagnostics:window.SiteScene?.diagnostics?.(),probe:window.__qualityMotion};});}
async function main(){const {server,url}=await start({publicDir:dir+'/public',localOnly:true});const browser=await toolRequire('playwright').chromium.launch({executablePath:'/tmp/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});try{
 for(let trial=1;trial<=5;trial++){const row={trial,route:'writing',width:390,rate:1,startedAt:new Date().toISOString(),pageErrors:[]};record.trials.push(row);save();
 const proxy={newContext:async options=>{const ctx=await browser.newContext(options);await ctx.addInitScript(watch);let page;const open=ctx.newPage.bind(ctx),close=ctx.close.bind(ctx);ctx.newPage=async()=>{page=await open();page.on('pageerror',e=>row.pageErrors.push(e.message));return page;};ctx.close=async()=>{try{row.beforeTeardown=await snapshot(page);}catch(e){row.snapshotError=e.stack;}finally{await close();}};return ctx;}};
 try{row.sample=await motion.sample(proxy,url,'writing',{width:390,rate:1});row.pass=true;}catch(e){row.pass=false;row.error=e.stack;}
 row.finishedAt=new Date().toISOString();save();console.log(JSON.stringify({trial,pass:row.pass,error:row.error,control:row.beforeTeardown?.control,freshQuery:row.beforeTeardown?.freshQuery,pageErrors:row.pageErrors}));
 }
}finally{await browser.close();await new Promise(r=>server.close(r));record.finishedAt=new Date().toISOString();save();}}
main().catch(e=>{record.error=e.stack;save();console.error(e.stack);process.exitCode=1;});
