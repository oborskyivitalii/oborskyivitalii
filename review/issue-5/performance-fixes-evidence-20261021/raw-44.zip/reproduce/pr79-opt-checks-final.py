from pathlib import Path
import subprocess,json,datetime,os,sys,hashlib
root=Path('/workspace/scratch/38e8b0c92238/pr79-opt'); out=root.parent/'pr79-opt-final-source-checks'; out.mkdir(exist_ok=True)
artifact=root.parent/'pr79-opt-final-artifact'; q=os.environ['OPT_SOURCE']
def git(*a): return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==q and git('status','--porcelain')==''
env={**os.environ,'SITE_PUBLIC_DIR':str(artifact/'public'),'SITE_ARTIFACT_MANIFEST':str(artifact/'artifact.json'),'SITE_REPORT_DIR':str(out),'SITE_AUDIT_TOOLS':str(root/'tools/quality/toolchain'),'SITE_AUDIT_CHROME':'/tmp/chromium'}
commands=[('owning',['python3','tools/issue_acceptance.py','run','--policy','.github/acceptance/issue-5.json','--report',str(out/'issue-5-acceptance.json'),'--require-clean','--expected-source',q]),('format',['node','tools/quality/format.cjs','--check']),('lint',['node','tools/quality/scanners.cjs','lint']),('ri-tests',['python3','-m','unittest','discover','-s','tests','-p','test_repository_intelligence.py']),('ri-ci-tests',['python3','-m','unittest','discover','-s','tests','-p','test_ri_ci.py']),('python-toolchain',['tools/quality/toolchain/venv/bin/python','tools/quality/python_toolchain.py'])]
rows=[]
for name,cmd in commands:
 row={'name':name,'command':cmd,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (out/'started.json').write_text(json.dumps({'source':q,'tree':git('rev-parse','HEAD^{tree}'),'active':row,'completed':rows},indent=2)+'\n')
 with (out/(name+'.log')).open('x') as log: r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()); rows.append(row)
 record={'source':q,'tree':git('rev-parse','HEAD^{tree}'),'sourceDirty':bool(git('status','--porcelain')),'rows':rows,'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (out/'execution.json').write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps(row),flush=True)
 if r.returncode: sys.exit(r.returncode)
assert git('status','--porcelain')==''
print('All frozen-source checks passed',flush=True)
