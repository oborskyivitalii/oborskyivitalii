from pathlib import Path
import json,hashlib,sys
import fitz
from PIL import Image,ImageDraw
out=Path(sys.argv[1]); p=out/'cold-native-print.pdf'; data=p.read_bytes(); doc=fitz.open(p)
images={}
for page in doc:
 for row in page.get_images(full=True): images[row[0]]={'xref':row[0],'width':row[2],'height':row[3]}
functional=json.loads((out/'functional.json').read_text())
expected=sorted((image['width'],image['height']) for image in functional['admittedImages'])
assert len(images)==len(expected), images
assert sorted((image['width'],image['height']) for image in images.values())==expected
cols=5; tw,th=200,285; rows=(len(doc)+cols-1)//cols
contact=Image.new('RGB',(cols*tw,rows*(th+24)),(215,215,215)); draw=ImageDraw.Draw(contact)
for i,page in enumerate(doc):
 pix=page.get_pixmap(matrix=fitz.Matrix(.35,.35),alpha=False)
 im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples); im.thumbnail((tw-8,th-8))
 x=(i%cols)*tw+(tw-im.width)//2;y=(i//cols)*(th+24)
 contact.paste(im,(x,y+20));draw.text(((i%cols)*tw+8,y+3),str(i+1),fill=(0,0,0))
contact.save(out/'print-contact.jpg',format='JPEG',quality=85,optimize=True)
Image.open(out/'print-contact.jpg').verify()
record={'pass':True,'pdfSha256':hashlib.sha256(data).hexdigest(),'pdfBytes':len(data),'pages':len(doc),'uniqueEmbeddedImages':list(images.values()),'contactSheet':'print-contact.jpg','contactSha256':hashlib.sha256((out/'print-contact.jpg').read_bytes()).hexdigest(),'nativePdfRepaired':doc.is_repaired}
(out/'print-inspection.json').write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps(record))
