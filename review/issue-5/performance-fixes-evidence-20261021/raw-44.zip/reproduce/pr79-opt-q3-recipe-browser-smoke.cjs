'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const root = '/workspace/scratch/38e8b0c92238/pr79-opt';
const dir = process.env.OPT_ARTIFACT_DIR || '/workspace/scratch/38e8b0c92238/pr79-opt-prepared-artifact';
const out = process.env.OPT_RESULTS_DIR || '/workspace/scratch/38e8b0c92238/pr79-opt-preflight-browser';
const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'artifact.json')));
const { toolRequire } = require(path.join(root, 'tools/quality/common.cjs'));
const { start } = require(path.join(root, 'tools/quality/serve.cjs'));
const record = {kind:'reader-loading-functional',sourceCommit:manifest.sourceCommit,sourceDirty:manifest.sourceDirty,artifactDigest:manifest.artifactDigest,startedAt:new Date().toISOString(),checks:[],scriptSha256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex')};
fs.mkdirSync(out,{recursive:true});
const save=()=>fs.writeFileSync(path.join(out,'functional.json'),JSON.stringify(record,null,2)+'\n');
async function images(page){return page.locator('.article-body img').evaluateAll(xs=>xs.map(x=>({src:x.src,loading:x.loading,complete:x.complete,naturalWidth:x.naturalWidth,naturalHeight:x.naturalHeight,width:x.width,height:x.height})));}
async function main(){
  const {server,url}=await start({publicDir:path.join(dir,'public'),localOnly:true});
  const browser=await toolRequire('playwright').chromium.launch({executablePath:'/tmp/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
  const [key,article]=Object.entries(manifest.components.articles)[0];
  const target=url+'/'+article.alias;
  try{
    const context=await browser.newContext({viewport:{width:390,height:844}});
    const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto(target,{waitUntil:'networkidle'});
    const initial=await images(page);assert.equal(initial.length,8);assert.equal(initial[0].loading,'eager');
    assert.ok(initial.slice(1).every(x=>x.loading==='lazy'));
    assert.equal(initial.filter(x=>x.complete&&x.naturalWidth>0).length,1,'only near/critical cover loads initially');
    assert.ok(await page.locator('.reader-introduction > p').first().isVisible());
    record.checks.push({name:'cold-image-scheduling',images:initial});save();
    const last=page.locator('.reader-image-open').last();const lastURL=initial.at(-1).src;
    const figure=await last.evaluate(x=>x.closest('figure').id);
    await page.goto(target+'#'+figure,{waitUntil:'networkidle'});
    await require(path.join(root,'tools/quality/article-browser.cjs')).waitForReaderAnchor(page,'#'+figure);
    await page.locator('#'+figure+' img').evaluate(x=>x.decode());
    const fragment=await page.locator('#'+figure).boundingBox();assert.ok(fragment.y<844&&fragment.y+fragment.height>0,'deep-linked figure is visible');
    await page.locator('#'+figure+' .reader-image-open').click();
    const dialog=page.locator('.reader-image-dialog');await dialog.waitFor({state:'visible'});
    const shown=dialog.locator('[data-reader-image] img');await shown.evaluate(x=>x.decode());assert.equal(await shown.evaluate(x=>x.src),lastURL);
    await page.keyboard.press('Escape');assert.equal(await dialog.isVisible(),false);
    assert.equal(await page.locator('#'+figure+' .reader-image-open').evaluate(x=>x===document.activeElement),true);
    record.checks.push({name:'deep-fragment-late-image-dialog-and-focus',figure,lastURL});save();
    await page.locator('.reader-back').click();await page.waitForFunction(()=>!document.body.dataset.article);
    await page.goBack();await page.waitForFunction(x=>document.body.dataset.article===x,key);
    assert.equal(new URL(page.url()).hash,'#'+figure);await page.locator('#'+figure+' img').evaluate(x=>x.decode());
    record.checks.push({name:'writing-return-history',url:page.url()});assert.deepEqual(errors,[]);await context.close();save();
    const nativeContext=await browser.newContext({javaScriptEnabled:false,viewport:{width:390,height:844}});
    const native=await nativeContext.newPage();await native.goto(target,{waitUntil:'networkidle'});
    const nativeImages=await images(native);assert.equal(nativeImages.length,8);assert.ok(nativeImages.every(x=>x.complete&&x.naturalWidth>0));
    record.checks.push({name:'no-js-native-all-images',images:nativeImages});await nativeContext.close();save();
    const printContext=await browser.newContext({viewport:{width:390,height:844}});
    const print=await printContext.newPage();await print.goto(target,{waitUntil:'networkidle'});
    const before=await images(print);assert.equal(before.filter(x=>x.complete&&x.naturalWidth>0).length,1);
    await print.pdf({path:path.join(out,'cold-native-print.pdf'),format:'A4',printBackground:true});
    const after=await images(print);assert.ok(after.every(x=>x.complete&&x.naturalWidth>0),'cold native print loads every lazy image');
    record.checks.push({name:'cold-native-print',before,after});await printContext.close();save();
    record.pass=true;
  }catch(e){record.error=e.stack;record.pass=false;throw e;}
  finally{record.finishedAt=new Date().toISOString();save();await browser.close();server.close();}
}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
