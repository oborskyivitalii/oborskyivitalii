from pathlib import Path
import subprocess,json,datetime,os,sys
root=Path('/workspace/scratch/38e8b0c92238/pr79-opt'); out=root.parent/'pr79-opt-final-build'; out.mkdir(exist_ok=True)
artifact=root.parent/'pr79-opt-final-artifact'
q=os.environ['OPT_SOURCE']
def git(*a): return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==q and git('status','--porcelain')==''
rows=[]; env={**os.environ,'SITE_ARTICLE_PREVIEW':'true','SITE_AUDIT_TOOLS':str(root/'tools/quality/toolchain'),'SITE_AUDIT_CHROME':'/tmp/chromium'}
commands=[['node','tools/quality/artifact.cjs','build',str(artifact)],['node','tools/staging/review-flow.cjs','rendition',str(artifact)],['node','tools/staging/edition.cjs',str(artifact)]]
for i,cmd in enumerate(commands):
 row={'command':cmd,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/f'{i+1}.log').open('x') as log: r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()); rows.append(row)
 (out/'execution.json').write_text(json.dumps({'source':q,'tree':git('rev-parse','HEAD^{tree}'),'sourceDirty':bool(git('status','--porcelain')),'rows':rows},indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if r.returncode: sys.exit(r.returncode)
assert git('status','--porcelain')==''
print('Frozen final Color/staging artifact built from clean '+q,flush=True)
