from pathlib import Path
import json,hashlib,zipfile,subprocess
ROOT=Path('/workspace/scratch/faafe921a49f/archive-work')
OUT=Path('/tmp/issue184')
paths=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
files=[]
for name in filter(None,paths):
 p=ROOT/name
 if p.is_file():
  b=p.read_bytes();files.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
byname={p['path']:p for p in files};groups={}
for f in files:groups.setdefault(f['sha256'],[]).append(f['path'])
duplicates=[{'sha256':sha,'bytes':byname[names[0]]['bytes'],'paths':names} for sha,names in groups.items() if len(names)>1]
archive_matches=[]
for p in sorted((ROOT/'review').glob('site-v1-*.zip')):
 if p.stat().st_size>20_000_000:continue
 archive_sha=hashlib.sha256(p.read_bytes()).hexdigest()
 with zipfile.ZipFile(p) as z:
  for i in z.infolist():
   local=byname.get(i.filename)
   if not local or i.file_size!=local['bytes'] or i.file_size>2_000_000:continue
   actual=hashlib.sha256(z.read(i)).hexdigest()
   if actual==local['sha256']:archive_matches.append({**local,'archive':p.relative_to(ROOT).as_posix(),'archiveSha256':archive_sha,'member':i.filename})
selected=[r for r in archive_matches if r['path'].endswith('.html') and any(f'20261002-v{n}-' in r['path'] for n in (5,6,7)) and r['bytes']>1000]
assert len({r['path'] for r in selected})==len(selected)
result={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'trackedFiles':len(files),'trackedBytes':sum(f['bytes'] for f in files),'largest':sorted(files,key=lambda x:x['bytes'],reverse=True)[:35],'duplicateGroups':duplicates,'existingArchiveMatches':archive_matches,'selected':selected,'selectedOriginalBytes':sum(x['bytes'] for x in selected),'exclusions':['docs/','site/','active source/test/tool/rights inputs','PR110 f96425b unmerged post-event R10','R12 ongoing issue169 source/PDF','maintained v11 previews']}
(OUT/'inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'trackedFiles':result['trackedFiles'],'trackedBytes':result['trackedBytes'],'duplicateGroups':len(duplicates),'existingArchiveMatches':len(archive_matches),'selected':len(selected),'selectedOriginalBytes':result['selectedOriginalBytes'],'paths':[r['path'] for r in selected]},indent=2))
