from pathlib import Path
import json,hashlib,zipfile,subprocess,tempfile,importlib.util
ROOT=Path('/workspace/scratch/faafe921a49f/archive-work')
sha=lambda b:hashlib.sha256(b).hexdigest()
d=json.loads((ROOT/'review/issue-184/archive-index.json').read_text()); results=[]
with tempfile.TemporaryDirectory() as output:
 for row in d['items']:
  archive=ROOT/row['archive']; assert sha(archive.read_bytes())==row['archiveSha256']
  with zipfile.ZipFile(archive) as z: raw=z.read(row['member'])
  original=subprocess.check_output(['git','show',d['base']+':'+row['path']],cwd=ROOT)
  target=Path(output)/Path(row['path']).name;target.write_bytes(raw)
  assert target.read_bytes()==original and len(raw)==row['bytes'] and sha(raw)==row['sha256']
  locator=(ROOT/row['path']).read_bytes();assert sha(locator)==row['locatorSha256'] and len(locator)==row['locatorBytes']
  # Execute the actual unzip member operation; the displayed command's /tmp target is for readers.
  extracted=subprocess.check_output(['unzip','-p',str(archive),row['member']]); assert extracted==raw
  results.append({'path':row['path'],'recoveredBytes':len(raw),'sha256':sha(raw),'originalGitBlobEqual':True,'unzipCommandEqual':True})
protected=['site/','docs/','tests/','tools/','guides/','.github/workflows/']
for group in protected:subprocess.run(['git','diff','--exit-code',d['base'],'--',group],cwd=ROOT,check=True,stdout=subprocess.PIPE)
# All old v5-v7 archives and static/offline manifests remain byte-exact.
for glob in ('review/site-v1-20261002-v[567].zip','review/site-v1-static-previews-v[567].json','review/site-v1-offline-bundle-v[567].json'):
 for p in ROOT.glob(glob):assert p.read_bytes()==subprocess.check_output(['git','show',d['base']+':'+p.relative_to(ROOT).as_posix()],cwd=ROOT)
spec=importlib.util.spec_from_file_location('ri_actual',ROOT/'tools/repository_intelligence.py');ri=importlib.util.module_from_spec(spec);spec.loader.exec_module(ri)
records,_=ri.scan(ROOT,{'.github/repository-intelligence/agent-context.json','REPOSITORY-MAP.md'})
records=[x for x in records if x['identity_mode']=='content']
count=sum((ROOT/x['path']).stat().st_size for x in records)
out={'sourcePhase':'prepared candidate before literal final receipts','recoveries':results,'recovered':len(results),'protectedPublicSourceBytesUnchanged':True,'historicalArchivesManifestsUnchanged':True,'riHashInputFiles':len(records),'riHashBytes':count,'riLimitBytes':ri.MAX_HASH_TOTAL_BYTES,'headroom':ri.MAX_HASH_TOTAL_BYTES-count}
Path('/tmp/issue184/recovery-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='recoveries'}))
