## Problem and maintainer decision — 10 November 2026

The repository-intelligence (RI) producer hashes the repository's physical source, assets and historical evidence. Its **250,000,000-byte aggregate hashing bound is almost exhausted**; this is not the size limit of the generated RI JSON and not a website/PDF page budget.

Measured at main/production `a9f576918defbed3950c8ab95b4161be26e56ade`: 2,640 hash inputs / 249,998,538 bytes, leaving 1,462 bytes. Replacing current Markdown/HTML contributes little; keeping new PDF/edition evidence alongside previous versions and duplicated historical exports adds physical bytes.

Maintainer selected **option 3: remove redundant loose copies while preserving exact originals in archives**, and requested making this normal practice for all changes that have actually reached production. Create this issue and execution plan before archival mutations. Do not solve the problem by raising RI limits, omitting inputs or weakening checks.

Related: #169 prepares the SDLC article R12. That editorial change stays owned by #169. This issue owns archive/storage hygiene and its standing workflow rule. Keep implementation branches and acceptance separate; link the dependency rather than silently expanding the article PR.

## Intended outcome

A completed production change has one accessible, source-bound evidence archive and a small readable handoff/index. Redundant loose review exports are removed or replaced with honest recovery locators. Exact originals remain recoverable; current authoring sources, public immutable editions, rollback resources and ongoing work stay usable. New changes do not repeatedly accumulate several physical copies of the same completed review kit.

Archiving is lossless storage maintenance, not acceptance of the archived content. Rejected experiments, failed runs and original reviewer judgments retain their actual status.

## Execution plan

### 1. Inventory and classify before touching bytes

- Revalidate live main/production refs, production releases and relevant open PRs. Follow current AGENTS/CONTRIBUTING, map owners and obtain independent requirements preflight.
- Produce a bounded inventory ranked by size/duplicate groups: loose historical review files, archives, current publication sources and generated/retained public resources. Record original path, bytes, SHA256, owner issue/PR, archive/member if one exists, and actual production/supersession evidence.
- Classify each item as active source, unfinished work, required runtime/rollback/immutable closure, recoverable redundant historical copy, or unresolved. An issue's closed/open state alone does not establish production completion.
- Locate code/test/build/registry/document consumers before deciding that a loose copy is redundant. Do not remove a path needed as an executable fixture or current authoring input.

### 2. Deliver the smallest safe space-recovery slice

- First reuse **existing archives that already contain exact originals**. Avoid adding another archive for the same bytes.
- Verified starting candidates: `review/site-v1-20261002-v6.zip` already contains byte-exact `day.html`, `night.html`, and `interactive.html` loose v6 previews under their original `review/` member paths: 683,344 bytes total. ZIP SHA256: `afe6784c18da5d5be6f4311d153e870bccd3ab7e8cb10275a883476b45a8cb42`. These are candidates, not permission to skip consumer/recovery checks.
- Preserve original-path locators where links need to remain usable. Each locator names the archive/member, decoded SHA256/size and practical recovery command. Historical manifests continue describing the original bytes; never relabel a locator as the old artifact.
- Where no suitable archive exists, create one compact lossless archive containing originals plus a manifest. Verify recovery **before** removing redundant loose copies.
- Recalculate the complete candidate's RI input size, including accompanying metadata/evidence and generated output. Report recovered bytes and remaining headroom. Restore useful headroom for the pending #169 increment; do not stop at a nominal 1-byte pass.
- Do not recompress or overwrite existing immutable archives merely to chase marginal savings. Preserve R11 publication/PDF and every served immutable URL/rollback closure unless its existing owning mechanism explicitly supports a verified relocation.

### 3. Apply the same treatment to completed production work

- Work through the eligible inventory in bounded batches. Include superseded preproduction experiments only when their owning work's later production completion and safe archival status are established.
- Keep a short per-owner summary with final source/release/run links, archive identity, original-path recovery map, remaining open obligations and measured savings.
- Deduplicate only proven redundant physical copies. Similar names, revisions or visual appearance are insufficient.
- Preserve raw failed observations and first independent review outputs. Do not turn historical failures into a green result, erase unresolved gates or prune unfinished PR material.

### 4. Make archiving a normal post-production step

- Add a short mandatory completion step to the existing canonical contribution/release workflow; route from AGENTS only if needed. Reuse existing evidence, RI and repository-only delivery mechanisms.
- Trigger after **verified production delivery** for every applicable completed change, not merely PR merge or successful staging. Open external follow-up obligations can remain explicit and must retain their evidence.
- At that step: record exact production source/release and served verification; archive completed transient review exports; verify recovery; remove redundant loose copies; refresh catalog/RI; record before/after sizes and unfinished work in the existing owner.
- Perform source cleanup through an ordinary reviewed repository-maintenance PR. The post-production step does not mutate a production host, purge rollback assets or rewrite Git history.
- Keep the first implementation simple. No new paid storage/service, automatic bulk deletion, archive service, scheduled job or separate release pipeline. Add a bounded helper only if the inventory demonstrates repeated mechanical work that existing tools cannot safely cover.

### 5. Verify, review and deliver

- Map the full path delta and test impact before broad checks. Applicable CS01/04/05/08/09/10 cover ownership, reuse, readable configuration, behavioral verification, bounded guard and exact evidence.
- Verify every moved original by extracting it to a temporary directory and comparing size/SHA256; exercise a failed/missing/mismatched member case if a new helper is introduced.
- Update physical-path catalog ownership, generated RI views, affected links and CI coupling identities. Keep the 250MB aggregate cap and all file/text/runtime/release/test budgets unchanged.
- Run RI build/verify, affected RI/navigation/style/owning-policy checks and changed archive/link/retention checks. Website Basic/staging applies only if the actual changed ownership requires it; use the existing trusted repository-only route where genuinely eligible.
- Complete the four actual source-bound review roles and correction review required by the repository. Commit with `Refs #<this issue>`; deliver a separate Draft PR, exact-source results, recovery evidence and bytes saved. Publication/merge follow the existing authorized route.

## Acceptance criteria

- [ ] **AC01 — Inventory and eligibility.** A versioned inventory identifies large/duplicate inputs, exact hashes/sizes/owners/consumers, live production or supersession evidence and explicit exclusion of active/unfinished/required public resources.
- [ ] **AC02 — Lossless recovery.** Every removed or replaced loose original has an accessible archive/member and verified extraction with identical size/SHA256; affected original-path links have truthful locators. Historical archives/manifests/failed evidence are not silently rewritten.
- [ ] **AC03 — Measured capacity recovery.** Exact before/after totals and complete-candidate headroom are recorded; RI build/verify succeeds under the unchanged 250MB cap. Pending R12 storage needs are explicitly measured rather than assumed.
- [ ] **AC04 — Public and historical integrity.** Current source/build/test inputs, immutable served editions, rights/source bindings and rollback closure remain valid. R11 PDF/originals remain recoverable and unchanged. No Git-history rewrite, host purge or platform post occurs.
- [ ] **AC05 — Standing post-production process.** Existing canonical workflow requires source-bound archival/deduplication after verified production for all applicable changes, with ownership, unfinished-work exceptions, recovery verification and a normal maintenance PR. Merge/staging alone cannot trigger completion.
- [ ] **AC06 — Reviewed exact-source delivery.** Test impact, applicable CS rules, acceptance-policy/catalog/RI/CI updates, required checks and four independent roles are recorded for the exact candidate. Separate Draft PR and issue links identify what is implemented, merged and actually effective; partial acceptance stays open.

## Current status and next action

Planning/intake only. No archival deletion, threshold change or cleanup PR has occurred. First execution is the eligibility/consumer inventory and requirements review, followed by the smallest verified deduplication batch. #169's canonical R12 Markdown has been prepared separately; its reader/PDF/PR and later site publication remain pending.

Latest owner direction: “Роби, я думаю як мінімум можемо оновити АЦ і закрити ішью 179 109”.
Administrative closure is not production evidence: actual PR110 is open/Draft/unmerged at f96425baa9195b06149fd32c85cc6c9056efadcf. Its material must remain outside eligible production archival until independently justified. Actual production release prod-2026-11-09.1 and successful run42650891346 bind a9f576918defbed3950c8ab95b4161be26e56ade.
