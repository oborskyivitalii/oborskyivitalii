# Literal source-bound archive evidence

First/correction results are preserved separately. Source bundle preserves exact
local reviewed commits819432b/9884e19 with public prerequisitea9f5769, not a claim
that those commit IDs were previously published to GitHub. Verify the bundle and
fetch HEAD into a temporary local review ref to inspect them. Final remote source
will have its own identity/check/PR receipt; compare substantive path hashes.

The supplied packets retain their actual absolute paths/digests. Original source
diff is reproducible from those bundle commits and prerequisite; do not duplicate
the4.2MB original HTML patch, which is already in the immutable old ZIPs. Archive
index and unchanged33locators in the final source supply their recovery route.

Initial recovery count accidentally summed two derived RI records; its raw result
is retained. The corrected metric filters identity_mode=content, matching actual
RI hashing. All33 actual extraction/base-byte comparisons remain passed.

R12 cost is a temporary six-page content trial, not an accepted final PDF. The
517588-byte compressed output preserves text/link/page/metadata parity; three
copies plus500KB is an explicit planning allowance, not a measured final public
closure. Final five-page visual/author/source/public work stays issue169.

Actual browser observations are blocked: local Chromium's singleton socket is
EPERM; CUA permits http/https only and rejected local-file browsing with an
explicit no-workaround policy. No workaround, UI/download pass or screenshot is
claimed. Actual33archive links/member/hash/literal command journeys passed.

Raw deterministic logs bind their stated source, not later final receipt-only
metadata. Provider context/model/memory internals remain unknown. Requested and
accepted handles are separately recorded; shared filesystem is not OS isolation.
