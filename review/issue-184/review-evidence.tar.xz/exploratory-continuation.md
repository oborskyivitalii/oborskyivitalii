# Exploratory continuation — browser capability attempt

First judgment /tmp/issue184/exploratory-first.md remains unchanged. Parent subsequently authorized one CUA browser attempt. This continuation is not a fresh first judgment.

`cua.getState()` observed a Chrome CDP browser with no tabs and Linux native app inventory. Attempting `cua.createBrowserTab('cdp','file:///workspace/scratch/faafe921a49f/archive-work/review/site-v1-20261002-v7-day.html')` was rejected by browser URL policy: only http/https protocols allowed; it explicitly prohibited workaround, alternate browser surfaces and policy circumvention. No local file content was rendered and no screenshot exists. Stopped without workaround. CUA completion summary recorded.

Verdict unchanged: 33 recovery/command journeys pass, actual browser UI/download/focus/mobile/no-JS observations blocked. This is an environment/policy evidence limitation, not a candidate product failure. Source bytes and implementation were not changed.
