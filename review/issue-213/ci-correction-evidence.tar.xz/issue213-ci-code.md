# Independent Code / Artifact review — issue213 CI correction

Verdict: **blocked by F01**. The four dependency selections and explicit-source fixture corrections are supported by the retained CI symptoms. The newly selected exact runtime tuple reaches a preserved negative case that fails: the current client is missing from document-hook verification admission. No corrected-source judgment is supplied by this execution.

## Identity and boundaries

- Reviewer: `/root/issue213_ci_code`, Code / Artifact, first completed candidate-delta judgment for this packet; nonauthor, no implementation or delegation.
- Immutable reviewed correction: `cb9c219f12e469860fd35213c5bd951932306f7a` → `c88399022d6b882e7e4a13fce5ede7c2ffafeddf`, candidate tree `73de091cad15b2c6c8f82b99c4d176cf0a7c3f7a`.
- Guide review additionally covers protected base `3877546d29a04f235f9ec0f3175f4e0d90bfd60d` → that candidate, all 25 reported guide-scope paths.
- Packet SHA-256: `c69c1079e91cbdbc5019162f75ed97044a1e3fd88416b2f1eacb76d7f251c0e1`. Independently recomputed; all referenced material hashes matched.
- Common prompt: `agents/reviewers/README.md`, SHA-256 `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`. Role prompt: `agents/reviewers/code-review.md`, SHA-256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Read supplied original intent/owner snapshot/AC01–AC06, root AGENTS, README, REPOSITORY-MAP, dated MEMORY, applicable CONTRIBUTING sections, CODE-STYLE, acceptance contract, staging owner and workflow guide. Inspected actual diffs, owners, registry and raw eight CI logs. No current peer verdict, preflight report, parent scratch/history or external service was read. Catalog entries name historical review artifacts; their contents were not read.
- Parent requested isolated review; actual launch receipt is parent-owned. Provider model/context internals are unknown. No author conversation was observed in the supplied task. User/project/platform instructions remain available shared context.

## Blocking finding

**F01 — High, retained document-hook refusal is bypassed for the new client.**

Location: `tools/site/runtime-compatibility.cjs`, `reviewedDocumentClients` and `verify()` early return; exposed by `tests/color-motion-contract.test.cjs:236` after its line211 selection changes to `issue213-discovery-link-plain`.

The candidate output lock declares client `87f9590292adefa27641b1315e6b4292a871a7acf12b033eab5f2521433899ab`. The document-client set ends with predecessor `97208ee3d165d8585186561ca50d2fdebe8ca0831c3fc6b7a7414a43e5f18aab` and lacks the current exact client. `verify()` checks runtime bytes/fingerprint, then returns without calling `verifyDocument()` for this client. The preserved test removes the actual `space-motion` id and expects rejection; no exception is thrown. The later comment/template/script spoof, fallback class and footer checks share that bypass.

Independent execution:

```text
node --test --test-name-pattern='producer refactoring preserves' tests/color-motion-contract.test.cjs
Node v24.22.3; exit 1; tests 1, pass 0, fail 1, cancelled/skipped/todo 0
AssertionError: Missing expected exception.
expected /client document hook space-motion/
at tests/color-motion-contract.test.cjs:236:14
```

The initial broader affected-suite execution independently reports the same failure. The targeted execution was a bounded diagnostic to locate that concrete failure, not an unchanged campaign rerun. Inspected test SHA-256 `4c0623dbf53399d60c2fb6b2deb39b2ce39f95fe93bf42a592425486d1ec2838` matches the immutable candidate. Runtime-compatibility source was unchanged by the correction or the observed metadata-only successor.

Impact: AC04 technical integrity / STYLE-REVIEW, CS08 meaningful refusal coverage, and AC05 current-source verification. This is a real source guard gap, not merely a stale expected tuple: current document hook corruption is accepted. Treatment: preserve all negative assertions and exact runtime-byte comparisons; correct the authoritative current-client verification admission with evidence and obtain fresh affected review. Do not skip the case, substitute the predecessor again, or broaden acceptance to arbitrary clients. This execution does not review any subsequent correction.

## Correction assessment and retained invariants

Observed raw failures at cb9 separate into:

- Navigation: `check_ri_ci.py verify` explicitly refuses missing current workflow-guide evidence. This review supplies a substantive guide judgment; the owner still must create the correctly source-bound record and pass the guard.
- Owning acceptance: format-parity helper cannot spawn `tools/quality/toolchain/venv/bin/python` (ENOENT). The candidate adds issue213 to quality npm, pinned Python, locked Python tools and publisher toolchain selections. No selector, action pin, clean-source check, timeout or failed-report upload is removed.
- Reader/release/archive consumers: real ENOENT failures try to capture current retained snapshot59ff… from a historical licensed-source fixture lacking that current resource. The correction passes each fixture's actual authoredRoot to Color and production edition construction, retaining actual capture/byte validation. It does not supply a fake missing snapshot.
- Color/publication/regression fixtures: actual issue213 tuple is compared with old issue183 tuple. The correction selects the explicit registered current tuple while retaining exact full variant and runtime-file assertions and unchanged historical-tuple coverage. F01 shows why changing the positive tuple alone is insufficient.

The seven-file cb9-to-head delta changes no site/docs bytes, production implementation, budgets, runner limits, registry selectors, policy human gates, or negative tests. The full protected-base covered diff adds explicit retention-source inputs at the owning builders/reconstructor, negative missing/malformed/tampered declarations and default/explicit equality, bounded canonical-link/origin-policy cases, historical fixture isolation and maintained issue213 mapping. Source-root inputs select retention declarations; trusted effect/origin/social policy remains module-owned. Registry changes add source dependencies and the owning task-snapshot route; existing normal maintained suite routes remain. Existing test/refusal assertions are retained.

I examined CS01 ownership/dependency direction and explicit inputs; CS02/04 single policy/source owners; CS05 focused readable edits; CS07 unchanged resource limits; CS08 actual independent positive/refusal oracle; CS09 guard limits and CS10 issue/policy mapping. F01 blocks the verification obligation beyond any bounded style-guard success.

## Independent workflow-guide disposition

**Disposition: `unchanged` for guide bytes at c883.** No substantive guide correction is required for the reviewed 25-path control scope. This is a content judgment, not a successful admission/Navigation result, and F01 still blocks advancement.

Guide: `guides/REPOSITORY-WORKFLOW.md`, SHA-256 `cec5fd9748792cfb7aa1b7bfa734fca4e0bfd695fb367c76f7b89b57ed1c21d0`.

Actual existing section names and rationale:

| Section | Independent comparison with full covered diff |
| --- | --- |
| Harness and ownership | New issue213 policy, test catalog entries, RI catalog additions/removals and refreshed source identity retain the existing one-catalog navigation and issue-owned AC/check mapping. No second authority or new lookup route is introduced. |
| Agents and orchestration | No agent prompt, role, fresh-launch requirement, correction-review or maintainer authority changes. Current independent correction review follows the existing described route. |
| Keeping this guide current | Workflow/check/registry and edition control changes are covered and still require the committed base/head scope, independent disposition and exact-head owner attestation. Current guard refusal is consistent with this section. This review does not replace the evidence record. |
| Site architecture | Explicit sourceRoot retention selection still composes verified authored generation into staging/production editions and preserves immutable closure. Fixture isolation changes no public source ownership. No new architecture, engine or cache authority is introduced. |
| Delivery routes and controls | The PR includes templates, executable controllers/tests and workflow controls, so the existing full/fallback route, complete-diff test-impact review, exact reviewed_sha, original source/staging gates and separate owner staging/admission/production decisions still describe it. Installing dependencies for the existing owning-acceptance job and fixing historical fixture source selection introduce no new operator command, event, permission or delivery lane. Current registered eight-shard platform source execution remains unchanged. |

Exact immutable guide-scope observation:

```text
base_sha: 3877546d29a04f235f9ec0f3175f4e0d90bfd60d
head_sha: c88399022d6b882e7e4a13fce5ede7c2ffafeddf
scope_sha256: 93aa03cf904508e0621f81e3edc3cfe60e5bf9b669069a9a5e2c5154b010ab05
decision: review-required; parser_required: true
```

All covered paths inspected (including the full protected-base changes, not just the correction):

```text
.github/repository-paths.json
.github/ri-ci-map.json
.github/workflows/issue-acceptance.yml
tests/article-candidate-source.test.cjs
tests/article-offline.test.cjs
tests/color-motion-contract.test.cjs
tests/content-release.test.cjs
tests/content.test.cjs
tests/edition-retention.test.cjs
tests/executive.test.cjs
tests/fixtures/catalog.cjs
tests/fixtures/delivery.cjs
tests/fixtures/publication-records.cjs
tests/reader-controller.test.cjs
tests/release-archive.test.cjs
tests/release-controller.test.cjs
tests/site-articles.test.cjs
tests/site-engine.test.cjs
tests/staging-regression.test.cjs
tests/test_issue213_acceptance.py
tools/quality/candidate-source.cjs
tools/quality/color-motion-contract.cjs
tools/quality/test-profiles.json
tools/release/edition.cjs
tools/staging/color.cjs
```

The path catalog diff was also compared structurally:133 added entries, three superseded loose historical PDF entries removed, zero modified existing entries. The additions retain canonical owners and distinguish history/generated/source roles. The RI/CI map retains its check routes and adds the owning policy; formatting and reviewed source identities do not introduce a new delivery model.

During review the shared checkout advanced to metadata-only `49a39fb9095f78c945e7a7a948b652f3c81829b4` (tree266e3e691fc704fd82ab07febdd45b1f4b06931d), changing only `.github/ri-ci-map.json` reviewed_source_identity and generated agent-context versus c883. A further actual guide-scope invocation at49a39 returned **ab5f38c7b3db3a7827825b75e51dab1ddfb322b606e0ff8e62c9365b65d1f81f**, with identical paths. Therefore the owner must not reuse c883's scope digest as the final record after metadata refresh. The guide content rationale above remains unchanged; this receipt's candidate judgment is c883 and it does not accept future source corrections.

## Execution limits and remaining evidence

This review is bounded source/artifact and operator-control review. The supplied logs are failed cb9 CI evidence, not corrected-source green results. No hosted browser, physical device, external publication, stable alias, protected merge, production or search measurement was exercised. Current-state GitHub admission is not independently claimed.

An affected local execution was started on the correction-equivalent shared sources:

```text
node --test tests/staging-regression.test.cjs tests/reader-controller.test.cjs tests/release-archive.test.cjs tests/release-controller.test.cjs tests/color-motion-contract.test.cjs
```

Its interim output confirmed F01, passed the exact generated plain/staging/production tuple reproduction, passed the full selected staging and historical production controller-consumer subtests, and passed the previously failing optional passive-diagnostic archive case. Final combined accounting is recorded below if completed within this review. Interim individual passes are observations only, not a suite/campaign pass. Local Node24.22.3 differs from CI's pinned24.19.0; F01 is directly explained by source membership and early return, not assigned to a Node-version hypothesis.

Required next actions: resolve F01 with preserved refusal behavior; use fresh affected independent review; bind the workflow-guide evidence to the actual final base/head/scope; run required exact-current-source checks and retain failed results. None of AC01–AC06 is marked complete here, and this review grants no release approval.

At artifact completion the broader execution remains active as tool session55976, with no final accounting available. Parent may retain its eventual raw completion separately; it supplies no pass in this first judgment. No additional diagnostic was started after the confirmed blocker.
