# Requirements & Acceptance preflight — issue 213 document-hook admission

Verdict: bounded correction is justified before further staging advancement; the current candidate fails its existing negative document-hook oracle. Preserve that oracle. This preflight is not completed-candidate acceptance or release approval.

Identity: distinct nonauthor Requirements & Acceptance execution `/root/issue213_hook_preflight`, 21 November 2026. The visible initial context contained platform/project instructions, the user AGENTS instructions and the assigned source packet; no author's conversation or peer verdict was supplied or read. Actual parent launch parameters/accepted response are not visible to this execution and must be recorded by the orchestrator. Provider context/model internals remain unknown. The source-packet instructions include historical candidate statements treated as subjects, not verdicts. Later parent message supplied an additional producer/SEO dependency for independent inspection; no peer output was read.

Inspected native source: clean worktree at `49a39fb9095f78c945e7a7a948b652f3c81829b4`; protected local main `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`. Native refs observed with `git show-ref --heads`; external live GitHub state was not re-read in this bounded, no-external-write task. Owner is the explicitly dated `issue213-owner.json` snapshot and original `issue213-ci-packet.md`; stable staging only is the latest stated authority. Production and merge remain separately gated.

Packet SHA256 verified: `cba15b9374a96496277ae508f210ab8b922ca532bfa4681bb30a058090342bbf`. Common reviewer SHA256 verified: `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`; Requirements role: `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. Read README, root AGENTS (the only inventoried AGENTS), map, dated MEMORY, relevant CONTRIBUTING, acceptance/RI/style/site/staging contracts and the owning AC policy. Some combined broad policy output was truncated; relevant independent-review/failure/oracle sections and actual dependency sources were then read directly.

## Finding and independent observation

**R-HOOK-01, high, blocks current trust/oracle advancement:** `tools/site/runtime-compatibility.cjs:118` returns before reading any document unless `components.client` is in `reviewedDocumentClients`. The current exact client `87f9590292adefa27641b1315e6b4292a871a7acf12b033eab5f2521433899ab` is explicitly registered as `issue213DiscoveryLink.baseEngine` in `tools/quality/color-motion-contract.cjs` and is the generated lock client, but absent from the document-verifier set. Consequently runtime-byte integrity succeeds while the document-hook assertions are bypassed.

Raw `quality-reports/issue213-ci/hook-first.tap` reports one test, zero passes, one failure: `tests/color-motion-contract.test.cjs:236`, missing expected `/client document hook space-motion/` exception. stderr is empty. The unchanged test independently establishes expected refusal for real missing motion hook, inert comment/template/script spoof substitutes, missing fallback class and footer; weakening these assertions would violate the existing contract.

A single bounded read-only diagnostic computed actual current fingerprints, then called `compatibility.verify` with a reader instrumented to count HTML reads and remove the real motion ID. Result: client and lock client both equal the above identity; verification returned successfully with **zero HTML reads**. This isolates the early-return mechanism rather than re-running the unchanged failed campaign. It does not claim browser coverage or full test acceptance.

## Minimal preservation constraints

1. Correct document-verification coverage for this exact already registered client. Retain all existing reviewed identities and the legacy version alias unchanged. Do not replace exact admission with arbitrary hash, marker, family-name or runtime-byte-only admission; do not change unknown/unregistered behavior as a side effect. Unknown valid fingerprints currently still undergo runtime-byte/fingerprint verification, then skip this reviewed-document contract; broader policy redesign needs separate intent review.
2. Preserve `fingerprint` inputs, producer freshness, cache/source identity, all five runtime/style bytes, route/article URL and immutable snapshot coverage. Admission must not waive the runtime-byte hash equality or fingerprint assertion. Retain route hook, unique typed real main/canvas/theme/motion hooks, exactly one footer/navigation, class hooks and meta contracts. Inert content must never satisfy a hook.
3. Preserve the original negative cases without removal, skipping, weaker regex expectations or fake fixtures. On the exact regenerated candidate, the existing producer-refactoring test must pass with its positive case and every missing-hook/class/footer/spoof/runtime/interface rejection active. Add focused coverage if needed to establish registered-current coverage and unchanged unknown policy; coverage must test behavior, not duplicate the set's text.
4. `build.fingerprints` hashes all `tools/site` bytes as producer dependencies, so an admission-source edit requires ordinary regeneration of dependent output/lock and freshness checks even when browser bytes remain identical. Verify old/new runtime bytes and unrelated rendered semantics, geometry, frozen dates/edition/history rather than assuming a no-runtime edit means unchanged output identity. Re-run required exact-source checks and affected independent roles after the code/outputs change.
5. Preserve frozen `review/issue-213/content-amendment.json` and its exact Research-link allowance. `tools/check_site_seo.cjs:socialCarrierProducer` uses exact approved historical record and explicit producer-successor hashes; there is no general producer fallback. Prefer a correction avoiding unnecessary `build.cjs` edits. If an affected producer changes, any new exact admission needs independently demonstrated historical-carrier byte/semantic equivalence and negative unregistered-producer refusal; do not loosen approved-record/schema/predecessor assertions or rewrite frozen amendment records to fit the result.
6. Keep existing budgets, selectors, test registries, source-to-check routing, human/editorial/rights/device gates and source/artifact/served-byte binding. Green bounded tests permit neither issue-wide AC completion nor production. Stable staging follows the existing authorized controller only after the required review/check gates.

## Acceptance linkage

| Intent/AC | Required check or decision | Observed status |
| --- | --- | --- |
| AC04 integrity, CS01/04/08/09/10 | Existing runtime/document contract negative oracle; bounded style/source checks | Existing hook refusal fails; exact early-return cause independently observed |
| AC03/04 truthful source/rendering and unchanged semantics | Frozen amendment + exact SEO, regenerated output/lock, byte comparison | Existing constraints inspected; new correction not yet implemented or verified |
| AC05 exact independently reviewed delivery | Fresh affected Requirements final, Code, White-box and Exploratory plus current-source mapped checks | Preflight only; all correction results pending |
| AC05 authorized release | Existing Preview → Stable Staging controller and exact served identity | Stable staging authority supplied; execution not observed here; production/merge not authorized |
| AC01/02/03/06 baseline, ownership, editorial, measurement | Original owner and nonautomated gates | Unchanged; this defect correction supplies no completion evidence |

Next gate: implement the smallest exact admission correction preserving these constraints, regenerate producer-bound outputs, and obtain fresh affected review and exact-candidate checks. No owner scope clarification is required for that bounded preservation fix. Any proposal to change unknown-client semantics, widen trusted producer policy, alter visible/runtime bytes or relax original acceptance requires renewed Requirements assessment before dependent implementation.

## Actual commands and source binding

Commands: `pwd`; scoped `rg --files`; `cat`/`sed`/`rg` on the named packet, owner, policy, instructions, raw failure and sources; `git -C author-site status --short/status --porcelain`, `show-ref --heads`; `sha256sum`; one `node` stdin diagnostic using `builder.configuration`, `builder.fingerprints`, `builder.runtimeVersion`, `compatibility.verify`, with an instrumented in-memory read callback and native `git rev-parse HEAD`. No implementation/test edits, external writes or delegation. Only this assigned artifact was written.

Inspected SHA256:

| Source | SHA256 |
| --- | --- |
| tools/site/runtime-compatibility.cjs | 86ae82d4cc0424be12d81d1559044b0e44501a9d38eafc72ee9e5d4fce7e94a4 |
| tests/color-motion-contract.test.cjs | 4c0623dbf53399d60c2fb6b2deb39b2ce39f95fe93bf42a592425486d1ec2838 |
| tools/site/build.cjs | 6832551602bee5d7281595e07bec7006cf9ccb97f3305638d0fe2bfe2879039b |
| tools/site/html.cjs | 386b6503b6166646e49895e6cd8af8d84b3596accc979731590dd1dc382d3c3b |
| tools/quality/color-motion-contract.cjs | f62e38d1534cf5a9d171b7e878d1deee262463ea9bf2c3f0d28f0eee87a7f0af |
| site/output-lock.json | 9ef58e2e280ee72c091ae1f2e28b801373f3317935ce00c6727c2f5ef0f5541f |
| quality-reports/issue213-ci/hook-first.tap | 7a397e1636639ff3651bd1ce0cd3e1f2dba009a2888cd991756c6d66cfd4ef96 |
| quality-reports/issue213-ci/hook-first.stderr | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
