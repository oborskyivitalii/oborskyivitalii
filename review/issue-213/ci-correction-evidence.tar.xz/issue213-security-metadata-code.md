# Independent Code / Artifact review — issue213 security metadata correction

Verdict: the factual metadata/proof correction is acceptable in this bounded scope. I found no new blocking defect in the corrected locator, source attribution, archive preservation or factual handoff. My independent full protected-base workflow-guide judgment is **unchanged** for `guides/REPOSITORY-WORKFLOW.md`; the existing text accurately describes the covered behavior. The tracked guide receipt is demonstrably stale and must be refreshed with this exact scope and judgment before dependent advancement. This review does not declare whole security, current-head CI, Stable Staging or any whole AC passed.

## Identity and boundaries

- Reviewer execution: `/root/issue213_security_metadata_code`, distinct nonauthor Code / Artifact role. No implementation, test changes, external writes or delegation performed. Provider model/context internals are unknown; parent must retain actual launch/isolation evidence separately.
- Repository: `/workspace/scratch/3f2ba1da2ac8/author-site`.
- Protected base: `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`.
- Previous candidate: `a9d558ab42b0fdff9b511c63c7d99226196d7531`.
- Reviewed candidate: `ae8dfd8d01dfd970428afc34cc8525595b2d152b`, tree `f69cd045bd41f2aa0d4940137eda20f8d1e9f1f1`.
- Source packet SHA256: `dcdffc47e34ce204a09452c97a8e4b6ca0f4bdfef5eb2b000fbcb6bd5897b5e6`.
- Common prompt SHA256: `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`; Code prompt: `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- All nine supplied material hashes matched. Read root AGENTS, README, map, MEMORY, common/Code contracts, relevant CONTRIBUTING/acceptance/style/check/security/workflow owners and actual scoped deltas. The inventory identifies only root AGENTS as applicable.
- No current peer result files or archived reviewer result contents were read. Candidate-authored handoff and guide receipt claims were inspected as subjects under review; archive member names and preservation hashes were inspected without accepting reviewer conclusions.
- `git ls-remote` observed main at the protected base and remote work branch at `7feb1c32dd65d643592057982ec12779c96b5cbc`; ae8 is a local prepared candidate, not the observed remote tip. Worktree was clean at review.

## Correction evidence and factual claims

The actual previous-to-candidate diff is seven files: generated RI, RI/CI map formatting, MEMORY, dated discovery review, correction archive, appended execution receipts and the fifth ledger locator. All implementation, test and workflow/oracle bytes are unchanged from a9d. The sole `tools/` delta changes only `secrets-issue213.json.scope` from the missing prepared-proof locator to the actual corrected member. Parsed RI/CI map content is identical to a9d despite formatting. The prior 36 execution receipt entries remain an exact prefix of the 42-entry candidate; this is a preservation check, not acceptance of those judgments.

The archive `review/issue-213/ci-correction-evidence.tar.xz` SHA256 is `02e4b1ae7aff0e956d6792c90e2d8c3a174df72ec13ef262eb2c5c49d5b0e192`. All 48 members present in a9d remain byte-identical. Original `issue213-secret-proof-prepared.json` remains SHA256 `cbd3174850f37b273b5a14379a557074078a8e2b18de6bd639675d4c3a24c3bb`; its final occurrence was attributed to 4aa. The corrected member exists, equals the supplied standalone bytes, and is SHA256 `bc7ea7f454b45c8334422f8d0db63ea614b4c7011e0a2c983978ca43e2024e4d`.

I independently checked every corrected record's raw report tuple (path/type/hashed value/line), archived source SHA256, byte equality to native Git source and source tree identity. All 324 occurrences matched: 318 from 7feb initial scan, five from 4aa full-correction scan, one from clean a9d Bandit-file scan. Each of the three report hashes matched its scan declaration. All 67 snapshot-manifest members matched declared size/SHA256 and the manifest equals its archived copy. Thus this is an explicitly labeled historical/current scan union, not a single-source result. Raw detect-secrets JSON itself has no source identity field; source attribution is the corrected proof plus immutable native/archived byte binding, not intrinsic scanner attestation.

The corrected last occurrence is `tools/quality/bandit-policy.json` line520, `Hex High Entropy String`, SHA1 identifier `50460f7c53b5d96b4b0871e076cfe7c1096cda8b`, source a9d/tree `0c1cb7bd9ce4a33136685d528f19ef944309a80e`; its archived source SHA256 is `c66c1f65978c38e5efcdad2bc202c2170e84cffb39de75086ee5c2dfb19048cc`. Recomputed referenced Python source and exact line hashes match the policy. The flagged line is the boolean report field `"pass": True,`, with expiry2026-12-06 unchanged. This correction restores attribution rather than expanding that allowance.

All 322 fifth-ledger IDs are covered by the proof; the proof's two additional IDs are the workflow receipt's base/scope fields handled by the separate dynamic checksum proof. All four older ledgers remain byte-identical to protected base. The changed locator retrieves the actual corrected proof without changing any ledger finding or detector guard.

`issue213-acceptance-a9d.json` is archived, matches supplied bytes/SHA256 `2aff3564c5a8d6ca0bac55b0de2ca96856b38e236826dd74737fec608e668741`, declares clean a9d/tree0c1c, and reports BASIC/CATALOG/DISCOVERY/PUBLISHING/RI/RI-CI/SEO/STYLE passed. This substantiates the handoff's bounded prepared-source eight-check claim, not a new ae8 execution or whole acceptance. Manual gates remain pending. MEMORY now accurately distinguishes Draft, failed pre-upload staging, prepared correction and pending exact-head admission/security. The supplied owner checkpoint corroborates staging failure after eight source shards and authorization limited to Stable Staging. No historical failed result is relabeled.

## Independent complete workflow-guide judgment

Recomputed command: `python3 tools/check_ri_ci.py guide-scope --base-sha 3877546d29a04f235f9ec0f3175f4e0d90bfd60d --head-sha ae8dfd8d01dfd970428afc34cc8525595b2d152b`.

Exact scope SHA256: `d0f05bdb70ead9d01e16a7604be3d9b9de2b07e7595efbe6b4840864026532f0`. The full 33-path scope is:

- `.github/repository-paths.json`
- `.github/ri-ci-map.json`
- `.github/workflows/issue-acceptance.yml`
- `guides/SITE-RELEASE-GATES.md`
- `tests/article-candidate-source.test.cjs`
- `tests/article-offline.test.cjs`
- `tests/color-motion-contract.test.cjs`
- `tests/content-release.test.cjs`
- `tests/content.test.cjs`
- `tests/edition-retention.test.cjs`
- `tests/executive.test.cjs`
- `tests/fixtures/catalog.cjs`
- `tests/fixtures/delivery.cjs`
- `tests/fixtures/publication-records.cjs`
- `tests/quality-sources.test.cjs`
- `tests/reader-controller.test.cjs`
- `tests/release-archive.test.cjs`
- `tests/release-controller.test.cjs`
- `tests/site-articles.test.cjs`
- `tests/site-engine.test.cjs`
- `tests/staging-regression.test.cjs`
- `tests/test_issue213_acceptance.py`
- `tests/test_python_toolchain.py`
- `tools/quality/bandit-policy.json`
- `tools/quality/candidate-source.cjs`
- `tools/quality/color-motion-contract.cjs`
- `tools/quality/generated-checksums.cjs`
- `tools/quality/python_toolchain.py`
- `tools/quality/scanners.cjs`
- `tools/quality/secrets-issue213.json`
- `tools/quality/test-profiles.json`
- `tools/release/edition.cjs`
- `tools/staging/color.cjs`

I inspected the complete protected-base covered delta, including workflow installation selection; catalog additions/removals and RI owner routing; retained-source adapter threading and historical fixture isolation; test dependency/profile selection; exact runtime registration and SEO negatives; the fifth closed ledger, guide-field checksum proof, exact dependency override and expiring Bandit rebind. The overview guide itself is unchanged from protected base. Section-specific dispositions:

| Actual section | Disposition and independent rationale |
| --- | --- |
| Harness and ownership | Unchanged. Existing issue/acceptance-policy, RI canonical-owner/check, versioned evidence and five-section factual MEMORY descriptions cover the added issue213 mappings, dated proof and recovery handoff. Catalog changes add136 paths and remove only four redundant archived PDFs; they do not create another authority owner. |
| Agents and orchestration | Unchanged. Existing fresh independent role, correction/review, source/prompt/oracle continuity, first-result preservation and pending/stale gate rules accurately cover this correction. Hash continuity does not silently supply a new role verdict. |
| Keeping this guide current | Unchanged. Existing committed base/head/path scope, substantive independent judgment and updated/unchanged receipt protocol directly describes the new dynamic proof's checker dependency. The proof requires a clean committed receipt, actual main ancestor and successful maintained guide review; it admits exact base/scope fields, not arbitrary prose or copied hashes. The stale receipt is rejected, matching the documented pending gate. |
| Site architecture | Unchanged. Existing source-owned retained artifacts, separate cache/baseline/archive boundaries and platform verification for template/toolchain changes accurately cover explicit sourceRoot retention, immutable fixture history, native-link policy dependency and exact runtime tuples. Defaults and trusted origin/effect/release policy remain module-owned. This introduces no architecture or publication route. |
| Delivery routes and controls | Unchanged. Full route for shared/mixed changes, current-head checks before owner staging, failure preservation, source revalidation and separate merge/production approval remain accurate. Fifth exact Semgrep compatibility override, checksum ledger and source checks are implementation details routed to the existing release-gates owner, which is updated in this candidate. No exemption from security or staged admission is introduced. |

Separately, `guides/SITE-RELEASE-GATES.md` **is updated** in its real “Security and source quality” section: five exact compatibility declarations now include wcmatch~=8.3→11.2 with bracex3.2, actual API/CE controls and unchanged distribution/advisory boundaries; the added paragraph accurately describes a fifth finite ledger, preserved tuple/schema/duplicate/2MB guard and exact dynamically verified guide fields. Those changes document the protected-base implementation without requiring duplication in the overview.

A suitable receipt rationale is: “The existing Harness and ownership, Agents and orchestration, Keeping this guide current, Site architecture and Delivery routes and controls sections already describe issue-owned checks and RI routing, independent source-bound correction review, exact committed guide-scope evidence, source-specific retained artifacts, full mixed/platform verification and separately authorized staging/merge/production. The finite ledger, checked guide-field proof and exact dependency compatibility correction preserve those routes; security details are updated in SITE-RELEASE-GATES.md#security-and-source-quality.”

## Gates, actual checks and limits

`guide-review` returned exit1 with the required new d0f05b scope: tracked `workflow-guide-evidence.json` still contains bd1a8345 and25 paths. This is the known missing mechanical refresh; it must not be represented as passed before refresh. Record my above unchanged disposition, exact paths/scope and execution reference. Any further covered-source change requires recomputation and affected judgment.

Actual read-only checks: all packet/archive/source/manifest/report comparisons above; native Git refs/status/diffs; `check_ri_ci.py guide-scope` passed; `check_ri_ci.py verify` passed (17 checks/20 layers); RI verify reported fresh. `guide-review` failed as expected on stale receipt and is retained as a pending prerequisite. I did not rerun security scanners, advisories, full owning tests, hosted CI or browser/staging. Newly offered ae8 advisory output was not needed for this bounded metadata judgment and was not inspected. No broad semantic retriage of every old public identifier, provider attestation, live PR-state attestation or deployment observation is claimed.

AC impact: corrected durable provenance and recovery make the bounded prepared security-source evidence reviewable. All six whole issue ACs, current whole security/CI and authorized stable delivery remain open/pending until their actual gates complete. No owner/release approval is supplied by this review.
