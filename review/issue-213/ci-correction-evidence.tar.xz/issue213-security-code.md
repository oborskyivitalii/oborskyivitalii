# Independent Code / Artifact review — issue213 security correction

Execution: `/root/issue213_security_code`, fresh independent correction and complete protected-base workflow-guide judgment. Reviewed repository `author-site`, previous `7feb1c32dd65d643592057982ec12779c96b5cbc` → candidate `a9d558ab42b0fdff9b511c63c7d99226196d7531`, tree `0c1cb7bd9ce4a33136685d528f19ef944309a80e`; guide comparison additionally starts at protected `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`.

Packet SHA256: `510b846c66f94923e4bfffcd0d69d49d1d96f7ee649ac60e7a1c79994eb0d85d`. Every listed material's actual hash matched. Common contract SHA256 `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`; Code prompt SHA256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`. Read root instructions, README, map, dated MEMORY, iteration contract, style, RI and security/release owners, owner snapshot and supplied primary reports. No current peer/preflight verdict was read. Candidate receipt/proof prose was treated as a review subject. No implementation, external writes or delegation occurred. Actual launch arguments/provider internals are parent-observed facts, not independently attestable here.

## Verdict

No new blocking implementation defect found in the reviewed security/compatibility changes. The source-bound false-positive dispositions, exact fifth compatibility override and R29 recovery are supported by the bounded primary inspection below. Advancement remains held by the known stale guide receipt, missing versioned triage-proof member and absent current-head successful integrated security report. This review supplies neither whole-AC acceptance nor staging/merge/publication authority.

### Evidence prerequisites

**SC-E01 — blocking before advancement: stale workflow-guide receipt.** `review/issue-213/workflow-guide-evidence.json:3` still records `bd1a83452f8aedc06ac378dd386067a2307c36ecf63af6977a30be102f52bdcf` and 25 paths. My fresh committed-scope calculation reports 33 paths and `7f0bb560a1e8bacc552e60c9479cd7e12b7aa330a7b2fd40f528b04732ff63f6`. Actual `guide-review` fails on that mismatch. This was explicitly declared pending in the packet; it is not an unexpected regression. Rebind base/scope/paths and this execution reference after adopting the independent guide judgment below, then verify the actual committed successor. A stale receipt must continue to supply no dynamic checksum proof. Affects AC04/current-source admission.

**SC-E02 — blocking evidence persistence before advancement:** `tools/quality/secrets-issue213.json:7` says its per-ID proof is preserved at `review/issue-213/ci-correction-evidence.tar.xz#issue213-secret-proof-prepared.json`. I inspected that archive's member inventory: no such member exists at a9d. The supplied scratch proof is accessible and hash-verified, so this does not invalidate my review inputs, but the committed locator is presently unresolvable. Preserve the supplied exact proof (SHA256 `cbd3174850f37b273b5a14379a557074078a8e2b18de6bd639675d4c3a24c3bb`) at the named locator or correct the locator to an actual durable, source-bound member. Verify the added bytes and unchanged meaning; do not substitute a summary. Affects AC04/auditable exact-tuple false-positive evidence.

**Current-source limit:** the supplied full tracked security report belongs to `4aa739ab3c5047de883f5f1995973b28bdfa2d0f`, tree `190f522a051d755b5834e7e520e50f88e8a7d20a`, and explicitly fails Bandit and secrets. Its retained error is an old Python source binding plus seven untriaged findings. Current a9d supplies the exact Bandit rebind and five new ledger tuples; the remaining two guide-receipt tuples await fresh guide proof. I did not run a duplicate full scan or claim that these deltas already constitute a successful current security/staging campaign.

## Security and compatibility inspection

- The fifth closed ledger contains 322 unique exact path/rule/hashed-value tuples and is 155,234 bytes, within the unchanged 2,000,000-byte bound. All four preexisting ledger files are byte-identical to 7feb. Schema, safe-path, nonempty rationale, exact ID, date, duplicate and file/symlink checks remain. Hex-only admission has only the finite four new inventory Base64 tuples, each separately ledgered; neighboring files and unknown types/values remain unadmitted. New tests include forbidden types, malformed metadata, copying a scope value into prose, dirty receipt bytes, wrong scope, changed controls and absent main identity. Existing cross-ledger integrity tests now include the new ledger as an unauthorized source.
- Supplied proof has 324 distinct records across 66 files: every one of the 322 ledger tuples has a keyed proof record; two guide-field records are deliberately dynamic rather than ledgered. I checked the actual occurrence line/hash for all Hex records (the sole non-contiguous exception is the already-reviewed public beacon token, which is not a 40/64-digit identifier), validated all 231 direct file-hash/Git-object witnesses and all 37 named archive-member SHA256 witnesses without reading archived peer verdict contents. They matched. The remaining field/domain-specific witnesses describe public rights, publication, semantic/SVG, material, byline, Color, source-equivalence and report identities rather than credential use; these are finite classifications, not an entropy-shape exemption. The five newly ledgered 4aa deltas bind the exact R29 archive/member hashes, two existing directory hashes in refusal fixtures and an immutable Git fixture commit. The sixth new ledger item binds the actual Python source hash in the Bandit policy. The guide base/scope values are correctly kept out of the static ledger.
- `collectGuideChecksumFields` asks the maintained committed-source checker for the actual origin/main merge ancestor and unique changed issue receipt, requires clean tracked bytes and exact successful result/base/scope/receipt, then admits only the two JSON fields at their parsed token positions. Other occurrences of the same value invalidate the whole value's bypass. The proof source identity includes HEAD/tree/main identity and guide/RI control inputs. No acceptance of the receipt's prose is inferred from its hash. Parent-controlled code/environment remains trusted tooling, consistent with the existing boundary.
- Python verification allows exactly the five reviewed Semgrep1.185.0 declaration→installed pairs; it still rejects extra/missing/unfrozen/incompatible graph edges and requires each override exactly once. Only wcmatch8.5.2→11.2 and bracex3.0.1→3.2 change in the lock. I executed the installed pinned verifier: 92 packages, 149 active dependencies, five overrides, pass. Nine Python verifier tests passed. Four direct `glob.globmatch` positive/negative brace/globstar cases passed against the installed patched API.
- Actual supplied CE1.185.0 git-controlled fixture scan detects exactly the two expected positive findings, no negative finding and no errors; navigation smoke scans the actual file without errors/findings. The earlier nongit control report has zero hits and cannot independently establish positive detection. The full 4aa Semgrep report is retained as successful engine coverage, not as whole security success. Supplied full pip-audit graph contains all 92 packages and zero reported vulnerabilities, including Semgrep1.185.0/wcmatch11.2/bracex3.2. This is the observed feed/report result, not a future advisory guarantee.
- Bandit policy comparison changes only the Python entry's source SHA256, line124→125 and appended rationale; all other parsed entry fields and policy entries are unchanged. The actual Python diff adds the fifth exact pair and comment. The return statement bytes are identical; retained raw Bandit still reports B105/LOW/MEDIUM at125. The actual current source SHA256 matches the new policy. No expiry, severity, rule, owner, line-content hash or allowance expansion occurs.
- R29's deleted loose PDF exactly equals `article.pdf` extracted from the unchanged native TAR.XZ: 1,417,566 bytes, SHA256 `7939f15ebfe1ac2588c0cedc79f53f4400d1a0271b174df732e4b0c2447ed7d1`. Archive SHA256 `038392346ededf1852b91981ae8f8826551e5202ce6ddfaa6d57e81d1ff1e089` matches the manifest and protected-base bytes. README points to the actual member. No active tools/site/tests reference the removed loose file or archived renderer. Recovery requires extraction only, no active generator.
- Supplied primary source-suite TAP records 43/43 pass, zero failure/skip/cancel/todo. I inspected affected tests and reused that raw bounded evidence without rerunning the broad suite. Its source must remain labeled as the supplied run, not renamed a new a9d integrated guard pass.

## Independent complete protected-base guide judgment

**Disposition: unchanged is accurate for `guides/REPOSITORY-WORKFLOW.md`.** I reviewed the complete covered protected387→a9d path set and actual diffs, including source-root threading, historical fixture isolation, native-link tests, test-selection additions, issue-policy installer conditions, exact Color family, RI mapping and the new security changes. The guide is an architectural/workflow overview whose linked owners retain detailed tool versions and finite security dispositions. It already describes these changes accurately; no new route, authority, actor or live publishing behavior is introduced.

Actual affected sections and rationale:

| Section | Independent assessment |
| --- | --- |
| Harness and ownership | New issue213 checks, unchanged finite review evidence and deterministic RI registration stay in their existing issue/PR/source owners. |
| Agents and orchestration | The changes retain fresh separate correction judgments, source-bound packets and pending/stale holds; they add no agent execution mechanism. |
| Keeping this guide current | The new dynamic checksum proof consumes this existing exact committed base/scope/receipt contract. It does not replace independent judgment or protected owner attestation. Current stale receipt correctly fails. |
| Site architecture | Native link aliasing, profile dependencies and explicit retention-source reconstruction stay in the existing publisher/build/adaptor boundary. Runtime/CSS remain separately verified. Historical fixture seeds do not become current content owners. |
| Delivery routes and controls | Current scanners, full lock change verification, exact candidate reconstruction, finite Color descriptors and failure preservation remain under existing full/current-source controls. Stable staging, protected merge and production remain separate decisions. |

Exact fresh guide scope:

```json
{
  "base_sha": "3877546d29a04f235f9ec0f3175f4e0d90bfd60d",
  "scope_sha256": "7f0bb560a1e8bacc552e60c9479cd7e12b7aa330a7b2fd40f528b04732ff63f6",
  "paths": [
    ".github/repository-paths.json",
    ".github/ri-ci-map.json",
    ".github/workflows/issue-acceptance.yml",
    "guides/SITE-RELEASE-GATES.md",
    "tests/article-candidate-source.test.cjs",
    "tests/article-offline.test.cjs",
    "tests/color-motion-contract.test.cjs",
    "tests/content-release.test.cjs",
    "tests/content.test.cjs",
    "tests/edition-retention.test.cjs",
    "tests/executive.test.cjs",
    "tests/fixtures/catalog.cjs",
    "tests/fixtures/delivery.cjs",
    "tests/fixtures/publication-records.cjs",
    "tests/quality-sources.test.cjs",
    "tests/reader-controller.test.cjs",
    "tests/release-archive.test.cjs",
    "tests/release-controller.test.cjs",
    "tests/site-articles.test.cjs",
    "tests/site-engine.test.cjs",
    "tests/staging-regression.test.cjs",
    "tests/test_issue213_acceptance.py",
    "tests/test_python_toolchain.py",
    "tools/quality/bandit-policy.json",
    "tools/quality/candidate-source.cjs",
    "tools/quality/color-motion-contract.cjs",
    "tools/quality/generated-checksums.cjs",
    "tools/quality/python_toolchain.py",
    "tools/quality/scanners.cjs",
    "tools/quality/secrets-issue213.json",
    "tools/quality/test-profiles.json",
    "tools/release/edition.cjs",
    "tools/staging/color.cjs"
  ]
}
```

Limits: live remote issue/PR/check/deployment state was not re-fetched in this read-only bounded review. Local refs and clean candidate state were observed; owner intent came from the supplied source-bound snapshot. No browser/device, production, full current staging or whole-issue acceptance claim is made. All six whole issue criteria remain open.
