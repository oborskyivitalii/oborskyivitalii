# Independent Code / factual metadata and final guide review

Execution: `/root/issue213_final_guide_code`, 2026-11-21. Read-only review; only this assigned report was written. No implementation, external writes, delegation, or archived peer report conclusions were used. Candidate receipt summaries were examined as claims under review; archived reviewer members were hashed without reading their conclusions. Provider internals and the parent launch transcript are not independently observable in this execution.

Verdict: the maintained workflow guide accurately describes the complete covered protected-base change. **Disposition: unchanged.** No substantive guide correction or runtime correction is needed for this review. The committed earlier guide receipt is stale and must be rebound before advancement; this report supplies the fresh final-scope judgment, not CI, staging or whole-AC acceptance.

## Source identity and inspected scope

- Repository: `/workspace/scratch/3f2ba1da2ac8/author-site`; clean working tree observed, HEAD and work branch at `e025325a7a5900e506aa2e53047080252cac413c`, tree `ad34f22813a90b96ebeb81d96293058b0aa427e0`.
- Protected comparison base: `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`; metadata predecessor: `a766fe0a2acffb176876ee578a4d75827ce45a7d`.
- Packet SHA-256: `04db2af04c1e234da6e5cf41217fd5cf97c6c07687cd0b2e57b3edf48416d72c`; all four declared material hashes independently match.
- Common reviewer contract SHA-256: `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`; Code prompt: `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Full final covered scope SHA-256: `bd1a83452f8aedc06ac378dd386067a2307c36ecf63af6977a30be102f52bdcf`.
- Workflow guide SHA-256: `cec5fd9748792cfb7aa1b7bfa734fca4e0bfd695fb367c76f7b89b57ed1c21d0`; guide bytes unchanged from protected base.

Read README, root AGENTS (the only applicable AGENTS), CONTRIBUTING iteration/acceptance/memory rules, REPOSITORY-MAP, MEMORY, reviewer contracts, guide and guide index, acceptance owner, relevant CODE-STYLE and delivery/check-profile owners. Inspected the complete 25-path covered diff, catalog roles/owner changes, and related actual publisher/build/runtime-compatibility sources. Inspected all eight paths in the a766→e025 metadata delta, including exact archive member hash provenance, rather than accepting review verdicts as source proof.

Exact covered paths:

```text
.github/repository-paths.json
.github/ri-ci-map.json
.github/workflows/issue-acceptance.yml
tests/article-candidate-source.test.cjs
tests/article-offline.test.cjs
tests/color-motion-contract.test.cjs
tests/content-release.test.cjs
tests/content.test.cjs
tests/edition-retention.test.cjs
tests/executive.test.cjs
tests/fixtures/catalog.cjs
tests/fixtures/delivery.cjs
tests/fixtures/publication-records.cjs
tests/reader-controller.test.cjs
tests/release-archive.test.cjs
tests/release-controller.test.cjs
tests/site-articles.test.cjs
tests/site-engine.test.cjs
tests/staging-regression.test.cjs
tests/test_issue213_acceptance.py
tools/quality/candidate-source.cjs
tools/quality/color-motion-contract.cjs
tools/quality/test-profiles.json
tools/release/edition.cjs
tools/staging/color.cjs
```

## Actual guide sections and independent rationale

| Actual section | Disposition | Source-based rationale |
| --- | --- | --- |
| Harness and ownership | unchanged | Issue213 adds its own bounded acceptance mapping and catalog entries, retaining issue-owned intent, Draft/Ready execution, named checks, pending human gates and five-section dated handoff. No new authority or source owner is introduced. |
| Agents and orchestration | unchanged | New archived correction receipts retain distinct role identities and bounded source claims. Existing text already requires fresh correction review, exact packet/source binding, pending-evidence holds and separation of parent observation from provider assurance. Receipt addition does not implement a new dispatcher or widen the offline component. |
| Keeping this guide current | unchanged | Actual checker computes immutable base/head covered scope, catalog/control changes and guide bytes; excludes the designated guide receipt itself. Existing instructions already require new evidence when covered bytes/base change. This is exactly why a766 evidence cannot admit e025. |
| Site architecture | unchanged | Native canonical aliases and production-origin dependency remain build-time article concerns, with explicit inputs and warm/cold invalidation. Native links remain ordinary static links. Explicit sourceRoot now supplies retention declarations to reconstruction; trusted rendering/effect/origin policy stays module-owned. Existing architecture and three separate cache/baseline/frozen-archive boundaries remain accurate. |
| Delivery routes and controls | unchanged | Issue workflow adds pinned dependency preparation; registry adds affected producer dependencies and issue-policy selection, without removing existing routes. Historical fixtures bind their own real source tip/retention/rights, and the exact current client family is added to document-hook validation. Source tests still cannot authorize baseline reuse, bypass full fallback, promote staging, merge, or publish. Existing test-impact/failure-preservation and exact-source owner decision requirements describe the actual behavior. |

The protected diff retains all existing source/profile and release checks, includes meaningful negative cases for explicit-source retention tampering and canonical collision/unapproved URLs, and preserves the existing document-hook refusal test while registering the exact new client. It does not relax unknown fingerprints or budgets. Confirmed unchanged protected `site/engine`, `site/scenes`, `site/effects`, and `tools/quality/budgets.json` bytes. Site runtime/CSS claims are thus bounded byte facts, not a dynamic browser guarantee.

## Factual receipt/catalog/memory delta

The a766→e025 delta changes only RI generated projection, catalog, RI-CI identity, MEMORY, dated review, archive, execution receipts and guide evidence. No tests, tools, workflow, issue policy or website source changed in that delta. The two added catalog entries are accurately historical review artifacts owned by REVIEW-TEMPLATE; generated RI and RI-CI identity verify current bytes.

All ten new archived own-result byte hashes match their receipt entries. Archived final packets match `c69c1079e91cbdbc5019162f75ed97044a1e3fd88416b2f1eacb76d7f251c0e1` and `a5f336a8da5e924511922a4d23cbaa026ab699c0061e5e7b9f3b08fddf06a70a`. This establishes retention/provenance, not reviewer correctness or provider isolation. Parent-observed launch descriptions cannot independently establish provider internals; the candidate acknowledges that limit.

Archived acceptance-a766 bytes exactly match the supplied primary raw report SHA-256 `694237729d6e1e16e2468228e6b784787cc7060121924ef045eb16eabe8b311e`. That report identifies clean a766/tree `0a251594c3aa7886eafe4ea7dfd2907888dbaf1b`, all eight mapped checks passed, pending manual gates and `ready_for_issue_closure: false`. It is correctly described as a766 evidence, never as a new e025 campaign. Archived raw final Color accounting is 38/38 with zero failures/skips, and raw regression stderr records RI-CI28 and RI40 successful tests. The first hook failure is retained and independently shows a missing expected document-hook exception. The actual source diff adds only the explicit client to the existing registry. The claim's failure mechanism and bounded correction agree.

MEMORY keeps all six whole ACs open, distinguishes earlier Preview from corrected source, calls out final binding/current-head CI, and scopes authorization to Stable Staging. That agrees with the supplied current user-intent packet. I did not independently observe current GitHub PR Ready state, new CI, author visual approval, or staging; MEMORY remains a dated handoff requiring live revalidation. Existing old Preview is not evidence that e025 was served.

## Finding and required disposition

**FG-C01 — advancement blocker until receipt rebinding (known pending metadata step).** `review/issue-213/workflow-guide-evidence.json` still has `scope_sha256=ac43e6eeb13d8ca25e45e999d309356b144155c6ef110f3a0bfb855fb9824fe2` and points to the a766 reviewer execution. Current immutable guide-scope returns `bd1a83452f8aedc06ac378dd386067a2307c36ecf63af6977a30be102f52bdcf`; guide-review rejects the committed receipt with “Add a current review”. This affects exact-source guide/Navigation evidence and AC05 advancement. Bind the receipt to this independently reviewed final scope, preserve the 25 exact paths, record unchanged and the actual sections/rationale above, and reference this own result. Do not edit runtime, oracles or budgets to solve a receipt mismatch. Recheck final committed guide scope and required current-head gates after adding the verbatim excluded receipt; any covered source change needs affected re-review.

No additional substantive blocker found in this bounded factual/guide review. Existing editorial/device/rights/search/schema/measurement/release obligations remain as recorded; none is waived.

## Actual checks and limits

Executed guide-scope and guide-review against immutable base/e025; observed the exact stale-receipt rejection. Executed `python3 tools/check_ri_ci.py verify`: passed, 17 checks/20 layers, source digest `1d2103a11b63d24deeee88844f08215f0c20b6471d302c93ef316294e6870888`, explicitly no live GitHub verification. Executed RI verify: fresh. Verified packet/material/archive/result hashes and bounded raw log accounting. No full source campaign, hosted/mobile/no-JS/PDF interaction, stable deployment, protected admission, merge or production was executed or claimed. Remote refs, current PR/check state and actual launch acceptance remain the orchestrator's live-evidence responsibility.
