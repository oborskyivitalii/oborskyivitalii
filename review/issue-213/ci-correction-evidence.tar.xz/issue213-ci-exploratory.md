# Issue 213 — independent Exploratory / operator QA

Verdict: **No new operator defect found in the bounded CI correction. Advancement remains held for a current guide receipt and actual current-source check/staging evidence.** This is an operator-workflow judgment, not issue acceptance or a successful hosted campaign.

## Identity and scope

- Role/execution: Exploratory / Interaction QA, `/root/issue213_ci_exploratory`, first completed judgment for this CI-correction packet. Nonauthor; no implementation, external writes or delegation performed. Only this assigned artifact written.
- Repository: `/workspace/scratch/3f2ba1da2ac8/author-site`; protected base `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`; correction candidate `c88399022d6b882e7e4a13fce5ede7c2ffafeddf`, tree `73de091cad15b2c6c8f82b99c4d176cf0a7c3f7a`; prior `cb9c219f12e469860fd35213c5bd951932306f7a`.
- Final packet SHA-256 verified: `c69c1079e91cbdbc5019162f75ed97044a1e3fd88416b2f1eacb76d7f251c0e1`. Every referenced material matched its declared SHA-256 on read. Factual packet `issue213-ci-packet.md`: `b675b3d395fc990d5a5677d0f07ced3fccfdc9473b6b30ccec68f082426bbe54`; owner snapshot `issue213-owner.json`: `6c0a278381c18f7b0db52bbe7326b6d81facd285d6b7f18aaa7f5bf6db3cd855`.
- Read common contract `agents/reviewers/README.md`, SHA-256 `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`; role `agents/reviewers/exploratory-interaction-qa.md`, SHA-256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Read root instructions, README, repository map, dated MEMORY, relevant CONTRIBUTING/acceptance/RI/style/check-profile/staging/workflow-guide owners, supplied owner snapshot and actual correction diff. Only root AGENTS.md was found. No current peer/preflight artifacts read. Supplied candidate/historical claims were treated as review subjects, not accepted verdicts. Requested isolation is stated in packet; accepted launch parameters/provider context internals require the orchestrator's separate receipt and are not independently visible here.
- Charter: in at most 15 minutes, walk policy ownership selection and refusal partitions; trace selected issue213 into the existing pinned setup steps; inspect actual failure/report retention; execute guide-scope/guide-review against committed c883; inspect source/report boundary. No new product UI claim. Seven changed files from cb9 to c883 are workflow/test fixtures; no site/docs/production-tool/policy delta.
- Environment: Linux bash, local Node `v24.22.3`, Python `3.12.14`; raw GitHub logs show Node `v24.19.0`. No browser/device or new GitHub execution used. Current live remote refs were not fetched by this reviewer; local refs and supplied immutable logs were inspected. Stable staging authorization in the supplied user instruction is distinct from production/merge authority.

## Source movement disclosed

Shared checkout moved during review from c883 to `49a39fb9095f78c945e7a7a948b652f3c81829b4` (tree `266e3e691fc704fd82ab07febdd45b1f4b06931d`), with clean working tree. Independently ran `git diff --stat c883..HEAD`: only `.github/repository-intelligence/agent-context.json` and `.github/ri-ci-map.json` changed. Verified identical Git blobs at c883 and49a for acceptance workflow, runner, checker, issue213 policy, common/role prompts and workflow guide; all seven correction files are unchanged. Actual selection/source-refusal executions below bind49a and must not be relabeled c883. Explicit immutable guide commands bind c883. No full latest-head RI/acceptance pass is inferred from equivalence.

## Executed journeys and observations

CLI selection probes used JSON supplied to `/dev/stdin` and `--github-env /dev/null --report /dev/null`; stdout retains the actual runner result without writing another artifact. Command shape: `python3 -B tools/issue_acceptance.py select --event /dev/stdin --event-name EVENT --github-env /dev/null --report /dev/null`. These diagnostic sinks test selection, not persistent report/env-file round trips.

| Case | Expected | Observed / status |
| --- | --- | --- |
| PR body `Refs #213` plus incidental `#31` | Select exactly issue213 | Exit0; policy `.github/acceptance/issue-213.json`, SHA-256 `a598cde4f5956cd283899bbd8d090af9edf6a7bfe5a9a1f3ebba690bded6cdbc`; source49a, clean. Executed/pass. |
| Dispatch `issue_number: "213"` | Same policy | Exit0; same policy/digest/source. Executed/pass. |
| PR `Refs #213` and `Refs #31` | Reject ambiguous ownership | Exit1; selection null; `PR needs exactly one explicit local owning issue; missing or ambiguous Refs`; no closure/pass. Executed/pass. |
| Incidental issue213 URL without Refs line | Reject absent ownership | Exit1 with the same missing/ambiguous error; selection null. Executed/pass. |
| Dispatch `213;echo bad` | Reject nonnumeric value | Exit1; `Dispatch needs a bounded numeric issue_number`; no command execution. Executed/pass. |
| `validate --policy .github/acceptance/issue-213.json` | Admit six mapped AC IDs | Exit0; AC01–AC06 and exact policy digest above. Executed/pass; validation is not check execution. |
| `run ... --report acceptance-should-not-exist.json` | Refuse checkout-local report before checking/writing | Exit2; `The acceptance report must be outside the checkout`; no report created. Executed/pass. |
| API `run_policy(... require_clean=True, expected_source="0"*40)` | Fail source mismatch before tests | `Expected source does not match exact checkout HEAD`; checks empty, all six criteria not-run, gates pending, evidence_valid/automation_pass/ready_for_issue_closure false. Actual API diagnostic/pass; not a CLI full run. |
| `check_ri_ci.py guide-scope --base-sha 3877546... --head-sha c883990...` | Describe complete covered committed scope | Exit0; decision review-required, parser_required true,25 covered paths, scope digest below. Executed/pass. |
| Same explicit base/head `guide-review` | Refuse without exact matching independent receipt | Printed `Add a current review in review/issue-N/workflow-guide-evidence.json` and exact scope. Executed/expected refusal. This is a pending advancement gate, not successful guide admission. |

Initial diagnostic sink failure is retained here: five first selection attempts used `--report /dev/stdout`, which Path.resolve converted into `/proc/<pid>/fd/pipe:[...]`; each exited1 with FileNotFoundError on report write. Those attempts did not establish selection outcomes. Diagnosis was the diagnostic pipe sink, outside documented ordinary-file usage, not a correction regression. The bounded next probe changed only the sink to `/dev/null`, which resolved the write failure and exposed actual selection stdout. No unchanged failed hosted campaign was rerun.

## Pinned setup reachability and actual retained failures

Actual raw `issue213-ci-136927372305.log` lines289–354 establish that cb9 selected issue213 correctly, immediately reached `run` without installing its tools, failed with format-parity helper venv Python ENOENT, then reported automation_pass false, AC02/03/04 failed, AC05 automated-pass, AC01/06 manual-only-pending, all12 gates pending, closure false. The always-upload step retained15930bytes in artifact14718150023, run44931000093. This is real negative evidence and report preservation, not a new green run.

At c883, inspected all setup branch predicates against the actual selected literal. Issue213 now reaches each of four steps: quality npm install, pinned Python3.12.14 setup, locked Python install (`ruff==0.16.10`, `PyYAML==6.0.3`, `packaging==26.3`), and publisher npm/locked media dependencies. Existing action SHAs and lock/install commands are unchanged. The later Markdown-only branch remains false for issue213; the required same publisher npm prefix is already installed by its publisher branch. This is source-level reachability evidence; actual fresh-host installation/run success remains not observed.

Inspected all eight supplied raw-log identities and failure signatures. The six source-shard logs retain reader/archive/controller snapshot ENOENT or current `issue213-discovery-link-*` versus stale `issue183-long-article-*` assertions (including motion tuple differences). The correction diff threads each fixture's explicit authoredRoot through existing adapters and updates current-motion expectations to the already registered issue213 family. These observations support the bounded repair's mechanism; they do not replace corrected suite execution or assert all refusal cases passed. `quality-reports/issue213-ci/affected.json` was empty when read; no completed campaign accounting was available from that file at that time.

## Guide operator handoff and finding

Exact c883 guide-scope result:

- base_sha `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`
- head_sha `c88399022d6b882e7e4a13fce5ede7c2ffafeddf`
- scope_sha256 `93aa03cf904508e0621f81e3edc3cfe60e5bf9b669069a9a5e2c5154b010ab05`
-25 paths include acceptance workflow plus all covered prior producer/adapter/test/profile controls; this is not just the seven-file correction scope.

**E01 — medium, known pending control gate:** c883 lacks `review/issue-213/workflow-guide-evidence.json` satisfying this scope. `tools/check_ri_ci.py` guide-review refuses as designed; raw navigation failure `issue213-ci-136927371860.log` originally showed the same missing-receipt class for the older scope. A stale cb9 scope digest cannot admit c883. Affected requirement: AC05 REVIEW/RELEASE and current workflow-guide admission. Treatment: obtain the independent changed-artifact guide judgment, record its execution, exact base/scope/paths, real section titles, updated/unchanged disposition and substantive rationale in the existing receipt route; rerun current-source navigation/guide validation. Do not invent a completed review or tick whole ACs.

The operator can find the command, receipt path, mandatory fields and next exact-head attestation in `guides/REPOSITORY-WORKFLOW.md` → **Keeping this guide current**. **Delivery routes and controls** names the Ready/source/navigation/owning prerequisites, separately authorized staging, stable-alias behavior, PR refresh and protected admission/merge. The source repair does not introduce a new user-facing delivery route. These existing sections provide usable navigation for this correction. Whether the whole protected-base control delta warrants substantive guide text changes remains the separately required Code review judgment; this operator walkthrough does not substitute for it.

## Regression allocation, limits and disposition

| Case / requirement | Existing route / owner | This review |
| --- | --- | --- |
| Owning selection, ambiguous/missing refs, numeric dispatch, source/report binding | Existing generic acceptance-runner regressions through Navigation; `.github/ACCEPTANCE.md` / `tools/issue_acceptance.py` | Actual bounded CLI/API diagnostics above; no new tests authored. |
| Pinned issue213 setup availability | `.github/workflows/issue-acceptance.yml`, Ready PR/explicit dispatch owning check | Source reachability inspected and original negative CI retained; fresh hosted positive pending. |
| Corrected motion and explicit-source fixture behavior | Registered changed-path source suites in `tools/quality/test-profiles.json`, PR source and ordinary platform staging source profile per SITE-CHECK-PROFILES | Existing six shard failures inspected; no duplicate campaign launched. Require actual corrected complete accounting. |
| Exact covered guide scope and receipt | Navigation guide-review and protected Change admission final recheck | c883 scope executed; missing receipt correctly refuses. Owner/Code reviewer handoff pending. |
| Actual stable staging | Existing ordinary platform route in SITE-CHECK-PROFILES/SITE-STAGING | Not observed in this review; no alias/publication/merge performed. |
| Product desktop/mobile/no-JS/PDF/physical device | Existing retained product evidence and explicit SURFACES gate | No new UI behavior in correction, so no new browser campaign designed here. Prior coverage is not newly executed or promoted to full acceptance. Missing surfaces remain pending. |

No additional regression suite is proposed: reuse the existing named owners/routes and retain the observed raw failures. The bounded run exercises operator inputs and refusal states; it cannot establish GitHub expression execution, network dependency availability, full-suite refusal preservation, live staging bytes, independent-launch internals or delayed search outcomes. All six whole criteria remain open unless their existing complete conditions are separately met. The current policy's historical preview-only description does not supersede the later explicit user staging authorization in the supplied packet; actual staging and all other gates still need their normal evidence.
