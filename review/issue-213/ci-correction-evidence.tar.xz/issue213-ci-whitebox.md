# Issue213 CI correction — independent White-box QA

Verdict: **blocked**. The c883 correction preserves the intended runtime and historical-retention oracles, but the corrected current-family assertion exposes an existing missing document-guard admission. Current-source guide evidence is also incomplete. No permission to stage or claim issue acceptance follows from this report.

## Identity and boundaries

- Role/phase: White-box QA, fresh completed-candidate CI correction review; task handle `/root/issue213_ci_whitebox`.
- Repository: `/workspace/scratch/3f2ba1da2ac8/author-site`; protected base `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`; previous `cb9c219f12e469860fd35213c5bd951932306f7a`; reviewed candidate `c88399022d6b882e7e4a13fce5ede7c2ffafeddf`, tree `73de091cad15b2c6c8f82b99c4d176cf0a7c3f7a`. Initial worktree clean.
- Manifest `/workspace/scratch/3f2ba1da2ac8/issue213-ci-final-packet.json`: SHA256 `c69c1079e91cbdbc5019162f75ed97044a1e3fd88416b2f1eacb76d7f251c0e1`. Verified every referenced material hash, including common README `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8` and role prompt `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Read supplied owner snapshot, raw CI logs, root README/AGENTS/MEMORY/map, relevant CONTRIBUTING/acceptance/style/RI/check-profile/staging/workflow sections, all seven correction paths and relevant producer/fixture consumers. No nested applicable AGENTS surfaced in the map. No peer output/preflight report, implementation change, external write or delegation.
- Isolation requested as fork-none in packet; actual parent launch receipt/provider internals are not independently observable here. No author conversation or current peer judgment was observed. Historical claims within explicitly supplied issue/memory were treated as review subjects, not verdicts.
- Shared HEAD moved during review to `49a39fb9095f78c945e7a7a948b652f3c81829b4`. Names-only comparison showed only `.github/repository-intelligence/agent-context.json` and `.github/ri-ci-map.json`; byte comparison of tests/tools/workflows/acceptance/site/docs/prompts was empty (exit0). This report judges c883; no assertion of fresh RI acceptance for49a. These unchanged executable bytes preserve attribution of the bounded dynamic observations.

## Findings

### W-CI-01 — High: current client bypasses document-hook verification

Evidence: `tools/site/runtime-compatibility.cjs:20–36` ends `reviewedDocumentClients` at the issue183 client `97208ee3…`; the already registered current issue213 client is `87f9590292adefa27641b1315e6b4292a871a7acf12b033eab5f2521433899ab`. `verify()` returns early at line120 whenever the client is absent from that Set. The current sources therefore verify executable file hashes and compatibility identity but skip every `verifyDocument()` hook/class/footer/navigation/meta check.

Root supplied primary execution `quality-reports/issue213-ci/hook-first.tap` and `.stderr`, independently read here: targeted `producer refactoring preserves client compatibility while runtime bytes and document hooks stay bound`, Node exit1, 1test/0pass/1fail, zero cancel/skip/todo,227.229822ms. Existing `tests/color-motion-contract.test.cjs:236` expects `/client document hook space-motion/` after replacing the real button id; no exception occurs. Earlier raw CI stopped this same test at line212 on its obsolete issue183 identity, hiding the later guard failure. Updating that expected identity alone cannot complete correction acceptance.

Protected invariant: an explicitly reviewed current client must retain the executable-byte AND document-hook checks exercised by the preserved negative tests. AC03 DISCOVERY/material correctness, AC04 runtime/integrity and AC05 exact-source verification are affected. Proposed treatment: inspect/admit only the exact independently reviewed current client to the existing document-check route, or an equally strict bounded correction; preserve all missing/decoy hook, wrong class/footer, malformed-markup and tamper assertions. Obtain Requirements/code/affected QA review and rerun the informative failed scope after an evidenced source change. Do not weaken or delete the negative test. No implementation was made by this reviewer.

### W-CI-02 — High advancement gate: current guide receipt absent

Actual command on c883: `python3 tools/check_ri_ci.py guide-review --base-sha 3877546d29a04f235f9ec0f3175f4e0d90bfd60d --head-sha c88399022d6b882e7e4a13fce5ede7c2ffafeddf` exited1: `Add a current review in review/issue-N/workflow-guide-evidence.json`. Current covered scope SHA256 is `93aa03cf904508e0621f81e3edc3cfe60e5bf9b669069a9a5e2c5154b010ab05`. This reproduces the missing-receipt mechanism of raw Navigation failure136927371860, with expanded current scope, without bypassing or rewriting the guard.

AC05/RI-CI and Navigation advancement remain blocked until independent Code review covers the complete protected-base guide scope and the orchestrator records its exact current scope, actual section titles and justified updated/unchanged disposition. This is a missing required receipt, not a recommendation to invent substantive guide edits. Any later covered source correction requires refreshing scope again. This reviewer did not author or inspect peer guide judgments.

## Structural risk and allocation matrix

| Risk / AC | Structural fault and scenario | Independent oracle | Route and observation |
| --- | --- | --- | --- |
| AC03/04 current runtime | Current generated client compared with historical183 tuple | Explicit213 registered tuple, all five executable/style hashes equal183, distinct reviewed client/fingerprints | `color-motion-contract`, permanent PR-targeted/staging/production source suites; registry unchanged. Own39 bounded identity probes pass; complete module still fails the hook invariant above. |
| AC04 document guard | New reviewed client takes unknown-client early return; delete real hook and add inert decoys | Real button absent must reject even if comments/templates/JSON mention it | Existing producer-refactoring case, same maintained suite; root raw targeted failure independently diagnosed. No test rewrite accepted. |
| AC03/05 historical retention | Archived public source accidentally consumes current83-entry declaration | Archived fixture root owns actual historical declaration; missing/malformed/tampered bytes must refuse | release-controller/archive/reader fixtures now thread `authoredRoot`; existing edition-retention parity/refusal case own execution1/1 passed. Full six-module integration pending when inspected. |
| AC03 rights | Current publication fixture asserts obsolete family before reaching licensing refusals | Current runtime still requires frozen rights; deleting/relabeling descriptors cannot opt out | publication-records fixture assertion updated, historical fixed baseline path unchanged; same permanent publication-records suite. Source inspection preserves missing-rights, rehashed metadata, scope/notices/substitution and receipt checks. |
| AC04/05 workflow setup | Policy213 selects BASIC/SEO/PUBLISHING/DISCOVERY without required pinned tools | Existing policy checks execute with their preexisting locked Node/Python/AST/media dependencies | Four issue213 additions to existing install selectors only; policy/runner/timeouts/check list/human gates unchanged. CI missing-venv raw failure matches this correction. Actual clean hosted install/run not observed. |
| AC05 guide gate | Covered controls change without source-bound receipt | Protected-base guide-review refuses missing/stale receipt | Navigation/Change admission owner; own c883 command fails as expected, W-CI-02. |
| AC04 staging journeys | Runtime/variant identity mixed or forged | Distinct descriptor vs actual engine; wrong runtime, unknown variant, conflicts reject | Existing staging-regression permanent suite, Navigation and source profiles; own2 targeted cases pass including their negative branches. |

## Actual bounded checks

Environment: Node `v24.22.3`, Python `3.12.14`; CI raw logs use Node24.19.0, so local results are bounded local evidence.

1. `node --test --test-name-pattern='selected journeys compare actual base runtime|functional collection failures' tests/staging-regression.test.cjs`: exit0;2tests/2pass/0fail/0cancel/0skip/0todo;151.008868ms. Missing PIL/selected-article evidence precedence and actual-vs-descriptor runtime assertions exercised.
2. `node --test --test-name-pattern='explicit retention source preserves defaults and refuses missing or tampered declarations' tests/edition-retention.test.cjs`: exit0;1test/1pass/0fail/0cancel/0skip/0todo;3320.814075ms. Both base-production and Color inputs refuse absent declaration, null map and zeroed declared digest; explicit-root and default resulting files/digests match, including subsequent Color production composition.
3. Bounded inline Node assertion probe: derive current Color identity from `docs/site-revision.json` using `color.identities(..., color.authoredEffects())`; assert exact213 plain variant and unchanged183 file map; for all3editions construct the explicit registered valid manifest, confirm selection, then independently zero each of10root/immutable aliases, forge engine and substitute old baseEngine. Exit0;39positive/negative assertions; output `{"currentDerivedIdentity":"matched","historicalRuntimeFiles":"unchanged","positiveAndNegativeAssertions":39}`. This checks tuple admission/refusal, not actual browser behavior or branch-coverage percentage.
4. Protected-base guide-review command above: exit1, exact expected refusal recorded in W-CI-02. No unchanged failure rerun.
5. Read root primary `hook-first.tap`/stderr as described in W-CI-01. This was root execution, not reviewer-executed test. Retained first failure supplies direct counterexample to acceptance.

## Unchanged and unresolved scope

`git diff cb9..c883` confirms no changes to product sources, registered Color contract, production/staging adapter implementation, acceptance policy/runner, registry or budgets. Thus historical runtime registrations and actual checks remain exact; the correction changes fixture inputs/assertions, not guard breadth. This does not imply existing code is correct: W-CI-01 explicitly falsifies that assumption.

At last inspection `quality-reports/issue213-ci/affected.json` and `affected.stderr` were still zero bytes, so no six-module completion/accounting is claimed. No installed-tool CI replay, full owning policy, physical/mobile/no-JS/PDF, browser, stable alias or production check was performed by this reviewer. These retain their existing owners/gates. No measured statement- or branch-coverage claim; the matrix records structural reasoning and bounded actual assertions only. A new guard correction requires fresh affected source/oracle review and completed current-source checks before advancement.
