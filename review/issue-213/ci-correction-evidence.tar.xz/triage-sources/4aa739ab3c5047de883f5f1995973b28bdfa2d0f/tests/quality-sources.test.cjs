'use strict';
const test = require('node:test'),
  assert = require('node:assert/strict'),
  fs = require('node:fs'),
  path = require('node:path'),
  cp = require('node:child_process');
const {
  authoredRuntimeSources,
  authoredRuntime,
  lintEffectCoverage,
} = require('../tools/quality/scanners.cjs');
const { effectInputs } = require('../tools/site/effects.cjs');
const root = path.resolve(__dirname, '..');
const sourceCatalog = () =>
  Object.fromEntries(
    authoredRuntimeSources.map((file) => [file, { kind: 'file', role: 'source' }])
  );

test('effect scanning uses the canonical manifest and rejects missing or misclassified active sources', () => {
  const diagnostics = ['review/site-scroll-sync-20261004/check-content-flight.cjs'];
  const catalog = sourceCatalog();
  assert.deepEqual(
    authoredRuntime([...effectInputs, ...diagnostics], () => true, catalog),
    authoredRuntimeSources
  );
  assert.throws(() => authoredRuntime([], () => true, catalog), /Missing active effect input/);
  for (const file of effectInputs) {
    assert.throws(
      () =>
        authoredRuntime(
          effectInputs.filter((input) => input !== file),
          () => true,
          catalog
        ),
      /Missing active effect input/
    );
    assert.throws(
      () => authoredRuntime(effectInputs, (input) => input !== file, catalog),
      /Missing active effect input/
    );
  }
  for (const file of authoredRuntimeSources) {
    for (const record of [
      undefined,
      { kind: 'file', role: 'history' },
      { kind: 'directory', role: 'source' },
    ]) {
      const invalid = { ...catalog, [file]: record };
      assert.throws(
        () => authoredRuntime(effectInputs, () => true, invalid),
        /Misclassified authored effect source/
      );
    }
  }
});

test('the effect manifest matches all active browser dependencies and tracked source classification', () => {
  const tracked = cp
    .execFileSync('git', ['ls-files', 'site', 'tools'], { cwd: root, encoding: 'utf8' })
    .trim()
    .split('\n');
  const pending = ['tools/site/effects.cjs', 'tools/site/export.cjs', 'tools/staging/color.cjs'];
  const visited = new Set(),
    imported = new Set();
  while (pending.length) {
    const file = pending.pop();
    if (visited.has(file)) continue;
    visited.add(file);
    const source = fs.readFileSync(path.join(root, file), 'utf8');
    for (const match of source.matchAll(/require\(['"](\.[^'"]+)['"]\)/g)) {
      const dependency = path
        .relative(root, path.resolve(root, path.dirname(file), match[1]))
        .split(path.sep)
        .join('/');
      if (dependency.startsWith('site/effects/') && dependency.endsWith('.cjs')) {
        imported.add(dependency);
        pending.push(dependency);
      }
    }
  }
  assert.deepEqual(
    [...imported].sort(),
    [...authoredRuntimeSources].sort(),
    'new browser effect dependencies must extend the canonical manifest'
  );
  assert.deepEqual(
    authoredRuntime(tracked),
    authoredRuntimeSources,
    'all declared effect inputs must remain tracked and present'
  );
});

test('ESLint coverage rejects an omitted, ignored, duplicated or unparsed browser effect', () => {
  const report = authoredRuntimeSources.map((file) => ({
    filePath: path.join(root, file),
    messages: [],
  }));
  lintEffectCoverage(report);
  for (const file of authoredRuntimeSources) {
    const row = report.find((item) => item.filePath === path.join(root, file));
    assert.throws(
      () => lintEffectCoverage(report.filter((item) => item !== row)),
      /effect lint coverage/
    );
    assert.throws(() => lintEffectCoverage([...report, row]), /effect lint coverage/);
    for (const message of [
      { message: 'File ignored because of a matching ignore pattern' },
      { fatal: true, message: 'Parsing error' },
    ]) {
      const changed = report.map((item) =>
        item === row ? { ...item, messages: [message] } : item
      );
      assert.throws(() => lintEffectCoverage(changed), /effect lint coverage/);
    }
  }
});

test('retained script lint verifies exact copies without ignoring correctness or authored complexity', () => {
  const os = require('node:os');
  const crypto = require('node:crypto');
  const vm = require('node:vm');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'retained-lint-'));
  const relative = 'runtime/' + 'a'.repeat(64) + '/fixture.js';
  const retainedFile = 'site/retained/' + relative;
  const authoredFile = 'site/engine/fixture.js';
  const manifestFile = path.join(directory, 'site/retained/manifest.json');
  const digest = (value) => crypto.createHash('sha256').update(value).digest('hex');
  const source = 'window.fixture=document.title;\n';
  const manifest = { schema: 1, files: { [relative]: digest(source) } };
  const configSource = fs.readFileSync(path.join(root, 'tools/quality/eslint.config.cjs'), 'utf8');
  const packages = {
    '@eslint/js': { configs: { recommended: { rules: { 'no-undef': 'error' } } } },
    'eslint-plugin-sonarjs': {},
    globals: {
      browser: { window: 'readonly', document: 'readonly' },
      node: { process: 'readonly' },
    },
  };
  const configRequire = (name) => {
    if (name === 'node:module') {
      return {
        createRequire: () => (packageName) => {
          assert.ok(Object.hasOwn(packages, packageName), 'unexpected lint dependency');
          return packages[packageName];
        },
      };
    }
    assert.ok(['node:fs', 'node:path', 'node:crypto'].includes(name), 'unexpected config import');
    return require(name);
  };
  const writeManifest = (value) => fs.writeFileSync(manifestFile, JSON.stringify(value));
  const loadConfig = () => {
    const sandbox = {
      module: { exports: {} },
      require: configRequire,
      __dirname: path.join(directory, 'tools/quality'),
      process: { env: {} },
    };
    vm.runInNewContext(configSource, sandbox, { filename: 'tools/quality/eslint.config.cjs' });
    return structuredClone(sandbox.module.exports);
  };
  try {
    fs.mkdirSync(path.dirname(path.join(directory, retainedFile)), { recursive: true });
    fs.writeFileSync(path.join(directory, retainedFile), source);
    writeManifest(manifest);
    const config = loadConfig();
    const retainedOverrides = config.filter(
      (entry) => entry.rules?.['sonarjs/cognitive-complexity'] === 'off'
    );
    assert.equal(retainedOverrides.length, 1);
    const retainedOverride = retainedOverrides[0];
    assert.deepEqual(retainedOverride.files, [retainedFile]);
    assert.equal(retainedOverride.languageOptions.sourceType, 'script');
    assert.equal(retainedOverride.languageOptions.globals.window, 'readonly');
    assert.equal(retainedOverride.languageOptions.globals.document, 'readonly');
    assert.deepEqual(Object.keys(retainedOverride.rules), ['sonarjs/cognitive-complexity']);
    assert.ok(!retainedOverride.files.includes(authoredFile));
    assert.equal(config.find((entry) => entry.rules?.['no-undef']).rules['no-undef'], 'error');
    const sonarRules = config.find((entry) => entry.plugins?.sonarjs).rules;
    assert.deepEqual(sonarRules['sonarjs/cognitive-complexity'], ['warn', 25]);
    for (const rule of [
      'sonarjs/no-identical-expressions',
      'sonarjs/no-duplicate-in-composite',
      'sonarjs/no-dead-store',
    ]) {
      assert.equal(sonarRules[rule], 'error');
    }
    assert.deepEqual(
      config.flatMap((entry) => entry.ignores || []),
      [],
      'declared maintained-source coverage cannot be suppressed by config ignores'
    );
    for (const changed of [
      [],
      { ...manifest, schema: true },
      { ...manifest, files: [] },
      { ...manifest, files: { [relative]: null } },
      { ...manifest, files: { [relative]: 'invalid' } },
    ]) {
      writeManifest(changed);
      assert.throws(loadConfig, /retained JavaScript manifest|retained JavaScript digest/);
    }
    writeManifest({ schema: 1, files: {} });
    const unverified = loadConfig();
    assert.ok(!unverified.some((entry) => entry.rules?.['sonarjs/cognitive-complexity'] === 'off'));
    assert.deepEqual(
      unverified.find((entry) => entry.plugins?.sonarjs).rules['sonarjs/cognitive-complexity'],
      ['warn', 25]
    );
    writeManifest(manifest);
    fs.appendFileSync(path.join(directory, retainedFile), '// Changed immutable copy\n');
    assert.throws(loadConfig, /Changed retained JavaScript bytes/);
    fs.writeFileSync(path.join(directory, retainedFile), source);
    const symlinkTarget = path.join(directory, 'fixture.js');
    fs.writeFileSync(symlinkTarget, source);
    fs.unlinkSync(path.join(directory, retainedFile));
    fs.symlinkSync(symlinkTarget, path.join(directory, retainedFile));
    assert.throws(loadConfig, /Invalid retained JavaScript path/);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('maintained ESLint coverage rejects missing, duplicate, ignored, unparsed and incorrect sources', () => {
  const { lintSourceCoverage } = require('../tools/quality/scanners.cjs');
  const expected = [
    'build.config.cjs',
    'site/engine/nested/component.js',
    'tools/quality/scanners.cjs',
    'tests/fixtures/data.cjs',
  ];
  const report = expected.map((file) => ({
    filePath: path.join(root, file),
    messages: [],
    errorCount: 0,
  }));
  assert.deepEqual(lintSourceCoverage(report, expected), expected.sort());
  for (const row of report) {
    assert.throws(
      () =>
        lintSourceCoverage(
          report.filter((item) => item !== row),
          expected
        ),
      /Missing or duplicated ESLint coverage/
    );
    assert.throws(
      () => lintSourceCoverage([...report, row], expected),
      /Missing or duplicated ESLint coverage/
    );
    for (const messages of [
      undefined,
      [{ message: 'File ignored because of ignore patterns', severity: 1 }],
      [{ message: 'Parsing error', fatal: true, severity: 2 }],
      [{ message: 'Incorrect source', severity: 2 }],
    ]) {
      assert.throws(
        () =>
          lintSourceCoverage(
            report.map((item) => (item === row ? { ...item, messages } : item)),
            expected
          ),
        /Ignored, unparsed or incorrect/
      );
    }
  }
  assert.throws(
    () =>
      lintSourceCoverage(
        [...report, { filePath: path.join(root, 'unreviewed.cjs'), messages: [] }],
        expected
      ),
    /Unexpected ESLint coverage/
  );
  assert.throws(() => lintSourceCoverage(report, []), /coverage inventory/);
  assert.throws(() => lintSourceCoverage(report, [...expected, expected[0]]), /coverage inventory/);
});

test('Ruff parsed-file inventory rejects omitted, duplicate and unexpected Python sources', () => {
  const { lintFileCoverage } = require('../tools/quality/scanners.cjs');
  const expected = ['site/metadata.py', 'tools/check.py', 'tests/nested/test_source.py'];
  const files = expected.map((file) => path.join(root, file));
  assert.deepEqual(lintFileCoverage(files, expected, 'Ruff'), expected.sort());
  for (const file of files) {
    assert.throws(
      () =>
        lintFileCoverage(
          files.filter((item) => item !== file),
          expected,
          'Ruff'
        ),
      /Missing or duplicated Ruff coverage/
    );
    assert.throws(
      () => lintFileCoverage([...files, file], expected, 'Ruff'),
      /Missing or duplicated Ruff coverage/
    );
  }
  assert.throws(
    () => lintFileCoverage([...files, path.join(root, 'tools/untracked.py')], expected, 'Ruff'),
    /Unexpected Ruff coverage/
  );
});

test('generated JavaScript coverage follows the declared output and rejects omitted, extra or symlinked files', () => {
  const { generatedJavaScript } = require('../tools/quality/scanners.cjs');
  const os = require('node:os'),
    directory = fs.mkdtempSync(path.join(os.tmpdir(), 'generated-lint-'));
  try {
    fs.mkdirSync(path.join(directory, 'site'));
    fs.mkdirSync(path.join(directory, 'docs'));
    fs.writeFileSync(
      path.join(directory, 'site/output-lock.json'),
      JSON.stringify({
        files: { 'theme.js': 'a'.repeat(64), 'runtime/retained/theme.js': 'a'.repeat(64) },
      })
    );
    fs.writeFileSync(path.join(directory, 'docs/theme.js'), 'void 0;');
    assert.deepEqual(generatedJavaScript(directory), ['docs/theme.js']);
    fs.writeFileSync(path.join(directory, 'docs/unbound.js'), 'void 0;');
    assert.throws(() => generatedJavaScript(directory), /Unexpected generated JavaScript coverage/);
    fs.unlinkSync(path.join(directory, 'docs/unbound.js'));
    fs.unlinkSync(path.join(directory, 'docs/theme.js'));
    assert.throws(
      () => generatedJavaScript(directory),
      /Missing or duplicated generated JavaScript coverage/
    );
    fs.symlinkSync(
      path.join(directory, 'site/output-lock.json'),
      path.join(directory, 'docs/theme.js')
    );
    assert.throws(() => generatedJavaScript(directory), /symlinked generated JavaScript/);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('browser security policies cover the authored effect source directory without diagnostic harness scope', () => {
  const source = fs.readFileSync(path.join(root, 'tools/quality/security-rules.yml'), 'utf8');
  for (const id of ['browser-html-injection', 'browser-code-execution']) {
    const rule = source.split('  - id: ' + id + '\n')[1].split('\n  - id: ')[0];
    for (const directoryScope of [
      'docs/**',
      'site/engine/**',
      'site/scenes/**',
      'site/integrations/**',
      'site/effects/**',
    ]) {
      assert.ok(rule.includes(directoryScope), id + ' lost public source scope');
    }
    for (const file of authoredRuntimeSources)
      assert.ok(file.startsWith('site/effects/'), id + ' missing canonical effect ' + file);
    assert.ok(!rule.includes('review/'), 'diagnostic files do not define browser runtime policy');
  }
});

test('Stylelint covers every authored CSS file and generated stylesheet, including newly added components', async () => {
  const { cssSources, scanStyles, styleSourceFindings } = require('../tools/quality/stylelint.cjs');
  const os = require('node:os'),
    directory = fs.mkdtempSync(path.join(os.tmpdir(), 'css-coverage-'));
  try {
    fs.mkdirSync(path.join(directory, 'site/effects'), { recursive: true });
    fs.mkdirSync(path.join(directory, 'site/engine'), { recursive: true });
    fs.mkdirSync(path.join(directory, 'docs'));
    const files = [
      'site/engine/styles.css',
      'site/engine/reading-surfaces.css',
      'site/effects/component.css',
      'tools/ui/check.css',
      'tests/fixtures/source.css',
      'root-config.css',
      'docs/styles.css',
    ];
    for (const file of files) {
      fs.mkdirSync(path.dirname(path.join(directory, file)), { recursive: true });
      fs.writeFileSync(path.join(directory, file), '.reading { color: red; }');
    }
    const options = {
      scope: require('../tools/quality/format-scope.json'),
      tracked: files,
      diskFiles: files,
      catalog: Object.fromEntries(
        files.map((file) => [
          file,
          {
            kind: 'file',
            role: file.startsWith('docs/') ? 'generated' : 'source',
            owner: 'site/README.md',
          },
        ])
      ),
      exists: () => true,
      effects: [],
    };
    const scanned = [];
    const rows = await scanStyles(
      directory,
      async ({ codeFilename, code, ignoreDisables }) => {
        scanned.push(path.relative(directory, codeFilename).split(path.sep).join('/'));
        assert.equal(code, '.reading { color: red; }');
        assert.equal(ignoreDisables, true, 'inline disable comments must not hide source findings');
        return {
          results: [
            {
              source: codeFilename,
              warnings: [],
              parseErrors: [],
              invalidOptionWarnings: [],
              errored: false,
            },
          ],
        };
      },
      options
    );
    assert.deepEqual(scanned, [
      ...files.filter((file) => !file.startsWith('docs/')).sort(),
      'docs/styles.css',
    ]);
    assert.equal(rows.length, files.length);
    styleSourceFindings(rows);
    for (const result of [
      { results: [] },
      { results: [{ source: path.join(directory, 'docs/other.css') }] },
      { results: [{ source: path.join(directory, scanned[0]), ignored: true }] },
      { results: [rows[0], rows[0]] },
    ]) {
      await assert.rejects(
        scanStyles(directory, async () => result, options),
        /missing or mismatched coverage/
      );
    }
    for (const finding of [
      { warnings: undefined },
      { warnings: [{ severity: 'warning', text: 'New finding' }] },
      { parseErrors: [{ text: 'Malformed CSS' }] },
      { invalidOptionWarnings: [{ text: 'Unknown rule' }] },
      { deprecations: [{ text: 'Deprecated rule' }] },
      { autofixed: true },
      { errored: true },
    ]) {
      assert.throws(
        () => styleSourceFindings([{ ...rows[0], ...finding }]),
        /Stylelint correctness findings/
      );
    }
    assert.throws(
      () =>
        cssSources(directory, {
          ...options,
          tracked: files.filter((file) => file !== 'tools/ui/check.css'),
        }),
      /Untracked or ignored formatter source/
    );
    fs.unlinkSync(path.join(directory, 'docs/styles.css'));
    assert.throws(() => cssSources(directory, options), /ENOENT|generated CSS/);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
  const authored = require('../tools/quality/format.cjs').sourceInventory(root).byLanguage.css;
  assert.deepEqual(cssSources(root), [...authored.sort(), 'docs/styles.css']);
});

test('newly exposed effect complexity preserves exact source debt and rejects stale or expanded allowances', () => {
  const { reviewComplexity } = require('../tools/quality/scanners.cjs');
  const digest = (bytes) => require('node:crypto').createHash('sha256').update(bytes).digest('hex');
  const source = 'function projector() { return 1; }\n',
    baseline = '// Original source\n' + source;
  const warning = {
    file: 'site/effects/ribbons.cjs',
    rule: 'sonarjs/cognitive-complexity',
    message: 'Existing exact complexity warning',
  };
  const entry = {
    path: warning.file,
    rule: warning.rule,
    message: warning.message,
    issue: 56,
    removalTask: 'R5',
    reason:
      'Preserved browser bytes; projection simplification remains a separately reviewed task.',
    source_sha256: digest(source),
    baseline: {
      commit: 'a'.repeat(40),
      path: 'review/legacy/RIBBONS-PROTOTYPE.cjs',
      sha256: digest(baseline),
    },
  };
  const policy = { reviewBy: '2026-11-03', complexity: [entry] };
  const options = {
    now: new Date('2026-10-08T12:00:00Z'),
    sourceBytes: () => source,
    baselineBytes: () => baseline,
  };
  reviewComplexity([warning], policy, options);
  assert.throws(
    () =>
      reviewComplexity([warning], policy, {
        ...options,
        sourceBytes: () => source + '// Changed source\n',
      }),
    /Changed source-bound/
  );
  assert.throws(
    () =>
      reviewComplexity([warning], policy, {
        ...options,
        baselineBytes: () => baseline + '// Wrong baseline\n',
      }),
    /Changed source-bound/
  );
  assert.throws(
    () =>
      reviewComplexity([warning], policy, { ...options, now: new Date('2026-11-04T00:00:00Z') }),
    /expired/
  );
  assert.throws(() => reviewComplexity([], policy, options), /Stale complexity/);
  assert.throws(
    () => reviewComplexity([warning, { ...warning, message: 'New complexity' }], policy, options),
    /New or duplicated/
  );
  assert.throws(() => reviewComplexity([warning, warning], policy, options), /New or duplicated/);
  assert.throws(
    () => reviewComplexity([warning], { ...policy, complexity: [entry, entry] }, options),
    /New or duplicated/
  );
  for (const field of ['source_sha256', 'issue', 'removalTask', 'reason', 'baseline']) {
    const changed = structuredClone(policy);
    delete changed.complexity[0][field];
    assert.throws(() => reviewComplexity([warning], changed, options), /Invalid source-bound/);
  }
});

test('removed complexity debt has no expiry gate while invalid dates and new warnings stay blocking', () => {
  const { reviewComplexity } = require('../tools/quality/scanners.cjs');
  const policy = { reviewBy: '2026-11-03', complexity: [] };
  const options = { now: new Date('2026-11-04T00:00:00Z') };
  reviewComplexity([], policy, options);
  assert.throws(
    () =>
      reviewComplexity(
        [
          {
            file: 'site/effects/ribbons.cjs',
            rule: 'sonarjs/cognitive-complexity',
            message: 'New complexity warning',
          },
        ],
        policy,
        options
      ),
    /New or duplicated complexity debt/
  );
  assert.throws(() => reviewComplexity([], { ...policy, reviewBy: 'invalid' }, options), /expired/);
});

function banditFixture() {
  const os = require('node:os'),
    triage = require('../tools/quality/bandit-triage.cjs'),
    directory = fs.mkdtempSync(path.join(os.tmpdir(), 'bandit-review-')),
    file = 'tools/reviewed.py',
    source = 'import subprocess\n';
  fs.mkdirSync(path.join(directory, 'tools'));
  fs.mkdirSync(path.join(directory, '.github'));
  fs.writeFileSync(path.join(directory, file), source);
  fs.writeFileSync(
    path.join(directory, '.github/REPOSITORY-INTELLIGENCE.md'),
    'Canonical tooling owner\n'
  );
  const row = {
    path: file,
    rule: 'B404',
    line: 1,
    test_name: 'blacklist',
    severity: 'LOW',
    confidence: 'HIGH',
    source_sha256: triage.digest(source),
    line_sha256: triage.digest(source.trimEnd()),
    owner: '.github/REPOSITORY-INTELLIGENCE.md',
    issue: 35,
    reviewBy: '2026-11-03',
    rationale:
      'Reviewed shell-free developer tooling import; exact argv and installed executable trust remain owned by this source.',
  };
  const policy = {
      schema_version: 1,
      repository: 'oborskyivitalii/oborskyivitalii',
      issue: 35,
      reviewBy: row.reviewBy,
      entries: [row],
    },
    totals = { loc: 1 };
  for (const field of ['SEVERITY', 'CONFIDENCE'])
    for (const level of ['LOW', 'MEDIUM', 'HIGH', 'UNDEFINED']) totals[field + '.' + level] = 0;
  totals['SEVERITY.LOW'] = 1;
  totals['CONFIDENCE.HIGH'] = 1;
  const report = {
      errors: [],
      metrics: { _totals: totals, [file]: { loc: 1 } },
      results: [
        {
          filename: file,
          test_id: row.rule,
          line_number: row.line,
          test_name: row.test_name,
          issue_severity: row.severity,
          issue_confidence: row.confidence,
          issue_text: 'Raw import finding remains visible',
        },
      ],
    },
    options = { expectedFiles: [file], now: new Date('2026-10-07T12:00:00Z') };
  return { directory, file, source, policy, report, options, triage };
}
test('Bandit admission retains raw findings and admits only exact reviewed source, rule, line and coverage', () => {
  const f = banditFixture();
  try {
    const before = structuredClone(f.report),
      result = f.triage.review(f.directory, f.report, f.policy, f.options);
    assert.equal(result.pass, true);
    assert.equal(result.rawFindings, 1);
    assert.equal(result.reviewedFindings, 1);
    assert.equal(result.untriagedFindings, 0);
    assert.deepEqual(f.report, before, 'triage never removes or changes scanner findings');
    assert.deepEqual(result.trackedPythonFiles, [f.file]);
    assert.match(result.policySha256, /^[a-f0-9]{64}$/);
    const invalidPolicy = [
      (p) => p.entries.push(structuredClone(p.entries[0])),
      (p) => (p.entries[0].rule = 'B603'),
      (p) => (p.entries[0].line = 2),
      (p) => (p.entries[0].owner = 'AGENTS.md'),
      (p) => (p.entries[0].rationale = ''),
      (p) => (p.entries[0].severity = 'HIGH'),
      (p) => (p.entries[0].issue = 13),
    ];
    for (const mutate of invalidPolicy) {
      const policy = structuredClone(f.policy);
      mutate(policy);
      assert.throws(() => f.triage.review(f.directory, f.report, policy, f.options));
    }
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});
test('Bandit admission fails new, missing, duplicated or changed scanner findings without lowering severity', () => {
  const f = banditFixture();
  try {
    for (const mutate of [
      (r) => r.results.push({ ...r.results[0], test_id: 'B603' }),
      (r) => (r.results = []),
      (r) => r.results.push(structuredClone(r.results[0])),
      (r) => (r.results[0].issue_severity = 'HIGH'),
      (r) => (r.results[0].issue_confidence = 'MEDIUM'),
      (r) => (r.results[0].test_name = 'another_plugin'),
      (r) => (r.metrics._totals['SEVERITY.LOW'] = 0),
    ]) {
      const report = structuredClone(f.report);
      mutate(report);
      assert.throws(() => f.triage.review(f.directory, report, f.policy, f.options));
    }
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});
test('Bandit admission fails expired reviews, changed source bytes, shifted lines and symlink substitution', () => {
  const f = banditFixture();
  try {
    assert.throws(
      () =>
        f.triage.review(f.directory, f.report, f.policy, {
          ...f.options,
          now: new Date('2026-11-04T00:00:00Z'),
        }),
      /expired/
    );
    const badDate = structuredClone(f.policy);
    badDate.reviewBy = '2026-02-30';
    badDate.entries[0].reviewBy = badDate.reviewBy;
    assert.throws(() => f.triage.review(f.directory, f.report, badDate, f.options), /deadline/);
    fs.appendFileSync(
      path.join(f.directory, f.file),
      '# A change outside the finding also requires review.\n'
    );
    assert.throws(
      () => f.triage.review(f.directory, f.report, f.policy, f.options),
      /source changed/
    );
    const altered = 'import subprocess; unsafe_call()\n';
    fs.writeFileSync(path.join(f.directory, f.file), altered);
    const partial = structuredClone(f.policy);
    partial.entries[0].source_sha256 = f.triage.digest(altered);
    assert.throws(() => f.triage.review(f.directory, f.report, partial, f.options), /line changed/);
    fs.unlinkSync(path.join(f.directory, f.file));
    fs.symlinkSync('missing.py', path.join(f.directory, f.file));
    assert.throws(() => f.triage.review(f.directory, f.report, f.policy, f.options), /symlink/);
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});
test('Bandit admission keeps scanner errors, empty or missing tracked coverage and malformed reports blocking', () => {
  const f = banditFixture();
  try {
    for (const mutate of [
      (r) => r.errors.push({ filename: f.file, reason: 'parse error' }),
      (r) => delete r.errors,
      (r) => delete r.results,
      (r) => delete r.metrics,
      (r) => (r.metrics._totals.loc = 0),
      (r) => delete r.metrics[f.file],
      (r) => (r.metrics[f.file].loc = -1),
    ]) {
      const report = structuredClone(f.report);
      mutate(report);
      assert.throws(() => f.triage.review(f.directory, report, f.policy, f.options));
    }
    assert.throws(
      () => f.triage.review(f.directory, f.report, f.policy, { ...f.options, expectedFiles: [] }),
      /coverage inventory/
    );
    assert.throws(
      () =>
        f.triage.review(f.directory, f.report, f.policy, {
          ...f.options,
          expectedFiles: [f.file, f.file],
        }),
      /duplicate/
    );
    const escape = structuredClone(f.report);
    escape.results[0].filename = '../reviewed.py';
    assert.throws(() => f.triage.review(f.directory, escape, f.policy, f.options), /unsafe/);
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('only actually verified RI/coupling checksum fields may bypass literal secret baselines', () => {
  const { verifiedChecksumIds, verifiedChecksumFinding } = require('../tools/quality/scanners.cjs');
  const hash = 'abcdef0123456789'.repeat(4),
    ids = verifiedChecksumIds([hash]);
  const finding = { type: 'Hex High Entropy String', hashed_secret: [...ids][0] },
    nav = '.github/repository-intelligence/agent-context.json',
    ci = '.github/ri-ci-map.json';
  const proved = new Map([
    [nav, ids],
    [ci, ids],
  ]);
  assert.equal(verifiedChecksumFinding(nav, finding, proved), true);
  assert.equal(verifiedChecksumFinding(ci, finding, proved), true);
  assert.equal(verifiedChecksumFinding('unverified-metadata.json', finding, proved), false);
  assert.equal(verifiedChecksumFinding(ci, { ...finding, type: 'Secret Keyword' }, proved), false);
  assert.equal(
    verifiedChecksumFinding(ci, { ...finding, hashed_secret: 'a'.repeat(40) }, proved),
    false
  );
  assert.equal(verifiedChecksumFinding(ci, finding, new Map()), false);
  assert.throws(() => verifiedChecksumIds(['private-value']), /invalid verified public checksum/);
});

function secretReviewFixture() {
  const os = require('node:os');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'secret-review-'));
  const files = [
    'tools/quality/secrets-baseline.json',
    'tools/quality/secrets-reviewed.json',
    'tools/quality/secrets-reviewed-checksums.json',
    'tools/quality/secrets-publication.json',
    'tools/quality/secrets-issue213.json',
  ];
  const metadata = {
    owner: 'Review owner',
    issue: 'https://github.com/oborskyivitalii/oborskyivitalii/issues/69',
    reviewedAt: '2026-10-11',
    scope: 'Individually reviewed exact public findings.',
    findings: [],
  };
  const reviews = files.map((_, index) => ({
    ...(index ? { schema_version: 1 } : {}),
    ...structuredClone(metadata),
  }));
  const write = (index, review = reviews[index]) =>
    fs.writeFileSync(path.join(directory, files[index]), JSON.stringify(review));
  fs.mkdirSync(path.join(directory, 'tools/quality'), { recursive: true });
  files.forEach((_, index) => write(index));
  const entry = (file, rule = 'Hex High Entropy String', hash = 'a'.repeat(40)) => ({
    id: [file, rule, hash].join(':'),
    path: file,
    rule,
    disposition: 'false positive',
    reason: 'Individually recomputed public checksum with independent review.',
  });
  return { directory, files, reviews, write, entry };
}

test('the two public inventory paths each require their exact reviewed tuple', () => {
  const { loadSecretReviews, reviewedSecretFinding } = require('../tools/quality/scanners.cjs');
  const f = secretReviewFixture();
  try {
    for (const file of [
      '.github/repository-paths.json',
      '.github/repository-intelligence/agent-context.json',
    ]) {
      for (const hash of [
        '41ceb5699f64d5bfeaccc5850d0cf398a19b10c9',
        'eb3400c0b18476eb7e38e5a430d52a263f917b89',
        '6642018803cd2ae612e7b4186ab13f9105e44e37',
        'c8aafd7b5d13b635e9e3cd0e5b433e8bda6502f2',
      ]) {
        const entry = f.entry(file, 'Base64 High Entropy String', hash);
        const finding = {
          type: entry.rule,
          hashed_secret: entry.id.slice(-40),
        };
        assert.equal(reviewedSecretFinding(entry.path, finding, new Map()), false);
        f.reviews[2].findings = [entry];
        f.write(2);
        const reviewed = loadSecretReviews(f.directory);
        assert.equal(reviewedSecretFinding(entry.path, finding, reviewed), true);
        assert.equal(reviewedSecretFinding('other/catalogue.json', finding, reviewed), false);
        assert.equal(
          reviewedSecretFinding(
            entry.path,
            { ...finding, hashed_secret: 'a'.repeat(40) },
            reviewed
          ),
          false
        );
        assert.equal(
          reviewedSecretFinding(
            entry.path,
            { ...finding, type: 'Hex High Entropy String' },
            reviewed
          ),
          false
        );
        for (const bad of [
          f.entry(entry.path, entry.rule, 'a'.repeat(40)),
          f.entry('other/catalogue.json', entry.rule, finding.hashed_secret),
        ]) {
          f.reviews[2].findings = [bad];
          f.write(2);
          assert.throws(() => loadSecretReviews(f.directory), /Invalid exact secret review entry/);
        }
      }
    }
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('closed secret ledgers admit only exact reviewed path, rule and hashed value', () => {
  const { loadSecretReviews, reviewedSecretFinding } = require('../tools/quality/scanners.cjs');
  const f = secretReviewFixture();
  try {
    f.reviews[0].findings.push(f.entry('review/legacy.json', 'Basic Auth Credentials'));
    f.reviews[1].findings.push(f.entry('review/metadata.json', 'Secret Keyword'));
    f.reviews[2].findings.push(f.entry('review/naïve proof.json'));
    f.reviews[3].findings.push(f.entry('review/publication.json'));
    f.reviews[4].findings.push(f.entry('review/issue213-checksum.json'));
    f.files.forEach((_, index) => f.write(index));
    fs.writeFileSync(
      path.join(f.directory, 'tools/quality/secrets-reviewed-extra.json'),
      JSON.stringify({
        ...f.reviews[2],
        findings: [f.entry('unreviewed.json')],
      })
    );
    const reviewed = loadSecretReviews(f.directory);
    assert.equal(reviewed.size, 5);
    for (const entry of f.reviews.flatMap((review) => review.findings)) {
      const finding = { type: entry.rule, hashed_secret: entry.id.slice(-40) };
      assert.deepEqual(reviewed.get(entry.id), entry);
      assert.equal(reviewedSecretFinding(entry.path, finding, reviewed), true);
      assert.equal(reviewedSecretFinding('other/' + entry.path, finding, reviewed), false);
      assert.equal(
        reviewedSecretFinding(entry.path, { ...finding, type: 'unknown rule' }, reviewed),
        false
      );
      assert.equal(
        reviewedSecretFinding(entry.path, { ...finding, hashed_secret: 'b'.repeat(40) }, reviewed),
        false
      );
    }
    assert.equal(
      reviewedSecretFinding(
        'unreviewed.json',
        { type: 'Hex High Entropy String', hashed_secret: 'a'.repeat(40) },
        reviewed
      ),
      false,
      'neighboring ledger names are not admission authorities'
    );
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('the additional closed checksum ledger keeps strict types and metadata', () => {
  const { loadSecretReviews } = require('../tools/quality/scanners.cjs');
  const f = secretReviewFixture();
  try {
    for (const rule of ['Secret Keyword', 'Basic Auth Credentials', 'unknown']) {
      f.write(4, { ...f.reviews[4], findings: [f.entry('review/public.json', rule)] });
      assert.throws(() => loadSecretReviews(f.directory), /Invalid exact secret review entry/);
    }
    for (const changed of [
      { ...f.reviews[4], owner: '' },
      { ...f.reviews[4], reviewedAt: '2026-02-30' },
      { ...f.reviews[4], schema_version: 2 },
      { ...f.reviews[4], findings: {} },
      { ...f.reviews[4], extraAdmission: true },
    ]) {
      f.write(4, changed);
      assert.throws(() => loadSecretReviews(f.directory), /Invalid secret review metadata/);
    }
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('current guide checksum proof follows real committed scope and rejects stale or copied fields', () => {
  const os = require('node:os'),
    crypto = require('node:crypto');
  const helper = require('../tools/quality/generated-checksums.cjs');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'guide-checksum-'));
  const file = 'review/issue-213/workflow-guide-evidence.json';
  const git = (...args) =>
    cp.execFileSync('git', args, { cwd: directory, encoding: 'utf8' }).trim();
  try {
    cp.execFileSync('git', ['clone', '--shared', '--quiet', root, directory]);
    git('config', 'user.email', 'fixture@example.invalid');
    git('config', 'user.name', 'Checksum fixture');
    git('checkout', '--quiet', '--detach', '7feb1c32dd65d643592057982ec12779c96b5cbc');
    const baseline = git('rev-parse', 'HEAD');
    const original = fs.readFileSync(path.join(directory, file), 'utf8');
    const record = JSON.parse(original);
    git('update-ref', 'refs/remotes/origin/main', record.base_sha);
    const modules = 'tools/publishing/toolchain/node_modules';
    fs.symlinkSync(path.join(root, modules), path.join(directory, modules), 'junction');
    const read = (name) => fs.readFileSync(path.join(directory, name), 'utf8');
    const collect = () => helper.collectGuideChecksumFields(directory, read);
    const hash = crypto.createHash('sha1').update(record.scope_sha256).digest('hex');
    assert.ok(collect().get(file).locations.has(hash));
    fs.writeFileSync(path.join(directory, file), original + '\n');
    assert.equal(collect().size, 0, 'dirty bytes cannot use committed proof');
    git('reset', '--hard', baseline);
    const copied = {
      ...record,
      rationale: record.rationale + ' Copied value ' + record.scope_sha256,
    };
    fs.writeFileSync(path.join(directory, file), JSON.stringify(copied, null, 2));
    git('add', file);
    git('commit', '--quiet', '-m', 'Controlled copied field');
    assert.equal(collect().get(file).locations.has(hash), false, 'same value in prose is unproved');
    git('reset', '--hard', baseline);
    const changed = { ...record, scope_sha256: 'a'.repeat(64) };
    fs.writeFileSync(path.join(directory, file), JSON.stringify(changed));
    git('add', file);
    git('commit', '--quiet', '-m', 'Controlled stale scope');
    assert.equal(collect().size, 0);
    git('reset', '--hard', baseline);
    const mapFile = '.github/ri-ci-map.json';
    const map = JSON.parse(read(mapFile));
    map.fixtureChange = true;
    fs.writeFileSync(path.join(directory, mapFile), JSON.stringify(map));
    git('add', mapFile);
    git('commit', '--quiet', '-m', 'Controlled changed source');
    assert.equal(collect().size, 0, 'changed control source invalidates old scope');
    git('reset', '--hard', baseline);
    git('update-ref', '-d', 'refs/remotes/origin/main');
    assert.equal(collect().size, 0, 'missing main identity supplies no authority');
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

function browserIntegrityFixture() {
  const f = secretReviewFixture();
  const crypto = require('node:crypto');
  const inventoryFile = 'tools/quality/browser-archives.json';
  const selected = path.join(f.directory, 'selected-toolchain');
  const packages = {};
  const lock = { lockfileVersion: 3, packages: {} };
  for (const name of ['playwright', 'playwright-core']) {
    const integrity =
      'sha512-' +
      crypto
        .createHash('sha512')
        .update('public ' + name)
        .digest('base64');
    packages[name] = { version: '1.63.0', integrity };
    lock.packages['node_modules/' + name] = {
      ...packages[name],
      resolved: 'https://registry.npmjs.org/' + name + '/-/' + name + '-1.63.0.tgz',
    };
  }
  const snapshots = new Map();
  const write = (file, value) => {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(value));
    snapshots.set(file, fs.readFileSync(file));
  };
  write(path.join(f.directory, inventoryFile), {
    schema: 1,
    archives: [{ identity: { packages } }],
  });
  write(path.join(f.directory, 'tools/quality/toolchain/package-lock.json'), lock);
  write(path.join(selected, 'package-lock.json'), lock);
  write(path.join(selected, 'node_modules/.package-lock.json'), lock);
  for (const name of Object.keys(packages))
    write(path.join(selected, 'node_modules/' + name + '/package.json'), {
      name,
      version: '1.63.0',
    });
  const findings = Object.values(packages).map((entry) => ({
    type: 'Base64 High Entropy String',
    hashed_secret: crypto.createHash('sha1').update(entry.integrity).digest('hex'),
  }));
  f.reviews[2].findings = findings.map((finding) =>
    f.entry(inventoryFile, finding.type, finding.hashed_secret)
  );
  f.write(2);
  return { ...f, inventoryFile, selected, packages, findings, snapshots };
}

test('browser SRI findings require exact review IDs and a separate selected-toolchain proof', () => {
  const {
    loadSecretReviews,
    browserIntegrityProof,
    reviewedSecretFinding,
  } = require('../tools/quality/scanners.cjs');
  const f = browserIntegrityFixture();
  try {
    const reviewed = loadSecretReviews(f.directory);
    const proof = browserIntegrityProof(f.directory, f.selected);
    assert.equal(proof.size, 2);
    for (const finding of f.findings) {
      assert.equal(
        reviewedSecretFinding(f.inventoryFile, finding, reviewed, new Set(), proof),
        true
      );
      assert.equal(reviewedSecretFinding(f.inventoryFile, finding, reviewed), false);
      assert.equal(
        reviewedSecretFinding(f.inventoryFile, finding, new Map(), new Set(), proof),
        false
      );
      assert.equal(
        reviewedSecretFinding(f.inventoryFile, finding, reviewed, proof),
        false,
        'publication proof cannot authorize browser fields'
      );
      assert.equal(
        reviewedSecretFinding('other/' + f.inventoryFile, finding, reviewed, new Set(), proof),
        false
      );
      assert.equal(
        reviewedSecretFinding(
          f.inventoryFile,
          { ...finding, type: 'Secret Keyword' },
          reviewed,
          new Set(),
          proof
        ),
        false
      );
    }
    const unknown = { type: f.findings[0].type, hashed_secret: 'a'.repeat(40) };
    reviewed.set(f.entry(f.inventoryFile, unknown.type, unknown.hashed_secret).id, {});
    assert.equal(
      reviewedSecretFinding(f.inventoryFile, unknown, reviewed, new Set(), proof),
      false
    );
    for (const index of [0, 1, 3, 4]) {
      f.reviews[2].findings = [];
      f.write(2);
      f.reviews[index].findings = [
        f.entry(f.inventoryFile, f.findings[0].type, f.findings[0].hashed_secret),
      ];
      f.write(index);
      assert.throws(() => loadSecretReviews(f.directory), /Invalid exact secret review entry/);
      f.reviews[index].findings = [];
      f.write(index);
    }
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('browser integrity proof rejects field, authored-lock and selected installation drift', () => {
  const { browserIntegrityProof } = require('../tools/quality/scanners.cjs');
  const f = browserIntegrityFixture();
  const inventory = path.join(f.directory, f.inventoryFile);
  const authored = path.join(f.directory, 'tools/quality/toolchain/package-lock.json');
  const selectedLock = path.join(f.selected, 'package-lock.json');
  const installedLock = path.join(f.selected, 'node_modules/.package-lock.json');
  const installedPackage = path.join(f.selected, 'node_modules/playwright/package.json');
  try {
    for (const [file, mutate] of [
      [inventory, (value) => (value.archives[0].identity.packages.playwright.version = 'other')],
      [
        inventory,
        (value) =>
          (value.archives[0].identity.packages.playwright.integrity =
            f.packages['playwright-core'].integrity),
      ],
      [inventory, (value) => (value.archives[0].identity.packages.other = f.packages.playwright)],
      [
        inventory,
        (value) =>
          (value.notes = 'Copied outside its package field: ' + f.packages.playwright.integrity),
      ],
      [
        inventory,
        (value) =>
          (value.unrelated = { [f.packages.playwright.integrity]: 'copied as a property name' }),
      ],
      [inventory, (value) => (value.archives = [])],
      [authored, (value) => (value.packages['node_modules/playwright'].version = 'other')],
      [selectedLock, (value) => (value.packages['node_modules/playwright'].integrity = 'unproved')],
      [
        installedLock,
        (value) => (value.packages['node_modules/playwright'].integrity = 'unproved'),
      ],
      [installedLock, (value) => (value.packages['node_modules/playwright'].resolved = 'other')],
      [installedPackage, (value) => (value.name = 'other')],
      [installedPackage, (value) => (value.version = 'other')],
    ]) {
      const value = JSON.parse(f.snapshots.get(file));
      mutate(value);
      fs.writeFileSync(file, JSON.stringify(value));
      assert.throws(() => browserIntegrityProof(f.directory, f.selected));
      fs.writeFileSync(file, f.snapshots.get(file));
    }
    // Matching malformed strings across every input still do not prove a canonical NPM integrity.
    for (const file of [inventory, authored, selectedLock, installedLock]) {
      const value = JSON.parse(f.snapshots.get(file));
      const entry =
        file === inventory
          ? value.archives[0].identity.packages.playwright
          : value.packages['node_modules/playwright'];
      entry.integrity = 'sha512-not-canonical';
      fs.writeFileSync(file, JSON.stringify(value));
    }
    assert.throws(() => browserIntegrityProof(f.directory, f.selected), /Noncanonical/);
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('browser integrity proof refuses missing, malformed, symlinked or oversized proof files', () => {
  const { browserIntegrityProof } = require('../tools/quality/scanners.cjs');
  const f = browserIntegrityFixture();
  try {
    for (const [file, original] of f.snapshots) {
      fs.unlinkSync(file);
      assert.throws(() => browserIntegrityProof(f.directory, f.selected), /ENOENT/);
      fs.writeFileSync(file, '{');
      assert.throws(() => browserIntegrityProof(f.directory, f.selected));
      fs.writeFileSync(file + '.original', original);
      fs.unlinkSync(file);
      fs.symlinkSync(file + '.original', file);
      assert.throws(() => browserIntegrityProof(f.directory, f.selected), /symlink/);
      fs.unlinkSync(file);
      fs.writeFileSync(file, Buffer.alloc(2000001, 32));
      assert.throws(() => browserIntegrityProof(f.directory, f.selected), /Oversized/);
      fs.writeFileSync(file, original);
    }
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('public npm integrity dispositions require the exact inventory path, ledger and current lock proof', () => {
  const crypto = require('node:crypto');
  const {
    loadSecretReviews,
    reviewedSecretFinding,
    publicationIntegrityProof,
  } = require('../tools/quality/scanners.cjs');
  const f = secretReviewFixture();
  const inventoryFile = 'tools/publishing/toolchain/licenses.json';
  const directory = path.join(f.directory, 'tools/publishing/toolchain');
  fs.mkdirSync(directory, { recursive: true });
  const integrity =
    'sha512-' +
    crypto
      .createHash('sha512')
      .update('Public controlled npm registry integrity fixture')
      .digest('base64');
  const hash = crypto.createHash('sha1').update(integrity).digest('hex');
  const lock = {
    lockfileVersion: 3,
    packages: {
      '': { name: 'fixture' },
      'node_modules/fixture-package': { version: '1.0.0', integrity },
    },
  };
  const lockBytes = JSON.stringify(lock);
  const inventory = {
    schema: 1,
    dependencyLockSha256: crypto.createHash('sha256').update(lockBytes).digest('hex'),
    packages: [
      {
        name: 'fixture-package',
        location: 'node_modules/fixture-package',
        version: '1.0.0',
        integrity,
      },
    ],
  };
  const writeInventory = (value) =>
    fs.writeFileSync(path.join(f.directory, inventoryFile), JSON.stringify(value));
  try {
    fs.writeFileSync(path.join(directory, 'package-lock.json'), lockBytes);
    writeInventory(inventory);
    f.reviews[3].findings.push(f.entry(inventoryFile, 'Base64 High Entropy String', hash));
    f.write(3);
    const finding = { type: 'Base64 High Entropy String', hashed_secret: hash };
    const reviewed = loadSecretReviews(f.directory);
    const proof = publicationIntegrityProof(f.directory);
    assert.equal(proof.size, 1);
    assert.equal(reviewedSecretFinding(inventoryFile, finding, reviewed, proof), true);
    assert.equal(
      reviewedSecretFinding(inventoryFile, finding, reviewed),
      false,
      'a ledger alone cannot supply the current dependency proof'
    );
    assert.equal(
      reviewedSecretFinding(
        inventoryFile,
        { ...finding, hashed_secret: 'b'.repeat(40) },
        reviewed,
        proof
      ),
      false
    );
    for (const mutate of [
      (value) => {
        value.dependencyLockSha256 = 'a'.repeat(64);
      },
      (value) => {
        value.packages[0].version = '2.0.0';
      },
      (value) => {
        value.packages[0].integrity = 'sha512-' + Buffer.from('unproved value').toString('base64');
      },
      (value) => {
        value.packages[0].location = 'node_modules/other';
      },
      (value) => {
        value.packages.push(structuredClone(value.packages[0]));
      },
    ]) {
      const value = structuredClone(inventory);
      mutate(value);
      writeInventory(value);
      assert.throws(() => publicationIntegrityProof(f.directory), /integrity|inventory/);
    }
    writeInventory(inventory);
    for (const index of [0, 1, 2, 4]) {
      f.reviews[3].findings = [];
      f.write(3);
      f.reviews[index].findings = [f.entry(inventoryFile, finding.type, hash)];
      f.write(index);
      assert.throws(() => loadSecretReviews(f.directory), /Invalid exact secret review entry/);
      f.reviews[index].findings = [];
      f.write(index);
    }
    f.reviews[3].findings = [f.entry('review/arbitrary-integrity.json', finding.type, hash)];
    f.write(3);
    assert.throws(() => loadSecretReviews(f.directory), /Invalid exact secret review entry/);
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('secret ledgers reject malformed metadata and non-exact or non-checksum companion records', () => {
  const { loadSecretReviews } = require('../tools/quality/scanners.cjs');
  const f = secretReviewFixture();
  try {
    const record = f.entry('review/public.json');
    for (const changed of [
      null,
      [],
      { ...record, path: '/absolute.json' },
      { ...record, path: '../escape.json' },
      { ...record, path: 'review/./public.json' },
      { ...record, path: 'review//public.json' },
      { ...record, path: 'review\\public.json' },
      { ...record, path: 'review/*.json' },
      { ...record, path: 'review/line\npublic.json' },
      { ...record, path: 'review:public.json' },
      { ...record, id: 'wrong:' + record.id },
      { ...record, id: record.id.slice(0, -1) + 'z' },
      { ...record, id: record.id.slice(0, -1) },
      { ...record, disposition: 'accepted risk' },
      { ...record, reason: ' ' },
      { ...record, extraAdmission: true },
      f.entry('review/public.json', 'Secret Keyword'),
      f.entry('review/public.json', 'Basic Auth Credentials'),
      f.entry('review/public.json', 'unknown rule'),
    ]) {
      f.write(2, { ...f.reviews[2], findings: [changed] });
      assert.throws(() => loadSecretReviews(f.directory), /Invalid exact secret review entry/);
    }
    for (const changed of [
      null,
      [],
      { ...f.reviews[2], schema_version: true },
      { ...f.reviews[2], schema_version: 2 },
      { ...f.reviews[2], owner: '' },
      { ...f.reviews[2], issue: 'https://example.com/69' },
      { ...f.reviews[2], issue: [f.reviews[2].issue] },
      { ...f.reviews[2], reviewedAt: '2026-02-30' },
      { ...f.reviews[2], reviewedAt: [f.reviews[2].reviewedAt] },
      { ...f.reviews[2], reviewedAt: '2026-10-11T00:00:00Z' },
      { ...f.reviews[2], scope: '' },
      { ...f.reviews[2], findings: {} },
      { ...f.reviews[2], extraLedger: 'other.json' },
    ]) {
      f.write(2, changed);
      assert.throws(() => loadSecretReviews(f.directory), /Invalid secret review metadata/);
    }
    f.write(2);
    f.write(0, { ...f.reviews[0], schema_version: 1 });
    assert.throws(() => loadSecretReviews(f.directory), /Invalid secret review metadata/);
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('secret ledgers reject duplicate IDs within or across every closed input', () => {
  const { loadSecretReviews } = require('../tools/quality/scanners.cjs');
  const f = secretReviewFixture();
  try {
    const record = f.entry('review/public.json');
    for (let first = 0; first < f.files.length; first++) {
      for (let second = first; second < f.files.length; second++) {
        f.reviews.forEach((review) => (review.findings = []));
        f.reviews[first].findings.push(record);
        f.reviews[second].findings.push(record);
        f.files.forEach((_, index) => f.write(index));
        assert.throws(() => loadSecretReviews(f.directory), /Duplicate secret review ID/);
      }
    }
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('secret ledgers require all bounded regular inputs and reject invalid JSON', () => {
  const { loadSecretReviews } = require('../tools/quality/scanners.cjs');
  const f = secretReviewFixture();
  try {
    for (let index = 0; index < f.files.length; index++) {
      const absolute = path.join(f.directory, f.files[index]);
      fs.unlinkSync(absolute);
      assert.throws(() => loadSecretReviews(f.directory), /ENOENT/);
      fs.mkdirSync(absolute);
      assert.throws(() => loadSecretReviews(f.directory), /Invalid or oversized/);
      fs.rmdirSync(absolute);
      fs.symlinkSync(path.join(f.directory, f.files[(index + 1) % f.files.length]), absolute);
      assert.throws(() => loadSecretReviews(f.directory), /Invalid or oversized/);
      fs.unlinkSync(absolute);
      const bytes = JSON.stringify(f.reviews[index]);
      fs.writeFileSync(absolute, bytes.padEnd(2000000));
      assert.equal(loadSecretReviews(f.directory).size, 0);
      fs.appendFileSync(absolute, ' ');
      assert.throws(() => loadSecretReviews(f.directory), /Invalid or oversized/);
      fs.writeFileSync(absolute, '{');
      assert.throws(() => loadSecretReviews(f.directory), SyntaxError);
      f.write(index);
    }
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('all historical secret dispositions retain their exact data in the closed ledger map', () => {
  const { loadSecretReviews } = require('../tools/quality/scanners.cjs');
  const reviewed = loadSecretReviews(root);
  const legacy = [
    'tools/quality/secrets-baseline.json',
    'tools/quality/secrets-reviewed.json',
    'tools/quality/secrets-publication.json',
  ];
  for (const file of legacy) {
    const source = JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
    for (const entry of source.findings) assert.deepEqual(reviewed.get(entry.id), entry);
  }
  const previousPublication = JSON.parse(
    cp.execFileSync(
      'git',
      ['show', '16d4b1cd03afbb3d01194bbda3d5a2db2edab2d4:tools/quality/secrets-publication.json'],
      { cwd: root, encoding: 'utf8' }
    )
  );
  for (const entry of previousPublication.findings)
    assert.deepEqual(
      reviewed.get(entry.id),
      entry,
      'preserve each original publication disposition'
    );
});

function generatedChecksumFixture() {
  const helper = require('../tools/quality/generated-checksums.cjs');
  const crypto = require('node:crypto');
  const bytes = new Map();
  const readBytes = (file) => {
    if (!bytes.has(file)) bytes.set(file, fs.readFileSync(path.join(root, file)));
    return bytes.get(file);
  };
  const read = (file) => readBytes(file).toString('utf8');
  const write = (file, text) => bytes.set(file, Buffer.from(text));
  const digest = (text, algorithm = 'sha256') =>
    crypto.createHash(algorithm).update(text).digest('hex');
  const manifestFile = 'review/site-v1-static-previews-v11.json';
  const manifest = JSON.parse(read(manifestFile));
  const fixture = {
    helper,
    read,
    readBytes,
    write,
    digest,
    lock: JSON.parse(read('site/output-lock.json')),
    revision: JSON.parse(read('docs/site-revision.json')),
    previews: Object.fromEntries(
      [...Object.keys(manifest.files), manifestFile].map((file) => [file, read(file)])
    ),
    bundle: JSON.parse(read('review/site-v1-offline-bundle-v11.json')),
  };
  fixture.collect = () => helper.collectChecksumFields(fixture);
  fixture.has = (collected, file, value) =>
    collected.get(file)?.locations.has(digest(value, 'sha1')) === true;
  return fixture;
}

test('generated field collection follows a changed content identity without modifying secret ledgers', () => {
  const fixture = generatedChecksumFixture();
  const before = fs.readFileSync(path.join(root, 'tools/quality/secrets-reviewed-checksums.json'));
  const old = fixture.revision.routes.writing;
  const version = fixture.digest('A newly rendered Writing content edition');
  const snapshot = 'snapshots/' + version + '/writing.html';
  const html = fixture.read('docs/writing.html').replaceAll(old.version, version);
  fixture.write('docs/writing.html', html);
  fixture.write('docs/' + snapshot, html);
  fixture.revision.routes.writing = {
    ...old,
    version,
    url: snapshot,
    sha256: fixture.digest(html),
  };
  fixture.lock.routes.writing = {
    ...fixture.lock.routes.writing,
    version,
    snapshotSHA: fixture.digest(html),
  };
  delete fixture.lock.files[old.url];
  fixture.lock.files[snapshot] = fixture.digest(html);
  fixture.write('docs/site-revision.json', JSON.stringify(fixture.revision, null, 2));
  fixture.write('site/output-lock.json', JSON.stringify(fixture.lock, null, 2));
  const collected = fixture.collect();
  assert.ok(fixture.has(collected, 'docs/writing.html', version));
  assert.ok(fixture.has(collected, 'docs/' + snapshot, version));
  assert.ok(fixture.has(collected, 'site/output-lock.json', version));
  assert.equal(fixture.has(collected, 'docs/writing.html', old.version), false);
  assert.deepEqual(
    fs.readFileSync(path.join(root, 'tools/quality/secrets-reviewed-checksums.json')),
    before
  );
  for (const [file, value] of [
    ['docs/writing.html', version],
    ['site/output-lock.json', fixture.lock.components.client],
  ]) {
    const checksum = fixture.digest(value, 'sha1');
    const locations = collected.get(file)?.locations.get(checksum);
    assert.ok(locations?.size, 'the candidate finding must have a valid computed location');
    const finding = {
      type: 'Hex High Entropy String',
      hashed_secret: checksum,
      line_number: locations.values().next().value,
    };
    assert.equal(
      fixture.helper.verifiedGeneratedChecksumFinding(file, finding, {
        proved: collected,
      }),
      false,
      'pure caller-supplied field data cannot create a production admission proof'
    );
  }
  assert.throws(
    () => fixture.helper.admitGeneratedChecksumFindings({}, { proved: collected }),
    /Unverified/
  );
});

test('generated checksum collection rejects arbitrary fields and same-known-value prose or external URLs', () => {
  for (const extra of [
    (value) => '<p>' + value + '</p>',
    (value) => '<!-- <meta name="site-engine" content="' + value + '"> -->',
    (value) =>
      '<script>window.fixture=\'<meta name="site-engine" content="' + value + '">\';</script>',
    (value) => '<textarea><meta name="site-engine" content="' + value + '"></textarea>',
    (value) => '<title><meta name="site-engine" content="' + value + '"></title>',
    (value) => '<a href="https://example.org/' + value + '">External</a>',
    (value) => '<p href="runtime/' + value + '/theme.js">Text</p>',
    (value) => '<a href="runtime/' + value + '/theme.js">Text</a>',
  ]) {
    const fixture = generatedChecksumFixture();
    const file = 'docs/index.html',
      value = fixture.revision.engine;
    fixture.write(file, fixture.read(file).replace('</body>', extra(value) + '</body>'));
    assert.equal(fixture.has(fixture.collect(), file, value), false);
  }
  for (const valueKind of ['known', 'unknown']) {
    const fixture = generatedChecksumFixture();
    const file = 'docs/site-revision.json';
    const value =
      valueKind === 'known'
        ? fixture.revision.engine
        : fixture.digest('Unapproved extra JSON field');
    fixture.write(file, JSON.stringify({ ...fixture.revision, notes: value }, null, 2));
    assert.equal(fixture.has(fixture.collect(), file, value), false);
  }
  const fixture = generatedChecksumFixture();
  const file = 'site/output-lock.json';
  const client = fixture.lock.components.client;
  assert.match(client, /^[a-f0-9]{64}$/);
  assert.ok(fixture.has(fixture.collect(), file, client));
  fixture.write(file, JSON.stringify({ ...fixture.lock, notes: client }, null, 2));
  assert.equal(
    fixture.has(fixture.collect(), file, client),
    false,
    'a known client fingerprint copied outside its computed field is not admitted'
  );
});

test('article resource names and unauthorized owners do not become computed checksum fields', () => {
  const fixture = generatedChecksumFixture();
  const name = fixture.digest('Authored asset basename, not its computed content digest');
  const assetDigest = fixture.digest('Actual asset bytes');
  const resource = 'article-media/' + assetDigest + '/' + name + '.png';
  const version = fixture.digest('Article edition');
  const article = {
    version,
    sha256: fixture.digest('Snapshot bytes'),
    alias: 'articles/fixture.html',
    url: 'article-snapshots/' + version + '/fixture.html',
    assets: [resource],
    sourceSha256: fixture.digest('Manuscript bytes'),
    semanticSha256: fixture.digest('Article semantics'),
  };
  fixture.revision.articles = { 'fixture:en': article };
  fixture.lock.articles = {
    'fixture:en': { ...article, snapshot: article.url },
  };
  fixture.lock.files[resource] = assetDigest;
  fixture.bundle.entries['site/' + resource] = assetDigest;
  fixture.write('docs/site-revision.json', JSON.stringify(fixture.revision, null, 2));
  fixture.write('site/output-lock.json', JSON.stringify(fixture.lock, null, 2));
  fixture.write('review/site-v1-offline-bundle-v11.json', JSON.stringify(fixture.bundle, null, 2));
  const html =
    '<html><head><meta name="site-engine" content="' +
    fixture.revision.engine +
    '">' +
    '<meta name="site-route" content="' +
    version +
    '"></head><body><img src="' +
    resource +
    '"></body></html>';
  for (const file of [article.alias, article.url]) fixture.write('docs/' + file, html);
  const collected = fixture.collect();
  for (const file of [
    'docs/site-revision.json',
    'site/output-lock.json',
    'docs/' + article.alias,
    'docs/' + article.url,
    'review/site-v1-offline-bundle-v11.json',
  ]) {
    assert.equal(fixture.has(collected, file, name), false, file);
    assert.ok(fixture.has(collected, file, assetDigest), file);
  }
  assert.equal(collected.has('review/unapproved-archive.html'), false);
  const finding = {
    type: 'Secret Keyword',
    hashed_secret: fixture.digest(assetDigest, 'sha1'),
    line_number: 1,
  };
  assert.equal(
    fixture.helper.verifiedGeneratedChecksumFinding('docs/' + article.alias, finding, collected),
    false
  );
  assert.equal(
    fixture.helper.verifiedGeneratedChecksumFinding(
      'review/unapproved-archive.html',
      { ...finding, type: 'Hex High Entropy String' },
      collected
    ),
    false
  );
});

test('one-line inert payload fields require their exact role and recomputed page bytes', () => {
  for (const mutation of ['extra', 'stale']) {
    const fixture = generatedChecksumFixture();
    const file = 'review/site-v1-20261004-v11-interactive.html';
    const pattern = /(<script type="application\/json" id="site-pages">)([\s\S]*?)(<\/script>)/;
    const match = fixture.read(file).match(pattern);
    const payload = JSON.parse(match[2]);
    const value =
      mutation === 'extra' ? fixture.revision.engine : payload.revision.routes.writing.sha256;
    if (mutation === 'extra') payload.privateNotes = value;
    else payload.pages.writing += '<p>A changed page whose old digest must fail.</p>';
    const changed = fixture
      .read(file)
      .replace(
        pattern,
        () => match[1] + JSON.stringify(payload).replace(/</g, '\\u003c') + match[3]
      );
    fixture.write(file, changed);
    fixture.previews[file] = changed;
    assert.equal(fixture.has(fixture.collect(), file, value), false);
  }
});

function publicationChecksumFixture() {
  const directory = fs.mkdtempSync(
    path.join(require('node:os').tmpdir(), 'publication-checksum-test-')
  );
  const publisher = require('../tools/publishing/article.cjs');
  const digest = (bytes, algorithm = 'sha256') =>
    require('node:crypto').createHash(algorithm).update(bytes).digest('hex');
  const owner = 'site/publications/checksum-fixture';
  const write = (file, value) => {
    const target = path.join(directory, file);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, value);
  };
  const json = (file, value) => write(file, JSON.stringify(value, null, 2) + '\n');
  const git = (...args) =>
    cp
      .execFileSync(
        'git',
        ['-c', 'user.name=Checksum fixture', '-c', 'user.email=fixture@example.invalid', ...args],
        { cwd: directory, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }
      )
      .trim();
  git('init', '--quiet');
  write(owner + '/manuscript.en.md', '# Checksum article\n\nFirst complete edition.\n');
  write(owner + '/launch-post.en.md', 'First authored launch.\n');
  const metadata = {
    schema: 1,
    id: 'checksum-fixture',
    slug: 'checksum-fixture',
    title: 'Checksum article',
    summary: 'A synthetic source proof.',
    authors: [{ name: 'Fixture author' }],
    language: 'en',
    topic: 'delivery',
    owner: { repository: 'oborskyivitalii/oborskyivitalii', path: owner },
    status: 'draft',
    source: 'manuscript.en.md',
    edition: 'v1',
    rights: { status: 'review-pending', notice: 'Synthetic test artifact.', references: [] },
    profile: 'profile.json',
    references: [],
    assets: [],
    platforms: {
      linkedin: {
        mode: 'adaptation',
        source: 'adaptations/linkedin.en.md',
        edition: 'linkedin-v1',
      },
      medium: { mode: 'equivalent-rendition' },
    },
    canonical: null,
  };
  write(owner + '/adaptations/linkedin.en.md', '# Adaptation\n\nA distinct short argument.\n');
  const edition = {
    schema: 1,
    id: 'v1',
    articleId: metadata.id,
    language: 'en',
    kind: 'full-article',
    source: {
      path: metadata.source,
      sha256: digest(fs.readFileSync(path.join(directory, owner, metadata.source))),
      commit: null,
      blob: null,
    },
    owner: 'site',
    derivation: null,
    rights: 'review-pending',
  };
  const adaptation = {
    ...edition,
    id: 'linkedin-v1',
    kind: 'adaptation',
    source: {
      ...edition.source,
      path: 'adaptations/linkedin.en.md',
      sha256: digest(fs.readFileSync(path.join(directory, owner, 'adaptations/linkedin.en.md'))),
    },
  };
  const profile = {
    schema: 1,
    id: 'checksum-fixture-profile',
    platforms: {
      linkedin: { formats: ['txt'], relationship: 'adaptation' },
      medium: { formats: ['txt'], relationship: 'equivalent-rendition' },
    },
    launch: {
      source: 'launch-post.en.md',
      sha256: digest(fs.readFileSync(path.join(directory, owner, 'launch-post.en.md'))),
    },
    seo: { title: 'Authored distribution title', summary: metadata.summary },
    assets: { cover: { omitReason: 'Plain fixture.' }, hero: { omitReason: 'Plain fixture.' } },
    limits: {},
  };
  function save() {
    edition.semanticSha256 = publisher.semanticDigest(metadata, edition.source);
    adaptation.derivation = {
      relationship: 'adaptation',
      baseEdition: edition.id,
      baseSourceSha256: edition.source.sha256,
      baseSemanticSha256: edition.semanticSha256,
    };
    adaptation.semanticSha256 = publisher.adaptationDigest(
      metadata,
      adaptation.source,
      edition,
      'linkedin'
    );
    json(owner + '/publication.json', metadata);
    json(owner + '/profile.json', profile);
    json(owner + '/editions/' + edition.id + '.json', edition);
    json(owner + '/editions/' + adaptation.id + '.json', adaptation);
  }
  save();
  git('add', '.');
  git('commit', '--quiet', '-m', 'Prepare source bytes');
  return {
    directory,
    owner,
    metadata,
    edition,
    adaptation,
    profile,
    publisher,
    digest,
    write,
    json,
    git,
    save,
  };
}

test('strict local publisher proof retains frozen versions and admits new source, adaptation and launch hashes', () => {
  const f = publicationChecksumFixture();
  const helper = require('../tools/quality/generated-checksums.cjs');
  const read = (file) => fs.readFileSync(path.join(f.directory, file), 'utf8');
  const collect = () => helper.collectPublicationChecksumFields(f.directory, read);
  const has = (records, file, value) =>
    records.get(file)?.locations.has(f.digest(value, 'sha1')) === true;
  try {
    const pin = () => {
      for (const edition of [f.edition, f.adaptation]) {
        edition.source.commit = f.git('rev-parse', 'HEAD');
        edition.source.blob = f.git('rev-parse', 'HEAD:' + f.owner + '/' + edition.source.path);
        edition.rights = 'accepted';
      }
    };
    f.metadata.status = 'accepted';
    f.metadata.rights.status = 'accepted';
    pin();
    f.save();
    // The exact frozen records precede the existence of their selecting metadata.
    f.git('rm', '--cached', '--force', '--quiet', f.owner + '/publication.json');
    f.git('add', f.owner + '/editions');
    f.git('commit', '--quiet', '-m', 'Freeze v1 records before selecting metadata');
    f.save();
    f.git('add', '.');
    f.git('commit', '--quiet', '-m', 'Select complete accepted v1');
    const old = JSON.parse(read(f.owner + '/editions/v1.json'));
    const oldAdaptation = JSON.parse(read(f.owner + '/editions/linkedin-v1.json'));
    for (let index = 0; index < 101; index++) {
      f.metadata.slug = 'checksum-fixture-' + index;
      f.json(f.owner + '/publication.json', f.metadata);
      f.git('add', f.owner + '/publication.json');
      f.git('commit', '--quiet', '-m', 'Metadata-only slug update');
    }
    f.edition.id = 'v2';
    f.adaptation.id = 'linkedin-v2';
    f.metadata.edition = f.edition.id;
    f.metadata.platforms.linkedin.edition = f.adaptation.id;
    f.metadata.status = 'draft';
    f.metadata.rights.status = 'review-pending';
    f.write(f.owner + '/manuscript.en.md', '# Checksum article\n\nSecond complete edition.\n');
    f.write(f.owner + '/launch-post.en.md', 'A changed authored launch.\n');
    for (const edition of [f.edition, f.adaptation]) {
      edition.source = {
        ...edition.source,
        commit: null,
        blob: null,
        sha256: f.digest(fs.readFileSync(path.join(f.directory, f.owner, edition.source.path))),
      };
      edition.rights = 'review-pending';
    }
    f.profile.launch.sha256 = f.digest(
      fs.readFileSync(path.join(f.directory, f.owner, 'launch-post.en.md'))
    );
    f.save();
    f.git('add', '.');
    f.git('commit', '--quiet', '-m', 'Prepare v2 source bytes');
    pin();
    f.metadata.status = 'accepted';
    f.metadata.rights.status = 'accepted';
    f.save();
    f.git('add', '.');
    f.git('commit', '--quiet', '-m', 'Select complete accepted v2');
    const records = collect();
    const originalHead = fs.readFileSync(path.join(f.directory, '.git/HEAD'));
    const originalConfig = fs.readFileSync(path.join(f.directory, '.git/config'));
    const outsideConfig = path.join(f.directory, 'outside-config');
    fs.writeFileSync(outsideConfig, '[core]\n\thooksPath = fixture-original-hooks\n');
    const outsideBytes = fs.readFileSync(outsideConfig);
    for (const variable of [
      'GIT_DIR',
      'GIT_CONFIG',
      'GIT_CONFIG_COUNT',
      'GIT_CONFIG_PARAMETERS',
      'GIT_CONFIG_KEY_0',
      'GIT_CONFIG_VALUE_0',
      'git_config_key_0',
    ]) {
      const inherited = process.env[variable];
      try {
        process.env[variable] =
          variable === 'GIT_DIR' ? path.join(f.directory, '.git') : outsideConfig;
        assert.throws(collect, /Inherited Git routing/);
      } finally {
        if (inherited === undefined) delete process.env[variable];
        else process.env[variable] = inherited;
      }
      assert.deepEqual(fs.readFileSync(outsideConfig), outsideBytes);
    }
    assert.deepEqual(fs.readFileSync(path.join(f.directory, '.git/HEAD')), originalHead);
    assert.deepEqual(fs.readFileSync(path.join(f.directory, '.git/config')), originalConfig);
    for (const edition of [old, oldAdaptation, f.edition, f.adaptation]) {
      const file = f.owner + '/editions/' + edition.id + '.json';
      for (const value of [
        edition.source.sha256,
        edition.semanticSha256,
        edition.source.commit,
        edition.source.blob,
      ])
        assert.ok(has(records, file, value), file);
    }
    assert.ok(has(records, f.owner + '/profile.json', f.profile.launch.sha256));
    assert.ok(has(records, f.owner + '/editions/linkedin-v2.json', f.edition.semanticSha256));
    assert.deepEqual(JSON.parse(read(f.owner + '/editions/v1.json')), old);
    const orphan = {
      ...f.edition,
      id: 'orphan',
      source: { ...f.edition.source, commit: null, blob: null },
    };
    f.json(f.owner + '/editions/orphan.json', orphan);
    assert.equal(collect().has(f.owner + '/editions/orphan.json'), false);
    f.write(f.owner + '/manuscript.en.md', '# Checksum article\n\nUnpinned source drift.\n');
    assert.throws(collect, /Source bytes do not match/);
  } finally {
    fs.rmSync(f.directory, { recursive: true, force: true });
  }
});

test('independent scanner engines retain current raw results and continue after sibling failures', (t) => {
  const { collectEngines } = require('../tools/quality/scanners.cjs');
  const directory = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'scanner-engines-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  for (const names of [
    ['eslint', 'stylelint', 'ruff'],
    ['semgrep', 'bandit', 'secrets'],
    ['npm', 'pip'],
  ]) {
    const calls = [];
    fs.writeFileSync(path.join(directory, names[0] + '.json'), 'stale successful report');
    const engines = names.map((name, index) => ({
      name,
      reports: [name + '.json'],
      run: () => {
        calls.push(name);
        if (index === 0) throw Error('controlled tool/feed failure');
        fs.writeFileSync(path.join(directory, name + '.json'), JSON.stringify({ engine: name }));
        if (index === 1 && names.length === 3) throw Error('controlled policy rejection');
        return { observed: true };
      },
    }));
    let failure;
    assert.throws(
      () => collectEngines(engines, directory),
      (error) => {
        failure = error;
        return /Scanner engines failed/.test(error.message);
      }
    );
    assert.deepEqual(calls, names);
    assert.deepEqual(
      failure.detail.engines.map((row) => row.name),
      names
    );
    assert.equal(failure.detail.engines[0].pass, false);
    assert.deepEqual(
      failure.detail.engines[0].rawReports,
      [],
      'stale raw evidence cannot stand in for a failed invocation'
    );
    assert.equal(failure.detail.engines.at(-1).pass, true);
    for (const row of failure.detail.engines.slice(1)) {
      assert.equal(row.rawReports.length, 1);
      const bytes = fs.readFileSync(path.join(directory, row.rawReports[0].file));
      assert.equal(row.rawReports[0].bytes, bytes.length);
      assert.equal(
        row.rawReports[0].sha256,
        require('../tools/quality/artifact.cjs').digest(bytes)
      );
    }
  }
});
test('Python advisory reports require every unique exact pin and reject skipped or malformed clean claims', () => {
  const {
    admitPythonAdvisories,
    pinnedPythonRequirements,
  } = require('../tools/quality/scanners.cjs');
  const requirements = '# exact input\nExample_Pkg==1.2.3\nsecond.pkg==4.5.6\n';
  const report = {
    dependencies: [
      { name: 'example-pkg', version: '1.2.3', vulns: [] },
      { name: 'Second.Pkg', version: '4.5.6', vulns: [] },
    ],
  };
  const before = structuredClone(report);
  assert.deepEqual(admitPythonAdvisories(report, requirements), {
    dependencies: 2,
  });
  for (const mutate of [
    (value) => value.dependencies.pop(),
    (value) => value.dependencies.push(structuredClone(value.dependencies[0])),
    (value) => {
      value.dependencies[1].name = 'unknown';
    },
    (value) => {
      value.dependencies[0].version = '1.2.4';
    },
    (value) => {
      value.dependencies[0].skip_reason = 'not audited';
    },
    (value) => {
      value.dependencies[0].skip_reason = '';
    },
    (value) => {
      delete value.dependencies[0].vulns;
    },
    (value) => {
      value.dependencies[0].vulns = {};
    },
    (value) => {
      value.dependencies[0].vulns = [{ id: 'controlled-advisory' }];
    },
    (value) => {
      value.dependencies = [];
    },
    (value) => {
      value.dependencies = {};
    },
    (value) => {
      delete value.dependencies;
    },
  ]) {
    const changed = structuredClone(report);
    mutate(changed);
    assert.throws(() => admitPythonAdvisories(changed, requirements));
  }
  assert.deepEqual(report, before, 'policy review never deletes raw findings');
  for (const input of [
    '',
    'one>=1',
    '-r other.txt',
    'one==1; python_version>"3"',
    'one==1\nONE==1',
    'one.pkg==1\none-pkg==1',
  ])
    assert.throws(() => pinnedPythonRequirements(input));
});
test('npm advisory policy rejects feed failures and every stale or expanded exact reachability exception', (t) => {
  const { admitNpmAdvisories } = require('../tools/quality/scanners.cjs');
  const { digest } = require('../tools/quality/artifact.cjs');
  const fixturePackage = 'reviewed-fixture',
    fixtureVersion = '1.2.3',
    fixtureAdvisory = 'https://example.invalid/advisory-fixture',
    reviewedSource = 'tools/reviewed-tool.cjs';
  // Own the reviewed bytes: real repository policy may legitimately become stale
  // after a dependency update or be renewed by a separate reachability review.
  const materials = {
    [reviewedSource]: "'use strict';\nmodule.exports = {};\n",
    'tools/reviewed-config.json': '{"fixture":true}\n',
    'tools/quality/toolchain/package-lock.json':
      JSON.stringify({
        lockfileVersion: 3,
        packages: { ['node_modules/' + fixturePackage]: { version: fixtureVersion } },
      }) + '\n',
  };
  const exceptions = [
    {
      package: fixturePackage,
      version: fixtureVersion,
      url: fixtureAdvisory,
      reviewedSource,
      reviewedSourceSha256: digest(materials[reviewedSource]),
      reviewedMaterials: Object.fromEntries(
        Object.entries(materials)
          .filter(([file]) => file !== reviewedSource)
          .map(([file, bytes]) => [file, digest(bytes)])
      ),
      expires: '2026-11-03',
    },
  ];
  const exception = exceptions[0];
  const directory = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'advisory-policy-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const files = Object.keys(materials);
  for (const file of files) {
    fs.mkdirSync(path.dirname(path.join(directory, file)), { recursive: true });
    fs.writeFileSync(path.join(directory, file), materials[file]);
  }
  const options = {
    projectRoot: directory,
    toolchain: path.join(directory, 'tools/quality/toolchain'),
    exceptions,
    now: new Date('2026-10-15T00:00:00Z'),
  };
  const report = {
    metadata: { dependencies: { total: 1 }, vulnerabilities: { total: 1 } },
    vulnerabilities: {
      [fixturePackage]: { via: [{ name: exception.package, url: exception.url }] },
    },
  };
  assert.equal(admitNpmAdvisories(report, options).findings, 1);
  const before = structuredClone(report);
  for (const mutate of [
    (value) => {
      value.error = { message: 'controlled feed failure' };
    },
    (value) => {
      delete value.metadata;
    },
    (value) => {
      delete value.metadata.dependencies;
    },
    (value) => {
      value.metadata.dependencies = {};
    },
    (value) => {
      value.metadata.dependencies.total = 0;
    },
    (value) => {
      value.metadata.dependencies.total = -1;
    },
    (value) => {
      value.metadata.dependencies.total = '1';
    },
    (value) => {
      value.metadata.vulnerabilities.total = -1;
    },
    (value) => {
      value.vulnerabilities[fixturePackage].via[0].url = 'https://example.invalid/new-advisory';
    },
    (value) => {
      value.vulnerabilities[fixturePackage].via = ['unresolved-chain'];
    },
  ]) {
    const changed = structuredClone(report);
    mutate(changed);
    assert.throws(() => admitNpmAdvisories(changed, options));
  }
  for (const mutate of [
    (value) => {
      value.expires = 'not-a-date';
    },
    (value) => {
      value.expires = '2026-02-30';
    },
    (value) => {
      value.expires = '2026-10-14';
    },
    (value) => {
      value.version = '0.0.0';
    },
    (value) => {
      value.reviewedSourceSha256 = '0'.repeat(64);
    },
    (value) => {
      value.reviewedMaterials[files.at(-1)] = '0'.repeat(64);
    },
  ]) {
    const changed = structuredClone(exceptions);
    mutate(changed[0]);
    assert.throws(() => admitNpmAdvisories(report, { ...options, exceptions: changed }));
  }
  for (const file of files) {
    const target = path.join(directory, file),
      bytes = fs.readFileSync(target);
    fs.appendFileSync(target, '\nchanged reviewed bytes\n');
    assert.throws(() => admitNpmAdvisories(report, options));
    fs.writeFileSync(target, bytes);
  }
  assert.deepEqual(report, before);
});
test('actual scanner category control flow keeps later engines and reports failed prerequisites honestly', (t) => {
  const vm = require('node:vm'),
    { createRequire } = require('node:module');
  const filename = path.join(root, 'tools/quality/scanners.cjs');
  const source = fs.readFileSync(filename, 'utf8'),
    nativeRequire = createRequire(filename);
  const parent = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'scanner-cli-'));
  t.after(() => fs.rmSync(parent, { recursive: true, force: true }));
  const execute = (kind, invalidIdentity = false) => {
    const directory = path.join(parent, kind + (invalidIdentity ? '-blocked' : ''));
    fs.mkdirSync(directory);
    const calls = [],
      reports = [];
    const output = (value = '') => ({ status: 0, stdout: value, stderr: '' });
    const write = (name, value) =>
      fs.writeFileSync(path.join(directory, name), JSON.stringify(value));
    const spawnSync = (command, args, options) => {
      if (command === 'git') return cp.spawnSync(command, args, options);
      const tool = path.basename(command);
      calls.push(tool === path.basename(process.execPath) ? args[0] : tool);
      if (tool === 'eslint') {
        write('eslint.json', []);
        return { ...output(), status: 2, stderr: 'controlled ESLint failure' };
      }
      if (tool === path.basename(process.execPath)) {
        write('stylelint.json', []);
        return output();
      }
      if (tool === 'ruff')
        return output(
          args.includes('--show-files') ? path.join(root, 'tools/build_site_bundle.py') : '[]'
        );
      if (tool === 'semgrep') {
        write('semgrep.json', {
          results: [{ extra: { lines: 'controlled source snippet' } }],
          errors: [],
          paths: { scanned: [] },
        });
        return { ...output(), status: 2, stderr: 'controlled Semgrep failure' };
      }
      if (tool === 'bandit') {
        write('bandit.json', {
          results: [{ code: 'controlled source snippet' }],
          errors: [],
          metrics: {},
        });
        return { ...output(), status: 2, stderr: 'controlled Bandit failure' };
      }
      if (tool === 'detect-secrets') return output(JSON.stringify({ results: {} }));
      if (tool === 'python') return output();
      if (tool === 'npm')
        return output(JSON.stringify({ error: { message: 'controlled feed failure' } }));
      if (tool === 'pip-audit') {
        const dependencies = fs
          .readFileSync(path.join(root, 'tools/quality/toolchain/requirements.txt'), 'utf8')
          .trim()
          .split('\n')
          .map((line) => {
            const [name, version] = line.split('==');
            return { name, version, vulns: [] };
          });
        write('pip-audit.json', { dependencies });
        return output();
      }
      throw Error('unexpected controlled tool ' + tool);
    };
    const localRequire = (name) => {
      if (name === 'node:child_process') return { spawnSync };
      if (name === './common.cjs')
        return {
          identity: () => {
            if (invalidIdentity) throw Error('controlled invalid artifact identity');
            return {
              sourceCommit: 'a'.repeat(40),
              sourceTree: 'b'.repeat(40),
              candidateCommit: 'a'.repeat(40),
              artifactDigest: 'c'.repeat(64),
            };
          },
          report: (reportKind, value, pass) => reports.push({ kind: reportKind, value, pass }),
        };
      // This scanner-orchestration fixture has no detected secrets. Keep its
      // generated-checksum input synthetic: producer/media reconstruction is
      // tested separately and requires a pinned image toolchain in hosted CI.
      if (name === './generated-checksums.cjs')
        return {
          proveGeneratedChecksums: () => ({ detail: { synthetic: true } }),
          admitGeneratedChecksumFindings: () => new Set(),
          findingKey: () => {
            throw Error('unexpected generated checksum finding in empty controlled scan');
          },
        };
      if (name === './format.cjs')
        return {
          sourceInventory: () => ({
            files: ['tools/build_site_bundle.py'],
            byLanguage: { js: [], python: ['tools/build_site_bundle.py'] },
          }),
        };
      return nativeRequire(name);
    };
    const module = { exports: {} };
    vm.runInNewContext(
      source,
      {
        require: localRequire,
        module,
        __dirname: path.dirname(filename),
        Buffer,
        process: {
          ...process,
          env: { ...process.env, SITE_REPORT_DIR: directory },
        },
      },
      { filename }
    );
    assert.throws(
      () => module.exports.main(kind),
      invalidIdentity ? /invalid artifact/ : /Scanner engines failed/
    );
    assert.equal(reports.length, 1);
    assert.equal(reports[0].pass, false);
    return { calls, detail: reports[0].value.detail, directory };
  };
  for (const [kind, names] of [
    ['lint', ['eslint', 'stylelint', 'ruff']],
    ['security', ['semgrep', 'bandit', 'secrets']],
    ['advisories', ['npm', 'publicationNpm', 'pip']],
  ]) {
    const result = execute(kind);
    assert.deepEqual(
      Array.from(result.detail.engines, (row) => row.name),
      names
    );
    assert.equal(result.detail.engines[0].pass, false);
    assert.equal(result.detail.engines.at(-1).pass, true, JSON.stringify(result.detail));
    assert.ok(result.detail.engines.every((row) => row.commands.length > 0));
    if (kind === 'advisories') {
      assert.equal(result.detail.engines[1].pass, false);
      assert.deepEqual(
        Array.from(result.detail.engines[1].rawReports, (row) => row.file),
        ['publication-npm-audit.json'],
        'the independent publication feed failure keeps its actual report'
      );
    }
    if (kind === 'security') {
      assert.equal(
        JSON.parse(fs.readFileSync(path.join(result.directory, 'semgrep.json'))).results[0].extra
          .lines,
        undefined
      );
      assert.equal(
        JSON.parse(fs.readFileSync(path.join(result.directory, 'bandit.json'))).results[0].code,
        undefined
      );
    }
  }
  assert.deepEqual(execute('security', true).calls, []);
});
test('shared MIME admission accepts exact variants and rejects missing or substituted image types', () => {
  const mime = require('../tools/quality/serve.cjs');
  for (const [file, value] of [
    ['/', 'text/html; charset=utf-8'],
    ['index.html', 'TEXT/HTML'],
    ['code.js', 'application/javascript'],
    ['code.js', 'text/javascript'],
    ['file.css', 'text/css'],
    ['file.json', 'application/json'],
    ['icon.svg', 'image/svg+xml'],
    ['portrait.jpg', 'image/jpeg'],
    ['portrait.jpeg', 'image/jpeg; charset=UTF-8'],
    ['portrait.webp', 'image/webp'],
    ['image.png', 'image/png'],
    ['favicon.ico', 'image/x-icon'],
    ['favicon.ico', 'image/vnd.microsoft.icon'],
    ['robots.txt', 'text/plain'],
    ['sitemap.xml', 'text/xml'],
    ['sitemap.xml', 'application/xml'],
    ['opaque', 'application/octet-stream'],
  ])
    assert.doesNotThrow(() => mime.assertContentType(file, value));
  for (const file of ['portrait.jpg', 'portrait.jpeg', 'portrait.webp', 'image.png', 'favicon.ico'])
    for (const wrong of [
      undefined,
      '',
      'text/plain',
      'application/octet-stream',
      'text/html,image/jpeg',
      'image/jpeg.evil',
      'image/jpeg\r\nX-Evil: true',
    ])
      assert.throws(() => mime.assertContentType(file, wrong));
});
test('actual hosted collector rejects wrong or missing MIME with unchanged JPEG/WebP/PNG/ICO bytes', async () => {
  const { verify } = require('../tools/quality/hosted.cjs'),
    { digest } = require('../tools/quality/artifact.cjs');
  const data = {
    'index.html': Buffer.from('<h1>Exact fixture</h1>'),
    '404.html': Buffer.from('<h1>Missing fixture</h1>'),
    'portrait.jpg': fs.readFileSync(path.join(root, 'site/assets/vitalii-oborskyi.jpg')),
    'portrait.webp': fs.readFileSync(path.join(root, 'site/assets/vitalii-oborskyi-cutout.webp')),
    'image.png': fs.readFileSync(
      path.join(root, 'review/assets/vitalii-oborskyi-cutout-20261002.png')
    ),
    'favicon.ico': Buffer.from([0, 0, 1, 0, 0, 0]),
    'robots.txt': Buffer.from('User-agent: *\n'),
    'sitemap.xml': Buffer.from('<urlset/>'),
    opaque: Buffer.from('controlled opaque bytes'),
  };
  const types = {
    'index.html': 'text/html',
    '404.html': 'text/html',
    'portrait.jpg': 'image/jpeg',
    'portrait.webp': 'image/webp',
    'image.png': 'image/png',
    'favicon.ico': 'image/x-icon',
    'robots.txt': 'text/plain',
    'sitemap.xml': 'application/xml',
    opaque: 'application/octet-stream',
  };
  const manifest = {
    sourceCommit: 'a'.repeat(40),
    files: Object.fromEntries(
      Object.entries(data).map(([file, bytes]) => [file, { sha256: digest(bytes) }])
    ),
  };
  const fetcher = (changed, value) => async (url) => {
    const name = new URL(url).pathname.slice('/site/'.length) || 'index.html';
    const exists = Object.hasOwn(data, name),
      file = exists ? name : '404.html';
    const type = name === changed ? value : types[file];
    return new Response(data[file], {
      status: exists ? 200 : 404,
      headers: {
        ...(type === undefined ? {} : { 'content-type': type }),
        'x-robots-tag': 'noindex',
        'x-content-type-options': 'nosniff',
      },
    });
  };
  assert.equal(
    (await verify('https://quality.invalid/site', 'staging', manifest, fetcher())).root,
    true
  );
  for (const file of ['portrait.jpg', 'portrait.webp', 'image.png', 'favicon.ico'])
    for (const value of [undefined, '', 'text/plain'])
      await assert.rejects(
        verify('https://quality.invalid/site', 'staging', manifest, fetcher(file, value)),
        /Content-Type/
      );
  await assert.rejects(
    verify(
      'https://quality.invalid/site',
      'staging',
      manifest,
      fetcher('index.html', 'application/octet-stream')
    ),
    /Content-Type/
  );
});
test('loopback serves canonical image/robots/sitemap types and root or extensionless bytes', async (t) => {
  const { start } = require('../tools/quality/serve.cjs');
  const directory = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'mime-server-'));
  const files = {
    'index.html': 'text/html',
    'image.jpg': 'image/jpeg',
    'image.webp': 'image/webp',
    'image.png': 'image/png',
    'favicon.ico': 'image/x-icon',
    'robots.txt': 'text/plain',
    'sitemap.xml': 'application/xml',
    opaque: 'application/octet-stream',
  };
  for (const file of Object.keys(files))
    fs.writeFileSync(path.join(directory, file), 'controlled immutable ' + file);
  const { server, url } = await start(directory);
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    fs.rmSync(directory, { recursive: true, force: true });
  });
  for (const [file, expected] of [['', 'text/html'], ...Object.entries(files)]) {
    const response = await fetch(url + '/' + file);
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('content-type').split(';')[0], expected);
    assert.equal(await response.text(), 'controlled immutable ' + (file || 'index.html'));
  }
});

for (const kind of ['lint', 'security', 'advisories'])
  test(
    'repository ' +
      kind +
      ' reaches source scanners without a website manifest and retains scanner failure',
    (t) => {
      const os = require('node:os');
      const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'repository-lint-'));
      t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
      const result = cp.spawnSync(process.execPath, ['tools/quality/scanners.cjs', kind], {
        cwd: root,
        encoding: 'utf8',
        timeout: 30000,
        env: {
          ...process.env,
          SITE_REPOSITORY_ONLY: 'true',
          SITE_ARTIFACT_MANIFEST: path.join(directory, 'absent-website.json'),
          SITE_REPORT_DIR: directory,
          SITE_AUDIT_TOOLS: path.join(directory, 'missing-tools'),
        },
      });
      assert.notEqual(result.status, 0);
      const report = JSON.parse(
        fs.readFileSync(path.join(directory, 'repository-' + kind + '.json'))
      );
      assert.equal(report.kind, 'repository-source-' + kind);
      assert.equal(report.website, 'not-applicable');
      assert.equal(report.pass, false);
      assert.match(report.error, /Scanner engines failed/);
      assert.equal(
        report.sourceCommit,
        cp.execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim()
      );
      assert.equal(Object.hasOwn(report, 'artifactDigest'), false);
      assert.equal(fs.existsSync(path.join(directory, 'absent-website.json')), false);
    }
  );
