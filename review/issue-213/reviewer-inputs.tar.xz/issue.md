## Original intent

Author request, 17 November 2026:

> Стати по сайту а також зроби тікет на ідею наступну - доволі відомий пошуковий термін Гугл Ai code crisis і треба попасти в цей граф

**Confirmed objective:** make Vitalii Oborskyi's relevant work discoverable for **“AI code crisis”** and the related search/topic space, with a clear connection to **The Subprime Code Crisis**, verification capacity, system understanding, and SDLC imbalance.

This is an **idea/backlog intake**. The target page, content changes, implementation sequence, and measurable opportunity remain to be validated before dependent implementation.

## Owner and scope

**Owner:** this issue owns the bounded query/topic discovery opportunity and its content decision.

Reuse these existing owners:

- [#8 — Search Console](https://github.com/oborskyivitalii/oborskyivitalii/issues/8): indexing, canonical inspection, sitemap observations, and organic baseline.
- [#11 — native buyer-problem guides](https://github.com/oborskyivitalii/oborskyivitalii/issues/11): coordinate if the chosen answer needs a new native problem guide.
- [#116 — Subprime mount](https://github.com/oborskyivitalii/oborskyivitalii/issues/116): planned `/subprime/` composition and upstream research ownership. Assess this route before proposing a competing hub.
- [#159 — SEO and analytics delivery](https://github.com/oborskyivitalii/oborskyivitalii/issues/159) and [#177 — SDLC discovery/analytics](https://github.com/oborskyivitalii/oborskyivitalii/issues/177): reuse delivered mechanisms.
- [#183 — article library](https://github.com/oborskyivitalii/oborskyivitalii/issues/183): reuse existing native articles and their exact source/edition dates.

“Graph” is treated as an intent to enter the relevant topic/discovery space. Evaluate **organic results**, **AI Overviews/AI Mode citations**, and **Google Knowledge Graph/entity representation** separately; they are different observations, and none is guaranteed by adding a keyword or structured data.

### Evidence at intake — 17 November 2026

The expression is used publicly, for example:

- [StepTo: Comprehension Debt: The AI Code Crisis Your Metrics Are Completely Missing](https://stepto.net/blog/comprehension-debt-ai-code-understanding-2026).
- [AI Indigo: The AI Code Crisis: Why Major Open Source Projects are Banning AI-Authored PRs](https://aiindigo.com/blog/the-ai-code-crisis-why-major-open-source-projects-are-banning-ai-authored-prs).

These are evidence of vocabulary and adjacent intent, **not measured search demand, reliable Google ranks, or endorsement of their technical claims**. This intake did not establish keyword volume or a locale-controlled Google results baseline. The connected keyword/SERP research provider reported an ended trial; no paid upgrade was initiated.

Live Google Search Console data for `sc-domain:vitaliioborskyi.ai`, retrieved through Windsor on 17 November:

| Finalized window (Google/PT dates) | Property impressions | Clicks | CTR |
| --- | ---: | ---: | ---: |
| 8–14 November | 10 | 1 | 10.0% |
| 1–7 November | 14 | 3 | 21.4% |
| 20 October–14 November | 65 | 7 | 10.8% |

Latest returned date: **14 November**. The query report disclosed only two query rows and no “AI code crisis” row. Query privacy/truncation prevents treating this as proof of zero searches or complete zero visibility. Article readers published on 16 November are outside this finalized observation window.

### Candidate work, to refine after discovery

1. **Map the actual query family and reader intent.** Start with `AI code crisis`, `AI-generated code crisis`, `subprime code crisis`, `AI code review bottleneck`, and `comprehension debt`. Treat them as related candidates, not interchangeable terms. Capture date, country, language, device, observed results, content types, and any AI/knowledge-panel features. Record volume source/limits or explicitly leave demand unknown.
2. **Choose the primary destination before writing.** Compare the existing [Research page](https://vitaliioborskyi.ai/research.html), [SDLC imbalance article](https://vitaliioborskyi.ai/articles/the-sdlc-is-out-of-balance.html), the planned `/subprime/` route under #116, and a genuinely useful new guide only if a distinct intent remains uncovered. Avoid several pages competing for the same answer.
3. **Connect public vocabulary to the author's contribution.** Give readers a concise explanation of the crisis, distinguish code quality from verification/review capacity, integration, operational comprehension, and ownership, and show where The Subprime Code Crisis adds a delivery-system explanation. Preserve evidence limits and counterexamples. Do not imply that every AI-assisted workflow degrades or claim ownership of the search phrase.
4. **Make the relationships explicit.** Use natural contextual links from Research, Writing and appropriate articles, including SDLC imbalance, Verification Crisis and Cost-Cutting Fallacy. Audit the existing title/description/H1, visible explanatory text, canonical, sitemap, and author/Article structured data; change only what the chosen intent requires. Visible statements and markup must agree. Existing source owners include `site/seo/query-map.json` and `site/content/pages/research/research.json`; verify current paths/contracts before editing.
5. **Prepare legitimate external connections.** Record possible contextually useful updates to author-owned research/distribution surfaces and relevant discussion opportunities. Preserve canonical and edition ownership. Any external editing, outreach, or publication is separate work requiring the applicable authorization; no artificial links or unsupported authority claims.
6. **Measure the result.** Record the chosen page and query-family baseline, inspect indexing through #8, and compare equal finalized 28-day windows after delivery. Report impressions, clicks, CTR, and average position with query/privacy limits. Observe AI citations/entity panels separately with dated, locale-specific evidence. Improvement is a target to evaluate, not a promised release gate.

## Acceptance criteria

These are proposed observable criteria for the future bounded implementation. All remain open at intake.

### AC01 — Search intent and baseline

- [ ] A dated query/intent matrix records terms, locale/language/device, observed result types, current author/site presence, and demand evidence or explicit unknowns. Reproduce the GSC baseline through the connected property; never substitute generic web-search ordering for an exact Google rank.
- Required gate: source-based requirements review before dependent implementation.

### AC02 — One primary destination and ownership

- [ ] Record the chosen canonical destination and why it satisfies the intent; map supporting pages and links. Reconcile #8, #11, #116 and #183, including whether an existing page suffices. Do not create an unapproved duplicate research hub.
- Required gate: resolve content/research ownership and any expansion beyond this bounded objective.

### AC03 — Useful content and accurate provenance

- [ ] The chosen page answers the query in visible readable prose, connects the author's delivery-system explanation to evidence and limits, and retains accurate authorship and original/platform/site dates. Check the approved source against the rendered page; preserve research acceptance boundaries.
- Required gate: independent editorial/source review and applicable author publication approval.

### AC04 — Discovery and technical integrity

- [ ] Verify the selected canonical URL, indexability, sitemap inclusion, natural internal links, metadata and applicable author/Article markup against visible content, including the mobile and no-JavaScript reader experience.
- Select current deterministic checks from the repository's maintained SEO/content profiles based on the actual diff; exact selectors must be recorded in the implementation PR.
- Code-style AC is not applicable to this issue-only intake. If implementation changes code/templates/styles/configuration, add the applicable CS rule IDs, bounded selectors and independent review before editing.

### AC05 — Verified delivery through existing routes

- [ ] Link the actual implementation PR/commits, independent review, exact-source checks and required PR Preview → Stable Staging → Production evidence. Observe the final live page and reconcile actual acceptance; green source checks alone are not publication or indexing evidence.
- Required gate: existing maintainer/release decisions and dependent owner gates.

### AC06 — Measurement handoff and outcome

- [ ] A reproducible post-release check records indexing status, the selected query/page metrics and a comparable finalized 28-day window when available. Separate technical completion from delayed search outcomes; retain an explicitly owned measurement follow-up if the observation window has not matured.
- Record actual outcomes, including no measurable improvement. Do not fabricate query volume, claim complete query visibility, or guarantee rank, AI citation, Knowledge Graph inclusion, or a knowledge panel.

## Plan and decisions

1. Validate opportunity and intent.
2. Select the canonical/content approach and reconcile owners.
3. Review requirements, then implement only the accepted bounded change.
4. Verify, release through existing gates, and record measurement.

Google's primary guidance:

- [AI features and your website](https://developers.google.com/search/docs/appearance/ai-features): normal SEO eligibility applies; no special AI schema or new AI text file is required; serving is not guaranteed.
- [Structured data introduction](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data): markup describes visible page content and entities.
- [Search Console data discrepancies](https://support.google.com/webmasters/answer/17010575?hl=en): query omissions, aggregation differences, processing delay and Pacific dates.

### Review / analysis / model handoff — 2026-11-17

Initial read-only discovery and issue intake completed. Opportunity demand, exact locale-controlled Google baseline, canonical choice, implementation scope and independent requirements review remain pending. No implementation, source policy, review receipt or check result is claimed by this issue creation.

## Linked execution

- Implementation PR: not started.
- Implementation commits: none.
- Requirements/acceptance and implementation review records: pending; create in the owning PR under the repository protocol when implementation starts.
- Check selectors/policy: to be selected from the current maintained owners for the actual diff; no invented file or pass result.

## Completion evidence

| AC | Check / observation | Actual result | Exact source / run | Remaining gate |
| --- | --- | --- | --- | --- |
| AC01 | Initial vocabulary search and live GSC read | Preliminary evidence recorded; demand and locale-controlled baseline unknown | Sources and dated property/window above | Complete baseline + requirements review |
| AC02–AC06 | Canonical decision, content, verification, release and measurement | Not started | No implementation PR/run | All proposed implementation and delivery gates |


## 21 November 2026 — Discovery analysis and proposed first change

**Author request:** take #213 into work; first analyse what to optimise in the article and SEO, and how to increase relevant search discovery. This checkpoint is analysis and a proposed content approach, not implementation/publication approval or completed AC acceptance.

### Verified source and scope

- Read README, root AGENTS, REPOSITORY-MAP, MEMORY, CONTRIBUTING, the site source/SEO and repository ownership contracts, the SDLC manuscript/metadata/edition, relevant Research sources, generated pages, and live production HTML. The only applicable AGENTS in the current repository inventory is the root file.
- Live main and production both resolve to `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`. The shallow local main checkout is clean. MEMORY's 16 November snapshot is historical, not the current deployment.
- Read the current #8, #11, #116 and #183 owner records. #183 is closed; #116 remains open and retains the already chosen future report mount `/subprime/`. No new hub, research import or competing mount is proposed.
- The intake's suggested `site/seo/query-map.json` does **not** exist at this inspected ref. Use the maintained `guides/SITE-SEO.md`, actual page sources and publication/catalog contracts; do not invent a configuration owner from that stale suggestion.

### Search baseline and its limits

Retrieved through the existing connected property `sc-domain:vitaliioborskyi.ai` on 21 November. Initial requests beginning 21 October were refused by the connector's 30-day-history plan limit. The bounded correction requested **24 October–20 November 2026**, using three separate Search Analytics dimension sets: date; query; page, each with impressions/clicks/CTR/position. The latest returned daily row is **19 November**; 20 November is unavailable in this result, not asserted zero or final. This is a 27-returned-day baseline, not a complete finalised 28-day comparison.

| Scope | Impressions | Clicks | Average position |
| --- | ---: | ---: | ---: |
| Property, sum of returned daily rows | 44 | 6 | Not used for query targeting |
| SDLC article, page dimension | 1 | 0 | 21 |
| Research, page dimension | 8 | 0 | 19.75 |
| Writing, page dimension | 17 | 0 | 6.8235 |

Page-dimension impression totals differ from property aggregation and must not be summed or treated as the same denominator. The only disclosed query rows were `arkadiy dobkin` and `vladimir beskorovainyi ai`, one impression each. No target-family query was disclosed. Privacy/aggregation omissions prevent interpreting that as zero demand or zero target-query exposure. One article impression cannot identify a stable rank, a CTR defect, or a cause of low visibility.

Semrush keyword discovery returned every relevant volume/related/SERP report as unavailable because the account has no API units. **Demand, organic difficulty and exact Google positions remain unknown.** No upgrade was initiated.

Dated public web searches were used to inspect vocabulary and result types, not to measure a locale-controlled Google SERP. Provider location/device were unspecified; no PL/US mobile/desktop rank, Google AI citation, or Knowledge Graph panel was observed.

### Query family and destination proposal

English is the current site language. The proposed reader is an engineering/delivery leader or architect investigating why AI coding gains fail to become sustainable delivery gains.

| Candidate query family | Reader question / observed public vocabulary | Proposed answer owner |
| --- | --- | --- |
| AI code crisis; AI-generated code crisis | What is going wrong, and does this mean defects, security, maintainer overload or loss of understanding? Public results use the phrase for several different problems. | Existing SDLC article, with an explicit bounded explanation near the beginning |
| AI code review bottleneck; AI-generated PR overload | Why does faster generation overload review, and is automating review enough? Vendor/product advice and practitioner discussion are present. | SDLC article's existing core argument |
| Comprehension debt; understanding AI-generated code | Who understands and can maintain/recover what was accepted? Adjacent practitioner vocabulary exists, including Addy Osmani's own essay. | SDLC learning/ownership section, with attributed terminology and a distinction from ordinary technical debt |
| Subprime code crisis | What is this particular research project and what does it contribute? Public search retrieves the author's research repository alongside other uses of the phrase. | Canonical upstream Subprime research; later the already owned #116 report mount |
| AI coding productivity versus delivery; hidden cost of AI coding | Why do activity gains differ from useful output and total cost? | SDLC evidence/operating-model sections, supported by Cost-Cutting Fallacy |

**Recommendation for the first bounded change:** use the existing SDLC URL as the primary site article for the broad delivery-system interpretation of “AI code crisis”. Keep Research as the two-direction research entry, Verification Crisis as its focused argument, and Cost-Cutting Fallacy as the economic companion. The later `/subprime/` report remains a distinct upstream-owned research publication; this proposal does not move its authority, make it a prerequisite, or change the article's URL.

“Primary answer for a query” is an editorial choice, not a request to point all supporting articles' `rel=canonical` at SDLC. Distinct works retain their own canonical identities.

### What the actual article already does well

The ~2,570-word authored manuscript has a clear review-bottleneck title, a simple bounded queue illustration, an important distinction between checking and learning, primary references, explicit evidence limits, and practical pilot/recovery guidance. Preserve these. The queue numbers remain a thought experiment; the industry-level conclusion remains the author's synthesis.

Live HTML already rewrites Verification Crisis and Thinking Systems references to their native readers. Do not report the historical external URLs in the manuscript as broken public internal linking. The missing opportunity is earlier context and additional relevant return links.

### Proposed content changes, in priority order

1. **Make the broad query-to-thesis connection in the opening.** The exact phrase “AI code crisis” is absent from the inspected visible article. Subprime appears near the references/byline, rather than introducing the contribution. Add a concise explanation within the first 100–150 words, naturally using “AI-generated code” and “AI code crisis”, then link Subprime's source. Define the particular delivery-system problem without implying that every use of the broad phrase means the same thing.

   Proposed author-review wording, not applied:

   > The AI code crisis is often framed as a problem of bad AI-generated code or overloaded reviewers. This article examines a wider delivery-system risk: accepted changes can outpace the capacity to verify, integrate, understand and maintain them. My Subprime Code Crisis research explores that imbalance. Code review is one place it becomes visible; automating review does not by itself establish a better business outcome.

2. **Use a descriptive opening H2.** Consider “Why the AI code crisis extends beyond code review” in place of the current sales-story heading, while keeping the vendor example in its paragraphs. Retain the existing article title/H1 in the first change: it already names “AI Code Review Bottleneck”, and there is no evidence that renaming the work improves discovery. A separate SEO-title field is not assumed to exist.

3. **Connect the existing comprehension-gap argument to public vocabulary.** Add one short attributed explanation of “comprehension debt” and distinguish loss of usable team understanding from code defects/ordinary technical debt. Read and source-review the primary practitioner essay before integration; do not claim the author originated this term or import unverified numerical claims from competitor pages. This is a proposed editorial addition, not empirical validation.

4. **Make the practical answer easier to retrieve and use.** Add a compact text table near “Finding a new balance”: observed symptom → what to measure → bounded response. Candidate rows: waiting PRs/review elapsed time → queue age and WIP → smaller admitted batches; merged work that colleagues cannot explain → bounded explanation/recovery drill → protect learning; more releases without outcome gain → adopted useful change and total cost → reassess scope/demand. Reuse the existing argument and retain limitations. A useful summary is a readability hypothesis, not a guaranteed snippet/AI-citation tactic. No mandatory FAQ expansion is proposed.

5. **Update the description to match the visible new opening.** Proposed description:

   > The AI code crisis is more than a code review bottleneck. Explore verification capacity, comprehension debt and changes needed for sustainable software delivery.

   Apply only after the body actually covers those terms. Keep title, summary, catalog description and derived outputs consistent through the existing publication workflow.

### Internal links and topic relationships

| Source | Proposed contextual relationship |
| --- | --- |
| Research delivery/Subprime block | Add a direct “AI code crisis and the SDLC imbalance” article link; retain the upstream research link and the Writing collection link |
| SDLC opening | Link the particular Subprime research contribution, with boundaries |
| SDLC learning and economic sections | Link Verification Crisis and Cost-Cutting Fallacy in relevant prose |
| Verification Crisis | Add a contextual link to SDLC for the wider delivery-system treatment |
| Cost-Cutting Fallacy | Add a contextual link to SDLC for the flow/learning mechanism |
| Writing catalog/topic reading paths | Check that titles and summaries describe the distinct reader question rather than making all entries answer the same phrase |

Use ordinary crawlable links and descriptive anchors. Avoid repeating every term on every page. Governance/UA articles do not need unrelated crisis copy. Later #116 navigation can expose the admitted report without duplicating this article or inventing a new intermediate hub.

### Technical observations from live production

Read-only HTTP checks on 21 November established:

- Both SDLC `.html` and extensionless entry return HTTP 200 and the same 43,072-byte document. Both declare the `.html` canonical. Their coexistence is not itself a demonstrated canonicalisation defect.
- The article has `index,follow`, with no observed blocking X-Robots-Tag.
- Live robots.txt permits this path and advertises the sitemap. Live sitemap contains 13 URLs, including all eight current native articles and the SDLC canonical.
- Full article prose and links are present in the returned HTML. This establishes server-delivered text, not a newly executed mobile/no-JS interaction matrix.
- Live Article JSON-LD contains name/headline/description/language/author, but no image, URL/mainEntityOfPage, datePublished or dateModified. Canonical/OG tags are already emitted separately. Add supported article/author identity, validated cover and accurately sourced publication/modification dates where justified, through the existing producer; do not invent dates or confuse the R12 author-review byline date with a site publication event. This is descriptive markup quality, not a ranking prerequisite or Knowledge Graph guarantee.
- Authored `publication.json` has `canonical: null` while the hosted production layer emits the correct canonical. Do not “fix” source null blindly or edit generated docs as an owner.
- Public web retrieval read the Medium rendition, but raw HTTP access returned 403. Medium's actual rel=canonical was **not inspected**. Google-selected canonical and current URL Inspection coverage were also **not observed** through the available Search Analytics fields. #8 owns those inspections. Verify canonical selection before asserting the site or Medium copy has a canonical problem.

### Search, AI answers and entity identity

Prioritise relevant organic visibility and the actual reader's answer. Google documents the same SEO eligibility for AI Overviews/AI Mode: indexable snippet-eligible text, crawlable internal links and consistent visible content/structured data. It does not require a special AI schema or text file. AI-generated answers may retrieve related subtopics; this supports the relevance of clear related explanations, not a promise that these changes will be cited.

Google Knowledge Graph/entity recognition is a separate observation. Consistent author identity and truthful links are useful descriptive hygiene; no keyword insertion, Article property or new page guarantees inclusion or a knowledge panel.

### Proposed execution and measurement handoff

1. Review the proposed primary answer and editorial scope against AC01/AC02 before dependent implementation.
2. Prepare one bounded existing-content change: SDLC opening/H2/description/diagnostic summary plus contextual Research and companion links. Use `site/publications/sdlc-out-of-balance/`, the affected companion publication owners, Research content, `site/content/catalog.json` and maintained SEO documentation. Preserve exact source editions and regenerate through the current owners.
3. Treat producer/schema changes as separately identified code scope if needed, even within the same #213 implementation PR. Do not assume all proposed work is content-only.
4. Obtain the applicable independent Requirements and changed-artifact/editorial reviews before dependent implementation/advancement; select actual deterministic and hosted checks after inspecting the complete proposed diff. This analysis did not run Basic, browser/performance or release tests and claims no pass from them.
5. After an authorised release, inspect URL status and Google's selected canonical under #8. Keep author-owned external distribution proposals separate; no Medium, LinkedIn, upstream research, outreach or publication edit was performed.
6. Compare equal **finalised 28-day** pre/post windows when accessible. Track the primary page and disclosed query family: impressions, clicks, CTR and average position, with query omissions and page/property denominators. If the connector's rolling 30-day limit prevents reconstructing an older baseline later, use a retained baseline/export or owner-authorised direct GSC export; do not silently compare unequal windows.
7. Observe PL/en and US/en desktop/mobile SERPs and any AI citations separately with explicit dates, exact queries and locale/device controls when available. These observations remain pending. Target improvement is broader relevant exposure, not an arbitrary ranking promise.

All AC01–AC06 remain open: preliminary evidence and a proposed destination do not complete the accepted baseline/review/implementation/release/measurement gates. No site source, generated output, repository policy, external edition or production deployment was changed in this analysis checkpoint.

### Primary guidance and vocabulary sources

- [Google: AI features and your website](https://developers.google.com/search/docs/appearance/ai-features)
- [Google: crawlable links and anchor text](https://developers.google.com/search/docs/crawling-indexing/links-crawlable)
- [Google: canonical consolidation](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls)
- [Google: Article structured data](https://developers.google.com/search/docs/appearance/structured-data/article)
- [Google: Search Console impressions, clicks and position](https://support.google.com/webmasters/answer/7042828?hl=en)
- [Addy Osmani: Comprehension Debt](https://addyosmani.com/blog/comprehension-debt/) — practitioner terminology/input for source review, not accepted empirical evidence
- [StepTo's AI code crisis page](https://stepto.net/blog/comprehension-debt-ai-code-understanding-2026) and the AI Indigo pages already recorded at intake — vocabulary/result-type observations only

