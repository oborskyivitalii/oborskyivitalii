# Issue213 existing Research slot — independent Requirements preflight

## Verdict and boundary

**PERMISSIBLE TO IMPLEMENT the bounded correction described in this packet. Not completed-candidate acceptance or delivery approval.** No material owner ambiguity blocks this correction: the supplied latest user instruction authorizes correction and Stable Staging only. Replacing the delivery lens's selected reading route with the existing SDLC article is relevant to AC02/AC04 and stays within personal-site distribution ownership. It does not transfer canonical research authority. The removed upstream mechanics shortcut must be disclosed as a real semantic change; retaining the upstream repository link does not make these journeys equivalent.

Restore the Research card template exactly to protected main; remove its unused added T028/U005 values; use the existing lenses.json U002/T006 only for the changed selected reading. The label must identify the SDLC article truthfully, rather than imply the destination is the upstream report or a TOC reference. Preserve delivery/systems cards, upstream repositories, both Writing collections, TOC background, all UA journeys, metadata/anchors and unrelated lens prose. Preserve published/declared immutable resources and all runtime, rights, capacity and release bounds. This is a correction within #213/#216, not authorization for another hub, new runtime trust allowance, protected merge, production or external publication.

Findings below prescribe necessary treatments. They do not require another user confirmation for this authorized correction. Completed implementation, exact runtime identity, cross-version protected-package verification, fresh independent results and hosted evidence remain unobserved.

## Identity and inspected sources

- Reviewer role: Requirements & Acceptance; execution handle `/root/issue213_slot_preflight`; phase: preimplementation correction, distinct nonauthor of the candidate.
- Source repository: `/workspace/scratch/74ce6d806bbc/repo`; clean working tree observed. HEAD `263d071e7be129e9a6bf7af6e717805e19e7564a`, tree `41d0bdcff8c464a1185e0ecb4bcbedf078801799`. Local main/origin/main `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`. These are local ref observations; live GitHub state was not fetched by this execution.
- Packet `/workspace/scratch/74ce6d806bbc/213-work/preflight-packet.json` SHA256 `c65a3f2417e18644dd722865d7c681ca58b3641ca68139396dc460e61427ea8a`; verified all 15 listed current file digests and supplied owner digest `8bfb0551be8e479c4e52833d42c74c6f2223d8fd472cd591e91bcaa766e28f37` against actual bytes.
- Common prompt SHA256 `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`; role prompt `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. Read both, AGENTS, CONTRIBUTING, README, REPOSITORY-MAP, relevant site/SEO/staging/style/acceptance/ownership contracts and supplied original owner/AC text. Historical author/orchestrator interpretations in the owner record were review subjects, not acceptance evidence.
- Inspected actual base/head Research template/content delta, current lens template/data, issue213 amendment and SEO reversal, issue48 historical amendment identity, current content alignment assertions, discovery negative assertions, runtime registry and generation tuple assertions; inspected build fingerprint inputs and the relevant SDLC manuscript passages. No full original-implementation review is claimed.
- Scoped binary diff SHA256 `1ccc0d5c354af8a889462b7009df767893ca4f7f8f15e4cf80ddb94b3e3e5586` covers base→head: Research card template, Research card/lens JSON, issue213 amendment, SEO checker, content/executive tests, Color registry and Color tests.
- Parent supplied launch evidence in a separate factual message: requested `fork_turns="none"`, task `issue213_slot_preflight`, no model/effort override, accepted handle `/root/issue213_slot_preflight`. This execution did not inspect the parent's launch tool transcript. Platform/provider model, injected context and internal isolation behavior are unknown; this is not a provider attestation.
- Visible platform/project/user instructions were present, including the supplied project AGENTS instructions. No separate account-memory retrieval or audit occurred. No current peer results, private author conversation, parent scratch notes, repository MEMORY or unrelated memory were read. No unexpected peer exposure observed. Only this output artifact was written; no implementation/test edits, external writes or delegation occurred.

## Findings and required treatment

### RPF01 — High: current exact oracle describes the superseded card addition

**Evidence:** `review/issue-213/content-amendment.json:7–14` declares an added paragraph after the Writing collection link; `tools/check_site_seo.cjs:1351–1373` pins that exact change and its before/after digests. `tests/executive.test.cjs:291–330` validates that predecessor, reversal and forged-record refusals. Separately, `tests/content.test.cjs:420–469` compares the complete delivery lens reading body to immutable issue48 bytes. Current `lenses.json:10,20` still selects the upstream mechanics report.

**Mechanism/AC impact:** changing the lens alone fails the existing alignment oracle, while keeping the old amendment would describe an absent card addition and omit the actual removed upstream shortcut. Silently editing issue48 or broadening normalization would defeat AC04's historical semantic protection rather than express AC02's accepted destination decision.

**Treatment:** replace only the active issue213 amendment with exact protected-predecessor/current-successor fragments for U002/T006; state the old report destination and new article destination honestly. Pin the exact new pair in the issue213 reversal; reverse this successor before historical issue48 comparison. Update the current alignment check to account for this one separately approved successor while retaining the original issue48 record/oracle intact. Keep wrong-page behavior, outside changes, wrong destination, corrupt hash, forged recomputed hash, duplicate/extra change and wrong baseline refusals. Verify unrelated lens body, systems article, TOC background, repository/Writing routes and the five-page outer comparison remain protected. This finding blocks candidate acceptance until treated; it does not block implementing that treatment.

### RPF02 — Medium: current descriptive authority text is stale for this correction

**Evidence:** `.github/acceptance/issue-213.json:126` says the current checkpoint authorizes Preview preparation only; supplied latest instruction authorizes Stable Staging. `guides/SITE-SEO.md:9–12` describes an additional Research card link, which the correction removes. The original whole AC05 still includes Production.

**Mechanism/AC impact:** these descriptions would misstate both the selected journey and the current authorized checkpoint. Conversely, removing Production from whole AC05 or declaring it complete at Stable would weaken the original acceptance contract.

**Treatment:** record the dated latest authorization and changed journey in the owning issue/review and reconcile current descriptions. Keep AC05's full eventual route and separate protected merge/Production authorization. Update policy wording to describe the current Stable-only checkpoint without inventing approval for later stages. Keep all six whole ACs open; the correction cannot complete baseline, publication, search or measurement gates. No renewed permission request is warranted for already authorized Stable Staging.

### RPF03 — Medium, conditional: immutable retention/capacity remains unmeasured for the new candidate

**Evidence:** parent separately reports current RI input bytes `264343626 / 265000000`, headroom `656374`, 3110 files; this execution has not independently run that measurement. New regeneration/retention bytes are not supplied. CONTRIBUTING's archive section requires actual completed-production or documented supersession eligibility, lossless recovery, original locators and preservation of raw failures/first results.

**Mechanism/AC impact:** template restoration may generate additional immutable identity resources; an assumed small edit does not establish fit. A generic archive-compression proposal does not identify eligible bytes or demonstrate recovery. AC04/AC05 cannot advance with omitted resources or a raised/excluded capacity bound.

**Treatment:** measure the complete resulting retained/generated delta first and preserve every declared/public immutable resource. If within the unchanged bound, no capacity maintenance is justified by this fact. If exceeding it, identify the exact historical archive(s), completion/supersession evidence, original and replacement members/digests, locator compatibility and extracted-byte recovery before a bounded maintenance judgment. Lossless repacking may be a feasible route under the existing contract, but no unspecified archive replacement/deletion is accepted here. Active sources, issue213 raw failures/first outputs and public resources remain protected. This conditional uncertainty does not block source correction; it blocks advancement if capacity fails or maintenance eligibility/recovery remains unresolved.

## Runtime feasibility and release constraint

Actual source supports the correction hypothesis: `tools/site/build.cjs:342–350` hashes all page templates into platform identity; lens prose/URL data is distinct from that template identity. Protected main and current candidate have identical lens JSON/template bytes, while the Research card template differs by the one added anchor. Protected Research template SHA256 is `8b1dfacf1e2684b24211de1fa766625db7a39e8f87cd2ad810349dd196758084`; current is `ccc00592efc34fdf23d1078ace24e4a38ace9632adcaaf413911678aef6d69e2`. Issue48 amendment remains byte-identical to protected main (`eaf8594ec4fbcc0c8a2568395bd6aef544cd7ebb4e84c282bded037a89a2bae1`).

Protected main actually contains `issue183LongArticle` and lacks `issue213DiscoveryLink`; the candidate adds the latter at `tools/quality/color-motion-contract.cjs:1062–1070`. Same runtime bytes alone do not admit its different fingerprint. Restoring the template is plausible, but no future generated tuple is observed here. Derive actual plain/staging/production identities and require unchanged protected-verifier acceptance of each applicable package/edition and full runtime closure. Select only an already admitted exact family if derivation truly matches. Do not relabel a manifest, wildcard admission, alter fingerprints, checkout candidate verifier code in the credentialed job, or bypass the existing controller. If exact identity does not match, stop this hypothesis and diagnose rather than add an allowance under this preflight.

## AC trace and next gate

| Intent / AC | Independent oracle or gate | Observation in this execution |
| --- | --- | --- |
| AC01 baseline | Dated query/GSC evidence and requirements gate | Not revalidated; no search/outcome claim. |
| AC02 one destination | Original SDLC choice, actual source route, distinct upstream/companion identities | Existing slot and relevant article inspected; authorized route replacement is permissible, RPF01 disclosure required. |
| AC03 useful prose/provenance | Approved source/edition, editorial/rights/publication gates | SDLC delivery/constraint passages support truthful article labeling; no new TOC certification/research-acceptance claim. Original content/publication acceptance not re-reviewed. |
| AC04 discovery/integrity | Exact amendment+SEO/content assertions; Basic/style/runtime/retention; actual mobile/no-JS journeys | Source coupling inspected; RPF01 and conditional RPF03 remain implementation obligations. No generated/hosted execution. |
| AC05 authorized delivery | Fresh final four-role results, current exact-source CI, unchanged protected publisher replay, actual owner `/stage` and served regression | Supplied authorization ends at Stable. No staging success, protected merge or production observation. RPF02 documentation reconciliation required. |
| AC06 measurement | Owned indexing and comparable finalized windows | Unchanged pending work; no source test can establish it. |

Next gate: implement only this bounded correction and its exact oracle/documentation treatments, measure retention/capacity, regenerate and verify through unchanged protected publication modules, then fresh completed-candidate Requirements/Code/White-box/Exploratory review and required current-source checks before another full authorized staging attempt. No prior test result is relabelled as this future candidate's evidence. No former peer judgment or whole-issue coverage was reused. All check observations here are read-only source/hash/Git inspections, not executed test, browser, indexing or release evidence.
