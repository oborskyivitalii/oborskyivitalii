# Issue213 / PR216 — independent White-box QA correction review

## Verdict

**Needs changes. WB213-F01 blocks advancement.** The bounded Research-slot correction and restored protected runtime identities pass the selected positive/negative checks. All prior immutable public bytes and the three recovered PDFs survive exactly. However, the correction adds18 retained resources without corresponding rights-inventory entries. Two independently selected fixture consumers fail at the existing strict rights guard. This is an integration failure, not permission to reduce retention or weaken that guard.

All six whole ACs remain open. This result does not authorize merge or Production. Current authorization is correction and Stable Staging only; Stable remains gated on the correction and exact-source required checks/reviews. The guide-review receipt is acknowledged as pending refresh after Code review and is not counted as current acceptance here.

## Identity, independence and scope

- Role/task: distinct nonauthor White-box QA correction execution `/root/issue213_slot_whitebox`.
- Launch facts supplied by the orchestrator: actual `fork_turns="none"`; no model/effort override; accepted task handle above. This execution received the bounded task/source packet rather than the author's conversation. Provider model/context internals and history injection are unknown; no provider attestation is claimed.
- Repository: `/workspace/scratch/74ce6d806bbc/repo`; clean candidate observed before checks and after byte comparisons: `ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01`, tree `bfc93c7ea87055b9dda178ed3f360634293b3bb0`.
- Protected base: `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`, tree `756d30c140cea2ff3aaac581caf9925b51b81241`.
- Correction parent: `263d071e7be129e9a6bf7af6e717805e19e7564a`, tree `41d0bdcff8c464a1185e0ecb4bcbedf078801799`.
- Packet: `/workspace/scratch/74ce6d806bbc/213-work/candidate-packet.json`, SHA256 `934913cc1ceb5a63ad899ee0442b5dad3b02de545b293be4745c25408ca97b82`; independently recomputed. Every supplied file/contract digest or declared absence matched actual inspected checkout bytes.
- Common prompt SHA256: `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`; role prompt: `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Read root README/AGENTS/CONTRIBUTING/map/MEMORY as required navigation, common/role contracts, current acceptance/profile policy, site source contract, bounded issue intent/ACs, exact changed source/tests and raw allowed evidence. Only root AGENTS is present. Historical narrative in the owner/MEMORY was not used as a verdict. No current peer outputs, parent private notes or unrelated memory were read. No external writes, source/test changes or delegation occurred. Only this assigned report is written.
- Local refs/status were inspected. Live GitHub/CI/deployment state was not independently fetched in this bounded review.

## Finding WB213-F01 — high / blocking retained-rights mismatch

**Locations:** `site/retained/manifest.json`; `site/rights.json` retained map; consumer assertion `tools/release/rights.cjs:122`; fixture callers `tests/fixtures/delivery.cjs:271`, `tests/fixtures/publication-records.cjs:119`; failing cases `tests/publication-records.test.cjs:852` and `tests/release-controller.test.cjs:572`.

**Independent requirement/oracle:** preserved public editions must keep byte identity and explicit rights/provenance inventory. The existing rights owner requires exact equality of declared retained paths and rights paths, and exact SHA256s. New immutable files cannot become unclassified merely because current executable runtime returns to the protected family.

**Observed mechanism:** correction adds8 article snapshots,5 runtime files under `87f959…`, and5 route snapshots to retained source. The retained map now has101 entries, while `site/rights.json.retained` still has83 and its bytes are unchanged from263d071. The18 absent entries are exactly those enumerated in the supplied raw `retention-delta.json`. There are no stale rights-only keys and no hash mismatches among the83 shared keys. Thus fixtures build coherent runtime/public bytes but rights compilation refuses them before publication admission.

**Executed symptoms:**

```text
✖ modern staging can preserve an accepted historical production root without inventing its rights
✖ explicit production Color preserves approved runtime and rejects a different selected variant
AssertionError [ERR_ASSERTION]: uncovered or stale retained rights inventory
at validateManifest (tools/release/rights.cjs:122:10)
at Object.compile (tools/release/rights.cjs:398:35)
at rightsInventory (tests/fixtures/delivery.cjs:271:60)
```

The first failing tool output preserved the assertion, added path identities, caller trace and complete4-case accounting; its verbose assertion arrays were truncated by the output budget. The subsequent read-only source join identified the entire18-key difference without another test rerun. No unchanged failing campaign was rerun.

**AC impact:** AC03 provenance/rights, AC04 technical integration, AC05 verified delivery. The guard is correctly refusing incomplete source accounting. This is not evidence of an unauthorized release or a changed license.

**Treatment:** inventory each retained resource with its exact digest and justified existing rights/provenance basis; preserve all bytes, old notices and rights boundaries. Obtain fresh affected independent review and rerun the failed fixture consumers, rights/source acceptance and protected package admission on the corrected source. Do not remove the18 resources, bypass equality, or substitute a historical green report.

## Structural risk → scenario → independent oracle → existing route

| Risk / AC | Structural fault and bounded scenario | Independent oracle | Executed result / allocation |
| --- | --- | --- | --- |
| Research destination / AC02,04 | Wrong TOC href/label; mutation elsewhere accidentally excused; forged record with recomputed digest | Protected3877546 predecessor anchor plus fixed reviewed successor digest; outside content must remain observable; only Research route is reversible | `executive.test.cjs` discovery-link case PASS, including wrong destination, foreign page, extra change and recomputed wrong record. Registry permanent pr-targeted/staging/production; owning SEO/DISCOVERY maps remain |
| Historical lenses / AC02,04 | New route weakens old theory prose, project association, systems reading or TOC background | Historical issue48 pre-amendment lens body after reversal, exact current native systems alias and unchanged CSS association/mobile rule | `content.test.cjs` research-theories case PASS; old semantic check is preserved by reversal rather than edited to accept new content broadly |
| Runtime admission / AC04,05 | Restored template still derives a new client fingerprint; registry merely renamed to fit generated records | Protected-main template/compatibility/Color registry exact bytes and three known plain/staging/production identities with actual full runtime byte closure | Three-edition current-platform runtime case PASS. All three owners byte-equal protected main; plain/staging/production distinct fingerprints remain |
| Admission negatives / AC04,05 | Old renderer, counting logic, or substituted canonical/immutable bytes pass a valid label | Existing historical reviewed identities plus byte equality at both canonical and immutable paths | Color content-registry refusal case PASS; no extra family/client alias remains |
| Fixture consumers / AC03,05 | Valid restored runtime reaches rights/package with incomplete retained source metadata | Rights retained-key equality, exact digests and frozen publication report binding | Selected production/modern-staging consumers FAIL with WB213-F01; selected staging regression identity case PASS. Existing release-controller/publication-records suites and protected prepublication routes own this |
| Explicit retention source / AC03,05 | Reconstructs from wrong checkout, missing declaration, tampered digest or silently ignores sourceRoot | Default and explicit-root artifacts equal; missing/malformed/tampered declarations refuse | Existing edition-retention explicit-source case PASS for base/Color including production derivation; unchanged publisher sourceRoot scope reused by source analysis, no new implementation authored here |
| Public recovery / AC03,05 | Current correction deletes/replaces previously served immutable bytes | Base/parent Git blobs, not current manifest alone | All120 protected-main and139 parent immutable public files match exactly using `snapshot.immutable`; all101 declared retained source/public copies match their digest. Existing edition-retention/rights/source gates still required |
| Historical PDFs / AC03,05 | Archive omits, corrupts, renames or changes a historical rendition | Protected-base original Git blobs, member SHA/size and exact member inventory | All3 members read in memory and equal original bytes; archive hash/size matches manifest; no extraction side effects. Recovery locators and catalog read; RI verify PASS |
| Catalog/budget / AC04,05 | Newly archived/deleted paths escape ownership or limits are raised | Existing unchanged RI config, full current catalog and hashes | RI `verify` PASS; capacity metadata within unchanged bounds. Current hash bytes263954631/265000000, margin1045369; largest parsed-text margin218 bytes. Capacity alone does not prove hash integrity; verify separately passed |

## Actual execution and retained observations

### A. Exact-slot/runtime check

```sh
node --test --test-reporter=spec --test-name-pattern='discovery link reversal|research theories retain|current platform runtime tuples|content registry admission rejects' tests/executive.test.cjs tests/content.test.cjs tests/color-motion-contract.test.cjs
```

Exit0;4 tests,4 pass,0 fail/cancelled/skipped/todo; duration14081ms. Passed cases are exactly the first four matrix rows. Runtime build uses temporary output/lock/cache and cleans it; repository source remained clean.

A prior invocation of the same selectors was not admitted as evidence: the wrapper emitted only `.output` and lost the session/completion metadata. Process inspection found no remaining matching process. The explicitly captured invocation above fixes evidence collection; no prior pass/fail was inferred. This is a reporting limitation, not a suppressed failing test.

### B. Dependency/fixture check

```sh
node --test --test-reporter=spec --test-name-pattern='selected journeys compare actual base|explicit production Color preserves|modern staging can preserve|explicit retention source preserves' tests/staging-regression.test.cjs tests/release-controller.test.cjs tests/publication-records.test.cjs tests/edition-retention.test.cjs
```

Exit1;4 tests,2 pass,2 fail,0 cancelled/skipped/todo; duration4985ms. Passing cases: explicit retention-source declaration/refusal and selected base/Color journey identity. Failing cases and diagnosis are WB213-F01. These are8 total accounted test cases across A+B:6 pass,2 fail, not a broad suite pass.

### C. Read-only identity/recovery diagnostics

- Packet bytes verified, all file/contracts matched. Protected `research.html` template, runtime compatibility and Color contract equal3877546 exactly.
- Public files selected with actual `snapshot.immutable`:120/120 base and139/139263d parent match,0 differences. Initial exploratory prefix count excluded media and was not used for completeness; final count uses the canonical predicate.
- Retained manifest101 paths: both `site/retained/` and `docs/` copies SHA256-equal declaration,0 differences. A separate rights join observed101 versus83,18 missing,0 stale,0 shared-hash mismatches.
- Archive `historical-r32-r34-pdfs.tar.xz`:1170736 bytes, SHA256 `759109e5c0c04b436c5a83fe06902ad43ad3ffefe4f9f9d720a6fe1a41fe0faa`; exactly3 expected regular PDF members. Each equals its protected-base original and its declared size/hash: R32=1103360/`63badf1b…55ffe`, R33=1103558/`bef605e3…0f773`, R34=1104019/`a4bff09e…8b80`.
- First diagnostic script resolved `Path('.').parent` instead of the absolute cwd and failed to find the packet before any comparison (exit1). Corrected the read path to `Path.cwd()`; completed diagnostic exit0. No source mutation and no inferred success from failed setup.
- `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify`: exit0, `Repository Intelligence context is fresh.` Capacity command exit0 with bounds above. Diagnostic metadata explicitly says content integrity/catalog freshness unverified; the separate verify supplies that observation.
- Allowed existing raw files read: `protected-runtime-tuples.json`, `retention-delta.json`, `seo-content-correction.tap`, `seo-current.json`. Their preparation/old source labels remain; no current check identity was retroactively assigned. Current scoped executions above supply independent evidence.

## Whole-delta allocation and limits

Inspected complete base→candidate path/stat inventory and actual correction changes. Inspected underlying native-link/origin dependency, candidate reconstruction sourceRoot, release retention-source handoff, profile registry and workflow predicate additions for integration context. These earlier changes remain part of the PR; they are not excused by the small Research correction. Unchanged publishing/parser/origin/advisory/scanner/history campaigns were not repeated here and are **not independently passed by this review**. Their maintained issue-policy/source/security routes retain full obligations. No broad CPU campaign was launched.

The selected cases are branch/partition-driven, not a measured branch-coverage claim. No browser, PDF visual/rendering, hosted response, mobile/no-JS, intermittent navigation, live GSC/canonical, external editorial provenance, actual CI or protected package replay was executed here. Existing SURFACES/SEARCH/EDITORIAL/TECHNICAL-SCOPE/RELEASE/MEASUREMENT gates remain with their owners. The tight unchanged RI headroom is observed, not a new permission to enlarge budgets. Refresh the pending guide receipt and required exact-head evidence after correcting WB213-F01; this report supplies neither those approvals nor closure.
