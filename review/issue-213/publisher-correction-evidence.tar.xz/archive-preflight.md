# Issue 213 / PR216 — lossless historical-PDF archival preflight

Date: 2026-11-21. Role: independent Requirements & Acceptance, preimplementation archival scope only. Execution/task handle: `/root/issue213_archive_scope`.

## Own verdict

**PASS for the exact bounded archival preparation/implementation, subject to the mandatory completion conditions below; no completed-candidate, whole-AC, staging, publication or release acceptance is supplied.** The proposed R32/R33/R34 review-preview repack is necessary capacity maintenance for retaining the correction's immutable public resources within the existing 265,000,000-byte RI limit. The three PDFs have documented historical supersession, are outside the current selected R37 publication and its declared assets/presentation, and are not active authoring inputs or executable fixtures in the inspected callers. This permits lossless storage relocation while preserving the unfinished publication/rights owners and all historical evidence. It does not permit deleting that evidence or treating issue2/5 acceptance as complete.

Independent checks confirm all three original hashes and sizes, exact archive-member byte equality, the archive digest/size, and the supplied before-capacity measurement. No loose PDF was removed, archive installed, source/test changed or external service written by this reviewer.

## Scope and authority

Issue213's original intent is bounded discovery of the existing SDLC article and distinct research/companion ownership. Its latest supplied owner checkpoint requires preservation of all public/retained immutable resources and existing bounds before another authorized Stable Staging attempt. It expressly requires capacity measurement before maintenance. The supplied instruction authorizes correction and Stable Staging only; protected merge, production and external publication remain separate.

CONTRIBUTING.md lines97–116 permits exact-original archival with a path/size/SHA256 manifest, extracted-byte comparison, useful original-path locators, complete inventory and before/after headroom. Eligibility requires delivery **or documented supersession**. It forbids archiving active inputs, unfinished work and public/rights/rollback resources just because an issue is closed. Here the eligible objects are obsolete rendered previews, not the unfinished publication's authored source, current edition, asset or acceptance records. Blueprint lines15–21 expressly identifies R34 as historical, not matching R35, and R32/R30 passages as historical. The selected `publication.json` is R37 and remains `status: review`, `rights.status: review-pending`; its presentation PDF is the separate `site/assets/publications/pmday-ai-both-sides/presentation-v35.pdf`. Manuscript revision history identifies R33/R34 followed by R35/R36/R37. These observations establish supersession without asserting production delivery or clearance.

The precise three-file relocation, archive/member mapping and metadata/check work should be appended as a dated scope decision in the existing issue213/PR216 route before dependent removal. It is ancillary retention maintenance, not an expansion into issue2 editorial changes, a new publication edition, controller authority or a duplicate owner. The original AC IDs/meaning and open owner/rights decisions stay intact.

## Independent observations

The local checkout is deliberately dirty, not a clean candidate. Local HEAD is `263d071e7be129e9a6bf7af6e717805e19e7564a`; local main is `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`. Read-only `git status`, refs and remote agree with the packet's dated identities. I did not independently query live GitHub state; parent must revalidate before advancement. Only root AGENTS.md was found in the relevant repository inventory. README, root AGENTS, map, CONTRIBUTING and dated MEMORY were read; MEMORY was not treated as live delivery evidence. No parent scratch notes, peer output or private conversation was read.

The scratch archive has exactly three regular members, each a **basename**, not a repository-relative path. It is 1,170,736 bytes, SHA256 `759109e5c0c04b436c5a83fe06902ad43ad3ffefe4f9f9d720a6fe1a41fe0faa`.

| Full original path prefix `review/issue-2/pmday-candidate-20261015/` + filename | Original/member bytes | Original/member SHA256 | Actual comparison |
| --- | ---: | --- | --- |
| `The_Sum_of_Our_Technology_R32_2026-10-24.pdf` | 1,103,360 | `63badf1b31fd89ca4612f9ed641f7714ea8382a8953ed03628bd45216bd55ffe` | Equal, direct decompressed-member bytes compared with original |
| `The_Sum_of_Our_Technology_R33_2026-10-24.pdf` | 1,103,558 | `bef605e3c03b60e4b882909ce4ea47bb18706f2554e3dd0d6a0db75f65e0f773` | Equal, direct decompressed-member bytes compared with original |
| `The_Sum_of_Our_Technology_R34_2026-10-24.pdf` | 1,104,019 | `a4bff09eb22101cef76a3a3cec50879784aeffa85d5ae81d3048c5ae50f08b80` | Equal, direct decompressed-member bytes compared with original |

A first diagnostic using the full repository path as the TAR member failed `KeyError`; listing showed basenames. The subsequent basename extraction comparisons passed. This was a reviewer diagnostic error, not archive corruption, and demonstrates why explicit path-to-member mapping matters. No files were extracted onto disk.

All eleven existing ZIP/TAR archives under `review/issue-2` were enumerated by member names; none contains any of the three exact PDF basenames. This supports creating the proposed new archive rather than reusing those scoped existing kits; it is not a global archive-content audit.

Repository-wide exact filename searches, including hidden tracked configuration but excluding `.git` and derived `agent-context.json`, found: R32 links at candidate README line7, blueprint line30, immutable R32 audit line35; all three path catalog entries at lines7672–7688. No executable test, engine, public catalog, publication asset or retained-resource caller was found. R33/R34 additionally occur in manuscript revision history and R35 historical status prose. Generated RI references are derived inventory and must be rebuilt. Search absence is bounded by these names and inspected inventories, not a proof against arbitrary constructed external links.

Independent command `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json capacity` returned exit1 with exactly the supplied current figures: 266,038,565 hash bytes against265,000,000 (excess1,038,565), 3,141/5,000 files, 11,726,610/32,000,000 largest hash input, 24,257,391/50,000,000 parsed-text total, and1,999,782/2,000,000 largest parsed-text file. This diagnostic expressly does not verify content integrity or catalog freshness. Arithmetic: loose originals total3,310,937 minus archive1,170,736 yields2,140,201 bytes saving. Projected total **before new metadata** is263,898,364, leaving1,101,636 bytes. Actual final capacity/build/verify, not this projection, must determine acceptance. No bound increase or inventory exclusion is permissible.

## Findings and mandatory completion conditions

| ID / severity | Exact evidence and mechanism | Affected requirement | Required treatment / disposition |
| --- | --- | --- | --- |
| AR01 / medium, implementation prerequisite | Proposal records full original paths but TAR stores basename members; no final on-repo recovery manifest/locators exist yet. A full-path extraction command fails, as observed. | CONTRIBUTING archive recovery and historical provenance; AC03/AC05 retention/integrity | Record an explicit original-path → archive path → exact basename-member mapping, original byte size and SHA256, archive digest/size and source ref. Each proposed `.pdf.ARCHIVED.md` locator must identify itself as a locator and use the actual member in a tested extraction command. This is a defined implementation obligation, not a blocker to preparing that metadata. |
| AR02 / medium, advancement gate | Before-capacity diagnostic is over the fixed limit;2,140,201-byte saving is only pre-metadata arithmetic. Index/catalog freshness is intentionally not yet verified. | AC05 RI/RI-CI and unchanged hard bounds | Record exact final before/after bytes and headroom including manifest, locators, amended indexes/review receipts and catalog changes. Register removals/additions with correct history owners; rebuild and verify complete RI and applicable RI-CI/navigation. Recheck each original's extracted bytes before any loose removal. Preserve failed capacity evidence. No source exclusion or limit change. |
| AR03 / low, navigation/provenance constraint | R32 audit line35 links the original `.pdf`; proposed locator name is `.pdf.ARCHIVED.md`. Preserving historical audit bytes leaves that historical direct link unresolved as a normal file link. | Useful retrieval and immutable historical audit requirements | Keep the audit and historical manifests unchanged. Update maintained README/blueprint navigation to explicit locators and add an archive index note explaining original-path lookup through the matching locator/manifest. Do not claim every historical PDF hyperlink remains directly downloadable. Do not create misleading PDF bytes containing Markdown. |
| AR04 / medium, scope/status constraint | `publication.json` remains review/review-pending; R35 status records unfinished native integration and pending rights. Supersession allows storage relocation but does not satisfy those decisions. | AC03 publication/provenance boundaries; AC05 authorized delivery; issue2/5/7 ownership | Append exact bounded maintenance scope in issue213/PR216 and retain explicit issue2/5/7 unresolved exceptions/status. Archive only these three historical rendered PDFs; preserve current source, editions, asset/PDF resources, raw failures, first reviewer results, manifests and public retention. No acceptance/status upgrade or release authority follows from repack. |

No blocking ambiguity was found about which exact three bytesets may be losslessly relocated. AR01–04 must be satisfied in the completed candidate; this preflight does not mark them executed.

## Intent / AC → check or gate → observed result

| Intent / AC linkage | Required independent oracle or gate | Observed here / next gate |
| --- | --- | --- |
| AC02: one primary SDLC destination and distinct research owners | Scope comparison with owner and selected publication | Archive affects historical issue2 review storage only; no destination or content decision accepted/changed here |
| AC03: provenance/edition/rights retention | Original bytes versus extracted bytes; current publication/assets versus archived targets; preserved rights status | All three equal; selected R37/current declared assets disjoint; rights stay pending; final manifest/locators and preservation diff pending |
| AC04: technical integrity and unchanged bounds | Actual callers, recovery path, maintained navigation, appropriate complete-diff checks | No executable/public caller found for exact target filenames; current README/blueprint and historical audit references identified; final navigation/recovery checks pending |
| AC05: source-bound reviewed delivery and RI integrity | Final source manifest/diff, archive recovery, complete RI build/verify and CI map, independent candidate review, existing controller admission | Current capacity failure reproduced; saving projection verified; final prepared source/inventory, full review and protected-main replay still pending |
| AC01/AC06: baseline and outcome measurement | Dated search/GSC and delayed finalized-window owner gates | Outside archival review; no acceptance supplied |
| Stable Staging only | Existing source/admission/review gates, current protected-main consumer replay, fresh authorized staging run | No controller replay, hosted observation or release executed by this review; original authorization boundaries retained |

All six whole issue213 criteria remain open. No issue2/5/7 gate is closed. Completed-candidate review must consider the full corrected integration, rather than importing this storage-only verdict as acceptance of unrelated content/oracles/runtime changes.

## Input identities and assurance limits

Primary packet `/workspace/scratch/74ce6d806bbc/213-work/archive-proposal.json`: SHA256 `d093030da107a5f2c7ea9a2d88f552e47e4d9f8e827156a6ae6fce87f3e56cba` (independently recomputed). Supplied owner `/workspace/scratch/74ce6d806bbc/issue213-owner.md`:49,942 bytes, SHA256 `8bfb0551be8e479c4e52833d42c74c6f2223d8fd472cd591e91bcaa766e28f37`. Before-capacity packet:2,624 bytes, SHA256 `22cc9918a8dbbed09b8f168bc4fe24f7c1e96f3e578cae183fed53f23f1979e8`.

| Dependency | SHA256 inspected bytes |
| --- | --- |
| `agents/reviewers/README.md` (common prompt) | `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8` |
| `agents/reviewers/requirements-acceptance.md` (role prompt) | `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6` |
| `AGENTS.md` | `120bba8320b0ed2c24fb6ce21cb317b9773490f5fafc19fc780f8b42781caba3` |
| `CONTRIBUTING.md` | `ec10d92c6f861e9c6de32b79eaf428fb6d4ce3b5091d000bc680bfc5ca29d30f` |
| `site/publications/pmday-ai-both-sides/publication.json` | `a0c0c33f7206e96eafd587a67bf893b70520563fe6e0682d650df03eea5a9142` |
| `site/publications/pmday-ai-both-sides/blueprint.md` | `f8bb7dfe8ad1abf413535cc205b21eddbe510b14746f870d7a1f46dd1bea4c0b` |
| `site/publications/pmday-ai-both-sides/manuscript.en.md` | `8c788866896cf28ecc4dc6da8bbdcdc3c8fc76a561b485596fd0f467e2a04d71` |
| `review/issue-2/pmday-candidate-20261015/README.md` | `688069b1f308a0a1784d7edf2d887ec0f0d250f4a25f7c4893d858ba205b0c74` |
| `review/issue-2/2026-10-24-r32-pr-audit.md` | `14c6cc7354fcb33ca5e9ef13051b8a6867770f86fee491f54ad9875a3e4174d0` |
| `review/issue-2/2026-10-24-r35-source-and-print-status.md` | `3d7f37ff4d57b3b7ce89a15b0539f72995e8fc2dc5e36dc0ed8aff89d58d797a` |
| `.github/repository-paths.json` | `ea290f76905fb6222f9b1191a141917073d88b507edbdbd29737b6361c2636b2` |
| `.github/repository-intelligence-config.json` | `66adb348ba24a7f5fa4851ddba10f102e6f81cbff8824679e800204068db9468` |
| `.github/acceptance/issue-213.json` (working candidate) | `551f6b898d0889296b786b8b89cd6b8467d19e007a2875679396786a3eca4898` |

The supplied task states actual launch `fork_turns=none`, no model/effort override and accepted handle `/root/issue213_archive_scope`. These are supplied launch facts; the parent owns retaining the originating tool response. The reviewer's visible task did not contain author conversation or current peer verdicts. Provider context/model/memory internals are unknown; no provider-level isolation attestation is claimed. Shared filesystem is not a sandbox. Source hashes bind the inspected dirty subset; there was no complete immutable candidate manifest in this archival preflight, and no clean-checkout claim. Supplied proposal hash and actual original/archive identities agree. Key supersession-source hashes were rechecked unchanged during inspection. Relevant later byte changes require affected re-review.

Executed checks were read-only filesystem/Git inspection, exact-name caller searches, scoped archive-member inventory, decompression into memory and direct equality/hash checks, and one current RI capacity diagnostic. No full RI verification, final recovery command/locator inspection, visual PDF review, broad testing, release replay or hosted acceptance was performed. This is the first preserved judgment of this execution; no reconciliation or peer output was consumed. Only this assigned output artifact was written.
