# Issue213 finite secret dispositions — independent Requirements preimplementation review

Date: 2026-11-21. Reviewer execution: `/root/issue213_finite_scan_preflight`; distinct nonauthor Requirements role, first preimplementation judgment. Parent reports explicit requested and accepted `fork_turns="none"`, no model/effort override. Provider context/model internals are unknown; this is not provider attestation. No delegation, implementation/test edits, external writes or broad scan rerun performed. Only this assigned artifact is written.

## Verdict

**Boundedly permissible for dependent implementation, with mandatory proof and refusal conditions below.** The eligible finite scope is exactly99 new path/rule/SHA1 tuples:91 Hex findings plus8 Base64 inventory findings. The101-row proposal is an evidence inventory, not an instruction to append all101 rows. Exclude its two `review/issue-213/workflow-guide-evidence.json` findings from every finite ledger. Their admission must come from the existing current-source generated-field proof after a correct committed guide receipt exists. The separate two browser-integrity findings use existing current lock/installed-package proof and existing ledger authority; they do not require new exceptions.

This permits the narrow treatment already owned by issue213; it supplies no completed-candidate acceptance, whole AC completion, security guarantee, protected merge, production or external publication authority. Latest supplied authorization is correction plus Stable Staging only.

## Inspected identity and independence

Repository HEAD: `ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01`; original report tree: `bfc93c7ea87055b9dda178ed3f360634293b3bb0`. Local `origin/main` is `3877546d29a04f235f9ec0f3175f4e0d90bfd60d`. Live GitHub refs were not independently refreshed in this delegated read-only review. Supplied owner binds issue213 / PR216. This checkout is dirty, with guide receipt, rights inventory, content/executive tests and SEO formatter restoration; it is not a clean reviewed candidate. Native ee6383c bytes, rather than ambient dirty bytes, were read for all101 factual witnesses. Of those41 source files, guide receipt and SEO source differ currently; both proposed SEO literals still exist after formatting. Final implementation needs new exact-source binding.

Read root AGENTS, README, repository map, CONTRIBUTING, acceptance and style owners, release/security policy, common and role prompts, scoped owner/AC text, actual scanner/closed ledgers, generated-proof implementation, existing secret-review negatives and relevant generation owners. Map identifies only root AGENTS as applicable. No current peer review artifacts or private history were read. Historical judgments embedded in the supplied owner were not used as acceptance evidence. No unrelated memory was inspected.

Proposal SHA256: `a0ca6748c21d8712a4ea953ac0d73d762ac60238c34dd93d679f8ed2b7aad644`.
Common prompt SHA256: `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`.
Role prompt SHA256: `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`.

## Independent observations

- All101 proposal IDs are unique and absent from all five current ledgers. For each, independently loaded its source blob from native ee6383c, recomputed source SHA256, found the exact literal on the reported line, recomputed its SHA1, and matched path/type/hash/line against the raw detect-secrets report. Zero mismatches. This verifies occurrence identity, not that any arbitrary high-entropy literal is harmless.
- Independently examined all101 source-line contexts. HTML values occupy `site-engine`, `site-route`, `data-article-rights` or `data-materials-binding` fields; the owning builders generate them as public content/runtime/rights/material digests. No inspected value is a credential, authentication input or secret retrieval reference. Immutable route hashes agree with the named snapshot directory. The values in the source amendment and exact SEO amendment are its before/after fragment SHA256s; both recompute correctly.
- Recomputed all13 flagged retention-manifest checksums against both the exact native retained files and corresponding native docs files:13/13 agree in both locations. The four Base64 source literals are four actual tracked retained snapshot directories, each containing one HTML file with a corresponding docs snapshot. The whole `site/retained/article-snapshots/<hex>` literal, not merely the hex suffix, produces each proposed SHA1. Each appears in exactly the two named catalog paths. These8 exact IDs are the finite admissible addition to the currently10-member `reviewedInventoryPaths` set.
- Recomputed the recovery archive SHA256/byte count and read all3 exact archive members without extraction; all member byte counts and SHA256s match the recovery metadata. These4 flagged fields therefore identify recoverable public historical PDF bytes. The receipt does not establish rights clearance or publication acceptance.
- The reproduction contains103 distinct candidates, not101: proposal covers101 and the remaining2 are `tools/quality/browser-archives.json` Base64 IDs `0cbdcde8a0303a73dad738a11aa7550d9510b4d0` and `cd7fc992e9d11af32806607c3a889f40813c5e56`. Independently executed existing `browserIntegrityProof(process.cwd(), path.resolve('tools/quality/toolchain'))`; it returned exactly these2 IDs against current unchanged registry, dependency lock and installed package lock/metadata. Parent-provided `browser-integrity-disposition.json` agrees. No new browser exception is justified.
- Existing `secretReviewEntry`, `loadSecretReviews` and `reviewedSecretFinding` require exact path/type/hash, a closed five-ledger input list, strict metadata, no duplicates, regular nonsymlink ledger files and unchanged2,000,000-byte ledger bounds. Current issue213 ledger is155,235 bytes. Its checksum-only type restriction has the explicit finite inventory-ID exception; adding eight IDs preserves this design only if every corresponding tuple has its own reviewed ledger entry.
- The existing generated guide proof refuses dirty checkout bytes, requires exactly one changed guide receipt, binds its base to the actual merge-base and reruns the actual guide-review command on committed HEAD before admitting only `base_sha` and `scope_sha256` fields at their actual locations. Dirty or stale guide text is therefore not a finite-ledger candidate. Existing negative tests cover dirty, stale and copied guide fields. The first raw repository-security result remains failed; no new pass is claimed here.

## Requirements findings and necessary treatments

| ID | Severity / source | Mechanism and AC impact | Required treatment |
| --- | --- | --- | --- |
| RFS01 | Blocking if omitted: proposal `findings` rows50–51 / `scope` | Mechanically appending the101-row evidence list would bypass the maintained guide proof and hide stale receipt fields; violates AC04/AC05 source integrity. | Append exactly99 eligible IDs. Keep both guide IDs out of every ledger, correct/review the real guide receipt, commit it, and establish fresh generated proof. |
| RFS02 | Evidence completeness: reproduction103 vs proposal101 | A99-ledger result alone leaves4 findings unaccounted:2 guide and2 browser values. Omitting them would overclaim successful triage under AC05. | Preserve explicit103 =99 finite +2 guide proof +2 browser proof accounting. Browser proof independently reproduced here; guide/final integrated scan remains pending. |
| RFS03 | Mandatory final gate: dirty checkout and native failed report | The current changes invalidate treating first-run line/source identities or old guide checks as final source evidence. | Bind proof to each original scan/source, then independently review the actual completed finite set/ledger/test changes and run security/required checks on the final clean native candidate. Preserve the failed first report. |

No independent scope defect prevents implementing the exact99-entry /8-ID treatment under these constraints. The treatment is necessary to distinguish audited public hash false positives from secret material while retaining the original scanner behavior. These conditions are acceptance obligations, not permission to relax the guard when a new value fails.

## Required preservation and refusal cases

1. Extend only the existing finite inventory set by the8 proposal `newBase64Ids`, each independently witnessed above, plus their own issue213 ledger entries. Keep the old10 set IDs, all preexisting ledger entries and older ledger bytes unchanged; add no new authority file, wildcard, type-wide/path-wide match, permissive fallback or automatic approval helper.
2. Append only the91 verified non-guide Hex tuples plus8 inventory Base64 tuples, with reasons pointing to controlled exact source/line/literal/hash evidence. A generic “public checksum” assertion alone is insufficient proof. Keep original detector plugins/entropy limits, full tracked text coverage/public HTML and byte/time/resource bounds.
3. Required negative coverage for the8 IDs: missing corresponding ledger must refuse; correct hash under another path, another hash in either exact inventory, another detector type, arbitrary Base64 tuple and unapproved neighboring ledger must refuse. Existing exact-inventory test uses prior values; update its bounded data coverage or add a focused maintained case so all8 new admissions are exercised under both exact source paths. Retain duplicate/metadata/type/path/symlink/oversize failures. Existing semantics do not need a general rewrite.
4. Guide fields: wrong base, stale scope, dirty receipt, copied value outside the admitted fields/locations and forged proof must continue refusing. New scanner/ledger/test edits change the guide scope; refresh against the final candidate rather than an intermediate dirty state. No ledger workaround for missing Git objects, unavailable producer/toolchain, invalid proof or source drift.
5. Browser integrity admission still requires its existing exact ledger plus successful current installed-package/lock proof; absent/stale/mismatched proof must refuse. The2 observed IDs do not expand inventory exceptions.
6. On any unmatched new value or changed meaning, stop automatic classification and inspect it individually. If it is credential material, remove/rotate under its actual owner rather than admitting it as a checksum. Historical public presence alone cannot prove safety.

## Acceptance traceability and next gate

| Intent / AC | Check or owner gate | Observation / remaining evidence |
| --- | --- | --- |
| AC04 technical integrity / CS01/04/05/08/09/10 | Existing source owners, exact metadata/tuple validation, style guard and independent review | Bounded requirements admissibility established; completed scanner/ledger/test diff and style/behavior checks pending. |
| AC05 exact-source delivery | Retained first raw scan, occurrence/source proof, final clean full security and owning source checks | First report failed;101 witnesses reproduced;103 dispositions accounted as above; final generated guide proof/integrated scan pending. |
| Rights/provenance preservation / AC03 | Unchanged immutable source/retention/recovery evidence and existing rights gates |13 manifest checks and4 archive/member hashes reproduced; no rights/publication decision supplied. |
| Existing delivery authority / AC05 | Fresh applicable role reviews, current-source CI/admission, existing Stable workflow and operator observation | Scope is correction plus authorized Stable only. No release outcome or whole issue acceptance claimed. |

The next dependent step is the bounded implementation, followed by fresh completed-candidate Requirements/Code/White-box and applicable integration/Exploratory reviews under the repository's full-scope role policy. This preflight does not replace those executions. No broad campaign rerun was performed; later exact-source execution is justified by a changed, reviewed correction and must retain all earlier failures.

## Reproducible inspected-input identity

The following manifest binds the actual inputs read and all41 native occurrence-source files. It is reviewer-created input accounting, not a claim that the parent supplied a complete precomputed packet. Manifest SHA256 (canonical JSON with sorted keys, compact separators over `nativeSources` and `inputs`): `aa6d16ccac5e60d63dbedbcb7d676f506e94261816bc7874f69f46be926956c1`.

```json
{
  "nativeSources": [
    {
      "path": ".github/repository-intelligence/agent-context.json",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "677b25dca9a38f6a146ec3156490230cbe003b5fbbb1daa5e7c4b610cd771d49"
    },
    {
      "path": ".github/repository-paths.json",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "f9b908b8b78e4d81e196e10cb964e29aabd169bc5c722aa0177109dee6836979"
    },
    {
      "path": "docs/article-snapshots/0306d12d1f4a6ceec662ab04dacaa5a4636bb0893b438286ce229ab11d83b5d2/ai-governance-is-control-theory.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "45b48ba545e0f40efa907550d6ab494e24841a00cdf61fc18dbc93696a702c63"
    },
    {
      "path": "docs/article-snapshots/055b659ede4dd64a77e712c87a20fd82fdec604d769c8a12c7cb1319f4fe58ba/beyond-embeddings.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "e7c9385aa5d57adef141eb60db00f378de73cfb3e61df3da83d5df474dd26844"
    },
    {
      "path": "docs/article-snapshots/0a32467ca8154a3d74828f1b85365c29ac66d4be77aa7997a882ee6635e6f621/beyond-embeddings.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "3031a6d03f8a6da8726bfe49c6635edae8b23ac3e90012c88de8dd4e321b45a6"
    },
    {
      "path": "docs/article-snapshots/19aad38dbd11c66b57529b19e412d3603895e63c01189290c35df1460953c314/ai-verification-crisis.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "1112962f35f206cc52ee5ca9a522255147edc5f524b2a441b3c5e6bdca3fb8db"
    },
    {
      "path": "docs/article-snapshots/297841ec5d32aef83aab3a9843eb68e4cc4bd27c3e9dd8e99b408959b0b29220/ai-governance-is-control-theory.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "7c2c96df921e0abb6fc58411ddd8a8c5fd10ec5e57cf1534b11bafb4e3e209f3"
    },
    {
      "path": "docs/article-snapshots/42d13085317f026e0f95c02fda650633f93c1515fd34de80296c63abb4c113b6/ai-native-workflows-have-a-moat-problem.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "0fcbe6ae203dc9561ab38dbc063bf92c9f8be3cddc1bffcb5c733997b70860b1"
    },
    {
      "path": "docs/article-snapshots/71b4e2104436e7e4558fa8240567d6a897261f9b38b1ad86208ba5cc1283b4be/thinking-systems.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "90d041a9aba6f5fd41621be248e3dbb67d5763f37df6d3cf22e52f09d0d04560"
    },
    {
      "path": "docs/article-snapshots/7a82415930ae3e8b6c71bf84cc0577332bcd2ffd72a5ac09503a77589c4dc517/ai-native-workflows-have-a-moat-problem.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "e63d5d2145fc6bcf7ff6cb07ae6f422debc57d458704126a7f2a456210215bfb"
    },
    {
      "path": "docs/article-snapshots/8dd248b9e11dee2b70c3fdb8378c62d28c9bac4181cab7f598bf7f6d4b79632e/ai-verification-crisis.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "15d84ec52e22a1880f31452cd92157477f69fc819ac8aeecb081ac74b7208316"
    },
    {
      "path": "docs/article-snapshots/9895f1b734aa89e978e1c085fcdc5006affb72aa782988e378521331b3e86579/thinking-systems.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "6a71cb22784fcc338407b115c6f3f614c21a706a3b85abf27583405ec7b8ecc7"
    },
    {
      "path": "docs/article-snapshots/a46f5b6bd8340d8d84f0ba43e8fe6ee6559a77b74c01bc167e4f6f393fb2e32b/agentic-loops.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "b723aeeb5fd4ca110ef46d12284f6233a0165fbf19d71bdbe157535217bfe969"
    },
    {
      "path": "docs/article-snapshots/b7f04f9973d9e03e615ae4144dda13e41e69590ecd1d0accc6de577f7855b4c8/agentic-loops.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "a63ed628eea015abdaf77a7cbe3186f5a7628f6a228387df8d7e96ea66ee7307"
    },
    {
      "path": "docs/article-snapshots/cc75b74b18fa378997195f8af0097e3ca5c7b77d6d3e8d45920d03f9bec5a326/ai-cost-cutting-fallacy.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "c8aca91c47db03bb4970fda36e279f58b499e5a0ece2330113af78bdcc0cf031"
    },
    {
      "path": "docs/article-snapshots/dd70db1d1b2730c61e4ee0085d9ca8c0590de08d2cee49f4df2091dc21a63f91/the-sdlc-is-out-of-balance.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "904d7bcad386e10fa20677ba4035ca0868c9642f53fb62a24a4d9699e80845b5"
    },
    {
      "path": "docs/article-snapshots/df1d5045fee76cc7497436c529b80e5cee53418668ff4dad5e29d0c39eace573/the-sdlc-is-out-of-balance.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "a51c4b47e9b8eca591f866c3cc5a75b95dc9bed34c925a5fedb349957d7912f9"
    },
    {
      "path": "docs/article-snapshots/f91fdaf40d817f72d6ccc4f6f40537e040512375bcd48b408273eff58128246a/ai-cost-cutting-fallacy.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "45790f31eba04ab22a032aa1c0877e5efe01ca807f7728a061424a7c638c93cc"
    },
    {
      "path": "docs/snapshots/10d6abf1c911d0567ef6f555a667afd00283df5a565e6873ecce4ae782183b4c/credits.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "e08b40359a40a71da1e8f04d429c4ac9a753cdd5b37fa320b6daf7e16374e5f6"
    },
    {
      "path": "docs/snapshots/4f2a4c2c9cf12de88be4c7c62fe5d7af01545068e1f78c479e130703c7d64aa5/talks.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "c3bf39a92d4b43734a795ea018bcea15a0b0a3dbf99359a9af15c936837fdffd"
    },
    {
      "path": "docs/snapshots/8f5478a0c1d09efdcc4145647c4f8b9163bc873dc5ac37ef9c7557173a306a33/index.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "f079bc530d88e5da7f8b1f7da2bd61e21fb891ad97e0a9dac4b2d0bd7492da02"
    },
    {
      "path": "docs/snapshots/b82089d4524a93ec50208ce6f154aa67f6e155e8771b73f689e9d60ab773b61c/writing.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "48a439f57348fe498c649a3df7f20e58c6c69b2627926e77101d9c85ebb1c958"
    },
    {
      "path": "docs/snapshots/bed37cc707c2ab1626565d25a47ffc285ee0999e1b7cf9a781085902e44bfd46/research.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "2df8c90711ca2e92ad8f3139dafd2a8f4ed8d038d78c115da1f92594386cd124"
    },
    {
      "path": "review/issue-213/content-amendment.json",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "de6efbfca0ff712d6a29541a66de694aa01c4de2fa22768c7569c5ad0b55a100"
    },
    {
      "path": "review/issue-213/historical-pdf-recovery.json",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "6368d4fd65be1c684ba2e1f0e8683fa558664da0b3d813e6e8e96c5109787fa9"
    },
    {
      "path": "review/issue-213/workflow-guide-evidence.json",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "c01bb9ad09e3b989d2f36e493a83564f71fe98a5d3e9eb997c20bb41ef7a3899"
    },
    {
      "path": "site/retained/article-snapshots/0306d12d1f4a6ceec662ab04dacaa5a4636bb0893b438286ce229ab11d83b5d2/ai-governance-is-control-theory.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "45b48ba545e0f40efa907550d6ab494e24841a00cdf61fc18dbc93696a702c63"
    },
    {
      "path": "site/retained/article-snapshots/055b659ede4dd64a77e712c87a20fd82fdec604d769c8a12c7cb1319f4fe58ba/beyond-embeddings.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "e7c9385aa5d57adef141eb60db00f378de73cfb3e61df3da83d5df474dd26844"
    },
    {
      "path": "site/retained/article-snapshots/42d13085317f026e0f95c02fda650633f93c1515fd34de80296c63abb4c113b6/ai-native-workflows-have-a-moat-problem.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "0fcbe6ae203dc9561ab38dbc063bf92c9f8be3cddc1bffcb5c733997b70860b1"
    },
    {
      "path": "site/retained/article-snapshots/71b4e2104436e7e4558fa8240567d6a897261f9b38b1ad86208ba5cc1283b4be/thinking-systems.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "90d041a9aba6f5fd41621be248e3dbb67d5763f37df6d3cf22e52f09d0d04560"
    },
    {
      "path": "site/retained/article-snapshots/8dd248b9e11dee2b70c3fdb8378c62d28c9bac4181cab7f598bf7f6d4b79632e/ai-verification-crisis.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "15d84ec52e22a1880f31452cd92157477f69fc819ac8aeecb081ac74b7208316"
    },
    {
      "path": "site/retained/article-snapshots/a46f5b6bd8340d8d84f0ba43e8fe6ee6559a77b74c01bc167e4f6f393fb2e32b/agentic-loops.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "b723aeeb5fd4ca110ef46d12284f6233a0165fbf19d71bdbe157535217bfe969"
    },
    {
      "path": "site/retained/article-snapshots/df1d5045fee76cc7497436c529b80e5cee53418668ff4dad5e29d0c39eace573/the-sdlc-is-out-of-balance.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "a51c4b47e9b8eca591f866c3cc5a75b95dc9bed34c925a5fedb349957d7912f9"
    },
    {
      "path": "site/retained/article-snapshots/f91fdaf40d817f72d6ccc4f6f40537e040512375bcd48b408273eff58128246a/ai-cost-cutting-fallacy.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "45790f31eba04ab22a032aa1c0877e5efe01ca807f7728a061424a7c638c93cc"
    },
    {
      "path": "site/retained/manifest.json",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "45e3e1b1cad2438accb92165eece29e4adbbf7cf997dd1736ee6eda5a88b7cfd"
    },
    {
      "path": "site/retained/snapshots/10d6abf1c911d0567ef6f555a667afd00283df5a565e6873ecce4ae782183b4c/credits.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "e08b40359a40a71da1e8f04d429c4ac9a753cdd5b37fa320b6daf7e16374e5f6"
    },
    {
      "path": "site/retained/snapshots/4f2a4c2c9cf12de88be4c7c62fe5d7af01545068e1f78c479e130703c7d64aa5/talks.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "c3bf39a92d4b43734a795ea018bcea15a0b0a3dbf99359a9af15c936837fdffd"
    },
    {
      "path": "site/retained/snapshots/8f5478a0c1d09efdcc4145647c4f8b9163bc873dc5ac37ef9c7557173a306a33/index.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "f079bc530d88e5da7f8b1f7da2bd61e21fb891ad97e0a9dac4b2d0bd7492da02"
    },
    {
      "path": "site/retained/snapshots/b82089d4524a93ec50208ce6f154aa67f6e155e8771b73f689e9d60ab773b61c/writing.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "48a439f57348fe498c649a3df7f20e58c6c69b2627926e77101d9c85ebb1c958"
    },
    {
      "path": "site/retained/snapshots/bed37cc707c2ab1626565d25a47ffc285ee0999e1b7cf9a781085902e44bfd46/research.html",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "2df8c90711ca2e92ad8f3139dafd2a8f4ed8d038d78c115da1f92594386cd124"
    },
    {
      "path": "tools/check_site_seo.cjs",
      "sourceCommit": "ee6383c96d90b7fc39d163bd57c8cb6c7a3b5e01",
      "sha256": "f3f3be1d1dedb0670945a1d769d7697853f2ad261dee7f5ce602aceb19e0c90f"
    }
  ],
  "inputs": [
    {
      "path": "AGENTS.md",
      "sha256": "120bba8320b0ed2c24fb6ce21cb317b9773490f5fafc19fc780f8b42781caba3"
    },
    {
      "path": "README.md",
      "sha256": "579d50a35f2d38d7e9c1b162690b461260e4cbe6fdec361c255b4077c0e6871b"
    },
    {
      "path": "REPOSITORY-MAP.md",
      "sha256": "0407e98b97844cfc9bc649d2ce12a736b843713b68d46c6db905e3f39e2a5edd"
    },
    {
      "path": "CONTRIBUTING.md",
      "sha256": "ec10d92c6f861e9c6de32b79eaf428fb6d4ce3b5091d000bc680bfc5ca29d30f"
    },
    {
      "path": ".github/ACCEPTANCE.md",
      "sha256": "6b67e083df18236a8bc347a8346ef03beda426ebd2a1608896ba82359cfa5e81"
    },
    {
      "path": "guides/CODE-STYLE.md",
      "sha256": "cdef877504055734d653af12237fc708f3e3636dd15dfc0703f71e0f6c87ee40"
    },
    {
      "path": "guides/SITE-RELEASE-GATES.md",
      "sha256": "7ba34887e3ebfc018a1d792e74a704b9570328b8c13563ecc3c3d754799b8b4a"
    },
    {
      "path": "agents/reviewers/README.md",
      "sha256": "725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8"
    },
    {
      "path": "agents/reviewers/requirements-acceptance.md",
      "sha256": "010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6"
    },
    {
      "path": "tools/quality/scanners.cjs",
      "sha256": "96fe64ff182ce4445e15e90db0569eebd85faae0d031d5a36d0ceb0fd73662c8"
    },
    {
      "path": "tools/quality/generated-checksums.cjs",
      "sha256": "5f75fad899737f1494326488ac629aefb0037b418ea385a73937c70f07c8cb31"
    },
    {
      "path": "tools/quality/triage-secrets.py",
      "sha256": "118286bba0bc432052a02f41060128bfa689347e32bd1cb7123ddc538378432d"
    },
    {
      "path": "tests/quality-sources.test.cjs",
      "sha256": "de409412ab8da4ac9b5dceb02f009cb2298c25cc444616df9c75fdeda2015dc5"
    },
    {
      "path": "tools/site/build.cjs",
      "sha256": "6832551602bee5d7281595e07bec7006cf9ccb97f3305638d0fe2bfe2879039b"
    },
    {
      "path": "tools/site/articles.cjs",
      "sha256": "04afec9aa509cc91da03d412854e5fbdad402c65afa294f8ac7762aa52886891"
    },
    {
      "path": "tools/site/article-materials.cjs",
      "sha256": "492e0377bea6741b57a59e87fcfd2c1ffd120371f3a13996633f66491d6622b0"
    },
    {
      "path": "tools/quality/secrets-issue213.json",
      "sha256": "3da5d0d8fd3f389cacda88ea1681cc7b0bef8b8ea10b403151fdf8f998e04ac8"
    },
    {
      "path": "213-work/secret-correction-proposal.json",
      "sha256": "a0ca6748c21d8712a4ea953ac0d73d762ac60238c34dd93d679f8ed2b7aad644"
    },
    {
      "path": "213-work/security-first/detect-secrets.json",
      "sha256": "b5425044e88f820b03c486494e4107157e08a0800d8655c93de9eae2f9115ea4"
    },
    {
      "path": "213-work/security-first/repository-security.json",
      "sha256": "319fbcc464d5950db4f94670d0aab19ebbea9f43b0ecbd784ce68177f893d1b9"
    },
    {
      "path": "213-work/secret-untriaged-first.json",
      "sha256": "5cc13175b36b95e950f7fd8575a69561da2542dd9cfe552d15be8be007ca45a4"
    },
    {
      "path": "213-work/browser-integrity-disposition.json",
      "sha256": "b24412d98fb2471ba704f3f72905a3b40cb1cf83e9b9a8fe44cc9ba0c342febf"
    },
    {
      "path": "issue213-owner.md",
      "sha256": "8bfb0551be8e479c4e52833d42c74c6f2223d8fd472cd591e91bcaa766e28f37"
    }
  ]
}
```
