# Independent Exploratory / Interaction QA — charter and first result

Reviewer handle: `/root/issue213_preview_operator`. Fresh distinct launch reported to reviewer with `fork_turns="none"`; model/effort override absent. Provider model/context internals unknown. No author chat, peer outputs, full issue history or MEMORY read. Supplied sanitized owner and packet used as factual intake. This is an operational input boundary, not provider assurance.

Candidate cf2ab301cc5b658e284f09a49d787d460e69f9bf, tree 762417bdc874db8a2ac7337a9e8c081d8ae3446a, protected base 3877546d29a04f235f9ec0f3175f4e0d90bfd60d. Clean local status and HEAD/tree independently observed. Native hosted source independently confirmed below; local repository remained clean after this read-only review.

Packet SHA256 `2111d962f0d5a22af0039a9285ad0e1af6cf3a4bba9426c3bed6e53b0d4917ce`; owner SHA256 `51bbf4cea5a5edd2db1a030f96e31d445ebf299fd8d3f787f55ddaebd0ba38c7`. Common SHA256 `725c8432ec1f2fea9a61cdbaba01d32676778b3e83b7a73fe2faea422b4ea0a8`; role SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`. Read `agents/reviewers/README.md`, `agents/reviewers/exploratory-interaction-qa.md`, root AGENTS/CONTRIBUTING/README, REPOSITORY-MAP, SITE-CHECK-PROFILES, issue213 acceptance policy, site source contract, Research lenses/research sources and primary manuscript. Only root AGENTS applies (inventory observed).

## Charter set before exploration

Bound: approximately 10 minutes after source-bound hosted origin is available (parent narrowed original25-minute charter before execution); eight meaningful journeys across desktop1440/mobile390 and no-JavaScript. Linux system Chromium156 through Playwright is an exploratory operator surface, not pinned CI153, performance acceptance or physical-device proof. No implementation/source/test edits, external writes or delegation.

1. Research lens selects explicitly labeled existing SDLC article; context and TOC background remain separate.
2. Primary article opens with query answer, attributable research relationship and readable intro.
3. TOC/anchor journey reaches Finding a new balance and diagnostic table; examine small-screen reading and horizontal overflow.
4. Research upstream Subprime and UA destinations and distinct Writing topic links remain discoverable and semantically separate.
5. Article links lead to distinct Verification Crisis and Cost-Cutting companion canonicals rather than collapsing content into a duplicate hub.
6. Repeat primary Research→article journey at390px, inspect screenshots and keyboard focus/return navigation where meaningful.
7. With JS disabled, read changed Research/article and Writing links; anchors/native navigation remain usable.
8. Follow native PDF link; inspect served MIME/status/source digest and visually view representative opening/diagnostic pages, retaining actual failures.

Expected authority: sanitized owner AC02/03/04 and current correction, acceptance SURFACES/EDITORIAL gates, source contract native/noJS promises. This bounded pass cannot close whole ACs or replace native full hosted/staging, editorial, physical-device, production, Google/indexing or outcome evidence.

## Independent first result

**Partial execution / no reproduced product defect in observed desktop and PDF scope.** This is not a blanket SURFACES pass: mobile390 and JavaScript-disabled observations were designed but remain not observed due the browser capability limits below. AC02/03/04 receive bounded positive interaction evidence; whole ACs and REVIEW/SURFACES/EDITORIAL acceptance remain with the orchestrator and their full gates.

### Origin and environment

Immutable origin `https://c308824f.oborskyi-author-ci-staging.pages.dev/`. Parent supplied actual deployment observation run44959869330/job137016851490; that is intake evidence, not my independent CI judgment. I independently retrieved `/_staging/revision.json` successfully and retained raw `preview-operator/hosted-revision.json`: sourceCommit `cf2ab301cc5b658e284f09a49d787d460e69f9bf`, sourceTree `762417bdc874db8a2ac7337a9e8c081d8ae3446a`, publicDigest `f47d5b36a67d1cefcbac6d7a5ff0c5d4fb9f61c59f8a8ce1180a5196828920d6`. Actual CUA screenshot badge also showed `STAGING · cf2ab301`.

Local Playwright system Chromium launch failed before any page/browser observation: `process_singleton_posix.cc:297 socket() failed: Operation not permitted (1)`, SIGABRT. Exact attempted operator script `preview-operator/initial.cjs` and complete stderr `preview-operator/initial.log` retained. This is an environment failure, not a site defect. No unchanged retry occurred. The official browser download was not repeated.

Fallback actual cloud Chrome/CUA browser selected via `cua.getBrowser`, then created tab2. Browser version unknown; DOM-observed viewport1363×936. This differs from the planned1440 width and is explicitly desktop exploration only. CUA's documented tab APIs expose neither viewport resizing nor context JS-disable; no unsupported APIs or source/CSS modifications were used to simulate those observations. No performance, pinned-browser, physical-device or assistive-technology acceptance is claimed.

### Designed and actually executed journeys

Raw CUA AX snapshots, read-only DOM observations and viewed screenshots are retained in this reviewer's execution transcript (calls titled Opening exact preview through Confirming Writing library return). Screenshots were actually viewed, not merely generated. They were not copied into local files. Local HTTP/PDF raw evidence is in the assigned `preview-operator/` directory.

| Case | Expected from accepted scope | Actual observation | Disposition |
| --- | --- | --- | --- |
| E01 Research lens | Clearly labeled existing SDLC article, separate context/TOC destination | Opened Research (`research.html` redirected to `/research`), selected Control & constraints; screenshot showed TOC card, explicit AI code crisis/SDLC article link, separate For The Subprime Code Crisis context anchor and TOC background link. Click reached `/articles/the-sdlc-is-out-of-balance.html`. | Executed/pass at1363px. |
| E02 Primary opening | Query answer with source attribution and accurate edition labeling | Actual article screenshot showed full SDLC title, author, original10November date and R13 author-review revision21November. AX/DOM exposed new Why the AI code crisis extends beyond code review answer and upstream Subprime research link. Intro clearly extends beyond defects to verification, integration and understanding. | Executed/pass; bounded reading, not full source/editorial acceptance. |
| E03 Diagnostic navigation/reading | TOC reaches Finding a new balance; prompts/table readable | Expanded Contents, clicked Finding a new balance; URL hash changed; heading top269.6px. Screenshot showed heading below persistent navigation, Diagnostic prompts, not validated thresholds, all3 rows/3 columns and Cost-Cutting link without clipping. DOM document overflow was false on primary. | Executed/pass desktop. |
| E04 Distinct companions | Cost-Cutting and Verification remain distinct native works with contextual primary return | Clicked inline Cost-Cutting link, observed distinct h1 and2January2026 LinkedIn source label; followed its Verification related-reading link, observed distinct Verification h1 and12June Medium/10June LinkedIn source labels. Both exposed contextual SDLC links; Verification's SDLC link activated with Enter returned to primary. | Executed/pass desktop; no claim of Google-selected canonical. |
| E05 Writing return | Native article returns to existing library with separate works | On primary pressed Enter on Back to Writing. Arrival snapshot at `/writing.html` showed30article library, distinct SDLC/Verification/Cost-Cutting native rows and their separate external platform edition links. Main landmark received arrival focus. | Executed/pass. |
| E06 Upstream/TOC/UA separation | Research ownership and author perspectives remain distinct | Research AX exposed upstream Subprime GitHub, upstream UA GitHub, separate Writing delivery/systems paths and TOC Institute background; primary rendered intro also linked upstream Subprime. | Destination exposure executed/pass. External endpoints and Research→Writing topic-anchor activation not observed. |
| E07 Mobile/noJS | Changed reading/native links remain usable at390px and with JS disabled | Planned local browser could not launch. Fallback has no documented resize/context JS control. Static HTML/source reading does not establish these experiences. | Not observed/blocked; not N/A and not pass. |
| E08 PDF | Native labeled R13 material leads to readable exact immutable PDF | Actual primary Materials block exposed Download the illustrated PDF — R13 review edition and5page description. Opened this observed exact href in Chrome PDF viewer: screenshot showed page1 of5, correct title/R13 byline, hero and query answer. Independently fetched endpoint200 application/pdf,871476bytes, SHA256 `a967d35ecd0b16674bbafb2dcf4f02e2bbc33aa51b6780fccf6fc5057fed93ec`, matching immutable URL path. Poppler rendered pages1and4 were actually viewed: opening/figure1 and all diagnostic rows legible, no clipping observed. | Executed/pass bounded pages1and4. Actual download-control click/save dialog, other PDF pages and PDF embedded-link activation not observed. |

Animated route departures briefly showed old URL/background without article content; subsequent actual observations showed successful arrivals for all activated journeys. I did not measure transition timing or infer a runtime defect/performance pass from transient screenshots. Extension-only metadata errors appeared in console; no site runtime error was established.

### Findings and residual acceptance

No reproducible product finding in executed scope. Risks examined: mislabeled Research destination, loss of upstream/TOC distinction, absent new primary answer, edition confusion, inaccessible TOC target, unreadable diagnostic table, companion collapse, missing reciprocal primary link, broken Writing return, wrong PDF bytes/type and visible PDF clipping. The mobile/noJS capability gap is an evidence limit, not a product finding. Do not treat it as completed independent coverage or silently use source tests as its replacement.

### Regression allocation / proposed treatment

| Case/risk | Existing maintained owner and route | Treatment and actual status |
| --- | --- | --- |
| Research lens label/native target/upstream separation | `tests/test_issue213_acceptance.py` discovery/material contract; `tests/test_issue41_acceptance.py` exact SEO semantic comparison; issue213 DISCOVERY/SEO policy and issue-acceptance workflow | Reuse existing targeted source owners for deterministic link/oracle checks. This reviewer did not run them; actual interaction evidence E01/E06 remains separate. No new suite proposed. |
| Changed primary/companion navigation, noJS/mobile, PDF response identity | `tools/quality/local-browser.cjs --smoke` ordinary preview in `.github/workflows/site-color-review.yml`; `tools/quality/article-browser.cjs` and `tests/article-browser-evidence.test.cjs`; selected content documents in `tools/quality/content-browser.cjs` or existing platform `staging-regression.cjs`, `.github/workflows/site-release-checks.yml` representative-browser step | Retain native selected profiles unchanged. Proposed bounded follow-up: execute affected Research/primary/companion reading at390px and noJS using supported browser, preserving exact source. Not executed here; must remain pending until separately observed. No new browser matrix/budget. |
| Diagnostic table/PDF visual readability | Existing issue213 SURFACES/EDITORIAL manual gates, SITE-CHECK-PROFILES actual reader/media obligations | Retain E03/E08 as bounded desktop and PDF page1/page4 visual observations. No pixel-test addition justified by a reproduced defect. Remaining pages/full parity and any author publication decisions remain separate. |

### Evidence inventory and final identity check

`preview-operator/hosted-revision.json`, `initial.cjs`, `initial.log`, `pdf-headers.txt`, `reading-r13.pdf`, `pdf-text.txt`, `pdf-page1.png`, `pdf-page4.png`. Served headers include200, application/pdf and immutable caching. `pdfinfo` reports A4,5pages, unencrypted R13 review edition authored by Vitalii Oborskyi. PDF view is not authorship/rights/research/publication acceptance.

After observations, Git status remained clean; rehashed common/role, Research lenses/research template and primary manuscript match packet identities listed above. No source/test changes, external writes, implementation or delegation performed. No prior execution evidence was reused as my judgment, and no peer results were read. Provider memory/context internals remain unknown as stated in launch contract.
