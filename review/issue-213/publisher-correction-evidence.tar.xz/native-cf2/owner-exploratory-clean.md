## Original intent

Author request, 17 November 2026:

> Стати по сайту а також зроби тікет на ідею наступну - доволі відомий пошуковий термін Гугл Ai code crisis і треба попасти в цей граф

**Confirmed objective:** make Vitalii Oborskyi's relevant work discoverable for **“AI code crisis”** and the related search/topic space, with a clear connection to **The Subprime Code Crisis**, verification capacity, system understanding, and SDLC imbalance.

This is an **idea/backlog intake**. The target page, content changes, implementation sequence, and measurable opportunity remain to be validated before dependent implementation.

## Owner and scope

**Owner:** this issue owns the bounded query/topic discovery opportunity and its content decision.

Reuse these existing owners:

- [#8 — Search Console](https://github.com/oborskyivitalii/oborskyivitalii/issues/8): indexing, canonical inspection, sitemap observations, and organic baseline.
- [#11 — native buyer-problem guides](https://github.com/oborskyivitalii/oborskyivitalii/issues/11): coordinate if the chosen answer needs a new native problem guide.
- [#116 — Subprime mount](https://github.com/oborskyivitalii/oborskyivitalii/issues/116): planned `/subprime/` composition and upstream research ownership. Assess this route before proposing a competing hub.
- [#159 — SEO and analytics delivery](https://github.com/oborskyivitalii/oborskyivitalii/issues/159) and [#177 — SDLC discovery/analytics](https://github.com/oborskyivitalii/oborskyivitalii/issues/177): reuse delivered mechanisms.
- [#183 — article library](https://github.com/oborskyivitalii/oborskyivitalii/issues/183): reuse existing native articles and their exact source/edition dates.

“Graph” is treated as an intent to enter the relevant topic/discovery space. Evaluate **organic results**, **AI Overviews/AI Mode citations**, and **Google Knowledge Graph/entity representation** separately; they are different observations, and none is guaranteed by adding a keyword or structured data.

### Evidence at intake — 17 November 2026

The expression is used publicly, for example:

- [StepTo: Comprehension Debt: The AI Code Crisis Your Metrics Are Completely Missing](https://stepto.net/blog/comprehension-debt-ai-code-understanding-2026).
- [AI Indigo: The AI Code Crisis: Why Major Open Source Projects are Banning AI-Authored PRs](https://aiindigo.com/blog/the-ai-code-crisis-why-major-open-source-projects-are-banning-ai-authored-prs).

These are evidence of vocabulary and adjacent intent, **not measured search demand, reliable Google ranks, or endorsement of their technical claims**. This intake did not establish keyword volume or a locale-controlled Google results baseline. The connected keyword/SERP research provider reported an ended trial; no paid upgrade was initiated.

Live Google Search Console data for `sc-domain:vitaliioborskyi.ai`, retrieved through Windsor on 17 November:

| Finalized window (Google/PT dates) | Property impressions | Clicks | CTR |
| --- | ---: | ---: | ---: |
| 8–14 November | 10 | 1 | 10.0% |
| 1–7 November | 14 | 3 | 21.4% |
| 20 October–14 November | 65 | 7 | 10.8% |

Latest returned date: **14 November**. The query report disclosed only two query rows and no “AI code crisis” row. Query privacy/truncation prevents treating this as proof of zero searches or complete zero visibility. Article readers published on 16 November are outside this finalized observation window.

### Candidate work, to refine after discovery

1. **Map the actual query family and reader intent.** Start with `AI code crisis`, `AI-generated code crisis`, `subprime code crisis`, `AI code review bottleneck`, and `comprehension debt`. Treat them as related candidates, not interchangeable terms. Capture date, country, language, device, observed results, content types, and any AI/knowledge-panel features. Record volume source/limits or explicitly leave demand unknown.
2. **Choose the primary destination before writing.** Compare the existing [Research page](https://vitaliioborskyi.ai/research.html), [SDLC imbalance article](https://vitaliioborskyi.ai/articles/the-sdlc-is-out-of-balance.html), the planned `/subprime/` route under #116, and a genuinely useful new guide only if a distinct intent remains uncovered. Avoid several pages competing for the same answer.
3. **Connect public vocabulary to the author's contribution.** Give readers a concise explanation of the crisis, distinguish code quality from verification/review capacity, integration, operational comprehension, and ownership, and show where The Subprime Code Crisis adds a delivery-system explanation. Preserve evidence limits and counterexamples. Do not imply that every AI-assisted workflow degrades or claim ownership of the search phrase.
4. **Make the relationships explicit.** Use natural contextual links from Research, Writing and appropriate articles, including SDLC imbalance, Verification Crisis and Cost-Cutting Fallacy. Audit the existing title/description/H1, visible explanatory text, canonical, sitemap, and author/Article structured data; change only what the chosen intent requires. Visible statements and markup must agree. Existing source owners include `site/seo/query-map.json` and `site/content/pages/research/research.json`; verify current paths/contracts before editing.
5. **Prepare legitimate external connections.** Record possible contextually useful updates to author-owned research/distribution surfaces and relevant discussion opportunities. Preserve canonical and edition ownership. Any external editing, outreach, or publication is separate work requiring the applicable authorization; no artificial links or unsupported authority claims.
6. **Measure the result.** Record the chosen page and query-family baseline, inspect indexing through #8, and compare equal finalized 28-day windows after delivery. Report impressions, clicks, CTR, and average position with query/privacy limits. Observe AI citations/entity panels separately with dated, locale-specific evidence. Improvement is a target to evaluate, not a promised release gate.

## Acceptance criteria

These are proposed observable criteria for the future bounded implementation. All remain open at intake.

### AC01 — Search intent and baseline

- [ ] A dated query/intent matrix records terms, locale/language/device, observed result types, current author/site presence, and demand evidence or explicit unknowns. Reproduce the GSC baseline through the connected property; never substitute generic web-search ordering for an exact Google rank.
- Required gate: source-based requirements review before dependent implementation.

### AC02 — One primary destination and ownership

- [ ] Record the chosen canonical destination and why it satisfies the intent; map supporting pages and links. Reconcile #8, #11, #116 and #183, including whether an existing page suffices. Do not create an unapproved duplicate research hub.
- Required gate: resolve content/research ownership and any expansion beyond this bounded objective.

### AC03 — Useful content and accurate provenance

- [ ] The chosen page answers the query in visible readable prose, connects the author's delivery-system explanation to evidence and limits, and retains accurate authorship and original/platform/site dates. Check the approved source against the rendered page; preserve research acceptance boundaries.
- Required gate: independent editorial/source review and applicable author publication approval.

### AC04 — Discovery and technical integrity

- [ ] Verify the selected canonical URL, indexability, sitemap inclusion, natural internal links, metadata and applicable author/Article markup against visible content, including the mobile and no-JavaScript reader experience.
- Select current deterministic checks from the repository's maintained SEO/content profiles based on the actual diff; exact selectors must be recorded in the implementation PR.
- Code-style AC is not applicable to this issue-only intake. If implementation changes code/templates/styles/configuration, add the applicable CS rule IDs, bounded selectors and independent review before editing.

### AC05 — Verified delivery through existing routes

- [ ] Link the actual implementation PR/commits, independent review, exact-source checks and required PR Preview → Stable Staging → Production evidence. Observe the final live page and reconcile actual acceptance; green source checks alone are not publication or indexing evidence.
- Required gate: existing maintainer/release decisions and dependent owner gates.

### AC06 — Measurement handoff and outcome

- [ ] A reproducible post-release check records indexing status, the selected query/page metrics and a comparable finalized 28-day window when available. Separate technical completion from delayed search outcomes; retain an explicitly owned measurement follow-up if the observation window has not matured.
- Record actual outcomes, including no measurable improvement. Do not fabricate query volume, claim complete query visibility, or guarantee rank, AI citation, Knowledge Graph inclusion, or a knowledge panel.

## Plan and decisions

1. Validate opportunity and intent.
2. Select the canonical/content approach and reconcile owners.
3. Review requirements, then implement only the accepted bounded change.
4. Verify, release through existing gates, and record measurement.

Google's primary guidance:

- [AI features and your website](https://developers.google.com/search/docs/appearance/ai-features): normal SEO eligibility applies; no special AI schema or new AI text file is required; serving is not guaranteed.
- [Structured data introduction](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data): markup describes visible page content and entities.
- [Search Console data discrepancies](https://support.google.com/webmasters/answer/17010575?hl=en): query omissions, aggregation differences, processing delay and Pacific dates.

### Review / analysis / model handoff — 2026-11-17

Initial read-only discovery and issue intake completed. Opportunity demand, exact locale-controlled Google baseline, canonical choice, implementation scope and independent requirements review remain pending. No implementation, source policy, review receipt or check result is claimed by this issue creation.


## Current authorized checkpoint

The maintainer explicitly instructed continuation of the correction and delivery to Stable Staging only. The primary existing SDLC article and distinct companion/upstream research ownership remain. Protected merge, Production and external publication have separate decisions.

Current native source cf2ab301cc5b658e284f09a49d787d460e69f9bf; tree762417bdc874db8a2ac7337a9e8c081d8ae3446a; protected main3877546d29a04f235f9ec0f3175f4e0d90bfd60d. Read those actual sources. The current Research lens U002/T006 selects the native SDLC article with an explicit article label; upstream Research and Writing journeys and TOC background are separate links. No historic reviewer results or UI diagnoses are supplied here.

All six whole ACs remain open. This pass supplies bounded actual Preview interaction evidence, not full regression, physical-device acceptance, production or search outcomes.
