# Issue189 — 2026-11-10 architecture and execution plan

Owner: https://github.com/oborskyivitalii/oborskyivitalii/issues/189.
Scope of this checkpoint: investigation, proposed architecture, refined acceptance and implementation plan. No archival deletion, producer/config implementation, merge, staging or production activation.
Inspected main/production: ca756417590b9176f9fc33428321ffe1f64158cc. Open PRs171/117/110/107/79 were revalidated and remain outside this task.
Author explicitly selected keeping archives **inside this repository** during this investigation.

## Evidence and limits

README, root AGENTS (the only live AGENTS.md in the complete observed tree), CONTRIBUTING, MEMORY, generated map, RI contract/config/producer/catalog, coupling map/validator, navigation workflow, root-layout and relevant current/historical tests, and issue184's inventory/recovery index were inspected.

The local material is a **partial connector snapshot**, not a complete checkout. Code search returned no matches even for known present filenames, so it cannot establish consumer absence. Full consumer discovery, production eligibility for a new batch and binary extraction remain execution preflight gates. A Git transport probe could not authenticate; no archive bytes were obtained that way.

An initial prepared packet added a final LF to supplied native text files. The first Requirements report identified that distinction and accurately scoped its fixture run to prepared bytes. A separate native snapshot now verifies every supplied repository file against the observed Git blob SHA-1, correcting only that transport LF; original packet/result are preserved. Neither snapshot proves a full native RI run. The initial large-file contents response omitted the machine JSON bytes. A later blob-API retrieval succeeded: full native JSON1,764,356bytes, Git blob3f3b0efe98ec42e1a72f132f857161e3f75d5aa9, SHA256d951684629541c47ff7590d3da17f6382b26181a6e5cfa01ad2b2086b70c562e. It has2,674 artifacts/inputs,283directories, schema2 and root AGENTS only. Nine supplemental sources (JSON plus delivery/acceptance/test consumers) match native blob IDs. This narrows the access gap; absent archive binaries, full consumer audit and full-checkout verification remain unobserved.

## Current architecture and failure mechanism

1. scan() walks supported files, hashes all nonderived input bytes (including HTML/JS/assets/archives), decodes bounded text, and checks tracked exclusions/modes.
2. path_inventory() requires exact catalog coverage of files and ancestor directories, purposes, roles and existing editing owners.
3. build() constructs one complete projection with source identities, owner aliases, instructions, artifacts/directories and validation routes.
4. render_map() prints the entire inventory into REPOSITORY-MAP.md. JSON also retains the complete projection.
5. verify() rebuilds the source projection and compares parsed JSON plus map text. Every query/context command invokes this full verification first.
6. GitHub issues/refs/checks/deployments remain a separate live overlay; RI cannot establish current delivery or acceptance.

Thus there are two independent problems: excessive **default reading volume** and almost exhausted **physical hash-input capacity**. Shrinking the two existing derived outputs helps context size, but does not save bytes under the 250MB input cap. Faster lookup is not promised: the existing full verification remains in place; no cache is introduced in this task.

| Resource at inspected source | Measured/metadata value | Existing bound / headroom |
| --- | ---: | ---: |
| Tracked files | 2,674 | RI maximum5,000; actual scan also sees supported untracked files |
| Hash-input bytes (two derived outputs excluded) | 249,743,718 | 250,000,000 /256,282 spare |
| Parsed-suffix bytes (tree estimate) | 21,679,851 | 50,000,000 aggregate |
| Largest parsed file: tools/quality/secrets-reviewed.json | 1,999,782 | 2,000,000 /218 spare |
| Largest hash input: historical v6 ZIP | 11,726,610 | 32,000,000 per file |
| review/ | 194,194,215 | Part of complete input set |
| REPOSITORY-MAP.md | 865,848 | Derived output, not counted toward hash-input bytes |
| agent-context.json | 1,764,356 | Derived output, not counted toward hash-input bytes |
| repository-paths.json | 847,452 | Maintained input; counted |

Catalog has2,957 entries:2,010 history entries (files and directories). There are1,858 history-classified files totaling194,735,660bytes; role and review-directory totals differ and must not be conflated.

The near-full secrets ledger is a separate risk, not an archival candidate: its existing reviewed companion mechanism must be respected. Do not edit/recompress/omit that historical control to manufacture capacity. Report its margin and use its existing extension route for later additions.

## Proposed architecture: keep two outputs and one producer

Retain Git, Markdown, the canonical catalog and current RI CLI. No database, vector store, new service, generated shard tree, remote archive store or new persistent cache.

- **Authored owners:** repository-paths.json owns purposes/roles/editing ownership; repository-intelligence-config.json owns concern aliases, validation routes and continuity settings. Do not maintain a second parallel list of task history.
- **Complete projection:** keep agent-context.json at its existing path and preserve existing schema2 fields, source_identity.digest and full artifacts/directories/inputs. This remains the complete machine/navigation inventory and CI identity surface, not a file to paste wholesale into every chat.
- **Short entry:** change REPOSITORY-MAP.md from exhaustive dump to a deterministic current-repository entry, generated from those same owners. Include root entry routes, current areas/canonical owners, applicable instruction/check entrypoints, explicit current/history lookup recipes and direct-source fallback for connector-only agents. Proposed hard budget32,768 UTF-8 bytes. A rough concern/check rendering from current configuration is5,519bytes; that is feasibility evidence, not a finished map.
- **Scoped reads:** add optional current/history/all scope and exact prefix/file filtering to the existing CLI. The recommended map/agent route uses explicit current scope. Preserve legacy unqualified query/inventory behavior for compatibility; do not silently change existing API results. Current excludes history/draft/generated artifact roles but never filters the complete stored projection or freshness scan. Historical and generated paths remain explicitly accessible.
- **Bounded results:** opt-in scoped queries expose a stable page limit (proposed20 artifact/directory hits), returned/remaining counts, continuation position, verified source digest and explicit unresolved/fallback state. Never present a truncated list as complete. Prefix matching is path-component aware; exact file/directory requests retain all applicable instructions and check routes, including directory-only matches. Existing query result fields remain available; additive metadata is reviewed against real consumers. Paging applies only to artifact/directory hits ordered deterministically by (kind,path); complete applicable instruction/owner/check-route metadata must never be paged away. The20-hit count is explicitly only a list bound, not a total-response byte limit: measure complete broad-alias and normal-task responses separately; never drop applicable instruction/check metadata to force a byte target. Report a need to narrow or read direct sources where excessive. Continuation uses explicit offset plus a request fingerprint binding normalized query, scope, exact prefix, page size and verified source digest; reject reuse after any bound input changes. No persistent cursor service or cache is added.
- **Integrity:** keep full input hashing and all existing bounds. Canonical serialization verification for generated JSON/map will compare regenerated bytes; current JSON equality is semantic and does not detect whitespace-only edits. No recursive self-hashing or new derived-output family is needed.
- **Instruction safety:** live scoped instructions remain discovered and routed. Loose historical AGENTS.md must not become active because of its basename: reject contradictory history/draft classification for such a live-name file and require an inert archive name or compressed member. Do not silently let a role label suppress a live applicable instruction. The current tree has only root AGENTS.md; this is a negative-boundary requirement, not an observed incident.
- **Capacity visibility:** extend existing tooling with a small read-only capacity report if needed; report file count, aggregate hash/text, maxima and individual margins, output bytes and top contributors. A warning below10,000,000bytes aggregate headroom is advisory; the existing hard limits remain the only refusal thresholds. Reporting must work on an over-limit inventory sufficiently to explain the limit without accepting it as valid RI; do not hide missing/unsafe inputs.

The short entry does not select a current issue from filenames or timestamps. MEMORY remains the task pointer (#188); live GitHub remains operational authority.

## Archive design and bounded selection

Use issue184's existing unchanged ZIPs and truthful original-path locators. Its inventory is dated a9f5769 and must be revalidated, not imported as current approval.

Potential additional old-site files still exist at matching recorded sizes:
- v3:15files /694,937bytes;
- v4:15files /891,774bytes;
- v5:55files /8,925,958bytes;
- v6:55files /10,089,230bytes;
- v7:55files /9,490,434bytes.
Total195files /30,092,333bytes. Includes84PNG,60JPG,30HTML,15WebM,6JSON. These are **inspection candidates**, not newly verified duplicates, eligible deletions or net recoverable savings.

The33 former HTML originals replaced under184 already saved their bytes; do not count their4,199,222 original bytes again. Ten active-authored-site archive matches are excluded. Open PMDay/PR79, PR110, current publication sources, tests/fixtures, immutable editions, rights and rollback closure remain excluded unless their own actual consumers prove a different permitted treatment.

For each selected current-base path:
1. Establish original owner and actual production/supersession evidence.
2. Search actual maintained consumers by exact path and derived/relative references; classify historical-manifest-only uses separately from active execution/authoring. Inspect graph/catalog registrations, native links and script/fixture readers. A no-result search alone is insufficient.
3. Bind original base Git blob, SHA256/size, existing archive SHA256/member and extraction command. Retain unchanged historical manifests as descriptions of the archived original.
4. Extract to a temporary directory and compare original bytes before replacing/removing a loose file. Refuse missing, wrong-size/hash, duplicate/ambiguous or unsafe members where the recovery mechanism processes them.
5. Use a truthful locator appropriate to the original extension. Do not replace PNG/WebM bytes with an HTML file at that extension and call it the old media. Prefer adjacent Markdown recovery locator plus rewritten active navigation link; preserve historical exact-path evidence through the recovery index. Any direct historical media-link behavior change is explicit.
6. Compare frozen protected sets and unchanged archive blobs, then account for all new locators/catalog/report/review bytes.

User-selected target: **at least10,000,000 final hash-input bytes spare**; requires net recovery at least9,743,718bytes plus new input overhead. Candidates suggest feasibility but do not prove it. Select the smallest eligible batch meeting the complete final target. Do not clean all history or touch unresolved articles to chase a larger number.

First capacity checkpoint for planning: >=2,000,000bytes spare after the complete archive/checkpoint metadata, with remaining189 work allowance <=1,000,000bytes and at least1,000,000 reserve. Measure the allowance rather than assume it. This allows safe continuation of this task; #188/#187 mutations should normally start after189 delivery at the final10MB target, or require their own complete-candidate fit check. No intermediate green number authorizes merge/release or skips remaining ACs.

Because archives stay in-tree, this reduces redundancy and buys useful headroom; it cannot guarantee infinite future growth under a fixed bound. The standing post-production process plus capacity reporting makes the next limit visible. No new paid storage or archive service is introduced.

## Consumer and change map

| Surface | Retain / change | Checks / risk |
| --- | --- | --- |
| README, AGENTS, PROJECT-BOOTSTRAP | Same entry paths; route through short map and explicit scoped reads | root-layout/link/bootstrap tests; AGENTS100lines |
| tools/repository_intelligence.py/config | Same producer/complete JSON; short map + opt-in scope/prefix/pagination/capacity | existing RI permanent fixtures; compatibility and new boundary cases |
| Full JSON/source digest | Preserve schema/path/complete inventory; strengthen serialized-byte freshness | navigation.yml current-source receipt; no source_identity schema replacement |
| REPOSITORY-MAP consumer contract | Intentionally replace exhaustive listing with short entry; full path detail remains machine/CLI/catalog | Update RI architecture, catalog description and affected consumers/tests atomically |
| Coupling DERIVED set | Keep existing two outputs | check_ri_ci.py refresh/verify; no new output exclusion or self-reference |
| Catalog/root layout | Describe changed map purpose; classify new review/policy files, no new root file | path coverage, active Markdown links, root-layout |
| Historical issue31/33 snapshots | Preserve dated intent; select still-relevant methods through189 policy | Do not rerun or rewrite every old task snapshot as permanent current requirements |
| Archive locators/index | Extend bounded selection, exact originals recoverable | source-bound every-member recovery and protected closure comparison |
| Delivery selector/controller | Full actual diff determines lane | Existing184 HTML/policy delta required full route; do not assume repository-only eligibility |
| MEMORY | One task pointer only during handoff | Do not implement188's lifecycle/byte-cap policy in189 |

Full consumer audit remains T01. This table is a source-grounded starting map, not a completed search of the missing full checkout.

## Execution plan and stop points

| Step | Work | Output / stop condition |
| --- | --- | --- |
| T01 | Freeze current base/live owners, complete consumer/eligibility audit and requirements review | Exact selected/excluded paths, agreed interface/budgets, test-impact map; report before mutations |
| T02 | Recover the smallest safe archive slice using existing members and locators | Every-original recovery and protected-set comparison; measured first checkpoint; report actual net bytes |
| T03 | Generate short map and implement optional scoped/paged reads; preserve complete JSON and existing unqualified CLI/API | Deterministic entry and lookup journeys; compatibility/negative fixture checks |
| T04 | Add bounded capacity visibility and finish useful headroom target | Final full-candidate accounting includes all new metadata/evidence; margins for every current limit |
| T05 | Reconcile requirements/code/white-box/exploratory results and current-source policy/RI/CI/style checks | Four actual roles, corrected findings, source-bound evidence and truthful pending gates |
| T06 | Deliver separate Draft→trusted selected lane→maintainer decision; handoff to188 | Actual merged/effective identity and remaining exclusions; no website release claim from RI green |

Use one owning189 PR, with bounded coherent iterations. A separately delivered capacity slice is optional only if actual size/route constraints require it; it stays under189, not a new umbrella issue. Do not ask the maintainer to approve each routine file decision. Report after T01/T02 and T03/T04, then the review/delivery checkpoint.

## Refined acceptance contract (stable AC01–AC05)

### AC01 — Short current entry and scoped retrieval
- Short generated REPOSITORY-MAP <=32,768 UTF-8 bytes; no appended exhaustive history dump.
- Preserve existing full JSON and unqualified lookup compatibility; explicit current/history/all and prefix/file retrieval.
- Bounded scoped response reports limit/remaining/continuation/source digest. Current scope is role-based, not timestamp authority.
- Demonstrate EN/UA owner aliases already promised, exact file, directory-only, history retrieval, generated lookup, pagination and lexical miss. Check expected owners/instructions/check routes against canonical sources.
- Connector-only journey uses the short map/direct owners without downloading/pasting full JSON; no false local-verification claim.
Owner gate: accept proposed entry budget and intended presentation; independent lookup usability/compatibility review.

### AC02 — Full deterministic integrity and instruction safety
- Every supported tracked/nonderived input (plus supported untracked files per existing contract) remains cataloged and byte-hashed; no new exclusion, cap increase or recursive output hashing.
- Two derived outputs have deterministic regenerated-byte freshness; whitespace-only JSON mutation must be rejected. This is the single proposed output oracle, not an optional post-implementation choice.
- Current unknown/missing/unsafe paths, modes, source/producer/config mutation and stale/tampered/missing outputs fail.
- Live instruction scope is preserved; historical exact AGENTS.md cannot silently activate or suppress live instructions. Exercise this boundary, not only AGENTS.before.md.
- Full native build/verify, current real-repository tests, coupling and affected consumer checks pass on exact final source.
Owner gate: independent source/integrity review; fixture-only success is not full-checkout verification.

### AC03 — Eligible archive batch and lossless recovery
- Freeze selected current-base paths, owner/delivery/consumer dispositions and explicit exclusions.
- Every original has base identity/size/SHA256 plus archive/member/digest and practical recovery; compare every extracted original before replacement.
- Historical manifests/failures/first-review status and original archive bytes stay intact. New media locators do not masquerade as old bytes.
- Frozen protected closure of active/unfinished/public/fixture/rights/rollback resources is unchanged; any permitted index/link adjustment is listed.
Owner gate: evidence-based eligibility and actual every-member recovery; old inventory match is not approval.

### AC04 — Complete resource accounting and sustainable maintenance
- Before/after report separates hash-input saving, full tracked storage and derived-output/context reduction.
- Report file count, total hash/text, largest hash/text and margins, including the218-byte ledger risk.
- Final target >=10,000,000bytes aggregate headroom after all candidate/evidence inputs; first checkpoint >=2,000,000 with measured <=1,000,000 remaining allowance and >=1,000,000 reserve.
- Existing250MB/32MB/50MB/2MB/5000 caps unchanged. Under10MB advisory warnings do not create another hard CI gate.
- Archive-in-repo choice and existing post-production recovery process are retained; no infinite-growth guarantee or all-history completion claim.
Owner gate: the10,000,000-byte final target is user-selected. The first checkpoint/allowance is an internal planning proposal to validate by measurement; if safe eligibility cannot meet the target, return measured alternatives rather than weaken protections.

### AC05 — Style, allocation, review and real delivery
- Apply CS01/04/05/07/08/09/10 to actual producer/config/archive tooling; other IDs only as applicable. Bounded guard does not replace architectural review.
- Versioned owning policy maps stable criteria to named current checks and explicit eligibility/usability/recovery/review/merge gates.
- Update map/contract/catalog/RI/CI/test-selection companions together. Preserve historical task snapshots; use selected existing methods rather than blindly running all old issue tests.
- Test-impact review precedes expensive CI; raw first failures persist. Four actual role results and affected corrections are source-bound.
- Complete actual trusted lane and applicable maintainer decisions; record source/tested/merged/effective states distinctly. Refresh only the task handoff pointer.
No AC is passed by this planning checkpoint.

## Test design and allocation

Keep existing NavigationSafetyTests, RICICouplingTests, root-layout/style and selected current-catalog methods as foundations. Add a small cohesive behavioral group for scope/prefix/paging/byte-serialization/capacity, through existing permanent RI tests; do not introduce a separate service/pipeline or one string test per prose rule.

| Risk / case | Independent oracle | Planned route |
| --- | --- | --- |
| Compact entry hides owner | Chosen canonical source/instruction/check files, EN/UA aliases | RI source tests + actual operator journey |
| Scope mistakes / archived instructions | Explicit roles, boundary paths, current AGENTS + inert history; exact AGENTS refusal; preserve configured lexical validation-route family prefixes separately from path-component-aware user filters | RI fixture negatives |
| Directory-only lookup | Directory and descendant instructions/check owners | Scoped context regression |
| Partial page appears complete | Full fixture expected set; concatenate pages exactly; invalid bounds/source continuation rejected; reject changed query/scope/prefix/page interpretation and measure complete owner/route payload | RI fixture group |
| Whitespace or binary mutation | Exact regenerated serialization / SHA256 inputs | existing mutation tests extended; adapt materialize() from noncanonical json.dumps(data) to the production serializer atomically, retain an independent formatting-mutation oracle and an actual CLI build→verify round trip |
| Unsafe/missing archive member | Frozen original Git bytes, member digest/size and strict selected paths | actual recovery plus helper negatives if helper changes |
| Protected media/fixtures removed | Frozen protected-set Git blob inventory and consumer closure | actual base/candidate comparison |
| Capacity arithmetic double-counts derived views/old33 | Fixed independent fixture byte totals and current native scan | capacity regression + final exact-source report; exact hard-limit/limit+1, advisory threshold, explicit invalid over-limit report and unsafe/missing/unreadable-input cases must preserve build/verify refusal |
| Tests rewrite historical acceptance | Existing registry and owning policy selector | existing selection/coupling tests |
| Repository-only route assumed | Actual full-diff trusted selector result | native selected lane; do not bypass full route |

Requirements first preflight actually ran27 existing fixture tests with0failures/errors/skips on its prepared source packet; two full-repository cases were deliberately not selected. This is evidence about existing component behavior only. Final native tests, extraction, scoped prototype and implementation checks remain unexecuted. No performance, production or archive-recovery pass is claimed.

## Decisions and open gates

- **D01 resolved:** author selected in-repository archives. No GitHub Releases migration.
- **D02 resolved in part:** author selected10,000,000bytes minimum final aggregate reserve. The32,768byte short-map budget and2,000,000byte internal checkpoint/allowance are engineering proposals presented with this plan, not claimed as separately approved user choices.
- **D03 technical proposal:** preserve existing schema/path/unqualified lookup behavior; use explicit scoped agent route. No generated shards/cache in the first implementation.
- **D04 execution gate:** current native consumer audit and archive-member verification. Missing access is not evidence of absence or non-applicability.
- **D05 follow-up boundary:** near-full secrets ledger uses its current companion mechanism;189 reports margin, does not rewrite scanner history.

The user requested a concrete reviewable plan, not implementation in this turn. Present the remaining technical proposals and rationale; proceed to implementation only after the next instruction authorizes it and requirements gates are resolved. Planning artifacts and issue refinement are authorized in this turn.

