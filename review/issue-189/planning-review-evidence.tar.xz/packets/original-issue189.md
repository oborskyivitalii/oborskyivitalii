## Original intent — 10 November 2026

The maintainer wants repository intelligence to describe the current repository, with old revisions/evidence archived, and asks whether a different representation is needed.

Explicitly split from #187 at the maintainer's request. [Preserved combined intake](https://github.com/oborskyivitalii/oborskyivitalii/issues/187#issuecomment-6770665091). Transfers original **AC04–AC05** and the RI/archive-specific obligations of **AC06**. Stable local ACs below retain those outcomes. #188 owns MEMORY; #187 owns reusable article motion.

## Verified baseline

Inspected main ca756417590b9176f9fc33428321ffe1f64158cc, unchanged at split time. Revalidate before implementation.

- The architecture contract .github/REPOSITORY-INTELLIGENCE.md is 19,611 bytes, not a commit diary.
- REPOSITORY-MAP.md: 865,848 bytes; generated agent-context.json: 1,764,356 bytes; maintained path catalog: 847,452 bytes.
- Complete Git tree: 2,674 tracked files / 252,373,922 bytes. Excluding two derived RI outputs gives **249,743,718 bytes**, matching the reported hash-input total. Only **256,282 bytes** remain under the existing **250,000,000-byte** input cap.
- review/ contains 194,194,215 bytes. Old Git commits do not count toward the working-tree scan. Moving or rewriting Git history cannot fix this capacity problem. Archives still in the tree also count.
- These measurements come from GitHub tree/source inspection and #184's delivery record; no fresh local RI execution is claimed.

[#184](https://github.com/oborskyivitalii/oborskyivitalii/issues/184) completed a 33-path lossless archival batch and standing post-production process, integrated in PR186 / prod-2026-11-10.1. Reuse its inventory, archive index, exclusions and recovery mechanism. Remaining inventory is not automatically eligible for deletion. This issue is a subsequent bounded maintenance owner.

## Recommendation and scope

Retain Git, Markdown and the existing deterministic RI/query CLI. Existing evidence does not justify a database, vector store, paid service or replacement indexing platform.

Separate default navigation from complete integrity coverage:
1. A compact generated entry describes current areas, canonical owners, scoped instructions and checks. Proposed budget **32 KiB**, reviewed against actual consumers.
2. Existing query/context/scoped indexes provide detailed per-path information. History is explicitly retrievable and labeled without dominating default context.
3. Full tracked-path inventory, ownership and exact-byte verification remain intact, including archives. Archived AGENTS text must not become current instructions.

Inspect consumers before choosing the smallest compatible layout for REPOSITORY-MAP and agent-context. No hand-edited generated snapshot or duplicate maintained prose index.

Recover capacity through bounded eligible batches: reuse exact existing archives first; create a new lossless archive only when necessary. Verify member paths, byte sizes/SHA256 and extraction before replacing/removing loose originals. Keep truthful original-path recovery locators. Preserve first failed/reviewer observations and their actual status.

Protect active authoring, unfinished PR work, executable fixtures, public immutable editions, rights and rollback resources. Do not treat closed issues/merged PRs alone as production eligibility. Do not silently raise limits, omit tracked inputs, rewrite history, purge a host or add another release pipeline.

Measure hash inputs, parsed text, derived-output sizes, file count and remaining capacity separately. Proposed useful headroom target: **10 MB** under the current 250MB cap, subject to inventory/eligibility evidence. This is a recommendation, not an accepted numeric requirement. If protected inputs prevent it, present measured alternatives for an explicit decision rather than weaken integrity. Prefer a small capacity report/warning in existing tooling if it prevents recurrence.

Owners: tools/repository_intelligence.py, .github/repository-intelligence-config.json, .github/repository-paths.json, .github/REPOSITORY-INTELLIGENCE.md, REPOSITORY-MAP.md, .github/repository-intelligence/agent-context.json, .github/ri-ci-map.json, tools/check_ri_ci.py, existing RI/CI tests and #184's archive consumers. Read common repository instructions and applicable source contracts first.

## Acceptance criteria

### AC01 — Compact current entry and scoped lookup
- [ ] A reviewed bounded generated entry routes current tasks to canonical source/instruction/check owners; detailed/current/history lookups are usable through scoped routes. Default context does not dump the entire historical inventory. Record actual entry/map/JSON sizes and resolve the proposed 32 KiB budget before implementation.
Checks: actual query/context/owner journeys, relevant existing consumer and RI regression tests.
External gate: independent requirements/usability/backward-compatibility review.

### AC02 — Complete deterministic inventory and integrity
- [ ] All tracked paths remain cataloged and exact-byte checked. Scope/instruction ownership is preserved; history cannot act as current instructions. Build/verify/query remain deterministic; missing/stale/tampered outputs, unknown paths and unsafe inputs fail visibly. Existing limits are unchanged.
Checks: RI build/verify and affected tests/test_repository_intelligence.py behavior/negative tests, full catalog and RI/CI coupling.
External gate: independent source/architecture review; compact context is not permission to omit integrity inputs.

### AC03 — Eligible archive inventory and exact recovery
- [ ] Every archived/replaced original has an evidenced owner, consumers, eligibility, original size/SHA256 and accessible archive/member/locator. Extracted bytes match before loose copies are removed. Current sources, unfinished work, fixtures, immutable public/rights/rollback closure and historical failures remain usable with their true status.
Checks: exact original/archive extraction comparisons, actual locator/recovery journeys, affected consumer/retention checks; meaningful missing/mismatched-member negatives for any changed helper.
External gate: independent eligibility and protected-resource review. Reuse #184's existing mechanism.

### AC04 — Measured useful capacity and maintenance
- [ ] Record complete-candidate before/after input/output/count/headroom measurements. Recover the accepted useful headroom under the unchanged cap; resolve the proposed 10 MB target from the inventory. Existing standing post-production archival process is followed, not duplicated. Navigation compaction and physical storage savings are reported separately.
Checks: full current-source RI verification and exact capacity/recovery accounting.
External gate: evidence-based target/scope decision if protected inputs prevent the proposed budget.

### AC05 — Reviewed exact-source delivery
- [ ] Map applicable CODE-STYLE IDs before code/config edits; run the bounded guard plus meaningful affected checks and review unautomated rules. Update catalog/acceptance/RI/CI consumers and allocation; record four independent roles and correction reviews on exact candidates. Use the trusted delivery lane selected for the complete diff. Record merged/delivered identity, remaining exclusions and owner handoff; do not claim archive completeness beyond this accepted batch.
Checks: affected RI/CI/style/owning tests, generation/freshness/recovery checks and actual selected CI route.
External gates: four source-bound role results and applicable maintainer merge/release decision.

## Execution sequence and dependencies

**First of the three tasks**, ahead of MEMORY #188 and article pulse #187:
1. Revalidate refs, scope/consumers and production/supersession evidence; requirements review.
2. Recover minimum safe headroom in a bounded batch first, so dependent work does not hit the existing cap.
3. Implement compact entry/scoped detail using the same producer and complete inventory; measure the full candidate and accepted capacity target.
4. Review test impact before expensive execution, run affected checks/recovery and four-role reviews; deliver through the actual selected route.
5. Pass the current canonical navigation/config and concise source-bound handoff to #188.

This is an operational capacity ordering, not a claim that MEMORY or animation logically requires an RI redesign. Do not delay them for optional all-history cleanup. A first capacity checkpoint may allow safe parallel preparation; mutations to shared controls remain sequential. Keep separate issue/PR acceptance and refs. No article motion or substantive MEMORY lifecycle rewrite in this scope.

## Status

Intake/split only. No implementation, test run, merge or deployment. All ACs pending.

