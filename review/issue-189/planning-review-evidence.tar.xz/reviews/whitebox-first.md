# Issue189 — independent White-box QA first judgment

Date: 2026-11-10. Reviewer task: `/root/issue189_whitebox_plan`. Phase: first independent review, planning only. No current peer output, parent notes, private history or unrelated memory was inspected. No implementation, accepted-source/test change, external write or delegation was performed. The orchestrator must retain the actual launch parameters/accepted handle; this report cannot attest provider context/model internals.

## Verdict

The proposed separation of compact navigation from complete byte integrity is structurally sound for a planning checkpoint. The capacity arithmetic and bounded candidate inventory reproduce from supplied metadata. No blocker to presenting the architecture and proposed budgets to the owner was found. This is not implementation acceptance: AC01–AC05 remain pending, and the native consumer audit, real archive recovery, exact-source checks and trusted delivery are genuine prerequisites.

After the frozen candidate was supplied, the orchestrator conveyed the user's explicit selection of the final minimum **10,000,000 bytes** headroom. Treat that number as the new owner decision when updating the candidate; the map budget and first-checkpoint parameters remain proposals. This decision does not establish eligibility, recoverability or achievement of that target.

One acceptance ambiguity should be resolved before implementation; two test-allocation refinements are recommended below. Proposed scoped/paged/capacity functionality does not exist in the inspected producer and has not been executed.

## Inputs and identities

- Base reference supplied: `ca756417590b9176f9fc33428321ffe1f64158cc`.
- Packet SHA256: `f1e180f8c890219202e2269c5d76d6ae5e3074ec84ccc44210050120a18958d0`.
- Candidate `issue189-plan/2026-11-10-analysis.md` SHA256: `14037509dec64e6dc760152bcaf343d0ce7782aab120718679d3385558d0273e`.
- Native-subset manifest SHA256: `4ad55a8e62244cce0f568b342620a8387abab8ad1ae12c4192135b41b18b7ce6`. All 37 entries independently matched supplied sizes/SHA256; that verifies packet bytes, not a full checkout.
- Common prompt SHA256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- White-box prompt SHA256: `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.

Inspected primary material: original intake/user-intent; README, AGENTS, CONTRIBUTING; generated map ownership routes; RI architecture, native producer/config/catalog, coupling producer/map and navigation workflow; relevant permanent RI, coupling, root-layout and selection tests; selected issue31/33 historical methods; issue184 archive narrative, policy, inventory and recovery index. No archive ZIP/member bytes were available.

After the frozen packet was supplied, the orchestrator supplied additional primary source access in `issue189-supplemental`. Its nine files independently matched Git blob IDs in the observed base tree: full agent-context JSON, site-checks workflow, issue_acceptance and repository-test runner, delivery routing/admission/observation, and two related tests. Relevant JSON, routing, runner, workflow and acceptance identity code were inspected. The additional test files were byte-identified, not run or comprehensively reviewed. These additions do not alter the first packet identity and are explicitly additional evidence.

The now-accessible JSON has schema2, 2,674 artifacts/inputs, 283 directories, source digest `313a0bacaf9d61745833fc24b8ac1e30983a29d2ce62925531cab930609c4ed8`; only root AGENTS is discovered. Candidate evidence-limit prose saying that JSON remains unavailable is stale after this supplement and should be refreshed. Reading that JSON does not verify freshness against the incomplete local tree.

## Findings and treatments

### WQ01 — P2: serialized-byte acceptance is conditional inside an otherwise definite contract

Location: candidate line128; compare architecture line52 and AC02's first clause at line128. It promises deterministic regenerated-byte freshness but qualifies whitespace rejection with “if this promised strengthening is implemented.” The current `verify()` (`tools/repository_intelligence.py:468–479`) parses JSON and compares values, so formatting-only changes pass. I reproduced that behavior using the existing temporary fixture.

Failure mechanism: the implementation could retain semantic comparison and cite the conditional clause while another reviewer expects exact bytes. That leaves the same AC with two different pass oracles. Affected criterion: AC02. Treatment: select one explicit contract before dependent code changes. The architecture's stated recommendation is byte equality; if retained, make whitespace rejection unconditional and test the production serialization. This does not invalidate the rest of the plan.

### WQ02 — P3: name the existing fixture serialization adaptation

Location: candidate test allocation lines159/167; existing `tests/test_repository_intelligence.py:93–98` writes `json.dumps(data)` in `materialize()`, while CLI build writes indented UTF-8 JSON plus LF. Strengthened byte verification would reject most otherwise valid fixture outputs unless the fixture writer is adjusted atomically. The present plan broadly says affected tests change together, but does not identify this dependency.

Affected criterion: AC02/AC05. Treatment: explicitly allocate the fixture materializer update to the producer serialization change, keep independently expected byte/mutation oracles, and exercise a real CLI build→verify round trip as well as unit fixtures. Reusing the production formatter for fixture setup is reasonable; expected whitespace rejection must still be tested independently. Do not weaken verification to preserve old fixture formatting.

### WQ03 — P3: capacity allocation should exercise its new refusal/reporting split

Location: candidate line54 and capacity test row170. Existing `scan()` fails at a limit breach before returning an inventory. A report capable of explaining over-limit inputs while leaving RI invalid adds a distinct path. The current row covers arithmetic/double counting but does not state that path's oracle.

Affected criterion: AC04 and AC02's preserved refusal boundary. Treatment: add cases for exact hard limit versus limit+1, advisory boundary, over-limit reporting with an explicit invalid status, and unsafe/missing/unreadable inputs. Reported numbers must not make build/verify/query admissible. This fits the proposed existing RI fixture group; no new pipeline is needed.

## Structural assessment and risk-to-check allocation

The existing flow is `scan → catalog/instruction validation → complete projection → render`, then `verify → lookup → context routing`. Scope/prefix/page filtering belongs after complete verification. A scoped result must never supply the input set for hashing or hide unknown catalog paths. Directory-only requests currently need special attention because context route collection uses owner/artifact paths and does not consume matching directory records.

All cases below are proposed unless explicitly called executed in the next section.

| Risk / AC | Structural fault and scenario | Independent oracle | Existing/proposed check and actual owner route |
| --- | --- | --- | --- |
| Compact entry loses source owner / AC01 | Current map truncates away an essential owner, bilingual alias or fallback | Frozen representative journeys chosen from canonical owner/config/instruction/check files, not from rendered output | Extend `NavigationSafetyTests`; real connector/direct-source usability journey retained under issue189 manual gate. `navigation.yml` job `navigation`, `ri-regressions` mapping |
| Scope leaks or hides paths / AC01–02 | Current/history/all filters affect complete inventory; mixed-role directory; role change on exact AGENTS | Fixture's complete explicit path/role set; digest unchanged by retrieval options; live root/nested instructions always applicable | Proposed RI fixture group; keep existing full inventory, unsafe path, catalog and history tests. Exact history/draft AGENTS must refuse; inert `AGENTS.before.md` stays searchable |
| File/prefix/directory ambiguity / AC01 | `a/b` also matches `a/bad`; directory-only hit omits applicable routes; exact file mistaken for prefix | Component-aware path set and canonical instruction/route closure, with root and nested scopes | Proposed RI component and CLI cases, including empty/missing/unsafe prefix and directory with no direct artifact hit; existing permanent RI route |
| Pagination silently loses evidence / AC01 | Split artifacts/directories produce duplicates/gaps or misleading remaining count; source mutates between pages | Full independently specified fixture set; deterministic ordering; concatenated pages equal set/order exactly; cursor bound to source and query/scope/prefix | Proposed RI group: 0/1/limit/limit+1 hits, last/empty page, invalid/negative/oversize limit, malformed/stale/cross-query continuation, unresolved miss; define whether limit is shared across hit kinds |
| Legacy callers regress / AC01/05 | New defaults or result shape silently change unqualified query/inventory | Existing alias/status/result expectations and real maintained consumer parsing | Retain existing permanent tests and explicit old command/API comparisons; full consumer audit T01 remains open. Full JSON remains schema/path complete |
| Output and source integrity / AC02 | Semantically equal JSON bytes accepted, derived view self-hashed, binary/config/producer edit ignored | Exact production serialization and fixed independent original bytes/SHA256 | Existing mutation and unsafe-input tests extended; fixture adaptation WQ02; current full native build/verify and source receipt later. `navigation` `ri-regressions` + `ri-freshness` |
| Capacity bypass / AC02/04 | Reporter uses filtered view, counts outputs/old33 twice, rounds limits, accepts invalid RI | Independent sum of known fixture file bytes; fixed production bounds; separately counted derived bytes and tracked storage | Proposed capacity group plus exact-source final scan/report; WQ03. Low-threshold fixtures can avoid allocating hundreds of MB; at least actual repository measurement remains required |
| Archive replacement loses bytes / AC03 | Wrong/missing/duplicate/unsafe member, wrong archive identity, truncation or command points elsewhere | Frozen base Git bytes, original SHA256/size, unchanged archive blob, exact extracted bytes | Every selected original's practical extraction/locator journey, retained under issue189 ARCHIVE gate. Changed reusable helper gets small meaningful negative fixtures and an explicit permanent registry/selection owner; unchanged helper need not receive duplicate tests |
| Eligibility/protected closure / AC03 | Inventory from old base treated as approval; active media/fixtures/public/rights/rollback path removed; relative consumers missed | Actual original owner/delivery evidence and frozen protected Git-blob closure, with listed permitted navigation edits | T01 consumer/eligibility audit and T02 full base/candidate comparison; independent eligibility gate. Historical index matches are candidate metadata only |
| Coupling or trusted selection missed / AC05 | New controls unregistered; derived set changed; owning test never selected; archive media classified repository-only | Maintained map, workflow invocation and full base/head diff, not filename intuition | Existing `RICICouplingTests`, repository selection tests, root-layout/style checks; selected issue189 policy. `navigation` mapping is explicit; site-checks technical lane runs `run_repository_tests.py`. Full actual selector remains authoritative |

The allocation is feasible within existing permanent RI/coupling suites and the current issue-policy/manual gate mechanism. The existing selector deliberately excludes exact numeric task snapshots from the permanent module set; selecting current catalog verification from issue31 is possible, but whole issue31/33 snapshots should not be made permanent. Native delivery routing confirms controls and unmatched historical media can force the full route; no repository-only shortcut follows from an unchanged public site.

`guides/SITE-CHECK-PROFILES.md`, full `test-profiles.json`, several source-selector companions and complete current consumers are absent from this supplied subset. Their final registry/profile dispositions cannot be verified here. The plan correctly places consumer/selection reconciliation before implementation advancement; the matrix above names existing verified routes where available and explicit manual/deferred owners elsewhere.

## Executed checks and exact results

No existing suite was replayed merely to duplicate the prior 27-case component run. I executed three bounded read-only diagnostic scripts via `python3 - <<'PY'` from the native subset; each command exited0, no signal, and produced complete output. They are diagnostics, not measured test/branch coverage or acceptance campaigns.

1. Packet hashes plus two temporary fixture probes and observed-tree accounting. The script loaded `exact-packet-manifest.json`, compared all path sizes/SHA256, printed packet/candidate/prompt hashes, imported the existing `NavigationSafetyTests` fixture, and called its temporary setup/cleanup. Probe A materialized a valid fixture, rewrote JSON with `json.dumps(data, indent=7) + '\n\n'`, then called `ri.verify`. Probe B added `archive/AGENTS.md` and `archive/item.md`, marked both history in the catalog, and called `ri.build`. It then summed observed Git-tree blob sizes excluding only the two existing derived outputs.

```text
packet entries 37 mismatches []
diagnostic existing semantic JSON verification accepts formatting-only mutation: True
diagnostic exact history AGENTS discovered: True
diagnostic history descendant instruction route: ['AGENTS.md', 'archive/AGENTS.md']
observed tree truncated: False files: 2674 tracked_bytes: 252373922 nonderived_bytes: 249743718
remaining hash bytes: 256282
```

The AGENTS probe demonstrates the proposed guard's fault model, not a current repository incident: native full JSON and tree contain no historical exact AGENTS. Both probes exhibit existing behavior the plan proposes to strengthen; they are not failures of implemented new code.

2. Supplemental source byte identity and JSON inventory. For every supplied supplemental file, computed native Git blob identity with `sha1(b'blob ' + str(len(bytes)).encode() + b'\0' + bytes)` and compared to the observed base tree. All9 matched. JSON output: schema2; 2674 artifacts; 283 directories; 2674 inputs; digest as recorded above; history AGENTS `[]`; instructions `[{'path': 'AGENTS.md', 'scope_root': '.'}]`.

3. Candidate inventory accounting. Loaded issue184 `existingArchiveMatches`; retained `other-legacy-site-evidence`, excluded all33 selected index paths and required the observed current tree size to equal each old record. Output:

```text
candidate count 195 bytes 30092333 suffixes {'.html': 30, '.json': 6, '.jpg': 60, '.png': 84, '.webm': 15}
matched metadata only; no original or ZIP-byte verification
```

Thus the stated 9,743,718-byte required net recovery before new overhead follows independently from 10,000,000 minus 256,282. No candidate eligibility, decoded archive identity or recoverable net saving follows from size matches. The proposed first checkpoint arithmetic is coherent only with a measured remaining allowance and full metadata overhead; an intermediate under-cap number alone cannot satisfy final AC04.

## Uncovered scope and disposition

No full checkout, full native build/verify, measured coverage, scoped prototype, final budget check, archive extraction, real operator/browser journey, hosted workflow, merge or delivery was executed. Archive binaries and most consumers remain unavailable. Partial source inspection cannot prove absence of consumers. Existing source bounds on per-file text/hash, aggregate text/hash and file count must remain independently enforced even if aggregate headroom improves. No performance improvement is established because full verification still occurs before lookup.

Retain this first report unchanged. Resolve WQ01 and update the now-stale JSON access statement; incorporate the WQ02/WQ03 allocation refinements before implementation. Later changed-source review should use a versioned delta and retain these diagnostics as observations of the unchanged baseline only.
