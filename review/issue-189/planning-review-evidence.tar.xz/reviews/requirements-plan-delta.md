# Issue189 — Requirements & Acceptance planning delta

Date: 2026-11-10. Reviewer/execution: `/root/issue189_requirements`, continuation of the same nonauthor Requirements role. This is a delta review, not a fresh-context first judgment. The original `requirements-first.md` remains unchanged (SHA256 `bcf53d5ad6a36a17ac5caa32bfb5b430ba223ac893e68152971069b2c7032c30`). No current peer judgment or author conversation was supplied/read. Later inputs comprise the planning candidate, native source normalization and newly accessible primary sources. Provider-internal history injection remains unknown; no OS/provider isolation claim is made.

## Inspected identity and verdict

- Review packet: `issue189-plan/review-packet.json`, SHA256 `f1e180f8c890219202e2269c5d76d6ae5e3074ec84ccc44210050120a18958d0`.
- Actual candidate path named by that packet: `issue189-plan/2026-11-10-analysis.md`, 22,773 bytes, SHA256 `14037509dec64e6dc760152bcaf343d0ce7782aab120718679d3385558d0273e`. The follow-up message's `candidate2026-11-10-analysis.md` filename does not exist; I used the packet's accessible path and verified the exact expected digest.
- Native packet: `issue189-native/exact-packet-manifest.json`, SHA256 `4ad55a8e62244cce0f568b342620a8387abab8ad1ae12c4192135b41b18b7ce6`.

All stated packet/candidate digests match. All 37 native-manifest entries match their listed bytes/SHA256. All 33 entries declared native independently reproduce their observed Git blob IDs at `ca756417590b9176f9fc33428321ffe1f64158cc`. Those 33 sources are exactly the previously inspected text with its final transport LF removed; their substantive source logic is unchanged. Thus the previous source analysis can be reused, but the prior fixture run is still accurately recorded as executed on its original prepared bytes, not relabeled as a native execution.

**Verdict: the candidate is a substantially complete, reviewable proposal for owner discussion.** It has addressed most first-report defects by defining proposed interfaces, numeric targets, test oracles and explicit execution gates, without pretending those proposals are accepted requirements or that missing recovery/consumer work has passed. It is not implementation acceptance. One residual acceptance-oracle ambiguity should be resolved before implementation; two narrower planning/evidence clarifications should be corrected before presenting the plan as a fully current record.

The user-selected in-repository archive location is accepted input to this review through the supplied decision packet/task. No archive migration decision needs asking again. Numeric targets and changed default presentation remain proposals.

## Disposition of earlier findings

| First-report finding | Delta inspection / disposition | What remains |
| --- | --- | --- |
| R1 — undefined entry/scope/budget/journeys | Candidate lines49–51,118–124 fix the proposed map path, byte budget, opt-in scope, legacy behavior and concrete lookup journeys. Substantially addressed as a proposal. | Owner acceptance of default presentation/budget; clarify the bounded-result claim in D3 below; actual journeys remain future checks. |
| R2 — consumer/compatibility audit | Lines48–54,86–101 retain the existing full machine schema/path/digest and two derived views, avoid shard/self-hash expansion, and make complete audit T01. This is a defensible initial design, not an executed compatibility proof. | Newly accessible full JSON removes that specific access gap (D2); full current native consumer inventory and actual diff routing still remain execution gates. |
| R3 — no newly eligible archive batch | Lines60–78,134–139 explicitly separate 195 inspection candidates from eligible savings, exclude the old33/active matches and require every-original extraction plus protected closure. Addressed at planning level. | No candidate original/archive recovery or newly approved path set has been observed; T01/T02 remain blocked on those inputs, correctly. |
| R4 — unassessable capacity/checkpoint | Lines80–82,141–147 define exact final/checkpoint bytes and allowance/reserve, include evidence overhead and retain measured alternatives. Addressed as an unaccepted proposal. | Owner decision and actual allowance/eligible-savings measurement. The 1 MB allowance is a proposed ceiling to demonstrate, not an observed cost. |
| R5 — aggregate-only capacity envelope | Lines29–41,54,143 retain all limits, show individual margins and protect the ledger/companion route. Addressed in the plan. | Actual complete-candidate measurements; no scanner/ledger rewrite authorized. |
| R6 — derived exact-byte oracle | Lines52,92,128 make stronger serialized-byte checking a proposed direction, but AC02 remains conditional internally. Partially addressed; D1 below remains. | One coherent accepted oracle before implementation/test design. |
| R7 — exact historical AGENTS basename | Lines53,130,164 explicitly require a negative boundary and reject contradictory historical/draft live-name classification. Addressed as a proposed invariant. | Live scoped-instruction compatibility and actual adversarial cases; no existing historical incident is claimed. |
| R8 — allocation/historical snapshots/delivery | Lines96,149–174 preserve snapshots, use selected methods, retain current permanent checks, four roles and exact-source delivery distinctions. Addressed in the plan. | Named issue189 policy/selector allocation and actual current-source reviews/CI/delivery when implementation is authorized. |

## Remaining delta findings

### D1 — P1 before implementation: AC02 gives two different freshness oracles

Location: candidate line128 (AC02): “Two derived outputs have deterministic regenerated-byte freshness; whitespace-only JSON mutation is rejected **if this promised strengthening is implemented**.” Architecture line52 says serialization checking “should” compare regenerated bytes; consumer map line92 and test-design line167 otherwise plan stronger byte freshness.

Mechanism/AC impact: regenerated-byte freshness entails rejecting serialized-byte changes, including whitespace. The conditional clause would allow deciding after implementation whether the rejection is required, precisely when tests should already have an independent oracle. All of this can remain a proposal pending plan acceptance, but the proposal itself should not admit mutually inconsistent pass conditions.

Treatment: choose a single proposed generated-output guarantee and its rejection oracle before dependent implementation; if owner plan acceptance adopts serialized-byte freshness, treat that obligation consistently throughout architecture/AC/test allocation. This does not require an extra permission question about routine serialization details. It must not relax exact nonderived/archive byte hashing. No code/test change or candidate fix was authored by this reviewer.

### D2 — P2 current-record correction: the full JSON access statement is stale

Location: candidate evidence/limits line15 says machine JSON “remains an explicit missing full-source input.” Since freezing this candidate, the full native file became accessible at `issue189-supplemental/.github/repository-intelligence/agent-context.json`.

Actual observation: 1,764,356 bytes, SHA256 `d951684629541c47ff7590d3da17f6382b26181a6e5cfa01ad2b2086b70c562e`, independently matching the observed native Git blob. Parsed schema2 has 2,674 artifacts, 283 directories and 2,674 source-identity records, two derived records, root AGENTS as the only instruction, and source digest `313a0bacaf9d61745833fc24b8ac1e30983a29d2ce62925531cab930609c4ed8`. Its actual top-level fields agree with the plan's complete-projection preservation direction. This inspection is neither rebuild/verify nor proof that all stored source hashes are current.

Treatment: distinguish the historical failed large-file contents response from now-successful access, record the new source identity and narrow the remaining missing-source limits. Preserve the full consumer/eligibility/binary/native-checkout gate; retrieving this JSON does not supply the absent archives or complete checkout. This factual update affects the source-access claim and known machine interface, not the already recorded first fixture result.

### D3 — P2 before implementation: “bounded scoped response” currently defines only artifact/directory count

Location: proposed architecture line51, AC01 line121, test table line166. Proposed20-hit paging explicitly covers artifact/directory hits, while existing responses also carry owner candidates, instructions, terms/sources and potentially large validation routes.

Mechanism/AC impact: paging artifacts/directories can be correct while a scoped context still emits a large owner/route payload. The user problem is excessive default reading volume. A fixed artifact count is an assessable list bound, but does not alone prove a bounded total context response. Conversely, paging away mandatory instruction/check routes could undermine scope safety.

Treatment: specify which collections are paged and which must remain complete, and describe the intended context-size observation honestly. Include a broad-alias/many-route case in test-impact design and measure a real default scoped journey. A separate total-response byte cap is a possible engineering proposal, not an inferred user requirement; neither 20 hits nor 32 KiB for the map should silently become such a cap. The continuation oracle should be bound to the same query/scope/filter and verified source so a position from another result set cannot masquerade as complete retrieval. These are technical contract details, not a new owner questionnaire unless they require dropping promised information or breaking compatibility.

## Additional primary-source checks and limits

The newly supplied routing sources confirm that actual complete-diff selection matters: `delivery-routing.cjs` maps existing RI views/config to D02 and producer to D03, while `technicalSelection` has narrowly enumerated support and rejects unsupported controls/deletions. `site-checks.yml:90–143` selects through the protected-base classifier and retains Python/security/advisory work for technical repository cases. The plan correctly does not predetermine the final lane from the phrase “repository maintenance.” I did not execute an admission selector or accept a lane for the unimplemented diff.

`run_repository_tests.py` confirms numeric task modules are excluded from the enduring module selector; `issue_acceptance.py` confirms exact-source/clean checks and manually pending gates. This strengthens the source basis for the plan's selected-method/historical-snapshot distinction. It does not select an issue189 policy that has not yet been authored.

All nine newly supplied supplemental files independently matched their observed native blob IDs. Recorded SHA256 identities:

| Path under `issue189-supplemental/` | SHA256 |
| --- | --- |
| `.github/repository-intelligence/agent-context.json` | `d951684629541c47ff7590d3da17f6382b26181a6e5cfa01ad2b2086b70c562e` |
| `.github/workflows/site-checks.yml` | `79b271f62d4d936118fe8da1c144ae8646fb857ccc418ce2ea0246b92ef8d5b7` |
| `tools/quality/delivery-routing.cjs` | `8fa772ba0837d7f8acf4a7df5b54615778e0107da01de43a389c3344269bcaa9` |
| `tools/quality/delivery-admission.cjs` | `2394bf4830590602ca53f8c32adaa206f40a5e267943664e5afd843c0459e316` |
| `tools/quality/delivery-observation.cjs` | `9bb43a511a87f3ce3b14388b76c11d0e1d2b27265720732a92a21c7200d3f6ba` |
| `tools/run_repository_tests.py` | `389d90fd8fd02a4587e3cf3c5543ffe00cde1caee8614e88a262d72dbb12924d` |
| `tools/issue_acceptance.py` | `c4d98db96844f19d73e4f66d389d3c54b5f0eead60029395d77d970c18950a97` |
| `tests/delivery-admission.test.cjs` | `9cf8d520ad1127ee625a040d3c37fd3a2875f99e641a66a0df97fbbec6d5468e` |
| `tests/test_issue_acceptance.py` | `51b509df5b1bb8838d85c1c25ee1c07e5323d7cf882ae2b1bbe8846709f3bd8d` |

Hash/parse observations and targeted source reading are the new checks. No implementation, fixture rerun, complete native RI/coupling/layout/CI campaign or archive extraction was performed for this delta. The first report's 27 passing fixture tests are reused only as their original limited observation because source logic is unchanged; they do not test the planned scope/paging/capacity behavior.

## Remaining owner decisions versus execution gates

| Item | Status |
| --- | --- |
| Keep archives in this repository | Resolved user decision supplied; do not reopen. |
| Make the fixed map path the short default while retaining complete JSON and legacy unqualified CLI | Concrete technical proposal, intentionally changes the existing readable-map contract; present its compatibility rationale for plan acceptance. |
| 32,768-byte entry, 10,000,000-byte final headroom, 2,000,000-byte first checkpoint/allowance/reserve | Explicit proposed parameters; need owner acceptance or revision. Candidate evidence does not prove eligibility or observed growth costs. |
| 20-hit default and exact paging/filter details | Proposed technical contract to complete under AC01; not accepted user preference or a reason to ask about each routine parameter. |
| New batch selection, protected-set closure, archive member identity/recovery and actual final fit | Unexecuted T01/T02 gates, not decisions supplied by duplicate filenames or closed issues. |
| If safe eligible savings miss an accepted target | Return measured concrete alternatives; no blanket exemption requested now. |
| Implementation/merge/release | Not authorized by current analysis request or this review; existing later authorization and gates remain. |

The next review need only recheck the affected planning wording/source-access delta and any material oracle changes. The preserved first result and unchanged source analysis need not be repeated. All issue ACs remain pending for implementation/delivery; the plan can be presented as a proposal after its limited clarity/factual corrections, with the numeric/default-interface decisions plainly open.
