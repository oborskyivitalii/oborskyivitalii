# Issue189 — independent Code / changed-artifact first review

Date: 2026-11-10. Reviewer: `/root/issue189_code_plan`, nonauthor Code / changed-artifact role. First judgment; no peer reports, parent notes or private author conversation inspected. No delegation, implementation or external writes performed.

## Verdict and scope

**No blocking architectural finding in the planning candidate.** The proposed one-producer/two-view architecture, retained complete schema-v2 inventory, opt-in scoped navigation and archive-first capacity sequence are technically coherent against the inspected producer, config, catalog, existing tests and supplemental consumers. This is a planning review, not implementation acceptance, an archive eligibility decision, or evidence that any AC has passed.

The two nonblocking clarifications below should enter the plan correction/T01 interface freeze. Full consumer discovery, native build/verify, actual archive recovery and exact final delivery selection remain mandatory unobserved gates; their absence was appropriately disclosed rather than counted as success.

## Bound inputs and independence limits

- Base: `ca756417590b9176f9fc33428321ffe1f64158cc`.
- Candidate: `/workspace/scratch/2c34f552b848/issue189-plan/2026-11-10-analysis.md`, 22,773 bytes, SHA256 `14037509dec64e6dc760152bcaf343d0ce7782aab120718679d3385558d0273e`.
- Packet: `/workspace/scratch/2c34f552b848/issue189-plan/review-packet.json`, SHA256 `f1e180f8c890219202e2269c5d76d6ae5e3074ec84ccc44210050120a18958d0`.
- Native prepared manifest: `issue189-native/exact-packet-manifest.json`, SHA256 `4ad55a8e62244cce0f568b342620a8387abab8ad1ae12c4192135b41b18b7ce6`.
- Common contract SHA256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Code role prompt SHA256: `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Original intent and scope: supplied `intake-issue189.md` and `user-intent.txt`; in-repository archive choice supplied as owner decision. Analysis/planning only, no mutations authorized.

This is a partial native-blob-verified materialization, not a Git checkout. All 37 manifest entries matched local byte counts/SHA256. All 33 entries labeled native were independently recomputed as Git blobs and matched their paths in the supplied untruncated observed tree. The supplied tree is an observed GitHub response, not a fresh repository fetch by this reviewer. Actual launch parameters/accepted execution receipt are the orchestrator's evidence; provider context/history injection and internals remain unknown. No cleanliness or attestation beyond these observations is asserted.

Before this first judgment, the orchestrator supplied additional primary-source paths under `issue189-supplemental`, without peer verdicts. I inspected relevant portions and independently verified all nine supplied files against native Git blob IDs in the same observed tree: full agent-context JSON, site-checks workflow, delivery-routing/observation/admission, issue acceptance producer/tests, enduring-test runner and delivery-admission tests. These supplemental bytes are outside the original frozen packet manifest and are explicitly additional review inputs.

## Nonblocking findings

### C01 — Freeze continuation identity across query parameters, not only source

Severity: low, interface clarification before T03; affects AC01.

Location: candidate lines 50–51 and test allocation line 166. The plan promises continuation position, source digest, exact prefix/file and scope, and tests invalid source continuation. It does not explicitly define stable result ordering or bind a continuation to normalized query, scope, path filter and page interpretation. With unchanged source, replaying a valid continuation after changing the prefix/query can skip relevant hits while still returning plausible remaining counts. The existing `lookup()` has separate ordered artifact/directory lists, so combining/page-order rules also need one explicit contract.

Treatment: at T01 define deterministic ordering and cursor semantics; reject continuation for a different effective query/scope/path filter, or clearly document an offset API with restart obligations and validate it accordingly. Include changed-query/scope/filter replay and cross-kind page-boundary cases alongside the already planned source-mismatch/concatenation checks. No implementation is required in this analysis turn.

### C02 — Refresh the missing-JSON statement using newly available source

Severity: low, factual evidence correction; affects AC01/AC02 evidence limits.

Location: candidate Evidence and limits, line 15, says full machine JSON remains unavailable. It was unavailable when the frozen candidate was authored, but the supplemental native blob is now accessible: `.github/repository-intelligence/agent-context.json`, 1,764,356 bytes, Git blob `3f3b0efe98ec42e1a72f132f857161e3f75d5aa9`.

Treatment: retain the dated access failure and add the later successful retrieval/identity, without claiming full local verification. Independent inspection confirms schema2, 2,674 artifacts/inputs, 283 directories, the expected two derived paths, one root instruction, full path parity with the canonical catalog and internally correct canonical input digest. The 40 content inputs available across the main and supplemental packets matched the stored SHA256 records. This narrows the missing-source limitation; it does not establish full consumer absence or native freshness.

## Architecture and compatibility assessment

The current `scan()` streams all supported nonderived bytes and only decodes bounded text; role filtering belongs after full `build()`/`verify()`, as proposed. Unqualified legacy queries can remain intact while new optional scope/prefix/page arguments use the same projection. The plan correctly identifies the existing directory-only context omission and basename-only instruction discovery, and adds relevant future boundary requirements without claiming current incidents.

Changing `render_map()` alone does not save capacity under the input cap because both RI outputs use derived records. Keeping full JSON/path/schema/source-identity fields retains the fields actually consumed by the inspected navigation receipt and `issue_acceptance.source_identity()`. The plan must preserve the identity contract, not the old digest value after input/producer changes. Existing JSON verification is semantic; the proposed regenerated-byte strengthening is real additional behavior, and fixture materialization must use canonical production serialization when that strengthening lands.

The config contains 31 owner rows and 15 validation routes; canonical owner paths and aliases are sufficient for a compact entry without a second maintained task registry. Exact path/prefix matching should not accidentally change the existing validation-route prefix syntax: current config intentionally contains family prefixes such as `.github/repository-`, `review/issue-`, and `.github/workflows/site-`. The plan's compatibility/atomic companion update requirements cover this risk; T01 should record it in interface detail.

Archive selection appropriately distinguishes matching size from matching bytes and eligibility, preserves existing ZIPs/manifests, excludes protected and unfinished work, and rejects fake media replacements. Adjacent locators and any historical navigation behavior changes need consumer-specific review. No recoverability or batch sufficiency has been observed here because ZIP/media originals are absent.

The delivered lane cannot be selected from the prose category alone. Supplemental routing confirms ordinary RI views/config and producer have repository dispositions, while unmatched archival media/HTML and control/policy changes can force a fuller route. The plan correctly leaves selection to the complete actual diff. Enduring Python selection excludes exact numbered task-snapshot modules, supporting selective reuse of #31/#33 methods rather than importing their dated acceptance wholesale.

## Checks actually performed

Read original issue/intent, root README/AGENTS/CONTRIBUTING/MEMORY/bootstrap, reviewer contract/prompt, CODE-STYLE rule headings, RI architecture/producer/config, canonical catalog/map metadata, RI/CI coupling and navigation workflow, archive184 inventory/index/report, relevant RI/root-layout/historical task/selection tests, and the supplemental consumers above. Commands performed bounded text/JSON inspection, hashing and arithmetic; no unit suite, full RI build/verify, CLI prototype, browser journey or archive extraction was run.

Independent recomputation from the observed tree reproduced:

| Quantity | Result |
| --- | ---: |
| Tracked files / bytes | 2,674 / 252,373,922 |
| Nonderived input bytes / spare under 250MB | 249,743,718 / 256,282 |
| Parsed-suffix tree estimate | 21,679,851 |
| review-directory bytes | 194,194,215 |
| History role files / bytes | 1,858 / 194,735,660 |
| History catalog entries including directories | 2,010 |
| Additional old-site archive-match size candidates | 195 / 30,092,333 |
| Candidate suffixes | 84 PNG, 60 JPG, 30 HTML, 15 WebM, 6 JSON |

These validate the plan's arithmetic and category distinction, not a live scan, native test result or new archival permission. Final 10MB reserve and 32KiB entry remain owner proposals. The 2MB checkpoint/1MB allowance is a proposed measurable stop condition, not a guarantee that remaining work fits.

No blocking issue found in dependency direction, complete-inventory preservation, two-output recursion avoidance, existing consumer fields, archive capacity arithmetic, separation of current navigation from history, style/check ownership, or preservation of human delivery gates. Remaining implementation/refinement and access gates are expressly unresolved.
