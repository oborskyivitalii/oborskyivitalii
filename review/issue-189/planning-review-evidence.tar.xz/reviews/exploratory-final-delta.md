# Issue189 — Exploratory / Interaction QA correction delta

Date: 2026-11-10. Reviewer: `/root/issue189_exploratory_plan`.
This continues the same review execution; it is not a newly fresh first judgment.
Correction input was the revised candidate and a factual change summary, without
peer judgments. First report remains intact at `exploratory-first.md`, SHA256
`ee9eff83e0a66b81879c3ac6f01cb7b506d0d303cfec9169b5dceba8bf4bbc4a`.

Reviewed the complete textual delta from `candidate-first.md` (SHA256
`14037509dec64e6dc760152bcaf343d0ce7782aab120718679d3385558d0273e`)
to `2026-11-10-analysis.md` (SHA256
`5313421c051dad1f9e17d6711fe7ccce5d0c4d130488e4e8b35b86b075a85ec5`),
then rewalked the affected pagination, fallback, integrity and decision journeys
in the revised prose. No implementation or external changes were made.

## Outcome

No blocking operator-plan defect found. The delta improves the clarity of the
proposed contract and retains the first review's planning-only verdict.

| Affected journey | Recheck outcome |
| --- | --- |
| Page broad/current/history results | The20-hit bound now explicitly covers only artifacts/directories, with deterministic `(kind,path)` ordering. Full instruction/owner/check metadata remains present. An operator cannot mistake the list bound for a total response-byte guarantee; excessive responses require narrowing/direct-source advice. Normal-task and broad-alias payload measurement remains planned. |
| Resume after a changed request or source | Offset continuation now carries a fingerprint binding normalized query, scope, exact prefix, page size and verified digest; reuse after bound-input change is rejected by the proposed contract. Added regression allocation matches that promise. This is designed behavior, not an observed implementation. |
| Preserve applicable check suggestions | The test plan distinguishes configured lexical validation-route family prefixes from path-component-aware user filters. This prevents an implementation from accidentally narrowing existing check-route matching while repairing path filtering. |
| Verify generated outputs | Byte freshness is consistently required rather than optional. The fixture serializer update and independent formatting mutation / CLI build→verify oracles are explicitly allocated. Existing fixture passes are not presented as execution of the stronger oracle. |
| Capacity and owner decision | The final10,000,000-byte reserve is recorded as user-selected. The32,768-byte map and internal checkpoint remain engineering proposals. Failure to find safely eligible inputs returns measured alternatives; protections are not weakened. |
| Connector-only fallback | Full JSON retrieval is newly recorded in candidate evidence, while the operational route still avoids requiring its wholesale ingestion. Direct owners, no false local-verification claim, native consumer audit and archive-binary limits remain explicit. |

The candidate now records full JSON identity `d951684629541c47ff7590d3da17f6382b26181a6e5cfa01ad2b2086b70c562e`.
This delta review inspected that updated evidence statement; it did not independently
retrieve or execute against those additional JSON bytes. Thus the first report's
“full JSON absent” statement describes its original supplied packet, not the
later author's access. No new full-source/runtime assurance follows from this rewalk.

Rechecked unchanged SHA256 identities for the existing producer, fixture module,
RI architecture, navigation workflow and common/role prompts. Reuse F01–F10 from
the preserved first report; no changed executable surface justifies rerunning
them. The observed directory-only top-level handoff limitation remains a baseline
regression oracle. Its correction is still promised by the candidate, not delivered.

Regression allocation remains the permanent RI fixture module in navigation's
existing job, plus actual connector/operator and selected-member recovery evidence
in the owning issue artifact. The updated pagination, byte-formatting and capacity
boundary scenarios are proposed checks; profile/registry owner inspection and
native execution remain T01/later obligations.

No implementation, compact-map usability, full-checkout verification, archive
recovery, browser/device, capacity attainment or delivery acceptance is granted.
All issue189 ACs remain pending; no additional execution was claimed in this delta.
