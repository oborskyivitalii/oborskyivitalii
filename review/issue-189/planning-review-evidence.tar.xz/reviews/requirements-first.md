# Issue189 — independent Requirements & Acceptance first preflight

Date: 2026-11-10. Role/execution: Requirements & Acceptance, `/root/issue189_requirements`, first judgment. Scope: analysis, architecture/plan/AC refinement; no implementation acceptance, archival change, external write, merge or deployment. This report is a reviewer treatment proposal, not an owner-approved replacement of issue189.

## Verdict and assurance boundary

**The intent is coherent, but dependent implementation is not ready for acceptance against the current intake.** AC01/AC04 still contain explicitly unaccepted budgets, the consumer-compatible representation is unchosen, and no newly eligible archival batch has been evidenced. These are preflight decisions/evidence gaps, not proof that the proposed approach is infeasible. Read-only inventory and plan preparation can continue. No AC is marked passed by this review.

I independently read the supplied common/role prompts, original-intent summary, issue intake, README, root AGENTS, CONTRIBUTING, MEMORY, bootstrap/map/RI contract, actual producer/config/catalog/coupling owners and relevant test/archive records. I did not read parent scratch notes, current peer output files, private chat history or prior conversations; I did not delegate. The historical issue184 report contains historical reviewer conclusions; I treated those as dated claims and used actual inventory/index/source where available, not as my own acceptance. Shared platform/project instructions, tools and filesystem are not an isolation sandbox. The orchestrator must preserve the actual requested/accepted launch receipt; I cannot observe provider-internal model selection, context construction or history injection, and do not attest to their absence.

Prepared source packet: `source-packet-manifest.json`, SHA256 `6b3e87f89c37b513a260bed610084e7361df319ac3dc1bbffc05d35d86a0ae7f`. All 30 listed local files independently matched their listed byte length/SHA256. Common prompt SHA256: `11370925623aae0243944cbfa4b59244d0b081149ff15709cf2abe2c586b360b`; role prompt: `44d2431d6de4f3618f90140813c43a994b55e1ea5897064a45adccca33750788`. Claimed repository base: `ca756417590b9176f9fc33428321ffe1f64158cc`. This is a partial connector snapshot, **not a Git checkout or a complete candidate**.

There is a systematic source-byte distinction: all 27 manifested files that also occur as blobs in `observed-git-tree.json` have one additional final LF locally. Their raw blob identities differ; removing exactly that final LF for comparison reproduces each observed Git blob SHA-1. No source was changed. The six supplemental files show the same relationship. The manifest truthfully identifies supplied bytes; fixture execution below is on those prepared bytes, not an exact native checkout. This explains the intake's one-byte-smaller map/catalog/contract sizes and prevents claiming native-byte verification.

Supplemental sources were explicitly supplied after the initial manifest. These individually identified bytes informed compatibility/test-selection findings:

| Supplemental path | Local bytes | SHA256 |
| --- | ---: | --- |
| `.github/repository-layout.json` | 4544 | `ab74500552389462d39faf62dfd8265dd033e5df07cf245d9d529ab255d31da7` |
| `.github/acceptance/issue-184.json` | 4943 | `7cdb0977fc8cfdfd260e6edf20ec1a46573083cea3c04e26ce94e3bf93ac566c` |
| `.github/workflows/change-admission.yml` | 8533 | `d90ffb1e2004a1dfc3aed3fe49b6c4da0fe36b3e60a1bd409baec94568469270` |
| `tests/test_root_layout.py` | 12795 | `84f91109e06522c8492ac3193fcc348182556bc5f5f49dca2a1123966c7550aa` |
| `tests/test_repository_test_selection.py` | 8840 | `6264e1df90fe0e099df461ede4d5f1b7b4102aebf17befa3d35b09a73d653465` |
| `tools/quality/README.md` | 21892 | `908662aa295bba729b4bd57eafbc8473ef5610c48f10b7c71141594b511cf0a9` |

## Independently established architecture and capacity facts

`scan` hashes every supported nonderived input; bounded navigation text is decoded separately. `path_inventory` requires an exact catalog/file/ancestor-directory correspondence with valid purposes, roles and existing owners. `build` creates a single complete surface. `render_map` emits every directory/file from that surface. `verify` rebuilds and compares the machine surface plus readable map. `query` and `context-for-task` first call `verify`; neither is an independent cached index. The context command adds instructions/check routes to lexical owner/artifact matches; it currently has no explicit current/history scope selector. Directory-only matches do not enter its paths set. The dated/live GitHub overlay is deliberately external.

The maintained catalog has 2,957 entries, including 2,010 with role `history`. A compact default surface and complete integrity inventory serve different needs. That supports investigating a smaller default navigation surface without abandoning the existing deterministic implementation. It does not establish a need for a database, vectors or a paid platform, nor does it establish any particular split layout as already accepted.

Metadata arithmetic independently reproduces the intake:

| Resource from observed tree metadata | Observation | Limit / implication |
| --- | ---: | --- |
| Tracked blob count | 2,674 | RI file bound 5,000; untracked supported inputs can also count during an actual scan |
| All tracked blob bytes | 252,373,922 | Includes both RI outputs |
| Nonderived hash-input bytes | 249,743,718 | 250,000,000 cap; only 256,282 bytes spare |
| `review/` bytes | 194,194,215 | Archives still consume hash-input capacity |
| Parsed-suffix input bytes | 21,679,851 | 50,000,000 aggregate text cap; metadata estimate, not actual decode execution |
| Largest parsed-suffix input | 1,999,782 (`tools/quality/secrets-reviewed.json`) | 2,000,000 per-text-file cap; only 218 bytes spare |
| Largest hash input | 11,726,610 (`review/site-v1-20261002-v6.zip`) | 32,000,000 per-file hash cap |

If 10 MB means 10,000,000 bytes of final aggregate headroom, the complete final input set must be at most 240,000,000 bytes. Relative to this baseline that requires at least **9,743,718 bytes net input reduction**, plus every new input/metadata/review byte. Reducing the two existing derived outputs does not reduce that aggregate input total. New generated shards are not automatically exempt: the producer's exclusions and coupling tool's `DERIVED` set currently name the existing outputs explicitly.

The issue184 inventory is pinned to older `a9f5769...`, not current base. Its 238 archive matches comprise 195 unresolved legacy matches (30,092,333 original bytes), 10 active-authored-site matches (781,130 bytes), and 33 already-selected legacy prototypes (4,199,222 original bytes). All 33 selected paths are now smaller in tree metadata, consistent with their existing locators. **Do not count those original 4.2 MB as a second future saving.** The other 195 matches are an inspection queue, not 30 MB of approved savings; archive bytes, duplicate overlap, locator/metadata overhead, current consumers and eligibility remain to be checked. The inventory explicitly preserves unresolved groups and active/public/fixture/rollback resources.

## Findings and treatments

### R1 — P1: Default surface, budget and observable lookup contract remain open

Evidence: `intake-issue189.md:23–28,40–43`; current `render_map`, `lookup`, `main`; RI contract sections “Complete path catalog and authority” and “Agent route”.

AC01 says “reviewed bounded”, “current” and “usable through scoped routes” without identifying the default artifact/command, defining the scope predicate, defining expected result fields, or enumerating representative tasks. The 32 KiB value is explicitly proposed. A compact heading pasted ahead of the existing 866 KB dump could satisfy an informal entry claim while preserving the original context problem. Conversely, filtering history out of the complete surface would violate AC02.

Treatment: retain AC01's ID, append the selected default surface and byte measure, accepted budget, current/history/all semantics and independent owner/instruction/check oracles. Require actual entry-to-owner journeys in both English/Ukrainian aliases where already promised, exact path and directory scope, history-only retrieval and a lexical miss with explicit fallback. Measure the actual default read/output, not only a decorative introduction. A directory journey must preserve applicable scoped instructions/check routes. No arbitrary “latest” inference from timestamps or closed issues should confer authority. Choosing rendering details after this contract is fixed is routine implementation, not a reason to ask about every file.

### R2 — P1: Compatibility cannot be accepted before complete consumer discovery

Evidence: intake lines 28,36,41; producer `load_config` fixes `map_output` to `REPOSITORY-MAP.md` and the machine path suffix; `verify`/CLI depend on full surface; `navigation.yml:54–69` reads `['source_identity']['digest']` at the fixed machine path; coupling `DERIVED`/`control_paths`; layout `root_files`/`active_markdown`; README/bootstrap/map entry routes. Several authoritative owner/runtime files, including the generated agent JSON, are absent.

Failure mechanism: replacing the machine JSON with a small summary can break CLI verification, freshness receipts and consumers; adding another root file can violate layout; new outputs can unintentionally become hashed self-dependent inputs; moving full map material can strand connector-only users or active relative links. Passing producer fixtures alone would not establish compatibility.

Treatment: inventory all producer/consumer pairs at the actual implementation base, including staging/source admission, acceptance/profile routes, layout/link validators and connector-only entry. Record retain/adapt/deprecate dispositions and schema/CLI behavior before choosing a split. Preserve complete inventory and deterministic freshness with explicit derivation rules for every output. A changed public interface needs an owner-approved migration disposition; a compatible generated view addition within existing owners can be chosen technically after this audit. Current packet cannot complete this audit.

### R3 — P1: No new archival batch has an eligibility/recovery oracle yet

Evidence: intake lines 17,30–32,50–53; `review/issue-184/inventory.json` `source`, `dispositionGroups`, `classificationCoverage`; `archive-index.json` items/exclusions; CONTRIBUTING “Archive completed production work”; supplemental issue184 policy ARCHIVE/PUBLIC gates.

The current AC has strong protections but no selected current-base path set, consumer search boundary or byte-level protected-set comparison. Old exact-duplicate/archive membership does not establish production eligibility. Many inventory owners are explicitly path-derived candidates. The previously selected 33 files have already been replaced, and their old consumer list only covers that old selection.

Treatment: freeze the next bounded selection and exclusions at a current source identity; attach each selected original to actual owner and delivery/supersession evidence, source/consumer dispositions, original bytes/hash, archive bytes/hash/member and locator/recovery command. Extract/compare every selected original before removal, preserving prior manifests, first failures and reviewer status. Compare the protected dependency closure and unchanged archives to a frozen base. Preserve unresolved entries and do not promise all-history completion. A new helper, if introduced, needs mismatch/missing/unsafe member refusal cases; no new helper is required merely to satisfy the AC. Actual archive binaries and original loose bytes are missing here, so no extraction/recovery pass is observed.

### R4 — P1: “Useful headroom” and the first capacity checkpoint are not assessable gates

Evidence: intake lines 34,55–58,67–74; producer constants/`scan`; metadata arithmetic above.

10 MB is explicitly unaccepted, and “minimum safe headroom” has no numeric or workload predicate. Compaction of existing derived outputs cannot itself satisfy hash-input recovery. A report could also stop before final evidence/metadata growth and overstate space available to #188/#187.

Treatment: obtain the owner's useful-capacity objective (exact units; hard final target or planning target tied to a bounded next-work allowance). Define what complete candidate is counted and a small first checkpoint sufficient for the identified next work/reserve. Require net final count/bytes at source-bound checkpoints, including new archives, locators, catalogs, reviews and any newly hashed views; report output/tracked-storage and input savings separately. If safe eligible savings are insufficient, return measured alternatives/exclusions for decision, keeping current limits and integrity. Do not silently make optional all-history cleanup a dependency of the sibling tasks.

### R5 — P2: Aggregate headroom does not describe the full capacity envelope

Evidence: producer constants; observed tree `tools/quality/secrets-reviewed.json` size; supplemental `tools/quality/README.md:181–191` preserves the historical ledger and uses specifically reviewed companions under the existing 2 MB bound.

Even after 10 MB aggregate recovery, an unrelated 219-byte addition to that nearly full text file can still refuse RI. The existing ledger companion mechanism also means the near-full historical file is not automatic authorization to rewrite or archive it.

Treatment: make AC04 report count, aggregate hash/text, largest per-file hash/text and each limiting margin separately; identify bounded pending input growth and protected/immutable ledgers. A small read-only capacity report/warning can be considered in existing tooling; accepting its threshold/hard-failure behavior is separate from merely reporting measurements. No cap increase, blanket ledger exemption or ledger rewrite follows from this finding.

### R6 — P2: AC02's “all tracked paths exact-byte checked” needs its derived-output exception and oracle made explicit

Evidence: intake line46; producer `scan` emits `identity_mode: derived` for two views; `verify` compares parsed machine JSON objects, whereas the map is compared as text; tests `test_missing_and_tampered_context_fail_visibly`/`test_map_missing_or_tampered_fails_and_is_not_recursive`.

The current machine verifier detects semantic changes but accepts harmless JSON serialization/whitespace changes. Thus current code does not supply a literal serialized-byte oracle for every tracked path. This distinction should not be lost in broad integrity wording.

Treatment: explicitly require SHA256 of exact nonderived input bytes, including binaries/archives; define generated-output freshness independently without recursive hashing. If serialized-byte determinism/tampering is promised, compare regenerated expected output bytes and test whitespace/serialization mutation. If existing semantic-JSON comparison is intentionally retained, document that exact limitation instead of calling it an exact-byte proof. This decision concerns the output guarantee, not permission to weaken archive/input integrity.

### R7 — P2: Historical-instruction refusal is broader than the existing fixture

Evidence: intake lines26,46; producer `build` discovers every basename `AGENTS.md` without consulting catalog role; `test_history_is_searchable_but_not_scoped_agent_instructions` only exercises `archive/AGENTS.before.md`. The observed tracked tree currently contains only root `AGENTS.md`.

There is no observed historical `AGENTS.md` defect at this base. However, a future loose historical path with that exact basename would become an instruction by the current discovery rule even if cataloged as history. Existing positive fixture coverage is narrower than AC02's promise.

Treatment: define the classification/instruction boundary for the selected representation; exercise an exact historical basename and/or ensure archives remain compressed or historical filenames are inert under the explicit accepted rule. Keep live scoped-instruction precedence and directory ownership tests. Merely asserting that `AGENTS.before.md` is absent from instruction lists is insufficient for the broader claim.

### R8 — P2: Acceptance allocation must preserve historical selectors and separate delivery from current planning

Evidence: intake AC05/status; supplemental issue184 policy uses one named `test_issue31_acceptance` method rather than all historical issue31 tests; supplemental `tests/test_repository_test_selection.py:21–48` excludes numeric task modules from permanent selection; issue31/33 contain frozen memory/public/history expectations; CONTRIBUTING acceptance and review protocol.

Running or rewriting all issue31/33 snapshots as if they were current permanent requirements would either produce misleading failures or weaken old evidence. Broad “affected tests” also does not identify issue189's recovery/capacity/manual oracles. This analysis request does not authorize implementation or merge despite AC05 describing eventual delivery.

Treatment: allocate current RI/coupling/layout/style regressions, selected existing methods and any issue189-specific checks through the canonical owning policy/profile route when implementation is authorized. Retain frozen task evidence and justify unchanged/obsolete/diagnostic dispositions. Distinguish requirements review, complete-candidate automated checks, four actual role results/corrections, trusted-lane CI, maintainer merge and applicable release observations. No generic green RI test establishes eligibility, reviewed meaning, served production or closure.

## Intent/AC → check or owner gate → observed result

| Intent / AC | Required check or decision | This review's actual evidence / remaining gate |
| --- | --- | --- |
| Original intent / owner continuity | Verify original #187 transferred AC04–05 and RI part of AC06; live #189 source/decisions | Prepared intake/intent summary read; raw combined comment and live issue not supplied/read by this reviewer. Transfer meaning and current refs remain orchestrator/live-source gates. |
| AC01 compact current entry | Fixed entry/scope/budget plus task→canonical owner/instruction/check journeys and connector fallback | Actual map/producer/config read; current all-inventory rendering confirmed. No compact candidate exists. Budget/interface decision pending (R1–R2). |
| AC02 complete inventory/integrity | Native full-checkout build/verify; exact catalog coverage; source/binary mutations, exclusions, unsafe paths; derived-output freshness | 27 existing producer fixture tests passed on supplied bytes; full catalog/production build and two real-repository RI cases not run. Existing history/derived oracle gaps identified (R6–R7). |
| AC03 safe lossless archival | Current-base eligibility/consumer/protected-set evidence; every original vs extracted member/size/hash/locator; actual recovery | Old inventory/index inspected and groups recounted; 33 already-selected size changes observed in metadata. Binary archives/originals absent; no recovery or new-batch eligibility established (R3). |
| AC04 capacity | Accepted units/target/checkpoint; full-candidate scan/resource/output accounting, exact-source margins | Tree metadata arithmetic reproduces intake; independent per-file bottleneck found. No native scan, final saving or accepted target (R4–R5). |
| AC05 reviewed delivery | Style IDs/guard, explicit policy/test allocation, four final source-bound roles and corrections, complete-diff trusted CI, maintainer merge/release as applicable | Applicable protocol and existing routes inspected only. No changed candidate, final-role acceptance, CI, merge or delivery claimed (R8). |

Actual bounded test execution: imported `tests/test_repository_intelligence.py` with `PYTHONDONTWRITEBYTECODE=1`; ran all `NavigationSafetyTests` except `test_real_adapter_owners_and_cross_repo_isolation` and `test_quality_agent_queries_and_context_route_to_existing_checks`. Result: **27 tests, 0 failures/errors, 0 skips, 0.317 seconds, exit 0**. Tests used their temporary fixture roots, including bounded unsafe-input/hash tests. The two real-repository cases were deliberately not selected, not reported as passes/skips; they require absent full owners/output bytes. No complete RI, coupling, root-layout, archive extraction, UI or native CI campaign was run. No failed campaign was retried or hidden.

## Material owner decisions and next gate

1. **Default representation and budget:** accept a bounded generated entry, and specify whether it becomes `REPOSITORY-MAP.md` or a scoped front route after the consumer audit; accept or revise 32,768 bytes as the measured entry budget. Preserve complete on-demand inventory and current/history retrieval. Avoid asking the owner to pick file plumbing before concrete compatible options are available.
2. **Useful capacity:** is 10,000,000 bytes final aggregate headroom a hard requirement, or a provisional workload/reserve objective? What evidence-bound capacity checkpoint releases dependent mutations? A target cannot authorize protected-resource loss or a limit increase.
3. **If audited eligible savings cannot meet that objective:** decide among a narrower accepted batch/target and deferred additional inventory. No such insufficiency has yet been proved; do not ask for a blanket archival exemption in advance.
4. **Only if compatibility cannot be preserved:** approve a concrete documented interface migration. Retaining Git/Markdown/current CLI is technically supported by present evidence; no platform replacement decision is necessary merely because the map is large.

The serialized-output oracle (R6) and precise current/history classification can normally be resolved as explicit technical contract proposals reviewed against original intent; do not inflate them into a long questionnaire of routine engineering choices. A materially weakened guarantee or consumer break does require owner disposition.

Next gate: obtain/record current owner intent/refs and complete consumer/binary inventory, resolve the budget/capacity/default-interface choices, append measurable subconditions under the stable AC01–AC05 IDs, and return materially changed requirements/oracles for Requirements review before dependent implementation. Current request ends at a concrete plan and disputed decisions; no archival or code action is authorized by this report.
