# Issue189 — White-box QA correction review

Date: 2026-11-10. Reviewer: `/root/issue189_whitebox_plan`, continuation of the original White-box role. This is a correction review using my own first findings and the corrected candidate, not a fresh independent-context launch. No peer verdicts were supplied or read.

Candidate: `issue189-plan/2026-11-10-analysis.md`, SHA256 `5313421c051dad1f9e17d6711fe7ccce5d0c4d130488e4e8b35b86b075a85ec5`. Compared its complete textual delta with preserved `candidate-first.md`, SHA256 `14037509dec64e6dc760152bcaf343d0ce7782aab120718679d3385558d0273e`. First report remains unchanged, SHA256 `db394b7e1dab931a8d11f507ee4dd0283617f781bbc3a14954cdf9c4200b12cc`. Original prompt/packet identities and source limitations remain recorded there.

## Verdict and findings disposition

No unresolved White-box blocker remains for the planning deliverable. All three findings are addressed at the level appropriate to this planning-only candidate. Their future implementation and tests remain pending.

| Finding | Corrected contract/allocation | Disposition |
| --- | --- | --- |
| WQ01 P2 — conditional serialization oracle | Architecture says regenerated-byte comparison will be used; AC02 requires whitespace-only JSON rejection unconditionally and identifies it as the single proposed output oracle | Resolved in the plan; exact-byte implementation/mutation evidence still required |
| WQ02 P3 — fixture serialization dependency | Test allocation explicitly names atomic `materialize()` adaptation from noncanonical `json.dumps(data)` to production serialization, an independent formatting-mutation oracle and actual CLI build→verify round trip | Resolved in the plan; no adapted fixture or new test has been executed |
| WQ03 P3 — capacity reporter/refusal split | Allocation explicitly requires exact hard-limit/limit+1, advisory threshold, invalid over-limit report and unsafe/missing/unreadable-input cases while preserving build/verify refusal | Resolved in the plan; report arithmetic and refusal branches remain implementation checks |

The related paging clarification is coherent with the protected invariant: deterministic `(kind,path)` hit order; the proposed20-hit count is a list bound; complete applicable instruction/owner/check metadata is not discarded to satisfy it. Continuation binds normalized query, scope, exact prefix, page size and verified source digest, and must refuse changed bound inputs. These are concrete independent fixture oracles. Measuring broad-alias and normal-task full responses preserves visibility of excessive metadata without inventing a response-byte guarantee. The actual behavior of scope/directory routing must still be demonstrated after implementation.

The plan also explicitly separates configured lexical validation-route family prefixes from path-component-aware user filters. That preserves current routes such as `.github/repository-` while allowing safe exact/prefix navigation; implementation must not apply one matcher indiscriminately to both.

The evidence section now correctly records full native JSON access while retaining missing archive binaries/full-checkout/consumer-audit limits. The final10,000,000-byte reserve is correctly recorded as user-selected; the map budget and interim checkpoint remain technical proposals. The owner decision supplies a target, not archive eligibility or measured achievement.

## Checks and reused evidence

Executed only source/delta checks, no suite replay:

- `sha256sum 2026-11-10-analysis.md candidate-first.md` matched the identities above; exit0.
- `diff -u candidate-first.md 2026-11-10-analysis.md` exposed the complete substantive correction delta; expected exit1 because differences exist.
- A bounded Python SHA256/size comparison against the original native manifest confirmed unchanged bytes for the common/role prompts, producer, RI tests, config, coupling producer/map and navigation workflow:8/8 matched, exit0. First-report SHA256 remains exact.

An initial lookup used the shorthand filename `analysis.md`, which does not exist; `sha256sum` returned exit1. Listing the supplied plan directory identified the actual dated filename. This was a path-discovery error, not a candidate/source-check failure; no acceptance run was attempted or retried.

The first report's two baseline fault probes, packet checks, supplemental native-blob identities, inventory arithmetic, risk matrix and verified existing workflow routes are reused because relevant source bytes are unchanged. They remain bounded baseline observations, not proof of corrected future behavior.

No implementation, accepted test change, full native RI verification, archive extraction, measured branch coverage, real lookup usability campaign, hosted check, merge or delivery was performed. AC01–AC05 remain pending. This correction review accepts the revised plan's testable obligations and allocation, with actual native consumer/eligibility/recovery/current-source delivery gates retained.
