# Issue189 — first independent Exploratory / Interaction QA report

Date: 2026-11-10. Role/task: `/root/issue189_exploratory_plan`.
Phase: first judgment, planning candidate only. No peer first-result files,
parent notes or private conversation history were inspected. Historical issue184
records were read as supplied source, not as current reviewer judgments.
Requested/accepted launch parameters and provider context/model internals must
be recorded by the orchestrator; this report does not infer them from its role name.

## Verdict

No blocking defect found in the proposed operator journeys at this planning
checkpoint. The plan is suitable for discussion and interface/budget decisions.
This is not implementation, full-repository, archive-recovery, UI or delivery
acceptance; all issue189 ACs remain pending.

The plan makes the key usability distinction correctly: a small default entry
does not replace complete inventory/integrity, and a lexical miss does not establish
absence. It preserves existing unqualified behavior while proposing an explicit
current route. The actual current CLI has a directory-only handoff limitation;
the candidate explicitly includes its correction and regression, as detailed below.

## Inspected identities and limits

| Input | Identity |
| --- | --- |
| Base observed in supplied packet | `ca756417590b9176f9fc33428321ffe1f64158cc` |
| `issue189-plan/review-packet.json` SHA256 | `f1e180f8c890219202e2269c5d76d6ae5e3074ec84ccc44210050120a18958d0` |
| `issue189-plan/2026-11-10-analysis.md` SHA256 | `14037509dec64e6dc760152bcaf343d0ce7782aab120718679d3385558d0273e` |
| `issue189-native/exact-packet-manifest.json` SHA256 | `4ad55a8e62244cce0f568b342620a8387abab8ad1ae12c4192135b41b18b7ce6` |
| Common reviewer contract SHA256 | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| Exploratory role prompt SHA256 | `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a` |
| Existing producer SHA256 | `dad68d88d241c2cd223081d6a28961c1aa7abc19c0f4c223c9c3382c562aa792` |
| Existing fixture module SHA256 | `44d726dbf263dba2fbfed4a863a38f26c7f7cd3df751afcf592c429cc0bf2a08` |

All 37 manifest-listed files were independently checked for supplied byte size
and SHA256: zero mismatches. Native Git-blob verification is the packet's supplied
provenance; I did not independently fetch Git objects or assert a clean checkout.
The snapshot is partial. Full machine JSON and archive bytes are absent. Live
GitHub/production revalidation was not repeated by this reviewer.

Read the common/role prompts; README, AGENTS, CONTRIBUTING, MEMORY and bootstrap;
the candidate and intake/original-intent text; relevant map entries, RI architecture,
producer/config/catalog and fixture code; navigation workflow; issue184 archive
record and recovery-index examples. No implementation diff exists in this scope.
The current test-allocation owner's path and purpose were confirmed through the
catalog, but `guides/SITE-CHECK-PROFILES.md` and the full registry bytes are not in
the supplied subset. Allocation below is proposed, pending owner inspection.

## Charter and bounds

Before execution, chose five operator risks: connector-only entry and fallback;
local owner/exact-path handoff; current versus historical discovery; directory-only
context; and stale-source refusal. Separately walked archive recovery instructions
without executing extraction. Bound: ten existing-CLI subprocess actions across
two temporary fixtures, each with a 15-second timeout; no real repository build,
browser session, new scoped implementation or archive extraction. All ten actions
completed within their timeout. Temporary fixture files were removed by cleanup.
Only this assigned report is retained; no external write or delegation occurred.

## Operator walkthroughs

| Journey | Expected from candidate | Observed / disposition |
| --- | --- | --- |
| Connector-only agent starts from README/bootstrap | Read bounded map, follow canonical owners and applicable instructions, avoid full JSON paste; use direct sources without falsely claiming local verification | Actual README/bootstrap route to AGENTS/map/MEMORY, and RI architecture lines184–194 explain direct-source fallback and exact-source CI evidence. Candidate lines49–51/118–124 preserve that route and add a short map. New map and connector read-volume outcome are **designed, not observed**. |
| Local alias or exact-file lookup | Owners, applicable instructions and suggested checks are discoverable | Existing CLI executed on temporary fixture; UA alias and exact file returned expected root/scoped instructions and fixture validation route. New scope/prefix parameters are **not implemented or executed**. |
| Historical lookup without instruction activation | History is labeled and old instruction text remains evidence | Existing CLI returned `archive/AGENTS.before.md` with role `history`, applying root instructions only. Exact live-name `AGENTS.md` refusal is **designed, not executed**; candidate specifically requires this stronger boundary. |
| Directory-only context | Directory hit retains appropriate instruction/check handoff | Existing pure directory hit loses top-level context. Baseline observation below. Candidate explicitly requires directory-only repair; new outcome **not observed**. |
| Lexical miss / stale data | Visible unresolved/direct-source path; no inferred absence or stale freshness | Fixture miss returned `unresolved-use-direct-search`; source mutation then query exited1 with direct-source fallback. Existing behavior **observed**. |
| Historical recovery locator | Identify original path/hash/size and archive/member/command; compare recovered bytes before mutation | Actual issue184 index has those fields and practical `unzip -p ... > /tmp/...` examples. Candidate adds honest media locators and member ambiguity checks. Archive/member bytes, current locators, browser links and extraction are **not observed**, because needed files are absent. |

The map still observed in this subset is the existing 865,848-byte exhaustive
map, not the proposed 32,768-byte entry. Reading it demonstrates the present route,
not success of the proposed reduced-context experience. The candidate expressly
identifies its 5,519-byte sketch as feasibility evidence rather than a finished map.

## Executed existing-CLI evidence

Used `NavigationSafetyTests.setUp()` from the supplied native fixture module to
create throwaway `example/research` roots, then invoked the copied, unchanged
producer using actual subprocess CLI commands:

```text
python3 <temporary-root>/tools/repository_intelligence.py \
  --root <temporary-root> --config governance/config.json <command> [query]
```

Fixture additions: inert `archive/AGENTS.before.md`, a historical Markdown record,
explicit `history` catalog roles, and a validation route for `evidence/` with a
nonexecuted suggestion `fixture-check-evidence`. No checks are inferred from
that suggestion. A second fixture gave only directory `evidence` the unique
purpose `DirectorySentinel` to avoid lexical descendant matches.

| Case | Command / expected | Actual output retained from execution |
| --- | --- | --- |
| F01 | `build`; create existing full views | Exit0, `Built RI views: 11 files, 6 directories` |
| F02 | `context-for-task джерела`; explicit owner + scoped handoff | Exit0, owner `evidence/SOURCES.md`; instructions `[AGENTS.md, evidence/AGENTS.md]`; `evidence/` fixture validation route |
| F03 | `context-for-task evidence/SOURCES.md`; exact file handoff | Exit0, artifact `evidence/SOURCES.md` / `source`; same two instructions and route |
| F04 | `context-for-task evidence`; inspect mixed lexical results | Exit0, directory `evidence` plus three artifacts, including historical `archive/old.md` whose title contains “evidence”; same two instructions and route. This is **not** a pure-directory test. |
| F05 | `context-for-task 'Former instructions'`; history remains inert | Exit0, artifact `archive/AGENTS.before.md` / `history`; instructions `[AGENTS.md]`; routes `[]` |
| F06 | `query nothing-related-82391`; unresolved without invented owner | Exit0, `unresolved-use-direct-search`; owners/artifacts/directories all `[]` |
| F07 | `verify`; fixture currently fresh | Exit0, `Repository Intelligence context is fresh.` |
| F08 | Append text to registry then `query джерела`; refuse stale surface | Exit1, stderr `RI unavailable: Stale or altered RI context; rebuild or use direct repository reading. Read authoritative sources directly.` |
| F09 | Build second pure-directory fixture | Exit0, `Built RI views: 9 files, 5 directories` |
| F10 | `context-for-task DirectorySentinel`; inspect directory-only handoff | Exit0, `candidates-read-sources`; one directory `evidence`; no artifacts/owners; top-level `instructions: []`, `validation_routes: []` |

F08 is an expected negative and was not rerun to obtain green. F04's mixed-match
observation motivated F09/F10's bounded diagnostic with a unique directory purpose;
the first result is preserved above rather than mislabeled directory-only success.

## Finding / risk disposition

**Existing limitation, P2 — pure directory context has no top-level handoff.**
Source: existing producer lines558–571 and actual F10. `context-for-task` constructs
its context paths from owners plus artifacts, excluding matched directories.
F10 returns directory `evidence` (whose own record includes root instructions),
but empty top-level instruction/check arrays despite the configured `evidence/`
route. A consumer relying on those arrays can miss the directory workflow.
Affected requirement: AC01 directory-only lookup and source-grounded instructions/
checks. Proposed treatment: preserve the candidate's explicit directory-only
correction and use a fixture where only the directory matches, including a
boundary sibling such as `evidence-old/`. Define the intended distinction between
instructions applicable to the directory itself and instructions required for
work on its descendants. This is already covered by the plan's promise; it is
not a newly introduced candidate defect or evidence that a fix exists.

Other examined risks have explicit planned treatment: prefix component boundaries;
page completeness/continuation bound to source digest; unknown query fallback;
history/draft/generated exclusion from current views without integrity omission;
existing unqualified compatibility; native consumer discovery before mutation;
media locators that disclose changed direct-link behavior; exact-member recovery
and protected-resource closure; complete-candidate capacity including evidence.
No additional blocking planning finding was established from supplied evidence.

## Proposed regression / execution allocation

| Risk / AC | Scenario and independent oracle | Existing or planned route / disposition |
| --- | --- | --- |
| AC01 directory handoff | Only directory matches; canonical scope/check owners define expected handoff; sibling prefix excluded | Extend permanent `NavigationSafetyTests` in `tests/test_repository_intelligence.py`; existing `.github/workflows/navigation.yml` job `navigation`, step “Check RI inventory and agent-memory contract”. F10 baseline executed; future regression **proposed**. |
| AC01 compatibility / history / miss | Preserve F02/F03/F05/F06 unqualified outputs; scoped current/history/all expected sets declared independently by fixture roles | Same permanent RI module/job. Existing component journeys observed; new scoped comparisons **proposed**. |
| AC01 pagination | More than20 artifacts/directories; concatenate pages without gaps/duplicates; reject stale-source continuation | Same permanent module/job; **proposed**, no pagination implementation observed. |
| AC01 connector route | At exact source read short map → known owner → applicable instructions/check owner without full JSON; missing CI identity leads to direct sources | Manual operator review in owning issue189 artifact after generated map exists; **deferred**. |
| AC02 stale source / instruction safety | Retain F08 refusal; exercise historical exact live-name `AGENTS.md` alongside inert archived name | Permanent RI negatives in same module/job; stale baseline observed, exact-name case **proposed**. |
| AC03 recovery / media use | Actual selected base bytes equal each extracted member; locator route works; active/historical references have explicit dispositions | Owning issue189 source-bound every-member recovery and protected-set comparison; **blocked here by absent archives/full checkout**. Browser perception/links remain deferred if changed HTML/locator UI makes them applicable. |
| AC04 capacity report failure path | Over-limit input reports why without accepting valid RI; independent byte totals include new locator/report inputs and exclude only the existing derived pair | Permanent RI fixture allocation plus full native report; **proposed / native unobserved**. |

These are allocations through the existing owner route, not new pipelines or
executed future tests. Confirm lifecycle/profile registration against the actual
`guides/SITE-CHECK-PROFILES.md` and `tools/quality/test-profiles.json` at T01.

Dynamic browser/device testing is reasoned not applicable to this prose-only
planning candidate. It is not waived for any later changed locator UI. Full native
CLI, source-set completeness, archive recovery, final capacity and delivery remain
unobserved required work, rather than non-applicable work. Recheck this report's
candidate identity before reusing it after any substantive plan change.
