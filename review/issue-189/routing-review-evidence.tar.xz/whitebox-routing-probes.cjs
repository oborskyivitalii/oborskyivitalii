"use strict";
const fs=require('node:fs'); const assert=require('node:assert/strict');
const root='/workspace/scratch/2c34f552b848/issue189-checkout';
const routing=require(root+'/tools/quality/delivery-routing.cjs');
const registry=JSON.parse(fs.readFileSync(root+'/tools/quality/test-profiles.json'));
const workflow=fs.readFileSync(root+'/.github/workflows/issue-acceptance.yml','utf8');
const rights=JSON.parse(fs.readFileSync(root+'/site/rights.json'));
const clone=structuredClone;
const record=(file,status='M',mode='100644')=>({status,oldPath:status==='A'?null:file,newPath:status==='D'?null:file,oldMode:status==='A'?null:mode,newMode:status==='D'?null:mode});
const source=()=>({registry:clone(registry),rights:routing.provenance(rights),repositoryNotices:routing.repositoryNotices(rights),contentPaths:new Set(),owningWorkflow:workflow});
const sources=()=>({base:source(),candidate:source(),policy:source()});
const basic=()=>[record('tests/delivery-observation.test.cjs')];
let total=0,failures=0;
function run(name,expected,records=basic(),mutate=()=>{}){
 const s=sources(); mutate(s,records);
 const technical=routing.technicalSelection(records,s);
 const analysis=routing.analyze(records,s,'1'.repeat(40),'2'.repeat(40),true).analysis;
 const actual=analysis.status==='complete'&&(technical.eligible||(analysis.control===false&&analysis.proposedLane==='repository'));
 total++; const pass=actual===expected; if(!pass)failures++;
 console.log(JSON.stringify({name,expectedRepositoryOnly:expected,actualRepositoryOnly:actual,pass,technical:technical.eligible,rejected:technical.rejected,status:analysis.status}));
}
// Independent oracle: both endpoint hosted dependencies, unknowns/modes and bootstrap
// controls require full work; ordinary supported evidence plus bounded source tests may omit it.
for(const side of ['base','candidate']) for(const kind of ['content','rights'])
 run(`${side}-${kind}-dependency`,false,[...basic(),record('review/issue-999/archive-index.json')],s=>s[side][kind==='content'?'contentPaths':'rights'].add('review/issue-999/archive-index.json'));
for(const file of ['review/issue-999/notes.md','review/issue-999/archive-index.json','review/issue-999/security-proof.json.gz','review/issue-999/review-evidence.tar.xz','review/site-v1-20261002-v7-captures/archive.md','review/site-v1-20261002-v7-index.html.gz'])
 for(const status of ['A','M','D'])run(`${status}-supported-${file}`,true,[...basic(),record(file,status)]);
for(const file of ['review/issue-999/unknown.json','review/issue-999/archive-index.json.cjs','review/issue-999/runner.cjs','review/site-v1-20261002-v7-captures/runner.cjs','review/site-v1-20261002-v7-captures/archive.zip','unknown.txt','tools/quality/delivery-routing.cjs','tools/quality/source-tests.cjs','.github/workflows/site-checks.yml'])
 run(`refuse-${file}`,false,[...basic(),record(file)]);
for(const mode of ['100755','120000','160000'])run(`refuse-mode-${mode}`,false,[...basic(),record('review/issue-999/notes.md','M',mode)]);
run('rename-unknown-into-evidence-is-delete-plus-add',false,[...basic(),record('unknown.txt','D'),record('review/issue-999/notes.md','A')]);
run('rename-public-into-evidence-is-delete-plus-add',false,[...basic(),record('site/engine/app.cjs','D'),record('review/issue-999/notes.md','A')]);
const policy='.github/acceptance/issue-999.json';
const original="env.ACCEPTANCE_POLICY == '.github/acceptance/issue-189.json'";
const extended=workflow.replaceAll(original,original+" ||\n          env.ACCEPTANCE_POLICY == '"+policy+"'");
const policyRecords=[...basic(),record(policy,'A'),record('.github/workflows/issue-acceptance.yml')];
run('workflow-monotonic-positive-new-policy',true,policyRecords,s=>s.candidate.owningWorkflow=extended);
for(const [name,value] of [
 ['removed-existing',extended.replace("env.ACCEPTANCE_POLICY == '.github/acceptance/issue-58.json' ||",'')],
 ['new-policy-not-added',extended.replaceAll('issue-999.json','issue-998.json')],
 ['duplicate-alternative',extended.replaceAll(original,original+' || '+original)],
 ['unknown-expression',extended.replaceAll(original,original+' && true')],
 ['pin-change',extended.replace('ubuntu-24.04','ubuntu-latest')],
 ['command-change',extended.replace('npm ci --prefix','echo omitted --prefix')],
 ['permission-change',extended.replace('contents: read','contents: write')],
 ['old-negative-change',extended.replace("github.event.pull_request.draft == false","github.event.pull_request.draft == true")],
 ['missing-workflow',null],
])run('workflow-refuse-'+name,false,policyRecords,s=>s.candidate.owningWorkflow=value);
function task(s,records){const file='tests/test_issue999_acceptance.py';records.push(record(file,'A'),record(policy,'A'),record('tools/quality/test-profiles.json'));s.candidate.registry.tests.push({path:file,language:'python',owner:'.github/ACCEPTANCE.md',lifecycle:'task-snapshot',profiles:['issue-policy'],surviving_route:policy,inputs:[file,policy]});}
run('task-row-with-matching-new-policy',true,basic(),task);
for(const [name,mutate] of [
 ['wrong-route',(s)=>s.candidate.registry.tests.at(-1).surviving_route='.github/acceptance/issue-998.json'],
 ['wrong-profile',(s)=>s.candidate.registry.tests.at(-1).profiles=['production']],
 ['policy-not-added',(s,r)=>r.splice(r.findIndex(x=>x.newPath===policy),1)],
 ['old-row-removed',(s)=>s.candidate.registry.tests.shift()],
 ['old-row-input-changed',(s)=>s.candidate.registry.tests[0].inputs.push('unknown.txt')],
 ['non-test-policy-changed',(s)=>s.candidate.registry.source_profiles.pr.shared_inputs.push('unknown.txt')],
])run('task-refuse-'+name,false,basic(),(s,r)=>{task(s,r);mutate(s,r);});
for(const side of ['base','candidate'])run(side+'-public-repository-notice',false,[...basic(),record('tools/RI-NOTICE.md')],s=>s[side].repositoryNotices.delete('tools/RI-NOTICE.md'));
run('private-repository-notice',true,[...basic(),record('tools/RI-NOTICE.md')]);
console.log(JSON.stringify({total,passed:total-failures,failures})); process.exitCode=failures?1:0;
