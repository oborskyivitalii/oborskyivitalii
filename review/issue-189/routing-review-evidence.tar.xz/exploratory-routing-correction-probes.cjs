'use strict';
// Independent charter: real-Git maintenance/refusal/operator journeys; <=300s total.
// Temporary fixture data only. No candidate source or accepted tests are edited.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const source='/workspace/scratch/2c34f552b848/issue189-checkout';
const observer=require(source+'/tools/quality/delivery-observation.cjs');
const start=Date.now(),rows=[];
const git=(root,...args)=>cp.execFileSync('git',args,{cwd:root,encoding:'utf8',stdio:['ignore','pipe','pipe'],timeout:15000}).trim();
const write=(root,file,text)=>{const p=path.join(root,file);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,text);};
function run(name,before,after,expected){
  if(Date.now()-start>240000)throw Error('charter deadline');
  const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'independent-route-'));
  try{
    git(temporary,'init','-q');git(temporary,'config','user.name','Offline QA');git(temporary,'config','user.email','qa@example.invalid');
    for(const file of observer.policyFiles)write(temporary,file,fs.readFileSync(path.join(source,file)));
    before?.(temporary);git(temporary,'add','.');git(temporary,'commit','-qm','Independent base fixture');const base=git(temporary,'rev-parse','HEAD');
    after(temporary);git(temporary,'add','-A');git(temporary,'commit','-qm','Independent candidate fixture');const head=git(temporary,'rev-parse','HEAD');
    const result=observer.selection(temporary,base,head);
    rows.push({name,expected,observed:result.repositoryOnly,pass:result.repositoryOnly===expected,technicalRepository:result.technicalRepository,control:result.analysis.control,analysis:result.analysis.status,rejected:result.technical.rejected,hosted:result.obligations.filter(r=>r.category==='hosted').map(r=>({id:r.id,required:r.required,state:r.state,reason:r.reason})),required:result.obligations.filter(r=>r.required).map(r=>r.id)});
  }catch(error){rows.push({name,expected,error:error.message,pass:false});}
  finally{fs.rmSync(temporary,{recursive:true,force:true});}
}
const addMaint=r=>write(r,'review/issue-999/archive-index.json','{}\n');
run('archive evidence add',null,addMaint,true);
run('historical gallery deletion',r=>write(r,'review/site-v1-20261002-v7-captures/index.webm','retained old bytes'),r=>fs.unlinkSync(path.join(r,'review/site-v1-20261002-v7-captures/index.webm')),true);
run('archive plus unknown nearby JSON',null,r=>{addMaint(r);write(r,'review/issue-999/nearby.json','{}\n');},false);
run('archive plus site runtime edit',null,r=>{addMaint(r);write(r,'site/engine/new.cjs','throw Error("changed")\n');},false);
run('archive plus source selector edit',null,r=>{addMaint(r);write(r,'tools/quality/source-tests.cjs','throw Error("changed")\n');},false);
run('runtime moved to historical evidence',r=>write(r,'site/engine/active.cjs','old runtime\n'),r=>{write(r,'review/issue-999/runtime-proof.json','old runtime\n');fs.unlinkSync(path.join(r,'site/engine/active.cjs'));},false);
run('executable archive index mode',null,r=>{addMaint(r);fs.chmodSync(path.join(r,'review/issue-999/archive-index.json'),0o755);},false);
run('owning workflow command mutation',null,r=>{addMaint(r);const f='.github/workflows/issue-acceptance.yml';write(r,f,fs.readFileSync(path.join(r,f),'utf8').replace('npm ci --prefix','echo removed --prefix'));},false);
run('repository component notice',null,r=>write(r,'tools/RI-NOTICE.md','updated repository notice\n'),true);
run('public provenance notice from base',r=>{const f='site/rights.json',v=JSON.parse(fs.readFileSync(path.join(r,f)));v.notices[0].bases.push('ri-component');write(r,f,JSON.stringify(v));},r=>write(r,'tools/RI-NOTICE.md','updated repository notice\n'),false);

run('executable evidence deleted from base',r=>{write(r,'review/issue-999/archive-index.json','#!/bin/sh\nexit 0\n');fs.chmodSync(path.join(r,'review/issue-999/archive-index.json'),0o755);},r=>fs.unlinkSync(path.join(r,'review/issue-999/archive-index.json')),false);
run('evidence executable mode-only change',r=>write(r,'review/issue-999/archive-index.json','{}\n'),r=>fs.chmodSync(path.join(r,'review/issue-999/archive-index.json'),0o755),false);
run('ordinary repository documentation stays lightweight',null,r=>write(r,'README.md','ordinary repository documentation\n'),true);
for(const row of rows){
  if(!row.error && row.expected===false){
    row.hostedRefusalPass=row.hosted.every(r=>r.required===true);
    row.pass &&= row.hostedRefusalPass;
  }
  if(['archive evidence add','historical gallery deletion'].includes(row.name)){
    row.retainedSourceGatesPass=['R-PYTHON','B-SECURITY','B-ADVISORIES','O','ADMISSION'].every(id=>row.required.includes(id));
    row.pass &&= row.technicalRepository===true && row.retainedSourceGatesPass;
  }
  if(row.name==='ordinary repository documentation stays lightweight')row.pass &&= row.technicalRepository===false && !row.required.includes('B-SECURITY');
}
for(const [name,head,expected] of [
  ['unchanged original1746 prospective maintenance source','1746a7afc1698502d95a426f4b75927b9fbce0f9',true],
  ['current enabling classifier delta cannot self-activate','dba309b4f5e7e58369dd4e3072663cda3e626a9b',false]
]){
  const result=observer.selection(source,'ca756417590b9176f9fc33428321ffe1f64158cc',head);
  rows.push({name,expected,observed:result.repositoryOnly,pass:result.repositoryOnly===expected,technicalRepository:result.technicalRepository,control:result.analysis.control,rejected:result.technical.rejected,required:result.obligations.filter(r=>r.required).map(r=>r.id)});
}
console.log(JSON.stringify({candidate:'dba309b4f5e7e58369dd4e3072663cda3e626a9b',charter:'Affected correction rewalk: prior maintenance/mixed/public paths; executable evidence A/M/D refusal with hosted flags; archive-only source allocation; ordinary-docs allocation; original1746 and enabling bootstrap',elapsedMs:Date.now()-start,rows},null,2));
if(rows.some(r=>!r.pass))process.exitCode=1;
