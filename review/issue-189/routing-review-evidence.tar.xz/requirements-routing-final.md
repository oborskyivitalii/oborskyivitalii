# Requirements & Acceptance — amended routing candidate review

2026-11-10. Same-role continuation `/root/issue189_route_requirements` after requirements preflight and the explicit maintainer amendment. This is the first final judgment on candidate979e; no current peer output or evidence archive content was read. The preceding reports are preserved. Provider internals remain unknown.

## Verdict

**Blocked for one reproducible source-obligation regression in a newly supported maintenance-only case.** The intended mixed189 route works prospectively and bootstrap remains correctly full; all70 maintained observer/App tests pass. However, archive-only maintenance can omit hosted work while also losing the amendment's mandatory enduring Python/security/advisory obligations. The representative mixed fixture does not detect that case. Correct that allocation and add a meaningful independent archive-only positive case before final acceptance.

The maintainer-authorized scope supports replacing189's website-building owning BASIC with the maintained observer/admission suites. The policy does not purport to remove global source/style checks: Basic format/architecture/lint/affected source, RI/coupling, enduring Python/security/advisories and owning checks keep their existing independent workflow owners. The named unittest wrapper calls both real suites and propagates exit/failure/skip results. This is a relevant AC05 allocation, not a performance threshold waiver. It cannot activate the classifier, pass a hosted failure or supply review/merge decisions.

## Findings

**High R-F01 — Archive-only service maintenance loses required source gates.** `tools/quality/delivery-routing.cjs:111` now classifies supported historical resources as ordinary D01. `technicalSelection()` lines726–732 discards ordinary repository records before the repositoryEvidence technical branch at733. For a regular deletion of `review/site-v1-20261002-v7-captures/index-motion.webm`, own isolated source probe returns:

- analysis complete/repository/control=false; no required hosted obligations;
- technical eligible=false, technical=[], rejected=[], additiveRegistry=true;
- R-PYTHON.required=false; no B-SECURITY or B-ADVISORIES obligations.

This exercises the actual exported routing implementation with unchanged valid endpoint registry/rights snapshots and an isolated synthetic regular deletion; it is not a native Git/CI delivery claim. In actual `selection()`, the complete ordinary repository result still makes repositoryOnly true and uses the older repository obligations. The newly supported file therefore gains the hosted omission without the complete source allocation required by `amended-requirements.md` and the guide's new maintenance paragraph. The current mixed fixture includes executable/scanner/owning controls, so it sets technical=true and masks this failure.

Affected requirement: amended AC05 source/security/Python preservation, not archive deletion eligibility. Smallest treatment: ensure newly admitted maintenance-only evidence unions receive the promised technical source obligations while retaining legacy documentation-only compatibility. Add an archive-only real-Git positive allocation case asserting required Python/security/advisory/source/RI/owning obligations and hosted inapplicability. Reuse the unchanged mixed/refusal/App cases; no browser measurement is warranted.

**Medium R-F02 — Canonical formatting pending on979e.** `.github/ri-ci-map.json` contains whole-file mechanical expansion of unchanged arrays; own parsed comparison confirms all nonidentity semantics exactly equal1746. The existing CS05 exception names the RI producer/test files, not this map. The new Python wrapper is also visibly outside maintained formatting. After my notification, the orchestrator reported actual pinned formatter failures on exactly this map and `tests/test_issue189_acceptance.py`, and committed to restoring canonical formatting with JSON/Python AST parity. That is reported planned correction, not executed evidence accepted by this review. Prefer that routine correction over expanding the maintainer exception. Final source/format readback remains required; do not describe979e as formatter-clean.

No additional material requirements defect established in this bounded final pass. I examined endpoint provenance, new evidence families, monotonic owning workflow predicates, task-row routing, source/security consumers and exact-head admission boundaries. The rights proof correctly requires every basis referencing the notice to be absent from public-record bases, includes direct sourceGroups/public-notice paths, and uses both endpoint snapshots. Existing assets/retained paths are constrained by their unchanged source owners; arbitrary manifest key guesses are not evidence of a valid bypass. Semantic scanner disposition acceptance remains a separate source-bound review obligation.

## Actual observations and AC linkage

| Requirement/AC05 addition | Actual check or independent observation | Result on979e |
| --- | --- | --- |
| Supported mixed service maintenance omits hosted work | Maintained real-Git observer fixture and own actual ca756→1746 selector replay | PASS prospectively: technicalRepository/repositoryOnly=true;0 unresolved/rejected; O, App, R-PYTHON, SECURITY and ADVISORIES required; hosted inapplicable. |
| Newly supported archive-only maintenance keeps source gates | Own isolated exported-routing probe described above | FAIL R-F01: hosted omitted but Python/security/advisories absent. |
| Classifier cannot activate itself | Own amended selector replay ca756→979e | PASS refusal: repositoryOnly=false, technicalRepository=false; rejects two routing guides and routing/observation implementation; hosted remains required. Actual unchanged protected-main route remains authoritative. |
| Both endpoint public/rights/content/unknown/mode/registry refusal | Actual maintained observer suite, including unchanged prior negative cases and new notice/public basis and mixed maintenance cases |70/70 combined observer/App suite passes; finite fixture coverage, not exhaustive dependency proof. |
| Exact reviewed_sha and genuine App evidence | Maintained real-Git App source evidence/control cases; admission source unchanged | Eligible maintenance does not request hosted API evidence; wrong/missing reviewed head and failed source still refuse. No native App invocation performed. |
| Owning BASIC allocation | Policy BASIC→named unittest→two maintained real-Git suites; actual same suites executed independently | Applicable and faithful to source-only intent. No site build delegated by this method. Global required checks are still separate owners, not inferred passed. |
| Stable AC mapping and RI/CI source linkage | `issue_acceptance.py validate --policy .github/acceptance/issue-189.json`; `check_ri_ci.py verify` | Both exit0; AC01–05 stable; coupling17checks/19layers passes, explicitly no live GitHub verification. |
| AC01–04 original RI/archive/capacity promises | Prior implementation bytes reused only where unchanged; amended MUTABLE closure inspected | No new full RI/archive/security acceptance campaign by this role. Existing caps and archive recovery checks remain; whole AC completion not established. |
| CS05 source formatting | Parsed nonidentity RI-map comparison; reported actual pinned formatter failure and planned correction | Pending R-F02; no new exception authorized or requested. |
| Native activation/delivery | Protected bootstrap, genuine source-only admission, exact source/native checks, normal merge | NOT OBSERVED. Original staging failure remains failed; no production or transition measurements. |

## Identities and executed checks

Protected base `ca756417590b9176f9fc33428321ffe1f64158cc`; preceding candidate `1746a7afc1698502d95a426f4b75927b9fbce0f9`; inspected local candidate `979e15899c71ad8633649bcb34afba385bdf4665`, tree `f060d85be1f7a3923308851ae10f7156192291de`. Exact Git identity and clean status verified before/after review checks. Candidate unpublished/unactivated per supplied brief; live GitHub not independently queried.

Implementation packet SHA256 `246416d08da5300f04eecd902b9b7049e9c2dadf8872b6f275ae1ead5014fe9d`: all32 entries match sizes/hashes. Common prompt `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. Candidate routing SHA256 `4b303fef277f49a3ffccffeb330541b4b77c3079a02fc2af6dc36d9dce54100c`; observation `633d824a714e221c8d3591228c5912e0c1f6657e68668d7746464a260b30e6b8`; policy `7c01e1b38a20b507c239f83cb62f39ff234ddad736f27202059b864f5eea8b1f`. Additional source identities are in own raw probe receipt.

Executed `node --test --test-reporter=tap tests/delivery-observation.test.cjs tests/delivery-admission.test.cjs`: exit0,70tests/70pass/0fail/0skip/0cancel/0todo,20.2seconds. Full own TAP is `requirements-final-route-tests.tap`. Policy validation exit0; coupling verify exit0; actual selector replays and isolated maintenance-only allocation probe retained in `requirements-final-raw-probes.txt`. Each process was bounded<=300seconds; no test source was authored or edited. No network/browser/workflow/security campaign/external write/delegation; archive contents were not opened (manifest byte hashing only). No parent raw logs or peer verdict used as acceptance. Guide/owner reads were focused on relevant changed scope and unchanged consumers.

Next gate: retain this first final result and original probe, correct R-F01 and canonical formatting, then provide exact changed-source identities and affected check outputs for actual same-role re-review. Do not broaden to transition diagnosis before the requested routing correction is reviewed. Whole ACs remain open until all required native/semantic/delivery gates are verified.
