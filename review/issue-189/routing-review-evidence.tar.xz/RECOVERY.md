# Routing evidence recovery

First candidate979e, corrected candidate dba309b4, their exact source trees and all prior local correction commits are retained in local-reviewed-candidates.bundle. This is a thin Git bundle requiring the existing published1746 commit in the repository. Verify with git bundle verify, then fetch bundle HEAD into a new evidence ref, never overwrite a working branch. Original first failures/reviewer judgments and later corrections are separate files; eventual passes do not erase them.

The corrected source reports bind to dba309b4:72/72 maintained Node,45/45 owning checks,567-file canonical format, coupling17, full source-security/advisory/lint and architecture/style/RI. Current main has not activated the classifier; prospective candidate-code selection is not trusted admission. All scan raw hashes are independently retained. No browser transition run or full hosted staging retry was performed during this routing iteration.
