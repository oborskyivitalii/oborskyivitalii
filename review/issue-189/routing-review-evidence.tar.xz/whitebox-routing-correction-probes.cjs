"use strict";
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process'),assert=require('node:assert/strict'),Module=require('node:module');
const root='/workspace/scratch/2c34f552b848/issue189-checkout';
const prefix='/workspace/scratch/2c34f552b848/issue189-t06/route-review/whitebox-routing-correction-probes-';
const observer=require(root+'/tools/quality/delivery-observation.cjs');
const git=(cwd,...args)=>cp.execFileSync('git',args,{cwd,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();
function pinned(name,revision,overrides={}) {const file=root+'/tools/quality/'+name;const code=git(root,'show',revision+':tools/quality/'+name);const m={exports:{}};const native=Module.createRequire(file);new Function('require','module','exports','__filename','__dirname',code)((id)=>overrides[id]||native(id),m,m.exports,file,path.dirname(file));return m.exports;}
const prior='979e15899c71ad8633649bcb34afba385bdf4665';
const previousRouting=pinned('delivery-routing.cjs',prior);
const previous=pinned('delivery-observation.cjs',prior,{'./delivery-routing.cjs':previousRouting});
let total=0,failed=0,demonstratedPriorFailures=0;
function write(dir,file,value='fixture\n'){fs.mkdirSync(path.dirname(path.join(dir,file)),{recursive:true});fs.writeFileSync(path.join(dir,file),value);}
function commit(dir){git(dir,'add','-A');git(dir,'commit','-qm','White-box isolated fixture; Refs #189');return git(dir,'rev-parse','HEAD');}
function view(p){return {repositoryOnly:p.repositoryOnly,technicalRepository:p.technicalRepository,rejected:p.technical.rejected,control:p.analysis.control,obligations:Object.fromEntries(p.obligations.filter(x=>['R-PYTHON','B-SECURITY','B-ADVISORIES','H','H-PREVIEW','O','ADMISSION'].includes(x.id)).map(x=>[x.id,x.required])),obligationIds:p.obligations.map(x=>x.id)};}
function check(name,before,after,expect,{oldMustFail=false}={}){const dir=fs.mkdtempSync(prefix);try{
 git(dir,'init','-q');git(dir,'config','user.name','White-box fixture');git(dir,'config','user.email','fixture@example.invalid');git(dir,'config','core.autocrlf','false');
 for(const file of observer.policyFiles)write(dir,file,fs.readFileSync(path.join(root,file)));
 before?.(dir);const base=commit(dir);after(dir);const head=commit(dir);
 const a=view(previous.selection(dir,base,head)),b=view(observer.selection(dir,base,head));
 let pass=true,error=null;try{expect(b);assert.equal(new Set(b.obligationIds).size,b.obligationIds.length);if(oldMustFail){let rejected=false;try{expect(a);}catch{rejected=true;}assert.equal(rejected,true,'fixture must detect prior integration defect');demonstratedPriorFailures++;}}catch(e){pass=false;error=e.message;failed++;}
 total++;console.log(JSON.stringify({name,pass,error,previous:a,current:b}));
 }finally{fs.rmSync(dir,{recursive:true,force:true});}}
function technical(p){assert.equal(p.repositoryOnly,true);assert.equal(p.technicalRepository,true);for(const id of ['R-PYTHON','B-SECURITY','B-ADVISORIES','O','ADMISSION'])assert.equal(p.obligations[id],true,id);for(const id of ['H','H-PREVIEW'])assert.equal(p.obligations[id],false,id);}
function full(p){assert.equal(p.repositoryOnly,false);for(const id of ['H','H-PREVIEW','R-PYTHON'])assert.equal(p.obligations[id],true,id);}
const cases=['review/issue-999/archive-index.json','review/issue-999/selected-files.json','review/issue-999/review-evidence.tar.xz','review/site-v1-20261002-v7-captures/ARCHIVE.md','review/site-v1-20261002-v7-captures/index-motion.webm','review/site-v1-20261002-v7-index.html.gz'];
for(const file of cases)for(const op of ['A','M','D'])check(op+'-'+file,dir=>{if(op!=='A')write(dir,file);},dir=>{if(op==='D')fs.unlinkSync(path.join(dir,file));else write(dir,file,'changed\n');},technical,{oldMustFail:true});
for(const op of ['A','mode','D']){const file='review/issue-999/archive-index.json';check('executable-'+op,dir=>{if(op!=='A')write(dir,file);if(op==='D')fs.chmodSync(path.join(dir,file),0o755);},dir=>{if(op==='D')fs.unlinkSync(path.join(dir,file));else{write(dir,file,'#!/usr/bin/env node\n');fs.chmodSync(path.join(dir,file),0o755);}},full,{oldMustFail:true});}
for(const file of ['README.md','review/issue-999/notes.md'])check('ordinary-'+file,null,dir=>write(dir,file),p=>{assert.equal(p.repositoryOnly,true);assert.equal(p.technicalRepository,false);assert.equal(p.obligations['R-PYTHON'],false);assert.equal(p.obligations['B-SECURITY'],undefined);assert.equal(p.obligations.H,false);});
for(const file of ['tools/quality/delivery-routing.cjs','unknown.txt','site/templates/pages/writing/main.html'])check('bootstrap-unknown-public-'+file,null,dir=>write(dir,file,'changed\n'),full);
for(const side of ['base','candidate']){const file='review/issue-999/archive-index.json';const expose=dir=>{const m=JSON.parse(fs.readFileSync(path.join(dir,'site/rights.json')));m.bases['linked-metadata'].provenance.push(file);write(dir,'site/rights.json',JSON.stringify(m));};check('rights-'+side,dir=>{write(dir,file);if(side==='base')expose(dir);},dir=>{write(dir,file,'changed\n');if(side==='candidate')expose(dir);},full);}
console.log(JSON.stringify({total,passed:total-failed,failed,demonstratedPriorFailures}));process.exitCode=failed?1:0;
