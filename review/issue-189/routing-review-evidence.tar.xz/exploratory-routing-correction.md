# Exploratory / Interaction QA — affected correction

Verdict: **EX-R01 resolved on the corrected candidate within this bounded review; no new blocking finding.** Archive-only source obligations and ordinary-document allocation also behaved as specified. No live activation/admission, security-campaign completion, browser/performance or whole-AC acceptance follows.

## Identity and exposure

Same nonauthor role/task `/root/issue189_route_exploratory`, post-first correction continuation. This is not a new fresh-first judgment. The original `exploratory-routing-review.md`, first failing probe JSON and two failing diagnostic observations remain unchanged. Correction input explicitly described both original technical defects and the subsequent scanner/format changes; that reconciliation exposure is disclosed. No other current role reports or parent scratch notes were read.

Clean local candidate observed before/after execution: `dba309b4f5e7e58369dd4e3072663cda3e626a9b`, tree `e932272967ba7f12ba02e942e33e1fce18fa135f`; compared actual `979e15899c71ad8633649bcb34afba385bdf4665`→candidate diff. Correction packet SHA256 `303cfc21aeff84bbb3ee88b84f5fa95d8e1bf5b74dad9c2f9eb685d9e4171113`, every listed digest matched. Common/role contracts remain those identified in the first report. Actual launch receipt belongs to the orchestrator; provider internals remain unknown.

Read correction brief/packet, own first evidence and actual changed classifier/observer/tests/guide and formatting sources. No implementation/test/config edits, external writes, network, CI, browser or delegation. Temporary real-Git fixtures were removed; only separately named own correction outputs were written.

## Charter and observations

The affected charter rewalked the previous maintenance and mixed/public cases, executable evidence addition/mode/deletion refusal including the actual hosted flags, archive-only Python/security/advisory allocation, ordinary-document allocation and prospective-versus-active source distinction. Probes remain bounded by240seconds per campaign and15seconds per Git child; no process exceeded300seconds.

`exploratory-routing-correction-probes.cjs` / `.json`: **15/15 independent real-Git journeys pass**, 3,137ms.

| Journey | Expected and observed |
| --- | --- |
| Regular archive-index addition and historical gallery deletion | Repository-only and technical=true; Python, security, advisories, owning and admission required; hosted work omitted |
| Executable evidence addition,100644→100755 mode transition and deletion from executable base | Both repository flags false; technical rejection retained; hosted obligations required |
| Unknown nearby JSON, runtime edit, source-selector edit or workflow-command mutation mixed with maintenance | Full/conservative refusal, hosted obligations required |
| Runtime moved to a supported historical evidence name | Old runtime endpoint retained and refused |
| Repository-only notice versus base-side public provenance | Technical repository selection versus full hosted refusal respectively |
| Ordinary README edit | Repository-only, technical=false; retains prior lightweight source allocation |
| Main→unchanged original1746 delta, evaluated by corrected classifier | Prospective supported technical repository route |
| Main→current enabling classifier delta | Repository-only=false, technical=false; cannot activate its own exemption |

Existing maintained observer/admission suites were rerun because the correction changes selection and obligations: **72/72 pass, 0fail/cancelled/skipped/todo**, 21,312ms. Raw `exploratory-routing-correction-probes-suites.tap` retains the actual accounting. New candidate regressions cover archive-only allocation and executable evidence A/mode/D refusal; the assertions inspect both repository flags and hosted-required flags. These are source/fixture observations, including existing mocked App/failure paths; no native App dispatch was performed.

## Why EX-R01 is resolved

`delivery-observation.cjs` now first analyzes the complete delta without narrowing obligations. It calculates repository eligibility only after the technical disposition, requiring no technical rejection for the ordinary fallback; it narrows obligations once, after that result. Therefore the executable evidence's technical rejection cannot coexist with the earlier ordinary hosted omission. The independent100755 addition/mode/deletion journeys reproduce the intended conservative result on both endpoint directions. The original failures are historical evidence, not reclassified as passing.

`delivery-routing.cjs` evaluates newly supported technical evidence before ordinary classification. The independent archive-only addition/deletion journeys now retain `R-PYTHON`, `B-SECURITY`, `B-ADVISORIES`, `O` and `ADMISSION`; ordinary README remains lightweight. `controlReviewRequired` now reflects actual control paths rather than treating a non-executable archive as an executable control. This preserves the distinction between hosted dependency and executable trust.

Regression allocation is concrete: the two new maintained cases live in `tests/delivery-observation.test.cjs`, exercised by the existing source selection/CI route and owning `test_source_only_maintenance_routing` method. The independent probes are review evidence, not newly accepted repository tests or a new browser campaign.

## Additional changed-source checks

The three `.exec`→`.match` substitutions use non-global literal regular expressions. Source inspection plus14 boundary comparisons across the three expressions found identical results; recorded in `exploratory-routing-correction-probes-regex.json`. No scanner rule/policy waiver is part of that semantic check. The separate full security/advisory campaign's actual completion was not observed by this role.

`exploratory-routing-correction-probes-parity.json` records unchanged Python AST for canonicalized `test_issue189_acceptance.py`. The first JSON parsed-value comparison was unequal; this was diagnosed rather than called formatting parity. The only changed top-level RI/CI-map field is regenerated `reviewed_source_identity`; all remaining policy values compare equal. That distinction is retained in the evidence. Whole JSON equality is not claimed after source identity regeneration.

## AC impact and limits

The previously identified **AC02 mode-refusal / AC05 allocation** correction is supported by current-source independent observations. The archive-only source gate gap described in correction input is likewise resolved in the observed journeys. **AC03** eligibility/recovery and **AC04** complete final accounting remain separate owner gates; classification alone grants no archive deletion approval. All whole ACs still require their complete actual evidence.

The guides continue to distinguish explicit hosted inapplicability, protected bootstrap, exact control-source review and live App authority. The actual current-delta refusal supports that wording; local prospective eligibility of1746 is not an activated protected-main result. No new operator-guidance blocker was found. Existing security/advisory/native CI, protection, delivery/merge and performance gates retain their own status. Browser transitions remain deferred by user scope; no website/device result is inferred from these tooling checks.
