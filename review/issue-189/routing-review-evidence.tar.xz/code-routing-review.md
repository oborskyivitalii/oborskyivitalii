# Independent Code / Artifact review — first judgment

Verdict: **no blocking correctness finding in the amendment reviewed**. No source changes requested. This is bounded code-review evidence for issue189/PR190 AC05, not closure, hosted acceptance, classifier activation or merge permission.

## Identity and independence

- Reviewer: `/root/issue189_route_code`, distinct nonauthor Code role, first judgment.
- Repository checkout: `/workspace/scratch/2c34f552b848/issue189-checkout`.
- Candidate: `979e15899c71ad8633649bcb34afba385bdf4665`; tree `f060d85be1f7a3923308851ae10f7156192291de`.
- Preceding candidate: `1746a7afc1698502d95a426f4b75927b9fbce0f9`; protected-base reference supplied: `ca756417590b9176f9fc33428321ffe1f64158cc`.
- Candidate checkout was clean at initial and final identity reads. No source/test/config edits were made.
- Supplied packet SHA256: `246416d08da5300f04eecd902b9b7049e9c2dadf8872b6f275ae1ead5014fe9d`, independently matched. All31 other listed source/brief/owner entries matched their packet bytes/hash. The archive entry was deliberately not opened or independently hashed, to preserve the explicit first-review boundary.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code prompt SHA256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Reviewed binary-form diff excluding the explicitly prohibited archive has SHA256 `1b2b8fb4eb8538adb0932a3457eee561a931cae5ac86e2d12f681e7ebf215166` (`git diff --binary 1746a7af... HEAD -- . :!review/issue-189/routing-review-evidence.tar.xz`).
- No current peer report, parent scratch note, evidence archive or private conversation was consumed before this judgment. The candidate's versioned analysis amendment was read as changed product content, not as approval. Provider model/context internals and the orchestrator's actual launch-acceptance record remain unknown to this reviewer; this report does not attest them.

## Inspected scope and reasoning

Read the supplied primary owner/AC text and explicit maintainer amendment; root README/AGENTS/REPOSITORY-MAP/MEMORY/CONTRIBUTING, common/Code prompts, acceptance, site source contract, applicable CODE-STYLE and routing/staging contracts. The map lists only root AGENTS as applicable. Inspected all15 amendment paths except prohibited archive payload, including generated/catalog/coupling companions, source/test/policy/guide deltas. Independently followed unchanged `delivery-git`, observer, admission, source selection, local repository delivery, rights-manifest/compiler and workflow consumers.

- The new hosted-dependency rejection runs before ordinary/technical admission and examines each actual endpoint. Public provenance and authored-content inputs cannot be hidden by a repository evidence name. Repository-component notices require absence of shared public bases and direct public scope; manifest changes themselves retain full routing.
- Ordinary non-executable review/history resources retain the existing repository route. Source/control maintenance retains technical routing, regular100644 restrictions, source allocation, enduring Python, locked security/advisories, RI/owning and App admission. Archive routing supplies no deletion/recovery/rights eligibility decision.
- Registry comparison preserves every old row and every non-test field; added task snapshots must use the matching newly added owning policy, `issue-policy` profile and regular added test. Existing task modifications remain owning-only through the unchanged selector. Full registry validation remains an actual consumer obligation.
- Workflow comparison supports only positive policy equality/OR alternatives with all prior alternatives preserved and additions tied to new policy files. Command/job/permission/pin changes and unavailable workflow inputs refuse this exemption. The algorithm compares normalized complete workflow text, rather than merely finding an allowed predicate somewhere.
- The App collector uses protected selection, exact control-head owner attestation and three genuine current source/navigation/owning workflow results for repository work. The new fixture exercises that real collector and source-failure propagation; it does not replace admission with a classifier assertion. Classifier/source-runner/admission/publication controller edits still refuse their own exemption.
- The issue189 BASIC now invokes maintained real-Git observer/admission suites. Existing source/style owners remain mapped independently. This matches the authorized omission of website building for source-only maintenance; it does not waive actual source/native/owner checks.
- CS01/04/05/07/08/09/10 were considered: changes remain in their canonical owner, add no runtime/build initialization dependency, preserve bounded Git/parser checks and use meaningful union/refusal tests. The style guard proves only its advertised subset. Coupling-map identity serialization is deterministic producer output; no additional mechanical source-format exception is inferred.

## Actual independent executions

Environment observed: Node v24.22.1, Python3.12.14, Git2.52.0. No network, browser, CI or external writes were performed. All processes completed within300seconds.

| Check | Result | Own raw evidence |
| --- | --- | --- |
| `timeout 300 node --test --test-reporter=tap tests/delivery-observation.test.cjs tests/delivery-admission.test.cjs` | exit0;70tests,70pass,0fail/cancelled/skipped/todo;20750.679185ms | `code-routing-probes.tap` |
| Independent direct boundary probes |11/11 expected outcomes: existing owning task modification; policy deletion; executable historical HTML; unknown JSON union; public notice provenance on either endpoint; missing workflow; changed command; unmatched added policy; monotonic new-policy predicate; removed prior predicate | `code-routing-probes-boundaries.json` |
| Current candidate-code selection of actual ca756→1746 Git delta | complete;0unresolved/0rejected; repositoryOnly=true; technicalRepository=true; control=true; Python/security/advisory/owning/App retained | `code-routing-probes-selection.json` |
| `python3 tools/check_code_style.py` | exit0; pass;165scanned files,0legacy occurrences | `code-routing-probes-style.txt` |
| `python3 tools/check_ri_ci.py verify` | exit0;17checks/19layers; current source digest50edb594... | `code-routing-probes-coupling.txt` |
| `timeout 300 python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify` | exit0; current generated context fresh | `code-routing-probes-ri.txt` |
| Packet source identity comparison |31/31 admitted non-archive entries match | `code-routing-probes-packet.json` |

No independent probe failed. The current candidate's source tests are the observations here; no author result is substituted for execution. Direct boundary probes are bounded review experiments, not proposed repository test additions.

## Acceptance impact and limits

AC05's amended routing/test-allocation/code-review subset is supported by the inspected implementation and these actual results. The tests preserve source failures, exact reviewed_sha and full-route unknown/public/control refusals. AC01–04 are not newly accepted by this amendment review; archive eligibility/recovery, original protected closure/caps and semantic owner decisions retain their existing independent evidence obligations. No whole AC checkbox is approved here.

The observed ca756→1746 result executes the **new candidate implementation** against immutable older endpoints. It establishes prospective routing behavior only. The candidate's own classifier/registry changes remain a bootstrap/full-route concern under the actually protected code; no self-activation was executed or claimed. Live GitHub refs/checks, genuine App issuance, protected deployment/admission and transition performance were not observed. The original stage performance failure remains unchanged. The archive payload was not inspected. No entire source/security/browser campaign, runtime coverage percentage or provider isolation guarantee follows from this review.

This first judgment is preserved before peer reconciliation; any later correction assessment must remain separate and bind its actual new source identity.
