## Original intent — 10 November 2026

The maintainer wants RI to describe the current repository, with old revision/evidence material archived, and requested deep investigation, architecture/logic, an execution plan, disputed choices and assessable ACs.

Split from #187 at the maintainer's explicit request. Original combined AC04–AC05 and the RI/archive portion of AC06 remain owned here; local AC01–AC05 below preserve those outcomes. #188 owns MEMORY lifecycle/bounds and #187 owns article motion. [Original combined intake](https://github.com/oborskyivitalii/oborskyivitalii/issues/187#issuecomment-6770665091).

## Current status — T06 hosted performance blocker, 10 November 2026

PR190 remains Ready/open/unmerged at **1746a7afc1698502d95a426f4b75927b9fbce0f9**, tree23ef14003b2d550c0783177e5581206c5442b7c3; source clean. Actual sourceCI42904711981 (eight shards and required checks), navigation42904711838 and owning42904711888 pass. Owner stage42905616039 passes all26prepublication guards including security and exact hosted/static identity, but **full/staging fails**: cold Home→Writing equivalentReadyMs **3277.1 > 3200**, excess **77.1ms**. Three other flights, functional journeys, Color smoke and both single-trial Lighthouse observations pass; these do not waive the failed gate. full/gate and merge-admission fail, stable promotion and change-admission receipt are skipped. Main/prod remain ca756417590b9176f9fc33428321ffe1f64158cc.

[Exact failure, raw artifact identity, independent diagnosis and predeclared bounded next action](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6780446284). Code and White-box independently reproduce the failure with the real unchanged validator. Site/docs/runtime/collector/pacing/budget bytes are unchanged from protected main. Cold fetch/read delay materially contributes; CPU/scheduling overhead also exists. No new RI runtime defect, purely network cause or statistical flake classification is established.

One diagnostic cold/warm Writing pair was planned, with unchanged helper/browser/390px/CPU×4/budgets and stop-on-setup-blocker. Actual pinned Playwright launch failed because chromium_headless_shell-1243 is absent locally. **Zero diagnostic transitions measured; no system-browser substitution, full rerun or acceptance claim.** Next execution needs the pinned browser and permitted access to the same immutable deployment; preserve the original failure. Diagnostic results cannot replace native staging acceptance.

All whole AC01–AC05 remain unchecked until complete final acceptance. Inputs **239,105,584bytes**, headroom **10,894,416bytes**, original five caps unchanged. Separate owners188/187 remain pending; no production release.

## Historical source-admission checkpoint — superseded delivery status



Current PR190 head **1746a7afc1698502d95a426f4b75927b9fbce0f9**, tree23ef14003b2d550c0783177e5581206c5442b7c3, Ready for actual new-sourceCI. Exact clean navigation121/121, owning45/45 and full pinned source-security pass. Semgrep376files/0findings/errors; Bandit48raw/48reviewed/0untriaged; secrets1,737textfiles. [Complete source results, retained failed local history attempt and canonical139-object environment repair,6parts](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6779638374). Inputs239,105,584bytes/headroom**10,894,416**; all caps unchanged, inherited parsed-ledger margin218bytes retained.

Actual CI on13c exposed the missing global task-registry companion, corrected at4a. Native sourceCI/navigation/owning on4a passed, then first owner stage42899614004 failed security before upload (25/26preflightpassed). Concrete local same-engine diagnosis found108untriaged public identity candidates; all were independently recomputed. The exact109-row correction adds108dispositions plus a separately detected pinned-proof checksum, preserving all3,681 predecessor records/metadata and other ledgers/scanner protections. Four actual affected reviewer continuations accepted the correction; source/raw failures/probes and first judgments remain retained in [8-part security evidence](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6779489837). No native detailed-engine firstfailure proof is invented.

Current source-specific integrity/review/eligibility/capacity/navigation evidence is reconciled only within its documented bounded scope. **DELIVERY/MERGE pending:** protected-base conservative website/control lane,100obligations/38unresolved, no repository-only exemption. Authentic current CI/preview, full owner staging, reviewed_sha/control admission and normal merge remain required. PR unmerged; main/productionca756417 unchanged. CS05 remains accepted; all wholeACs remain unchecked until complete applicable evidence is recorded. No production release requested.

## Historical whole-PR review checkpoint — before actual CI

**[Повний змістовний звіт: усі49шляхів PR190](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6778454235)** · [Versioned report](https://github.com/oborskyivitalii/oborskyivitalii/blob/13cdbd0cfa4ca566185f6bdcb17722ae2833271f/review/issue-189/2026-11-10-analysis.md?plain=1#L715).

Four distinct fresh none-fork Requirements/Code/White-box/Exploratory first reviews examined the complete main→c9ad37c7 delta, actual sources/oracles and bounded fresh fault/recovery/operator scenarios. **No new reproducible technical blocker or correctness defect found.** All19 originals compare byte-for-byte to actual main blobs;3 complete galleries retain all168 examined local links. The five other open-PR heads still match the pinned primary consumer-audit heads.

Fresh clean reviewed-source checks:45/45 policy,95 additional Python executions (two overlap policy checks),567-source formatter,48-source Python lint and fresh48-findings/0-errors Bandit scan with16-files/48reviewed/0untriaged admission. Source/no-fault claims are bounded; browser playback/complete hosted/security-advisory/eligibility and merge attestations are not inferred.

Current published head **13cdbd0cfa4ca566185f6bdcb17722ae2833271f**, treeb75fd67d23fc1102904f8f811cbe01b2922b84df, adds only the verbatim reviewed report, handoff pointer and generated RI identity. No implementation/tests/workflow/policy/archive bytes changed during this review. Final exact clean-head policy45/45 passes after publication; inputs239,022,868bytes leave **10,977,132bytes** under unchanged caps.

Two retained cautions: inherited secrets-ledger per-file margin218bytes; scoped hit pages do not cap all metadata or speed up full verification. These are not introduced regressions. The actual delivery blocker remains unmet full raw-head CI/hosted/control/admission/merge obligations: latest source/navigation/owning jobs are skipped while Draft; final protected selector remains full/control,37unresolved endpoints/100obligations. CS05 remains explicitly accepted.

PR190 stays Draft/unmerged; all whole AC01–05 remain unchecked. Review request did not execute Ready/staging/merge/production. Recommendation: continue agreed T06 without an additional source refactor; reconcile current semantic/owner evidence and execute the authentic full route.

## CS05 decision checkpoint —10November2026

**The maintainer's “Залишай” is applied:** keep both RI formatting deltas inside PR190. The dated two-file exception below and PR citation resolve CS05; do not request the same permission again.

Current receipt/handoff source **c9ad37c7c67516f02e95a954e4f882ae63ad54d1**, tree **0f57cf8592069042a23894c3882f3cf4dba073a5**. Only MEMORY, the dated decision receipt and generated RI identity changed. [Independent receipt review, exact clean-source45/45 policy checks, raw result and protected-base reselection](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6778087054). All original code/test/workflow/policy/archive bytes are unchanged from the four-role-reviewed T05 implementation.

Final inputs239,008,186bytes; headroom **10,991,814bytes**, all five caps unchanged. T06 full/control route and unmet semantic/source/hosted/admission/merge decisions remain pending. PR190 stays Draft/unmerged; all whole AC01–AC05 remain unchecked.

## T05 technical checkpoint — 10 November 2026

[Exact clean-source checkpoint, raw checks, actual protected selection and final review](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6777138904) · [Draft PR190](https://github.com/oborskyivitalii/oborskyivitalii/pull/190) · [owning policy](https://github.com/oborskyivitalii/oborskyivitalii/blob/390076339875e2939a34b733b0f620c942210229/.github/acceptance/issue-189.json) · [versioned report](https://github.com/oborskyivitalii/oborskyivitalii/blob/390076339875e2939a34b733b0f620c942210229/review/issue-189/2026-11-10-analysis.md).

**Implementation T01–T04 and bounded T05 technical preparation are committed.** Exact source **390076339875e2939a34b733b0f620c942210229**, tree **915f92cc29b3d90e1e34b2c18363c24f3f8f3117**, native source clean before/after final checks. The14,272-byte map, complete inventory and compatible scoped CLI remain; frozen19 originals remain losslessly recoverable in3 original ZIPs.

The versioned policy maps AC01–AC05 to45 unique checks and seven explicit external gates. Two owning-only archive/protection/capacity methods protect original identities, complete base closure, narrow Bandit/workflow exceptions and actual final budgets. Actual review corrected missing issue189 dependency bootstrap and CRLF normalization in the workflow protection oracle. Exactly four existing workflow conditions now include189; commands/pins/actions/jobs/permissions/budgets remain unchanged.

**Actual current-source results:**45/45 policy checks pass (44 named unittest checks + fixed Basic with28 Node cases); additional23 coupling/15 root/6 selection/24 acceptance-runner cases pass; exact RI/coupling/style,567-source formatter,48-source Python lint and whitespace pass. Prior complete48-finding Bandit scan is reused only on unchanged16-tools-source bytes, with current source/policy admission48 reviewed/0 untriaged and unchanged2026-12-06 expiry; no full-security/hosted pass is claimed.

Four actual distinct none-fork first role results plus affected bootstrap and byte-boundary corrections are preserved. Original failures/findings and packet metadata erratum remain in the139,028-byte/84-member lossless bundle. Final independent receipt review verifies source/bundle/result bindings; provider internals are unknown. Raw exact-head results and complete final selector are preserved separately in PR comments.

Final inputs **239,006,903bytes**, headroom **10,993,097**; tracked240,782,727 = inputs +1,775,824 derived bytes. All five caps unchanged; largest parsed-text margin remains218bytes. T05 net growth182,940 fits the previous1MB allowance. Final>=10MB target passes after all source/evidence inputs.

**T06 route is observed, not assumed:** protected-main code executed against this exact final head returns conservative/website, control=true, technicalRepository=false, repositoryOnly=false;37 unresolved D10 endpoints/100 obligations retained. Full source/RI/owning/hosted/preflight/admission and applicable exact reviewed_sha/maintainer decisions remain. This local classification is not an App admission or hosted run.

## Maintainer decision — CS05 exception accepted, 10 November 2026

After the assistant explained that permission concerns keeping only the whole-file mechanical formatting of `tools/repository_intelligence.py` and `tests/test_repository_intelligence.py` inside PR190, the maintainer replied **“Залишай”** (“keep it”) in the current project session.

This records the dated CS05 exception for those two already-touched files in this owning PR. Source reviewed for the decision:390076339875e2939a34b733b0f620c942210229; independently verified whole-AST parity and exact-source checks are in the [T05 checkpoint](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6777138904). Keep the formatting in PR190. **The CS05 blocker is resolved.** This limited formatting decision does not itself supply complete-candidate control attestation/reviewed_sha, merge or production approval.

T06 may continue with the agreed current-source/full-route preparation and checks. Other unmet semantic/delivery/merge gates and all whole AC01–AC05 remain open until verified.

All whole AC01–AC05 remain unchecked, all seven runner gates pending. PR190 remains Draft/unmerged; main remains ca756417590b9176f9fc33428321ffe1f64158cc. No Ready/staging/merge/production or closure action occurred. T02 browser playback remains unobserved; no new UI/device matrix is introduced.

Earlier checkpoints: [T01](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6772597589), [T02](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6773669726), [T03/T04](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6776168184).

## Initial architecture / planning checkpoint — 2026-11-10

**[Versioned deep analysis, architecture, consumer map and test design](https://github.com/oborskyivitalii/oborskyivitalii/blob/78e4944e739dcfd728434a8e41d768b8389a10e1/review/issue-189/2026-11-10-analysis.md)**
**[Draft PR190](https://github.com/oborskyivitalii/oborskyivitalii/pull/190)** — planning artifacts only; execution commits [b63d0de](https://github.com/oborskyivitalii/oborskyivitalii/commit/b63d0de324da54590d801227156ee5fc82700e25) and [cbb7dfa](https://github.com/oborskyivitalii/oborskyivitalii/commit/cbb7dfa8b4f0ab4e3ca6448843edf84da3bd8b1a).

Four separately launched nonauthor roles reviewed the plan and affected corrections: Requirements, Code, White-box, Exploratory. Original results, source/prompt/packet identities and launch/result receipts are preserved in the PR's lossless planning-review-evidence.tar.xz. No blocking planning finding remains; this is not implementation acceptance.

### Live baseline and observed problems

Main/production remain ca756417590b9176f9fc33428321ffe1f64158cc. Inspect current refs again before implementation.

| Resource | Observed baseline |
| --- | ---: |
| RI hash inputs |249,743,718bytes;256,282 spare under250,000,000 |
| review/ |194,194,215bytes |
| Readable map / full JSON |865,848 /1,764,356bytes |
| Full catalog |2,957entries, including2,010 history file/directory entries |
| Parsed text aggregate |21,679,851bytes from tree metadata;50MB cap |
| Largest parsed file |secrets-reviewed.json1,999,782bytes; only218 spare under2MB |

These are source/tree/JSON observations, not a full native RI run. The now-accessible full native JSON and supplemental source blobs were inspected. Complete native consumer discovery, selected historical originals and binary archive extraction remain unobserved.

Two distinct problems: default context reads too much history; physical hash inputs nearly fill their cap. Shortening the two existing derived views does not recover hash-input capacity. Old Git commits are outside that working-tree scan.

### Decisions and concrete proposed architecture

**User decisions recorded during this investigation:**

- Keep historical archives **inside this repository**.
- Recover **at least10,000,000bytes final aggregate headroom**, after all new metadata/evidence inputs. This target does not override protected-resource eligibility.

**Technical proposal: one producer, the same two outputs.**

- Canonical catalog/config remain the authored owners; no duplicate current-state registry.
- REPOSITORY-MAP.md becomes a generated short current-repository entry; proposed hard budget32,768UTF-8 bytes.
- Keep full agent-context.json schema2/path/source-digest/artifacts/directories/input fields and complete verification.
- Add opt-in scoped/current/history/all, exact path/prefix and bounded paged retrieval through the existing CLI. Preserve unqualified query/inventory compatibility. Default agent instructions recommend explicit current scope.
- Keep applicable instructions/check routes complete. Paging applies to hit lists, not silently to mandatory metadata; measure whole responses and offer narrowing/direct-source fallback. Fix the observed directory-only context omission.
- Preserve full byte hashing and all existing caps; compare regenerated output bytes so whitespace-only JSON mutations also fail. Archive/instruction safety gets an exact AGENTS.md negative, not only AGENTS.before.md.
- No database, service, remote archive migration, shard tree or persistent cache in this first implementation. Query still performs full verification; no lookup speed claim is made.

**Archive candidates, not approved savings:**195 remaining old-site metadata matches /30,092,333bytes in existing archives. The previous33 originals were already replaced under184 and cannot be counted again. Revalidate ownership, consumers, archive bytes and every extracted original before removing any loose copy. Active/unfinished/public/fixture/rights/rollback resources stay protected. Never replace PNG/WebM bytes with fake HTML at the same extension.

**Capacity checkpoint proposal:**>=2,000,000bytes spare after a bounded first slice, with measured remaining189 allowance<=1,000,000 and>=1,000,000 reserve. This is internal planning, not a bypass of the accepted final10MB target. Existing secrets-ledger companion mechanism remains untouched; report every limiting margin.

## Execution plan and stop points

| Step | Work | Output / stop condition |
| --- | --- | --- |
| T01 | Freeze current base/live owners, complete consumer/eligibility audit and requirements review | Exact selected/excluded paths, agreed interface/budgets, test-impact map; report before mutations |
| T02 | Recover the smallest safe archive slice using existing members and locators | Every-original recovery and protected-set comparison; measured first checkpoint; report actual net bytes |
| T03 | Generate short map and implement optional scoped/paged reads; preserve complete JSON and existing unqualified CLI/API | Deterministic entry and lookup journeys; compatibility/negative fixture checks |
| T04 | Add bounded capacity visibility and finish useful headroom target | Final full-candidate accounting includes all new metadata/evidence; margins for every current limit |
| T05 | Reconcile requirements/code/white-box/exploratory results and current-source policy/RI/CI/style checks | Four actual roles, corrected findings, source-bound evidence and truthful pending gates |
| T06 | Deliver separate Draft→trusted selected lane→maintainer decision; handoff to188 | Actual merged/effective identity and remaining exclusions; no website release claim from RI green |

Use one owning189 PR, with bounded coherent iterations. A separately delivered capacity slice is optional only if actual size/route constraints require it; it stays under189, not a new umbrella issue. Do not ask the maintainer to approve each routine file decision. Report after T01/T02 and T03/T04, then the review/delivery checkpoint.



## Refined acceptance contract (stable AC01–AC05)

### AC01 — Short current entry and scoped retrieval

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Short generated REPOSITORY-MAP <=32,768 UTF-8 bytes; no appended exhaustive history dump.
- Preserve existing full JSON and unqualified lookup compatibility; explicit current/history/all and prefix/file retrieval.
- Bounded scoped response reports limit/remaining/continuation/source digest. Current scope is role-based, not timestamp authority.
- Demonstrate EN/UA owner aliases already promised, exact file, directory-only, history retrieval, generated lookup, pagination and lexical miss. Check expected owners/instructions/check routes against canonical sources.
- Connector-only journey uses the short map/direct owners without downloading/pasting full JSON; no false local-verification claim.

Owner gate: accept proposed entry budget and intended presentation; independent lookup usability/compatibility review.

### AC02 — Full deterministic integrity and instruction safety

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Every supported tracked/nonderived input (plus supported untracked files per existing contract) remains cataloged and byte-hashed; no new exclusion, cap increase or recursive output hashing.
- Two derived outputs have deterministic regenerated-byte freshness; whitespace-only JSON mutation must be rejected. This is the single proposed output oracle, not an optional post-implementation choice.
- Current unknown/missing/unsafe paths, modes, source/producer/config mutation and stale/tampered/missing outputs fail.
- Live instruction scope is preserved; historical exact AGENTS.md cannot silently activate or suppress live instructions. Exercise this boundary, not only AGENTS.before.md.
- Full native build/verify, current real-repository tests, coupling and affected consumer checks pass on exact final source.

Owner gate: independent source/integrity review; fixture-only success is not full-checkout verification.

### AC03 — Eligible archive batch and lossless recovery

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Freeze selected current-base paths, owner/delivery/consumer dispositions and explicit exclusions.
- Every original has base identity/size/SHA256 plus archive/member/digest and practical recovery; compare every extracted original before replacement.
- Historical manifests/failures/first-review status and original archive bytes stay intact. New media locators do not masquerade as old bytes.
- Frozen protected closure of active/unfinished/public/fixture/rights/rollback resources is unchanged; any permitted index/link adjustment is listed.

Owner gate: evidence-based eligibility and actual every-member recovery; old inventory match is not approval.

### AC04 — Complete resource accounting and sustainable maintenance

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Before/after report separates hash-input saving, full tracked storage and derived-output/context reduction.
- Report file count, total hash/text, largest hash/text and margins, including the218-byte ledger risk.
- Final target >=10,000,000bytes aggregate headroom after all candidate/evidence inputs; first checkpoint >=2,000,000 with measured <=1,000,000 remaining allowance and >=1,000,000 reserve.
- Existing250MB/32MB/50MB/2MB/5000 caps unchanged. Under10MB advisory warnings do not create another hard CI gate.
- Archive-in-repo choice and existing post-production recovery process are retained; no infinite-growth guarantee or all-history completion claim.

Owner gate: the10,000,000-byte final target is user-selected. The first checkpoint/allowance is an internal planning proposal to validate by measurement; if safe eligibility cannot meet the target, return measured alternatives rather than weaken protections.

### AC05 — Style, allocation, review and real delivery

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Apply CS01/04/05/07/08/09/10 to actual producer/config/archive tooling; other IDs only as applicable. Bounded guard does not replace architectural review.
- Versioned owning policy maps stable criteria to named current checks and explicit eligibility/usability/recovery/review/merge gates.
- Update map/contract/catalog/RI/CI/test-selection companions together. Preserve historical task snapshots; use selected existing methods rather than blindly running all old issue tests.
- Test-impact review precedes expensive CI; raw first failures persist. Four actual role results and affected corrections are source-bound.
- Complete actual trusted lane and applicable maintainer decisions; record source/tested/merged/effective states distinctly. Refresh only the task handoff pointer.
No AC is passed by this planning checkpoint.



## Remaining work after T05 preparation

- **T01–T04 implementation / T05 technical preparation checked:** archive recovery, short current map, complete scoped/paged/context-safe CLI, deterministic byte/instruction integrity, diagnostic capacity, owning policy, current tests and four actual roles. [Exact-source evidence](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6777138904).
- **CS05 resolved,10November:** maintainer explicitly accepted keeping the two mechanical formatting deltas in PR190 (“Залишай”); the dated decision above owns this exception. Continue actual T06 checks and required decisions.
- **T06:** reconcile current semantic/owner gates; execute all obligations from the actual protected full/control route, exact reviewed_sha/maintainer control decisions and authentic source/RI/owning/hosted/preflight/admission checks. Record tested/merged/effective states separately; normal protected merge requires its applicable decision.
- All whole ACs remain unchecked. Source/fixture/local results and Draft preview do not establish delivery/merge/production.
- Preserve19-original frozen selection, all3 original archives/gzip/manifests/prior findings/rights/public/rollback/unfinished resources and five hard caps. No extra archival batch, service/cache/database, cap increase or repository-only exemption.
- Hand off to188 MEMORY lifecycle only after189's actual delivery/acceptance;187 motion remains separate.

