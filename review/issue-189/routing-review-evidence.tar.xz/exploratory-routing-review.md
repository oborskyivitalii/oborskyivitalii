# Exploratory / Interaction QA — first independent result

Verdict: **changes required before activation**. A reproducible executable-evidence boundary violation remains. The normal maintenance, mixed/public/unknown refusal and candidate-bootstrap journeys otherwise behaved as expected in the bounded observations below. This is the first result, preserved before peer reconciliation.

## Identity, scope and assurance

- Reviewer: distinct nonauthor Exploratory / Interaction QA, task `/root/issue189_route_exploratory`; first phase. Actual launch parameters/runner acceptance belong to the orchestrator receipt; provider model/context internals are unknown to this reviewer.
- Repository checkout: `/workspace/scratch/2c34f552b848/issue189-checkout`.
- Candidate `979e15899c71ad8633649bcb34afba385bdf4665`, tree `f060d85be1f7a3923308851ae10f7156192291de`; prior `1746a7afc1698502d95a426f4b75927b9fbce0f9`; protected-base reference supplied `ca756417590b9176f9fc33428321ffe1f64158cc`. Git identity and clean worktree were observed locally. Live GitHub was intentionally not queried under the review's offline constraint.
- Packet `implementation-packet.json` SHA256 `246416d08da5300f04eecd902b9b7049e9c2dadf8872b6f275ae1ead5014fe9d`; every listed file digest was checked and matched after execution. Digest checking the listed evidence archive did not inspect its contents.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Read root instructions, README, CONTRIBUTING, map, dated MEMORY, supplied original owning issue/ACs, implementation brief, common/role prompts, applicable acceptance/style/routing/staging owners, actual amended code/tests/policy delta and unchanged collection/admission consumers. No nested AGENTS files were found in the affected tools/tests/.github/guides areas. No current peer output, parent scratch notes or review-evidence archive contents were read. The supplied owner text contains historical review conclusions; they were treated as dated candidate/owner claims, not adopted as verdicts.
- No implementation changes, network, browser, CI, external writes or delegation. Temporary real-Git fixtures were removed. Only this report and own `exploratory-routing-probes*` artifacts were created in the assigned output directory.

## Charter and actual surface

Before probing, the independent charter was recorded in `exploratory-routing-probes.cjs`: exercise real-Git maintenance, mixed unknown/public/control/mode refusals and the enabling candidate's inability to self-activate. Each child process is bounded; probes enforce a 240-second charter stop and 15-second Git calls. The first 11-case probe campaign took 1,661ms; the two-case diagnostic took about 240ms. The existing two-suite run took 33,022ms; no process exceeded 300 seconds.

The changed interaction is operator classification/selection and App-admission reporting. Browser/website interaction is not part of this changed surface. Transition/browser diagnosis is explicitly deferred by the supplied user scope; it was not performed and supplies no acceptance evidence. Source reading helped explain observed selection behavior; it did not substitute for the actual real-Git journeys.

## Executed observations

| Journey | Expected | Observed |
| --- | --- | --- |
| Add supported archive index; delete supported historical capture | Repository route, retained repository/App/owning/review obligations, hosted work omitted | Both pass; hosted obligations `required:false`, with no fabricated success |
| Add unknown nearby JSON alongside archive maintenance | Full/conservative route | Pass: unknown path rejected; hosted work remains required |
| Add site runtime or source-selector edit alongside maintenance | Full route | Both pass |
| Move runtime bytes into a supported historical evidence name | Retain old-side runtime obligation | Pass: complete A/D collection rejects old runtime side |
| Mutate owning-workflow command alongside maintenance | Full/control route | Pass: workflow rejected |
| Edit repository-only component notice | Technical repository route | Pass: control remains true; Python/security/advisories and admission remain required |
| Same notice with public provenance already present in base | Hosted dependency survives | Pass: full route, notice rejected |
| Complete actual protected-base-to-candidate delta | Classifier cannot exempt itself | Pass: `repositoryOnly:false`, `technicalRepository:false`, control true; classifier/observer and policy-guide changes rejected |
| Add supported archive index with executable mode100755 | Refuse cheap non-executable evidence route | **Fail:** `repositoryOnly:true`, control false, despite `technical.rejected` containing that path |

First campaign accounting: **11 executed, 10 pass, 1 fail**, retained in `exploratory-routing-probes.json`; process exit1 preserved. No unchanged failed campaign was rerun.

A bounded diagnostic then asked whether ordinary evidence classification bypasses technical mode rejection. It ran a mode-only100644→100755 transition on the supported index, plus a newly added100755 file at the same name containing `#!/bin/sh` and `exit 0`. **Both failed their expected refusal**, producing `repositoryOnly:true`, control false, `technicalRepository:false` and technical rejection of the same path. Raw results are in `exploratory-routing-probes-diagnostic.json`; diagnostic exit1 retained. No script under review was executed.

Existing candidate tests: `node --test --test-reporter=tap tests/delivery-observation.test.cjs tests/delivery-admission.test.cjs`, **70/70 pass, 0 fail/cancelled/skipped/todo**. Raw TAP is `exploratory-routing-probes-suites.tap`. This includes actual observer CLI/error collection tests and mocked genuine-App/source-failure propagation journeys. Those offline APIs are fixtures; no live App, workflow run or provider decision was observed.

## Finding EX-R01 — executable evidence takes ordinary repository route

**Severity: medium; blocking the claimed non-executable maintenance disposition before activation.**

Locations: `tools/quality/delivery-routing.cjs:48` (`repositoryEvidence`), `:108` (D01 classification), `:535` (`appendSide`), `:708` (technical mode rejection); `tools/quality/delivery-observation.cjs:204` (final repository eligibility). Contract: `guides/SITE-CHECK-PROFILES.md:640` requires actual content/executable ownership for100755; `:746` restricts this extension to non-executable issue evidence.

Mechanism: the newly recognized evidence path is classified as ordinary D01 regardless of executable bit/content. Generic `appendSide` accepts100755 without adding conservative ownership. `analyze(..., true)` consequently already omits hosted/Python work. `technicalSelection` correctly rejects the executable mode, but the final eligibility OR still accepts the ordinary repository branch. Thus one report simultaneously says the file is technically rejected and selects cheap delivery. An executable shebang under the supported `.json` name reproduces it.

Observed consequence: hosted obligations are not required, `R-PYTHON` is not required, no technical security/advisory obligations are introduced, control is false, and exact control-SHA review is not requested by the path-based control classifier. This observation is a routing/required-evidence gap; it does **not** establish arbitrary code execution, successful CI, live App admission or production compromise. The actual candidate contains no demonstrated offending executable evidence file, but its future classifier admission promise is wider than the authorized class.

Treatment: the author should ensure both present endpoints of newly supported historical evidence have the intended regular non-executable ownership before the ordinary branch can narrow obligations. Preserve known-control/runtime/public endpoints, and ensure a technical rejection cannot be silently bypassed by the ordinary branch for this case. A separate author must implement the correction and accepted regressions.

AC impact: **AC05** source-only allocation/admission safety is unresolved; **AC02** unsafe mode/owner refusal subcondition is not demonstrated by the current implementation. Archive routing alone still proves neither **AC03** deletion eligibility/recovery nor whole-criterion acceptance.

Proposed regression allocation: add addition and mode-only executable-evidence negatives to maintained `tests/delivery-observation.test.cjs` (the existing observer/source selection suite, source CI and owning `test_source_only_maintenance_routing` entry). Include an archive-only case so a technical companion cannot hide the ordinary-branch bypass. Add an App collector refusal case if the corrected boundary affects its selection contract. Proposed tests are not implemented or counted as passes here.

## Operator reading and remaining limits

The maintained routing/staging guides let an operator find conditional obligations, explicit hosted inapplicability, exact reviewed_sha, source failure propagation and protected bootstrap. The wording distinguishes local classification, prepared code and operational activation. The actual complete-delta probe corroborates self-activation refusal. No additional activation-guidance blocker was found in this bounded walkthrough.

The executable-evidence inconsistency makes the technical `rejected` list insufficient as an operator refusal signal; final lane and obligation fields need consistent behavior after correction. Evidence records remaining `planned` while `required:false` are distinguished by `inapplicable`, not reported as passed. The broader observer remains advisory; no runtime dispatcher, native protected workflow, authentic App credential path, protection settings, archive eligibility, full original recovery, full RI/source-security campaign, physical device or browser performance claim is supplied by this review. All whole ACs remain open under the owner until their separate actual gates pass.
