# Code / Artifact correction review — same-role continuation

Verdict: **the supplied routing defects are independently confirmed on979e and corrected on dba309; no unresolved blocking code finding in the affected correction**. My first report remains unchanged. Its no-blocking-finding conclusion missed the two boundary cases below and must not be cited as proof that979e preserved them.

This is a correction review after explicit parent reconciliation input, not a fresh independent first judgment. I read the supplied factual correction brief/packet and raw scanner evidence; no current peer report or archived peer output was opened.

## Exact identities

- Reviewer `/root/issue189_route_code`, nonauthor Code role; first report `code-routing-review.md` preserved separately.
- Corrected clean candidate `dba309b4f5e7e58369dd4e3072663cda3e626a9b`; tree `e932272967ba7f12ba02e942e33e1fce18fa135f`.
- Prior inspected source `979e15899c71ad8633649bcb34afba385bdf4665`; complete binary-form979e→dba diff SHA256 `70a133431e650fb219a690c46fd71b19cfd9822f6fb7b8e54d27b1a1514c4890`.
- Correction packet SHA256 `303cfc21aeff84bbb3ee88b84f5fa95d8e1bf5b74dad9c2f9eb685d9e4171113`; all11referenced byte/hash entries independently matched (`code-routing-correction-probes-packet.json`). Common/Code prompts are unchanged from first review, SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` / `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Checkout clean and candidate/tree unchanged at final read. No source/test/config edits, network, browser, CI, external write or delegation. Provider context/model internals remain unknown. All own processes completed within300seconds.

## Confirmed original defects and actual resolution

1. **Blocking missing security/Python allocation on archive-only work.** Original `technicalSelection` classified recognized historical evidence as ordinary repository input before adding it to the technical set. An archive-only deletion therefore produced technicalRepository=false, disabled R-PYTHON and omitted B-SECURITY/B-ADVISORIES. My first tests included an executable test edit alongside maintenance, masking this pure-evidence boundary. New `technicalEvidence` admission before ordinary-document classification makes newly supported evidence technical; historical issue Markdown retains its old ordinary-document allocation. The unchanged `site-checks.yml` consumer consequently executes the existing technical Python/security/advisory steps.

2. **Blocking technical rejection bypass through ordinary fallback.** Original `selection` called `analyze(..., true)` before technical eligibility, and its repositoryOnly fallback ignored `technical.rejected`. Executable evidence could be rejected technically while the ordinary D01 repository classification still disabled hosting. Corrected `selection` obtains full obligations first, computes complete eligibility with no-rejected condition for ordinary fallback, and narrows once only if the final repositoryOnly result is true. Executable evidence addition, mode change and deletion now all retain H and H-PREVIEW required. This fixes both returned eligibility and the obligation mutation, rather than just changing a display boolean.

I replayed **actual exact979e and corrected routing/observer source** in isolated CommonJS VM wrappers over four fresh real-Git fixtures. The loader supplied only the versioned routing dependency and unchanged Git/JSON helpers; it made no global loader patches or source edits. Each fixture was evaluated by both implementations. All four reproduced the original failure and corrected result. Own raw result: `code-routing-correction-probes-replay.json` (archive deletion; executable evidence A/mode/D).

`controlReviewRequired: technical.some(control)` now describes actual control paths. App admission still independently inventories control changes using `definitions` and requires exact owner reviewed_sha; this diagnostic flag does not replace its protection. The original full/control bootstrap boundary remains intact for changes to the classifier/admission/source runner.

## Other affected deltas

- The three RegExp.exec→String.match changes are equivalent for the validated primitive strings and non-global literal expressions used here. They alter neither accepted patterns nor predicate/registry semantics and contain no subprocess call. The original Semgrep result has precisely three node-shell-injection findings at the corresponding parser calls and no parser errors. No scanner-rule/threshold/ledger waiver was introduced by this correction.
- Independently confirmed Python AST parity for task-test canonical formatting and complete parsed RI-map parity after removing only refreshed reviewed_source_identity (`code-routing-correction-probes-parity.json`). Inspected guide two-word correction and current RI identity refresh; no unrelated behavior change.
- Reused first review reasoning only for unchanged App/workflow/source-selector/public-provenance/owning-policy bytes; checked the changed selection outputs against those actual consumers and reran their real suites. The source remains under the same189 amendment intent/ACs.

## Actual checks and receipt inspection

| Observation | Result | Own raw file |
| --- | --- | --- |
| Current observer/admission suites, timeout300 |72tests/72pass;0fail/cancelled/skipped/todo;23269.775145ms;exit0 | `code-routing-correction-probes.tap` |
| Real-Git exact979e/current failure-and-fix replay |4/4 expected before/after outcomes | `code-routing-correction-probes-replay.json` |
| Candidate-code selection of actual ca756→1746 delta |repositoryOnly=true;technicalRepository=true;0rejected/0unresolved;required Python/security/advisories/owning/App retained | `code-routing-correction-probes-selection.json` |
| Current `node tools/quality/format.cjs --check` |exit0; canonical check pass | `code-routing-correction-probes-format.txt` |
| Current bounded style guard |pass;165files;0legacy occurrences | `code-routing-correction-probes-style.txt` |
| Current RI/CI coupling verify |pass;17checks/19layers;digest3646ef07... | `code-routing-correction-probes-coupling.txt` |
| Current RI verify |context fresh;exit0 | `code-routing-correction-probes-ri.txt` |

I additionally inspected the completed source-security **raw receipt**, not an author pass assertion: `security-corrected/repository-security.json` SHA256 `3f79cdf4209ad2268835b7605a3dfbbe4ca2acd6d9f9d5a97628b0b98a4102d2` binds exact dba309/treee932, website not-applicable and pass=true. Every listed raw engine report byte/hash matches: Semgrep0findings/0errors/376scanned paths; Bandit and secrets engine admissions pass. Bandit's raw exit1 is recorded and is handled through existing triage; it was not mislabeled raw zero-exit. Own binding summary: `code-routing-correction-probes-security.json`. I did not independently rerun the complete scanner or inspect a completed advisory receipt in this correction review; those remain separate current-source delivery checks.

## Acceptance and limits

The original two failures invalidated the first report's broad gate-preservation assessment; this report records their reproduction and resolution explicitly. The corrected implementation and72-case suites now support AC05's amended code/routing subset, including meaningful pure-evidence and executable-mode negatives. No whole AC is accepted, and no archive eligibility/recovery, owner decision, native App issuance, activation, merge or transition-performance result is supplied.

The ca756→1746 classification is prospective candidate-code proof only. It does not activate the enabling classifier change under protected main and does not erase the original hosted failure. Current protected execution, source/advisory/owning obligations and all other role/owner gates still require their proper evidence. First-review artifact and original failing scanner reports remain preserved.
