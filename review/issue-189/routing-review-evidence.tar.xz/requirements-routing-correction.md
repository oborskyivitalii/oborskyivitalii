# Requirements & Acceptance — actual affected correction

2026-11-10. Same-role post-first continuation `/root/issue189_route_requirements`. First final judgment on979e and its failed allocation probe remain unchanged. Reconciliation exposure: the supplied correction brief states my archive-only finding, an independently found executable-evidence fallback, scanner raw findings and formatting failures. I read the actual correction/source/tests/raw receipts; I did not inspect peer report files or archive contents. This is not a fresh isolated first review; provider internals remain unknown.

## Verdict

**The reviewed correction resolves my R-F01 and R-F02. No remaining blocking requirements finding in the affected amendment scope.** This is local source/review acceptance of the corrected behavior, not activation, native CI/App admission, merge, production or whole189 acceptance.

`technicalEvidence()` now allocates newly admitted non-Markdown issue data and historical capture/archive/gallery evidence before ordinary documentation handling. The real-Git archive-only test proves Python/security/advisories/owning/App obligations remain required while hosted work is inapplicable. Original issue Markdown and ordinary documentation keep their prior lightweight allocation. This respects the intended distinction between expanded maintenance support and unchanged documentation compatibility.

`selection()` now derives complete technical/ordinary eligibility before applying repository obligation narrowing once. Technical rejection blocks the ordinary fallback. Executable evidence addition, mode change and deletion therefore remain full, with hosted obligations required. Safety is not achieved by merely setting repositoryOnly=false after obligations were already waived.

The three non-global literal regular-expression `.exec(string)` calls were changed to equivalent `string.match(regex)` operations. In the inspected paths both produce the same capture array or null, including the optional capture access; regex flags, accepted policy forms, monotonicity and task numbering are unchanged. This removes scanner-name ambiguity without changing scanners, suppression ledgers or thresholds. The preserved979e Semgrep report contains3 findings/0errors at those exact regex calls. Correcteddba source-security report passes with raw reports bound and independently rehashed; no shell-execution or security waiver claim is introduced.

Canonical formatting resolves R-F02 without expanding the existing exception. Own current pinned format check passes all567files; the owning Python AST is equal before/after and parsed nonidentity RI-map semantics remain equal. Refreshed identity hashes appropriately change with the source correction.

## Requirement → actual corrected outcome

| Requirement/finding | Observed evidence | Disposition |
| --- | --- | --- |
| R-F01 archive-only required source allocation | Own72-test observer/App execution includes new real-Git archive-only deletion: technicalRepository/repositoryOnly=true; R-PYTHON, SECURITY, ADVISORIES, O and App required; hosted inapplicable. | Resolved. The earlier failed probe remains retained. |
| Executable historical evidence cannot use ordinary fallback | New real-Git A/mode/D evidence cases; code narrows obligations only after final eligibility; all pass. | Resolved affected safety boundary. |
| Existing mixed189 maintenance intent | Own current amended selector replay of actual ca756→1746 Git objects: zero unresolved/rejected, technicalRepository/repositoryOnly=true; source/Python/security/advisory/owning/App obligations retained; hosted false-required. | Correct prospective behavior; no active route claim. |
| Bootstrap cannot exempt itself | Own replay ca756→dba remains technicalRepository=false/repositoryOnly=false; routing guides and observation/routing implementation rejected; hosted required. | Correct refusal. Protected-main activation still absent. |
| Exact-control trust and source failure propagation | Entire maintained observer/App suites execute successfully; admission implementation unchanged from prior reviewed source. | Actual finite local fixture coverage reused/re-executed; no native App claim. |
| BASIC source-only allocation | Unchanged policy mapping to the maintained suites through the named unittest; wrapper change in this correction is formatting only with equal AST. | Prior scope acceptance retained. Global source/style/RI/owning/security owners remain independently required. |
| R-F02 canonical formatting | Own `node tools/quality/format.cjs --check`: pass,567files,0changed; own Python AST and map nonidentity JSON parity. | Resolved. |
| Locked source security | Read correcteddba exact-source report, verify each referenced raw report's size/SHA256; Semgrep376scanned/0findings/0errors; Bandit48raw/48reviewed/0untriaged/0errors; secrets engine pass. | Local source-bound report observed; engines were executed by the parent workflow, not rerun by this role. Native CI/advisory acceptance is not inferred. |
| Original AC01–04 and full AC05 delivery | Unchanged previously reviewed scope reused only by exact source identity; actual complete/native/advisory/four-role/delivery gates remain separate. | No whole-AC checkbox pass supplied by this result. |

## Identities, checks and limits

Inspected correction HEAD `dba309b4f5e7e58369dd4e3072663cda3e626a9b`, tree `e932272967ba7f12ba02e942e33e1fce18fa135f`, clean before/after checks; prior `979e15899c71ad8633649bcb34afba385bdf4665`. Protected base remains `ca756417590b9176f9fc33428321ffe1f64158cc`. Packet SHA256 `303cfc21aeff84bbb3ee88b84f5fa95d8e1bf5b74dad9c2f9eb685d9e4171113`; all11 entries match their exact byte counts/digests. Unchanged common/role prompt and original owner/amendment identities remain those recorded in the preceding reports.

Corrected routing SHA256 `d66b3c27ae634ede5e757fdde13c75b5522d683c9c843e0ecd7eb97e643c5eb8`; observation `14d98914c4a890051de6cc133f602c22a5d6622f719a952c2566defa7ba36665`; observer tests `9bdf0283ad6bfc1520b595553f6bf89b2752c820197268fe1d41d691f3a32d9e`. Corrected source-security report SHA256 `3f79cdf4209ad2268835b7605a3dfbbe4ca2acd6d9f9d5a97628b0b98a4102d2` binds dba/e932 and website=not-applicable. All4 referenced raw file size/digest bindings match. Own raw receipt retains these checks.

Executed independently: maintained observer/App suites,72tests/72pass/0fail/0skip/0cancel/0todo,27.0seconds; global pinned format check,567files/0changed,7.4seconds; packet hashing/Git cleanliness; JSON/Python AST comparison; two actual Git selector replays; retained raw security parsing/hashes. Each process bounded<=300seconds. Own TAP: `requirements-correction-tests.tap`; own receipt: `requirements-correction-raw-probes.txt`.

No source/test/config edits, browser/network/CI/security-engine execution, transition measurement, delegation or external writes. No new policy suppression or performance threshold change is accepted. Advisory results were not inspected here. Original hosted performance failure remains failed. Four-role reconciliation and all required exact-source/native/trust/bootstrap gates must complete before advancement claims; local source-only eligibility cannot supply its own protected activation.
