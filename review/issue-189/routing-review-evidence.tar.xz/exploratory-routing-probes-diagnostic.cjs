'use strict';
// Independent charter: real-Git maintenance/refusal/operator journeys; <=300s total.
// Temporary fixture data only. No candidate source or accepted tests are edited.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const source='/workspace/scratch/2c34f552b848/issue189-checkout';
const observer=require(source+'/tools/quality/delivery-observation.cjs');
const start=Date.now(),rows=[];
const git=(root,...args)=>cp.execFileSync('git',args,{cwd:root,encoding:'utf8',stdio:['ignore','pipe','pipe'],timeout:15000}).trim();
const write=(root,file,text)=>{const p=path.join(root,file);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,text);};
function run(name,before,after,expected){
  if(Date.now()-start>240000)throw Error('charter deadline');
  const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'independent-route-'));
  try{
    git(temporary,'init','-q');git(temporary,'config','user.name','Offline QA');git(temporary,'config','user.email','qa@example.invalid');
    for(const file of observer.policyFiles)write(temporary,file,fs.readFileSync(path.join(source,file)));
    before?.(temporary);git(temporary,'add','.');git(temporary,'commit','-qm','Independent base fixture');const base=git(temporary,'rev-parse','HEAD');
    after(temporary);git(temporary,'add','-A');git(temporary,'commit','-qm','Independent candidate fixture');const head=git(temporary,'rev-parse','HEAD');
    const result=observer.selection(temporary,base,head);
    rows.push({name,expected,observed:result.repositoryOnly,pass:result.repositoryOnly===expected,technicalRepository:result.technicalRepository,control:result.analysis.control,analysis:result.analysis.status,rejected:result.technical.rejected,hosted:result.obligations.filter(r=>r.category==='hosted').map(r=>({id:r.id,required:r.required,state:r.state,reason:r.reason})),required:result.obligations.filter(r=>r.required).map(r=>r.id)});
  }catch(error){rows.push({name,expected,error:error.message,pass:false});}
  finally{fs.rmSync(temporary,{recursive:true,force:true});}
}

// Diagnostic question recorded after the retained first failure: does ordinary
// evidence classification bypass the stricter technical mode rejection, including
// content which is demonstrably executable? Stop after these two comparisons.
run('mode-only transition on newly supported evidence',r=>write(r,'review/issue-999/archive-index.json','{}\n'),r=>fs.chmodSync(path.join(r,'review/issue-999/archive-index.json'),0o755),false);
run('executable script disguised as supported evidence',null,r=>{write(r,'review/issue-999/archive-index.json','#!/bin/sh\nexit 0\n');fs.chmodSync(path.join(r,'review/issue-999/archive-index.json'),0o755);},false);
console.log(JSON.stringify({question:'Ordinary evidence path bypasses technical regular-mode rejection?',elapsedMs:Date.now()-start,rows},null,2));
if(rows.some(r=>!r.pass))process.exitCode=1;
