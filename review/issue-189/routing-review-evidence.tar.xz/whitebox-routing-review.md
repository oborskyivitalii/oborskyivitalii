# White-box QA — first independent routing verdict

Date: 2026-11-10. Reviewer: `/root/issue189_route_whitebox`, distinct nonauthor. **No blocking finding found in the inspected amendment; bounded technical review passes.** This does not satisfy delivery, merge, archive eligibility/recovery, complete source security or hosted acceptance.

## Identity and independence

- Repository: `oborskyivitalii/oborskyivitalii`, owning issue189 / PR190.
- Inspected clean HEAD `979e15899c71ad8633649bcb34afba385bdf4665`, tree `f060d85be1f7a3923308851ae10f7156192291de`; amendment base `1746a7afc1698502d95a426f4b75927b9fbce0f9`; protected-base reference `ca756417590b9176f9fc33428321ffe1f64158cc`.
- Packet SHA256 `246416d08da5300f04eecd902b9b7049e9c2dadf8872b6f275ae1ead5014fe9d`; checked 30 listed byte identities, zero mismatches. Deliberately did not read the peer archive or author analysis narrative; therefore the packet's two such entries were not byte-read for this review.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Read root AGENTS (sole applicable AGENTS), README, MEMORY as handoff, repository map, CONTRIBUTING, acceptance/style owners, common/role prompts, supplied primary owner/user amendment, actual implementation/test/registry/policy diffs and relevant unchanged observer/admission/collector consumers. The owner issue contains historical review summaries; these were not used as an oracle. No current peer output, parent scratch diagnosis or evidence archive was read before this first judgment. Provider context/memory internals are unknown; no OS-isolation claim. Parent owns the actual launch receipt.
- `git status --short` empty before and after tests; source HEAD/tree unchanged. Only assigned whitebox-routing output files were written. No network, external writes, browser, CI, source/test edits, delegation, performance experiment or transition diagnostic.

## Independent oracle and structure

The original AC02/AC03/AC05 and explicit maintainer amendment require source-only maintenance to omit hosted work while preserving exact-source/source/security/RI/owning/App/review gates. Unknown/public/unsafe endpoints and selection/bootstrap edits retain full work; existing owning predicates may only gain positive alternatives naming newly added policies; old registry rows and all non-test registry policy remain equal. Archive routing supplies no deletion or rights permission. These requirements, rather than classifier output, supplied the expected outcomes in the additional probes.

Actual data flow inspected: immutable raw Git AMDT records → both endpoint input manifests/declared content → structural technical selection → `repositoryOnly` requires complete analysis → obligation narrowing → actual admission `collect` chooses three source routes and retains exact control-head attestation. Collector forces no-renames, so moves are deletion plus addition; unknown/public source deletion remains visible. A synthetic R record is outside this admitted collector contract and was not treated as a production failure.

| Risk / AC | Structural fault and scenario | Independent expected result | Check / result / owner |
| --- | --- | --- | --- |
| Hosted dependency hidden on either endpoint / AC02,05 | Evidence path present in base-only or candidate-only rights or declared content | Full route on each of four partitions | Own direct routing probes 4/4; existing actual-Git provenance tests pass; observer suite / site-checks source |
| Unknown/public/mode input hidden in union / AC02,05 | Unknown JSON, executable evidence, website/selector/workflow input, mode100755/symlink/gitlink; unknown/public→evidence move | Full route; no shortcut from allowed companion | Own negatives and delete+add moves pass; existing real-Git mode, unsafe path, rename, collector-completeness tests pass |
| Safe historical evidence / AC03,05 | Add/modify/delete six supported classes including index/proof/gzip/review tar/media/gallery | Omit hosted work in valid source-only union; retain required source checks | Own18 partitions pass; existing RI/owning/archive positive real-Git test passes; no recovery/deletion approval |
| Owning workflow broadening / AC05 | New positive policy OR versus removed old policy, nonexistent policy, duplicate, conjunction, job image, command, permission, Draft guard or missing workflow | Only positive newly added policy alternatives eligible | Own positive + nine negatives pass; existing real-Git four mutation checks pass |
| Task registry / AC02,05 | New numeric task/matching new policy; wrong route/profile/missing new policy, old-row deletion/input change/non-test policy change | Matching new task eligible; six corruptions full | Own7 partitions pass; existing additive/invalid-registry checks pass |
| Notice falsely treated as repository-only / AC02,05 | Base/candidate public notice exposure; sourceGroups/assets/retained/public notice basis/direct path | Any public dependency retains full route | Own private positive and two endpoint refusals pass; existing notice exposures and real-Git base-public case pass |
| Candidate bypasses executable trust / AC05 | Actual collector/admission with mocked API: missing/wrong reviewed SHA, changed source wrapper, failed required source workflow | Exact control SHA and genuine producer identity required; failing source refuses; no hosted API for eligible maintenance | Existing actual `admission.collect` integration test passes; dedicated-App/exact-controller consumers and durable publication/finalization tests pass |
| Obligation/selection regression / AC05 | Base-selected obligations, diagnostic profile, Python/security/advisories, external four-role gates | Required sources preserved; hosted inapplicable rather than passed | Existing observer obligations checks pass; source inspected at routing594–756, observer180–208, admission395–455 |

## Executed checks and raw accounting

1. `timeout 300s node --test tests/delivery-observation.test.cjs tests/delivery-admission.test.cjs` (stdout/stderr redirected outside checkout). Exit0; **70 tests,70 pass,0 fail/cancelled/skipped/todo**,20,287.01883ms reported. Raw output: `whitebox-routing-probes-existing.tap`. Despite its filename, this Node runtime emitted its default human-readable reporter, not TAP. This is the actual affected native Node suite, not a reconstructed success receipt.
2. `timeout 300s node /workspace/scratch/2c34f552b848/issue189-t06/route-review/whitebox-routing-probes.cjs`. Exit0; **56 independently specified direct routing scenarios,56 pass,0 failures**; process2.565s. Raw per-case expected/actual/source-decision JSON lines: `whitebox-routing-probes.jsonl`; reproducible probe source: `whitebox-routing-probes.cjs`. These are direct component scenarios with synthetic admitted-shape AMDT records, not actual-Git or live-App executions. Their expectations are explicit in the probe source and table above.
3. Packet-byte identity check:30 checked entries,0 mismatches; two prohibited narrative/archive entries not read. Git head/tree and empty source status rechecked after execution.

All executions were bounded below300s. No failed own run was erased or retried. No branch/statement coverage measurement was taken; the56 partitions are not a blanket coverage claim. Existing suites provide real-Git and actual controller-function integration; the added component probes supplement their failure partitions and do not replace those integrations.

## Findings, AC impact and limits

No reproducible introduced defect found within this scope. The invariant examined is that hosted omission depends on complete, supported source-only dependency disposition, while source trust and exact reviewed control head remain mandatory. Positive and negative cases reject the dangerous alternative outcomes in the examined partitions.

AC02/AC05 gain current-source bounded routing/guard evidence. AC03 gains routing evidence only, not eligibility, protected-closure or recovery acceptance. AC01/AC04 behavior and current resource accounting were not dynamically re-evaluated. Whole AC01–AC05 stay pending until their complete checks and external gates pass.

The owning BASIC mapping now calls the named `test_source_only_maintenance_routing` unittest, whose subprocess runs these two actual Node suites with300s timeout; its current inner execution is substantiated above. The wrapper itself and complete45-check policy were not repeated by this reviewer. Existing global style/source/security/Python owners are preserved by selection, but this review did not execute all those checks. Added probe cases are reviewer diagnostics; if promoted into accepted tests, a different nonauthor must review them.

No live GitHub App-issued check, current protected-main deployment/activation, CI result, protected-bootstrap execution, website/hosted run, browser transition or performance result was observed. Actual App API calls are mocked in the executed integration tests; claims are limited to real controller code and refusal behavior. No approval, exemption self-activation, release or merger follows. Candidate classifier/observer changes remain full-route bootstrap controls; read-only source analysis confirms the exclusion, while live bootstrap remains a separate gate. Existing native staging failure is neither rerun nor waived.

This is the preserved first judgment before peer reconciliation. No implementation correction was requested; no hypothetical untested test or generalized assurance is presented as a passing check.
