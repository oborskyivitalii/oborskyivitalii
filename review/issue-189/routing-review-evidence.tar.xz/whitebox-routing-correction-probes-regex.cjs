'use strict';
const assert=require('node:assert/strict');
const patterns=[/^(\s*)if: (.*)$/,/^env\.ACCEPTANCE_POLICY == '(\.github\/acceptance\/issue-\d+\.json)'$/,/^tests\/test_issue(\d+)_acceptance\.py$/];
const corpus=['','if: >-','        if: >-','if: >','if: true','if: env.ACCEPTANCE_POLICY == \'.github/acceptance/issue-189.json\'','if: >-\r','if: >-\n','env.ACCEPTANCE_POLICY == \'.github/acceptance/issue-189.json\'','env.ACCEPTANCE_POLICY == \'.github/acceptance/issue-999.json\'','env.ACCEPTANCE_POLICY != \'.github/acceptance/issue-999.json\'','env.ACCEPTANCE_POLICY == \'.github/acceptance/issue-x.json\'','tests/test_issue999_acceptance.py','tests/test_issue0_acceptance.py','tests/test_issue999_acceptance.py\n','tests/nested/test_issue999_acceptance.py','tests/test_issue_acceptance.py','tests/test_issue999_acceptance.py.cjs','Копія *.md'];
let count=0;for(const regex of patterns)for(const value of corpus){const before=regex.exec(value);const after=value.match(regex);assert.deepEqual(after,before);count++;}
console.log(JSON.stringify({comparisons:count,passed:count,failures:0,nonGlobal:true}));
