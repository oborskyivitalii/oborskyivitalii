# Issue 189 — T05 acceptance bootstrap scope preflight

Date: 2026-11-10. Requirements & Acceptance targeted continuation, before dependent workflow correction. Original first preflight and quality-scope addendum remain intact. The orchestrator supplied a proposed correction and diagnostic filenames; no current peer reports, parent notes or diagnostic conclusions were read or accepted as proof.

## Verdict

**PASS for a narrowly scoped acceptance-workflow bootstrap companion correction.** A policy invoking the unchanged fixed Basic command must provision its existing canonical transitive dependencies on a fresh runner. Adding issue189 to relevant existing installation conditions is necessary reproducibility preparation under AC02/AC05, within T05 scope. This changes bootstrap eligibility for the selected owning policy, not issue intent, accepted oracle, scanner budgets or delivery authority. No new permission is needed for this bounded reversible correction.

The actual completed workflow delta still requires source-bound review and verification. Local success with a repaired environment cannot establish fresh-runner CI success. All whole AC01–AC05 remain open; no hosted, Ready, staging, merge or production action is authorized here.

## Independently inspected dependency evidence

- Current `issue-189.json` AC05 maps to `BASIC`, kind `node-basic`. The fixed Basic implementation `tools/quality/local.cjs` begins with `tools/site/build.cjs --check`, then existing focused source checks and exported-source checks. Do not weaken or remove Basic to avoid installation.
- The current build imports `tools/site/articles.cjs`. Article selection calls the existing publisher loader/compiler and `article-media.cjs` render/social adapters. The media adapter prefers `tools/quality/toolchain/venv/bin/python` whenever it exists, otherwise `python3`, unless the existing explicit environment override is supplied. Thus an incomplete new venv shadows a more capable ambient interpreter.
- `tools/publishing/web-media.py` imports PIL inside encoding and requires its version to equal the unique canonical `pillow==...` line in the quality toolchain requirements. Current canonical pin is `pillow==13.0.0`; WebP codec version remains checked as 1.6.0. The existing `--requirement` route reads the pin without importing PIL. No new media behavior or dependency version is needed.
- `tools/publishing/article.cjs` checks the installed exact declared unified/remark versions and invokes the unchanged AST compiler. Its existing publishing toolchain manifest owns those pinned dependencies; using its existing locked `npm ci --ignore-scripts` step preserves that contract.
- Actual `.github/workflows/issue-acceptance.yml` has explicit policy conditions for quality Node installation, pinned Python setup, creation of the partial locked lint venv, and the publisher AST plus canonical Pillow installation. None currently names issue189. The publisher step assumes the earlier venv exists, so selecting only its condition would be insufficient.
- Workflow currently pins Node24.19.0 and Python3.12.14, retains exact-source/history checkout, read-only repository permission, Draft job guard, ten-minute job limit, clean expected-source policy run and always-uploaded report. These remain binding.

The claimed first PIL failure/repair is plausible from actual dependency selection, but this reviewer did not inspect the supplied failure JSONs or rerun it. This review establishes the source-level missing bootstrap route, not actual failure accounting or later green execution.

## Allowed correction and constraints

1. Extend only existing step-condition scalar expressions to add exact `.github/acceptance/issue-189.json` equality. Preserve all existing terms and their meanings. The pinned Python setup, locked venv creation and existing combined publisher/Pillow step form the necessary existing recipe. An accurate display-name adjustment is harmless if needed; preserve action identity, ordering, arguments and environment.
2. The proposed quality Node condition extension is within the permitted bootstrap family, but this bounded inspection did not independently establish that quality Node packages are needed by this exact 45-check policy. Publisher Node dependencies are demonstrated above. Prefer the smallest evidenced step set; if retaining the quality installation for parity, record its actual dependency/reuse reason instead of claiming missing PIL proves it necessary. No new command, package pin, whole-toolchain expansion, job, permission, event, deadline, lane or reusable workflow is covered by this correction.
3. Define the exact `.github/workflows/issue-acceptance.yml` protected-resource exception before accepting the change: only the enumerated setup `if` scalar additions and optional display name. A path-wide exclusion would be too broad; changing selection, source checkout, runner, run scripts, report upload, clean-source checks, execution guard or budget must still fail the frozen protection comparison. Existing source/metadata exceptions remain explicit and every other protected resource remains bound.
4. Independently review the parsed workflow delta and expression truth table: issue189 selects its required installs; every previously listed policy keeps identical truth values; unrelated policies remain unchanged; all required installs precede the criterion run. Preserve the distinction between this acceptance job's existing partial venv and the full locked source/security toolchain owned by other routes. No claim that the partial install satisfies full security/advisory/source obligations.
5. Keep first failure evidence, exact tool versions, source identity and any repaired local result. Demonstrate installed canonical Pillow/codec and publisher availability through the actual interpreter/module paths the unchanged Basic uses. Rerun affected required checks on the final source and preserve complete accounting; an environment-only smoke supplies narrower evidence than a policy pass.
6. Refresh RI/CI source identity after reviewing the workflow companion and regenerate affected RI views. Recompute final input capacity after all policy/workflow/test/evidence bytes. Obtain fresh four-role final/delta review of the completed candidate and exact workflow exception. No workflow bootstrap edit supplies actual CI/trusted delivery success; retain those external gates for T06.

## CS05 whole-file formatting disposition

A follow-up reports whole-file producer/test formatting with AST parity and no remaining pinned formatter errors, but no observed dated maintainer exception. This reviewer has not independently verified that parity/result or inspected another role's report. The authoritative `guides/CODE-STYLE.md` CS05 requires whole-file/repository mechanical formatting separately from behavioral/structural work unless the owning issue records a dated maintainer exception and the PR cites it.

**Read-only T05 preparation/review may continue with this as an explicit open decision.** The candidate can be examined and made concrete for a later decision; neither this preflight nor another reviewer can create the required maintainer exception. The earlier narrow formatting scope covered touched functions/new sources, so it cannot be retrospectively cited as acceptance of whole-file formatting. AST parity supports a mechanical-behavior claim for its actual comparison only; it does not satisfy the separate-PR/exception requirement.

Record exact affected paths, before/after identities, formatter/parity evidence and the missing exception in the issue/PR REVIEW gate and T06 handoff. Keep CS05/AC05 and the whole REVIEW gate pending. Do not declare this candidate compliant, accepted, Ready or eligible for workflow advancement while relying on the absent decision. The next gate is either (a) an actual dated maintainer exception in the owning issue, cited by the PR and followed by affected review, or (b) a conforming source disposition that avoids the mixed whole-file formatting and retains all required checks. Neither silence, a prepared candidate, passing checks nor this scope assessment chooses that outcome. No exception decision is invented and no implementation permission is expanded by this report.

## Acceptance disposition

| Criterion | Effect of correction | Remaining gate |
| --- | --- | --- |
| AC02 full exact-source integrity | Corrects the selected policy's fresh-runner dependency route; RI/CI identity must include it | Final clean-source execution and independent integrity review |
| AC04 final resource accounting | Adds small workflow/evidence inputs, counted after finalization | >=10MB final input headroom and all unchanged caps |
| AC05 authentic allocation/review/delivery | Preserves the original fixed Basic oracle while making its declared dependencies available | Actual policy CI, four source-bound roles/corrections, full protected-base lane and applicable maintainer delivery decision |

No requirements/oracle weakening is accepted. The original historical archive eligibility, recovery and semantic owner gates remain exactly pending to the extent not evidenced. This reviewer performed only source reads and wrote this assigned artifact; no tests, implementation, external writes or delegation. Provider/launch assurance limits remain those of the original preflight.

## Inspected source identities

- `.github/workflows/issue-acceptance.yml`: SHA256 `d2f5f752c838f002f92788db630af17246a02a91a79d941f77332b314f517102`.
- `.github/acceptance/issue-189.json`: SHA256 `0dd78d35fea8e0ac4cc3b47b795822136cfb14ae4aead23c00c5987f3d95a691`.
- `tools/quality/local.cjs`: SHA256 `ea8550ebac5b2f62147c60c8e0b70a54f6e60d20643cf190ec45c6a5d693f96d`.
- `tools/site/articles.cjs`: SHA256 `64aa6bfe5ed67011cac30401a9a1e84a4b8e481ee552609fe6aad717d943ddd4`.
- `tools/site/article-media.cjs`: SHA256 `eb90839d1348510379aedb9801ab89ffa2e959810fafd24ea9f17dd7e8467526`.
- `tools/publishing/web-media.py`: SHA256 `ad24001a471a6cf747e3f1a136cca605866d70d9cf4458bc4e1ff65e6653ad69`.
- `tools/publishing/article.cjs`: SHA256 `54459f1f49b3405bc5fdf9f5a3e627d026ad3bbe7822026dc1ca4602a69eb7cb`.
- `tools/publishing/toolchain/package.json`: SHA256 `88203a0a8d8421a69080829674ca25653723e6b26ad5821ce44da801c6d4c15d`.
- `tools/quality/toolchain/requirements.txt`: SHA256 `aca230d90b81c5e62440dba6d25348ac5954f324446bab54fd2a30b7cf0daa46`.
