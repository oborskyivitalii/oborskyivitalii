# Issue189 T05 — Code / Artifact affected correction review

**Technical correction PASS; advancement remains BLOCKED by the explicitly pending CS05 disposition and external gates.** No new blocking source defect found in the bootstrap correction. The original `code-first.md` remains unchanged. This is a continuation after first judgments, not a newly fresh first review or maintainer authorization.

## Identity and boundary

Task `/root/issue189_t05_code`; affected correction phase. Explicit none-fork was requested for the first execution; actual provider model/context/isolation internals and launch acceptance remain independently unobserved. Reused only my own first review and unchanged relevant sources. The candidate dated report contains reconciled first-role statements, which I treated as review subjects, not proof or peer verdicts to adopt. No delegation, implementation, test authoring, external writes, private chat or unrelated memory reads.

Correction packet `/workspace/scratch/2c34f552b848/issue189-t05/bootstrap-correction-packet.json` independently hashes to `10f8895103c6fe1253a9b620b12a3453b9360edf26a30afb4df2a6ccc1892428`. Every candidate/reference file size and SHA256 in it matches native inspected bytes. Original issue snapshot remains `ac9ee956d2acedda4a0c6e69536382cd55d724917569127c3cc5a7a88b645727`. HEAD/base is `1a0e877367d10e46382056372898f1fe5f3744cf`; protected comparison is `ca756417590b9176f9fc33428321ffe1f64158cc`; corrected native staged tree `d17707ff9452ce7b757950fdf73b094e5d989546`. This is still a dirty staged candidate, not clean committed delivery.

Cached binary patch SHA256: `a42ade8aafe1894ffb24b88d550a55bf9f993af9a89a072fcc9ba0556eb3353f`. Actual six-file delta from first tree `39f3437d2c0b830e039bf9410b19c6336529778a` has binary diff SHA256 `c34699d0d3518b40e68d9fb30264d33c11b7eb717b161f596cf05dd0ac36c85b`.

The common/role prompt bytes remain `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` and `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`. AGENTS/CONTRIBUTING/CODE-STYLE and unchanged producer/policy/Bandit/test sources retain the identities documented in my first report and verified against this packet.

## Independent inspection and conclusion

I inspected the actual first-to-correction tree diff, complete owning workflow, added protection assertions, RI/CI/source identity refresh and factual report/handoff changes. The sole executable workflow correction adds issue189 to four existing step conditions:

1. Locked quality Node-tool installation.
2. Pinned Python3.12.14 setup.
3. Existing Python venv and locked Ruff/PyYAML/packaging install.
4. Locked publisher AST installation and canonical Pillow pin installation.

Independent YAML parsing confirms exactly the four `if` scalars at step indices3/4/5/6 change; each retains its old admitted policies and adds only issue189. After excluding those scalars, parsed workflow objects are identical. Actions, commands, versions, jobs, permissions, timeout, source identity, clean-head requirement and upload behavior remain exact. This does not broaden selection to another owner or authorize hosted delivery.

The correction addresses the actual dependency path: `tools/site/article-media.cjs` selects the quality venv interpreter, while `tools/publishing/web-media.py` imports PIL and requires the canonical exact Pillow version plus its WebP codec version. The previously omitted issue189 conditions could leave BASIC without this dependency. Existing commands now provide the selected owner with the established bootstrap, instead of relying on ambient image state. No new runtime behavior or dependency pin was added.

The new guard in `test_complete_protected_closure_and_final_capacity` derives expected workflow text from immutable protected base and applies only the four explicit condition transformations. It additionally requires exactly four issue189 matches and exact resulting text equality. Thus adding the path to MUTABLE does not simply exempt all workflow contents: changed commands, other conditions, actions, permissions or budgets would fail the exact comparison. The existing fixed Bandit exception, deletion/addition sets, archive oracle and five resource bounds are preserved. The source of the expected result is the independent base and fixed accepted delta, not observed candidate content.

No new code correctness finding. CS01/04 keep the existing workflow/dependency owners and canonical pin; CS05 added Python is readable and pinned-format consistent; CS07 retains resource limits; CS08/09/10 use the owning method, existing route and current exact-source check. No new browser/UI matrix is justified by this bootstrap-only change. The correction is a workflow control change and remains subject to the complete protected-base delivery route, not a repository-only assumption.

## Actual verification

Independently reran:

- Owning task module:2 tests pass,2.297s. Protected exact-comparison count2638, hash inputs238,865,512bytes, final-at-this-candidate headroom11,134,488; derived1,775,824; tracked240,641,336. Largest parsed-text margin218bytes and all original hard caps remain intact.
- RI/CI coupling verify: pass,17 checks/19 layers; digest `303073ceb7f170193117a2e5d443edc700520e4554a8ef346d368af0ae051b2d`.
- Bounded style guard: pass,165 files/0 legacy occurrences; its declared subset only.
- Owning policy validation: pass, unchanged policy `0dd78d35fea8e0ac4cc3b47b795822136cfb14ae4aead23c00c5987f3d95a691`.
- Cached whitespace check, packet/file hash comparisons and independent full-workflow semantic comparison: pass.

Inspected, without claiming a new execution: `bootstrap-correction-probes.json` SHA256 `9404e792871c6d73e27cb002f14a8366127d9bf83748f79fa7f7be5880962116` retains actual fresh-venv creation, canonical `pillow==13.0.0` resolution, exact pinned install and successful PIL/WebP availability import. It explicitly says hosted_execution=false. I did not independently recreate that installation or attest the GitHub runner image.

The retained corrected policy report binds the corrected cached patch/RI surface, has45 checks, automated pass, no errors and all7 gates pending; closure readiness=false. Its tree field describes the HEAD tree while dirty source is separately bound by the patch and RI digests. I did not rerun all45/BASIC or the formatter in this role; their raw corrected runs were inspected, and my independent reruns are listed above.

## Retained unresolved requirements

CS05 whole-file mechanical formatting remains proposed. The dated report and handoff now accurately say no owning-issue maintainer exception has been observed, AST parity and reviewer approval cannot supply it, and REVIEW/AC05/Ready/T06 cannot advance until an actual maintainer decision or conforming source disposition. My first evidence question is therefore truthfully recorded, not resolved as an approval. No additional permission or approval is inferred here.

The delivery TAR remains the declared placeholder. Final first/correction receipts, lossless evidence packaging, RI/CI refresh and source-bound final accounting require verification after replacement. Existing19-original archive facts, producer semantics, Bandit constraints and policy mappings are unchanged and can reuse the exact prior observations; final evidence size cannot reuse the old capacity number uncritically.

No live GitHub admission, hosted execution, maintainer decision, merge or production evidence was established by this role. The original bootstrap source defect is technically corrected; all seven external gates remain pending, and the CS05 protocol disposition blocks advancement. This review does not authorize delivery.
