import pathlib,json,subprocess,time
r=pathlib.Path('/workspace/scratch/2c34f552b848/issue189-checkout');o=pathlib.Path(__file__).parent;logs=o/'candidate-checks';logs.mkdir(exist_ok=True);p=r/'.github/ri-ci-map.json';raw=p.read_text();old=json.loads(raw);results=[]
for name,cmd in [('coupling-refresh',['python3','tools/check_ri_ci.py','refresh']),('ri-build',['python3','tools/repository_intelligence.py','--config','.github/repository-intelligence-config.json','build']),('ri-verify',['python3','tools/repository_intelligence.py','--config','.github/repository-intelligence-config.json','verify'])]:
 t=time.monotonic();c=subprocess.run(cmd,cwd=r,capture_output=True,text=True);results.append({'name':name,'command':cmd,'exit':c.returncode,'stdout':c.stdout,'stderr':c.stderr,'seconds':time.monotonic()-t});(logs/'generation.json').write_text(json.dumps(results,indent=2)+'\n');print(name,c.returncode,c.stdout,c.stderr,flush=True)
 if c.returncode:raise SystemExit(c.returncode)
 if name=='coupling-refresh':
  new=json.loads(p.read_text());assert {k:v for k,v in old.items() if k!='reviewed_source_identity'}=={k:v for k,v in new.items() if k!='reviewed_source_identity'}
  key='"reviewed_source_identity":';start=raw.index(key)+len(key)
  while raw[start].isspace():start+=1
  _,length=json.JSONDecoder().raw_decode(raw[start:]);value=json.dumps(new['reviewed_source_identity'],ensure_ascii=False,indent=2).replace('\n','\n  ');focused=raw[:start]+value+raw[start+length:];assert json.loads(focused)==new;p.write_text(focused)
  a={x['path']:x['sha256'] for x in old['reviewed_source_identity']['inputs']};b={x['path']:x['sha256'] for x in new['reviewed_source_identity']['inputs']};(logs/'coupling-delta.json').write_text(json.dumps({'definition_identical':True,'added_input_paths':sorted(b.keys()-a.keys()),'removed_input_paths':sorted(a.keys()-b.keys()),'changed_input_paths':[p for p in a.keys()&b.keys() if a[p]!=b[p]]},indent=2)+'\n')
