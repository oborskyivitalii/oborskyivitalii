# Issue189 T05 — White-box QA affected correction

Date2026-11-10; reviewer execution `/root/issue189_t05_whitebox`, correction continuation. First judgment `whitebox-first.md` remains intact. This is not a fresh independent first context: I reused my own review and received the factual bootstrap delta plus the orchestrator's focused newline-boundary question after first results were preserved. No peer verdict was read or used as oracle, no delegation/implementation/external write occurred. Provider model/context/memory internals remain unknown; original launch-parameter evidence remains the orchestrator's responsibility.

## Verdict

The four-condition dependency-bootstrap correction is structurally sound and preserves previous policy partitions, commands, pins and workflow authority. **One medium guard/oracle finding remains:** the new exact protected-workflow comparison normalizes line endings, so its claimed unrelated-byte protection is too broad. Correct that comparison or explicitly narrow the accepted contract before calling this protection correction complete. No Ready/T06/delivery approval. CS05's dated maintainer exception remains pending and cannot be supplied by this technical review; all seven external gates remain pending.

The initial first pass did not execute a fresh hosted bootstrap path. Its no-blocking-finding conclusion was bounded to the examined cases and does not establish that dependency bootstrap was complete. This correction closes that previously unexecuted selection path, subject to the byte-oracle finding below.

## Input identities and reused evidence

Packet `bootstrap-correction-packet.json` SHA256 `10f8895103c6fe1253a9b620b12a3453b9360edf26a30afb4df2a6ccc1892428`; supplied staged tree `d17707ff9452ce7b757950fdf73b094e5d989546`; native HEAD `1a0e877367d10e46382056372898f1fe5f3744cf`; protected base `ca756417590b9176f9fc33428321ffe1f64158cc`. Candidate is staged/dirty, not clean committed source. Every candidate/reference hash from the new packet matched independently. Owner snapshot remains `ac9ee956d2acedda4a0c6e69536382cd55d724917569127c3cc5a7a88b645727`.

Common reviewer prompt remains SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; white-box prompt `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`. Same applicable AGENTS/CONTRIBUTING/acceptance/check-profile contracts as first report. CS05 was reread directly: whole-file mechanical formatting mixed with behavior requires a dated maintainer exception cited by the PR. Passing guard/format/parity cannot provide that decision.

Changed primary workflow SHA256 `626c1710fe641d7054fd8d10e81534693880e125ac8796656285fa2d5f18f287`; owning test `38b0fb8242ad7d19491617a91a3b20af89c901c30f1dbf1746424b10e4e30aa2`; RI/CI map `1778523736ebbf0eb56cdb8527f4313283eb62d0c82160024af930ac1ac6138d`. Unchanged issue policy/RI producer/RI suite/Bandit policy byte hashes match the first packet; their source review, archive baseline, named-test routing, format parity and narrow Bandit findings are reused only for unchanged portions. The new protected-closure method was read in full and executed on this source.

## Risk matrix and independent oracles

| Risk / AC | Scenario and oracle | Actual observation / route |
| --- | --- | --- |
| AC05 dependency omission | Issue189 must select quality npm, pinned Python, locked Python venv and publishing/Pillow setup before BASIC; prior policy decisions unchanged | Independent YAML parsed comparison finds exactly steps3/4/5/6 if-scalars changed, each adds only exact issue189 policy. Existing issue-acceptance.yml/acceptance route retained |
| AC05 unintended policy widening | Existing policies, unknown policy, path suffix, empty/traversal-like value | Parsed strict equality-OR grammar and membership partitions preserve all previous values; issue189 alone newly selects all4; unknown/lookalikes reject |
| AC03/05 excessive workflow exception | Mutable workflow path must permit only exact protected-base-derived four-condition extension | Existing protection/capacity method passes baseline and rejects timeout change, command change and missing189 bootstrap membership in memory |
| AC03/05 line-ending drift | Same text with different underlying bytes must remain outside exact condition-only exception | Temp CRLF copy has different bytes/hash but read_text comparison passes: finding WB-C01 |
| AC04 final accounting | Additional correction bytes stay inside all unchanged caps and >=10MB target | Current method executes complete native RI verification/accounting;11,134,488bytes headroom,218byte ledger margin. Final bundle not yet measured |

Dependencies inspected directly: policy BASIC uses fixed local.cjs; local basic platformCheck calls site/build.cjs --check; site article assembly loads publishing/article.cjs and article-media.cjs. article-media.cjs:11–13 chooses the canonical quality venv when it exists, otherwise python3. web-media.py imports PIL only inside encode, validates its exact canonical requirement and WebP codec; --requirement can run before PIL is installed. The corrected workflow establishes Node, selects policy, installs locked quality npm packages, establishes Python3.12.14, creates quality venv with exact Ruff/PyYAML/packaging pins, then installs publishing npm and canonical Pillow before acceptance run. Action pins, permissions, job/step order, commands, 10minute job budget, clean-source enforcement and always-upload failure evidence remain unchanged.

## Executed bounded checks

Command receipt8387e4, exit0,2.418s total: Python3 with PYTHONDONTWRITEBYTECODE=1 parsed current/protected workflow using yaml.safe_load; compared all YAML except four if-scalars, checked each actual condition against strict `env.ACCEPTANCE_POLICY == 'path'` OR grammar and compared exact policy partitions. Output:

```text
PACKET 10f8895103c6fe1253a9b620b12a3453b9360edf26a30afb4df2a6ccc1892428
MANIFEST True
step3 quality npm old9 new10;189 false→true
step4 pinned Python old2 new3;189 false→true
step5 Python tools old8 new9;189 false→true
step6 publishing/Pillow old3 new4;189 false→true
CHANGED_ONLY_FOUR_CONDITIONS [3,4,5,6] True
```

Same receipt executed only `Issue189AcceptanceTests.test_complete_protected_closure_and_final_capacity` as baseline:1 run,0 failures,0 errors,0 skips,1.597s. Raw native accounting:

```json
{"derived_bytes":1775824,"hash_headroom":11134488,"hash_input_bytes":238865512,"protected_paths":2638,"tracked_bytes":240641336,"metrics":{"files":{"limit":5000,"margin":2332,"used":2668},"hash_file_bytes":{"limit":32000000,"margin":20273390,"used":11726610},"hash_total_bytes":{"limit":250000000,"margin":11134488,"used":238865512},"text_file_bytes":{"limit":2000000,"margin":218,"used":1999782},"text_total_bytes":{"limit":50000000,"margin":28140880,"used":21859120}}}
```

Then patched Path.read_text in memory only for the workflow path, running the unchanged accepted method once per intentional fault. No candidate bytes/tests were edited. Each fault produced1 run,1 failure,0 errors,0 skips at tests/test_issue189_acceptance.py:237:

- timeout-minutes10→20, rejected in0.268s;
- remove first issue189 bootstrap membership, rejected in0.253s;
- quality npm ci --ignore-scripts→npm install, rejected in0.267s.

These intentional rejection traces are expected fault-probe outcomes, not baseline candidate failures. They show the workflow's mutable-list exception does not silently waive ordinary semantic drift. They are not measured branch coverage or new accepted tests.

## Finding WB-C01 — medium — newline normalization weakens exact protected workflow oracle

Location: `tests/test_issue189_acceptance.py:237`, `self.assertEqual((REPO / workflow_path).read_text(), expected_workflow)`. Affected AC03 protected closure and AC05 preservation of controls; the declared correction permits only exact four-condition extensions and says unrelated workflow bytes fail.

Path.read_text uses universal newline translation. A workflow changed from LF to CRLF is outside the base-derived four-condition byte delta but compares equal after normalization. Bounded independent probe receipt409c54 (exit0) wrote only a TemporaryDirectory copy of current workflow with LF→CRLF and compared it to the current candidate:

```text
RAW_BYTES_EQUAL False
READ_TEXT_EQUAL True
RAW_DECODE_EQUAL False
ORIGINAL_SHA256 626c1710fe641d7054fd8d10e81534693880e125ac8796656285fa2d5f18f287
CRLF_SHA256 552a3e6e2274ad4ed78cf44f2fb7faadf120a36ccd0fdd8c706e02cacf587431
```

RI freshness detects an unrefreshed workflow mutation, but normal regeneration binds RI to changed current bytes; it does not compare those bytes with protected base. Thus it cannot supply the omitted base-byte closure invariant. The present valid LF candidate is unaffected, but this test is weaker than its exact protected-source claim.

Treatment: compare `(REPO / workflow_path).read_bytes().decode('utf-8')` with the base-derived expected string (or compare encoded bytes directly), retaining the strict base oracle. A later affected negative should reject a CRLF-only change as well as the already detected semantic mutations. If the owner instead explicitly accepts normalized text equality, narrow the contract/report accordingly; current precise condition-only scope supports the byte-preserving fix. No fix or accepted test was authored here. Finding was communicated to orchestrator before this result.

## Retained evidence and remaining gates

Raw bootstrap-correction-probes.json SHA256 `9404e792871c6d73e27cb002f14a8366127d9bf83748f79fa7f7be5880962116` was inspected. It records fresh temporary venv creation, canonical pillow==13.0.0 requirement extraction, exact Ruff/PyYAML/packaging/Pillow installation, then Pillow13.0.0 import/WebP support, all exit0. This is retained local execution, not my new execution or hosted proof. No network install or expensive full suite was duplicated.

bootstrap-corrected-checks.json SHA256 `b2a08ebcec45ab71dc4aa4d5011c41c79e6c0dc2412589367a07f6f352c4e931` records maintained format, policy, coupling and bounded style passing on dirty source. candidate-policy-bootstrap.json SHA256 `3f438a205e1812f5ae4832d790e8436d366ec764414d0c38364404411c67c996` reports45 passing checks, automation_pass/evidence_valid true, closure false and all seven gates pending. Policy and current owning-test/source identities match packet. These are retained producer results, not independently rerun full campaigns.

NAVIGATION, INTEGRITY, ARCHIVE-ELIGIBILITY, CAPACITY, REVIEW, DELIVERY and MERGE remain pending. CS05 decision blocks REVIEW/wholeAC05/Ready even after a technical fix. Final lossless receipt bundle, regenerated identities, actual protected-base full-diff delivery selection, clean exact-source policy/scanners/admission/hosted results and final accounting remain separate. This correction review makes no live-GitHub, media-playback, platform-isolation or release claim.
