# Issue189 T05 — independent White-box QA first judgment

Date: 2026-11-10. Role/execution: White-box QA, `/root/issue189_t05_whitebox`, first judgment. Nonauthor review; no implementation or accepted tests authored. No peer verdict, parent scratch note, private conversation or unrelated memory was read. Supplied owner text and candidate claims were treated as review subjects and checked against actual local source. This result is preserved before reconciliation.

## Verdict and scope

No blocking defect found in the bounded T05 candidate inspected. The two owning checks detect the examined integrity/protection faults; policy routing preserves all 40 permanent RI methods and separates 45 automated checks from seven pending gates. This is preparation review, **not delivery, whole-AC acceptance, Ready, merge or production approval**. The final review-evidence archive is currently a declared placeholder; final evidence costs and clean-source checks must be measured after its replacement. All seven external gates remain pending.

Actual launch API parameters/accepted response are not visible from this reviewer execution; the orchestrator must attach its original explicit-none-fork launch receipt. I received the supplied task packet without author conversation. Platform memory behavior, provider model/context internals and provider-internal isolation are unknown, not attested. This is an operational reading boundary, not filesystem isolation.

## Exact inputs and identity

Native checkout `/workspace/scratch/2c34f552b848/issue189-checkout`; HEAD `1a0e877367d10e46382056372898f1fe5f3744cf`; protected comparison base `ca756417590b9176f9fc33428321ffe1f64158cc`; native staged tree `39f3437d2c0b830e039bf9410b19c6336529778a`. This is a staged dirty candidate, not a clean committed-source run. Local task branch points to HEAD; local remote-tracking task ref was `e4e09f45d014b985568af497e5958cc7eb8e3fab`. No origin/main ref exists in this checkout; the initial origin/main rev-parse returned128. Live GitHub refs/PR status are not independently observed here and must be reconciled by the orchestrator.

Packet `/workspace/scratch/2c34f552b848/issue189-t05/candidate-packet.json`, SHA256 `4d876e58b1c3551c30f239ab2b8ef26620f2a8a2b4abe1e3cf0dab4a927e0200`. Owner issue snapshot SHA256 `ac9ee956d2acedda4a0c6e69536382cd55d724917569127c3cc5a7a88b645727`. Every candidate/reference byte hash listed by the packet matched during my independent verification. Hash verification does not imply reading/comprehension of every reference.

Read common and role prompts plus root instructions and applicable protocol. Common `agents/reviewers/README.md` SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role `agents/reviewers/white-box-qa.md` SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`. Root AGENTS SHA256 `5785791859fd0aca18e2fb77e4803171fec75be8d708167972ce3f90be02eb05`; CONTRIBUTING `0dc5be319f0269b4ba56751348dc1758ca874cb0f067b440b2b0d60a6d8b577a`. README, REPOSITORY-MAP and task MEMORY were read; only root AGENTS is identified by the map. Acceptance contract and check-profile allocation sections were read.

Primary inspected source: issue policy `0dd78d35fea8e0ac4cc3b47b795822136cfb14ae4aead23c00c5987f3d95a691`; new owning test `88cf0c1be25b860fc6e15200b7201d3f40f77d724f8e4735ee381ba786ca8e42`; RI producer `d44cd68e3acca7d56f2723da84eeaddf911ce609fb0cdde4f77f7c5d50760294`; RI suite `69dc9cf2a28d96a5027630dc3a68d5e4231727ba2ef0703cd76869a7489165da`; Bandit policy `c33889efa39b3e603e7bfcc5f12765760d3a5cd31fad40fbe6709e35bf7add3b`; RI/CI map `420411b6d6b4426dd4576afcdc8607e31bd8ca83411a944d8d3268c2f67be1c8`. Also inspected existing numeric selector/test inventory, exact policy/mapping diffs, fixed Git subprocess call and actual frozen archive/closure oracles.

## Structural risk and check allocation

Expected outcomes derive from issue AC01–05 and immutable original selection/base, not candidate-green reports. Matrix distinguishes executed checks from retained/reviewed evidence.

| Risk / AC | Structural fault and scenario | Independent oracle | Check and route / observed result |
| --- | --- | --- | --- |
| AC03 archive identity | Selection follows edited HEAD; ZIP or recovered original bytes drift | Frozen selection SHA256, original base Git blobs, immutable ZIP digests; native unzip and Python extraction agree | ARCHIVE owning-policy method, issue-acceptance.yml/acceptance. Executed pass; selection/ZIP fault probes reject |
| AC03 useful complete gallery | Relative target omitted, duplicate/traversal member, locator points away | All 85 members per ZIP, member names/ancestors, original gzip gallery byte equality, local target closure and exact locator target set | Same ARCHIVE method executed; no added browser/media-playback claim |
| AC03 protected closure | Extra deletion/addition, protected byte/mode/symlink change | Protected base tree minus exact19 originals; explicit ADDITIONS/MUTABLE | PROTECTION-CAPACITY owning-policy method executed. Protected LICENSE-CODE byte fault rejected |
| AC02/03 narrow control exception | Blanket Bandit mutation/expiry extension hidden by mutable-path exception | Root key equality; exact48 ordered entries; only3 RI binding/rationale fields may differ, remaining45 rows equal; prefix-only append | PROTECTION-CAPACITY executed; unrelated-row severity and root deadline fault probes reject |
| AC04 final accounting | Derived savings counted as hash recovery; caps or margins weaken | Fixed5000/250MB/32MB/50MB/2MB; native tracked/input/derived sums; >=10MB final target | PROTECTION-CAPACITY executed, independently verified complete native RI/capacity. RI09–11 existing boundaries retained in policy, not rerun here |
| AC01/02 mechanical formatting | Behavior changes under formatting claim | Full Python AST equality with immediate HEAD for already touched producer/suite; JSON equality with retained preformat policy | Independent AST/JSON checks pass. New owning test includes later deliberate narrow guard addition and is not falsely claimed wholly equal to preformat AST |
| AC05 task selection | New task silently becomes permanent suite or owner methods unreachable | Existing exact numeric module grammar; current policy methods callable; future ordinary tests still execute | Two existing RepositoryTestSelectionTests executed pass; navigation.yml/navigation owns enduring selection regression, issue acceptance owns task methods |
| AC05 mapping and pending gates | Missing/orphan check; mapped policy falsely closes owner | Stable owner ACs; all40 actual RI methods; 45 checks,7 explicit external gates; exactly2 new controls in existing intent-acceptance layer | Inventory analysis pass; retained current policy evidence has45 passes and seven pending; COUPLING existing route retained |
| AC02/05 scanner binding | New finding/allowance or changed command hidden by rebinding |48 baseline rows; only3 exact-source coordinate/rationale edits; source hash and current actual call, no shell | Independent delta and call AST compare pass; complete raw Bandit/triage retained evidence examined; full scanner not duplicated |

No cancellation/UI state machine is introduced by T05. Native subprocess failure/timeout, input scan and capacity error paths are retained existing producer behavior and RI suites, not new behavior changed by formatting. Readability/semantic review and delivery remain external obligations. No branch-coverage percentage is measured or claimed.

## Executed checks and raw observations

All commands ran from the native checkout using system Python3, with PYTHONDONTWRITEBYTECODE=1 for test/probe imports. Baseline command used unittest.TestSuite with the two named Issue189AcceptanceTests methods. It ran each exactly once: 2 tests,2 passes,0 failures,0 errors,0 skips. Tool command receipt `4eadd2` exited0 in3.030s including the fault probes below; baseline per-test durations1.529s and0.653s.

Protection/capacity raw JSON:

```json
{"derived_bytes":1775824,"hash_headroom":11138735,"hash_input_bytes":238861265,"protected_paths":2639,"tracked_bytes":240637089,"metrics":{"files":{"limit":5000,"margin":2332,"used":2668},"hash_file_bytes":{"limit":32000000,"margin":20273390,"used":11726610},"hash_total_bytes":{"limit":250000000,"margin":11138735,"used":238861265},"text_file_bytes":{"limit":2000000,"margin":218,"used":1999782},"text_total_bytes":{"limit":50000000,"margin":28145127,"used":21854873}}}
```

Bounded fault experiment: mock pathlib.Path.read_bytes/read_text **in memory only**, scoped to one named path, run the existing accepted method, and restore the original method after each scenario. No candidate source/test/fixture bytes were changed. Expected result was rejection; do not count these intentional failures as candidate baseline failures or tests authored for acceptance.

| Injected fault | Exact observed accounting | Detection location / raw evidence |
| --- | --- | --- |
| Append X to frozen selected-files read |1 run,1 failure,0 errors | selection():65 `Frozen selection changed; original oracle must not follow HEAD` |
| Append X to v5 ZIP read |1 run,1 failure,0 errors | test_issue189_acceptance.py:95 SHA256 differs:27f52539… versus721900d7… |
| Append X to LICENSE-CODE.md read |1 run,1 subtest failure,1 error | :182 protected blob a72b7a73… versus d6456956…; continued RI scan then :202 `Input changed while decoding: LICENSE-CODE.md` |
| Root Bandit reviewBy2099-01-01 |1 run,1 failure,0 errors | :195 original2026-12-06 differs from2099-01-01 |
| First unrelated Bandit row severity HIGH |1 run,1 failure,0 errors | :202 non-RI old/new row equality fails |

The probe's convenience `detected` boolean required exactly one failure and zero errors; it printed false for the protected-byte scenario because subTest continues after its expected failure and the later RI scan also rejects the injected bytes. The actual trace demonstrates detection twice. This is an instrumentation classification detail, not an undetected fault or production failure. First output was retained in tool receipt4eadd2; no retry or source edit followed it. All other probes met that convenience boolean.

Two existing enduring selection methods executed once with unittest.TextTestRunner(verbosity=2): `test_actual_permanent_modules_and_explicit_task_policy_methods_are_available`, `test_future_arbitrary_modules_are_run_and_exact_numeric_task_modules_are_not_imported`. Receipt681a57: exit0,1.959s unittest duration,2 run,0 failures,0 errors,0 skips. The latter creates its existing temporary synthetic suite, executes ordinary modules and confirms numeric task modules containing a raising import are excluded. No complete enduring or acceptance suite duplicated.

Independent structural/accounting script receipt67bbac exit0: policy has45 checks/7 gates; actual RI test inventory40, no missing RI methods, no orphan check; both new named owner methods load as one case each. Exact numeric grammar admits test_issue189_acceptance.py and rejects alphabetic/lookalike/suffixed/newline variants. RI/CI map adds only issue189 policy and task module to existing intent-acceptance layer without adding checks/workflows. Existing selector is unchanged.

Independent source script receipt9943cd exit0: Bandit48→48 rows; changed row indices28,29,30 only; source/rationale changed for B404, line/source/rationale for B607/B603. All point to current producer hash. Current B404 import is line17; B607/B603 share sole `tracked = subprocess.run(` at213. Its complete subprocess.run AST equals protected base: explicit Git ls-files argv, capture_output=True, check=False, timeout15, no shell. Immediate HEAD whole AST equality independently passes for RI producer and suite. The same parity passes versus retained format-before bytes for those files and semantic JSON equality for issue policy. Retained new-test preformat hash differs from final guarded test; immediate-format parity report concerns its earlier formatted version f5f8c2… and cannot itself certify final88cf0c… bytes. Final current guarded method was read and executed directly.

## Retained evidence, diagnosis and limitations

Read raw first coupling failure (exit1: both new controls unmapped), associated bounded mapping diagnosis, raw first archive failure and diagnosis, current Bandit triage and policy delta, preformat byte snapshots/parity, Pillow setup diagnosis and current policy-ready report. These are historical/source-bound evidence, not my executions. Their reported conclusions were not used as sole oracle. Archive failure was explicit ZIP-member-only closure refusing an actual implicit directory; current ancestor-directory handling preserves original bytes and checks useful local closure. First failure remains in archive-first-failure-raw.json (SHA2566b8d0952434ab9a7d5b87a5a326166b7f40770835b7c018fd2699f7d3dad35d9). Coupling-first-failure SHA256b65c54319f18ddd275a0dcf2e6d891c645d045110800d2282d08be6f2faa266b.

Current bandit-current-admission.json SHA256d127b0655583279693c419fe25fdc2013e2b6ff02327a715fea99f64f42c1990 reports48 findings,48 reviewed,0 untriaged with current policy digest and complete16-file tools inventory. It does not remove the need for exact final scanner coverage in selected delivery. I did not rerun Bandit, Basic, all40 RI cases, style or coupling full suites. Existing source-check/hosted allocation remains required from protected-base full-diff selection; candidate policy/basic green supplies no repository-only exemption.

Retained candidate-policy-ready.json reports45 passed checks, automation_pass true, evidence_valid true, ready_for_issue_closure false and seven gates pending. I verified its policy and owning-test identities against this candidate, and independently executed the two new methods. Its remaining checks are retained results, not independently rerun here. Earlier Basic dependency failure remains separate (partial local quality interpreter lacked PIL); no source/lock behavioral fix is inferred from installing existing pinned dependencies.

Seven gates: NAVIGATION, INTEGRITY, ARCHIVE-ELIGIBILITY, CAPACITY, REVIEW, DELIVERY, MERGE. They remain pending in this first result. Actual current GitHub admission/checks, live owner/PR/consumer changes, media playback, human source/eligibility/usability decisions and trusted hosted/merge/effective-source evidence are not observed here. No new browser surface is introduced by T05; legacy media playback remains an unobserved external obligation, not not-applicable. Additional source/meaning/test-oracle changes need affected review; deterministic receipt/RI refresh reuse must verify all relevant bytes and final accounting. No majority vote or green policy can replace the pending gates.
