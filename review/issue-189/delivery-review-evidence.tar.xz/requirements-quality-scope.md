# Issue 189 — T05 source-quality scope addendum

Date: 2026-11-10. Requirements & Acceptance continuation; targeted preimplementation scope assessment. Original `requirements-preflight.md` is preserved unchanged. This continuation has received the orchestrator's stated diagnostic proposal/current-candidate status; it is not a new fresh independent first judgment and does not accept that status as executed evidence.

## Verdict

**Within the accepted bounded preparation scope, subject to evidence and the limits below.** Read-only pinned formatter/linter/Bandit probes and necessary mechanical corrections to already changed owners support AC02/AC05 and do not introduce a new runtime feature. The original no-producer-behavior-change boundary remains binding. Narrow revalidation of the three existing RI Bandit dispositions can be necessary source-quality work, but is a security-policy correction requiring actual current-source finding/context review, not a deterministic hash refresh or inherited acceptance.

No new maintainer permission is required for this reversible, necessary preparation. No Ready/staging/merge/production action or gate waiver is authorized by this addendum. All whole AC01–AC05 remain open.

## Primary observations

- Read actual `format.cjs` formatter-settings/toolchain checks, the complete short `ruff-format.toml`, the Bandit scan/admission path in `scanners.cjs`, the three RI policy records and relevant `bandit-triage.cjs` source/line/rule/severity/expiry checks.
- `format.cjs` requires declared/installed Prettier 3.6.2 and Ruff 0.16.10, exact formatter settings, maintained inventory and tracked source. This review did not execute those tools. The parent-reported untracked-source refusal and 45-check result are not independently verified here.
- Actual producer SHA256 is `bd40042bac259cc896e2c8715d754ee1ccabd9f0cac7794ec8f0c2adeaefde1b`. All three existing RI Bandit records still bind `dad68d88d241c2cd223081d6a28961c1aa7abc19c0f4c223c9c3382c562aa792`: B404 at line17 and B607/B603 at line193. Their deadline is 2026-12-06. Their prose explicitly expires review upon source/line/rule change; the admission code rejects source mismatch. Thus the old dispositions cannot be cited as current producer acceptance merely because the import/call text may be unchanged.
- The scanner owns a full `tools` recursive scan with unchanged toolchain exclusion, raw finding collection, admission and expected-Python coverage. Preserve this route; a narrow diagnostic can investigate but cannot replace required final coverage.
- Current checkout is dirty and includes the new owning policy/test/evidence. Initial preflight clean HEAD remains the prior source, not this completed candidate. This inspection is not final candidate review or live delivery observation.

## Required constraints

1. **Probe before fixing.** Retain exact commands, installed tool versions, current source bytes/status, inventory and complete raw results, including the first refusal/failure. Diagnose the actual result before selecting a bounded correction. Do not run broad autofix, invent exceptions or label skipped/untracked input checked.
2. **Mechanical formatting only.** Limit edits to already touched RI functions/tests and new policy/test sources. Preserve Python AST including docstrings and relevant type comments, literal values and executable behavior against the immediately preceding T05 source; retain before/after identities and an actual parity result. For JSON use parsed semantic equality including stable array order, followed by normal policy validation. Review comments/instruction text and other meaning outside a location-free AST separately. No lint autofix that changes semantics, import behavior, scanner scope or source selection. A full-file formatter request that would expand into untouched legacy formatting must be assessed against the repository's separate-formatting rule instead of silently broadening the scope.
3. **Fresh Bandit context review, not only line equality.** Require actual pinned Bandit 1.9.4 output for final bytes, complete raw accounting and one-to-one correspondence for exactly the three existing RI rule records, preserving severity, confidence, test-name, line-byte signature and the reviewed shell-free argv/PATH trust assumptions. A line-number move can be recorded only from the actual report. Assess relevant changed callers/data/control paths since the old pinned source: formatting AST parity does not prove that the earlier T03 semantic changes preserved security. If the rule/line/context assumptions differ or a new finding appears, stop the proposed simple rebind and record the new evidence and necessary treatment; this addendum supplies no additional allowance.
4. **No waiver expansion.** Preserve all other policy rows and fields, original expiry, thresholds, scanner configuration/toolchain, budgets and admission failures. Rebind only necessary existing RI identity/location fields after substantiation, with a truthful source-bound current review reference. Do not copy old claims of identical whole-source AST to a source that had T03 behavior changes. Any substantive rationale correction must accurately identify the current review and undergo review with the policy diff.
5. **Explicit protected exception.** If a real probe demonstrates the need, add the exact `tools/quality/bandit-policy.json` exception as a named reviewed correction with the permitted field/record scope fixed before accepting it. Do not derive an allowlist from arbitrary HEAD drift. Existing protected resources and original frozen19/archive manifest remain unchanged. Security policy is a control surface: retain complete protected-base lane classification and all full/source obligations; this correction grants no repository-only exemption.
6. **Rebind final evidence.** Formatting or policy changes invalidate affected prior byte/source evidence. Refresh appropriate RI/catalog/coupling outputs and final capacity accounting after all receipts, run relevant exact-source source-quality/owning checks, and obtain fresh four-role review of the changed candidate and its security-policy exception. Prior unchanged observations may be reused only with matching inspected identities; the reported dirty 45-check run does not establish clean final-head success. The actual final trusted scan/lane remains a later gate.

## Acceptance linkage and next gate

| Obligation | Supporting observation/check | Pending decision/evidence |
| --- | --- | --- |
| AC02 exact full integrity | Current-source native RI/coupling and admitted complete source inventory after mechanical edits | Final current-source execution and integrity review |
| AC04 final capacity | Recomputed complete input/storage/derived totals after new evidence/policy bytes | >=10MB final headroom and all original limits |
| AC05 CS05/08/09/10 and applicable architecture/security rules | Pinned format/lint probes, actual AST/JSON parity, exact three-finding Bandit review, owning policy and guards | Four-role corrected-candidate review, complete-diff allocation, actual trusted lane and applicable maintainer delivery decision |

Proceed with read-only probes. Only evidence-supported corrections within these bounds are covered. Return new findings or behavior/oracle changes for targeted reconsideration before dependent expansion. No tests, implementation or external writes were performed by this reviewer; only this assigned artifact was written. Launch/provider assurance limits remain those of the original preflight; no new isolation claim.

## Inspected source identities

- `tools/quality/format.cjs`: SHA256 `c95dd0c6ccd20e1fa855becd9431b7250e7a9a5e66101b5ef8456d2a4dfdced7`.
- `tools/quality/ruff-format.toml`: SHA256 `774a90bc050e15df8b211bb26db7b3536381ecdc0c6b192266c3c223a63f197a`.
- `tools/quality/scanners.cjs`: SHA256 `54919dd5235ed20cbe193bbe844758a4e3badc9391f6da8c6a5b7641194921f5`.
- `tools/quality/bandit-policy.json`: SHA256 `425f5b803972f6ef9c099eefce05e44a312493622da90ca432250bd110fdfede`.
- `tools/quality/bandit-triage.cjs`: SHA256 `597454f795bf287c7eee5765db0b88589741e96c3f991091669db14275884564`.
- `tools/repository_intelligence.py`: SHA256 `bd40042bac259cc896e2c8715d754ee1ccabd9f0cac7794ec8f0c2adeaefde1b`.
