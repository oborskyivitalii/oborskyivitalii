# Issue189 T05 — White-box QA byte-boundary correction

2026-11-10; role/execution `/root/issue189_t05_whitebox`, targeted correction continuation. Prior first and bootstrap-correction reports are preserved unchanged. I reused my own prior source review/finding, not peer verdicts. No implementation, accepted test authoring, delegation or external write. Provider model/context/memory internals remain unknown; this continuation is not a new fresh first context.

**WB-C01 resolved on the inspected candidate.** The former CRLF counterexample now fails the exact protected-workflow assertion, while the complete protected-closure/RI/capacity baseline passes. No further blocking technical finding in this targeted delta. CS05 maintainer exception and all seven external gates remain pending; this is no Ready/T06/delivery/merge/production approval.

Input packet `byte-boundary-correction-packet.json` SHA256 `472b36fda9200b9494b0b69156ca1a629ad1180e0a3a42452049ac6501712608`; native staged tree `bb3ec3f34f9dcd6075a749a177c2a9485ed0a5b8`; HEAD/base unchanged from prior report (`1a0e877367d10e46382056372898f1fe5f3744cf` / protected `ca756417590b9176f9fc33428321ffe1f64158cc`). Every supplied candidate/reference hash independently matched. `git diff --cached --quiet bb3ec3f34f9dcd6075a749a177c2a9485ed0a5b8` exited0, confirming staged tree equality. Source remains staged/dirty, not a clean committed-source check.

Common/role prompt identities remain `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` / `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`. Accepted intent and scoped instructions are unchanged. Current owning-test SHA256 `a98a3a19074cbb0d89cb1fb8b2ee3b2396a01e0a88a5b4b7bc112cd113568fd6`.

Independent staged diff against prior correction tree `d17707ff9452ce7b757950fdf73b094e5d989546` confirms the sole source/oracle delta in examined source paths is test_issue189_acceptance.py:237:

```python
self.assertEqual((REPO / workflow_path).read_bytes().decode("utf-8"), expected_workflow)
```

Workflow, owning policy, RI producer and Bandit policy have no delta against that tree. The protected-base-derived expected workflow is unchanged. Thus prior four-condition partition analysis, dependency-path review, command/timeout fault rejections, archive/Bandit protection review and numeric routing evidence are reused only for their unchanged scope. Deterministic RI/identity/report refresh is separately represented by packet bytes.

| Risk / AC | Scenario / independent oracle | Executed result |
| --- | --- | --- |
| AC03/05 exact workflow closure | CRLF bytes differ from base-derived permitted LF workflow even when text normalizes | Existing protected method now rejects CRLF at line237 |
| AC02/03/04 integration | Actual permitted workflow, unchanged protected tree/limits, exact RI freshness and complete capacity sums | Existing protected method passes on native corrected candidate |

Raw receipt890475: Python3, PYTHONDONTWRITEBYTECODE=1, unittest.TestSuite with only `Issue189AcceptanceTests.test_complete_protected_closure_and_final_capacity`. Baseline1 run,0 failures,0 errors,0 skips,1.657s. For negative probe I mocked Path.read_bytes **in memory only** for the workflow path to replace LF with CRLF, then ran the same existing method. Probe1 run,1 expected failure,0 errors,0 skips,0.324s. The exact line237 assertion rejects `\r\n` versus `\n` before RI regeneration/integration, directly establishing the repaired protection boundary. No candidate/fixture/test bytes changed. Receipt exit0 reflects the diagnostic harness; the intentional negative unittest result is not candidate baseline failure. No full suite duplicated and no coverage percentage claimed.

Current baseline accounting:

```json
{"derived_bytes":1775824,"hash_headroom":11133906,"hash_input_bytes":238866094,"protected_paths":2638,"tracked_bytes":240641918,"metrics":{"files":{"limit":5000,"margin":2332,"used":2668},"hash_file_bytes":{"limit":32000000,"margin":20273390,"used":11726610},"hash_total_bytes":{"limit":250000000,"margin":11133906,"used":238866094},"text_file_bytes":{"limit":2000000,"margin":218,"used":1999782},"text_total_bytes":{"limit":50000000,"margin":28140298,"used":21859702}}}
```

Native source/delta check receipt459377 exited0. Later final bundle replacement and deterministic refresh still require source-hash reconciliation, final clean-source required checks and accounting. NAVIGATION, INTEGRITY, ARCHIVE-ELIGIBILITY, CAPACITY, REVIEW, DELIVERY, MERGE remain pending, including CS05's explicit maintainer decision. No hosted execution, live-GitHub admission, owner acceptance, media playback or effective delivery was observed in this targeted check.
