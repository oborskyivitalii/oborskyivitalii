## T01 — native source and archive preflight, 2026-11-10

### Scope and actual stopping point

The maintainer authorized iteration1 after reviewing the staged execution plan: complete source/consumer inspection, freeze the archive selection and protected files, then **report before moving/removing originals**. This checkpoint performs that bounded work. It does not implement scoped RI/short-map behavior or archive deletions.

Native checkout acquired at PR190 head **cbb7dfa8b4f0ab4e3ca6448843edf84da3bd8b1a**, tree **c2c8f5bcd4d4a6e0814fd1cc95eb757d4bc2950f**; production/main remain **ca756417590b9176f9fc33428321ffe1f64158cc**. The native checkout was clean at baseline. Published release prod-2026-11-10.1 targets that production source. Later commit/evidence additions are separately measured and do not change selected original/archive identities.

### Read boundary and consumer conclusions

Read and byte-identified **647 current-role textual paths /16,424,426bytes**, including code, tests, config, guides and the extra MJS/SVG/git-text families. Roles and path coverage came from the current catalog; source identity was checked against native Git objects. Generated/history/draft material is not conflated with current execution. Historical capture records, offline/static manifests, execution records and current archive locators were inspected separately.

All5 open nonowning PR source overlays were frozen and inspected at their actual heads:

| PR | Frozen head | Source/config/draft text paths inspected |
| --- | --- | ---: |
|79 |5ee28e5f9833df8eb6da8bc5aaab8b5655bc92f2 |585 |
|107 |50efb5c07dc4d8087be6a2731d6f3871f6116be6 |455 |
|110 |f96425baa9195b06149fd32c85cc6c9056efadcf |695 |
|117 |8d215e1d78719fa80abb9c007b57048c6d8daeec |432 |
|171 |39afcc67b0b5612a787c82d0574d0468bfb5962c |642 |

The overlay boundary covers textual source/config/test/guide/agent/draft roots and root text, excluding generated views and old lock/security-disposition data as dereferencing consumers. Immutable object reuse avoided downloading the same source repeatedly;580 additional blob variants were read and native-ID checked. The exact path/blob inventory and exclusions are preserved in the evidence bundle. This is not a claim to have executed every branch or exhaustively understood arbitrary dynamic code.

**Selected21 exact paths:** current references occur only in the path catalog. Full generated RI views list them by design. Basename-only matches in tests use temporary controlled fixtures; capture tools bind output to **v11**, not the selected v5–v7 directories. All5 open PRs retain the same21 selected Git blobs and have no exact selected-path source references in the inspected boundary. Their basename matches are likewise v11/fixture paths. No unfinished article, presentation or current build input is selected.

For the broader195 candidates, old security-baseline records also mention paths. Those historical closed-ledger bytes remain protected. For the final21 specifically, there is no exact-path hit in the current security ledger. No ledger entry, byte limit or scanner suppression is changed.

Historical captures.json and offline-bundle manifests still describe the original old editions; they must remain byte-exact. Existing old gallery HTML is already a small locator linking to the preserved gzip original. Recovery guidance will point to unpacking the unchanged complete ZIP so relative media paths are restored, rather than silently rewriting old evidence.

### Frozen archive selection

Select the largest old capture files in descending (bytes,path) order until gross recovery reaches12,000,000bytes. The resulting exact21 paths are in **selected-files.json**; do not expand the batch by filename similarity.

| Original capture family | Files | Exact loose bytes |
| --- | ---: | ---: |
|v5 |7 |3,863,421 |
|v6 |7 |3,747,039 |
|v7 |7 |4,496,035 |
|**Total** |**21** |**12,106,495** |

These are contact sheets, recordings and two large v6 screenshots. There are6 contact sheets,13 recordings and2 screenshots. Existing unchanged ZIPs already contain every original; no new historical ZIP is needed.

Original work ownership is issue1: v5 introduction33806f116c38aa0c99f84468c5be944ed5aa9440; v6 introduction407f94f0c8de2b3a0749729eb8fbebc1b317fe61; v7 introduction6b2d13ef291dac90c423cbf93e448eab00bc2818. Issue1's old visual directions were superseded; current production source plus current/open-PR v11 producer bindings establish the concrete replacement, not issue closure alone. The current published source/release and all unselected archives/current inputs are retained.

### Actual binary/member/native-original verification

Fetched all3 original ZIPs read-only at the fixed production commit through ordinary HTTPS after the connector's binary/large-file limitations were observed. No unsafe transport override or credential change was needed.

| Existing ZIP | Bytes | Selected members verified |
| --- | ---: | ---: |
|review/site-v1-20261002-v5.zip |10,266,858 |7 |
|review/site-v1-20261002-v6.zip |11,726,610 |7 |
|review/site-v1-20261002-v7.zip |11,065,237 |7 |

Each archive's actual SHA256 and Git blob ID match the frozen repository record. Each contains85 unique member names; selected members are unique, exact relative names with no traversal. Decoded21 members match their **actual native loose originals** in length, SHA256 and Git blob identity; total12,106,495bytes. No original was removed, no archive was recompressed, and no failed historical evidence was discarded.

Raw proofs are archive-member-preflight-proof.json and native-selected-original-proof.json inside audit-review-evidence.tar.xz. They establish actual read-only recovery, not just matching old inventory sizes. T02 must revalidate the frozen IDs before mutation and compare each practical extraction/locator path afterward; unchanged bytes can reuse this proof.

### Protected set and planned T02 delta

The baseline native tree has2,676 tracked files. Default protection covers **2,655 existing paths outside the21 selected originals**. The frozen tree and a digest of the protected path/mode/blob listing are recorded in selected-files.json, allowing deterministic regeneration rather than committing another large duplicate inventory.

For the archive-only iteration:
- All existing site/, docs/, tools/, tests/, drafts/ and agents/ bytes remain exact, including current/unfinished publications, retained editions, rights and rollback resources.
- All3 ZIPs, original gzip galleries, captures/contrast/offline/static manifests, old planning-review bundle and all other unselected historical binaries remain exact.
- Explicit metadata exceptions are the catalog, generated RI views, MEMORY task pointer, this owning analysis, and the3 existing gallery locators if links to recovery guidance are added. A CI map digest update is allowed only if actual coupling verification requires it and its meaning is unchanged.
- Add one ARCHIVE.md per old capture directory and one owning recovery index; remove only the21 loose originals after successful rechecks. Do not create fake PNG/WebM content or21 duplicate per-media handoff files.
- Keep the original-path→archive/member/size/hash mapping in the owning index and directory guidance. Old Git-pinned original URLs remain available; removed loose media paths at the new branch will require recovery. No claim of unchanged direct loose-media URLs is made.

This protected contract is specifically T02 archival scope. T03's intended producer/config/test edits need their own explicit current diff and test-impact review; they are not secretly authorized as archival exceptions.

### Capacity: actual baseline and bounded forecast

Actual native ri.build() succeeded on the clean starting checkout, covering2,674 nonderived hash inputs:
**249,814,458bytes**, with **185,542bytes spare**. This is stronger than the earlier metadata-only estimate, but it does not verify the stale generated outputs. The source projection digest was0875010ee5c63011ef5d58c8cfc6d015f57e7fefb27f721c33449c226b5567c1.

Conservative planning envelope:

| Term | Bytes |
| --- | ---: |
|Starting native hash inputs |249,814,458 |
|T01 new report/index/evidence ceiling |+150,000 |
|T02 locator/catalog/recovery evidence ceiling |+100,000 |
|Remaining RI implementation/evidence allowance |+1,000,000 |
|Verified removable loose originals |−12,106,495 |
|Conservative final hash inputs |238,957,963 |
|**Conservative final spare capacity** |**11,042,037** |

The accepted minimum is10,000,000bytes. This leaves1,042,037bytes beyond the accepted reserve **if the overhead ceilings hold**. It is a forecast, not actual saved capacity; source additions/locators and the complete final candidate must be measured again. The first2MB archival checkpoint is comfortably supported by this selection but remains an actual T02 measurement.

T01 itself has only185,542bytes baseline room. Keep the compressed evidence bundle and selected index under the150KB T01 ceiling; actual final native scan is required before publishing this checkpoint. Existing output-size reductions do not count toward physical input recovery. No limits are raised. The218-byte margin in secrets-reviewed.json remains reported and its bytes protected.

### Test-impact allocation before archive changes

| Obligation | Check / oracle | T01 disposition |
| --- | --- | --- |
|Selected bytes exist in old archives |Actual archive SHA256/Git identity, unique safe member lookup, decoded member vs native original |21/21 pass read-only |
|No current/unfinished capture consumer lost |647 current sources plus5 pinned PR overlays; exact and basename/path-root inspection |Scoped source evidence recorded; later branch changes require delta check |
|Protected source/rights/fixtures/history |Native base path/mode/blob set; compare full T02 tree with explicit metadata exceptions |Contract frozen; mutation comparison pending |
|Recovery remains practical |Exact per-member command and full-ZIP relative layout, directory locator and index |Binary data verified; new locator/command journeys pending T02 |
|RI/capacity stays complete |Actual native scan/build, catalog coverage; regenerate and verify current outputs |Baseline build pass; final current-source build/verify after checkpoint artifacts required |
|RI/CI/style routes |Existing permanent RI/coupling/root-layout/style checks; selected owning policy later |No producer/oracle code changed here; run affected current checks, preserve historical task snapshots |
|Website/build behavior |Protected site/docs/public closure; actual trusted full-diff lane |No website behavior change or hosted admission claimed; no capture/perf campaign merely to validate old media metadata |

The future archive delta may select the full trusted route because of media deletions/control paths. This preflight does not grant a repository-only exemption. Do not run stale article-specific or all numbered historical issue snapshots as a substitute for current mapped checks.

### Tool/access and failure accounting

Two PR changed-file-list calls (107/117) returned internal tool errors; complete immutable head trees supplied the source boundary instead, without treating an empty result as absence. General GitHub Fetch refused binary UTF-8 decoding, contents API returned empty large-file content, and blob text decoding failed. Those failures were preserved; none is called successful recovery. Direct fixed-commit raw downloads returned the actual ZIPs and passed independent hash/native-member checks. The earlier wrong-host Git transport probe did not establish that all Git access was blocked: ordinary public Git clone succeeded and the native checkout is now available.

Large scratch text materialization was stopped after becoming inefficient; all source blobs were retained, streamed via a native-ID-checking writer and verified before audit use. No acceptance campaign was rerun unchanged or failed result erased.

### Completion boundary

Iteration1 ends with the exact21-path selection, actual archive/member/native-original proof, protected contract, source-consumer findings, bounded forecast and test-impact allocation. Four independent role results and final native checkpoint checks are recorded below when complete.

**No archive deletion or RI feature implementation in this iteration.** All full issue AC01–AC05 remain unchecked: preflight proves only their relevant subconditions. Next authorized continuation after this report is T02, revalidating the source lease and applying the bounded archive delta; T03–T06 remain afterward.
