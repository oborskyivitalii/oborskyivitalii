# Issue189 T01 — Requirements & Acceptance first result

2026-11-10. Reviewer: `/root/issue189_requirements`, same Requirements role continued for a new bounded T01 iteration. Prior own analysis is reused where instructions/source contracts remain unchanged; this is not a fresh-context claim. No current peer verdict or output was read. Provider-internal model/context/history injection remains unknown. Actual launch/continuation receipts belong to the orchestrator.

## Identity, scope and verdict

Native source inspected: clean `cbb7dfa8b4f0ab4e3ca6448843edf84da3bd8b1a`, tree `c2c8f5bcd4d4a6e0814fd1cc95eb757d4bc2950f`, in `issue189-checkout/`. Candidate `issue189-t01/audit-candidate.md` independently matches SHA256 `80bf9cc77c1e1adbba4379ed737ec57fdcbf90e3527acd78ece2a477b18a6191`; packet `review-packet.json` matches `46883d31d0a0907d8fe1194e87da09544731e9e0ea9caf8029791c3ae774641b`. All ten packet-listed files match listed byte lengths/SHA256. This result evaluates the frozen **21-file** candidate; a subsequently discussed selection correction has not been accepted by silently substituting it into this first result.

Read native README, root AGENTS, common/Requirements prompts, MEMORY, relevant CONTRIBUTING/RI contracts, owning `review/issue-189/2026-11-10-analysis.md`, supplied live-issue text, selected/protected/forecast contracts and primary proof files. Common prompt SHA256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role: `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`; native owning analysis: `3e7c149e988e8f710407da931b3e34f77e077d4d916b9052d0b79f993a3d95c6`. Root AGENTS is the only tracked live AGENTS.

**Verdict: T01 now has substantive, independently reproducible native/member/consumer evidence and a plausible bounded capacity forecast. The report needs the three contract dispositions below before it is used to advance to archival mutation.** No selected original or archive-integrity defect was found. This is not approval of T02, issue completion, merge, hosted behavior or release. The supplied authorization is iteration1 and stop/report before moving/removing originals; that boundary was observed during my checks.

## Findings

### T01-R1 — P1 at the mutation boundary: report completion is not T02 authorization

Location: candidate “Scope and actual stopping point” versus final “Completion boundary”, which says: “Next authorized continuation after this report is T02 ... applying the bounded archive delta.”

Evidence/impact: the supplied current authorization explicitly covers iteration1 and stopping/reporting before moving/removing originals. The final sentence can instead be consumed as an existing authorization to begin deletions immediately after emitting this report. Source/user authorization and successful review are separate preconditions; AC03/AC05 and the original intent cannot be satisfied by a reviewer or report supplying that decision.

Treatment: distinguish the next planned step from the existing authorized scope. At this checkpoint stop/report with originals intact; do not infer permission to mutate from successful preflight. If an existing user instruction already authorizes T02 beyond this stop point, cite that exact scope rather than inventing another approval requirement. None was supplied to this review. This finding concerns the report's operative wording; it does not call for repeated permission about each routine file.

### T01-R2 — P2 before T02: the machine-readable and prose protected exceptions disagree

Location: candidate “Protected set and planned T02 delta”, and `selected-files.json` → `protected_contract.permitted_T02_existing_metadata_changes`.

The prose conditionally allows an unchanged-meaning RI/CI digest refresh if actual verification requires it; the JSON's explicit existing-metadata exception list omits `.github/ri-ci-map.json`. The catalog and generated views are listed. The native coupling owner includes catalog bytes in its reviewed identity, so catalog/path updates and a digest refresh are a real dependency, not an unrelated prospective convenience.

Failure mechanism/AC impact: a T02 protected-tree checker using the explicit JSON list would reject that refresh; a prose-driven implementer could silently broaden the machine contract. Neither is a single clear protected-set oracle for AC03/AC05.

Treatment: reconcile the conditional digest-only exception in the canonical protected contract before mutation, retaining the exact unchanged-meaning restriction and actual coupling check. Do not add a blanket permission to alter workflow/routing/map meaning. The frozen default protected set itself is reproducible and sound; the issue is its exception representation.

### T01-R3 — P2 selection rationale: the new 12 MB gross threshold is larger than the stated minimum needed

Location: candidate “Frozen archive selection” chooses largest files until gross recovery reaches 12,000,000 bytes; owning plan says select the smallest eligible batch meeting the complete final target.

Independent arithmetic using this same forecast:

- Required gross removal = 249,814,458 + 150,000 + 100,000 + 1,000,000 − 240,000,000 = **11,064,458 bytes**.
- The largest **19** files from the proposed21 total **11,386,774 bytes**, giving **10,322,316 bytes** forecast final headroom under those same ceilings.
- Proposed21 total **12,106,495 bytes** and give **11,042,037 bytes** forecast headroom. The extra two v6 screenshots total **719,721 bytes**.

The extra margin may be reasonable, and these two files passed the same recovery checks; this is not a finding that they are corrupt or active inputs. However, the unaccepted rounded gross threshold does not demonstrate that21 is the smallest batch satisfying the accepted10 MB objective under the stated envelope.

Treatment: either narrow the batch consistently with the accepted minimization rule or explicitly disposition why the additional margin is needed and how that changes the selection objective. Preserve exact selection/protected/forecast identities across the correction; do not treat my arithmetic as an authored or accepted replacement index. Any larger unknown overhead must still be measured rather than covered by an unexplained target increase.

## Actual independent checks and evidence limits

1. **Native/member recovery:** read all three cached ZIPs and their actual native tracked counterparts. For each, byte length, SHA256 and Git blob ID match the frozen archive record. All85 member names in each archive are unique and relative without traversal. Read/decode each selected member and compare it to the native loose file: **21/21 exact matches; 12,106,495 decoded bytes**. Native originals remained present. No archive was rewritten and no extraction was performed into repository paths.
2. **Current source identity and references:** independently verified all **647 current-source records /16,424,426 bytes** against actual native bytes and Git blob hashes. Exact selected-path references occur in catalog entries, not active consumers. Capture-root references also occur in the protected old security baseline without exact references to selected21. Inspected basename-bearing producer/test sources: producer binds v11; preview/quality tests create controlled temporary fixtures. An additional exact-path/root search over remaining UTF-8 tracked sources found generated inventories and historical manifests/inventory; omitted textual draft sources supplied no such selected/root hit. This is bounded static evidence, not exhaustive dynamic-code understanding.
3. **Open-PR source overlays:** independently verified all **580 cached variant blobs** against their content-addressed names. Per-PR source counts reproduce **585/455/695/432/642** after the explicitly declared metadata-only pairs are excluded. No exact selected-path reference was found in that inspected source boundary. Initial all-path comparison correctly exposes those metadata exclusions; they were not silently counted as inspected source bytes. I did not execute any PR branch.
4. **Open-PR selected originals:** the initial count-only proof was not independently sufficient. Additional primary `open-pr-selected-primary.json` is now supplied, SHA256 `171ec8e97342230e7855772a4b302f5302d6d8df23c3f64d6d6135dda5795405`, with immutable tree URLs, `truncated:false` and per-path mode/blob/size rows. All **21 rows across each of five pinned PRs** match selected native blob/size and regular mode. The branch commits are absent from the local Git object store: this comparison relies on the supplied actual connector tree records, not a fabricated local branch checkout or fresh live-state observation.
5. **Protected set:** independently reconstructed the **2,655** nonselected path/mode/blob rows from the fixed native tree. Its exact newline-terminated Git-order listing equals supplied `protected-base-index.txt` and reproduces digest `f806e3e3e31a5a0720a20d988c099c729461d0341726c0999ff18f010a6d02b2`. This freezes the base; no mutated candidate exists yet to compare.
6. **Native capacity:** independently invoked pure in-memory `ri.build()` with bytecode writing disabled. Pass: **2,674 nonderived inputs;249,814,458 bytes;185,542 bytes headroom**; source digest `0875010ee5c63011ef5d58c8cfc6d015f57e7fefb27f721c33449c226b5567c1`. No output file was written. This exactly reproduces baseline proof; it is **not `verify`**, and does not bless stale derived outputs.
7. **Forecast:** independently reproduced final238,957,963 inputs /11,042,037 spare under the stated21-file/1.25 MB overhead envelope. No bytes have yet been saved. T01's150 KB and later allowances remain ceilings to prove against actual added artifacts/evidence; the final complete source must be scanned again. The near-full secrets ledger and its existing companion mechanism remain protected.

Current native checkout stayed clean during these checks at cbb7dfa; no source, test, original or external service was changed. No suite, browser, hosted selector, workflow, merge or release acceptance was executed. Native production/release labels are supplied dated source observations; this reviewer did not independently query the live hosting endpoint. Source-grounded v11 supersession and scoped consumer absence support treating these old captures as redundant historical candidates; issue closure alone was not used as eligibility proof.

## Intent/AC linkage and next gate

| Requirement / AC | T01 evidence can support | Still pending |
| --- | --- | --- |
| Stop/report before archival mutations | Clean fixed checkout; all originals retained; read-only recovery/build | Correct T01-R1 wording and honor actual authorization boundary. |
| AC01 short current entry | Consumer owners/test routes identified | Entire short-map/scoped behavior and usability/compatibility checks remain future. |
| AC02 full deterministic integrity | Real native baseline build and complete selected/archive identities | Final current-source generation/verify, coupling and implemented negative-oracle checks; no global pass. |
| AC03 eligible recoverable batch | Native/member matches, selected/open-PR identity rows, current/v11 consumer dispositions, frozen protection | Reconcile exceptions/selection; practical extraction/index/directory/gzip-gallery journeys and protected post-change comparison in T02. |
| AC04 useful capacity | Actual baseline and bounded arithmetic; all limits unchanged | Actual T01 artifact fit, actual savings/final candidate costs and accepted10 MB reserve. |
| AC05 reviewed exact-source delivery | Test-impact plan identifies archive, integrity, protected, recovery and route obligations | Other actual roles/corrections, complete candidate checks, policy/lane and later delivery decisions. |

After preserving this first result, recheck only the affected scope/authorization/exception/selection correction and refresh exact source/packet identities. The verified unchanged archive/member/native evidence can be reused for retained selected files after checking their identities; a changed selection needs its own revised accounting and protected set. Final checkpoint metadata and native build/verify remain explicit gates, not a reason to move originals before this iteration's stop/report.
