# Issue189 T01 — White-box QA first judgment

2026-11-10; reviewer `/root/issue189_whitebox_plan`. This is the continuing White-box role's first judgment of the T01 candidate, not a newly fresh-context launch. Only permitted sources and my own earlier review context were used; no current peer output, parent notes or unrelated memory was read. No delegation, external write, implementation or repository mutation was performed. Provider model/context internals remain unknown; actual role-launch receipts belong to the orchestrator.

## Verdict

The binary recovery, native-original identities, frozen protected-set digest and forecast arithmetic are independently reproducible. The candidate is useful as the required report before archival mutation. One P2 inconsistency in the frozen exception contract should be corrected before T02; it does not invalidate the read-only archive proof. Final checkpoint build/verify/capacity evidence remains pending, as the candidate states. No full issue AC, deletion authorization, merge or delivery acceptance follows from this review.

## Identity and inspected scope

- Native checkout: clean `cbb7dfa8b4f0ab4e3ca6448843edf84da3bd8b1a`, tree `c2c8f5bcd4d4a6e0814fd1cc95eb757d4bc2950f`.
- Candidate `issue189-t01/audit-candidate.md`: SHA256 `80bf9cc77c1e1adbba4379ed737ec57fdcbf90e3527acd78ece2a477b18a6191`.
- Packet `issue189-t01/review-packet.json`: SHA256 `46883d31d0a0907d8fe1194e87da09544731e9e0ea9caf8029791c3ae774641b`; all10 supplied entries matched actual size/SHA256.
- Selected-file contract: SHA256 `c464c7e45bc07169d83e2e53434059df983537bd9172d496dd7363f320c04bfc`.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; White-box prompt SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.

Read the native common/role prompts, README/AGENTS, relevant CONTRIBUTING and now-available SITE-CHECK-PROFILES allocation contract, MEMORY as handoff, live issue snapshot, candidate/selection/proof/capacity/consumer records; inspected native capture/bundle/preview routes, historical gallery locator and coupling input interpretation. Root AGENTS is the only discovered AGENTS. Native issue189 acceptance policy is not yet present; selected owning-policy allocation remains future work rather than a passing check.

## Finding T01-WQ01 — P2: prose and frozen machine exception sets disagree

Evidence: `audit-candidate.md:67` permits a conditional CI-map digest update. `selected-files.json:25–34` lists eight permitted existing metadata changes but omits `.github/ri-ci-map.json`. That file is part of the default protected2655 set. Native `tools/check_ri_ci.py` includes `.github/repository-paths.json` in coupling identity, and the planned archive operation changes that catalog. A coupling digest refresh is therefore a real dependency, not an unrelated hypothetical edit.

Failure mechanism: a T02 comparator following the frozen JSON rejects the prose-authorized digest update; a comparator following an inferred broader prose exception has a different oracle. This undermines the single exact protected-resource contract required by AC03/AC05.

Treatment before T02: reconcile the two descriptions explicitly. If retaining the conditional exception, identify `.github/ri-ci-map.json` in a conditional exception record and require the exact reviewed-source-identity refresh with unchanged mapping semantics. Preserve the other protected bytes and re-review substantive map interpretation changes. Do not bypass the protected-set check or exempt the entire map without the stated condition.

Nonblocking refinement: name the new recovery-index path and permitted new-file set when freezing the actual T02 delta. The existing protected digest covers existing paths; by itself it cannot reject an unrelated new file. Compare the complete resulting tree, not only the old protected entries.

## Independent executed checks

Bounded scripts used Python standard-library `hashlib`, `zipfile`, JSON and read-only Git commands. No full suite or RI build/verify was replayed. Successful scripts exited0 with complete output; no signals or timeouts occurred.

### Actual archive/member/native proof

For each of the3 ZIPs, read the actual audit-cache bytes and native checkout bytes; required equality, exact size/SHA256/Git blob identity and matching pinned Git object. Each archive has85 unique member names, no absolute/traversal/backslash paths and no symlink members. Selected member lookup required exactly one non-directory entry. Decoded every selected member in memory and compared it to the actual loose native original, declared length, SHA256, Git blob ID and pinned original Git object.

```text
v5 ZIP: 10,266,858 bytes; 85 unique members; 7 selected verified
v6 ZIP: 11,726,610 bytes; 85 unique members; 7 selected verified
v7 ZIP: 11,065,237 bytes; 85 unique members; 7 selected verified
decoded/native/original proofs: 21; total bytes: 12,106,495
```

This is actual read-only decoding and byte comparison, stronger than inventory-size matching. It does not execute the planned literal `unzip` commands or new locator journeys, and does not validate arbitrary unselected member payloads. No original was removed.

### Protected-set and capacity reconstruction

Regenerated the protected listing from `git ls-tree -rz HEAD`, excluding only the21 exact selected paths and formatting each retained record as `mode blob path` plus LF. It equals supplied `protected-base-index.txt` byte-for-byte:

```text
tracked files: 2676
protected paths: 2655
protected listing SHA256: f806e3e3e31a5a0720a20d988c099c729461d0341726c0999ff18f010a6d02b2
nonderived hash inputs: 2674
native file-size sum excluding exactly the2 RI outputs: 249814458
baseline headroom: 185542
forecast: 249814458 + 150000 + 100000 + 1000000 - 12106495 = 238957963
forecast headroom: 11042037
surplus above accepted reserve: 1042037
remaining baseline room after full T01 ceiling alone: 35542
native git status after checks: empty
```

The baseline size reconstruction is independent arithmetic over the clean tracked files, not a replacement for the candidate's actual scan/build or final verification. The forecast is sound conditional on overhead ceilings; no bytes have yet been saved. The35,542-byte remaining room is small enough that the final T01 artifact/evidence scan is a material prerequisite. Derived map/JSON size reduction supplies no hash-input recovery. The ledger's218-byte parsed-file margin remains independent of aggregate headroom.

### Consumer-boundary reproduction

Read and matched size/SHA256/Git blob IDs for all647 current manifest files, totaling16,424,426bytes. Within that boundary the only exact selected-path consumer is `.github/repository-paths.json`, with all21 paths. Broad old-family token search additionally finds the existing security baseline; it does not imply a selected-path dereference. Reading native tools confirms capture outputs bind v11; basename fixtures do not establish v5–v7 use.

For each declared PR overlay, independently byte-identified every nonexcluded supplied blob variant and repeated exact selected-path matching:

| PR | Actual byte-read paths | Exact selected-path references |
| --- | ---: | --- |
|79 |585 |0 |
|107 |455 |0 |
|110 |695 |0 |
|117 |432 |0 |
|171 |642 |0 |

There are1,059 unique read overlay blobs, including580 variants beyond the current native manifest. All byte IDs match. The five capture/bundle/preview/contrast tool variants in each overlay contain the v11 family bindings. This is source-bound search and inspected route evidence, not execution of every consumer branch. The supplied nine metadata-only path/blob pairs are explicitly outside the dereferencing-consumer read boundary.

The nonowning PR commit objects are not in this local checkout: a bounded `git cat-file -t` probe of PR79's head failed. I therefore verified supplied blob bytes and inventory associations, but did not independently regenerate each immutable PR tree/head association from native commit objects. The packet's association proof remains the evidence for that part; no live PR state was fetched during this review.

## Diagnostic failure accounting

One initial overlay-verification script incorrectly treated every listed pair as available byte-inspected text and stopped with `AssertionError` for metadata-only `tools/quality/secrets-publication.json` blob `28f628c44537bb4f46f29057caa279c2ecf7e5a9`; exit1. Before any follow-up, I inspected the explicit `metadata_only` list:9 unique pairs; per-PR exclusions4/4/3/4/3, giving the candidate's585/455/695/432/642 actual read counts. The corrected bounded diagnostic skipped precisely those declared pairs and verified all remaining bytes successfully. This was a reviewer boundary-selection error, not failed archive proof; the first result is retained here and no unchanged campaign was blindly retried.

A listing piped to `head` emitted a broken-pipe message after the requested filename samples; it was inventory display, not an acceptance check. The PR79 object probe failure above caused its chained follow-up source read to be skipped; the source read was then issued separately. No missing source was treated as evidence of absence.

## Risk → oracle → planned allocation

| Risk / AC | Scenario and independent oracle | Allocation / execution state |
| --- | --- | --- |
| Wrong/truncated/ambiguous archive / AC03 | Actual3 ZIP identities, selected21 unique exact members, native originals | Executed read-only above; revalidate source lease/bytes before deletion. Unchanged proof can be reused; literal extraction/locator journeys remain T02 manual ARCHIVE evidence |
| Active/unfinished consumer lost / AC03 | Exact paths, relevant basenames and producer directory bindings at frozen current/PR sources | Bounded byte/search/route checks executed; recheck changed overlays. Runtime/dynamically constructed consumer absence is not established by lexical search alone |
| Unselected source/history altered / AC03/05 | Full base path/mode/blob set; only exact selected deletions and explicit metadata/new-file dispositions | Digest regenerated here. Actual candidate tree comparison pending T02; resolve T01-WQ01 first. Retain manual protected-resource gate; do not add a redundant service |
| Metadata budget breaks next checkpoint / AC04 | Independent input/output/count accounting including all reports and evidence, existing bounds unchanged | Forecast reproduced; final actual T01/T02/full-candidate scans pending. Target remains10,000,000 final bytes spare |
| Catalog/check route omitted / AC02/05 | Exact catalog ownership, deterministic regenerated outputs, actual coupling source identity | Existing permanent RI/coupling/root-layout/style commands, `navigation.yml` job `navigation`; current checkpoint runs pending. Issue189 policy and complete-diff trusted selection still need actual source-bound evidence |
| Recovery guidance impractical / AC03 | New directory guidance/index, literal member commands and full relative-layout extraction into temporary location | Pending T02 manual journey. If a helper changes, allocate wrong/missing/duplicate/unsafe-member negative cases to its existing permanent suite or explicit new registry owner; unchanged helper does not require a duplicate suite |

The profile owner allows added cases inside already-discovered Python suites to use their existing route; new suites/inputs/lifecycles need registry reconciliation. No blanket browser/performance campaign is justified to establish old media byte identity. Actual locator usability and trusted selected delivery remain separate gates.

## Limits and stopping point

The current native checkout and actual archives remove the earlier planning snapshot's access gap. This review still does not accept final generated freshness, full T01 artifact capacity, archive eligibility beyond the selected batch, every dynamic consumer, new locator usability, hosted checks or delivery. No measured branch-coverage claim is made. Candidate/source identity must be refreshed after any relevant change. Preserve this first judgment before reconciliation; report the T01 result before archival mutations.
