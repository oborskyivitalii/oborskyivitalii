# Issue189 T01 — first Exploratory / Interaction QA result

Date: 2026-11-10. Reviewer/task: `/root/issue189_exploratory_plan`.
This is a continuation on the existing role handle, not a newly fresh context.
Earlier planning results remain preserved. No current peer verdicts, parent notes
or private conversation history were read. Provider internals remain unknown;
the orchestrator owns actual launch/acceptance receipts.

## Verdict

The frozen21-media selection has independently observed practical recovery:
all21 member CLI extractions and all3 complete-ZIP restores matched the native
originals. Complete restored relative HTML/media layouts resolved locally.
No blocker to reporting this read-only preflight was found. Two P2 handoff/design
clarifications below should be resolved before an archival mutation iteration:
make full-bundle guidance mandatory on the existing gallery entrypoints, and
describe T02 as the next planned phase without overriding the T01 stop/report.

This report does not authorize deletion, accept new locators, establish capacity
recovery, or pass whole issue ACs. No original or checkout file was changed.

## Inputs and inspected source

| Input | Observed identity |
| --- | --- |
| Native checkout HEAD | `cbb7dfa8b4f0ab4e3ca6448843edf84da3bd8b1a`; initial `git status --porcelain=v1` empty |
| Candidate `issue189-t01/audit-candidate.md` SHA256 | `80bf9cc77c1e1adbba4379ed737ec57fdcbf90e3527acd78ece2a477b18a6191` |
| Packet `issue189-t01/review-packet.json` SHA256 | `46883d31d0a0907d8fe1194e87da09544731e9e0ea9caf8029791c3ae774641b` |
| Common reviewer contract SHA256 | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| Exploratory role prompt SHA256 | `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a` |

All10 packet-listed files independently matched their declared size/SHA256.
Read native README/root AGENTS, common/role prompts, CONTRIBUTING, relevant
SITE-CHECK-PROFILES allocation, existing gallery locators, canonical issue189
analysis/ACs, selected-files.json and actual archive bytes. `rg --files -g AGENTS.md`
found only root AGENTS. Inspected the supplied current/open-PR consumer manifests,
reference reports and member/native proof records, plus current capture tool roots.

Independently rechecked all647 current-manifest paths against native length,
SHA256 and Git-blob formula: zero mismatches,16,424,426bytes. Exact selected-path
matches within this boundary occurred only in `.github/repository-paths.json`
(21 target paths). Current capture/contact-sheet/recording tools bind v11.
This byte/reference scan does not claim complete semantic analysis of arbitrary
dynamic code. Open-PR claims were inspected through the supplied pinned inventories
and reference reports; this reviewer did not fetch or execute the five branch trees.
Live production/release state was not independently revalidated.

## Charter and execution bounds

Chosen independently for this iteration: follow a selected PNG/WebM from frozen
index to practical extraction; restore complete galleries with relative assets;
check recovery after a missing member; and walk the proposed directory/index
handoff without inventing new UI. Bound:21 member CLI recoveries,3 complete-ZIP
restores, plus1 missing-member diagnostic;10seconds per member subprocess and
20seconds per full restore. All completed within the limits. All output files
were temporary outside the checkout and were removed at cleanup.

Before complete extraction, checked all85 member names per ZIP for duplicates,
absolute/traversing paths and symlink metadata: none found. Actual ZIP bytes
matched the frozen size/SHA256/Git blob and native checkout ZIP bytes. This is
bounded examination of these3 inputs, not a reusable arbitrary-archive safety proof.

Actual existing-tool journeys used subprocess arguments equivalent to:

```sh
unzip -p '<absolute-archive>' '<exact-member>' > '<temporary-output>'
unzip -q '<absolute-archive>' -d '<fresh-temporary-directory>'
```

For each selected file, compared extracted bytes with (a) working-tree original,
(b) `git show cbb7dfa:<path>`, (c) the full-ZIP-restored member, and (d) frozen
length/SHA256/Git blob identity. Every comparison passed.

## Expected versus observed evidence

| Case | Expected | Observed |
| --- | --- | --- |
| E01 packet identity | Every declared byte identity matches |10/10 size/SHA256 checks passed |
| E02 v5 restore |7 members recover exactly; full layout resolves |7/7,3,863,421bytes; ZIP10,266,858bytes;85 members;22 HTML files;303 local `href`/`src` occurrences checked;0 missing targets |
| E02 v6 restore |7 members recover exactly; full layout resolves |7/7,3,747,039bytes; ZIP11,726,610bytes;85 members;22 HTML files;303 local occurrences;0 missing targets |
| E02 v7 restore |7 members recover exactly; full layout resolves |7/7,4,496,035bytes; ZIP11,065,237bytes;85 members;22 HTML files;303 local occurrences;0 missing targets |
| E03 total recovery |21 selected originals,12,106,495bytes |Exactly21 member CLI commands plus3 full-ZIP commands; all matches; temporary outputs cleaned |
| E04 source-reference boundary | Manifest is source-bound; selected current exact references explained |647/647 native identities; exact selected references only catalog; no changed checkout files observed |
| E05 missing member | Nonzero extraction; no valid recovered artifact |`unzip -p ... review/missing-member-not-in-archive.webm`: exit11; stderr `caution: filename not matched:  review/missing-member-not-in-archive.webm`; shell-equivalent redirection leaves an existing0-byte file. Expected negative, not rerun. File existence cannot establish recovery. |

For all3 families, decompressed native `*-index.html.gz` exactly equals the
restored original gallery HTML. Each original gallery has56 local `href`/`src`
occurrences, all resolving in its restored bundle. These include respectively
5/3/5 selected recordings: all13 selected WebM files are referenced by galleries.
The selected contact sheets/screenshots are independently recovered even where
the gallery does not directly link their exact paths.

File resolution checks used HTML parsing of `href`/`src`, decoded relative paths
and filesystem existence. They did not render pages, play recordings, evaluate JS,
prove accessibility or validate every possible CSS/runtime fetch. Browser/device
acceptance is not claimed.

## Findings and planned journey dispositions

### P2 — make full-ZIP recovery discoverable from the existing gallery locators

**Location/evidence:** candidate lines67–69 treats changes to the3 existing
gallery locators conditionally (“if links to recovery guidance are added”).
Actual `review/site-v1-20261002-v{5,6,7}-index.html` locators link only the gzip
original and instruct readers to decompress it. The original galleries reference
all13 selected recordings, demonstrated by the E02 restorations.

**Mechanism/impact:** after T02 removes those loose recordings, the existing
gallery entrypoint's gzip-only advice does not restore their relative media
layout or tell its reader how to obtain it. New capture-directory ARCHIVE.md files
can explain recovery, but an operator entering through the existing locator must
be able to discover that guidance. AC03's practical usable recovery journey
requires more than a correct archive/member mapping hidden elsewhere.

**Treatment:** require each existing gallery locator to link the appropriate
directory recovery guidance or owning recovery index and clearly offer complete-ZIP
recovery for relative assets. Keep gzip and original archive bytes unchanged.
T02 should verify entrypoint → guidance → full extraction → restored gallery/media,
and preserve individual-member extraction as a separate exact-byte route. This is
a proposed correction to the T02 navigation contract, not a change authored here.

### P2 — preserve the explicit T01 stop/report boundary in the final handoff

**Location/evidence:** candidate opening records iteration1 then report before
moving/removing originals; its last line118 calls T02 the “Next authorized
continuation after this report.” The supplied task scope explicitly stops at this
T01 checkpoint before mutation.

**Mechanism/impact:** another operator can read “authorized” as permission to
start the deletion phase without the required stop/report. A report should not
expand the actual supplied authorization. Affects AC05/operator handoff boundary.

**Treatment:** label T02 the next planned phase, retain the explicit stop after
T01, and bind any later continuation to the actual applicable user instruction.
This does not add a routine approval workflow or supersede broader authorization
if the orchestrator can evidence it; this reviewer received only the T01 scope.

### Designed versus observed locator journeys

The3 capture-folder ARCHIVE.md files and new owning recovery index do not exist
in the frozen candidate. Their link labels, relative paths, discoverability,
individual extraction instructions/checksums and final browser presentation are
therefore **designed, not observed**. Frozen selected-files.json already supplies
each exact original/archive/member/size/hash identity, sufficient to execute the
actual recovery checks above. The proposed directory-level approach avoids fake
media bytes and21 duplicate prose locators; no need for per-media placeholder files
was demonstrated.

Recovery guidance must require successful command status and expected size/hash;
E05 demonstrates why accepting an output path merely because it exists is invalid.
No new extraction helper or test implementation was introduced in this iteration.

## Allocation and remaining gates

Through `guides/SITE-CHECK-PROFILES.md#qa-findings-to-github-actions`:

| AC / risk | Independent oracle and disposition | Existing route / owner |
| --- | --- | --- |
| AC03 exact selected recovery | Reuse unchanged native Git bytes and frozen archive/member identities;21 actual member and3 complete restores observed here | Owning issue189 dated review/recovery evidence; no new permanent suite required for unchanged ZIPs |
| AC03 useful gallery recovery | Entrypoint/guidance links resolve; full restore supplies referenced assets; command failure cannot be treated as valid output | Manual bounded T02 operator/locator walkthrough in owning artifact; browser inspection if locator UI changes; **deferred until implemented** |
| AC03 protected closure | Complete base→T02 path/mode/blob comparison with explicit allowed metadata exceptions | Owning archival candidate evidence; **pending actual mutation candidate** |
| AC04 realized headroom | Complete native candidate accounting including report/index/locators and retained originals | Existing RI build/verify + owning measured report; forecast only here, **not independently rerun or accepted** |
| AC05 source admission | Full actual diff, affected native checks and trusted lane selection | Existing navigation RI/coupling/root-layout/style routes and owning policy; **final checkpoint checks pending** |

No blanket historical snapshot run, hosted capture/performance campaign or new
pipeline is justified merely by these archive metadata observations. Existing
runtime checks keep their native owners and selection routes. Required independent
roles, final checkpoint capacity/generation checks and any subsequent correction
review remain separate evidence. Whole issue AC01–AC05 remain open.
