# Issue189 T01 — Code / artifact review

Reviewer `/root/issue189_code_plan`, 2026-11-10. Same-handle role continuation from the planning review, not a newly fresh none-fork execution. No current peer verdicts or parent scratch notes consumed. Provider/context-isolation internals remain unknown. First report for this T01 candidate; earlier planning reports are preserved.

## Verdict

The read-only preflight's archive/member/original identities, scoped consumer findings, protection digest and capacity arithmetic are supported by independent checks. No binary recovery, consumer-binding or arithmetic blocker found. **Clarify the authorization sentence before treating this report as permission to move/remove originals.** Also reconcile the small protection-contract discrepancy below before freezing T02's comparison oracle. This review supplies no authorization, implementation acceptance, Ready/merge approval or full-AC pass.

## Findings

### T01-C01 — T02 is called authorized beyond the supplied iteration1 scope

Severity: medium, advancement/authority wording; affects AC03/AC05.

Location: `audit-candidate.md`, Completion boundary, final sentence: “Next authorized continuation after this report is T02 ... applying the bounded archive delta”. The supplied current instruction authorizes iteration1 and a report before moving/removing originals. The scope paragraph correctly keeps this iteration read-only. Calling archival mutation already authorized can cause the next agent to treat delivery of the report as sufficient approval of deletion.

Treatment: describe T02 as the next proposed step, state the actual authorization boundary, and cite an existing explicit instruction if it already authorizes archival mutation after reporting. Otherwise retain the report/stop boundary until the relevant next instruction. No new permission is supplied by source checks or this review.

### T01-C02 — Prose and frozen JSON disagree on the CI-map exception

Severity: low, protection-oracle clarification; affects AC03/AC05.

Location: `audit-candidate.md:67` permits a CI-map digest-only update if coupling requires it. `selected-files.json:protected_contract.permitted_T02_existing_metadata_changes` omits `.github/ri-ci-map.json` and otherwise defaults all existing unselected paths to protection. A T02 comparison following the JSON literally would reject an edit the prose conditionally permits; following the prose alone could silently broaden a frozen allowlist.

Treatment: make the two representations agree. Either keep that path protected unless a later reviewed delta adds a narrowly described digest-only exception, or enumerate the conditional exception and assert unchanged map meaning. Do not broaden it to arbitrary CI-map edits. This is not evidence that an update will actually be necessary.

## Identity and actual inspection

Native checkout `/workspace/scratch/2c34f552b848/issue189-checkout`: independently observed clean `git status --short`, HEAD `cbb7dfa8b4f0ab4e3ca6448843edf84da3bd8b1a`, tree `c2c8f5bcd4d4a6e0814fd1cc95eb757d4bc2950f`. Only root `AGENTS.md` is tracked. Root README/AGENTS, relevant CONTRIBUTING archive/review rules, MEMORY, common/Code reviewer prompts and owning issue/source materials were read; unchanged planning source evidence was reused where applicable.

Candidate `/workspace/scratch/2c34f552b848/issue189-t01/audit-candidate.md`: SHA256 `80bf9cc77c1e1adbba4379ed737ec57fdcbf90e3527acd78ece2a477b18a6191`. Review packet SHA256 `46883d31d0a0907d8fe1194e87da09544731e9e0ea9caf8029791c3ae774641b`. All ten listed packet files matched recorded size/SHA256. Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code prompt SHA256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.

Read selected-files/proofs, current and PR consumer manifests, relevant original issue1 supersession evidence and current capture tools/locator. Independently verified all 647 current-source files against recorded size/SHA256/Git blob and native checkout bytes: 16,424,426 bytes, no mismatch. Rechecked all admitted PR source blobs by content-addressed identity, treating declared lock/security-disposition metadata as excluded rather than failed source reads. Admitted counts reproduce 585/455/695/432/642 for PR79/107/110/117/171; 580 additional cached blob variants. Independent exact-target scans found only the current catalog and no admitted PR source references. Actual current capture tools bind v11; their PR variants contain v11 and no selected v5/v6/v7 family binding. The admitted boundary is scoped source inspection, not a proof against arbitrary dynamic path construction or unseen subsequent branch changes.

## Independent checks and results

- All three cached ZIPs equal actual native repository ZIP bytes and match recorded size/SHA256/Git blob. Each has 85 unique members; no absolute/traversal/backslash member path observed.
- All 21 selected members were decoded in memory and compared directly to native loose originals. Every size/SHA256/Git blob and exact byte comparison matched; 12,106,495 bytes total. No original was altered or extracted into the repository.
- Regenerated the full protected listing from native Git mode/blob/path rows, excluding exactly the 21 originals: 2,655 rows, byte-identical to the supplied index; SHA256 `f806e3e3e31a5a0720a20d988c099c729461d0341726c0999ff18f010a6d02b2`.
- Recomputed selection from current-size-matching #184 candidates: descending size then path reaches 12MB at the same 21 files; preceding 20 total 11,749,313 bytes. This establishes the documented selection algorithm, not a claim of globally minimal deletion count for every possible headroom envelope.
- Executed the native producer's pure `build()` in memory without generating outputs. It succeeded: 2,676 records, 2,674 nonderived inputs, 249,814,458 hash bytes, digest `0875010ee5c63011ef5d58c8cfc6d015f57e7fefb27f721c33449c226b5567c1`; parsed-suffix bytes 21,707,487. This reproduces the baseline and leaves 185,542 hash bytes spare.
- Independently recomputed the bounded forecast: 249,814,458 + 150,000 + 100,000 + 1,000,000 − 12,106,495 = 238,957,963 input bytes / 11,042,037 spare. Its overhead ceilings remain assumptions to measure, not observed savings.

Existing historical capture/offline manifests and gzip originals stay protected; full-ZIP recovery preserves relative media layout. Directory guidance plus one owning index avoids fake media content. Actual locator edits, literal practical extraction journeys, full T02 protected comparison and complete-candidate accounting remain future checks. The preflight appropriately does not claim unchanged loose-media URLs.

## Limits and gate accounting

No repository mutations, external writes, implementation, test authoring or delegation performed. No unit suite, output-generating CLI build, RI verify, new locator/browser journey or hosted campaign run. Baseline in-memory build is not stale-output freshness acceptance. Final checkpoint artifacts/catalog/RI regeneration and final native checks are absent from this candidate and must fit the remaining 185,542-byte starting margin before publication. All full issue ACs remain pending.

This is a same-handle continuation. Under the common contract's fresh-review-of-changed-candidate rule it must not be recorded as a newly fresh execution; the orchestrator retains responsibility for any fresh-launch acceptance gate. No inference about accepted launch/provider internals is made here.
