# Issue189 T01 — Requirements correction result

2026-11-10; `/root/issue189_requirements`, same-handle correction delta. This continuation has received reconciled review facts; it is not a fresh independent first judgment. The first T01 report remains unchanged, SHA256 `bc3fa87db1bfdaf7c1339c2e83129e83161ade2066bd856153aae829c57d7deb`. Provider-internal context/history behavior remains unknown.

Corrected identities independently verified:

- `audit-candidate.md`: SHA256 `f658dc1839ac92e28af4c0c23a81367fd2b7ab14503bd8aa2c4793f950edf326`.
- `selected-files.json`: SHA256 `cee9263e5928946e6acd595ac3a0853ed2aad324837766fd89443d70de96e8bb`.
- Native checkout remains clean at `cbb7dfa8b4f0ab4e3ca6448843edf84da3bd8b1a`.

**Outcome: all three of my T01 findings are resolved in this correction. No blocking Requirements finding remains for the bounded T01 preflight report.** This does not authorize deletion, complete issue ACs or accept later implementation/delivery.

| First finding | Correction and actual affected check |
| --- | --- |
| T01-R1 — T02 authorization wording | Completion now calls T02 the proposed next step, conditional on maintainer continuation after the current agreed stop/report. It explicitly states that this report does not authorize deletion. The original stop boundary is preserved. |
| T01-R2 — inconsistent protected exception | JSON now lists `.github/ri-ci-map.json` and limits it to `reviewed_source_identity` refresh after actual diagnosis/check review, with definition/threshold/selection unchanged. This agrees with prose. Read the preserved first-failure diagnosis: stale mapping, catalog as the sole differing recorded input, definition validation successful; no subsequent pass is inferred. |
| T01-R3 — larger unexplained selection | Corrected19 paths are exactly the largest19-prefix of the previously verified21, with unchanged per-file identity records. Independently summed18 =10,992,915, below required11,064,458;19 =11,386,774, above it. The candidate correctly limits its minimum-count claim to these21 eligible verified candidates. The two v6 screenshots remain present, byte/SHA256-exact and excluded from removal. |

Reconstructed the affected protected listing directly from native Git: **2,657** nonselected paths, exact digest `e414fe8db7ddf7492b511f52cfaa89f6ac640a3a5f0f181095d106e71b8d6385`, matching the corrected contract. Its default protection now includes both retained screenshots. Independent forecast arithmetic reproduces **239,677,684 final input bytes /10,322,316 bytes spare**, leaving **322,316 bytes** beyond the accepted10 MB target only if all overhead ceilings hold. This remains a forecast; actual checkpoint/final input measurements are required.

The new mandatory guidance rule covers all three current gallery locators, retains original gzip links/bytes, and points to full unchanged ZIP recovery plus directory guidance for relative media. It is compatible with lossless member recovery and prevents claiming that a downloaded standalone gallery necessarily restores its media. The locators and their operator journeys are future T02 work. I did not use another role's reported link-count/recovery result as my own executed observation.

Unchanged three-archive/member evidence and source-consumer findings are reused from my first result because19 is a strict unchanged subset and no repository mutation occurred. The late native PR-tree check performed after preserving that first report independently confirmed all21 original path/mode/blob/size records on each of five fetched heads; it therefore also covers retained19. No suite or unchanged failed campaign was replayed, and no implementation was written or accepted.

Remaining gates are intentional: finish actual T01 artifact/capacity/current-source RI/coupling checks before declaring the published checkpoint verified; stop/report with originals intact; revalidate source/original/archive identities upon any subsequently authorized T02; execute actual locator/extraction journeys and protected-tree comparison after that change. Current stale-output/coupling evidence stays distinct from a later verified pass. Whole issue AC01–AC05, merge and release remain pending.
