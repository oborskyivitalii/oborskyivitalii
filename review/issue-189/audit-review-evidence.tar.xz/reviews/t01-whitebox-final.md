# Issue189 T01 — White-box correction review

2026-11-10; `/root/issue189_whitebox_plan`, same-handle continuation. First T01 judgment remains preserved in `t01-whitebox-first.md` (SHA256 `30f236712d8efb3320ad827b8c7e9e69065c3900047868a84302c4399a023570`). This is not a fresh-context execution. The corrected candidate includes summaries of other roles' later findings; this exposure is after my first judgment. Those summaries were not used as independent proof or inspected through peer output files. Provider internals remain unknown.

Reviewed correction identities:

- `audit-candidate.md`: SHA256 `f658dc1839ac92e28af4c0c23a81367fd2b7ab14503bd8aa2c4793f950edf326`.
- `selected-files.json`: SHA256 `cee9263e5928946e6acd595ac3a0853ed2aad324837766fd89443d70de96e8bb`.
- Original candidate/selection/packet are preserved in `first-candidate/`. The original `review-packet.json` still references first-candidate hashes; it is not a valid manifest of the revised bytes. The explicit correction task supplied the two revised hashes above, which matched inspected bytes.

## Verdict

T01-WQ01 is resolved: the JSON now explicitly allows `.github/ri-ci-map.json` only for `reviewed_source_identity` refresh after diagnosis/check review, preserving definition/threshold/selection semantics. This agrees with the prose. No unresolved White-box blocker remains for the read-only T01 report. Actual final checkpoint checks, full protected-tree comparison and subsequent authorization remain gates; this does not accept deletion, global ACs or delivery.

## Actual bounded rechecks

No suite, recovery campaign or failing coupling command was replayed. Read the full revised candidate and selection delta; independently checked these changed obligations with standard-library scripts and read-only Git:

| Obligation | Independent result |
| --- | --- |
| Revised membership | All19 entries are an unchanged-byte subset of the original21 native proofs; reread native original length/SHA256. Both v6 `index-day-desktop.png` and `index-night-desktop.png` are retained |
| First sufficient descending-size prefix | Required gross recovery11,064,458; first18 yield10,992,915, short71,543; first19 yield11,386,774. The selected set equals those first19 |
| Forecast | 249,814,458 +150,000 +100,000 +1,000,000 −11,386,774 =239,677,684 inputs; headroom10,322,316, only322,316 beyond the accepted minimum |
| Expanded protected closure | Regenerated2657 retained path/mode/blob records; digest `e414fe8db7ddf7492b511f52cfaa89f6ac640a3a5f0f181095d106e71b8d6385`; exact equality to revised protected index |
| Coupling diagnosis | Read preserved failure record; independently computed recorded/current identities `e8f06fcd35ec5f575ca7c61c5e79f8923d6c58ce01e6a4aceda8c2f6b72a029d` / `726bc83628d3bde94e33363fa74ce0a1d3bd5be9c226dedf7e5ab25791291e5a`; only differing input record is `.github/repository-paths.json` |
| Catalog meaning | Native production→cbb delta adds exactly3 issue189 history entries, with CONTRIBUTING ownership; no existing active control/route/threshold is changed |
| Repository | Native checkout remains clean at cbb7dfa |

The successful scripts exited0 with complete accounting. `diff -u` returns the expected1 for changed source; its `&&`-chained second diff did not run, but the complete revised candidate was read separately. No new test failure or source mutation occurred.

The19-file choice is minimum count within the21 individually verified candidates under the stated allowance, not a global optimum. Smaller reserve surplus makes actual complete-candidate accounting more significant, without invalidating the arithmetic. The original21 archive comparisons and current/PR source-bound consumer results remain usable for this strict unchanged subset; no reason exists to decode those same members again solely for volume.

## Changed allocation and remaining gates

All3 gallery locators now have a mandatory contract: retain original gzip links, expose unchanged full-ZIP recovery, explain relative media restoration and route to directory guidance. That gives T02 a testable manual recovery/usability oracle. Actual new guidance, literal extraction commands and resulting link/layout journeys remain unimplemented and unexecuted here; other-role recovery summaries are not my execution evidence.

The planned digest-only correction follows observed failure diagnosis: finish metadata, refresh reviewed identity, then verify and execute affected RI/coupling checks on that exact candidate. The preserved baseline coupling failure is not converted into a pass by this review. New-file scope still needs the exact T02 delta, with full-tree comparison rather than only checking old protected records. Existing permanent RI/coupling/root-layout/style routes and explicit recovery/protected-resource/manual gates remain appropriate; no new suite is needed merely for this subset reduction.

T01 still stops and reports before any archival mutation. T02 requires maintainer continuation after that stop, source-lease revalidation, exact selected/protected comparison and final actual capacity/output checks. No repository mutation, external write, suite replay, implementation or delivery acceptance was performed.
