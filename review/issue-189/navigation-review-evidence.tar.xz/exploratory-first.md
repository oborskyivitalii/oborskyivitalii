# Exploratory / Interaction QA — first judgment

Role/task: /root/issue189_t03_exploratory, distinct nonauthor. Source is a native staged candidate, not a clean committed checkout. Base e4e09f45d014b985568af497e5958cc7eb8e3fab; staged tree 957b21fde35f701a1d3b64af55daec5b8aa27568. No implementation/test/external writes or delegation. Review bounded to eight minutes and listed journeys. Provider internals/context isolation cannot be independently attested; no parent/private/current-peer materials were consulted.

## Charter and applicability

Walk compact-map owner discovery before CLI/full-catalog inspection; then actual CLI EN/UA alias, exact-file, directory-only context, history/generated partitions, continuation/refusal/miss, whole response bytes and capacity diagnostics. Website/browser behavior is reasoned not applicable: staged diff changes repository navigation/producer/tests/protocol only, with no site/docs runtime or media changes. Browser launch is not a required proxy for CLI interaction. Full suite/Basic and final delivery belong to orchestrator; not claimed here.

## Connector-only observation before local CLI

Read the prepared 14,272-byte short map without full JSON/catalog. Its concern table directly routed requirements quality → CONTRIBUTING.md and detailed reviewer owner; source/engine → site/README.md. GitHub connector fetch of candidate tree ref 957b21fde35f701a1d3b64af55daec5b8aa27568/REPOSITORY-MAP.md returned actual 404: `No commit found for the ref 957b21fde35f701a1d3b64af55daec5b8aa27568`. Candidate is staged/unpublished, so candidate connector retrieval is not observed and cannot be accepted as a deployed connector journey. Actual direct-owner connector reads at immutable base e4e09f45... succeeded: site/README.md and agents/reviewers/requirements-acceptance.md. The latter routes requirements review to CONTRIBUTING and the common launch contract; the former identifies site sources and generated docs. No full JSON/catalog or local CLI was used for this portion. Local map inspection and base connector owner reads are separate observations; no connector freshness/local verification claim.

## Identities

Packet SHA256 285e6c04f15ddd2c6bb4bd23aca5e60abd760c5e1d22771fe4b437b222d99667. Owner SHA256 657c77791316fc5e998c31120a9c8e78fa17821a01529661f4082ef6a21a30c5. Common prompt SHA256 2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb; role prompt SHA256 280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a.

All packet candidate/reference byte hashes compared: True. Mismatches: [].

## Actual CLI receipts

### full native verification

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify`

Exit 0; 1.055s. Complete stdout / stderr:

```text
Repository Intelligence context is fresh.

STDERR:
```

### EN owner

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task requirements quality --scope current --limit 1`

Exit 0; 1.072s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "requirements quality",
  "status": "candidates-read-sources",
  "owner_candidates": [
    {
      "concern": "independent requirements and acceptance-quality review",
      "path": "CONTRIBUTING.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання"
      ]
    },
    {
      "concern": "independent requirements and acceptance-quality review detailed prompt",
      "path": "agents/reviewers/requirements-acceptance.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання",
        "requirements prompt"
      ]
    }
  ],
  "terms": [],
  "sources": [],
  "artifacts": [
    {
      "path": "CONTRIBUTING.md",
      "kind": "file",
      "purpose": "Canonical issue-to-PR protocol, four independently executed quality-agent roles, requirements quality, test-design handoff, source evidence and closure.",
      "role": "guide",
      "owner": "CONTRIBUTING.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "Contributing"
    }
  ],
  "directories": [],
  "editing_owners": [
    "CONTRIBUTING.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "repository intelligence and continuity",
      "paths": [
        "AGENTS.md",
        "MEMORY.md",
        "CONTRIBUTING.md",
        "README.md",
        "guides/REPOSITORIES.md",
        "REPOSITORY-MAP.md",
        ".github/repository-",
        ".github/REPOSITORY-INTELLIGENCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "tools/repository_intelligence.py",
        "tests/test_repository_intelligence.py",
        ".github/ri-ci-map.json",
        "tools/check_ri_ci.py",
        "tests/test_ri_ci.py",
        "PROJECT-BOOTSTRAP.md",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_ri_ci.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json build",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify"
      ],
      "workflow": ".github/workflows/navigation.yml"
    },
    {
      "concern": "independent quality-agent protocol and risk-to-test handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        "tools/quality/source-tests.cjs",
        "tests/test_repository_intelligence.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/check_ri_ci.py verify"
      ],
      "read": [
        "CONTRIBUTING.md",
        "agents/reviewers/README.md",
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        ".github/workflows/issue-acceptance.yml"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Follow CONTRIBUTING.md#independent-quality-agents for separately launched Requirements/Acceptance Reviewer, Code Reviewer, White-box QA and Exploratory/Interaction QA. These commands verify navigation and CI coupling, not agent execution or acceptance. Map findings and test dispositions to the live owning issue, existing profile registry and its acceptance policy; retain actual role results and manual limits in the review artifact."
    },
    {
      "concern": "issue acceptance and anchored analysis/review handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/acceptance/",
        ".github/workflows/issue-acceptance.yml",
        "tools/issue_acceptance.py",
        "tests/test_issue_acceptance.py",
        "tests/test_issue31_acceptance.py",
        "review/REVIEW-TEMPLATE.md",
        "review/issue-",
        "PROJECT-BOOTSTRAP.md",
        "tests/test_issue33_acceptance.py",
        "tests/test_issue35_acceptance.py",
        "tests/test_issue36_acceptance.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/issue_acceptance.py --help"
      ],
      "read": [
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Help only describes invocation; it is not an acceptance check. Revalidate the live owning issue and select its policy from the PR's single Refs line or explicit dispatch issue, following ACCEPTANCE.md for exact-source execution. Historical policies do not select current work. Automated assertions cannot supply independent role execution/review, observed hosted timing, owner/device acceptance, merge or live GitHub linkage."
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "detailed reviewer prompt requirements-acceptance",
      "paths": [
        "agents/reviewers/requirements-acceptance.md"
      ],
      "read": [
        "agents/reviewers/README.md",
        "agents/reviewers/requirements-acceptance.md",
        "CONTRIBUTING.md"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read the common contract and this single role prompt for a role launch; navigation checks do not establish reviewer execution."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 2,
    "returned": 1,
    "remaining": 1,
    "request_fingerprint": "45e09842e8380c617e37b5ec3d1be33351bf4569f8ab4c6926fc9b753a6e04df",
    "next_cursor": "1:45e09842e8380c617e37b5ec3d1be33351bf4569f8ab4c6926fc9b753a6e04df"
  },
  "response_bytes": 7790,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### UA owner

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task якість вимог --scope current --limit 1`

Exit 0; 1.074s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "якість вимог",
  "status": "candidates-read-sources",
  "owner_candidates": [
    {
      "concern": "independent requirements and acceptance-quality review",
      "path": "CONTRIBUTING.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання"
      ]
    },
    {
      "concern": "independent requirements and acceptance-quality review detailed prompt",
      "path": "agents/reviewers/requirements-acceptance.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання",
        "requirements prompt"
      ]
    }
  ],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [],
  "editing_owners": [],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "repository intelligence and continuity",
      "paths": [
        "AGENTS.md",
        "MEMORY.md",
        "CONTRIBUTING.md",
        "README.md",
        "guides/REPOSITORIES.md",
        "REPOSITORY-MAP.md",
        ".github/repository-",
        ".github/REPOSITORY-INTELLIGENCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "tools/repository_intelligence.py",
        "tests/test_repository_intelligence.py",
        ".github/ri-ci-map.json",
        "tools/check_ri_ci.py",
        "tests/test_ri_ci.py",
        "PROJECT-BOOTSTRAP.md",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_ri_ci.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json build",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify"
      ],
      "workflow": ".github/workflows/navigation.yml"
    },
    {
      "concern": "independent quality-agent protocol and risk-to-test handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        "tools/quality/source-tests.cjs",
        "tests/test_repository_intelligence.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/check_ri_ci.py verify"
      ],
      "read": [
        "CONTRIBUTING.md",
        "agents/reviewers/README.md",
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        ".github/workflows/issue-acceptance.yml"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Follow CONTRIBUTING.md#independent-quality-agents for separately launched Requirements/Acceptance Reviewer, Code Reviewer, White-box QA and Exploratory/Interaction QA. These commands verify navigation and CI coupling, not agent execution or acceptance. Map findings and test dispositions to the live owning issue, existing profile registry and its acceptance policy; retain actual role results and manual limits in the review artifact."
    },
    {
      "concern": "issue acceptance and anchored analysis/review handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/acceptance/",
        ".github/workflows/issue-acceptance.yml",
        "tools/issue_acceptance.py",
        "tests/test_issue_acceptance.py",
        "tests/test_issue31_acceptance.py",
        "review/REVIEW-TEMPLATE.md",
        "review/issue-",
        "PROJECT-BOOTSTRAP.md",
        "tests/test_issue33_acceptance.py",
        "tests/test_issue35_acceptance.py",
        "tests/test_issue36_acceptance.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/issue_acceptance.py --help"
      ],
      "read": [
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Help only describes invocation; it is not an acceptance check. Revalidate the live owning issue and select its policy from the PR's single Refs line or explicit dispatch issue, following ACCEPTANCE.md for exact-source execution. Historical policies do not select current work. Automated assertions cannot supply independent role execution/review, observed hosted timing, owner/device acceptance, merge or live GitHub linkage."
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "detailed reviewer prompt requirements-acceptance",
      "paths": [
        "agents/reviewers/requirements-acceptance.md"
      ],
      "read": [
        "agents/reviewers/README.md",
        "agents/reviewers/requirements-acceptance.md",
        "CONTRIBUTING.md"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read the common contract and this single role prompt for a role launch; navigation checks do not establish reviewer execution."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 0,
    "returned": 0,
    "remaining": 0,
    "request_fingerprint": "d98897532878b015bd5ecfaddfb3b856992271c4a6515a2b0c5e2d34fbd0ae87",
    "next_cursor": null
  },
  "response_bytes": 7321,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### exact file

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope current --prefix tools/repository_intelligence.py`

Exit 0; 1.006s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "files": [
    {
      "path": "tools/repository_intelligence.py",
      "kind": "file",
      "purpose": "Bounded deterministic site RI producer, catalog validation, scoped lookup and generated-view verification.",
      "role": "source",
      "owner": ".github/REPOSITORY-INTELLIGENCE.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "repository_intelligence.py"
    }
  ],
  "directories": [],
  "editing_owners": [
    ".github/REPOSITORY-INTELLIGENCE.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "repository intelligence and continuity",
      "paths": [
        "AGENTS.md",
        "MEMORY.md",
        "CONTRIBUTING.md",
        "README.md",
        "guides/REPOSITORIES.md",
        "REPOSITORY-MAP.md",
        ".github/repository-",
        ".github/REPOSITORY-INTELLIGENCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "tools/repository_intelligence.py",
        "tests/test_repository_intelligence.py",
        ".github/ri-ci-map.json",
        "tools/check_ri_ci.py",
        "tests/test_ri_ci.py",
        "PROJECT-BOOTSTRAP.md",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_ri_ci.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json build",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify"
      ],
      "workflow": ".github/workflows/navigation.yml"
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": "tools/repository_intelligence.py",
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 20,
    "offset": 0,
    "total": 1,
    "returned": 1,
    "remaining": 0,
    "request_fingerprint": "6314a78775c9bbfc9d7018ded5e662ae468c972eb11a523c47190b796853ea86",
    "next_cursor": null
  },
  "response_bytes": 3273,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### directory only

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task site/engine --scope current --limit 1`

Exit 0; 0.988s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "site/engine",
  "status": "candidates-read-sources",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [
    {
      "path": "site/engine",
      "kind": "directory",
      "purpose": "Shared Canvas geometry/lifecycle, renderer, native-scroll router, theme, filters and CSS.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "editing_owners": [
    "guides/ARTICLE-WORKFLOW.md",
    "site/README.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "entry points, maintained guides and preserved root history",
      "paths": [
        "PROJECT-BOOTSTRAP.md",
        ".github/repository-layout.json",
        "guides/",
        "review/root-history-20261007/",
        "tools/check_repository_layout.py",
        "tests/test_root_layout.py",
        "tools/run_repository_tests.py",
        "tests/test_repository_test_selection.py"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_root_layout.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_test_selection.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Permanent contracts validate current routes and archive identities; frozen public/history snapshots belong only to the selected issue policy."
    },
    {
      "concern": "authored site and generated output",
      "paths": [
        "site/",
        "docs/",
        "tools/site/"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "workflow": ".github/workflows/site-checks.yml"
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "authored article publisher and Writing reader",
      "paths": [
        "site/publications/",
        "site/article-preview.json",
        "site/assets/publications/",
        "tools/publishing/",
        "tools/site/articles.cjs",
        "tests/publishing",
        "tests/site-articles.test.cjs",
        "tests/article-",
        "guides/ARTICLE-WORKFLOW.md",
        "tests/test_issue5_acceptance.py",
        ".github/acceptance/issue-5.json",
        "tools/site/offline.cjs",
        "tools/site/standalone.cjs",
        "tools/quality/candidate-source.cjs",
        "tools/quality/article-browser.cjs",
        "tests/local-catalog-relationships.test.cjs",
        "tests/site-transaction.test.cjs"
      ],
      "commands": [
        "node --test tests/publishing.test.cjs tests/publishing-history.test.cjs tests/publishing-profile.test.cjs tests/publishing-safety.test.cjs tests/publishing-print.test.cjs",
        "node --test tests/site-articles.test.cjs tests/site-transaction.test.cjs tests/article-offline.test.cjs tests/local-catalog-relationships.test.cjs tests/article-budgets.test.cjs tests/article-browser-evidence.test.cjs tests/article-candidate-source.test.cjs tests/article-delivery.test.cjs",
        "python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-5.json --report /tmp/issue-5-acceptance.json"
      ],
      "read": [
        "guides/ARTICLE-WORKFLOW.md",
        "site/README.md",
        "guides/SITE-CHECK-PROFILES.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Prepare the locked build-only toolchain before selected source checks. Actual PDF/native-editor/browser/rights/publication evidence and controller promotion remain separate; this route does not publish."
    },
    {
      "concern": "production preparation, canonical Pages migration and release-bound rights inventory",
      "paths": [
        "LICENSING.md",
        "LICENSE-CODE.md",
        "LICENSE-CONTENT.md",
        "NOTICE.md",
        "site/content/production-social.json",
        "site/rights.json",
        "tools/pages/",
        "tools/release/",
        "tools/site/edition-retention.cjs",
        "tools/site/legal.cjs",
        "site/templates/components/legal-notices.html",
        "tools/check_site_seo.cjs",
        "tests/executive.test.cjs",
        "tests/site-engine.test.cjs",
        "site/content/pages/credits/main.json",
        "site/templates/pages/credits/main.html",
        "site/engine/styles.css",
        "docs/styles.css",
        "tests/edition-retention.test.cjs",
        "tests/pages-migration.test.cjs",
        "tests/release-rights.test.cjs",
        ".github/workflows/site-pages-migration.yml",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md"
      ],
      "commands": [
        "node --test tests/executive.test.cjs tests/site-engine.test.cjs tests/edition-retention.test.cjs tests/pages-migration.test.cjs tests/release-rights.test.cjs tests/release-controller.test.cjs tests/release-archive.test.cjs",
        "node tools/quality/local.cjs"
      ],
      "read": [
        "LICENSING.md",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md",
        "guides/SITE-RELEASE-GATES.md"
      ],
      "workflow": ".github/workflows/site-checks.yml",
      "note": "Changed-source tests are selected through test-profiles.json; issue39 selects its source-bound implementation checks. Fixtures cannot supply maintainer reuse-policy or rights decisions, protected settings, actual domain migration, device acceptance or publication approval."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 17,
    "returned": 1,
    "remaining": 16,
    "request_fingerprint": "e185288a14c19d7b5d51bf200099bbb102e7f9f54704a6d1f64d9303fc097f82",
    "next_cursor": "1:e185288a14c19d7b5d51bf200099bbb102e7f9f54704a6d1f64d9303fc097f82"
  },
  "response_bytes": 6910,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### history

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope history --prefix review/issue-189 --limit 2`

Exit 0; 1.132s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "files": [
    {
      "path": "review/issue-189/2026-11-10-analysis.md",
      "kind": "file",
      "purpose": "Issue189 inspected-source architecture, proposed execution steps, refined AC01-AC05, author archive/headroom decisions and planning evidence limits.",
      "role": "history",
      "owner": "CONTRIBUTING.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "Issue189 — 2026-11-10 architecture and execution plan"
    }
  ],
  "directories": [
    {
      "path": "review/issue-189",
      "kind": "directory",
      "purpose": "Issue189 current RI navigation/capacity architecture, planning review and later source-bound execution evidence.",
      "role": "history",
      "owner": "CONTRIBUTING.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "editing_owners": [
    "CONTRIBUTING.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "repository intelligence and continuity",
      "paths": [
        "AGENTS.md",
        "MEMORY.md",
        "CONTRIBUTING.md",
        "README.md",
        "guides/REPOSITORIES.md",
        "REPOSITORY-MAP.md",
        ".github/repository-",
        ".github/REPOSITORY-INTELLIGENCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "tools/repository_intelligence.py",
        "tests/test_repository_intelligence.py",
        ".github/ri-ci-map.json",
        "tools/check_ri_ci.py",
        "tests/test_ri_ci.py",
        "PROJECT-BOOTSTRAP.md",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_ri_ci.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json build",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify"
      ],
      "workflow": ".github/workflows/navigation.yml"
    },
    {
      "concern": "independent quality-agent protocol and risk-to-test handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        "tools/quality/source-tests.cjs",
        "tests/test_repository_intelligence.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/check_ri_ci.py verify"
      ],
      "read": [
        "CONTRIBUTING.md",
        "agents/reviewers/README.md",
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        ".github/workflows/issue-acceptance.yml"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Follow CONTRIBUTING.md#independent-quality-agents for separately launched Requirements/Acceptance Reviewer, Code Reviewer, White-box QA and Exploratory/Interaction QA. These commands verify navigation and CI coupling, not agent execution or acceptance. Map findings and test dispositions to the live owning issue, existing profile registry and its acceptance policy; retain actual role results and manual limits in the review artifact."
    },
    {
      "concern": "issue acceptance and anchored analysis/review handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/acceptance/",
        ".github/workflows/issue-acceptance.yml",
        "tools/issue_acceptance.py",
        "tests/test_issue_acceptance.py",
        "tests/test_issue31_acceptance.py",
        "review/REVIEW-TEMPLATE.md",
        "review/issue-",
        "PROJECT-BOOTSTRAP.md",
        "tests/test_issue33_acceptance.py",
        "tests/test_issue35_acceptance.py",
        "tests/test_issue36_acceptance.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/issue_acceptance.py --help"
      ],
      "read": [
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Help only describes invocation; it is not an acceptance check. Revalidate the live owning issue and select its policy from the PR's single Refs line or explicit dispatch issue, following ACCEPTANCE.md for exact-source execution. Historical policies do not select current work. Automated assertions cannot supply independent role execution/review, observed hosted timing, owner/device acceptance, merge or live GitHub linkage."
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "history",
  "prefix": "review/issue-189",
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 2,
    "offset": 0,
    "total": 8,
    "returned": 2,
    "remaining": 6,
    "request_fingerprint": "1e7118641a79f3db72e25d1289b8e367deaf0b08a5550561b97cc47492dc0707",
    "next_cursor": "2:1e7118641a79f3db72e25d1289b8e367deaf0b08a5550561b97cc47492dc0707"
  },
  "response_bytes": 6490,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### generated

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json query docs/writing.html --scope all`

Exit 0; 1.154s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "docs/writing.html",
  "status": "candidates-read-sources",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [
    {
      "path": "docs/writing.html",
      "kind": "file",
      "purpose": "Generated public rendition: writing.html; regenerate from site sources with tools/site/build.cjs.",
      "role": "generated",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "writing.html"
    }
  ],
  "directories": [],
  "editing_owners": [
    "site/README.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "authored site and generated output",
      "paths": [
        "site/",
        "docs/",
        "tools/site/"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "workflow": ".github/workflows/site-checks.yml"
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "all",
  "prefix": null,
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 20,
    "offset": 0,
    "total": 1,
    "returned": 1,
    "remaining": 0,
    "request_fingerprint": "156a17d4236dd26c1ed706a21d9b967c254bca094126266c17cbac6c188cf1b4",
    "next_cursor": null
  },
  "response_bytes": 2407,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### generated current

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json query docs/writing.html --scope current`

Exit 0; 1.173s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "docs/writing.html",
  "status": "unresolved-use-direct-search",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [],
  "editing_owners": [],
  "instructions": [],
  "validation_routes": [],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 20,
    "offset": 0,
    "total": 0,
    "returned": 0,
    "remaining": 0,
    "request_fingerprint": "af47d9f7db1090b789cffe6283d36eedadb9f6b0ab507b56c6ba4a7b93be9a2a",
    "next_cursor": null
  },
  "response_bytes": 892,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### lexical miss

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json query zz_unfindable_189_qaz --scope current`

Exit 0; 1.174s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "zz_unfindable_189_qaz",
  "status": "unresolved-use-direct-search",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [],
  "editing_owners": [],
  "instructions": [],
  "validation_routes": [],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 20,
    "offset": 0,
    "total": 0,
    "returned": 0,
    "remaining": 0,
    "request_fingerprint": "18105de20f6c7aa561b64ef573788ae95d6c306bfb8b35725db4788a91dc1f6a",
    "next_cursor": null
  },
  "response_bytes": 896,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### component miss

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope all --prefix site/enginez`

Exit 0; 1.033s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "files": [],
  "directories": [],
  "editing_owners": [],
  "instructions": [],
  "validation_routes": [],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "all",
  "prefix": "site/enginez",
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 20,
    "offset": 0,
    "total": 0,
    "returned": 0,
    "remaining": 0,
    "request_fingerprint": "b47612dbf75aaa6f9c4b5e5a1108b73f7021e6563f96c57ceef9cfd240a79f32",
    "next_cursor": null
  },
  "response_bytes": 760,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### broad metadata

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task . --scope all --limit 1`

Exit 0; 1.001s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": ".",
  "status": "candidates-read-sources",
  "owner_candidates": [
    {
      "path": "guides/SITE-PRODUCTION.md",
      "concern": "GitHub Pages production custom domain and canonical redirect readiness",
      "queries": [
        "production domain",
        "custom domain",
        "GitHub Pages",
        "vitaliioborskyi.ai",
        "vitaliioborskyi.com",
        "domain redirect",
        "домен",
        "домени",
        "гітхаб пейджес"
      ]
    },
    {
      "concern": "personal-site code and content licensing, exclusions and attribution notices",
      "path": "LICENSING.md",
      "queries": [
        "site licensing",
        "code license",
        "content license",
        "Apache-2.0",
        "CC BY 4.0",
        "copyright",
        "ліцензування сайту",
        "ліцензія коду",
        "ліцензія контенту"
      ]
    }
  ],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [
    {
      "path": ".",
      "kind": "directory",
      "purpose": "Repository entry points, authored site, generated renditions, checks and historical review evidence.",
      "role": "guide",
      "owner": "CONTRIBUTING.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "editing_owners": [
    ".github/ACCEPTANCE.md",
    ".github/REPOSITORY-INTELLIGENCE.md",
    "AGENTS.md",
    "CONTRIBUTING.md",
    "LICENSING.md",
    "PROJECT-BOOTSTRAP.md",
    "README.md",
    "agents/reviewers/README.md",
    "agents/reviewers/code-review.md",
    "agents/reviewers/exploratory-interaction-qa.md",
    "agents/reviewers/requirements-acceptance.md",
    "agents/reviewers/white-box-qa.md",
    "guides/ARTICLE-MATERIALS.md",
    "guides/ARTICLE-WORKFLOW.md",
    "guides/BROWSER-ARCHIVES.md",
    "guides/CODE-STYLE.md",
    "guides/README.md",
    "guides/REPOSITORIES.md",
    "guides/SITE-ANALYTICS.md",
    "guides/SITE-CHECK-PROFILES.md",
    "guides/SITE-CONTENT-RELEASE.md",
    "guides/SITE-CONTENT-REVIEW.md",
    "guides/SITE-CONTROL-CHANGES.md",
    "guides/SITE-PRODUCTION.md",
    "guides/SITE-RELEASE-GATES.md",
    "guides/SITE-RIGHTS.md",
    "guides/SITE-ROADMAP.md",
    "guides/SITE-SEO.md",
    "guides/SITE-SOURCE-AUDIT.md",
    "guides/SITE-STAGING.md",
    "guides/WEB-ORCHESTRATION.md",
    "review/REVIEW-TEMPLATE.md",
    "review/issue-2/2026-10-21-r20-review.md",
    "review/issue-2/2026-10-21-r21-review.md",
    "review/issue-2/2026-10-23-r26-integration.md",
    "review/issue-2/2026-10-23-r27-feedback-and-reader.md",
    "review/issue-2/2026-10-24-r28-problem-framing.md",
    "review/issue-2/2026-10-24-r29-problem-framing.md",
    "review/issue-2/2026-10-24-r30-editorial-clarity.md",
    "review/issue-36/2026-10-07-handoff.md",
    "review/issue-39/2026-10-15-controller-compatibility.md",
    "review/issue-39/2026-10-16-compact-controller.md",
    "review/issue-39/2026-10-16-readiness-execution.md",
    "review/issue-39/2026-10-16-stable-staging.md",
    "review/issue-39/2026-10-16-writing-tbt.md",
    "review/issue-5/2026-10-12-ci-followup.md",
    "review/issue-5/2026-10-12-color-runtime.md",
    "review/issue-5/2026-10-12-execution.md",
    "review/issue-5/2026-10-13-content-release.md",
    "review/issue-5/2026-10-19-reader-resources-and-notices.md",
    "review/issue-5/2026-10-21-performance-review.md",
    "review/issue-58/2026-10-08-final-visual.json",
    "review/issue-58/2026-10-08-handoff.md",
    "review/issue-58/2026-10-08-visual-parity.json",
    "site/README.md",
    "tools/RI-NOTICE.md",
    "tools/check_site_seo.cjs",
    "tools/quality/README.md",
    "tools/quality/control-lock.cjs",
    "tools/quality/control-runner.cjs",
    "tools/quality/delivery-admission.cjs",
    "tools/quality/delivery-observation.cjs",
    "tools/site/build.cjs"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "repository intelligence and continuity",
      "paths": [
        "AGENTS.md",
        "MEMORY.md",
        "CONTRIBUTING.md",
        "README.md",
        "guides/REPOSITORIES.md",
        "REPOSITORY-MAP.md",
        ".github/repository-",
        ".github/REPOSITORY-INTELLIGENCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "tools/repository_intelligence.py",
        "tests/test_repository_intelligence.py",
        ".github/ri-ci-map.json",
        "tools/check_ri_ci.py",
        "tests/test_ri_ci.py",
        "PROJECT-BOOTSTRAP.md",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_ri_ci.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json build",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify"
      ],
      "workflow": ".github/workflows/navigation.yml"
    },
    {
      "concern": "entry points, maintained guides and preserved root history",
      "paths": [
        "PROJECT-BOOTSTRAP.md",
        ".github/repository-layout.json",
        "guides/",
        "review/root-history-20261007/",
        "tools/check_repository_layout.py",
        "tests/test_root_layout.py",
        "tools/run_repository_tests.py",
        "tests/test_repository_test_selection.py"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_root_layout.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_test_selection.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Permanent contracts validate current routes and archive identities; frozen public/history snapshots belong only to the selected issue policy."
    },
    {
      "concern": "authored site and generated output",
      "paths": [
        "site/",
        "docs/",
        "tools/site/"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "workflow": ".github/workflows/site-checks.yml"
    },
    {
      "concern": "hosting and release checks",
      "paths": [
        "tools/staging/",
        "tools/pages/",
        "tools/release/",
        "tools/quality/",
        ".github/workflows/site-",
        "guides/SITE-CHECK-PROFILES.md",
        "guides/SITE-RELEASE-GATES.md",
        "guides/SITE-STAGING.md"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "read": [
        "guides/SITE-CHECK-PROFILES.md",
        "guides/SITE-RELEASE-GATES.md",
        "guides/SITE-STAGING.md"
      ],
      "note": "Select the authorized hosted profile; this route does not trigger deployment."
    },
    {
      "concern": "independent quality-agent protocol and risk-to-test handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        "tools/quality/source-tests.cjs",
        "tests/test_repository_intelligence.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/check_ri_ci.py verify"
      ],
      "read": [
        "CONTRIBUTING.md",
        "agents/reviewers/README.md",
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        ".github/workflows/issue-acceptance.yml"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Follow CONTRIBUTING.md#independent-quality-agents for separately launched Requirements/Acceptance Reviewer, Code Reviewer, White-box QA and Exploratory/Interaction QA. These commands verify navigation and CI coupling, not agent execution or acceptance. Map findings and test dispositions to the live owning issue, existing profile registry and its acceptance policy; retain actual role results and manual limits in the review artifact."
    },
    {
      "concern": "issue acceptance and anchored analysis/review handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/acceptance/",
        ".github/workflows/issue-acceptance.yml",
        "tools/issue_acceptance.py",
        "tests/test_issue_acceptance.py",
        "tests/test_issue31_acceptance.py",
        "review/REVIEW-TEMPLATE.md",
        "review/issue-",
        "PROJECT-BOOTSTRAP.md",
        "tests/test_issue33_acceptance.py",
        "tests/test_issue35_acceptance.py",
        "tests/test_issue36_acceptance.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/issue_acceptance.py --help"
      ],
      "read": [
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Help only describes invocation; it is not an acceptance check. Revalidate the live owning issue and select its policy from the PR's single Refs line or explicit dispatch issue, following ACCEPTANCE.md for exact-source execution. Historical policies do not select current work. Automated assertions cannot supply independent role execution/review, observed hosted timing, owner/device acceptance, merge or live GitHub linkage."
    },
    {
      "concern": "canonical test inventory, changed-source selection and selected staging evidence",
      "paths": [
        "tools/quality/test-profiles.json",
        "tools/quality/source-tests.cjs",
        "tools/quality/staging-regression.cjs",
        "tools/quality/staging-gate.cjs",
        "tests/test-profile-selection.test.cjs",
        "tests/staging-regression.test.cjs",
        "tests/staging-gate.test.cjs",
        "tests/fixtures/",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/bandit-triage.cjs",
        "tools/quality/bandit-policy.json",
        "tools/quality/scanners.cjs",
        "tools/quality/generated-checksums.cjs",
        "tools/quality/secrets-baseline.json",
        "tests/quality-sources.test.cjs",
        "tools/quality/secrets-reviewed.json",
        "tools/quality/secrets-reviewed-checksums.json",
        "tools/quality/transition-pacing.json",
        "tools/quality/transition-pacing.cjs",
        "tools/quality/source-test-worker.cjs"
      ],
      "commands": [
        "node --test tests/test-profile-selection.test.cjs tests/staging-gate.test.cjs tests/staging-regression.test.cjs tests/quality-sources.test.cjs",
        "node tools/quality/source-tests.cjs --profile production --plan"
      ],
      "read": [
        "guides/SITE-CHECK-PROFILES.md",
        "guides/SITE-RELEASE-GATES.md",
        "guides/SITE-STAGING.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Plan lists allocation, not a passing run. PR execution requires exact --base/--head; staging/production selection and explicit diagnostic replay use the canonical registry. Hosted checks need an authorized exact candidate/origin; this navigation route does not deploy or provide external release acceptance."
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "authored article publisher and Writing reader",
      "paths": [
        "site/publications/",
        "site/article-preview.json",
        "site/assets/publications/",
        "tools/publishing/",
        "tools/site/articles.cjs",
        "tests/publishing",
        "tests/site-articles.test.cjs",
        "tests/article-",
        "guides/ARTICLE-WORKFLOW.md",
        "tests/test_issue5_acceptance.py",
        ".github/acceptance/issue-5.json",
        "tools/site/offline.cjs",
        "tools/site/standalone.cjs",
        "tools/quality/candidate-source.cjs",
        "tools/quality/article-browser.cjs",
        "tests/local-catalog-relationships.test.cjs",
        "tests/site-transaction.test.cjs"
      ],
      "commands": [
        "node --test tests/publishing.test.cjs tests/publishing-history.test.cjs tests/publishing-profile.test.cjs tests/publishing-safety.test.cjs tests/publishing-print.test.cjs",
        "node --test tests/site-articles.test.cjs tests/site-transaction.test.cjs tests/article-offline.test.cjs tests/local-catalog-relationships.test.cjs tests/article-budgets.test.cjs tests/article-browser-evidence.test.cjs tests/article-candidate-source.test.cjs tests/article-delivery.test.cjs",
        "python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-5.json --report /tmp/issue-5-acceptance.json"
      ],
      "read": [
        "guides/ARTICLE-WORKFLOW.md",
        "site/README.md",
        "guides/SITE-CHECK-PROFILES.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Prepare the locked build-only toolchain before selected source checks. Actual PDF/native-editor/browser/rights/publication evidence and controller promotion remain separate; this route does not publish."
    },
    {
      "concern": "production preparation, canonical Pages migration and release-bound rights inventory",
      "paths": [
        "LICENSING.md",
        "LICENSE-CODE.md",
        "LICENSE-CONTENT.md",
        "NOTICE.md",
        "site/content/production-social.json",
        "site/rights.json",
        "tools/pages/",
        "tools/release/",
        "tools/site/edition-retention.cjs",
        "tools/site/legal.cjs",
        "site/templates/components/legal-notices.html",
        "tools/check_site_seo.cjs",
        "tests/executive.test.cjs",
        "tests/site-engine.test.cjs",
        "site/content/pages/credits/main.json",
        "site/templates/pages/credits/main.html",
        "site/engine/styles.css",
        "docs/styles.css",
        "tests/edition-retention.test.cjs",
        "tests/pages-migration.test.cjs",
        "tests/release-rights.test.cjs",
        ".github/workflows/site-pages-migration.yml",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md"
      ],
      "commands": [
        "node --test tests/executive.test.cjs tests/site-engine.test.cjs tests/edition-retention.test.cjs tests/pages-migration.test.cjs tests/release-rights.test.cjs tests/release-controller.test.cjs tests/release-archive.test.cjs",
        "node tools/quality/local.cjs"
      ],
      "read": [
        "LICENSING.md",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md",
        "guides/SITE-RELEASE-GATES.md"
      ],
      "workflow": ".github/workflows/site-checks.yml",
      "note": "Changed-source tests are selected through test-profiles.json; issue39 selects its source-bound implementation checks. Fixtures cannot supply maintainer reuse-policy or rights decisions, protected settings, actual domain migration, device acceptance or publication approval."
    },
    {
      "concern": "fixture-only WEB orchestration state and recovery",
      "paths": [
        "tools/orchestration/",
        "tests/orchestration.test.cjs",
        "tests/fixtures/orchestration-accept-only.json",
        "tests/fixtures/orchestration-start.json",
        "guides/WEB-ORCHESTRATION.md"
      ],
      "commands": [
        "node --test tests/orchestration.test.cjs",
        "node tools/quality/local.cjs"
      ],
      "read": [
        "guides/WEB-ORCHESTRATION.md",
        "guides/SITE-CHECK-PROFILES.md",
        "guides/SITE-STAGING.md"
      ],
      "workflow": ".github/workflows/site-checks.yml",
      "note": "Direct node command is component evidence; maintained registry selects the suite through existing Basic/source profiles. Executable full B/R/O/H route and native RI/admission remain pending on Draft; this route never dispatches agents or deploys."
    },
    {
      "concern": "detailed reviewer prompt requirements-acceptance",
      "paths": [
        "agents/reviewers/requirements-acceptance.md"
      ],
      "read": [
        "agents/reviewers/README.md",
        "agents/reviewers/requirements-acceptance.md",
        "CONTRIBUTING.md"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read the common contract and this single role prompt for a role launch; navigation checks do not establish reviewer execution."
    },
    {
      "concern": "detailed reviewer prompt code-review",
      "paths": [
        "agents/reviewers/code-review.md"
      ],
      "read": [
        "agents/reviewers/README.md",
        "agents/reviewers/code-review.md",
        "CONTRIBUTING.md"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read the common contract and this single role prompt for a role launch; navigation checks do not establish reviewer execution."
    },
    {
      "concern": "detailed reviewer prompt white-box-qa",
      "paths": [
        "agents/reviewers/white-box-qa.md"
      ],
      "read": [
        "agents/reviewers/README.md",
        "agents/reviewers/white-box-qa.md",
        "CONTRIBUTING.md"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read the common contract and this single role prompt for a role launch; navigation checks do not establish reviewer execution."
    },
    {
      "concern": "detailed reviewer prompt exploratory-interaction-qa",
      "paths": [
        "agents/reviewers/exploratory-interaction-qa.md"
      ],
      "read": [
        "agents/reviewers/README.md",
        "agents/reviewers/exploratory-interaction-qa.md",
        "CONTRIBUTING.md"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read the common contract and this single role prompt for a role launch; navigation checks do not establish reviewer execution."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "all",
  "prefix": null,
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 2949,
    "returned": 1,
    "remaining": 2948,
    "request_fingerprint": "8e2f091efa8a80f60ee72c6d928713313e5ea23fc2506b5beb7b96ed3daee7b0",
    "next_cursor": "1:8e2f091efa8a80f60ee72c6d928713313e5ea23fc2506b5beb7b96ed3daee7b0"
  },
  "response_bytes": 20134,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### capacity

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json capacity`

Exit 0; 0.381s. Complete stdout / stderr:

```text
{
  "kind": "capacity-metadata-diagnostic",
  "inventory_complete": true,
  "content_integrity_verified": false,
  "catalog_and_freshness_verified": false,
  "within_hard_limits": true,
  "hard_limit_violations": [],
  "hash_input_files": 2663,
  "metrics": {
    "files": {
      "used": 2665,
      "limit": 5000,
      "margin": 2335
    },
    "hash_total_bytes": {
      "used": 238678837,
      "limit": 250000000,
      "margin": 11321163
    },
    "hash_file_bytes": {
      "used": 11726610,
      "limit": 32000000,
      "margin": 20273390
    },
    "text_total_bytes": {
      "used": 21811781,
      "limit": 50000000,
      "margin": 28188219
    },
    "text_file_bytes": {
      "used": 1999782,
      "limit": 2000000,
      "margin": 218
    }
  },
  "largest_hash_input": {
    "path": "review/site-v1-20261002-v6.zip",
    "bytes": 11726610
  },
  "largest_parsed_text": {
    "path": "tools/quality/secrets-reviewed.json",
    "bytes": 1999782
  },
  "derived_outputs": [
    {
      "path": ".github/repository-intelligence/agent-context.json",
      "bytes": 1759709
    },
    {
      "path": "REPOSITORY-MAP.md",
      "bytes": 14272
    }
  ],
  "top_hash_inputs": [
    {
      "path": "review/site-v1-20261002-v6.zip",
      "bytes": 11726610
    },
    {
      "path": "review/site-v1-20261002-v7.zip",
      "bytes": 11065237
    },
    {
      "path": "review/site-v1-20261002-v5.zip",
      "bytes": 10266858
    },
    {
      "path": "review/issue-2/r28-20261024/The_Sum_of_Our_Technology_R28_2026-10-24_Native_Review_Kit.zip",
      "bytes": 6521711
    },
    {
      "path": "review/issue-2/r27-20261023/The_Sum_of_Our_Technology_R27_2026-10-23_Native_Review_Kit.zip",
      "bytes": 6517105
    },
    {
      "path": "review/issue-2/r26-20261023/The_Sum_of_Our_Technology_R26_2026-10-23_Native_Review_Kit.zip",
      "bytes": 6513698
    },
    {
      "path": "review/issue-2/pmday-candidate-20261015/social-covers.zip",
      "bytes": 4104141
    },
    {
      "path": "review/issue-2/r29-20261024/The_Sum_of_Our_Technology_R29_2026-10-24_Native_Review_Kit.tar.xz",
      "bytes": 3418440
    },
    {
      "path": "review/issue-2/pmday-candidate-20261015/r18-review-source.zip",
      "bytes": 2977084
    },
    {
      "path": "site/assets/publications/pmday-ai-both-sides/source/cover-square.png",
      "bytes": 2178257
    }
  ],
  "advisories": [],
  "note": "Metadata/readability only; build/verify still enforce every original hard limit and input hash."
}

STDERR:
```

### page1

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope current --prefix site/engine --limit 2`

Exit 0; 1.033s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "files": [
    {
      "path": "site/engine/archive.js",
      "kind": "file",
      "purpose": "Accessible Writing topic filters, curated publication rendering and reflow.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "archive.js"
    }
  ],
  "directories": [
    {
      "path": "site/engine",
      "kind": "directory",
      "purpose": "Shared Canvas geometry/lifecycle, renderer, native-scroll router, theme, filters and CSS.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "editing_owners": [
    "guides/ARTICLE-WORKFLOW.md",
    "site/README.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "entry points, maintained guides and preserved root history",
      "paths": [
        "PROJECT-BOOTSTRAP.md",
        ".github/repository-layout.json",
        "guides/",
        "review/root-history-20261007/",
        "tools/check_repository_layout.py",
        "tests/test_root_layout.py",
        "tools/run_repository_tests.py",
        "tests/test_repository_test_selection.py"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_root_layout.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_test_selection.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Permanent contracts validate current routes and archive identities; frozen public/history snapshots belong only to the selected issue policy."
    },
    {
      "concern": "authored site and generated output",
      "paths": [
        "site/",
        "docs/",
        "tools/site/"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "workflow": ".github/workflows/site-checks.yml"
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "authored article publisher and Writing reader",
      "paths": [
        "site/publications/",
        "site/article-preview.json",
        "site/assets/publications/",
        "tools/publishing/",
        "tools/site/articles.cjs",
        "tests/publishing",
        "tests/site-articles.test.cjs",
        "tests/article-",
        "guides/ARTICLE-WORKFLOW.md",
        "tests/test_issue5_acceptance.py",
        ".github/acceptance/issue-5.json",
        "tools/site/offline.cjs",
        "tools/site/standalone.cjs",
        "tools/quality/candidate-source.cjs",
        "tools/quality/article-browser.cjs",
        "tests/local-catalog-relationships.test.cjs",
        "tests/site-transaction.test.cjs"
      ],
      "commands": [
        "node --test tests/publishing.test.cjs tests/publishing-history.test.cjs tests/publishing-profile.test.cjs tests/publishing-safety.test.cjs tests/publishing-print.test.cjs",
        "node --test tests/site-articles.test.cjs tests/site-transaction.test.cjs tests/article-offline.test.cjs tests/local-catalog-relationships.test.cjs tests/article-budgets.test.cjs tests/article-browser-evidence.test.cjs tests/article-candidate-source.test.cjs tests/article-delivery.test.cjs",
        "python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-5.json --report /tmp/issue-5-acceptance.json"
      ],
      "read": [
        "guides/ARTICLE-WORKFLOW.md",
        "site/README.md",
        "guides/SITE-CHECK-PROFILES.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Prepare the locked build-only toolchain before selected source checks. Actual PDF/native-editor/browser/rights/publication evidence and controller promotion remain separate; this route does not publish."
    },
    {
      "concern": "production preparation, canonical Pages migration and release-bound rights inventory",
      "paths": [
        "LICENSING.md",
        "LICENSE-CODE.md",
        "LICENSE-CONTENT.md",
        "NOTICE.md",
        "site/content/production-social.json",
        "site/rights.json",
        "tools/pages/",
        "tools/release/",
        "tools/site/edition-retention.cjs",
        "tools/site/legal.cjs",
        "site/templates/components/legal-notices.html",
        "tools/check_site_seo.cjs",
        "tests/executive.test.cjs",
        "tests/site-engine.test.cjs",
        "site/content/pages/credits/main.json",
        "site/templates/pages/credits/main.html",
        "site/engine/styles.css",
        "docs/styles.css",
        "tests/edition-retention.test.cjs",
        "tests/pages-migration.test.cjs",
        "tests/release-rights.test.cjs",
        ".github/workflows/site-pages-migration.yml",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md"
      ],
      "commands": [
        "node --test tests/executive.test.cjs tests/site-engine.test.cjs tests/edition-retention.test.cjs tests/pages-migration.test.cjs tests/release-rights.test.cjs tests/release-controller.test.cjs tests/release-archive.test.cjs",
        "node tools/quality/local.cjs"
      ],
      "read": [
        "LICENSING.md",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md",
        "guides/SITE-RELEASE-GATES.md"
      ],
      "workflow": ".github/workflows/site-checks.yml",
      "note": "Changed-source tests are selected through test-profiles.json; issue39 selects its source-bound implementation checks. Fixtures cannot supply maintainer reuse-policy or rights decisions, protected settings, actual domain migration, device acceptance or publication approval."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": "site/engine",
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 2,
    "offset": 0,
    "total": 17,
    "returned": 2,
    "remaining": 15,
    "request_fingerprint": "9fb058aaee88bcc42c0fd0346302592477a248e6ebb64a6d86171575e3d40284",
    "next_cursor": "2:9fb058aaee88bcc42c0fd0346302592477a248e6ebb64a6d86171575e3d40284"
  },
  "response_bytes": 7103,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### page2

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope current --prefix site/engine --limit 2 --cursor 2:9fb058aaee88bcc42c0fd0346302592477a248e6ebb64a6d86171575e3d40284`

Exit 0; 1.082s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "files": [
    {
      "path": "site/engine/article-print.css",
      "kind": "file",
      "purpose": "Canonical readable publication print stylesheet consumed by the isolated print adapter.",
      "role": "source",
      "owner": "guides/ARTICLE-WORKFLOW.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "article-print.css"
    },
    {
      "path": "site/engine/article-tags.cjs",
      "kind": "file",
      "role": "source",
      "owner": "site/README.md",
      "purpose": "Shared canonical publication tags, independently updated index, bounded runtime recommendations and verification.",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "article-tags.cjs"
    }
  ],
  "directories": [],
  "editing_owners": [
    "guides/ARTICLE-WORKFLOW.md",
    "site/README.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "entry points, maintained guides and preserved root history",
      "paths": [
        "PROJECT-BOOTSTRAP.md",
        ".github/repository-layout.json",
        "guides/",
        "review/root-history-20261007/",
        "tools/check_repository_layout.py",
        "tests/test_root_layout.py",
        "tools/run_repository_tests.py",
        "tests/test_repository_test_selection.py"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_root_layout.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_test_selection.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Permanent contracts validate current routes and archive identities; frozen public/history snapshots belong only to the selected issue policy."
    },
    {
      "concern": "authored site and generated output",
      "paths": [
        "site/",
        "docs/",
        "tools/site/"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "workflow": ".github/workflows/site-checks.yml"
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "authored article publisher and Writing reader",
      "paths": [
        "site/publications/",
        "site/article-preview.json",
        "site/assets/publications/",
        "tools/publishing/",
        "tools/site/articles.cjs",
        "tests/publishing",
        "tests/site-articles.test.cjs",
        "tests/article-",
        "guides/ARTICLE-WORKFLOW.md",
        "tests/test_issue5_acceptance.py",
        ".github/acceptance/issue-5.json",
        "tools/site/offline.cjs",
        "tools/site/standalone.cjs",
        "tools/quality/candidate-source.cjs",
        "tools/quality/article-browser.cjs",
        "tests/local-catalog-relationships.test.cjs",
        "tests/site-transaction.test.cjs"
      ],
      "commands": [
        "node --test tests/publishing.test.cjs tests/publishing-history.test.cjs tests/publishing-profile.test.cjs tests/publishing-safety.test.cjs tests/publishing-print.test.cjs",
        "node --test tests/site-articles.test.cjs tests/site-transaction.test.cjs tests/article-offline.test.cjs tests/local-catalog-relationships.test.cjs tests/article-budgets.test.cjs tests/article-browser-evidence.test.cjs tests/article-candidate-source.test.cjs tests/article-delivery.test.cjs",
        "python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-5.json --report /tmp/issue-5-acceptance.json"
      ],
      "read": [
        "guides/ARTICLE-WORKFLOW.md",
        "site/README.md",
        "guides/SITE-CHECK-PROFILES.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Prepare the locked build-only toolchain before selected source checks. Actual PDF/native-editor/browser/rights/publication evidence and controller promotion remain separate; this route does not publish."
    },
    {
      "concern": "production preparation, canonical Pages migration and release-bound rights inventory",
      "paths": [
        "LICENSING.md",
        "LICENSE-CODE.md",
        "LICENSE-CONTENT.md",
        "NOTICE.md",
        "site/content/production-social.json",
        "site/rights.json",
        "tools/pages/",
        "tools/release/",
        "tools/site/edition-retention.cjs",
        "tools/site/legal.cjs",
        "site/templates/components/legal-notices.html",
        "tools/check_site_seo.cjs",
        "tests/executive.test.cjs",
        "tests/site-engine.test.cjs",
        "site/content/pages/credits/main.json",
        "site/templates/pages/credits/main.html",
        "site/engine/styles.css",
        "docs/styles.css",
        "tests/edition-retention.test.cjs",
        "tests/pages-migration.test.cjs",
        "tests/release-rights.test.cjs",
        ".github/workflows/site-pages-migration.yml",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md"
      ],
      "commands": [
        "node --test tests/executive.test.cjs tests/site-engine.test.cjs tests/edition-retention.test.cjs tests/pages-migration.test.cjs tests/release-rights.test.cjs tests/release-controller.test.cjs tests/release-archive.test.cjs",
        "node tools/quality/local.cjs"
      ],
      "read": [
        "LICENSING.md",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md",
        "guides/SITE-RELEASE-GATES.md"
      ],
      "workflow": ".github/workflows/site-checks.yml",
      "note": "Changed-source tests are selected through test-profiles.json; issue39 selects its source-bound implementation checks. Fixtures cannot supply maintainer reuse-policy or rights decisions, protected settings, actual domain migration, device acceptance or publication approval."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": "site/engine",
  "source_digest": "5797a5015bc43b6fc634f969bda4249198973510fbcc0bd6bc91163b05d3766a",
  "pagination": {
    "order": "kind,path",
    "limit": 2,
    "offset": 2,
    "total": 17,
    "returned": 2,
    "remaining": 13,
    "request_fingerprint": "9fb058aaee88bcc42c0fd0346302592477a248e6ebb64a6d86171575e3d40284",
    "next_cursor": "4:9fb058aaee88bcc42c0fd0346302592477a248e6ebb64a6d86171575e3d40284"
  },
  "response_bytes": 7210,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### changed request cursor

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope history --prefix site/engine --limit 2 --cursor 2:9fb058aaee88bcc42c0fd0346302592477a248e6ebb64a6d86171575e3d40284`

Exit 1; 1.211s. Complete stdout / stderr:

```text

STDERR:
RI unavailable: Cursor does not match request/source; start a new first page. Read authoritative sources directly.
```

### unsafe prefix

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope current --prefix ../site`

Exit 1; 1.311s. Complete stdout / stderr:

```text

STDERR:
RI unavailable: Unsafe navigation prefix. Read authoritative sources directly.
```

### zero limit

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope current --limit 0`

Exit 1; 1.078s. Complete stdout / stderr:

```text

STDERR:
RI unavailable: Page limit must be an integer from1 to100. Read authoritative sources directly.
```

### malformed cursor

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json inventory --scope current --cursor -1:bad`

Exit 2; 0.053s. Complete stdout / stderr:

```text

STDERR:
usage: repository_intelligence.py [-h] [--root ROOT] --config CONFIG
                                  [--scope {current,history,all}]
                                  [--prefix PREFIX] [--limit LIMIT]
                                  [--cursor CURSOR]
                                  {build,verify,query,inventory,context-for-task,capacity}
                                  [query_text]
repository_intelligence.py: error: argument --cursor: expected one argument
```

### legacy EN query

Command: `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json query requirements quality`

Exit 0; 1.108s. Complete stdout / stderr:

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "requirements quality",
  "status": "candidates-read-sources",
  "owner_candidates": [
    {
      "concern": "independent requirements and acceptance-quality review",
      "path": "CONTRIBUTING.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання"
      ]
    },
    {
      "concern": "independent requirements and acceptance-quality review detailed prompt",
      "path": "agents/reviewers/requirements-acceptance.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання",
        "requirements prompt"
      ]
    }
  ],
  "terms": [],
  "sources": [],
  "artifacts": [
    {
      "path": "CONTRIBUTING.md",
      "kind": "file",
      "purpose": "Canonical issue-to-PR protocol, four independently executed quality-agent roles, requirements quality, test-design handoff, source evidence and closure.",
      "role": "guide",
      "owner": "CONTRIBUTING.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "Contributing"
    },
    {
      "path": "review/REVIEW-TEMPLATE.md",
      "kind": "file",
      "purpose": "Single versioned review format for independent role executions, requirements quality, QA scenarios/oracles, findings and acceptance evidence.",
      "role": "guide",
      "owner": "CONTRIBUTING.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "Issue N — YYYY-MM-DD review / analysis / handoff"
    }
  ],
  "directories": []
}

STDERR:
```

## Independent verdict and expected/observed assessment

No blocking implementation defect found in the bounded executed CLI/operator charter. This is T03/T04 first review, not whole-issue acceptance. Candidate connector-only retrieval is **not observed** because candidate is unpublished; connector direct-owner reads at the base and local candidate map usability do not replace that final-source observation. AC01's actual connector journey remains pending at an addressable commit. AC02 full suites/current final bytes and AC05 policy/trusted delivery remain orchestrator gates. Evidence-placeholder replacement, later handoff and deterministic regeneration must be source-bound; substantive changes need affected re-review.

| Journey / expected | Observed | Disposition |
| --- | --- | --- |
| Map under 32768 bytes; directs owners without catalog | 14272 bytes; short concern/area/instruction/check tables and paging recipes | Executed pass (local operator reading) |
| EN/UA requirements alias routes same canonical owners | Both return CONTRIBUTING.md and agents/reviewers/requirements-acceptance.md; UA owner alias has no lexical hits, but retains both explicit candidates, root AGENTS and check routes | Executed pass; candidates are navigation, not acceptance |
| Exact producer path and editing owner | Only tools/repository_intelligence.py; .github/REPOSITORY-INTELLIGENCE.md owner; root AGENTS + validation routes | Executed pass |
| Directory-only first hit retains metadata | site/engine directory first; editing owners site/README.md and ARTICLE-WORKFLOW; AGENTS and routes remain despite one-hit page | Executed pass |
| History and generated are explicit | History issue189 returns directory/report; docs/writing.html found in all, excluded current with unresolved fallback | Executed pass |
| Pagination nonoverlap, remaining and source binding | Engine pages have offsets0/2, remaining15/13, same source/fingerprint; first rows directory/archive.js then article-print.css/article-tags.cjs; changed scope rejects | Executed pass for first two pages; complete native enumeration not performed here |
| Error and miss treatment | Lexical miss says unresolved-use-direct-search; enginez prefix empty; unsafe prefix/zero limit exit1; malformed negative cursor rejected by argparse exit2 | Executed pass; argparse refusal is a visible usage error, not a successful empty page |
| Whole printed bytes retain metadata | Every parsed scoped raw response response_bytes exactly equals UTF-8 stdout bytes including LF; broad root one-hit response20134 bytes, all owners/instructions/routes retained | Executed pass; native response below advisory threshold |
| Oversized metadata warning | Focused existing response-measurement fixture executed1 test,0.008s,OK; synthetic >65536-byte metadata retained/advised | Executed pass (fixture only) |
| Capacity does not claim integrity | kind capacity-metadata-diagnostic, both integrity/freshness flags false; all five margins; no violations | Executed pass |
| Capacity original bounds and largest text | 2665files;238678837 hash bytes;11321163 spare;21811781 text bytes;largest text1999782 with218 spare | Executed measurement; final receipts will consume some reserve |
| Historical AGENTS safety and byte freshness | Focused existing tests below execute exact-name refusal and serialized/tampered freshness/legacy CLI roundtrip | Executed pass (fixtures only) |

Capacity overlimit fixture was separately executed: `python3 -m unittest discover -s tests -p test_repository_intelligence.py -k capacity_cli_reports_over_limit -v` → `test_capacity_cli_reports_over_limit_without_freshness_claim ... ok`, Ran1 test in0.089s,OK. Existing history-search fixture was separately executed: `-k history_is_searchable` → `test_history_is_searchable_but_not_scoped_agent_instructions ... ok`, Ran1 test in0.010s,OK. Those are bounded supplements, not the orchestrator's92-test campaign or Basic.

Risks examined: implicit history leakage into routine context, owner loss under paging, directory metadata omission, generated/source ambiguity, stale cursor reuse, unsafe paths, false absence inference, response-byte undercount, capacity-vs-integrity confusion, historical live-name instructions and JSON whitespace tampering. No new regression authored. Existing/proposed allocation: the named NavigationSafetyTests methods belong to test_repository_intelligence.py → .github/workflows/navigation.yml and D02 in SITE-CHECK-PROFILES. Connector final-ref walkthrough is manual AC01 pending; no invented browser/device suite. Existing CLI/API compatibility is sampled via native EN unqualified query and fixture roundtrip; this does not claim exhaustive arbitrary-client compatibility.

## Additional executed raw targeted receipts


Command: `python3 -m unittest discover -s tests -p test_repository_intelligence.py -k exact_historical_agents -v`; exit 0.

```text
test_exact_historical_agents_name_cannot_activate_or_be_suppressed (test_repository_intelligence.NavigationSafetyTests.test_exact_historical_agents_name_cannot_activate_or_be_suppressed) ... ok

----------------------------------------------------------------------
Ran 1 test in 0.033s

OK
```

Command: `python3 -m unittest discover -s tests -p test_repository_intelligence.py -k serialized_freshness -v`; exit 0.

```text
test_serialized_freshness_and_actual_cli_round_trip (test_repository_intelligence.NavigationSafetyTests.test_serialized_freshness_and_actual_cli_round_trip) ... ok

----------------------------------------------------------------------
Ran 1 test in 0.310s

OK
```

Final packet candidate/reference byte mismatches: []. Candidate tree remains staged, not committed. Review stops here; no source modifications.
