# Issue 189 T03/T04 — White-box QA first result

**Verdict: changes requested for WB1 (medium).** Six selected existing regression methods passed, and bounded independent guard probes behaved as described below. Directory-only context can omit descendant editing owners and their instruction/check metadata. This is a local T03/T04 review, not whole-AC, delivery or release acceptance.

## Identity and boundary

- Reviewer: distinct nonauthor execution `/root/issue189_t03_whitebox`, first judgment. No implementation/test changes, external writes or delegation. Only this report was written outside ephemeral fixtures.
- Native staged candidate, not a clean committed checkout. Base/HEAD `e4e09f45d014b985568af497e5958cc7eb8e3fab`; inspected staged tree `957b21fde35f701a1d3b64af55daec5b8aa27568`; 14 staged paths.
- Packet `/workspace/scratch/2c34f552b848/issue189-t03/candidate-packet.json`, SHA-256 `285e6c04f15ddd2c6bb4bd23aca5e60abd760c5e1d22771fe4b437b222d99667`. Independently recomputed packet digest and every candidate/reference-file digest: no mismatches.
- Common reviewer contract SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; white-box prompt SHA-256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Producer SHA-256 `4dfd1eb69e722bfd786bd79433d46bed50d820c8b169f10f4032f733b9d1f291`; test file SHA-256 `18e6223040162742a0ad7761bef3715c2d63af30ac87e3fb7d30ec598346cf94`. These remained identical at end of inspection.
- Read supplied owner issue/ACs, README, root AGENTS (map lists no nested scopes), MEMORY as dated handoff, map, relevant CONTRIBUTING/acceptance/test-allocation sections, full reviewer contracts, actual changed producer/tests/config and RI contract. No current peer output or private/parent scratch history read. Provider model/context internals are not observed; shared filesystem is not isolation attestation. GitHub live state was supplied, not independently fetched in this bounded role.

## Finding WB1 — incomplete directory-only owner closure

**Severity: medium; AC01 directory-only owner/instruction/check routing, AC02 live instruction preservation.**

Location: `tools/repository_intelligence.py:604–619`, especially owner collection at 606 and 614 followed by descendant path-only expansion at 609–612. The function expands a matched directory into descendant paths, but does not add those descendants to the rows used for editing owners or add their canonical owner paths to the instruction/check closure. An owner outside the directory, its scoped AGENTS and its owner-specific check disappear from an otherwise advertised complete metadata response.

Independent fixture: a directory `area` has the unique purpose `unique-directory-only-token`; its only content file `area/deep/item.md` is owned by `owner/guide.md`, with live `owner/AGENTS.md`. The directory itself is owned by root AGENTS. Configured routes are `owner/guide.md` → `owner-check`, and lexical family `area/deep/item` → `family-check`. A scoped `context-for-task` query for the unique directory purpose, limit1, returns only the directory as a hit. Observed metadata is:

```json
{"editing_owners":["AGENTS.md"],"instructions":["AGENTS.md"],"validation_routes":[{"commands":["family-check"],"concern":"descendant-family","paths":["area/deep/item"]}]}
```

Expected from complete directory context: descendant editing owner `owner/guide.md`, live `owner/AGENTS.md`, and `owner-check` accompany the already returned family check. No page-size change should be needed to obtain mandatory metadata. The current existing directory-context test assigns every row the same root owner, so it cannot expose this omission.

Treatment: extend directory-context closure to descendant rows and their editing owners before instruction/check selection; retain component boundaries for user filters and lexical prefixes for configured validation families. Have another nonauthor review any authored regression/fix, then rerun affected directory and paging checks. No fix or permanent test was authored here.

## Risk → oracle → route → executed result

All named methods below belong to `tests/test_repository_intelligence.py::NavigationSafetyTests`. Existing route is repository R / `.github/workflows/navigation.yml` / navigation job, step “Check RI inventory and agent-memory contract”; integration remains the orchestrator’s native suite/RI/CI/Basic allocation.

| Risk / AC | Structural fault and scenario | Independent oracle | Existing route / executed result |
| --- | --- | --- | --- |
| Partial paging / AC01 | Continuation loses/duplicates hits or accepts altered request/source | Ordered union of pages equals full `(kind,path)` inventory; changed query/scope/prefix/limit/digest rejects; exact end is empty | `test_paging_parity_and_request_source_bound_continuation`: PASS |
| Mandatory metadata / AC01–02 | A page drops nested instruction or lexical file-family checks | Full matched directory’s live instruction/check set survives limit1; similar sibling excluded | `test_directory_context_is_complete_before_paging_and_routes_keep_families`: PASS; independent external descendant-owner fixture FAILS completeness (WB1) |
| Historical exact instruction name / AC02 | Role or ancestor classification activates/suppresses loose AGENTS | Own or ancestor history/draft/generated refuses; inert rename remains evidence | `test_exact_historical_agents_name_cannot_activate_or_be_suppressed`: PASS; ephemeral guard-removal mutant is detected, below |
| Byte freshness / AC02 | Semantically equal altered output accepted | Added LF and CRLF JSON variants must fail exact serialized-byte comparison | Independent fixture: both refused with “Stale or altered RI context”; PASS |
| Capacity limits / AC04 | Off-by-one bound, wrong derived accounting, advisory promoted to hard gate | Independent byte sums; all five exact bounds accepted and one-over refused by scanner; 10MB advisory threshold separate | `test_capacity_independent_totals_and_all_hard_limit_boundaries`: PASS |
| Unsafe/partial inventory / AC02–04 | Diagnostic claims complete after unreadable/missing/symlink path | Traversal/read failure, symlink and missing tracked source refuse | `test_capacity_refuses_unsafe_missing_and_unreadable_inputs`: PASS |
| Over-limit diagnosis / AC04 | Diagnostic loads prohibited content or claims freshness | Sparse32,000,001-byte input yields complete metadata JSON, hard-limit exit1, no freshness claim; build refuses | `test_capacity_cli_reports_over_limit_without_freshness_claim`: PASS |

## Actual execution and raw observations

Focused command executed from the candidate checkout (stdlib import into an ephemeral module, no bytecode source mutation):

```python
spec = importlib.util.spec_from_file_location('ri_tests', 'tests/test_repository_intelligence.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
names = [
 'test_paging_parity_and_request_source_bound_continuation',
 'test_directory_context_is_complete_before_paging_and_routes_keep_families',
 'test_exact_historical_agents_name_cannot_activate_or_be_suppressed',
 'test_capacity_independent_totals_and_all_hard_limit_boundaries',
 'test_capacity_refuses_unsafe_missing_and_unreadable_inputs',
 'test_capacity_cli_reports_over_limit_without_freshness_claim',
]
unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(m.NavigationSafetyTests(n) for n in names))
```

Raw result: `Ran 6 tests in 0.218s`, `OK`; execution count6, failures0, errors0, skips0; enclosing Python exit0. Internal capacity CLI one-over expected exit1 and build refusal were asserted by the test. Full92-suite/Basic were intentionally not duplicated.

Independent temporary-fixture probe executed against the imported candidate producer, exit0:

```text
BYTE_TAMPER_REJECT Stale or altered RI context; rebuild or use direct repository reading
BYTE_TAMPER_REJECT Stale or altered RI context; rebuild or use direct repository reading
DIRECTORY_ONLY_RESULT {"artifacts": [], "directories": [{"instructions": ["AGENTS.md"], "kind": "directory", "owner": "AGENTS.md", "path": "area", "purpose": "unique-directory-only-token", "role": "source"}], "editing_owners": ["AGENTS.md"], "instructions": ["AGENTS.md"], "validation_routes": [{"commands": ["family-check"], "concern": "descendant-family", "paths": ["area/deep/item"]}]}
GUARD_BASELINE_REJECT Historical/generated AGENTS.md must use an inert archive name: archive/AGENTS.md
GUARD_MUTANT_DETECTED archive/AGENTS.md activated when guard removed
```

Fault probe replaced only the exact historical-ancestor `if any(not in_scope(entries[p], "current") for p in ancestors):` condition with `if False:` in an in-memory compiled copy; no repository bytes changed. Fixture `archive/AGENTS.md` under a history ancestor was rejected by baseline, then appeared in mutant instructions. This demonstrates assertion sensitivity for that guard, not a measured mutation score or branch coverage.

## Limits and disposition

- No measured statement/branch coverage. Source inspection covered row scope/filtering, prepage metadata closure, response accounting, cursor validation, scan/tracked-input admission, deterministic output comparison, historical instruction guard, and all capacity bound branches. Not every OS/concurrency failure branch was injected.
- No browser/UI surface was introduced by this local CLI change; hosted delivery, connector-only user journey and public/media recovery were not executed by this role. No live GitHub/CI status, wholeAC, clean-commit or production acceptance claim.
- Source analyses and existing tests do not prove final input headroom after report/evidence replacement. Placeholder TAR, literal receipts/MEMORY and deterministic RI refresh remain later delta; substantive fixes need affected re-review. AC03 archival eligibility/recovery remains outside this T03/T04 bounded review.
- WB1 should be resolved before accepting complete directory-only metadata. Other executed focused checks have no observed failure. Full-suite/integration/final-source evidence remains owned by the orchestrator.
