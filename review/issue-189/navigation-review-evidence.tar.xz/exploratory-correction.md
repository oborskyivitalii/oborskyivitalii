# Exploratory / Interaction QA — correction

Same handle /root/issue189_t03_exploratory, affected continuation after first judgments/reconciliation, not a fresh first judgment. First report is preserved. Correction facts disclosed: external descendant-owner closure was missing; config formatting restored. Inspected primary packet/diff/retained failing and fixed probe, not current peer reports. No source/accepted test/external writes/delegation. Five-minute bound.

Base e4e09f45d014b985568af497e5958cc7eb8e3fab; staged native tree 859b408a26ce30a51820f0af9a79fd803c55d0c2, not a clean committed source. Packet SHA256 9629b4e8175739a404abc97e1f3f152b715635ba39e3d6e2b77e989ffb098ffb; first report SHA256 e81d6183724e283929c58eeabb47269e8e96ca296082ce6861e4ecb06c40f7b4. Candidate packet hash mismatches []. Common prompt 2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb; role prompt 280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a.

## Retained reviewer-harness first failure

First attempted comparison run successfully executed nine CLI commands: native directory p1/p2, legacy, EN/UA aliases and temporary fixture directory scoped/legacy/inventory p1/p2, all exit0. The Python aggregation then failed `KeyError: 'editing_owners'` while comparing legacy CLI to scoped CLI. That first run emitted only command exits and its aggregation traceback, so no discarded stdout is claimed as retained evidence. It wrote no report. Diagnosis from tools/repository_intelligence.py lines798–804: unqualified context CLI deliberately pops editing_owners for legacy shape; it still returns instructions/routes. This was a reviewer oracle error, not a producer failure. The bounded follow-up below retains every stdout immediately and compares only the legacy metadata fields actually promised (instructions/routes); scoped owner presence is checked separately. No source correction or unchanged suite retry.

## Executed raw receipts

### native current directory p1

`python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task site/engine --scope current --limit 1`

Exit 0; 0.972s.

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "site/engine",
  "status": "candidates-read-sources",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [
    {
      "path": "site/engine",
      "kind": "directory",
      "purpose": "Shared Canvas geometry/lifecycle, renderer, native-scroll router, theme, filters and CSS.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "editing_owners": [
    "guides/ARTICLE-WORKFLOW.md",
    "site/README.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "entry points, maintained guides and preserved root history",
      "paths": [
        "PROJECT-BOOTSTRAP.md",
        ".github/repository-layout.json",
        "guides/",
        "review/root-history-20261007/",
        "tools/check_repository_layout.py",
        "tests/test_root_layout.py",
        "tools/run_repository_tests.py",
        "tests/test_repository_test_selection.py"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_root_layout.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_test_selection.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Permanent contracts validate current routes and archive identities; frozen public/history snapshots belong only to the selected issue policy."
    },
    {
      "concern": "authored site and generated output",
      "paths": [
        "site/",
        "docs/",
        "tools/site/"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "workflow": ".github/workflows/site-checks.yml"
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "authored article publisher and Writing reader",
      "paths": [
        "site/publications/",
        "site/article-preview.json",
        "site/assets/publications/",
        "tools/publishing/",
        "tools/site/articles.cjs",
        "tests/publishing",
        "tests/site-articles.test.cjs",
        "tests/article-",
        "guides/ARTICLE-WORKFLOW.md",
        "tests/test_issue5_acceptance.py",
        ".github/acceptance/issue-5.json",
        "tools/site/offline.cjs",
        "tools/site/standalone.cjs",
        "tools/quality/candidate-source.cjs",
        "tools/quality/article-browser.cjs",
        "tests/local-catalog-relationships.test.cjs",
        "tests/site-transaction.test.cjs"
      ],
      "commands": [
        "node --test tests/publishing.test.cjs tests/publishing-history.test.cjs tests/publishing-profile.test.cjs tests/publishing-safety.test.cjs tests/publishing-print.test.cjs",
        "node --test tests/site-articles.test.cjs tests/site-transaction.test.cjs tests/article-offline.test.cjs tests/local-catalog-relationships.test.cjs tests/article-budgets.test.cjs tests/article-browser-evidence.test.cjs tests/article-candidate-source.test.cjs tests/article-delivery.test.cjs",
        "python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-5.json --report /tmp/issue-5-acceptance.json"
      ],
      "read": [
        "guides/ARTICLE-WORKFLOW.md",
        "site/README.md",
        "guides/SITE-CHECK-PROFILES.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Prepare the locked build-only toolchain before selected source checks. Actual PDF/native-editor/browser/rights/publication evidence and controller promotion remain separate; this route does not publish."
    },
    {
      "concern": "production preparation, canonical Pages migration and release-bound rights inventory",
      "paths": [
        "LICENSING.md",
        "LICENSE-CODE.md",
        "LICENSE-CONTENT.md",
        "NOTICE.md",
        "site/content/production-social.json",
        "site/rights.json",
        "tools/pages/",
        "tools/release/",
        "tools/site/edition-retention.cjs",
        "tools/site/legal.cjs",
        "site/templates/components/legal-notices.html",
        "tools/check_site_seo.cjs",
        "tests/executive.test.cjs",
        "tests/site-engine.test.cjs",
        "site/content/pages/credits/main.json",
        "site/templates/pages/credits/main.html",
        "site/engine/styles.css",
        "docs/styles.css",
        "tests/edition-retention.test.cjs",
        "tests/pages-migration.test.cjs",
        "tests/release-rights.test.cjs",
        ".github/workflows/site-pages-migration.yml",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md"
      ],
      "commands": [
        "node --test tests/executive.test.cjs tests/site-engine.test.cjs tests/edition-retention.test.cjs tests/pages-migration.test.cjs tests/release-rights.test.cjs tests/release-controller.test.cjs tests/release-archive.test.cjs",
        "node tools/quality/local.cjs"
      ],
      "read": [
        "LICENSING.md",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md",
        "guides/SITE-RELEASE-GATES.md"
      ],
      "workflow": ".github/workflows/site-checks.yml",
      "note": "Changed-source tests are selected through test-profiles.json; issue39 selects its source-bound implementation checks. Fixtures cannot supply maintainer reuse-policy or rights decisions, protected settings, actual domain migration, device acceptance or publication approval."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "d5291e772269de8df038355656f2b65370354fe5ce5dedbecfca91b2e57a5e25",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 17,
    "returned": 1,
    "remaining": 16,
    "request_fingerprint": "6f6e6b2f11f6f467e6f9d72d1866c53bafe7ba665ac3e98a49e68be408f64f7a",
    "next_cursor": "1:6f6e6b2f11f6f467e6f9d72d1866c53bafe7ba665ac3e98a49e68be408f64f7a"
  },
  "response_bytes": 6910,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### native current directory p2

`python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task site/engine --scope current --limit 1 --cursor 1:6f6e6b2f11f6f467e6f9d72d1866c53bafe7ba665ac3e98a49e68be408f64f7a`

Exit 0; 0.917s.

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "site/engine",
  "status": "candidates-read-sources",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [
    {
      "path": "site/engine/archive.js",
      "kind": "file",
      "purpose": "Accessible Writing topic filters, curated publication rendering and reflow.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "archive.js"
    }
  ],
  "directories": [],
  "editing_owners": [
    "guides/ARTICLE-WORKFLOW.md",
    "site/README.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "entry points, maintained guides and preserved root history",
      "paths": [
        "PROJECT-BOOTSTRAP.md",
        ".github/repository-layout.json",
        "guides/",
        "review/root-history-20261007/",
        "tools/check_repository_layout.py",
        "tests/test_root_layout.py",
        "tools/run_repository_tests.py",
        "tests/test_repository_test_selection.py"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_root_layout.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_test_selection.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Permanent contracts validate current routes and archive identities; frozen public/history snapshots belong only to the selected issue policy."
    },
    {
      "concern": "authored site and generated output",
      "paths": [
        "site/",
        "docs/",
        "tools/site/"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "workflow": ".github/workflows/site-checks.yml"
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "authored article publisher and Writing reader",
      "paths": [
        "site/publications/",
        "site/article-preview.json",
        "site/assets/publications/",
        "tools/publishing/",
        "tools/site/articles.cjs",
        "tests/publishing",
        "tests/site-articles.test.cjs",
        "tests/article-",
        "guides/ARTICLE-WORKFLOW.md",
        "tests/test_issue5_acceptance.py",
        ".github/acceptance/issue-5.json",
        "tools/site/offline.cjs",
        "tools/site/standalone.cjs",
        "tools/quality/candidate-source.cjs",
        "tools/quality/article-browser.cjs",
        "tests/local-catalog-relationships.test.cjs",
        "tests/site-transaction.test.cjs"
      ],
      "commands": [
        "node --test tests/publishing.test.cjs tests/publishing-history.test.cjs tests/publishing-profile.test.cjs tests/publishing-safety.test.cjs tests/publishing-print.test.cjs",
        "node --test tests/site-articles.test.cjs tests/site-transaction.test.cjs tests/article-offline.test.cjs tests/local-catalog-relationships.test.cjs tests/article-budgets.test.cjs tests/article-browser-evidence.test.cjs tests/article-candidate-source.test.cjs tests/article-delivery.test.cjs",
        "python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-5.json --report /tmp/issue-5-acceptance.json"
      ],
      "read": [
        "guides/ARTICLE-WORKFLOW.md",
        "site/README.md",
        "guides/SITE-CHECK-PROFILES.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Prepare the locked build-only toolchain before selected source checks. Actual PDF/native-editor/browser/rights/publication evidence and controller promotion remain separate; this route does not publish."
    },
    {
      "concern": "production preparation, canonical Pages migration and release-bound rights inventory",
      "paths": [
        "LICENSING.md",
        "LICENSE-CODE.md",
        "LICENSE-CONTENT.md",
        "NOTICE.md",
        "site/content/production-social.json",
        "site/rights.json",
        "tools/pages/",
        "tools/release/",
        "tools/site/edition-retention.cjs",
        "tools/site/legal.cjs",
        "site/templates/components/legal-notices.html",
        "tools/check_site_seo.cjs",
        "tests/executive.test.cjs",
        "tests/site-engine.test.cjs",
        "site/content/pages/credits/main.json",
        "site/templates/pages/credits/main.html",
        "site/engine/styles.css",
        "docs/styles.css",
        "tests/edition-retention.test.cjs",
        "tests/pages-migration.test.cjs",
        "tests/release-rights.test.cjs",
        ".github/workflows/site-pages-migration.yml",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md"
      ],
      "commands": [
        "node --test tests/executive.test.cjs tests/site-engine.test.cjs tests/edition-retention.test.cjs tests/pages-migration.test.cjs tests/release-rights.test.cjs tests/release-controller.test.cjs tests/release-archive.test.cjs",
        "node tools/quality/local.cjs"
      ],
      "read": [
        "LICENSING.md",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md",
        "guides/SITE-RELEASE-GATES.md"
      ],
      "workflow": ".github/workflows/site-checks.yml",
      "note": "Changed-source tests are selected through test-profiles.json; issue39 selects its source-bound implementation checks. Fixtures cannot supply maintainer reuse-policy or rights decisions, protected settings, actual domain migration, device acceptance or publication approval."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "d5291e772269de8df038355656f2b65370354fe5ce5dedbecfca91b2e57a5e25",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 1,
    "total": 17,
    "returned": 1,
    "remaining": 15,
    "request_fingerprint": "6f6e6b2f11f6f467e6f9d72d1866c53bafe7ba665ac3e98a49e68be408f64f7a",
    "next_cursor": "2:6f6e6b2f11f6f467e6f9d72d1866c53bafe7ba665ac3e98a49e68be408f64f7a"
  },
  "response_bytes": 6931,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### native legacy directory

`python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task site/engine`

Exit 0; 0.998s.

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "site/engine",
  "status": "candidates-read-sources",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [
    {
      "path": "site/engine/archive.js",
      "kind": "file",
      "purpose": "Accessible Writing topic filters, curated publication rendering and reflow.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "archive.js"
    },
    {
      "path": "site/engine/article-print.css",
      "kind": "file",
      "purpose": "Canonical readable publication print stylesheet consumed by the isolated print adapter.",
      "role": "source",
      "owner": "guides/ARTICLE-WORKFLOW.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "article-print.css"
    },
    {
      "path": "site/engine/article-tags.cjs",
      "kind": "file",
      "role": "source",
      "owner": "site/README.md",
      "purpose": "Shared canonical publication tags, independently updated index, bounded runtime recommendations and verification.",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "article-tags.cjs"
    },
    {
      "path": "site/engine/critical-media.css",
      "kind": "file",
      "purpose": "Single authored responsive portrait rule; generated Home fallback and ordinary stylesheet preserve the same CSS bytes and normal selector order.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "critical-media.css"
    },
    {
      "path": "site/engine/lifecycle.cjs",
      "kind": "file",
      "purpose": "Single scene lifecycle/RAF, displayed-phase freeze and native-scroll progress.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "lifecycle.cjs"
    },
    {
      "path": "site/engine/math.cjs",
      "kind": "file",
      "purpose": "Pure finite vector and transform math used by world projection.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "math.cjs"
    },
    {
      "path": "site/engine/navigation.js",
      "kind": "file",
      "purpose": "Persistent header/Canvas route mounting, exact pinned snapshots and history fallback.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "navigation.js"
    },
    {
      "path": "site/engine/projection.cjs",
      "kind": "file",
      "purpose": "Camera/depth projection and visibility/detail calculations.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "projection.cjs"
    },
    {
      "path": "site/engine/reader.cjs",
      "kind": "file",
      "purpose": "Optional reusable reader lifecycle: contents, note disclosure, history and print state; no new clock.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "reader.cjs"
    },
    {
      "path": "site/engine/reader.css",
      "kind": "file",
      "purpose": "Canonical reusable reader layout, typography and table/code/figure/reference component styles.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "reader.css"
    },
    {
      "path": "site/engine/reading-surfaces.css",
      "kind": "file",
      "purpose": "Single authored reading-backdrop paint: shared paper, opacity, crisp edges, outer corners and paint-only placement across routes and renditions.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "reading-surfaces.css"
    },
    {
      "path": "site/engine/renderer.cjs",
      "kind": "file",
      "purpose": "Ordered Canvas commands, projected facets, adjacent-line batching and exact per-paint state deduplication with custom/formula invalidation.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "renderer.cjs"
    },
    {
      "path": "site/engine/scroll-entry.cjs",
      "kind": "file",
      "purpose": "Bounded native reading and route-block controller with one global effect control, stable shells, CSS layers, cancellation and visible fallback. Issue122 T03-R uses post-cleanup per-batch geometry/focus and behavioral read/write-order, fresh-event and forward-queue regressions.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "scroll-entry.cjs"
    },
    {
      "path": "site/engine/scroll-entry.css",
      "kind": "file",
      "purpose": "Canonical global block-motion configuration, opaque reading/route keyframes and responsive reading distance shared by hosted/base/Color/offline.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "scroll-entry.css"
    },
    {
      "path": "site/engine/styles.css",
      "kind": "file",
      "purpose": "Shared responsive presentation, reading surfaces, controls and theme contrast.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "styles.css"
    },
    {
      "path": "site/engine/theme.js",
      "kind": "file",
      "purpose": "Persisted Day/Night theme and lifecycle-safe repaint notifications.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "theme.js"
    }
  ],
  "directories": [
    {
      "path": "site/engine",
      "kind": "directory",
      "purpose": "Shared Canvas geometry/lifecycle, renderer, native-scroll router, theme, filters and CSS.",
      "role": "source",
      "owner": "site/README.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "entry points, maintained guides and preserved root history",
      "paths": [
        "PROJECT-BOOTSTRAP.md",
        ".github/repository-layout.json",
        "guides/",
        "review/root-history-20261007/",
        "tools/check_repository_layout.py",
        "tests/test_root_layout.py",
        "tools/run_repository_tests.py",
        "tests/test_repository_test_selection.py"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_root_layout.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_test_selection.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Permanent contracts validate current routes and archive identities; frozen public/history snapshots belong only to the selected issue policy."
    },
    {
      "concern": "authored site and generated output",
      "paths": [
        "site/",
        "docs/",
        "tools/site/"
      ],
      "commands": [
        "node tools/quality/local.cjs"
      ],
      "workflow": ".github/workflows/site-checks.yml"
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "authored article publisher and Writing reader",
      "paths": [
        "site/publications/",
        "site/article-preview.json",
        "site/assets/publications/",
        "tools/publishing/",
        "tools/site/articles.cjs",
        "tests/publishing",
        "tests/site-articles.test.cjs",
        "tests/article-",
        "guides/ARTICLE-WORKFLOW.md",
        "tests/test_issue5_acceptance.py",
        ".github/acceptance/issue-5.json",
        "tools/site/offline.cjs",
        "tools/site/standalone.cjs",
        "tools/quality/candidate-source.cjs",
        "tools/quality/article-browser.cjs",
        "tests/local-catalog-relationships.test.cjs",
        "tests/site-transaction.test.cjs"
      ],
      "commands": [
        "node --test tests/publishing.test.cjs tests/publishing-history.test.cjs tests/publishing-profile.test.cjs tests/publishing-safety.test.cjs tests/publishing-print.test.cjs",
        "node --test tests/site-articles.test.cjs tests/site-transaction.test.cjs tests/article-offline.test.cjs tests/local-catalog-relationships.test.cjs tests/article-budgets.test.cjs tests/article-browser-evidence.test.cjs tests/article-candidate-source.test.cjs tests/article-delivery.test.cjs",
        "python3 tools/issue_acceptance.py run --policy .github/acceptance/issue-5.json --report /tmp/issue-5-acceptance.json"
      ],
      "read": [
        "guides/ARTICLE-WORKFLOW.md",
        "site/README.md",
        "guides/SITE-CHECK-PROFILES.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Prepare the locked build-only toolchain before selected source checks. Actual PDF/native-editor/browser/rights/publication evidence and controller promotion remain separate; this route does not publish."
    },
    {
      "concern": "production preparation, canonical Pages migration and release-bound rights inventory",
      "paths": [
        "LICENSING.md",
        "LICENSE-CODE.md",
        "LICENSE-CONTENT.md",
        "NOTICE.md",
        "site/content/production-social.json",
        "site/rights.json",
        "tools/pages/",
        "tools/release/",
        "tools/site/edition-retention.cjs",
        "tools/site/legal.cjs",
        "site/templates/components/legal-notices.html",
        "tools/check_site_seo.cjs",
        "tests/executive.test.cjs",
        "tests/site-engine.test.cjs",
        "site/content/pages/credits/main.json",
        "site/templates/pages/credits/main.html",
        "site/engine/styles.css",
        "docs/styles.css",
        "tests/edition-retention.test.cjs",
        "tests/pages-migration.test.cjs",
        "tests/release-rights.test.cjs",
        ".github/workflows/site-pages-migration.yml",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md"
      ],
      "commands": [
        "node --test tests/executive.test.cjs tests/site-engine.test.cjs tests/edition-retention.test.cjs tests/pages-migration.test.cjs tests/release-rights.test.cjs tests/release-controller.test.cjs tests/release-archive.test.cjs",
        "node tools/quality/local.cjs"
      ],
      "read": [
        "LICENSING.md",
        "guides/SITE-PRODUCTION.md",
        "guides/SITE-RIGHTS.md",
        "guides/SITE-RELEASE-GATES.md"
      ],
      "workflow": ".github/workflows/site-checks.yml",
      "note": "Changed-source tests are selected through test-profiles.json; issue39 selects its source-bound implementation checks. Fixtures cannot supply maintainer reuse-policy or rights decisions, protected settings, actual domain migration, device acceptance or publication approval."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state."
}

STDERR:
```

### native EN alias

`python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task requirements quality --scope current --limit 1`

Exit 0; 0.996s.

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "requirements quality",
  "status": "candidates-read-sources",
  "owner_candidates": [
    {
      "concern": "independent requirements and acceptance-quality review",
      "path": "CONTRIBUTING.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання"
      ]
    },
    {
      "concern": "independent requirements and acceptance-quality review detailed prompt",
      "path": "agents/reviewers/requirements-acceptance.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання",
        "requirements prompt"
      ]
    }
  ],
  "terms": [],
  "sources": [],
  "artifacts": [
    {
      "path": "CONTRIBUTING.md",
      "kind": "file",
      "purpose": "Canonical issue-to-PR protocol, four independently executed quality-agent roles, requirements quality, test-design handoff, source evidence and closure.",
      "role": "guide",
      "owner": "CONTRIBUTING.md",
      "instructions": [
        "AGENTS.md"
      ],
      "title": "Contributing"
    }
  ],
  "directories": [],
  "editing_owners": [
    "CONTRIBUTING.md"
  ],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "repository intelligence and continuity",
      "paths": [
        "AGENTS.md",
        "MEMORY.md",
        "CONTRIBUTING.md",
        "README.md",
        "guides/REPOSITORIES.md",
        "REPOSITORY-MAP.md",
        ".github/repository-",
        ".github/REPOSITORY-INTELLIGENCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "tools/repository_intelligence.py",
        "tests/test_repository_intelligence.py",
        ".github/ri-ci-map.json",
        "tools/check_ri_ci.py",
        "tests/test_ri_ci.py",
        "PROJECT-BOOTSTRAP.md",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_ri_ci.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json build",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify"
      ],
      "workflow": ".github/workflows/navigation.yml"
    },
    {
      "concern": "independent quality-agent protocol and risk-to-test handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        "tools/quality/source-tests.cjs",
        "tests/test_repository_intelligence.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/check_ri_ci.py verify"
      ],
      "read": [
        "CONTRIBUTING.md",
        "agents/reviewers/README.md",
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        ".github/workflows/issue-acceptance.yml"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Follow CONTRIBUTING.md#independent-quality-agents for separately launched Requirements/Acceptance Reviewer, Code Reviewer, White-box QA and Exploratory/Interaction QA. These commands verify navigation and CI coupling, not agent execution or acceptance. Map findings and test dispositions to the live owning issue, existing profile registry and its acceptance policy; retain actual role results and manual limits in the review artifact."
    },
    {
      "concern": "issue acceptance and anchored analysis/review handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/acceptance/",
        ".github/workflows/issue-acceptance.yml",
        "tools/issue_acceptance.py",
        "tests/test_issue_acceptance.py",
        "tests/test_issue31_acceptance.py",
        "review/REVIEW-TEMPLATE.md",
        "review/issue-",
        "PROJECT-BOOTSTRAP.md",
        "tests/test_issue33_acceptance.py",
        "tests/test_issue35_acceptance.py",
        "tests/test_issue36_acceptance.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/issue_acceptance.py --help"
      ],
      "read": [
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Help only describes invocation; it is not an acceptance check. Revalidate the live owning issue and select its policy from the PR's single Refs line or explicit dispatch issue, following ACCEPTANCE.md for exact-source execution. Historical policies do not select current work. Automated assertions cannot supply independent role execution/review, observed hosted timing, owner/device acceptance, merge or live GitHub linkage."
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "detailed reviewer prompt requirements-acceptance",
      "paths": [
        "agents/reviewers/requirements-acceptance.md"
      ],
      "read": [
        "agents/reviewers/README.md",
        "agents/reviewers/requirements-acceptance.md",
        "CONTRIBUTING.md"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read the common contract and this single role prompt for a role launch; navigation checks do not establish reviewer execution."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "d5291e772269de8df038355656f2b65370354fe5ce5dedbecfca91b2e57a5e25",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 2,
    "returned": 1,
    "remaining": 1,
    "request_fingerprint": "52e211aaba2ad91865cb1985fa23dc0c8c99a36c478d151e680c7646cca8a2fa",
    "next_cursor": "1:52e211aaba2ad91865cb1985fa23dc0c8c99a36c478d151e680c7646cca8a2fa"
  },
  "response_bytes": 7790,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### native UA alias

`python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json context-for-task якість вимог --scope current --limit 1`

Exit 0; 0.915s.

```text
{
  "repository": "oborskyivitalii/oborskyivitalii",
  "query": "якість вимог",
  "status": "candidates-read-sources",
  "owner_candidates": [
    {
      "concern": "independent requirements and acceptance-quality review",
      "path": "CONTRIBUTING.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання"
      ]
    },
    {
      "concern": "independent requirements and acceptance-quality review detailed prompt",
      "path": "agents/reviewers/requirements-acceptance.md",
      "queries": [
        "requirements reviewer",
        "requirements review",
        "requirements quality",
        "acceptance quality",
        "якість вимог",
        "перевірка вимог",
        "якість критеріїв приймання",
        "requirements prompt"
      ]
    }
  ],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [],
  "editing_owners": [],
  "instructions": [
    "AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "repository intelligence and continuity",
      "paths": [
        "AGENTS.md",
        "MEMORY.md",
        "CONTRIBUTING.md",
        "README.md",
        "guides/REPOSITORIES.md",
        "REPOSITORY-MAP.md",
        ".github/repository-",
        ".github/REPOSITORY-INTELLIGENCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "tools/repository_intelligence.py",
        "tests/test_repository_intelligence.py",
        ".github/ri-ci-map.json",
        "tools/check_ri_ci.py",
        "tests/test_ri_ci.py",
        "PROJECT-BOOTSTRAP.md",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_ri_ci.py'",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json build",
        "python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify"
      ],
      "workflow": ".github/workflows/navigation.yml"
    },
    {
      "concern": "independent quality-agent protocol and risk-to-test handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/ISSUE_TEMPLATE/",
        ".github/pull_request_template.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        "tools/quality/source-tests.cjs",
        "tests/test_repository_intelligence.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'",
        "python3 tools/check_ri_ci.py verify"
      ],
      "read": [
        "CONTRIBUTING.md",
        "agents/reviewers/README.md",
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md",
        "guides/SITE-CHECK-PROFILES.md",
        "tools/quality/test-profiles.json",
        ".github/workflows/issue-acceptance.yml"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Follow CONTRIBUTING.md#independent-quality-agents for separately launched Requirements/Acceptance Reviewer, Code Reviewer, White-box QA and Exploratory/Interaction QA. These commands verify navigation and CI coupling, not agent execution or acceptance. Map findings and test dispositions to the live owning issue, existing profile registry and its acceptance policy; retain actual role results and manual limits in the review artifact."
    },
    {
      "concern": "issue acceptance and anchored analysis/review handoff",
      "paths": [
        "AGENTS.md",
        "CONTRIBUTING.md",
        ".github/ACCEPTANCE.md",
        ".github/acceptance/",
        ".github/workflows/issue-acceptance.yml",
        "tools/issue_acceptance.py",
        "tests/test_issue_acceptance.py",
        "tests/test_issue31_acceptance.py",
        "review/REVIEW-TEMPLATE.md",
        "review/issue-",
        "PROJECT-BOOTSTRAP.md",
        "tests/test_issue33_acceptance.py",
        "tests/test_issue35_acceptance.py",
        "tests/test_issue36_acceptance.py",
        "agents/reviewers/"
      ],
      "commands": [
        "python3 tools/issue_acceptance.py --help"
      ],
      "read": [
        ".github/ACCEPTANCE.md",
        "review/REVIEW-TEMPLATE.md"
      ],
      "workflow": ".github/workflows/issue-acceptance.yml",
      "note": "Help only describes invocation; it is not an acceptance check. Revalidate the live owning issue and select its policy from the PR's single Refs line or explicit dispatch issue, following ACCEPTANCE.md for exact-source execution. Historical policies do not select current work. Automated assertions cannot supply independent role execution/review, observed hosted timing, owner/device acceptance, merge or live GitHub linkage."
    },
    {
      "concern": "mandatory code style and bounded source architecture guard",
      "paths": [
        "site/",
        "tools/",
        "tests/",
        ".github/",
        "AGENTS.md",
        "CONTRIBUTING.md",
        "guides/CODE-STYLE.md",
        "review/site-scroll-sync-20261004/"
      ],
      "commands": [
        "python3 tools/check_code_style.py",
        "python3 -m unittest discover -s tests -p 'test_code_style.py'"
      ],
      "read": [
        "guides/CODE-STYLE.md"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read and follow applicable CS rules before code/template/style/config edits; map them to an issue AC and PR evidence. Guard success establishes only its stated subset; review unautomated rules and exact legacy allowances. This route does not authorize refactoring historical artifacts."
    },
    {
      "concern": "detailed reviewer prompt requirements-acceptance",
      "paths": [
        "agents/reviewers/requirements-acceptance.md"
      ],
      "read": [
        "agents/reviewers/README.md",
        "agents/reviewers/requirements-acceptance.md",
        "CONTRIBUTING.md"
      ],
      "commands": [
        "python3 tools/check_ri_ci.py verify",
        "python3 -m unittest discover -s tests -p 'test_repository_intelligence.py'"
      ],
      "workflow": ".github/workflows/navigation.yml",
      "note": "Read the common contract and this single role prompt for a role launch; navigation checks do not establish reviewer execution."
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "d5291e772269de8df038355656f2b65370354fe5ce5dedbecfca91b2e57a5e25",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 0,
    "returned": 0,
    "remaining": 0,
    "request_fingerprint": "a69acec90494a0e81ddd1d4621a98af5a6872839bc62a1c6783c3dbba29d2c57",
    "next_cursor": null
  },
  "response_bytes": 7321,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### fixture actual CLI sole-directory current

`python3 /workspace/scratch/2c34f552b848/issue189-checkout/tools/repository_intelligence.py --root /tmp/tmp5i1f95j0 --config governance/config.json context-for-task qax_directory_unique --scope current --limit 1`

Exit 0; 0.049s.

```text
{
  "repository": "example/research",
  "query": "qax_directory_unique",
  "status": "candidates-read-sources",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [
    {
      "path": "area",
      "kind": "directory",
      "purpose": "qax_directory_unique",
      "role": "source",
      "owner": "AGENTS.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "editing_owners": [
    "AGENTS.md",
    "owners/canonical.md"
  ],
  "instructions": [
    "AGENTS.md",
    "owners/AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "external owner check",
      "paths": [
        "owners/canonical.md"
      ],
      "commands": [
        "owner-check"
      ]
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": null,
  "source_digest": "8fdb737610c9eaaf48eedb927ccced1a28ad313c6c08cd31f21a7886d95df83e",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 1,
    "returned": 1,
    "remaining": 0,
    "request_fingerprint": "5973d118f1bae14a596d31db38a4e97b672b2e6867dab57ca604dd6c114a4035",
    "next_cursor": null
  },
  "response_bytes": 1335,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### fixture actual CLI sole-directory legacy

`python3 /workspace/scratch/2c34f552b848/issue189-checkout/tools/repository_intelligence.py --root /tmp/tmp5i1f95j0 --config governance/config.json context-for-task qax_directory_unique`

Exit 0; 0.048s.

```text
{
  "repository": "example/research",
  "query": "qax_directory_unique",
  "status": "candidates-read-sources",
  "owner_candidates": [],
  "terms": [],
  "sources": [],
  "artifacts": [],
  "directories": [
    {
      "path": "area",
      "kind": "directory",
      "purpose": "qax_directory_unique",
      "role": "source",
      "owner": "AGENTS.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "instructions": [
    "AGENTS.md",
    "owners/AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "external owner check",
      "paths": [
        "owners/canonical.md"
      ],
      "commands": [
        "owner-check"
      ]
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state."
}

STDERR:
```

### fixture actual CLI inventory p1

`python3 /workspace/scratch/2c34f552b848/issue189-checkout/tools/repository_intelligence.py --root /tmp/tmp5i1f95j0 --config governance/config.json inventory --scope current --prefix area --limit 1`

Exit 0; 0.05s.

```text
{
  "repository": "example/research",
  "files": [],
  "directories": [
    {
      "path": "area",
      "kind": "directory",
      "purpose": "qax_directory_unique",
      "role": "source",
      "owner": "AGENTS.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "editing_owners": [
    "AGENTS.md",
    "owners/canonical.md"
  ],
  "instructions": [
    "AGENTS.md",
    "owners/AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "external owner check",
      "paths": [
        "owners/canonical.md"
      ],
      "commands": [
        "owner-check"
      ]
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": "area",
  "source_digest": "8fdb737610c9eaaf48eedb927ccced1a28ad313c6c08cd31f21a7886d95df83e",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 0,
    "total": 3,
    "returned": 1,
    "remaining": 2,
    "request_fingerprint": "8c1cea4a7aed790b6d0bd59e3a0691a2b952bdd80975d3fcf2021b18308b77e6",
    "next_cursor": "1:8c1cea4a7aed790b6d0bd59e3a0691a2b952bdd80975d3fcf2021b18308b77e6"
  },
  "response_bytes": 1265,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### fixture actual CLI inventory p2

`python3 /workspace/scratch/2c34f552b848/issue189-checkout/tools/repository_intelligence.py --root /tmp/tmp5i1f95j0 --config governance/config.json inventory --scope current --prefix area --limit 1 --cursor 1:8c1cea4a7aed790b6d0bd59e3a0691a2b952bdd80975d3fcf2021b18308b77e6`

Exit 0; 0.053s.

```text
{
  "repository": "example/research",
  "files": [],
  "directories": [
    {
      "path": "area/deep",
      "kind": "directory",
      "purpose": "Fixture purpose: area/deep",
      "role": "source",
      "owner": "AGENTS.md",
      "instructions": [
        "AGENTS.md"
      ]
    }
  ],
  "editing_owners": [
    "AGENTS.md",
    "owners/canonical.md"
  ],
  "instructions": [
    "AGENTS.md",
    "owners/AGENTS.md"
  ],
  "validation_routes": [
    {
      "concern": "external owner check",
      "paths": [
        "owners/canonical.md"
      ],
      "commands": [
        "owner-check"
      ]
    }
  ],
  "note": "Read owners; commands are suggestions, not executed checks. Revalidate live issue/PR state.",
  "scope": "current",
  "prefix": "area",
  "source_digest": "8fdb737610c9eaaf48eedb927ccced1a28ad313c6c08cd31f21a7886d95df83e",
  "pagination": {
    "order": "kind,path",
    "limit": 1,
    "offset": 1,
    "total": 3,
    "returned": 1,
    "remaining": 1,
    "request_fingerprint": "8c1cea4a7aed790b6d0bd59e3a0691a2b952bdd80975d3fcf2021b18308b77e6",
    "next_cursor": "2:8c1cea4a7aed790b6d0bd59e3a0691a2b952bdd80975d3fcf2021b18308b77e6"
  },
  "response_bytes": 1276,
  "response_advisory_threshold_bytes": 65536,
  "response_advisory": "none"
}

STDERR:
```

### permanent affected regression

`python3 -m unittest discover -s tests -p test_repository_intelligence.py -k directory_only_context_keeps_external -v`

Exit 0; 0.096s.

```text

STDERR:
test_directory_only_context_keeps_external_descendant_owner_instructions_and_checks (test_repository_intelligence.NavigationSafetyTests.test_directory_only_context_keeps_external_descendant_owner_instructions_and_checks) ... ok

----------------------------------------------------------------------
Ran 1 test in 0.008s

OK
```

## Verdict and expectation comparison

Affected correction accepted for executed operator/CLI scope; no remaining blocking finding observed. This corrects a real gap outside my first native journey's discriminating power: the first report's no-findings result did not establish general owner closure. Expanded descendant rows now contribute canonical owners before owner-side instruction/check routing. Actual temporary CLI scenario above confirms this without relying solely on supplied probes.

| Expected condition | Result |
| --- | --- |
| native paged metadata complete/stable | PASS |
| native legacy instructions/routes agree | PASS |
| sole directory independent oracle | PASS |
| external editing owner retained | PASS |
| external live instructions retained | PASS |
| external check retained | PASS |
| unrelated instructions absent | PASS |
| fixture legacy instructions/routes agree | PASS |
| inventory page metadata stable | PASS |
| EN/UA owner paths equivalent | PASS |
| exact raw response sizes | PASS |

The fixture lexical oracle occurs only in the area directory purpose; its descendant has an external canonical owner with separate live AGENTS and an owner-only check. Actual CLI single-directory hit retains all three. Paged hit lists remain bounded and metadata stable; exact byte measurements include complete metadata. Native alias rechecks confirm config formatting did not change the selected EN/UA owners. No permanent regression authored by this reviewer.

Unchanged evidence reuse: map/root instructions/README/MEMORY/catalog bytes remain as first packet; compact map14272-byte operator discovery remains applicable. Hit partition/refusal/miss, capacity diagnostics, exact historical AGENTS safety and byte freshness retain their earlier bounded observations for unchanged algorithms. Source digests/cursors changed; old cursor values cannot be reused. Changed metadata integration is actually rechecked here. Source expansion means output size can grow intentionally. Full suite/Basic are not rerun or claimed by this role. Existing test allocation: named NavigationSafetyTests regression → test_repository_intelligence.py → navigation.yml/D02 in SITE-CHECK-PROFILES; temporary CLI case is supplemental exploratory/manual evidence.

Website/browser reasoned not applicable: changed surface is repository tooling/protocol only; no site/runtime/media changes. Connector candidate remains unpublished, so first expected404 is not repeated and final-ref connector journey remains unobserved. Root will perform actual remote short-map/direct-owner walkthrough after publication. No wholeAC/delivery acceptance. Final receipt replacement/clean commit/accounting/policy/trusted gates remain pending; semantic changes require affected re-review. First report retained unchanged.

Final candidate hash mismatches: []. First report unchanged: True.
