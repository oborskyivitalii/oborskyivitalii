# Requirements & Acceptance — correction reconciliation

2026-11-10; `/root/issue189_t03_acceptance`, same-handle correction continuation. The first report `requirements-first.md` remains intact. This is **not** a fresh isolated first judgment: the orchestrator disclosed the Code/White-box directory-owner finding and the implemented correction after all first judgments. No peer report files were read.

## Verdict

**Affected correction accepted; RA-01 resolved; no remaining blocking requirements defect found in this corrected T03/T04 scope.** Directory-only metadata must include descendant canonical editing owners and those owners' applicable live instructions/checks, even outside the matched directory. This follows the original AC01/AC02 completeness obligation; it is not a new intent, relaxed oracle or convenient postimplementation exception.

The initial report's positive directory-completeness assessment did not cover this external-owner case. Its initial fixture had the same owner throughout the directory; passing that fixture could not establish the missing closure. The newly demonstrated failure narrows/supersedes that affected first assessment without erasing it. The corrected implementation and meaningful regression now support the promised outcome.

All whole AC01–AC05 remain open. Final literal receipt archive, handoff/RI refresh, exact clean-source checks/accounting, owning acceptance policy, other affected role corrections and T05/T06 actual delivery remain separate gates.

## Source identity and inspected delta

- Base/HEAD: `e4e09f45d014b985568af497e5958cc7eb8e3fab`; corrected staged tree observed: `859b408a26ce30a51820f0af9a79fd803c55d0c2`. Native staged candidate, not a clean committed-source check.
- Correction packet: `/workspace/scratch/2c34f552b848/issue189-t03/correction-packet.json`, SHA256 `9629b4e8175739a404abc97e1f3f152b715635ba39e3d6e2b77e989ffb098ffb` independently matched.
- All14 listed candidate file SHA256 identities matched actual bytes. Producer SHA256 `bd40042bac259cc896e2c8715d754ee1ccabd9f0cac7794ec8f0c2adeaefde1b`; test SHA256 `67f64303e5bfdab6c11154ed01bbac865a4f579e497f49f335f5e23554754da5`; config SHA256 `77a26b1e9e8a0a45f48972149ad4aab103df5875e14ef66622aef36dec8a895b`.
- Native `verify` independently passed, digest `d5291e772269de8df038355656f2b65370354fe5ce5dedbecfca91b2e57a5e25`.
- Inspected actual correction.diff, current `context_metadata`, new regression, maintained contract clarification, analysis correction record, current config diff against base, raw pre-fix/fixed probe receipts and supplied Basic result. Original intent/prompt/policy identity and unchanged source scope are reused from the first report; no material requirement/acceptance-oracle change was found.

## Finding dispositions and traceability

| Finding / AC | Actual affected evidence | Disposition |
| --- | --- | --- |
| RA-01, scoped formatting / AC05 CS05 | Current staged config diff from base contains only four new aliases in the existing repository-structure owner. Unrelated expanded arrays have returned to base formatting. | Resolved without an exception or semantic config change. |
| Directory-only external descendant owner omission / AC01 and AC02 | `context_metadata` now first expands matched directory descendants as context rows, derives their direct canonical owner set, then combines paths/owners for instructions and validation routes. It leaves actual matched hit arrays and pagination unchanged. | Existing completeness requirement restored. Owner-side instruction and check metadata are no longer omitted. |
| Regression independence / AC01, AC02, AC05 | New test assigns a descendant `owners/canonical.md`, adds `owners/AGENTS.md` and owner-only/descendant-family checks, and queries a purpose string unique to the parent directory. It asserts one directory hit, no artifact hits, total1, both owners, scoped owner instructions and both routes; compares the unqualified context helper too. | Meaningful failure detection rather than code-shape/existence assertion. Test authored by implementer, not this reviewer. |
| Corrected integrity / AC02 | Native full-source verify passed after current config, producer, test, contract/report and deterministic RI/CI refreshes. Scope/prefix and paging parity tests still pass. | Supports corrected local source, not final clean commit or trusted delivery. |
| Current capacity / AC04 | Current diagnostic:2,665/5,000 files;238,681,230/250,000,000 hash bytes leaves11,318,770; max hash11,726,610/32,000,000; text21,814,174/50,000,000; max text1,999,782/2,000,000 leaves218. | Present margins remain within unchanged caps and above10MB; after provisional1MB allowance:10,318,770. Final all-input accounting remains pending. |
| Basic evidence / AC05 | `candidate-checks/basic-current.json` records unchanged Basic exit0 after exact locked publisher setup/full ancestry,18+10 focused tests,5 routes and deploymentAuthorized=false. First dependency/ancestry failures remain separate retained receipts. | Inspected successful raw result, not independently rerun by this role; no release/delivery claim. |

## Actual correction checks

- Ran four existing tests on corrected source: external descendant owner regression, directory metadata-before-paging/file-family routing, scopes/prefixes/legacy completeness and paging/request/source parity. **4 run,0 failures,0 skips,0.034s.**
- Independently extracted only `context_metadata` from first tree `957b21fde35f701a1d3b64af55daec5b8aa27568` into an in-memory test namespace, temporarily substituted it for the current helper, and ran the new regression unchanged. **1 run, exactly1 assertion failure,0 errors/skips**: old output owners were `['AGENTS.md']`, expected `['AGENTS.md', 'owners/canonical.md']`. Restored current helper immediately. This independently demonstrates the test catches the real pre-fix omission; no implementation/test file was modified.
- Native corrected RI `verify`, current capacity and SHA256/tree checks performed as above. Raw prior/fixed external-owner probe receipts show the same omission/restoration with hit total1 preserved.

Unchanged compact-map rendering/byte budget, full inventory/hash admission, serializer freshness, inert historical instruction-name boundary, original resource caps and legacy lookup logic are reused only because the actual correction does not change those implementations. Directory integration and affected owner/instruction/check completeness were rechecked directly. No full92-test/Basic campaign, browser/connector run, external write, implementation/test authoring or delegation occurred here.

The232-byte evidence TAR remains an explicitly disclosed placeholder; receipt replacement cannot yet be cited as a completed archive. Final source/accounting and unchanged-meaning verification remain required after the permitted literal receipts/handoff/derived refresh. Any substantive later implementation/oracle/claim change needs affected review. Launch/provider assurance limits from the first report continue to apply; the orchestrator owns actual execution receipts.
