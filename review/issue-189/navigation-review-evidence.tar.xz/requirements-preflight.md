# Issue 189 T03/T04 — Requirements & Acceptance preflight

Date: 2026-11-10. Role: distinct nonauthor Requirements & Acceptance reviewer, task `/root/issue189_t03_requirements`. Phase: first independent preimplementation judgment.

## Verdict

**PASS for bounded T03/T04 implementation. No blocking requirements defect found.** This satisfies only the requirements-preflight gate for the specified implementation/review route; it is not an implementation pass, whole-AC acceptance, Ready/merge/delivery or release judgment. The supplied user continuation authorizes T03/T04; the dated T02 STOP in MEMORY/issue history does not cancel that later instruction. Stop/report after this iteration remains required.

The proposed interface supplies enough concrete behavior to implement without inventing a material owner decision. Default limit20, range1–100, opt-in activation by scope/prefix/limit/cursor, deterministic `(kind,path)` paging, request/source-bound continuation, unchanged unqualified interface and diagnostic-only capacity are compatible with the recorded intent. Routine field/function design can be resolved by the implementer and documented for candidate review. No request to change caps, introduce shards/cache/services, modify media/runtime or deliver externally is supplied.

## Inspected identities and evidence

- Clean native checkout HEAD `e4e09f45d014b985568af497e5958cc7eb8e3fab`; `git status --short` empty at initial inspection. Local branch ref matched HEAD. Remote/live PR190 state was supplied as Draft and was **not independently queried** by this reviewer.
- Packet SHA256 `e4238a73c6ad930f8efbe19a0a828af217a5f127de65713a023eb90115b8fb42`, independently recomputed. All13 packet file SHA256 values matched inspected bytes. Dated owner issue snapshot SHA256 `657c77791316fc5e998c31120a9c8e78fa17821a01529661f4082ef6a21a30c5` also matched.
- Read root AGENTS/README, relevant map owners, MEMORY, CONTRIBUTING requirements/review route, RI/acceptance contracts, applicable style guidance, producer and existing test materialization/mutation/instruction/lookup cases; no applicable nested AGENTS found beneath tools/tests/.github/agents.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`, both verified against packet.
- Supplied analysis is historical candidate evidence, including its historical result tables. Those tables were not adopted as independent current verdicts. No current peer outputs, parent notes or private chat history were read. No implementation, tests or external state were changed; only this assigned report was written.

## Requirements/oracle assessment

| Intent / stable AC | Required check or owner gate | Preflight observation |
| --- | --- | --- |
| AC01 current entry / compatibility | Generated map <=32,768 UTF-8 bytes; real EN/UA aliases, exact files, directory context, history/generated access, lexical misses and connector-only direct-owner journey; unqualified API/CLI regression | Proposed behavior is assessable; current producer still renders an exhaustive map. Candidate execution remains pending. |
| AC01 bounded scoped navigation | Explicit complete-hit set, stable pages with returned/remaining/continuation/source digest; changed request/source cursor rejection; complete metadata and whole-response byte measurement | List bound is explicitly distinct from total byte bound. Complete mandatory metadata must survive pagination. No responsiveness or lookup-speed promise is inferred. |
| AC02 full integrity | Exact regenerated JSON/map bytes, independent whitespace mutation, actual CLI build→verify, retained source/binary/config/producer mutations and tracked-mode/exclusion negatives | Current verify compares parsed JSON objects and thus misses formatting-only edits; the accepted change fixes a real oracle gap. Fixture materialize currently writes noncanonical JSON and must change atomically with verification. |
| AC02 instructions / directory scope | Exact historical/draft AGENTS.md rejection plus inert historical name; nested live instructions; directory and descendant owner/instruction/check routing | Current build discovers AGENTS by basename regardless of role; current context path set omits directories. Accepted requirements directly cover both boundaries. Preserve configured lexical validation-route family semantics separately from path-component user filters. |
| AC03 archive/protected closure | Retain frozen original/archive/member/recovery evidence and protected identities; account for any explicitly permitted metadata edits | No new archive mutation is proposed. T02 supplied evidence is historical evidence, not rerun by this role. T03 is no authority to expand archival eligibility. |
| AC04 truthful resource limits | Fixed independent totals; hard-limit and limit+1 cases for all five limits; advisory threshold; complete native candidate accounting | Numeric target and unchanged bounds are explicit. Final >=10,000,000 spare includes all new source/evidence, not merely map/JSON size reductions. Existing218-byte text-ledger margin remains a reported constraint. |
| AC04 diagnostic capacity | Over-limit report yields exit1/diagnostics, never freshness/valid-RI status; missing/unsafe/unreadable sources remain visible failures; no derived-input double count | Metadata-only measurement is a separate observation, not full byte hashing or verification. Feasible without accepting over-limit inputs as valid RI. |
| AC05 allocation / review / delivery | Existing permanent RI suite, coupling/source/style routes, current-source four-role candidate review; owning policy and trusted delivery gates | T05/T06 explicitly remain pending. No AC checkbox may be completed from this preflight. |

## Nonblocking implementation clarifications

1. **Low — publish exact scope and error semantics in the maintained CLI contract.** The accepted current role exclusion is explicit (`history`, `draft`, `generated`); document the exact history role set, generated access through all, prefix normalization and root/file/directory matching, cursor invalid offset behavior, and empty page/miss meaning. Evidence: analysis scoped-read paragraph and packet proposed interface. These are ordinary API choices within the accepted architecture, not missing user authorization. Candidate tests must use a fixed independent mixed-role fixture rather than infer their expectations from implementation helpers.
2. **Low — avoid a misleading “bounded” claim for broad metadata.** Paging bounds only artifact/directory hits. Evidence: analysis bounded-results paragraph. Document complete-response UTF-8 byte accounting including printed newline, and a concrete advisory/narrowing policy. Do not cap/drop applicable owners/instructions/routes to satisfy an arbitrary payload target. Include a broad alias and a directory with descendant metadata in candidate review.
3. **Low — distinguish diagnostic completeness from validation.** Evidence: packet capacity contract and producer scan limits. Report which totals were obtained and any scan error; an unsafe/missing/unreadable inventory cannot receive a completeness claim. Over-limit capacity must not call verify or announce freshness, while normal build/verify must continue refusing at the original bounds. Exact-limit and limit+1 oracles must be independent arithmetic.

## Limits and next gate

This review checked requirements/source feasibility and identities, not implemented behavior: no new CLI prototype exists at this source and no test suite/build campaign was run. Live GitHub/hosting and browser surfaces were not observed. The supplied source instruction is an explicit dated owner snapshot, not a live observation.

The initial task describes a none-fork launch; this report cannot attest provider-internal context/model behavior or independently prove the parent tool launch parameters. Preserve the actual orchestrator launch/accepted response receipt separately. Shared workspace/instructions are not an isolation sandbox.

Proceed with T03/T04, document the above routine semantics alongside the actual interface, then return the exact candidate/diff/oracles/raw checks for fresh requirements review and the three other roles. Material requirement/oracle changes require another preimplementation gate. All stable AC01–AC05 remain open until their whole checks and external owner gates pass.
