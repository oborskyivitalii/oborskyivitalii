import pathlib,unittest,json,hashlib,time,io
r=pathlib.Path('/workspace/scratch/2c34f552b848/issue189-checkout');o=pathlib.Path(__file__).parent
(o/'fixture-harness-first-failure.json').write_text(json.dumps({'command':'initial focused fixture selection Python heredoc','exit':1,'tests_run':0,'raw_failure':"AttributeError: 'TestSuite' object has no attribute '_testMethodName'",'diagnosis':'Discovery has nested TestSuite objects; two-level iteration treated a suite as a case. Collection failed before any test execution.','fix':'Flatten only TestSuite nodes recursively; exclude only the two actual real-repository methods until RI regeneration. No candidate or test oracle change.'},indent=2)+'\n')
def cases(suite):
 for x in suite:
  if isinstance(x,unittest.TestSuite):yield from cases(x)
  else:yield x
allcases=list(cases(unittest.defaultTestLoader.discover(str(r/'tests'),pattern='test_repository_intelligence.py')))
selected=[x for x in allcases if x._testMethodName not in {'test_real_adapter_owners_and_cross_repo_isolation','test_quality_agent_queries_and_context_route_to_existing_checks'}]
stream=io.StringIO();t=time.monotonic();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite(selected));raw=stream.getvalue();(o/'fixture-first.log').write_text(raw);(o/'fixture-first.json').write_text(json.dumps({'base':'e4e09f45d014b985568af497e5958cc7eb8e3fab','source_dirty':True,'source_sha256':{p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in ['tools/repository_intelligence.py','tests/test_repository_intelligence.py']},'selected_ids':[x.id() for x in selected],'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'seconds':time.monotonic()-t},indent=2)+'\n');print(raw);raise SystemExit(not result.wasSuccessful())
