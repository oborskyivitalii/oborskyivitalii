## Original intent — 10 November 2026

The maintainer wants RI to describe the current repository, with old revision/evidence material archived, and requested deep investigation, architecture/logic, an execution plan, disputed choices and assessable ACs.

Split from #187 at the maintainer's explicit request. Original combined AC04–AC05 and the RI/archive portion of AC06 remain owned here; local AC01–AC05 below preserve those outcomes. #188 owns MEMORY lifecycle/bounds and #187 owns article motion. [Original combined intake](https://github.com/oborskyivitalii/oborskyivitalii/issues/187#issuecomment-6770665091).

## Current status — T02 completed, 10 November 2026

[Exact-source T02 checkpoint, raw checks and final delta review](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6773669726) · [versioned report](https://github.com/oborskyivitalii/oborskyivitalii/blob/e4e09f45d014b985568af497e5958cc7eb8e3fab/review/issue-189/2026-11-10-analysis.md) · [recovery index](https://github.com/oborskyivitalii/oborskyivitalii/blob/e4e09f45d014b985568af497e5958cc7eb8e3fab/review/issue-189/archive-index.json).

Iteration2 removed only the frozen **19 redundant loose captures /11,386,774bytes**, after exact native/Git/ZIP recovery checks. Their originals remain in **3 unchanged existing ZIPs**. Added3 directory guides/3 gallery full-ZIP locators; all2,650 protected paths and original gzip/manifests/prior evidence remain exact.

Final clean source **e4e09f45d014b985568af497e5958cc7eb8e3fab**, tree **0f3b36aced7737dab09ddb4d4c33767c0b0e8ea2**: **82 tests**, RI/CI/style guards,19 documented recovery commands,3 full gallery restores, accounting and whitespace check pass. Four distinct role first launches used explicit fork_turns=none; final reports and postreceipt delta verification found no blocking T02 defect. Browser rendering/playback is unobserved due retained launch/security blockers; command/media-format checks are distinct.

Actual hash inputs **238,637,798bytes**, spare **11,362,202**; reserving1,000,000 for remaining189 inputs leaves **10,362,202**. Net input recovery11,304,728; complete tracked saving11,316,984; derived reduction12,256 are separately reported. T02 metadata/evidence overhead82,046 is within100,000 ceiling. All resource caps remain unchanged; parsed-ledger margin is still218bytes.

**STOP/report after T02, before T03.** PR190 remains Draft/unmerged; main/production stay ca756417590b9176f9fc33428321ffe1f64158cc. All stable AC01–AC05 remain unchecked: compact map/CLI/integrity/capacity interface, owning policy and actual trusted delivery remain. T01 preflight is retained in [its earlier exact-source checkpoint](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6772597589).

## Initial architecture / planning checkpoint — 2026-11-10

**[Versioned deep analysis, architecture, consumer map and test design](https://github.com/oborskyivitalii/oborskyivitalii/blob/78e4944e739dcfd728434a8e41d768b8389a10e1/review/issue-189/2026-11-10-analysis.md)**
**[Draft PR190](https://github.com/oborskyivitalii/oborskyivitalii/pull/190)** — planning artifacts only; execution commits [b63d0de](https://github.com/oborskyivitalii/oborskyivitalii/commit/b63d0de324da54590d801227156ee5fc82700e25) and [cbb7dfa](https://github.com/oborskyivitalii/oborskyivitalii/commit/cbb7dfa8b4f0ab4e3ca6448843edf84da3bd8b1a).

Four separately launched nonauthor roles reviewed the plan and affected corrections: Requirements, Code, White-box, Exploratory. Original results, source/prompt/packet identities and launch/result receipts are preserved in the PR's lossless planning-review-evidence.tar.xz. No blocking planning finding remains; this is not implementation acceptance.

### Live baseline and observed problems

Main/production remain ca756417590b9176f9fc33428321ffe1f64158cc. Inspect current refs again before implementation.

| Resource | Observed baseline |
| --- | ---: |
| RI hash inputs |249,743,718bytes;256,282 spare under250,000,000 |
| review/ |194,194,215bytes |
| Readable map / full JSON |865,848 /1,764,356bytes |
| Full catalog |2,957entries, including2,010 history file/directory entries |
| Parsed text aggregate |21,679,851bytes from tree metadata;50MB cap |
| Largest parsed file |secrets-reviewed.json1,999,782bytes; only218 spare under2MB |

These are source/tree/JSON observations, not a full native RI run. The now-accessible full native JSON and supplemental source blobs were inspected. Complete native consumer discovery, selected historical originals and binary archive extraction remain unobserved.

Two distinct problems: default context reads too much history; physical hash inputs nearly fill their cap. Shortening the two existing derived views does not recover hash-input capacity. Old Git commits are outside that working-tree scan.

### Decisions and concrete proposed architecture

**User decisions recorded during this investigation:**

- Keep historical archives **inside this repository**.
- Recover **at least10,000,000bytes final aggregate headroom**, after all new metadata/evidence inputs. This target does not override protected-resource eligibility.

**Technical proposal: one producer, the same two outputs.**

- Canonical catalog/config remain the authored owners; no duplicate current-state registry.
- REPOSITORY-MAP.md becomes a generated short current-repository entry; proposed hard budget32,768UTF-8 bytes.
- Keep full agent-context.json schema2/path/source-digest/artifacts/directories/input fields and complete verification.
- Add opt-in scoped/current/history/all, exact path/prefix and bounded paged retrieval through the existing CLI. Preserve unqualified query/inventory compatibility. Default agent instructions recommend explicit current scope.
- Keep applicable instructions/check routes complete. Paging applies to hit lists, not silently to mandatory metadata; measure whole responses and offer narrowing/direct-source fallback. Fix the observed directory-only context omission.
- Preserve full byte hashing and all existing caps; compare regenerated output bytes so whitespace-only JSON mutations also fail. Archive/instruction safety gets an exact AGENTS.md negative, not only AGENTS.before.md.
- No database, service, remote archive migration, shard tree or persistent cache in this first implementation. Query still performs full verification; no lookup speed claim is made.

**Archive candidates, not approved savings:**195 remaining old-site metadata matches /30,092,333bytes in existing archives. The previous33 originals were already replaced under184 and cannot be counted again. Revalidate ownership, consumers, archive bytes and every extracted original before removing any loose copy. Active/unfinished/public/fixture/rights/rollback resources stay protected. Never replace PNG/WebM bytes with fake HTML at the same extension.

**Capacity checkpoint proposal:**>=2,000,000bytes spare after a bounded first slice, with measured remaining189 allowance<=1,000,000 and>=1,000,000 reserve. This is internal planning, not a bypass of the accepted final10MB target. Existing secrets-ledger companion mechanism remains untouched; report every limiting margin.

## Execution plan and stop points

| Step | Work | Output / stop condition |
| --- | --- | --- |
| T01 | Freeze current base/live owners, complete consumer/eligibility audit and requirements review | Exact selected/excluded paths, agreed interface/budgets, test-impact map; report before mutations |
| T02 | Recover the smallest safe archive slice using existing members and locators | Every-original recovery and protected-set comparison; measured first checkpoint; report actual net bytes |
| T03 | Generate short map and implement optional scoped/paged reads; preserve complete JSON and existing unqualified CLI/API | Deterministic entry and lookup journeys; compatibility/negative fixture checks |
| T04 | Add bounded capacity visibility and finish useful headroom target | Final full-candidate accounting includes all new metadata/evidence; margins for every current limit |
| T05 | Reconcile requirements/code/white-box/exploratory results and current-source policy/RI/CI/style checks | Four actual roles, corrected findings, source-bound evidence and truthful pending gates |
| T06 | Deliver separate Draft→trusted selected lane→maintainer decision; handoff to188 | Actual merged/effective identity and remaining exclusions; no website release claim from RI green |

Use one owning189 PR, with bounded coherent iterations. A separately delivered capacity slice is optional only if actual size/route constraints require it; it stays under189, not a new umbrella issue. Do not ask the maintainer to approve each routine file decision. Report after T01/T02 and T03/T04, then the review/delivery checkpoint.



## Refined acceptance contract (stable AC01–AC05)

### AC01 — Short current entry and scoped retrieval

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Short generated REPOSITORY-MAP <=32,768 UTF-8 bytes; no appended exhaustive history dump.
- Preserve existing full JSON and unqualified lookup compatibility; explicit current/history/all and prefix/file retrieval.
- Bounded scoped response reports limit/remaining/continuation/source digest. Current scope is role-based, not timestamp authority.
- Demonstrate EN/UA owner aliases already promised, exact file, directory-only, history retrieval, generated lookup, pagination and lexical miss. Check expected owners/instructions/check routes against canonical sources.
- Connector-only journey uses the short map/direct owners without downloading/pasting full JSON; no false local-verification claim.

Owner gate: accept proposed entry budget and intended presentation; independent lookup usability/compatibility review.

### AC02 — Full deterministic integrity and instruction safety

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Every supported tracked/nonderived input (plus supported untracked files per existing contract) remains cataloged and byte-hashed; no new exclusion, cap increase or recursive output hashing.
- Two derived outputs have deterministic regenerated-byte freshness; whitespace-only JSON mutation must be rejected. This is the single proposed output oracle, not an optional post-implementation choice.
- Current unknown/missing/unsafe paths, modes, source/producer/config mutation and stale/tampered/missing outputs fail.
- Live instruction scope is preserved; historical exact AGENTS.md cannot silently activate or suppress live instructions. Exercise this boundary, not only AGENTS.before.md.
- Full native build/verify, current real-repository tests, coupling and affected consumer checks pass on exact final source.

Owner gate: independent source/integrity review; fixture-only success is not full-checkout verification.

### AC03 — Eligible archive batch and lossless recovery

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Freeze selected current-base paths, owner/delivery/consumer dispositions and explicit exclusions.
- Every original has base identity/size/SHA256 plus archive/member/digest and practical recovery; compare every extracted original before replacement.
- Historical manifests/failures/first-review status and original archive bytes stay intact. New media locators do not masquerade as old bytes.
- Frozen protected closure of active/unfinished/public/fixture/rights/rollback resources is unchanged; any permitted index/link adjustment is listed.

Owner gate: evidence-based eligibility and actual every-member recovery; old inventory match is not approval.

### AC04 — Complete resource accounting and sustainable maintenance

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Before/after report separates hash-input saving, full tracked storage and derived-output/context reduction.
- Report file count, total hash/text, largest hash/text and margins, including the218-byte ledger risk.
- Final target >=10,000,000bytes aggregate headroom after all candidate/evidence inputs; first checkpoint >=2,000,000 with measured <=1,000,000 remaining allowance and >=1,000,000 reserve.
- Existing250MB/32MB/50MB/2MB/5000 caps unchanged. Under10MB advisory warnings do not create another hard CI gate.
- Archive-in-repo choice and existing post-production recovery process are retained; no infinite-growth guarantee or all-history completion claim.

Owner gate: the10,000,000-byte final target is user-selected. The first checkpoint/allowance is an internal planning proposal to validate by measurement; if safe eligibility cannot meet the target, return measured alternatives rather than weaken protections.

### AC05 — Style, allocation, review and real delivery

- [ ] Whole criterion verified, including all subconditions and required external gates below.
- Apply CS01/04/05/07/08/09/10 to actual producer/config/archive tooling; other IDs only as applicable. Bounded guard does not replace architectural review.
- Versioned owning policy maps stable criteria to named current checks and explicit eligibility/usability/recovery/review/merge gates.
- Update map/contract/catalog/RI/CI/test-selection companions together. Preserve historical task snapshots; use selected existing methods rather than blindly running all old issue tests.
- Test-impact review precedes expensive CI; raw first failures persist. Four actual role results and affected corrections are source-bound.
- Complete actual trusted lane and applicable maintainer decisions; record source/tested/merged/effective states distinctly. Refresh only the task handoff pointer.
No AC is passed by this planning checkpoint.



## Remaining work after T02

- **Completed T01–T02:** exact selection/consumer preflight, reviewed19-copy archival mutation, recovery guidance/protected closure, measured capacity and current-source local checks. [Final T02 source/raw evidence](https://github.com/oborskyivitalii/oborskyivitalii/pull/190#issuecomment-6773669726).
- **T03–T04:** compact generated current map and optional scoped/paged compatible CLI reads; preserve complete inventory/legacy interfaces and full integrity; implement capacity visibility, remeasure the final all-input reserve.
- **T05–T06:** finish/review issue acceptance policy and test allocation, exact-source integration/four-role corrections and actual trusted full-diff lane/maintainer delivery decisions; handoff to188.
- All ACs stay unchecked until their whole promised behavior and required gates are verified. Local archival success is not full issue, Ready, merged, hosted or production acceptance.
- Browser rendering/playback is not observed; concrete environment/security failures and bounded successful recovery/format observations remain preserved separately. No access workaround or release exemption is claimed.

The native checkout is available. Existing ZIPs, gzip galleries, historical manifests, all prior failures/reviews, public/rights/rollback resources and unfinished work remain protected. No producer/CLI feature has yet been implemented.

