import pathlib,json,subprocess,time
r=pathlib.Path('/workspace/scratch/2c34f552b848/issue189-checkout');o=pathlib.Path(__file__).parent;logs=o/'candidate-checks';p=r/'.github/ri-ci-map.json';raw=p.read_text();old=json.loads(raw);results=[]
for name,cmd in [('coupling-refresh',['python3','tools/check_ri_ci.py','refresh']),('ri-build',['python3','tools/repository_intelligence.py','--config','.github/repository-intelligence-config.json','build']),('ri-verify',['python3','tools/repository_intelligence.py','--config','.github/repository-intelligence-config.json','verify'])]:
 t=time.monotonic();c=subprocess.run(cmd,cwd=r,capture_output=True,text=True);results.append({'name':name,'command':cmd,'exit':c.returncode,'stdout':c.stdout,'stderr':c.stderr,'seconds':time.monotonic()-t});(logs/'generation-current.json').write_text(json.dumps(results,indent=2)+'\n');print(name,c.returncode,c.stdout,c.stderr,flush=True)
 if c.returncode:raise SystemExit(c.returncode)
 if name=='coupling-refresh':
  new=json.loads(p.read_text());assert {k:v for k,v in old.items() if k!='reviewed_source_identity'}=={k:v for k,v in new.items() if k!='reviewed_source_identity'}
  modified=raw.replace(old['reviewed_source_identity']['digest'],new['reviewed_source_identity']['digest']);changed=[]
  for x,y in zip(old['reviewed_source_identity']['inputs'],new['reviewed_source_identity']['inputs']):
   assert x['path']==y['path']
   if x!=y:modified=modified.replace(x['sha256'],y['sha256']);changed.append(x['path'])
  assert json.loads(modified)==new;p.write_text(modified);(logs/'coupling-delta-current.json').write_text(json.dumps({'definition_identical':True,'changed_inputs':changed},indent=2)+'\n')
