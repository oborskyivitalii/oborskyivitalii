# Issue 189 T03/T04 — White-box correction review

**Verdict: WB1 resolved; no blocking finding in this affected correction scope.** The independent directory-only fixture now preserves descendant editing owners and their external instructions/checks. The new permanent regression detects the actual old implementation. Whole ACs, final evidence accounting, clean committed-source checks and delivery remain pending.

## Chronology and source binding

This is a continuation of distinct nonauthor `/root/issue189_t03_whitebox`, not a fresh-context first judgment. `whitebox-first.md` is preserved. The correction request disclosed Code’s same finding and Requirements’ formatting finding after all first judgments; this exposure is acknowledged. I inspected the actual delta and reproduced my own fixture rather than treating peer conclusions as an oracle. No implementation/test/external writes or delegation; only this assigned report plus ephemeral fixtures.

- Base/HEAD: `e4e09f45d014b985568af497e5958cc7eb8e3fab`.
- First staged tree: `957b21fde35f701a1d3b64af55daec5b8aa27568`.
- Corrected staged tree independently read back: `859b408a26ce30a51820f0af9a79fd803c55d0c2`. This remains a native staged candidate, not clean committed source.
- Correction packet SHA-256 independently matched: `9629b4e8175739a404abc97e1f3f152b715635ba39e3d6e2b77e989ffb098ffb`; all candidate-file hashes matched, zero mismatches.
- Corrected producer SHA-256: `bd40042bac259cc896e2c8715d754ee1ccabd9f0cac7794ec8f0c2adeaefde1b`; tests: `67f64303e5bfdab6c11154ed01bbac865a4f579e497f49f335f5e23554754da5`.
- Common/role prompts are unchanged from the first report: common `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`, White-box `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.

Read correction packet/diff and retained pre-fix/post-fix owner-closure raw JSON. Config parsed JSON was independently compared with the first staged tree: semantically identical. Producer function source comparison showed only `context_metadata` changed; capacity, scan, repository_files, check_tracked_inputs, verify, render_map, scoped_lookup and lookup are byte-identical function bodies. Their unaffected first-review structural observations and focused capacity/instruction evidence are reused, without claiming they were rerun on this candidate. Changed integration was executed below.

## Correction assessment

`context_metadata` now expands directory descendants into context rows before collecting canonical editing owners and path closure. Instruction selection and lexical validation-family matching therefore see external owner paths. It does not append descendant rows into hit arrays; pagination still describes actual matches only. The doc clarification matches the original complete-directory-context obligation. The external owner is not recursively expanded into unrelated descendants. User component-boundary prefix filtering and configured lexical check prefixes remain separate.

The permanent test uses an external owner with its own live AGENTS, an owner-only route and a descendant lexical-family route. It asserts exactly one directory hit, both owners/instructions/checks, and metadata parity with the unqualified context helper. This catches the missing ownership edge which the old all-root-owner fixture could not expose.

## Risk → independent oracle → route → result

All selected methods are in `tests/test_repository_intelligence.py::NavigationSafetyTests`, allocated through repository R and `.github/workflows/navigation.yml` → navigation → “Check RI inventory and agent-memory contract”. No new workflow or unowned test route is needed.

| Risk / AC | Oracle and executed case | Result |
| --- | --- | --- |
| WB1 owner closure / AC01–02 | New `test_directory_only_context_keeps_external_descendant_owner_instructions_and_checks` preserves external owner/instruction/check and total1 | PASS |
| Regression sensitivity / AC01–02 | Substitute only old `context_metadata` from first staged tree into ephemeral module and run that new test | Intended failure:1 test,1 failure,0 errors; missing `owners/canonical.md` at test line250 |
| Metadata/filter integration / AC01 | `test_directory_context_is_complete_before_paging_and_routes_keep_families` retains nested instructions and lexical families, excluding sibling | PASS |
| Paging integrity / AC01 | `test_paging_parity_and_request_source_bound_continuation` retains complete ordered hits and request/source binding | PASS |
| Metadata size / AC01 | `test_response_measurement_and_large_metadata_are_not_silently_truncated` retains full metadata and exact UTF-8 response bytes | PASS |
| Changed producer/freshness/CLI integration / AC02 | `test_serialized_freshness_and_actual_cli_round_trip` rejects byte mutations and checks actual CLI serialization/legacy retrieval | PASS |
| Independent reproduction / AC01–02 | My original `area` / `area/deep/item.md` → `owner/guide.md` with live `owner/AGENTS.md` fixture, actual scoped query and scoped context-for-task subprocesses, limit1 | Both exit0; complete metadata, one hit, exact response_bytes |
| Unqualified integration / AC01 | Actual unqualified context-for-task subprocess against same independently materialized fixture | Exit0; external instruction and both check routes preserved |

## Raw execution accounting

Executed five named current-source methods through a stdlib unittest suite, with no permanent test edits:

```text
test_directory_only_context_keeps_external_descendant_owner_instructions_and_checks ... ok
test_directory_context_is_complete_before_paging_and_routes_keep_families ... ok
test_paging_parity_and_request_source_bound_continuation ... ok
test_response_measurement_and_large_metadata_are_not_silently_truncated ... ok
test_serialized_freshness_and_actual_cli_round_trip ... ok
Ran 5 tests in 0.276s
OK
SELECTED_ACCOUNTING 5 0 0 0
```

Fault-sensitivity run, using `unittest.mock.patch.object(ri, 'context_metadata', old['context_metadata'])` where `old` was compiled from the actual first-tree producer; no repository source mutation:

```text
REGRESSION_OLD_IMPLEMENTATION 1 1 0
AssertionError: Lists differ: ['AGENTS.md'] != ['AGENTS.md', 'owners/canonical.md']
Ran 1 test in 0.007s
FAILED (failures=1)
```

This expected negative result demonstrates detection of the original bug, not a coverage percentage. The enclosing Python orchestration asserted that exactly one failure and zero errors occurred and exited0.

Both independent scoped CLI observations returned:

```json
{"editing_owners":["AGENTS.md","owner/guide.md"],"instructions":["AGENTS.md","owner/AGENTS.md"],"validation_routes":[{"commands":["owner-check"],"concern":"descendant-owner-check","paths":["owner/guide.md"]},{"commands":["family-check"],"concern":"descendant-family","paths":["area/deep/item"]}]}
```

Pagination in both: limit1, offset0, total1, returned1, remaining0, next_cursor null. Query/context fingerprints differ as required by command binding. Complete printed response-byte accounting was asserted against UTF-8 stdout lengths. The third, unqualified context-for-task subprocess also exited0 and preserved both routes and external scoped instruction.

## Limits

No full-suite/Basic rerun, hosted or live GitHub observation, resource-accounting acceptance or measured branch coverage is claimed by this role. Supplied Basic/RI/CI summaries are not promoted into my executed evidence. Final literal reports/receipts, evidence TAR replacement, MEMORY handoff and deterministic RI regeneration need final-source verification/accounting; substantive changes require affected review. The first report remains the immutable initial judgment, and this report resolves WB1 only on the specified correction tree.
