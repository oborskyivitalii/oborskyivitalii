# Code / Artifact first review — issue189 T03/T04

Verdict: **changes requested**, one P2 completeness defect in directory-only metadata. This is the first independent result for `/root/issue189_t03_code`; I did not implement the candidate or its tests, consume current peer outputs, or delegate. Whole AC01–AC05, final evidence accounting and delivery remain pending.

## Inspected identities and boundary

- Native staged candidate, not clean committed source: HEAD/base `e4e09f45d014b985568af497e5958cc7eb8e3fab`; observed staged tree `957b21fde35f701a1d3b64af55daec5b8aa27568`.
- Packet `/workspace/scratch/2c34f552b848/issue189-t03/candidate-packet.json`, SHA256 `285e6c04f15ddd2c6bb4bd23aca5e60abd760c5e1d22771fe4b437b222d99667`. Every candidate/reference path byte count and SHA256 matched the packet when checked. Owner issue SHA256 `657c77791316fc5e998c31120a9c8e78fa17821a01529661f4082ef6a21a30c5` matched.
- Supplied actual diff SHA256 `8e11a38f7b70f8752b9f56bd68c2ba49bc8975a3462fe1a96e8587013e4d1fe2` matched `git diff --cached --abbrev=7` exactly. Default Git abbreviation now uses eight characters; that rendering-only discrepancy was diagnosed, not treated as source divergence.
- Common reviewer contract SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; code prompt SHA256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`, both read directly.
- Read root instructions/README/map/MEMORY (dated handoff only), original owner intent/ACs, CONTRIBUTING review/iteration/failure rules, acceptance/RI/style contracts, full producer and relevant test/diff changes, catalog/config/CI companions and raw supplied first-failure diagnoses. Map lists only root AGENTS; no nested applicable AGENTS was present in the supplied repository search.
- Requested task boundary: read-only review/temp probes, only this report written, no implementation/test/external writes. Requested versus accepted launch parameters and provider context/model internals must be recorded by the orchestrator; I cannot independently attest provider isolation. No author/private conversation or peer output was read during this execution.

## Blocking finding

### P2 — Directory-only context omits descendant editing owners and their owner-side instructions/checks

Location: `tools/repository_intelligence.py:602–619` (`context_metadata`), particularly descendant expansion at609–612 and `editing_owners` at614. Affected AC01 directory-only owner/instruction/check completeness; AC02 instruction routing in that promised context.

The function adds descendant **paths** after collecting owners from only the original hit rows. It never collects owners of the expanded descendant rows. Consequently a directory-only lexical match can advertise complete context while hiding a descendant's canonical editing owner and the instructions/check route attached to that owner outside the directory. Paging does not recover these entries because there was only a directory hit.

Actual bounded temporary probe using the existing fixture builder (no repository mutation): created `area/item.md` owned by `owners/owner.md`, live `owners/AGENTS.md`, and a validation route whose path is `owners/owner.md`. Set only directory `area`'s purpose to `unique-directory-only`. `scoped_lookup(data, 'unique-directory-only', scope='current', limit=1)` returned:

```json
{
  "directory_hit": ["area"],
  "editing_owners": ["AGENTS.md"],
  "instructions": ["AGENTS.md"],
  "checks": [],
  "descendant_actual_owner": "owners/owner.md"
}
```

This conflicts with the maintained scoped-retrieval promise that canonical editing owners and applicable instruction/check metadata remain available, and that directory context includes descendants. The current directory-context regression passes because every fixture catalog entry has the same owner `AGENTS.md`; it does not distinguish the missing owner closure.

Treatment: form the complete context row set, including descendants of directory matches, before deriving editing owners and owner paths; use those owner paths for instruction/check routing without role-filtering them away. Add a behavioral regression with an external descendant owner, its nested live instructions and owner-only check route. Preserve hit counts and legacy lookup output. Affected code/test correction needs separate nonauthor review; no fix was authored here.

## Other examined risks and observations

- The full projection retains schema2 and inventory: semantic base/candidate comparison found only the intended new evidence artifact and changed map purpose among artifact rows, with no removed files/directories or changed directory rows. Config semantic delta is owner aliases; limits/exclusions remain unchanged.
- Legacy `lookup` remains unchanged, unqualified query/inventory preserve their complete result shapes; opt-in scope/prefix/paging is separate. Request/source/page-size fingerprints, component-boundary user prefix filtering, lexical configured check-family prefixes, metadata-before-page handling and empty/miss status were examined.
- Exact regenerated UTF8 output bytes now reject JSON whitespace/CRLF mutations. Map is14,272bytes under32,768; same producer retains both outputs. Historical exact AGENTS roles/ancestors refuse rather than silently suppress live names. Capacity shares input admission and tracked-mode checks, labels metadata versus integrity correctly, preserves all five limits and reports over-limit inventories without treating them as fresh RI.
- CS01/04 ownership and dependency direction, CS05 readability, CS07 bounds, CS08/09 meaningful tests/guard scope and CS10 evidence routing were inspected. No runtime/template/media/service/release code changed. No additional style/architecture blocker identified.
- Supplied generation failure (`'workflow'`) is consistent with the optional-workflow renderer fix and source-only route regression; fixture collection failure ran0 tests and is correctly separated. Basic's missing publisher dependency and then shallow ancestry failures are setup refusals in unchanged guards, with separate diagnoses and bounded next actions. I did not reinterpret them as passes or rerun Basic. Subsequent successful Basic is an orchestrator-owned observation, not my execution.

## Actual checks and limits

- Independently executed packet/reference hash verification: all matched; owner hash matched; staged tree/base readback matched; exact diff equivalence confirmed with explicit abbreviation.
- `git diff --cached --check`: exit0.
- Native `python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify`: exit0, fresh outputs on the inspected staged source.
- `python3 -m unittest discover -s tests -p 'test_repository_intelligence.py' -k directory_context -v`: one test, pass; demonstrates the existing fixture gap alongside the independent negative probe above.
- `python3 tools/check_ri_ci.py verify`: exit0;17 checks/19 layers, digest `7c2be11c75ded9781b3fb01c33b48e4a464b75cc17f4e8a5af951070775ed1de`; live GitHub state explicitly unverified.
- Read supplied check results rather than duplicate the full92-test/Basic campaign. Their execution is not claimed as mine. No full hosted/UI/device/archive-media/release surface is part of this implementation; no provider/security/comprehensive coverage guarantee is supplied.
- Placeholder TAR→verbatim evidence, literal receipts/MEMORY handoff and deterministic RI refresh are still planned. Verify their exact final bytes/accounting and unchanged substantive sources before accepting this result. Any substantive correction requires affected re-review. No Ready/merge/release/whole-issue acceptance is given.
