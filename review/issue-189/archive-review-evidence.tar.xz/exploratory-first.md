# T02 independent Exploratory / Interaction QA — first result

Date: 2026-11-10. Reviewer task: `/root/issue189_t02_exploratory`. Distinct nonauthor first review; no implementation/test/external writes or delegation. Supplied candidate and necessary authoritative owners only; no parent/private chat or current peer outputs inspected. Shared filesystem/platform is not isolation attestation; provider context/model internals unknown. Orchestrator owns launch receipt.

## Verdict and boundary

**No blocking candidate finding in the executed bounded archive/operator journeys.** T02 practical command recovery/discovery passes: all19 individual index commands, all6 guide command blocks and3 complete galleries were actually exercised. Browser-rendered locator navigation/video playback remains **not observed**, with concrete environment/security blockers below. This is bounded archival review, not full issue AC03 acceptance, whole AC01–AC05 completion, Ready, trusted delivery, merge or release. Final complete input accounting and exact clean-source checks remain orchestrator work. Do not promote the CLI/media-format observations into browser playback or physical usability proof.

## Charter, limits and source binding

Independent charter: start from an existing gallery locator or removed-media directory, discover the full archive and recovery index without author chat, run published commands from repository root, recover single files and whole relative-layout galleries, distinguish gzip-only HTML from full gallery recovery, inspect usable media formats, and verify discoverability through actual RI lookup. Boundary cases: v6 has5 selected copies rather than7; gzip alone lacks relative media; removed original paths intentionally do not serve substitute media. Time bound: <=6 minutes of read-only operator/tool exploration, no broad test campaign. Native source is a staged candidate, **not a clean committed checkout**.

- Repository: `/workspace/scratch/2c34f552b848/issue189-checkout`.
- Observed HEAD/base: `78e4944e739dcfd728434a8e41d768b8389a10e1`.
- Observed staged tree: `c0081d569d7a1a902a412a45049c85998131a60c`.
- Packet SHA256: `03645dffb23464195e01f341e654cbaa43e729f8fed7fe48bdfee04d12c980a6`.
- Supplied diff SHA256: `13cbbc5c5d01470098ac1279b6cb1d73a93f2d5bcea615add063edf5e107d72e`.
- Owner/AC text SHA256: `1dfffa598c2360e8e0907465975f2755b07be376771808feb568d09e5f794ab6`.
- Common contract SHA256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role prompt SHA256: `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.

All candidate and reference bytes listed in supplied packet were independently SHA256-compared at entry and again after operator exploration: **zero mismatches**. Missing19 candidate paths are declared deletions. Root AGENTS/common/role/README and relevant CONTRIBUTING ownership, RI architecture/commands, report delta, owner ACs, memory handoff and map were inspected. No nested review AGENTS found. Generated map/catalog/RI are discovery evidence, not original-media authority.

## Actions and observations

| Journey / expected | Actual action / observed result |
| --- | --- |
| Locate old gallery recovery | Read all3 actual locator HTML files and guides. Each locator explicitly links complete ZIP, directory guide and original gzip, explains relative layout and distinguishes historical archive from active rendition. All9 local href targets exist. Guides link JSON index and gallery locator. |
| Execute published full restore | Extracted first `sh` block from each guide and executed verbatim with `bash -e` from repo root. All3 returned0; printed ZIP hashes matched guide values; unzip restored actual gallery path. |
| Single-file guide example | Executed second `sh` block from every guide verbatim; all3 returned0 and printed expected SHA256. Examples cover v5/v7 credits WebM and v6 desktop PNG. |
| Every-original index command | Executed each of19 `recoverFromRepositoryRoot` scripts verbatim with `bash -e`. All19 returned0 and actual shasum equaled the item's original/expected SHA256. This exercised shell quoting/output routing, not merely zipfile API reads. |
| Full relative gallery closure | Parsed href/src from all extracted HTML files, resolved each relative local path after dropping query/fragment. Each restored family has22 HTML files and303 local references; missing targets0/303 for each. External/data/fragment-only links were excluded explicitly. |
| Preserved gzip route | Decompressed each original `.html.gz` in memory and byte-compared against restored ZIP gallery HTML:3/3 identical. Guidance correctly says HTML alone does not restore media. |
| Media inspectability | PIL fully decoded both selected contact sheets per family:6 PNGs pass. Each mobile image1050x956, desktop1080x1890. ffprobe actual restored `index-motion.webm`: v5 VP8 1440x900, v6/v7 VP9 960x600;3/3 exit0. No claim of full video decode/playback. |
| Practical catalog discovery | Ran existing RI CLI exact-path queries for `review/site-v1-20261002-v5-captures/ARCHIVE.md` and `review/issue-189/archive-index.json`. Both exit0 and return the exact artifact, role history, owner CONTRIBUTING.md and root AGENTS.md instruction. |
| Handoff/next gate | MEMORY and report expose archive index, full ZIP requirement, T02 stop/report, T03/T04 remaining work and all whole ACs pending. Report allocation maps recovery to AC03/manual campaign and unchanged permanent navigation suite rather than adding a duplicate helper/test. |

Exact successful full-restoration outputs:

```text
GUIDE 5 0 exit0
721900d71fc91b9db33aa2758fab8d73f092bdfd811d4e5933ac6e2be3273ef1  review/site-v1-20261002-v5.zip
/tmp/tmp.Ld81gWYovR/review/site-v1-20261002-v5-index.html
FULL 5 htmls22 localRefs303 missing[] gzipExactTrue
GUIDE 5 1 exit0 ee3808d10d658bdfcebe48f0dd4669c2f43b52ba34928b552ad1209339cf9aa0
GUIDE 6 0 exit0
afe6784c18da5d5be6f4311d153e870bccd3ab7e8cb10275a883476b45a8cb42  review/site-v1-20261002-v6.zip
/tmp/tmp.gRcVkihWiw/review/site-v1-20261002-v6-index.html
FULL 6 htmls22 localRefs303 missing[] gzipExactTrue
GUIDE 6 1 exit0 4e6970584ca1ee28863daefbe293e15a689ec32b574d252f79d78474c115db76
GUIDE 7 0 exit0
f6675361394d7d9caba65e6d127c397535f5cb6b705cdcfd806f559581014df6  review/site-v1-20261002-v7.zip
/tmp/tmp.zzP9seCJDf/review/site-v1-20261002-v7-index.html
FULL 7 htmls22 localRefs303 missing[] gzipExactTrue
GUIDE 7 1 exit0 d8956d2ff1676cd01f3b8dcbb874536ffc02e58e3d224204ade185b16b0c4f80
INDEX_RECOVER: 19 commands exit0, actual SHA256 == indexed SHA256 for every item
FINAL_INPUT_MISMATCHES []
```

## Browser attempt and retained failures

Designed browser journey: view locator, follow guide, open printed restored gallery and play first video. Existing Playwright resolved at `/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.js`; installed Chromium156.0.8078.79 was present. A real launch using headless `/usr/bin/chromium` with `--no-sandbox` failed before a page was created. Relevant raw console:

```text
browserType.launch: Target page, context or browser has been closed
<launched> pid=17
/usr/bin/chromium: 9: [: 5225713664: unexpected operator
[17:17:1110/175328.629312:FATAL:chrome/browser/process_singleton_posix.cc:297] Check failed: . socket() failed: Operation not permitted (1)
[1110/175328.629981:ERROR:third_party/crashpad/crashpad/util/linux/scoped_ptrace_attach.cc:27] ptrace: Operation not permitted (1)
<process did exit: exitCode=null, signal=SIGABRT>
```

Then observed CUA inventory: Chrome/CDP available, tabs empty. Requested a new tab at the actual candidate locator `file:///workspace/scratch/2c34f552b848/issue189-checkout/review/site-v1-20261002-v5-index.html`. Tool rejected the protocol:

```text
Browser Use rejected this action due to browser security policy.
The requested URL protocol is not allowed. Allowed protocols: "http:", "https:".
The agent must not attempt to achieve the same outcome via workaround, indirect execution, raw CDP or browser commands, alternate browser surfaces, or policy circumvention.
```

Stopped that browser route; no alternate serving or security bypass attempted. Browser observations are failures of access/launch, not failures of candidate rendering. PIL/ffprobe inspection is a distinct permitted media-integrity observation, not a workaround claim of successful browser interaction. No screenshots exist because no candidate UI was reached.

## Findings, allocation and remaining evidence

No concrete candidate defect found in examined lossless-command, locator-link, relative-layout, gzip, index-discovery or handoff journeys. Browser rendering/playback and human-device usability are unobserved, not N/A or pass. Whole ACs remain open. The19 exact hash checks and3 archive layout inspections are manual source-bound recovery evidence under AC03; unchanged NavigationSafetyTests/navigation.yml and RI/CI tests remain orchestrator-owned permanent checks, not rerun here. No new mandatory device matrix or duplicate regression proposed for this data-only delta.

The supplied placeholder review TAR is intentionally not final review evidence. Its announced replacement with verbatim results/receipts and deterministic RI regeneration requires final source accounting/hash reconciliation. Any substantive locator/guide/index/contract correction requires affected re-review. This first result is preserved before reconciliation; no release authorization is inferred.
