import pathlib,json,subprocess,hashlib,shlex
r=pathlib.Path('/workspace/scratch/2c34f552b848/issue189-checkout');o=pathlib.Path(__file__).parent
d=json.loads((r/'review/issue-189/selected-files.json').read_text())
proof=json.loads((o/'before-removal-proof.json').read_text());assert proof['count']==19 and proof['gross_bytes']==11386774
index={'schema':1,'ownerIssue':189,'stage':'T02 lossless removal of redundant loose capture copies','base':'78e4944e739dcfd728434a8e41d768b8389a10e1','selection':'review/issue-189/selected-files.json','selectionSha256':proof['selection_sha256'],'production':{'source':'ca756417590b9176f9fc33428321ffe1f64158cc','release':'prod-2026-11-10.1'},'eligibility':d['eligibility'],'originalManifestTreatment':'Existing captures/offline/static manifests, gzip galleries and ZIPs describe exact historical bytes and remain unchanged. This index describes removed loose copies, not replacement media.','originalBytes':11386774,'archives':d['archives'],'items':[]}
new=[]
for v in (5,6,7):
 a=f'review/site-v1-20261002-v{v}.zip';prefix=f'review/site-v1-20261002-v{v}-captures';gallery=f'review/site-v1-20261002-v{v}-index.html';rows=[x for x in d['files'] if x['archive']==a];archive=d['archives'][a]
 for x in rows:
  dest=pathlib.Path(x['path']).name
  index['items'].append({**x,'archiveSha256':archive['sha256'],'originalWorkOwnerIssue':1,'originalWorkIntroductionCommit':archive['original_introduction_commit'],'recoverFromRepositoryRoot':f'restore_dir="$(mktemp -d)"\nunzip -p {shlex.quote(a)} {shlex.quote(x["member"])} > "$restore_dir/{dest}"\nshasum -a 256 "$restore_dir/{dest}"','expectedRecoveredSha256':x['sha256']})
 text=f'''# Historical v{v} capture archive

The {len(rows)} loose contact-sheet/recording copies listed below were removed under
[issue189](https://github.com/oborskyivitalii/oborskyivitalii/issues/189).
Their exact originals remain in [the existing ZIP](../site-v1-20261002-v{v}.zip),
with the full original relative directory layout. Other captures in this folder remain.
This guide is a locator, not replacement media or visual acceptance.

- ZIP SHA256: `{archive['sha256']}`
- ZIP bytes: {archive['bytes']}
- [Every-file recovery index](../issue-189/archive-index.json)
- [Gallery locator](../site-v1-20261002-v{v}-index.html)

## Restore the complete gallery

From the repository root, extract into a new temporary directory:

```sh
restore_dir="$(mktemp -d)"
shasum -a 256 {a}
unzip -q {a} -d "$restore_dir"
printf '%s\\n' "$restore_dir/{gallery}"
```

Compare the ZIP checksum above, then open the printed HTML path. Keep the
extracted `review/` directory together: the gallery uses relative media links.
The [original gzip HTML](../site-v1-20261002-v{v}-index.html.gz) is also preserved;
its HTML alone does not restore those relative media files. Do not extract over
this working tree merely to inspect old evidence.

## Recover one original

The ZIP member equals the original repository path: `{prefix}/<filename>`.
For example, from the repository root:

```sh
restore_dir="$(mktemp -d)"
unzip -p {a} {rows[0]['member']} > "$restore_dir/{pathlib.Path(rows[0]['path']).name}"
shasum -a 256 "$restore_dir/{pathlib.Path(rows[0]['path']).name}"
```

Compare its checksum with the table. The JSON index records every original path,
size, SHA256, Git blob, archive/member and individual command. Historical JSON
manifests still refer to original archived bytes; they have not been rewritten.
The removed loose-media URLs on this branch are recovered through the ZIP/index;
Git-pinned historical originals remain available.

| Filename | Original bytes | SHA256 |
| --- | ---: | --- |
'''
 for x in rows:text+=f"| `{pathlib.Path(x['path']).name}` | {x['bytes']} | `{x['sha256']}` |\n"
 p=prefix+'/ARCHIVE.md';(r/p).write_text(text);new.append(p)
 html=f'''<!doctype html>
<html lang="en">
<meta charset="utf-8">
<meta name="robots" content="noindex,nofollow">
<title>Historical preview archive</title>
<main>
<h1>Historical preview archive</h1>
<p>The exact original site-v1-20261002-v{v}-index.html is preserved losslessly.</p>
<p><a href="site-v1-20261002-v{v}.zip">Download the complete original preview ZIP</a></p>
<p>Extract the full ZIP into a temporary directory, keep its relative layout, then open review/site-v1-20261002-v{v}-index.html. The gallery's relative media require the complete extraction.</p>
<p><a href="site-v1-20261002-v{v}-captures/ARCHIVE.md">Checksums and recovery commands</a></p>
<p><a href="site-v1-20261002-v{v}-index.html.gz">Download the original HTML as gzip</a></p>
<p>The gzip preserves the original HTML alone; its relative media are in the ZIP. This locator is not an active site rendition or new visual acceptance.</p>
</main>
</html>
'''
 (r/gallery).write_text(html)
(r/'review/issue-189/archive-index.json').write_text(json.dumps(index,indent=2)+'\n');new.append('review/issue-189/archive-index.json')
# Only frozen, already actually recovered originals are removed.
subprocess.run(['git','rm','--']+[x['path'] for x in d['files']],cwd=r,check=True)
p=r/'.github/repository-paths.json';catalog=json.loads(p.read_text());e=catalog['entries']
for x in d['files']:del e[x['path']]
for path in new:e[path]={'kind':'file','purpose':('Exact T02 nineteen-file recovery index: base original identities, unchanged ZIP/member checksums and practical extraction commands.' if path.endswith('.json') else 'Historical capture archive locator: exact removed originals, unchanged full ZIP, relative-gallery recovery and checksums.'),'role':'history','owner':'CONTRIBUTING.md'}
p.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
print('Applied19 removals,3directory guides,3updated gallery locators,1index and catalog')
