# T02 independent White-box QA — first judgment

2026-11-10. Reviewer execution `/root/issue189_t02_whitebox`; distinct nonauthor. Verdict: **PASS for this prepared archive-only T02 candidate, with final-source verification pending after the declared evidence/RI replacement.** No blocking candidate defect found. No whole AC01–AC05 is accepted and no Ready, merge, delivery or release conclusion follows.

## Inspected identity and boundary

- Repository: `/workspace/scratch/2c34f552b848/issue189-checkout`; native staged candidate, not a clean committed checkout.
- Base HEAD `78e4944e739dcfd728434a8e41d768b8389a10e1`; staged tree checked before and after checks: `c0081d569d7a1a902a412a45049c85998131a60c`.
- Packet SHA256 `03645dffb23464195e01f341e654cbaa43e729f8fed7fe48bdfee04d12c980a6`; diff SHA256 `13cbbc5c5d01470098ac1279b6cb1d73a93f2d5bcea615add063edf5e107d72e`.
- Owner snapshot SHA256 `1dfffa598c2360e8e0907465975f2755b07be376771808feb568d09e5f794ab6`; frozen selection `cee9263e5928946e6acd595ac3a0853ed2aad324837766fd89443d70de96e8bb`; archive index `3258c63b0112937bc364f8cf5f4bc4c801b919d832340310ff47587c8db9b050`.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; white-box prompt `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- All packet candidate/reference file SHA256 values and declared deletions independently matched native files. Read root AGENTS/README, reviewer contracts, relevant map routes, dated MEMORY, owner snapshot, archive contract in CONTRIBUTING, RI bounds/integrity contract, check-profile routes, selected source/diff, current producer scan and existing NavigationSafetyTests inventory. No nested AGENTS was listed by the tracked-file inventory.
- No current peer output, parent scratch notes/private conversation or unrelated memory was opened. Candidate report contains historical review/status assertions; these were treated as claims, not test oracles. Platform/provider context internals remain unknown; runner launch admission is the orchestrator's separately recorded responsibility.

## Risk → scenario → independent oracle → route

| Risk / AC | Structural fault / scenario | Oracle and actual result | Route / allocation |
| --- | --- | --- | --- |
| Wrong or unrecoverable deletion / AC03 | Wrong member, wrong original, duplicate ZIP names, missing member | Restore all19; compare exact base bytes, size, SHA256 and Git blob; verify3 archive base bytes/SHA256 and85 unique names each. All pass. Missing-member lookup rejected3/3. | Source-bound manual archival campaign; retained source in index and selected-files; owning PR evidence |
| Lost original gallery / AC03 | Extracted relative layout missing or locator leads to absent target | Actual `unzip -q ZIP -d TEMP` for3 ZIPs; original gallery equals decompressed preserved gzip. All3 guides contain all19 expected size/digest entries;3 locators' local ZIP/guide/gzip targets exist and require complete relative layout. Pass. | Manual recovery/locator campaign; separate interaction role owns browser journey |
| Silent collateral mutation / AC03 | Removal outside selection or protected byte/mode rewrite | Independent base tree minus19 removals and9 permitted existing metadata exceptions:2650 native paths have exact unfiltered blob bytes and executable mode; staged modes/blob IDs also match. Deletion set exactly19. Pass. | Manual complete protected closure; mandatory site/docs/tools/tests/drafts/agents included |
| Inventory omission or control drift / AC02,05 | Catalog removes extra owner or CI refresh changes selectors | Catalog removes exactly19 entries, adds exactly5 recovery/evidence entries, every common entry unchanged. CI JSON excluding reviewed_source_identity identical to base. Native RI and coupling verification pass. | navigation.yml RI freshness / ri-ci-map; orchestrator owns82-test campaign |
| Capacity overclaim / AC04 | Gross deletion reported as net recovery, new inputs omitted, relaxed guard | Actual producer scan and full staged tracked size separately measured below; constants unchanged. Temporary32,000,001byte sparse ZIP rejected by actual scan's hash bound. Pass. | Manual complete accounting plus existing NavigationSafetyTests `test_hash_bounds_fail_without_silently_omitting_binary`; no new persistent test |
| Undetected corrupted restore / AC03 | Correct length but altered media byte | Flip first byte in memory and apply SHA256 oracle: mismatch rejected. Pass. This exercises the comparison oracle, not a new product validator. | Manual bounded negative; index expected digests |
| Premature acceptance / AC01–05 | Local archival success promoted to overall issue acceptance | Handoff/report preserve whole ACs pending and T03 stop boundary; no executable producer/helper/test/runtime change in candidate. | Owner issue policy and trusted delivery remain later gates |

No dynamic runtime state machine, cancellation or transaction code was introduced. Existing producer traversal has file/type/path, per-file and aggregate hash/text, tracked-file admission and derived-output branches; this candidate changes data inputs to those branches. This review measures selected observations, not branch coverage.

## Executed commands and raw results

Commands ran from the native checkout unless stated otherwise. Initial `git status --short`, `git rev-parse HEAD`, `git branch --show-current`, `git diff --cached --stat`, `git write-tree`, prompt/source reads and `sha256sum candidate-packet.json candidate.diff` established the identities above. Their results matched the supplied candidate; no source mutation was made.

Python heredoc campaign1 used stdlib JSON/hashlib/zipfile/subprocess/tempfile and assertions, in this order:

1. Verify every packet candidate/reference native SHA256 or absence.
2. For each ZIP, compare native SHA256/size and `git show BASE:ZIP` bytes; require85 unique member names.
3. For19 items: `ZipFile.read(member)` compared to `git show BASE:original`, declared bytes/SHA256, and Git blob using `git hash-object --stdin`; require native original absent.
4. Missing-member `ZipFile.read('review/nonexistent-member.png')` must raise KeyError,3 cases.
5. `unzip -q ABSOLUTE_ZIP -d TEMP`, compare extracted gallery to `gzip.decompress(preserved .gz)` bytes,3 cases.

Raw output before a later harness assertion:

```text
PACKET native candidate/reference byte identity PASS
RECOVERY 19/19 exact base bytes,size,SHA256,Git blob; 3/3 immutable ZIPs,85 unique members each,full extraction+gzip original HTML PASS; negative missing member rejected 3/3
Traceback ... AssertionError: review/sol-plan-20261002/SEO-QUERY-MAP.csv
exit 1
```

The failed protected assertion used `git hash-object FILE`, which applies repository text attributes. Diagnosis commands `git ls-tree HEAD PATH`, `git ls-files --stage PATH`, `stat`, `git check-attr -a -- PATH` and direct `git show`/native SHA256 comparison showed native/base identical15169-byte CRLF data, SHA256 `34efc6be3fd5441ceb3d057c7908daea446f9d1a06d2968a9eec7b6f2a7ffbcd`; base blob dff4f6906b7c76f02e2d4afc9d6c2662de8666d6, filtered hash998ee5240b8dd956ece82dd23a1cfb63e3943317. `text:auto,eol:lf` explains the false assertion. No candidate fix or unchanged blind rerun occurred. Corrected the independent check to `git hash-object --no-filters FILE` and separately compared staged modes/blob IDs and native stat executable bits.

Corrected protected/accounting campaign output:

```text
PROTECTED 2650 base paths byte/mode exact; exactly19 deletions; CI definitions/selectors unchanged PASS
CAPACITY {"base_tracked_bytes":252577067,"candidate_tracked_bytes":241210845,"derived_output_bytes":2622285,"hash_bytes":238588560,"hash_inputs":2662,"hash_margin":11411440,"largest_hash":["review/site-v1-20261002-v6.zip",11726610],"largest_text":["tools/quality/secrets-reviewed.json",1999782],"text_bytes":21769184,"text_files":1037,"text_margin":28230816,"tracked_saving":11366222}
STAGED_TREE c0081d569d7a1a902a412a45049c85998131a60c
```

The accounting imported the actual `tools/repository_intelligence.py` and called `scan(root,[config.output,config.map_output])`; sizes used actual scanned paths. Baseline tracked sizes came from `git ls-tree -r -z BASE` / `git cat-file -s BLOB`; current tracked total came from `git ls-files -z` and native sizes.

```sh
python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify
python3 tools/check_ri_ci.py verify
```

Both exit0:

```text
Repository Intelligence context is fresh.
{"checks":17,"kind":"ri-ci-coupling","layers":19,"live_github_state_verified":false,"pass":true,"source_digest":"54fe30f8dda6baa25ccb75b1ea8b83c92f4989da7a1db2a698966da58e2ad9d2"}
```

Metadata/negative campaign initially exited1 because its local Markdown-link existence predicate incorrectly treated `https://github.com/oborskyivitalii/oborskyivitalii/issues/189` as a filesystem target. Diagnosis: explicit URL scheme, not local file. Corrected predicate excludes scheme-bearing targets from local checks and records them unobserved; no source edits or blind rerun. Final exit0 output:

```text
METADATA3 guides/all19 table entries and3 locators local targets PASS; external links unobserved 3
CATALOG19 removals; additions ['review/issue-189/archive-index.json','review/issue-189/archive-review-evidence.tar.xz','review/site-v1-20261002-v5-captures/ARCHIVE.md','review/site-v1-20261002-v6-captures/ARCHIVE.md','review/site-v1-20261002-v7-captures/ARCHIVE.md'] all other entries exact PASS
NEGATIVE32,000,001byte sparse binary rejected: RI content hash bound exceeded at oversize.zip PASS
NEGATIVE one-byte corrupted recovery rejected by SHA256 oracle PASS
```

Sparse temporary file and extracted trees were automatically cleaned by TemporaryDirectory. The negative called actual `ri.scan(TEMP,[])` and required ValueError containing `hash bound exceeded`; it did not alter repo data/tests. Packet/reference identity campaign,19 byte comparisons,3 ZIP identities/unique-name sets/full extractions,2650 protected comparisons,2 native verify CLIs, metadata/catalog checks and bounded negatives completed; no whole-suite execution was duplicated.

## Accounting interpretation and limits

Current2662 hash inputs plus2 derived files leave2336 files under5000. Hash total238,588,560 leaves11,411,440 under250,000,000; largest hash11,726,610 leaves20,273,390 under32,000,000. Parsed text21,769,184 leaves28,230,816 under50,000,000; largest text1,999,782 leaves exactly218 under2,000,000. These caps and producer bytes are protected unchanged.

Gross removed originals11,386,774; complete tracked net saving11,366,222. Derived outputs total2,622,285; baseline derived total2,634,541, reduction12,256. Thus baseline hash input249,942,526 to238,588,560 gives net hash recovery11,353,966. Do not conflate these three quantities. Present margin exceeds the2MB first checkpoint and10MB final target at this prepared point, with1MB remaining work reserve leaving10,411,440 before the declared T02 evidence replacement. That is not final all-iteration accounting.

The248-byte archive-review-evidence TAR is expressly a placeholder and is not accepted as preserved completed review evidence. Replacing it with verbatim receipts/reports and regenerating deterministic RI is a declared later delta. Recheck final packet-relevant bytes, exact input accounting, protected closure, RI freshness and coupling after that replacement; any semantic source change needs affected review. The current result cannot certify future bytes.

External owner/PR/live GitHub state and served delivery were not independently queried; supplied dated snapshot identifies scope, and native refs identify inspected source. Browser/media playback, every extracted HTML relative-media reference, external URLs, broader syntax/style82-test campaign and final delivery are outside this bounded execution or allocated to other checks/roles. No existing full-suite pass is claimed here. No new test or implementation was authored. Findings are none within the examined scope; future feature, policy and real delivery gates stay pending.
