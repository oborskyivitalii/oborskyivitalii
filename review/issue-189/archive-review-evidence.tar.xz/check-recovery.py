import pathlib,tempfile,subprocess,json,hashlib,os,re,urllib.parse
from html.parser import HTMLParser
r=pathlib.Path('/workspace/scratch/2c34f552b848/issue189-checkout');o=pathlib.Path(__file__).parent;idx=json.loads((r/'review/issue-189/archive-index.json').read_text());results=[]
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[]
 def handle_starttag(self,tag,attrs):self.links += [v for k,v in attrs if k in ('href','src') and v]
with tempfile.TemporaryDirectory(prefix='issue189-postrestore-') as t:
 env={**os.environ,'TMPDIR':t}
 for x in idx['items']:
  c=subprocess.run(['sh','-c',x['recoverFromRepositoryRoot']],cwd=r,env=env,capture_output=True,text=True);assert c.returncode==0 and c.stdout.split()[0]==x['sha256'];assert not (r/x['path']).exists();results.append({'path':x['path'],'command':x['recoverFromRepositoryRoot'],'exit':c.returncode,'stdout':c.stdout})
 groups=[]
 for v in (5,6,7):
  guide=r/f'review/site-v1-20261002-v{v}-captures/ARCHIVE.md';text=guide.read_text();blocks=re.findall(r'```sh\n(.*?)```',text,re.S);assert len(blocks)==2
  c=subprocess.run(['sh','-c',blocks[0]],cwd=r,env=env,capture_output=True,text=True);assert c.returncode==0;lines=c.stdout.splitlines();a=f'review/site-v1-20261002-v{v}.zip';assert lines[0].split()[0]==idx['archives'][a]['sha256'];gallery=pathlib.Path(lines[-1]);assert gallery.is_file()
  parser=Links();parser.feed(gallery.read_text());local=[]
  for link in parser.links:
   u=urllib.parse.urlsplit(link)
   if u.scheme or u.netloc or not u.path:continue
   p=(gallery.parent/urllib.parse.unquote(u.path)).resolve();assert p.exists(),(gallery,link);local.append(link)
  loc=r/f'review/site-v1-20261002-v{v}-index.html';p=Links();p.feed(loc.read_text());assert set(p.links)=={f'site-v1-20261002-v{v}.zip',f'site-v1-20261002-v{v}-index.html.gz',f'site-v1-20261002-v{v}-captures/ARCHIVE.md'}
  for link in p.links:assert (loc.parent/link).is_file()
  c2=subprocess.run(['sh','-c',blocks[1]],cwd=r,env=env,capture_output=True,text=True);assert c2.returncode==0
  expected=next(x for x in idx['items'] if x['archive']==a)['sha256'];assert c2.stdout.split()[0]==expected
  groups.append({'version':v,'guide_sha256':hashlib.sha256(guide.read_bytes()).hexdigest(),'full_command':blocks[0],'exit':c.returncode,'local_gallery_references':len(local),'locator_targets':p.links,'example_command_exit':c2.returncode,'example_checksum':expected})
proof={'selection_sha256':idx['selectionSha256'],'individual_commands':results,'gallery_guide_journeys':groups,'result':'19/19 individual restores,3full gallery guide journeys and3guide examples exact; every gallery local link and locator target resolves'};(o/'postremove-recovery-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof['result']);print([{'v':x['version'],'local_refs':x['local_gallery_references']} for x in groups])
