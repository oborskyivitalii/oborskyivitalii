'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = '/workspace/scratch/db6290e7c2fe/author-site';
const playwright = require(root + '/tools/quality/toolchain/node_modules/playwright');
const { start } = require(root + '/tools/quality/serve.cjs');
const { entryScenario } = require(root + '/tools/quality/scroll-browser.cjs');
const artifact = require(root + '/tools/quality/artifact.cjs');
const engine = process.env.ENTRY_ENGINE || 'chromium';
const publicDir = process.env.SITE_PUBLIC_DIR || root + '/docs';
const output = process.env.ENTRY_REPORT || '/workspace/scratch/db6290e7c2fe/entry-browser.json';
const evidence = {
  scope: 'Focused local entry geometry/render replay; independent/device/production gates remain separate.',
  engine, publicDigest: artifact.manifest(publicDir).artifactDigest,
  runtime: JSON.parse(fs.readFileSync(publicDir + '/site-revision.json')).engine,
  sourceDirtyAtMeasurement: true, cases: [], errors: [],
};
async function main() {
  const { server, url } = await start();
  const browser = await playwright[engine].launch({
    headless: true,
    ...(engine === 'chromium' ? {executablePath:'/tmp/chromium',args:['--no-sandbox']} : {executablePath:'/workspace/scratch/db6290e7c2fe/webkit-launch.sh'}),
  });
  evidence.browserVersion = browser.version();
  try {
    for (const width of [1440, 390]) {
      for (const theme of ['light', 'dark']) {
        const context = await browser.newContext({viewport:{width,height:900},timezoneId:'Europe/Warsaw'});
        await context.addInitScript((theme) => localStorage.setItem('vo.theme', theme), theme);
        const page = await context.newPage();
        page.on('pageerror', error => evidence.errors.push(String(error)));
        for (const route of ['index', 'research', 'writing', 'talks', 'credits']) {
          await page.goto(url + '/' + route + '.html');
          const screenshot = `/workspace/scratch/db6290e7c2fe/entry-${path.basename(publicDir)}-${engine}-${width}-${theme}-${route}.png`;
          const result = await entryScenario(page, {route, screenshot});
          evidence.cases.push({width, theme, ...result});
          fs.writeFileSync(output, JSON.stringify(evidence,null,2)+'\n');
          console.log('pass', engine, width, theme, route);
        }
        await context.close();
      }
    }
    if (evidence.errors.length) throw Error(evidence.errors.join('\n'));
    evidence.pass = true;
  } catch (error) {
    evidence.pass = false;
    evidence.failure = String(error.stack);
    throw error;
  } finally {
    fs.writeFileSync(output, JSON.stringify(evidence,null,2)+'\n');
    await browser.close();
    server.close();
  }
}
main().catch(error=>{console.error(error.stack);process.exitCode=1});
