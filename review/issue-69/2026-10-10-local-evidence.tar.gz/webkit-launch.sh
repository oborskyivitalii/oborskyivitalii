#!/bin/sh
TASK_WEBKIT_DIR=/root/.cache/ms-playwright/webkit-2359/minibrowser-wpe
export WEBKIT_EXEC_PATH="${TASK_WEBKIT_DIR}/bin"
export WEBKIT_INJECTED_BUNDLE_PATH="${TASK_WEBKIT_DIR}/lib"
export WEBKIT_INSPECTOR_RESOURCES_PATH="${TASK_WEBKIT_DIR}/share"
export WEBKIT_FORCE_COMPLEX_TEXT=1
export LD_LIBRARY_PATH="${TASK_WEBKIT_DIR}/lib:${TASK_WEBKIT_DIR}/sys/lib:/workspace/scratch/db6290e7c2fe/webkit-libs/usr/lib/x86_64-linux-gnu"
exec "${TASK_WEBKIT_DIR}/bin/MiniBrowser" "$@"
