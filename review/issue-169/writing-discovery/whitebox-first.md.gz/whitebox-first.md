# White-box QA — independent first judgment

Verdict: PASS for the bounded prepared-source correction; no defect found in the inspected delta. This is not hosted interaction, production publication, full Basic, release or editorial acceptance. AC04/05/10/11 have positive bounded evidence here; AC09's PDF/platform gates were outside this correction.

## Identity and input boundary

Role/task: distinct nonauthor White-box QA, /root/writing_whitebox, first judgment. Requested none-fork execution is the launch contract; accepted/provider-observed model, memory injection and hidden context internals are unknown to this execution. Shared filesystem is not isolation. No peer review contents, MEMORY, parent scratch notes or private history were read. A git stat exposed historical review filenames only, not review contents. No implementation or test changes, external writes, delegation or browser launch were performed.

Repository HEAD: d5e915feb3ba02d7a80325664c9d1d10a2ac494e. Prepared working-tree delta, not a clean commit. Packet candidate.json SHA256: 6b657e9369d3d1f6f1a39914422692700b1e29a6c6a768d76e0039d39d779691. Common prompt SHA256: 2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb. White-box prompt SHA256: 832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f.

Inspected README, AGENTS, common/role prompts, issue-169 acceptance policy, scoped CONTRIBUTING failure/reviewer rules, site source contract, check-profile allocation, actual d5e915f diff, renderer/validation/SEO call sites, actual existing tests and generated Writing. All 44 packet source hashes matched at execution, with no mismatches. No applicable nested AGENTS file was returned by the scoped inventory search.

Critical current SHA256 identities:

| Source | SHA256 |
| --- | --- |
| site/content/catalog.json | 7a71bf2254436e2c012183cdfbd2b13c68e35f6b168de8989986814cad875909 |
| tools/site/render-records.cjs | 85a0478ec37ffd65778b6f10dad08d420c42559ec2faeb15786ff983e7c4006c |
| tools/site/validate-catalog.cjs | 4da744f7bbe52cc96be5df9c6f035bf1de8c9cb394baf8f1d2b1f8af1b6b7ef1 |
| tools/check_site_seo.cjs | 0b749ddda512fc58e0b43ac9698a2548ffd9fedcff33f1961983f9afd69bf04c |
| tests/archive.test.cjs | 546137e445f799b911b8701c87242ab8c0053ed286c7f6d6d87e59367dd58666 |
| tests/content.test.cjs | 090a60f373c1eae445dacfed826eb4e9537b1c1511aa9611e6f98d4e01c17475 |
| tests/local-catalog-relationships.test.cjs | 92ea9789ed73567e84c38e7d53cccaff18430e0f1bfbba2c1b9e22b69820c554 |
| unchanged site/engine/archive.js | 0c1300428b3088c1fb4f6ba86461f228efabd3175100c7c1219df13631a1ccd3 |

## Independent oracle and structural allocation

| Risk / AC | Structural fault | Scenario and independent oracle | Executed allocation |
| --- | --- | --- | --- |
| AC04/10 discoverability | grouping and row data-year disagree | Accepted target leads 2026/delivery in HTML, collection JSON-LD and existing archive state; English/year/topic/four tag intersections retain it; incompatible year/language hide it; reset restores complete count | existing content + archive tests; Basic/source B via source-tests registry; current hosted H remains separate |
| AC04 publication truth | archive classification creates observed date/event | Pending row has no time, datePublished/dateModified/publicationEvent or archiveYear in edition schema; presentation classification alone gives year | existing local-catalog/content tests; independent actual publication-30 edition-key assertions; workflow source inspection |
| AC04 dates | classification wrongly overrides observation | datePublished takes precedence over dateModified, which precedes archiveYear; absent all gives undated; dated row emits actual time and modified-only edited label | existing observed-event fixtures (2025/2027) plus independent helper/render branch probes |
| AC05 validation | unescaped arbitrary data-year or external override | Reject null, numeric, malformed/non-four-digit/zero and nonlocal values; accept string 1000 and 9999; reject 0999, 10000, fullwidth digits, trailing newline, false | existing local-catalog tests plus independent in-memory catalog probes; B/source |
| AC05 exact-source SEO | adapter accepts wrong predecessor, fake successor or changed current producer | Exact frozen predecessor hashes read from d5e915f; wrong predecessor map throws; changed before/after descriptors throw; injected newline into each changed producer and unchanged content.cjs throws at real restoration consumer; unrelated map preserved | existing content negative tests; successful SEO CLI; B/source |
| AC04/05 scope | unrelated route content changes silently | Complete old/current normalized non-Writing HTML differs only in one snapshot digest per route; existing SEO preservation proves all five routes against retained frames | independent old/current digest-only comparison + SEO CLI |
| AC09/11 external scope | source pass mistaken for public delivery/copy acceptance | Article source canonical remains null, R10 edition has no publication date/event; no PDF/platform/manuscript changes in inspected delta | source inspection; production/platform/PDF gates deferred to owning release route |

No asynchronous renderer state/cancellation or new storage/network behavior was introduced. Existing archive history/print/fallback coverage was executed as part of its small module; this is not measured branch coverage.

## Actual execution receipts

Commands ran from /workspace/scratch/f4dcb060a703/repo. Every execution completed below 60 seconds.

1. `timeout 60s node --test tests/local-catalog-relationships.test.cjs tests/archive.test.cjs tests/content.test.cjs`
   Exit 0, duration 4711.674482 ms. Raw tool chunk 8d9532. Complete accounting: tests 36, suites 0, pass 36, fail 0, cancelled 0, skipped 0, todo 0. Includes exact predecessor/successor and current-file newline fault injections; no implementation mutation. Temp fixtures are cleaned by test finally.
2. `timeout 60s node tools/check_site_seo.cjs`
   Exit 0, ~5.16 s. Raw tool chunk 61e2f3. JSON pass=true; index, research, writing, talks, credits each exactContentAndMetadataPreserved=true. Reported current hashes match packet (including Writing e80f275b13204d694a61022c06d640fe18d4220e0524b936824fe7846be15ee5).
3. Independent `node` stdin manifest/helper/render/boundary probes. Initial combined command exited 1 after successful 44-file manifest verification because reviewer incorrectly looked up article='the-sdlc-is-out-of-balance'; actual source article ID is sdlc-out-of-balance at publication-30. This is a reviewer setup error, not candidate failure. Inspected actual catalog before corrected lookup, preserving initial failure (chunk d22258).
4. Corrected independent probe used actual publication-30: first row/year and pending edition keys passed; 7 additional year-boundary probes passed; modified-only rendering/edited label, published-over-modified and undated fallback passed. Raw stdout:
   `{"independentCases":"PASS","first":"publication-30","pendingEditionKeys":["@type","name","url","inLanguage","author"],"boundaries":7,"dateBranches":4}`
   This combined command then exited 1 on an overly strict old/current normalized index HTML equality assertion (chunk 7b83de); normalizeHTML intentionally retains revision/snapshot identities. The assertion diff and subsequent minimal diagnostic identified a single snapshot digest change, not content drift.
5. Diagnostic `node` stdin, old docs read with `git show d5e915f:docs/NAME.html`; normalize both, compare after replacing only 64-hex digest values; print every changed digest and occurrence counts. Exit 0, 0.245 s, chunk 1cd272. index/research/talks/credits all equal after digest-only canonicalization; digest counts 10/10,10/10,9/9,9/9 respectively. Exactly one changed digest each: index 9c15723e…→6ab1b944…, research 4d3d841b…→0c50d969…, talks 2b7302a1…→4cbd43f3…, credits 899daade…→39441f2d…. Those are old/new snapshot namespaces; the successful stricter retained-frame SEO consumer separately binds producer bytes.
6. `sha256sum` on critical sources, packet/common/role prompts and `git rev-parse HEAD` returned the identities above. An inventory read command exited 1 because no nested AGENTS matched; another requested nonexistent registry path, reported missing and supplied no registry evidence. These read failures did not establish test selection acceptance. Check allocation uses inspected SITE-CHECK-PROFILES B/H obligations, not inferred registry freshness.

No prior source-final/source-corrected logs were needed or used to infer success. Newly executed source tests provide the accounting above.

## Limits / remaining owner work

No local browser attempted: supplied Chromium socket failure occurred before target page, so unchanged rerun would add no information. Native browser, hosted corrected year/tag/filter controls, reader navigation, mobile/no-JS served layout, downloaded PDF and production canonical/date/event observations remain unobserved by this role. Existing archive VM fixtures hand-assign target tag dataset in the new test, so they prove archive composition, not the real lazy tag producer; actual hosted tag population remains H and existing article-tags source owner evidence. No full matrix, Basic, source-test selection campaign, rights/native publisher, RI rebuild, all offline exports or immutable snapshot retention checks were executed. Do not promote this bounded PASS into any of those gates.

Only assigned output artifact was authored. No implementation/test fix is proposed. Recheck these source identities against final candidate before accepting this judgment.

