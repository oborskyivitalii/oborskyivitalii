# Exploratory / Interaction QA — first result (initial phase)

Role execution: distinct nonauthor `/root/writing_exploratory`; first judgment, before reconciliation. Requested launch isolation is supplied by orchestrator; provider context/memory internals unknown. Shared filesystem is not isolated. I have read only supplied candidate packet, common/role prompts, acceptance file and relevant check-profile excerpts. No peer output, MEMORY, implementation, parent private notes or conversation was read. No implementation edits, external writes or delegation.

## Input identities

- Packet `candidate.json`: SHA-256 `6b657e9369d3d1f6f1a39914422692700b1e29a6c6a768d76e0039d39d779691` (verified bytes).
- Common prompt `agents/reviewers/README.md`: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` (verified bytes).
- Role prompt `agents/reviewers/exploratory-interaction-qa.md`: `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a` (verified bytes).
- Owner issue #169, PR #170; predecessor head `d5e915feb3ba02d7a80325664c9d1d10a2ac494e`, base `8cf15883125892710633b17133d9ee0fc4b23b92`. Prepared correction is not described as a clean checkout or release.
- Acceptance source: `.github/acceptance/issue-169.json`; AC04/05/09/10/11 and delivery/visual/independent gates. Relevant public UI invariants come directly from packet's accepted discoverability scope.

## Independent bounded charter (designed before interaction judgment)

Initial time bound: six minutes; original hosted predecessor can establish the failure, never a current-candidate pass. A later precise corrected URL and source identity are required for candidate interaction judgment.

1. All filters at default: target article appears first in 2026 / AI-assisted delivery; preserve honest pending publication/date wording.
2. Select 2026; select delivery; combine 2026 + delivery + English. Target remains visible and first in relevant group. Ukrainian excludes the English edition; switch back/reset recovers.
3. Independently select each of the article's four tag labels (AI-assisted delivery, Software economics, Verification, Operating models); target remains discoverable, including combined compatible year/topic/language state.
4. Reset clears accumulated filters and restores full archive. Select an incompatible combination to check empty/recovery only if bounded time permits.
5. Follow target title to actual reader; heading and actual reader origin/path match target, then navigate back.
6. Applicable narrow/mobile normal and no-JS Writing/reader are required surfaces, not N/A. Assess supported browser controls without inventing unavailable viewport/script APIs. Native physical-device/human usability proof is out of scope. Missing local Chromium is a capability blocker, not N/A.

Current environment: supported CUA remote Chrome, browser ID `1`/`cdp`, own tab `5`; accessible native/DOM state, documented Playwright locators. Local Chromium reported launch failure before target (`socket() EPERM`) is packet evidence only; I did not rerun it.

## Initial observed evidence (predecessor only)

Opened supplied `https://bc200c76.oborskyi-author-ci-staging.pages.dev/writing.html`; browser visibly redirected to `https://bc200c76.oborskyi-author-ci-staging.pages.dev/writing`.

CUA createBrowserTab raw accessibility output: staging badge `STAGING · d5e915fe`; default Topic All topics / Year All years / Language EN + UA / Tag All tags, `30 articles`. 2026 section has 9 articles; delivery's first row is 17 Jun 2026 Ukrainian article. Target is in final `Publication date not recorded` section, one article, AI-ASSISTED DELIVERY, `EN · English · Article · Author site`; target title exactly `The SDLC Is Out of Balance: Beyond the AI Code Review Bottleneck`. Four tag links visible: AI-assisted delivery, Software economics, Verification, Operating models.

This is an executed predecessor failure against the intended corrected placement, not a defect newly found in the unhosted correction. Current-candidate UI: NOT OBSERVED / PENDING corrected immutable preview URL.

Executed predecessor follow-up: `getByRole(combobox, Year).selectOption(label=2026)` changed observed URL to `/writing?year=2026`, heading `All topics · 2026 · EN + UA`, `9 of 30 articles`; target and undated section disappeared from current accessibility tree. Reset click restored `/writing`, All years and `30 articles`, including target at undated bottom. These raw CUA tool results are the execution evidence; no screenshot/hash is invented.

## First verdict and finding

**Current-candidate interaction acceptance is pending, not passed.** The actual surface is applicable. Predecessor defect independently reproduced: high severity, predecessor `/writing` final `results-year-undated` / target row and Year filter. An English author-site article meant to lead 2026 delivery is sorted into undated and removed by selecting 2026; this defeats the requested discoverability (AC04/DELIVERY and affected related-reading discoverability AC10). Treatment: inspect the precise corrected hosted candidate and execute charter before advancing dependent UI gate. No acceptance is inferred from local source tests, packet claims, or an absent browser.

Profile routing: `guides/SITE-CHECK-PROFILES.md` Content update requires ordinary hosted smoke plus no-JS Writing and every rebuilt article journey; compatible Staging regression requires exact affected desktop/mobile normal/no-JS observations. The bounded current charter belongs to those existing hosted/reader observations; no new suite/matrix is proposed. Exact native job evidence can satisfy remaining surfaces when source-bound; it is not yet observed by this reviewer. No-JS/mobile and corrected reader link remain not observed, not N/A. No physical mobile device or human visual acceptance claimed.
