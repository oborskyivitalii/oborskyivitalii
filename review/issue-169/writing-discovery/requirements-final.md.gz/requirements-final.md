# Requirements & Acceptance — completed prepared correction

Role `/root/writing_requirements`; same-role correction continuation, 2026-11-06. First judgments remain preserved in `requirements-first.md` and `requirements-binding-preflight.md`. No peer reconciliation/results, MEMORY.md, parent notes or private history were read. This execution is not a newly fresh-context launch. Repository issue169 / PR170; working candidate based on `d5e915feb3ba02d7a80325664c9d1d10a2ac494e`, uncommitted prepared delta. Packet base `8cf15883125892710633b17133d9ee0fc4b23b92` remains historical supplied identity. Candidate packet SHA256 `6b657e9369d3d1f6f1a39914422692700b1e29a6c6a768d76e0039d39d779691` verified.

## Own verdict

**PASS for the completed prepared correction’s requirements and bounded local acceptance evidence. No unresolved requirements defect blocks corrected staging. Production advancement remains blocked until actual corrected hosted Writing/reader interaction and the existing release gates are observed.** This is not whole-issue acceptance, a browser pass, a merge or a publication claim.

The candidate implements the supplied user intent within the previously reviewed boundaries. The accepted R10 article now leads ordinary HTML and ItemList under2026 / AI-assisted delivery. A shared archive-year selector supplies grouping and data-year; the catalog’s presentation-only2026 classification supplies neither a publication date nor a publication event. Real edition dates take precedence and missing classification preserves undated. Local-only bounded validation is enforced together with the preexisting accepted committed-source checks. Canonical observation remains pending.

The workflow now explicitly requires verifying intended Writing year/topic placement and filters in ordinary HTML and the browser before release, including while publication is pending. This closes the process gap that allowed a source-valid article to remain undiscoverable through its intended year filter. It retains the existing exact served-edition gate before recording actual dates/canonical/events and the later author-manual platform sequence.

## Direct findings and preservation checks

No new blocking finding in this role’s scope. The original archive placement failure is corrected in generated output and exercised by the existing suites. The companion producer-binding refusal is corrected by an exact additive two-file successor chain; issue159 and event-migration ledgers retain their bytes and full current-file verification remains.

I independently parsed predecessor/current Writing ItemLists: total30; target occurs exactly once and is first; all29 other primary edition objects and their relative order are identical. Target schema contains title/URL/language/author and no datePublished/dateModified/archiveYear/event properties. Generated HTML places the date-free target row first in the2026/delivery group with matching data-year. The ordinary reader destination exists. This establishes structure and available local link target, not a successful browser navigation.

Protected-source Git diffs against d5e915f are empty for `site/publications/`, article media, `site/content/article-tags.json`, `site/engine/`, issue159’s content amendment and the event-migration record. Therefore the manuscript, semantic edition, metadata, PDF/material source, visuals and platform preparation owners remain unchanged by this correction. The generated reader diff only changes route/snapshot identities. Home/Research/Talks/Credits whitespace-normalized complete main regions are identical to d5e915f. Generated snapshot/preview identity churn does not introduce new editorial content; final build/artifact freshness remains an existing check gate.

The new producer adapter fixes exact expected before/after hashes for render-records and validate-catalog, checks immutable d5e915f predecessor bytes and leaves all other bindings unchanged. The tests reject wrong prior bindings, altered predecessor/successor record hashes and extra bytes in both changed producers plus an unrelated producer. The original current-versus-canonical event content tests now execute past that refusal and pass. Historical ledger updates, wildcard admission and event-semantic changes are absent.

The archive VM case injects the existing four tags into its row model, so it proves filter composition with tag data rather than real network hydration. Its row-first assumption is anchored by the separate content case’s literal article URL. The unchanged real-tag suite verifies catalog/index completeness and runtime tag behavior. Actual hosted filter/reader interaction is still needed; source/model tests do not replace it.

## AC → check → result → next gate

| Intent / retained AC | Independent check or oracle | Observed outcome / remaining gate |
| --- | --- | --- |
| Correct Writing discovery; AC04 and R4 discovery amendment | Literal target URL first in current2026/delivery HTML and ItemList; all records unique, other records/order retained | PASS direct output inspection and content case. Actual corrected hosted placement not observed. |
|2026/topic/language/tag filters and reset; AC04/10 | Existing archive VM tests with inclusion, mismatching year/language exclusion, all four tag choices and reset; real tag/index suite | PASS local execution. Actual desktop/mobile/no-JS reader/filter observation remains required in existing hosted route. |
| Honest pending publication; AC04/09 | Date-free schema/time, valid local source, invalid/nonlocal overrides rejected, undated fallback, actual2025/2027 event-bound dates override2026 presentation | PASS local cases/source and generated schema. Existing event/canonical production gate retained. |
| Reader/PDF/related scope; AC04/09/10 | Literal stable reader destination, local existence, unchanged article/PDF/material/visual/tag owners; existing link/tag/self-exclusion checks | PASS bounded source/local checks. Actual hosted reader/PDF/related destinations and layout not observed in this execution. |
| Source-bound hygiene/independent review; AC05/11 | Exact two-file successor plus immutable predecessors, malformed-binding and full-file mutation refusals, preserved ledgers/frames | PASS inspected source and independently executed cases. Other role results and current Basic/style/RI/issue/build/hosted evidence remain orchestrator gates. |
| CS01/02/04/05/08/10 | Existing catalog/validation/render/checker owners, one shared selector, typed data, focused existing-suite cases, explicit workflow gate | Applicable requirements linkage satisfied; no new runtime/controller/matrix. This review does not attest broader formatting/lint/style-guard runs. |
| Release authorization and publication truth; AC04/05/09/11 | Corrected current-source staging proof, identical-tree protected merge, production rights/archive/controller and exact served article/PDF/SEO validation | PENDING. Local browser launch reportedly stopped before page load at prohibited socket creation; that is not UI acceptance. Initial website release remains independent of the later manual LinkedIn/Medium pair. |

Whole original criteria stay open while required native/UI/release/human observations remain pending. The correction does not reopen editorial meaning or weaken the original distribution, PDF or related-reading requirements. No owner decision is missing for this bounded remedy.

## Actual executed verification

I inspected the supplied raw `source-corrected.tap`:46 tests,46 passed,0 failed/skipped/cancelled/todo. I then independently executed:

`timeout 60s node --test tests/local-catalog-relationships.test.cjs tests/archive.test.cjs tests/content.test.cjs tests/article-tags.test.cjs`

Result: exit0;46 tests,46 passed,0 failed/skipped/cancelled/todo; reported duration4469.18815ms. Tool execution receipt: chunk `d9159c`. This rerun was necessary to independently verify the supplied final46/46 claim on the actual candidate, and is limited to these existing suites. Original45/42/3 failure evidence remains preserved separately and is not relabeled.

All44 source-manifest entries matched the candidate packet before execution and again after execution. No implementation or tests were authored by this reviewer. A subsequent ad hoc inspection successfully printed output/scope comparisons but ended with FileNotFoundError due to my relative path for the candidate packet; I corrected only that manifest-read diagnostic using the absolute path, which returned no mismatches. This did not invalidate or rerun the passing source campaign.

Only this assigned review artifact is written. Tests used their normal temporary fixtures. No external mutations, browser operations or delegation occurred. Provider-injected memory/model/context internals remain unknown; shared-filesystem isolation is not claimed. No unexpected active-peer exposure occurred.

Next gate: use the existing authorized staging path for this exact corrected candidate, inspect actual Writing placement, all intended filters and reader link on the corrected served bytes, then continue the existing merge/production gates. Do not record an actual publication date/event/canonical observation or mark whole acceptance complete from this prepared-source verdict.

## Inspected identities

Hashes identify inspected bytes and do not alone prove behavior. Targeted owners/diffs and generated semantic regions were reviewed; large unchanged generated artifacts in the packet were hash-checked rather than exhaustively read. Existing common/role/source identities are retained from the first judgment; relevant current hashes follow.

| Source | SHA256 |
| --- | --- |
| `AGENTS.md` | `f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01` |
| `CONTRIBUTING.md` | `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442` |
| `agents/reviewers/README.md` | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| `agents/reviewers/requirements-acceptance.md` | `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6` |
| `.github/acceptance/issue-169.json` | `fcdf6622a5e6a0ba7e62fad828b82e14b2c6e8c75a96b18f97f12d1abc87025e` |
| `site/content/catalog.json` | `7a71bf2254436e2c012183cdfbd2b13c68e35f6b168de8989986814cad875909` |
| `tools/site/validate-catalog.cjs` | `4da744f7bbe52cc96be5df9c6f035bf1de8c9cb394baf8f1d2b1f8af1b6b7ef1` |
| `tools/site/render-records.cjs` | `85a0478ec37ffd65778b6f10dad08d420c42559ec2faeb15786ff983e7c4006c` |
| `tools/check_site_seo.cjs` | `0b749ddda512fc58e0b43ac9698a2548ffd9fedcff33f1961983f9afd69bf04c` |
| `guides/ARTICLE-WORKFLOW.md` | `b1b8c1bf8e2320ce74ce24d9837cce2bb0b2cb0e32b28b23f9658ef79cee3579` |
| `tests/content.test.cjs` | `090a60f373c1eae445dacfed826eb4e9537b1c1511aa9611e6f98d4e01c17475` |
| `tests/local-catalog-relationships.test.cjs` | `92ea9789ed73567e84c38e7d53cccaff18430e0f1bfbba2c1b9e22b69820c554` |
| `tests/archive.test.cjs` | `546137e445f799b911b8701c87242ab8c0053ed286c7f6d6d87e59367dd58666` |
| `tests/article-tags.test.cjs` | `a88f857081e50fc446f9901eeda2dcc500f6c2734190de0826e71ff660708d83` |
| `docs/writing.html` | `e80f275b13204d694a61022c06d640fe18d4220e0524b936824fe7846be15ee5` |
| `docs/articles/the-sdlc-is-out-of-balance.html` | `879917b7e7971077d711a848801412de633ce3a3a2448c7594156fc84ee55083` |
| `review/issue-159/content-amendment.json` | `8d6e8736f11089ab76ca9a494c988be68516d3c7e54cee3afab20131d2e5bf4c` |
| `review/issue-122/2026-10-24-r3-events-migration.json` | `3d5031a4ca8f256994dbafbf0e393ac0af900144dab4f74a4c67f0d2e4a03949` |
| `site/content/article-tags.json` | `dc314dcdd2871ecc368dd014739dffc9767bc6767347133411f2d47e51c20a73` |
| `writing-review/candidate.json` | `6b657e9369d3d1f6f1a39914422692700b1e29a6c6a768d76e0039d39d779691` |
| `writing-review/source-corrected.tap` | `c569a4ae4104ff578be9062769b76fc5f04dee4a1cdbddbc8c3fc97a4896d565` |
