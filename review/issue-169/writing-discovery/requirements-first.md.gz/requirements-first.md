# Requirements & Acceptance — independent first preimplementation judgment

Role/task: `/root/writing_requirements`. Phase: preflight, first judgment; no reconciliation received. Observation date: 2026-11-06. Repository: `oborskyivitalii/oborskyivitalii`, issue169, PR170. Inspected clean local HEAD `d5e915feb3ba02d7a80325664c9d1d10a2ac494e`; packet base `8cf15883125892710633b17133d9ee0fc4b23b92` is supplied identity, not independently compared here. Live issue169 was open, updated `2026-11-06T10:57:47Z`; live PR170 was open/unmerged and reported the same current candidate. No remedy implementation diff exists at this preflight.

## Own verdict

**PASS for bounded implementation preparation; NOT final acceptance or production readiness.** The supplied intent is specific and verifiable: the accepted R10 article must be first within Writing’s 2026 / AI-assisted delivery group, retained in the existing filters and linked to the reader. The live owner’s R4 discoverability requirement and subsequent authorized website release support this correction under original AC04/05/09/10/11. No new editorial, publication-controller or platform-posting authority is needed or supplied by this review.

The proposed presentation-only archive classification is proportionate and compatible with the site-first publication boundary, provided the constraints and independent outcomes below are met. This is a presentation year, not a claim that publication occurred in 2026. The article’s accepted status and committed R10 source are independently present in publication.json and the R10 edition record. The metadata still has `canonical: null`, and the catalog edition has no publication/modification date or event reference. Keep those distinctions.

A smaller existing configuration route was examined: `structuredOrder` already places publication-30 first. It cannot meet the stated 2026 grouping requirement because `writingEntries()` derives undated and sorts that year last. Moving the undated section or inventing dateModified/datePublished would either miss the explicit year-filter outcome or violate observed-publication semantics. A bounded field within the current catalog, consumed by its existing owners, is a reasonable remedy; its exact spelling is not a requirement.

## Findings and necessary treatment

1. **Medium, current release blocker — article is classified out of its required archive section.** `site/content/catalog.json:830–856` declares publication-30 as local/accepted-source-backed with delivery topic and first structured order but no observed date. `tools/site/validate-catalog.cjs:176–194` maps it to undated, then places that year last. A read-only Node diagnostic actually returned 30 entries, target year `undated`, order0, and target as the last entry. `tools/site/render-records.cjs:53–60` independently derives data-year from dates, so changing grouping alone would still fail the 2026 JS filter. This affects AC04’s discovery/distribution behavior and the owner’s R4 Writing discovery obligation. Treatment: one shared archive-year selection must drive both grouped HTML and row data-year; preserve original within-topic order and current dated behavior.

2. **Acceptance constraint, not a separate defect — preserve publication truth.** `guides/ARTICLE-WORKFLOW.md` site-first sequence requires exact served-edition proof before canonical/date/event observations. Classification must not insert dates, event references or schema.org date properties; no empty/fabricated time element. Local accepted-source validation must remain mandatory. Actual observed dates must take precedence when later supplied through the existing event-bound route, including a different year. External editions must not acquire this local-preparation override. Use a bounded explicit year representation and reject malformed values; missing classification retains current undated behavior. Do not derive year from edition-ID spelling, machine clock or approval timestamps.

3. **Acceptance evidence gap until correction — existing green checks cannot alone prove the intended placement.** `tests/content.test.cjs:45–84` checks HTML/schema edition parity and absence of invented dates; existing local-catalog tests deliberately cover undated accepted preparation. These are useful invariants, but neither currently asserts the new article’s exact 2026/delivery placement. Add focused positive and meaningful negative cases in those existing selected suites, and require actual normal/no-JS hosted interaction through existing checks. No new matrix is justified. This is expected work for the proposed correction, not a finding against an unimplemented candidate.

## Intent → AC → independent acceptance oracle

| Intent / retained criterion | Required check or gate | Current observed result / limit |
| --- | --- | --- |
| Proper Writing section; AC04, R4 discovery | Literal expected publication-30 identity is the first article in the 2026/delivery group in generated ordinary HTML. Same placement in JS and no-JS. All30 records remain exactly once; no unintended other-record reorder. | Source diagnostic confirms current failure: target last/undated. No corrected output observed. |
| Working archive discovery; AC04/10 | Browser selects year2026, topicdelivery, languageen and each existing tag (`ai-delivery`, `software-economics`, `verification`, `operating-models`), separately and in compatible conjunction. Target stays visible and count/group visibility agree. A mismatching year/language excludes it; reset restores it. | Current data-year derives undated; actual UI interaction not performed by this role. |
| Reachable reader; AC04/09/10 | Ordinary link remains `articles/the-sdlc-is-out-of-balance.html`; follow it in desktop/mobile and applicable no-JS. Verify accepted R10 reader, materials/PDF and related destinations through existing reader gates. No self recommendation. | Source link and accepted R10 identity observed; served reader/PDF not observed here. |
| Classification is not publication; AC04/09, site-first amendment | Assert literal classification2026 while primary edition/schema retain absent datePublished/dateModified/events and no fabricated time. Invalid/nonlocal override rejected; missing override retains undated; supplied actual2025 or2027 date wins over2026 classification. Preserve existing event refusals. | Existing source invariants support these expectations. Correction tests not authored or executed by this reviewer. |
| Scope preservation; AC04/09/10 | Diff/hash parity for R10 manuscript, semantic edition, PDF, five visual sources and platform exports. Existing tag vocabulary/assignments and recommendation engine retained. | Publication.json and R10 edition inspected; no semantic/artifact change authorized. Full artifact parity reserved for final diff. |
| Source-bound hygiene/style; AC05/11, CS01/02/04/05/08/10 | Existing catalog/render/validation owners, one concern/one selector, no engine content literals; bounded style guard, existing selected source suites, Basic/build freshness/RI/issue policy, four independent role results bound to final source. | Source registry includes local-catalog suite permanently in pr-targeted/staging/production. No final checks run here. RI/style alone never satisfy native acceptance. |
| Continue authorized release; AC04/05/09/11 | Exact corrected source → current staging/hosted proof → protected identical-tree merge → production rights/archive/controller → exact served article/PDF/SEO observation. Record actual dates/canonical/site event only after proof. | Live PR is unmerged. Staging observation is supplied in packet, not independently retrieved here. Production remains pending. |
| Platform distribution; AC04/09/10 | Complete prepared matching copies preserved. Author posts manually after actual website verification; observe both actual platform URLs/backlinks before one later reciprocal-materials update. | Later manual pair remains outside this correction and does not block initial website release. |

These oracles assert observable identities and outcomes independent of any new selector helper. Tests that merely compare helper output with the same helper used by rendering are insufficient. The actual-date precedence scenario must use a valid source/event-bound fixture, rather than bypass existing publication validation.

## Open decisions and next gate

No new material owner decision is necessary within the supplied scope. Four-digit value/domain and exact field validation are routine implementation choices, with default and precedence explicitly documented/tested. The2026 classification is accepted input from this packet, not a year inferred by this reviewer from actual publication evidence.

Before dependent release advancement, fix the current grouping/filter mismatch, preserve source/artifact boundaries, run the existing checks and obtain affected final independent reviews on exact changed hashes. Final Requirements review must inspect the actual diff, added cases and their results; this first judgment cannot be relabeled as completed-candidate acceptance. No whole AC or issue closure is established.

## Isolation, evidence and limits

I read the common contract, this role prompt and authoritative sources directly. No MEMORY.md, current peer output, parent scratch notes, private history, implementation edits, external mutations or delegation were used. The source packet’s proposed treatment was treated as a review subject. Live issue/PR bodies include historical authored summaries and past review claims; those were not used as independent proof of acceptance or current reviewer execution. No unexpected active-peer output exposure was observed. The assigned launch requests no inherited author conversation; provider-injected memory/model/context internals and shared-filesystem isolation cannot be attested by this execution.

Only a short read-only Node classification diagnostic was executed; it completed successfully and confirmed current failure. No browser, native publisher, Basic, RI, build, PDF rendering or production checks were executed by this role. The supplied staging UI observation is not my direct UI observation. Source reads were targeted; entire large inventories were not semantically audited. Live issue/PR were retrieved through GitHub on this date; their retrieval has no independently retained byte-hash in this artifact, so live textual provenance is identified by URL/update time and cannot substitute for immutable final evidence.

Packet SHA256: `e88ba6274247352338d7714cbac260d3ed2fda967dd995f08bda5f4e2b2a8266` (verified). Every inspected file covered by the packet manifest matched its supplied SHA256 before this judgment. Extra hashes below identify actual source bytes, not full comprehension or runtime proof.

| Inspected source | SHA256 |
| --- | --- |
| `AGENTS.md` | `f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01` |
| `CONTRIBUTING.md` | `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442` |
| `agents/reviewers/README.md` | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| `agents/reviewers/requirements-acceptance.md` | `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6` |
| `.github/acceptance/issue-169.json` | `fcdf6622a5e6a0ba7e62fad828b82e14b2c6e8c75a96b18f97f12d1abc87025e` |
| `README.md` | `6cfbf71fad0822cbd4d756afb76b2fd29cdd7b203541b098bfba040e2c24231e` |
| `REPOSITORY-MAP.md` | `debffe8e6e69fd9355e85a050bec93cd14e61cb332483bd57170ebb3bafa3633` |
| `site/README.md` | `6696e8f54d09d314ad1b0dda5249dffbcd1a1a6e80c62316ec5d2dabe7e50436` |
| `site/content/catalog.json` | `ca5ad58534246c0ec225019d4b8a331261a9b5b857561c81aa28496875cb8e2e` |
| `site/content/article-tags.json` | `dc314dcdd2871ecc368dd014739dffc9767bc6767347133411f2d47e51c20a73` |
| `tools/site/validate-catalog.cjs` | `6a61f3af40e94c42b4240c1afb21a2a25474f2cf58381a2c40f12dea12becc6c` |
| `tools/site/render-records.cjs` | `24f1bec530b762009a6b03a1d91700e7ee5c56345a0b8d9a4a4c6f0ff561038c` |
| `site/engine/archive.js` | `0c1300428b3088c1fb4f6ba86461f228efabd3175100c7c1219df13631a1ccd3` |
| `tests/content.test.cjs` | `920f4a764d9d44d0ca61450d725561e75120efd887228975388f9c5021925e81` |
| `tests/local-catalog-relationships.test.cjs` | `d7717709066db9f8330b547961d611f35c25995774117086e6a22ed80e4e210a` |
| `guides/ARTICLE-WORKFLOW.md` | `ec21bfb325841f2b428ce80ec71201756f3afd8b806b0364907d424a1122fa93` |
| `guides/CODE-STYLE.md` | `cdef877504055734d653af12237fc708f3e3636dd15dfc0703f71e0f6c87ee40` |
| `review/issue-169/native-check-allocation.md` | `1e4470b9778a818b94fca1da37106c80b4f3f9f723b9cce7dd2c0d0e5c523a98` |
| `tools/quality/test-profiles.json` | `5d3bb52fc8cd46de5c3744b787a349ee86fbe41ebb488846194a40c75965beb7` |
| `site/publications/sdlc-out-of-balance/publication.json` | `850664d62796a9a7023fb5b4115a3a70e590ddb215faa4e06fe552b194f21f4a` |
| `site/publications/sdlc-out-of-balance/editions/sdlc-out-of-balance-en-r10-20261106.json` | `19b68f7a9ce5e5e5fd11b1333226bd63e5206e3df298970312c6fe212fb90610` |
