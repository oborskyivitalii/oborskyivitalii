# Independent Code / Artifact Review — first result

Verdict: **PASS for the scoped prepared source/artifact correction; no blocking code findings.** This is not release approval, hosted UI acceptance, or proof of publication. No implementation or tests were authored by this reviewer.

## Identity and limits

- Role/task: distinct nonauthor Code / Artifact Reviewer, `/root/writing_code`, first judgment.
- Repository: `/workspace/scratch/f4dcb060a703/repo`; observed HEAD `d5e915feb3ba02d7a80325664c9d1d10a2ac494e`. Reviewed delta from that commit to the dirty working candidate, including six new untracked snapshot files. Packet's wider PR base is `8cf15883125892710633b17133d9ee0fc4b23b92`; this review does not repeat the entire PR.
- Packet: `/workspace/scratch/f4dcb060a703/writing-review/candidate.json`, SHA-256 `6b657e9369d3d1f6f1a39914422692700b1e29a6c6a768d76e0039d39d779691`. All 44 supplied path/byte manifest entries matched at inspection and final readback.
- Common prompt `agents/reviewers/README.md`: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/code-review.md`: `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Tracked binary diff SHA-256: `05696a64ff4b7ed067c23d5ce3c483d18ba2a95a46792c2c210078e7b30634ff`. This digest excludes untracked files; their six exact hashes were independently checked against the generated output lock.
- Read supplied source packet, repository instructions, README/source/style contracts, applicable CONTRIBUTING review protocol, actual authored diff and its source consumers, changed tests, relevant existing tag tests, maintained test-profile routing, generated ordinary HTML and lock/preview/retention manifests. No nested AGENTS files were returned for the affected source directories.
- Did not read MEMORY, current peer reviews, author conversation, parent scratch notes or private history. No unexpected peer verdict exposure observed. Actual launch/fork response is owned by the orchestrator; provider context/memory internals are unknown to this reviewer. Shared filesystem is not an isolation boundary.
- Read-only bounded commands, each under 60 seconds; no external writes or delegation. Only this assigned artifact was written. Node tests used their normal temporary fixtures. No browser was launched. Corrected hosted UI, production, physical devices, full Basic/CI and all article/PDF/platform editorial gates were not observed here.

## Source and artifact findings

No blockers or required source fixes found within this delta.

1. **Classification stays separate from publication.** `site/content/catalog.json` adds only `presentation.archiveYear: "2026"` on the local SDLC record. `tools/site/validate-catalog.cjs` validates a four-digit string beginning 1–9 and forbids the override on implicit/explicit external records. Its shared `archiveYear()` gives observed `datePublished`, then `dateModified`, precedence. `writingEntries()` and `render-records.cjs` consume the same result. The fallback does not enter the edition object, time element, publication event, JSON-LD publication date or canonical observation. Legacy dated records retain their original ordering/HTML. Tests cover earlier/later observed years, malformed values, external misuse and undated fallback. Relevant to AC04/05/10 and CS01/02/04/05/08.
2. **The actual public candidate has the intended reader path.** Ordinary `docs/writing.html` places the article first inside 2026 / AI-assisted delivery; its ItemList has the same first destination, all 30 rows remain, and the 2026 count becomes 10. The empty undated section/control disappears because no undated rows remain. The row has `data-year="2026"`, `data-topic="delivery"`, English language and the proper native reader href. Unit filtering covers year/topic/language, all four tags and reset; existing tag tests separately cover real catalog index assignments and hydration to stable/immutable article destinations. The new archive unit test itself supplies tags on its fake row, so it is not evidence of real browser hydration. Hosted interaction remains an explicit separate gate.
3. **Exact two-producer companion is bounded.** `tools/check_site_seo.cjs:416–456` freezes exactly `render-records.cjs` and `validate-catalog.cjs`, their predecessor/current SHA-256 pairs, and immutable predecessor commit `d5e915f`. The adapter rejects alternate successor mappings and wrong predecessor bindings, reads/hash-checks the actual Git predecessor bytes, then updates only those already-present bindings. Home/Writing/events consumers retain complete inventories and hash every current producer before comparing current generated regions. Missing producer entries therefore cannot bypass their downstream checks. Negative tests modify each of the two producer bytes and unrelated `content.cjs`, and reject the modified event producer. This is a specific companion to the existing adapter, without replacing its historic authority or admitting arbitrary successors.
4. **Historical and generated boundaries remain intact.** No delta exists in `site/retained`, `review/issue-122`, `review/issue-159`, `site/publications`, or `site/assets/publications`. All 50 retained manifest files are still present in `docs` with their declared bytes. The six removed snapshots were the prior candidate's current generated versions; six new versions are correctly referenced in current output. All 85 output-lock files match disk bytes, including new snapshots. All 31 static-preview source/file bindings match. Ordinary article content is byte-identical after accounting for its route/snapshot identity lines; four other ordinary routes change only their route identity. The offline bundle JSON was inspected as a generated manifest; its physical ZIP was not separately unpacked/verified here. No PDF, manuscript, figure or external edition changes were observed.
5. **Tests have a maintained allocation.** The changed content, local-catalog and archive suites already have permanent profile entries and the existing content-source mandatory selection; no new test matrix/controller is introduced. The new tests exercise actual rendered rows/JSON-LD, date precedence and invalid inputs rather than asserting implementation source text. Workflow prose correctly requires ordinary/browser placement review while reserving observed date/canonical/events for verified production. Relevant to AC05/11 and CS08/10.

## Actual checks and evidence accounting

- Independently executed `node --test tests/local-catalog-relationships.test.cjs tests/archive.test.cjs tests/content.test.cjs`: **36/36 pass**, 0 failed/skipped, approximately 4.4 seconds.
- Independently executed `node --test tests/article-tags.test.cjs`: **10/10 pass**, 0 failed/skipped, approximately 2.3 seconds. Combined independent suite observations are 46 tests, not one 46-test invocation.
- Independently executed `node tools/check_site_seo.cjs`: **pass**, all five exact-content/metadata preservation rows passed. This is bounded source/output preservation evidence, not publication or dynamic UI proof.
- Independently executed `python3 tools/check_code_style.py`: **pass**, 156 files; only its declared inline-style/reserved-token/history/literal-import subset. Manual inspection also examined source ownership, shared year logic, escaping/validated bounds, frozen provenance and current test allocation.
- Read permitted raw `source-corrected.tap`: records **46/46 pass**. Read permitted original `source-final.tap`: retains the prior exact-producer mismatch failures, including expected old versus actual changed renderer SHA. The corrected companion addresses that failure mechanism without changing old ledgers. The predecessor failed result remains failed historical evidence.
- Independently read/hash-checked packet, manifests, current files and generated closure as above; no unexplained manifest drift at final readback.

## Inspected core current identities

| Path | SHA-256 |
| --- | --- |
| `site/content/catalog.json` | `7a71bf2254436e2c012183cdfbd2b13c68e35f6b168de8989986814cad875909` |
| `tools/site/validate-catalog.cjs` | `4da744f7bbe52cc96be5df9c6f035bf1de8c9cb394baf8f1d2b1f8af1b6b7ef1` |
| `tools/site/render-records.cjs` | `85a0478ec37ffd65778b6f10dad08d420c42559ec2faeb15786ff983e7c4006c` |
| `tools/check_site_seo.cjs` | `0b749ddda512fc58e0b43ac9698a2548ffd9fedcff33f1961983f9afd69bf04c` |
| `tests/content.test.cjs` | `090a60f373c1eae445dacfed826eb4e9537b1c1511aa9611e6f98d4e01c17475` |
| `tests/archive.test.cjs` | `546137e445f799b911b8701c87242ab8c0053ed286c7f6d6d87e59367dd58666` |
| `tests/local-catalog-relationships.test.cjs` | `92ea9789ed73567e84c38e7d53cccaff18430e0f1bfbba2c1b9e22b69820c554` |
| `docs/writing.html` | `e80f275b13204d694a61022c06d640fe18d4220e0524b936824fe7846be15ee5` |
| `site/output-lock.json` | `44640ed40c257dfa638e108141574579f9ea9b8c978f52d0147924ef80a89944` |

Remaining acceptance question: actual corrected hosted discovery/filter/reader behavior must be observed on the exact candidate before advancing its applicable UI/delivery gate. This source review supplies neither that observation nor owner/release approval.
