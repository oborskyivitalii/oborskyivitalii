# Requirements & Acceptance — producer-binding correction preflight

Role `/root/writing_requirements`; correction continuation on 2026-11-06. This follows my preserved `requirements-first.md` judgment. Input is the targeted correction question, current actual diff, authoritative source owners and raw failed-test output. No peer verdict or parent scratch notes were read. This is a bounded scope preflight, not a fresh-context completed-candidate acceptance.

**Verdict: PASS for the proposed necessary companion within issue169 / PR170 scope.** An additive, exact two-producer successor in the existing SEO checker can preserve the original archive correction’s accepted behavior while maintaining full historical-output controls. It does not require a new user decision, new publisher or broader test matrix. The current candidate remains blocked by the observed failures until the companion and affected verification are complete.

The causal link is supported directly. `reviewedProducerBindings()` in `tools/check_site_seo.cjs:416–425` first applies issue159’s fixed successors and the existing HTML-parser successor. `restoreEventsCatalog():727–756`, Home verification and Writing verification then compare complete current producer bytes against those bindings. Issue159 freezes the former render-records and validate-catalog hashes. The authorized archive correction changes exactly those producer owners: one shared archive-year selector replaces their two independent date-derived year calculations; it also validates the bounded local-only archive field. The earlier producer files therefore no longer match. This is an expected detection of changed bytes, not evidence of event-content corruption.

I read the preserved raw log: 45 total, 42 passed, 3 failed, no skipped/cancelled cases. All three fail at the same strict full-file check, with current render-records hash `85a0478ec37ffd65778b6f10dad08d420c42559ec2faeb15786ff983e7c4006c` versus frozen issue159 hash `24f1bec530b762009a6b03a1d91700e7ee5c56345a0b8d9a4a4c6f0ff561038c`. I did not rerun the unchanged failing campaign. The second changed producer has not yet been reached by those failing paths; its stale binding is nevertheless directly confirmed in source.

The immutable-predecessor premise was independently checked with `git show d5e915feb3ba02d7a80325664c9d1d10a2ac494e:<path>` and SHA256. For both paths, those immutable bytes match issue159’s existing afterSHA256 exactly:

| Exact producer | Immutable d5e915f predecessor | Inspected current draft |
| --- | --- | --- |
| `tools/site/render-records.cjs` | `24f1bec530b762009a6b03a1d91700e7ee5c56345a0b8d9a4a4c6f0ff561038c` | `85a0478ec37ffd65778b6f10dad08d420c42559ec2faeb15786ff983e7c4006c` |
| `tools/site/validate-catalog.cjs` | `6a61f3af40e94c42b4240c1afb21a2a25474f2cf58381a2c40f12dea12becc6c` | `4da744f7bbe52cc96be5df9c6f035bf1de8c9cb394baf8f1d2b1f8af1b6b7ef1` |

Required acceptance boundaries:

1. Preserve issue159 and all older producer pins, frozen frame text/hashes, producer inventories and baseline comparisons byte-for-byte. Add the exact successor in the current checker’s existing binding chain. The prior binding must equal its expected predecessor before advancement; immutable Git predecessor bytes must match the stated predecessor hash. Do not accept an arbitrary caller-supplied predecessor/successor, partial path matching, wildcard or regenerated historical ledger.
2. Admit exactly the two reviewed current files. Full current-file verification remains mandatory in Home, Writing and Events owners; a harmless extra byte must still reject. Other producers and inventories retain their current checks. Retain existing HTML successor behavior and frozen/current collection comparisons. Do not catch/skip the failures or change event semantics.
3. Existing-suite guard cases must independently establish the exact valid transition and reject a malformed predecessor hash/source/path or tampered successor record, including missing/extra producer entries where represented. A wrong initial binding must fail. Cases should check literal expected identities, not manufacture expected values by calling the same helper under test. Exercise at least one changed current producer-file mutation through its real verifier, and keep an unrelated-producer negative. Existing end-to-end content tests supply current-event-versus-source and historical-output checks after the binding guard passes.
4. Keep source-bound reviewer accountability: hashes identify the exact reviewed files but do not establish correctness alone. The archive behavior and this acceptance-check adapter need affected Code/QA and final Requirements review before advancement. If the changed producer bytes evolve after this inspection, refresh affected bindings/review; do not reuse this draft hash as evidence for a different file.

| Requirement / AC | Check or gate | Status and next observation |
| --- | --- | --- |
| Proper2026/delivery placement and honest pending dates; AC04/09/10 | Existing focused catalog/archive/content cases and actual affected UI | Original requirements unchanged; this companion grants no new grouping/date behavior. |
| Preserve source-bound validation; AC05/11, CS01/04/08/10 | Exact immutable two-file successor chain, full current-file equality, malformed-input and source-mutation refusals | Feasible and necessary; companion not implemented at inspection. |
| No unrelated event/Home/Writing content acceptance | Existing actual-source collection comparisons and immutable frame comparisons, with existing producer/inventory refusals | Current failures stop before content verification; require full affected suite after correction. |
| Scope/history preservation; AC04/05/09 | Diff review proves historical ledgers/frames and editorial/PDF/media/platform editions unchanged | No ledger rewrite authorized. No publication evidence produced. |

After the companion, rerun the failed existing content suite once on the changed candidate, retain both results and complete relevant checker/producer regressions through existing registered routes. A pass means these bounded content/provenance checks passed; staging, production, canonical/date/event observation and whole-issue acceptance remain their separate existing gates. The first preflight’s requirement that actual observed dates override archive classification and absent classification remain undated is unchanged.

Limits: read-only source/diff inspection and immutable-hash diagnostics only; no implementation/test edits, external writes, browser actions or delegated work. The assigned review artifact is the only file written. The focused21-pass statement was supplied by the orchestrator; I did not independently execute that campaign. Provider-injected memory internals remain unknown. Sources are shared working files and must be hash-matched at final review.

| Inspected source | SHA256 at this judgment |
| --- | --- |
| `tools/check_site_seo.cjs` | `f9ac3f6a4b17ce99289c9574a3217b6fe6b7735c4dae1dd1ae1df22a33c1d379` |
| `review/issue-159/content-amendment.json` | `8d6e8736f11089ab76ca9a494c988be68516d3c7e54cee3afab20131d2e5bf4c` |
| `review/issue-122/2026-10-24-r3-events-migration.json` | `3d5031a4ca8f256994dbafbf0e393ac0af900144dab4f74a4c67f0d2e4a03949` |
| `tools/site/render-records.cjs` | `85a0478ec37ffd65778b6f10dad08d420c42559ec2faeb15786ff983e7c4006c` |
| `tools/site/validate-catalog.cjs` | `4da744f7bbe52cc96be5df9c6f035bf1de8c9cb394baf8f1d2b1f8af1b6b7ef1` |
| `tests/content.test.cjs` | `a755fec6f8c47dcecd273916c916abaca0a8a791de9d790801cf0b19cc754302` |
| `tests/local-catalog-relationships.test.cjs` | `92ea9789ed73567e84c38e7d53cccaff18430e0f1bfbba2c1b9e22b69820c554` |
| `guides/ARTICLE-WORKFLOW.md` | `f5760ddc6728449d4fe6d6755817b3f74c477cac5b929b9e9e4be212908f5f58` |
| `site/content/catalog.json` | `7a71bf2254436e2c012183cdfbd2b13c68e35f6b168de8989986814cad875909` |
| `writing-review/source-final.tap` (raw execution log) | `f9da9f39da61306d03384fcb09d60ec22c8f6848a2c4d633aed54d6daec7eab6` |
