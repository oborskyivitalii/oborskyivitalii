# White-box QA — first independent judgment

**Verdict: PASS for the inspected, bounded source/test correction; no blocking source defect found. Browser/runtime admission and release acceptance remain NOT ESTABLISHED by this review.** The diagnostic run 42112795903 was described as running at launch. I did not retrieve its result or execute a browser, and do not treat source tests, a frozen HTML projection, or the diagnostic script's assertions as actual interaction evidence.

This first judgment precedes reconciliation. I read no current peer verdict, parent conversation, private history, author scratch notes, or historical review conclusions. Provider memory/context internals are unknown. Launch-parameter acceptance is the orchestrator's receipt obligation; it is not independently observable inside this reviewer.

## Inspected identity and scope

- Repository: `/workspace/scratch/83aaf5811f83/release-repo`.
- HEAD: `223456b4b928017703dedf1cca352ca4c5affedf`; tree `eb37f5eeb60f059d77a471a4af019ecee93c6851`; comparison `d3a49960714e5f158afba23d02dd0f8e871cb28e`.
- Clean `git status --porcelain --untracked-files=all` observed before and after checks.
- Packet `/workspace/scratch/5ba265a57f36/reviewer-packet.json`: SHA256 `b726f00ba9c4b65d37bc6c034be64aa6bf708ff2d06e90971f92eaf1b586fe6c`. Independently checked all packet-listed file byte lengths and SHA256 values: **zero mismatches**.
- Common reviewer contract SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`; CONTRIBUTING SHA256 `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442`.
- Read README, AGENTS, relevant CONTRIBUTING diagnosis/independence/QA protocol, acceptance issue169, original release intent, SITE-CHECK-PROFILES, actual changed runtime/tests/registry diff, unchanged archive lifecycle, article evidence validator, frozen resource fixture and bounded probe source/workflow. No nested AGENTS found in affected site/tools/tests/review trees.
- Scope: recent reading/history ownership; immutable entry resource geometry; native completion oracle; changed dependency selection. Original R9 manuscript/PDF/visual acceptance and complete release audit are outside this bounded source review.

## Risk → structural fault → scenario → oracle/check

| Risk / AC impact | Structural fault and scenario | Independent oracle and executed/design evidence | Allocation |
| --- | --- | --- | --- |
| AC04/05 DELIVERY: latest reading lost before debounce | Native pop selects incoming history before outgoing scroll/focus/disclosures can be persisted; Forward followed by Back within 350ms | Outgoing reading remains attached to its exact entry without writing incoming state. `navigation` executes latest scroll/focus capture, arrival timer, duplicate URL entries, immutable principal/article paths, new forward branches and capture guards. | Existing permanent navigation suite; PR changed-path, staging, production |
| AC04/05 DELIVERY: transient animation state overwrites saved state | Scroll timer fires with inert/departing/arriving DOM or stale navigation | Preserve captured departure/target until completed ready state; serial supersession cannot mount or resume stale work. Existing navigation cases exercise hidden/inert retargets, arriving timer guard, cancellation and failed-scroll native fallback/cleanup. | Same navigation suite |
| AC04/05/07 DELIVERY: archive mutated before measured departure | Capture listener ordering versus archive bubble listeners; article destination already owns URL | Foreign document must leave outgoing archive unchanged; same-document history must update filters. Archive test executes actual extracted router lookup with archive event behavior; navigation tests exercise capture-first dispatch. | Existing archive suite via Basic plus applicable permanent profiles |
| AC07/09 DELIVERY: immutable entry depth breaks PDF/image/header destinations | Browser remains at immutable history URL while canonical alias has different depth | Resolve generated resource relative URL against its immutable source, then against actual browser mount address; both must denote same target. Frozen projection test executes actual rebase/header code at root and project base. Independent bounded negative below confirms wrong alias depth is detectable. | navigation suite; new fixture is an explicit selection input |
| AC05 DELIVERY: watchdog/cancellation accepted as native completion | A principal-side phase bypasses paper-only validation | Every current departure/arrival phase must report `animationend`. Article evidence suite actually corrupts each ordinary/native-history leg and each phase with watchdog/cancelled/null/missing completion and requires rejection; valid current and historical cases retained. | Existing permanent article-browser-evidence suite; PR/staging/production |
| AC05 DELIVERY: owner edit silently omits consuming assertions | Missing registry dependency or broad fallback hides routing gap | Direct changed owner selects consumer without unknown fallback; unrelated theme remains excluded; task snapshots stay excluded. New selection matrix and existing complete registry/accounting failures executed. | Existing permanent test-profile-selection suite; PR/staging/production |
| AC07/09 DELIVERY/VISUAL: disclosures/overlays affect restoration | Restore scroll before disclosure geometry; stale listeners or failed dialogs | Restore disclosure geometry before scroll; close/dispose overlays and preserve native destinations on failures. Existing reader-mode suite executed. | reader-mode changed-path, content safety, staging/production; browser/device review separate |

## Structural conclusions

`site/engine/navigation.js:342–445` separates serialized current-entry saves from bounded recent departures. Captures require an incoming safe index different from the mounted index, no active request, available departure DOM and a known incoming route. Recent state is selected by index **and page and exact URL**, preventing another query/page/branch from borrowing it. Captures delete/reinsert the entry for recency, evict beyond 128, and fall back to serialized state. Both push paths prune abandoned forward entries. `save` retires recent state only after successful `replaceState`, and refuses arrival geometry as well as unavailable departure geometry. These invariants are backed by executed checks, including guard outcomes and eviction/fallback; this is not a claim of measured branch coverage.

`navigation.js:1311–1327` puts capture ahead of archive mutation; the normal listener obtains the same recent state for route scroll and same-document disclosures/focus. Mount and final focus use recent state consistently. `navigation.js:1200` passes the actual browser URL to mount/rebasing, which matters when immutable history keeps its original address while `address()` produces a canonical article alias. Original principal entry recognition is limited to its validated initial pathname; unrelated immutable principal paths remain unresolved.

`tools/quality/article-browser.cjs:1304–1310` applies native-completion checking to all current phase records rather than only phases containing reader paper. I found no weakening of the existing native completion guard. The executed negatives demonstrate refusal of the specified invalid completions, including the principal side of both history directions. No CSS frame or performance measurement follows from this source result.

The frozen resource fixture explicitly says `liveEvidence: false` and identifies prepared dirty generation. It is a useful stable geometry input, **not** evidence that the current generated artifact or browser fetched correct bytes. Its provenance hashes were not reinterpreted as current generated-file identity.

## Actual execution and raw result

Environment: Linux x64, Node `v24.22.1` (different from workflow-pinned `24.19.0`; hosted result remains separate).

Executed exactly once, no retries:

```sh
node --test tests/navigation.test.cjs tests/archive.test.cjs tests/reader-mode.test.cjs tests/article-browser-evidence.test.cjs tests/test-profile-selection.test.cjs
```

Raw completion:

```text
ℹ tests 145
ℹ suites 0
ℹ pass 145
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 11609.73463
exit_code 0
```

Tool execution stdout chunks: `e2d645` (initial), `f265d2` (continuation), `863ce0` (final accounting). These are local source tests, including VM/harness and renderer checks, not actual browser acceptance. No failed campaign was rerun.

Executed one additional read-only, in-memory resource-geometry negative. It extracted the actual `rebaseResources` function, used the fixture PDF href and immutable original browser entry under `/project/`, and compared final URL with `new URL(fixture.pdfHref, sourceURL)`. No implementation/test files changed.

```text
candidate-browser-base:
actual = expected = https://fixture.test/project/article-media/75e052d6a5c386ae79cb1a51d59cdf42e53d3a7279bf0db31c227ee145bb18b4/reading-r9.pdf
PASS
fault-canonical-alias:
actual = https://fixture.test/project/article-snapshots/article-media/75e052d6a5c386ae79cb1a51d59cdf42e53d3a7279bf0db31c227ee145bb18b4/reading-r9.pdf
expected = https://fixture.test/project/article-media/75e052d6a5c386ae79cb1a51d59cdf42e53d3a7279bf0db31c227ee145bb18b4/reading-r9.pdf
EXPECTED_FAULT_DETECTED
exit_code 0
```

This demonstrates that the URL equality oracle distinguishes the corrected browser-base geometry from the canonical-alias fault. It does not demonstrate HTTP availability or correct served bytes.

## Gaps and disposition

No implementation changes or new acceptance tests are proposed by this review. Existing useful cases have permanent ownership and explicit selection routes. SITE-CHECK-PROFILES maps PR Basic/additional source work to `site-checks.yml` / `checks`; staging and production retain their existing source allocations. The dated probe is separately dispatched by `site-navigation-probe.yml` / `chromium`, not promoted into routine acceptance.

The following remain unobserved here and cannot receive a pass: actual Chromium 40-case diagnostic outcome and complete accounting; real CSS events/frame/geometry/scroll/focus under browser scheduling; root/project immutable-link fetches and current generated bytes; runtime-family admission; no-JS/hosted delivery, Firefox/native devices, production/staging gates, rights/byte/frame/time budgets and full original AC completion. The probe source binds clean HEAD/tree, artifact, exact PDF and browser archive and accounts for planned cases, but only its actual retained result can establish those bounded observations. No earlier green runtime source was reused as current acceptance.

Residual structural partitions not exhaustively explored include browser-native hash entries lacking app state/index, browser history persistence failures across reload/BFCache, and overlapping native pop operations during in-flight navigation beyond the existing synthetic retarget coverage. These are limits, not reproduced candidate defects. Do not expand this review into a full release guarantee or infer a percentage of coverage.

# Same-role continuation — finite admission proposal, before final delta review

**Conclusion: the finite plain/staging registration and normal guarded private production derivation are justified as preparation. They do not establish full admission/release acceptance.** The mechanism can admit exactly the two observed tuples, preserve all historical tuples and mandatory reader/rights semantics, and leave production absent until its normal adapter output is inspected. Partial inheritance must explicitly set `production: null` (or otherwise omit it), because spreading the footer family also inherits its old production fingerprint.

This is a continuation of the preserved first result, not a new independent context. No peer verdict was read. New neutral inputs were the local raw diagnostic report and actual plain/staging artifacts/logs supplied by the orchestrator. I observed new implementation bytes appearing in the shared worktree while checking the proposal; they were not accepted by this pre-implementation assessment. The promised final full delta review remains necessary.

## Newly verified evidence

- `diagnostic-42112795903/r9-reader-runtime-probe.json`: SHA256 `b61435e2ce2d9cd036c7e64910ddfe1a05143b374e7ae02e384e09af32074d3e`, matches supplied identity. Reports exact commit `223456b4b928017703dedf1cca352ca4c5affedf`, tree `eb37f5eeb60f059d77a471a4af019ecee93c6851`, clean start/end, source/workflow/candidate equality, `pass: true`, `fullGate: false`, 134249ms against 240000ms.
- `plain-observed/artifact.json`: SHA256 `57d633fcbc4cf2cdc62fc3eb09e4223456896775bea7e1d25fe8352cf020f482`, exactly equals the diagnostic's `manifestSha256`. Independently rehashed every listed public file for both plain and staged local artifacts: **132 file entries match**.
- `staging-observed/artifact.json` and supplied CI `current-staging-manifest.json` are byte-hash-identical (`713f52109b3357a7403c0144ed16c0c8bf2775bf8194bc29ffa11577cb17630f`) and object-identical. Preview log from run42112254313/job127542766291 contains the actual `unreviewed Color motion runtime` failure through `publicationRequired`/staging package verification. That retained failure is consistent with absence of this new finite family, not evidence of a successful hosted preview.
- Independently checked report case IDs: 40 unique records equal the entire 40-ID planned inventory; every state is pass, no `notObserved` or evidence errors. Its four context records have empty JS/console/request-failure arrays. Its 24 normal legs contain exactly two blocks each, all 48 `completedBy: animationend`. Twelve restoration records retain expected scroll within2px and matching focus. Eight stored heading/footer start/end pairs match node identity and have positive native elapsed duration. All ten `sourceFiles` hashes match the inspected repository source bytes.

These are inspected retained CI observations, not a browser session performed by this reviewer. I inspected the probe oracle itself: transition requires actual normal motion, validated camera event sequence and two native-completed phases; refreshed heading checks the current connected text layer and native matching start/end without cancellation; footer checks the actual anchor self layer with real keyframes and positive duration. Restoration compares independently captured departure scroll/focus/query with the returned document. Report reading does not add physical-device, hosted, production, full browser-matrix or performance acceptance. The supplied local report/log origins were not independently fetched/authenticated from GitHub by this reviewer.

## Proposed exact finite registration

| Field | Observed value |
| --- | --- |
| New ID | `issue169-reader-history` |
| Base client | `68fa384f47c646e4f2bc7d96c645f42efa6dabf9b84f5f514af4b959f561f72c` |
| Color plain | `b6f3a98b4b0fb438ec1747952f050baa4b016fb4f6d942b8b364e37638af2768` |
| Color staging | `ace81eb56ccb8fca35099e960d684ca90aa855733c7a8e9dfe35eab66da84f78` |
| archive.js | `bf1b9e42356b282f3c08f7763a7a59263241c752df5dd9ee776a6b0bf86b0caa` |
| navigation.js | `0c447ce8a4a8a02835753d144939e14842bd407f735273e8820cf1ff9121cb3e` |
| Production during partial preparation | Absent, not guessed |

Existing styles/theme/space exactly match the inherited footer policy. This inheritance preserves fixed blocks, stationary reading, whole reader blocks, paper, deferred media, interactions and mandatory publication rights. Adding this exact base client to semantic-document checking enables the existing guard; it does not alias the new client to an old identity or relax byte/source checks.

## Bounded executed mechanics checks and failure accounting

I evaluated the proposal in memory, without editing implementation/tests, using the actual baseline from `git show 223456b:tools/quality/color-motion-contract.cjs` and actual supplied manifest values. Raw result (tool chunk `eeb6b2`, exit0):

```text
plainAndStageAccepted: 2
oldRuntimeTuplesUnchanged: 152
newRuntimeCount: 2
rightsStillRequired: true
readerPoliciesInherited: true
negativeRejections: 27
productionUnregistered: true
actualPlainSemanticDocumentsChecked: 12
missingMainRejected: true
duplicateMainRejected: true
```

The 27 negatives alter each of five runtime file hashes in its direct and immutable path for each edition, alter base/fingerprint, mismatch edition, and request the absent production family. All reject. Every one of the152 baseline runtime descriptors remains equal after the partial simulated addition. Existing semantic hook verification accepts all12 actual plain principal/article alias/snapshot documents and rejects missing/duplicate main hooks. These are reviewer diagnostic assertions, not new authored acceptance tests.

An earlier mechanics invocation exited1 after successfully completing public/report integrity checks (chunk `88a92c`). The shared worktree had acquired the new family, including a production fingerprint, between the initial clean read and this invocation. Its supposed baseline therefore already included production while the partial simulation removed it; comparing every baseline runtime then raised `unknown reviewed Color runtime`. I preserved that failure, inspected dirty status/current family (chunk `b105c1`), and changed the next check to an immutable `git show` baseline. This resolves a review-harness input race; it is not an unchanged retry or a candidate runtime failure. At that inspection the shared contract SHA256 was `a1b3c0d2cf346c2781bfd56703f1435257ea009171f85424b454f05478d0f3b0`; that newly authored full implementation is explicitly outside this partial proposal verdict.

## Guarded production derivation and next allocation

`tools/release/edition.cjs:build` calls `motion.select(record)` on the input Color manifest before dispatching to ordinary edition construction. `tools/site/edition.cjs:build` verifies input artifact bytes, refuses an already-applied edition, checks preview exclusion, computes the edition identity from the real renderer/inputs, writes derived documents/runtime paths and verifies the resulting snapshot. Its output can therefore be observed before the new production tuple is registered, without calling the lower-level builder directly or calculating/guessing a fingerprint. Preserve truthful source metadata and derivation parent identity; a derivation built with uncommitted contract preparation must retain `sourceDirty: true` and must not be represented as a clean accepted new source. Run on an isolated copy because the adapter writes its input directory.

The exported build alone does not supply all publication rights or release evidence: the CLI's rights-writing path and subsequent production verification/rights/package/source checks remain mandatory under the existing route. Registration of the subsequently observed production tuple needs the full delta review and real targeted tests. No generalized unknown-runtime fallback, fingerprint-only acceptance, source-dirty coercion, old-family rewrite, budget change or historical golden replacement is justified.

Reuse existing permanent `color-motion-contract` and `article-browser-evidence` suites for exact positive/byte/identity/edition/policy/native-completion negatives; reuse `reader-mode` and `navigation` for the already reviewed lifecycle. For the final delta verify new-family inclusion in their explicit inventories, new base semantic-hook negatives, preservation of old descriptors/goldens, exact guarded production output provenance and changed-path selection through existing PR/staging/production profiles. Do not rerun the full browser campaign solely to prove the whitelist mechanics; source/runtime byte changes would require affected new browser evidence. All actual hosted and release gates remain separately open.

Post-conclusion neutral chronology readback: the saved partial contract `production-derivation-color-contract.cjs` SHA256 `c5e62e437f52a750470b5744a3e3dd51a7f65a99b68ef4a23a59108200a37faf` explicitly contains `production: null`; saved source diff SHA256 `018a620c770525c30f1a956d0bd8d3d8365b61e384242390025210a6026b0f6e`. Supplied production parent and derived manifest both honestly retain `sourceDirty: true`; derived manifest SHA256 `e090cbc23f0e3dd9110d9b07e3fb694871b5eec31bc63094509723865e6bed0e` records production fingerprint `c8c444e30127b60e1dac052ab6a2b53d3ff48f40efc68d526cc7c71f17151ebb` and the observed plain artifact digest as derivation parent. This readback supports the proposed sequence and truthful dirty-state handling. It does not accept the new full registry/tests or establish clean-source production acceptance; the final immutable packet must cover those.

# Final prepared admission delta — same-role correction review

**Verdict: PASS for this finite admission/source-test delta; no blocking defect found in the reviewed prepared bytes.** This admits the observed family and preserves existing controls. It is not clean-commit, hosted, full browser-matrix or production release acceptance. The prepared source is dirty on223456b, as the packet states. Earlier first results remain intact above; this is a source-bound continuation without peer verdict exposure.

## Final input identity

Packet `/workspace/scratch/5ba265a57f36/admission-final-packet.json` SHA256 `affddd872b54b87669eede7a91eae60445997eeea49c89e9a277ea35dbebeeb8`: independently checked all15 listed current paths' byte lengths and SHA256 values at entry and exit, **zero mismatches both times**. Inspected actual current source/test/registry diff and new fixture, canonical regenerated revision/output-lock, original failed log, completed current log and referenced raw manifests. App/probe equality to immutable223456b was independently checked for navigation.js, archive.js, scroll-entry.cjs and the runtime probe: all unchanged. Prior raw browser evidence can therefore support its bounded runtime observations; current-source package/profile/hosted acceptance remains separate.

Key final bytes: contract `a1b3c0d2cf346c2781bfd56703f1435257ea009171f85424b454f05478d0f3b0`; compatibility `341f4154d7600f17c0e1d5b353afcdc4256334c622fbbd9b71c0a1a056db21a1`; new observed fixture `b554ea4ef3efac9e08d2a93cb88b1d5cefdc65ace6e70527ac5151493afaff7b`; color test `186f3dfdd8dc6d67b7e1f5c8299a9b8fe09765f939fda173d53165bcf414ad74`. Remaining exact pins are retained in the supplied packet.

## Final risk/check matrix

| Invariant / affected gate | Inspected change and actual evidence | Result / route |
| --- | --- | --- |
| Finite observed identity; no guessed production | New family inherits footer and overrides only ID/base/archive/navigation/plain/staging/production. All three select exact actual manifests, including separately derived production `c8c444e30127b60e1dac052ab6a2b53d3ff48f40efc68d526cc7c71f17151ebb`. | Executed direct final-manifest comparisons and focused observed-runtime test; existing color-motion-contract PR/staging/production |
| No false clean-source provenance | Compared150 leaf values in the three fixture manifest projections against actual raw manifests. Production and parent both retain `sourceDirty: true`; exact source/tree and production derivation parent digest match. Seven referenced primary evidence digests independently rehashed. | Pass; controlled fixture is not release eligibility |
| Real byte closure, not fingerprint alone | Independently rehashed all88 production public file entries. Executed canonical/immutable missing/substitution tests and unknown/conflicting/mixed/edition guard tests, including pre-browser refusal. | Pass; existing color suite and gate consumers |
| Historical compatibility/goldens survive | Compiled immutable223456b and current contracts in memory. All152 historical runtime descriptors remain identical; runtime count increases by exactly3. All10 tracked historical fixture files except the intentionally current-build publication helper remain byte-identical. | Pass; old footer fixture still tested alongside new one |
| Reader/paper/rights semantics remain mandatory | Spread inheritance preserves existing behavior flags and rights requirement. New family added to current-policy, all-edition, licensed-byte and browser-evidence inventories. Each actual edition still requires publication rights. | Pass; color/article-browser-evidence suites |
| Semantic document guard runs for new base | Exact new client added to reviewedDocumentClients; no legacy hash alias added. Executed current compatibility test checks true generated bytes plus missing/forged inert/comment/template/script hooks, fallback/footer and changed runtime rejection. | Pass; color suite |
| Native CSS completion cannot pass via watchdog | Current completion-negative test now uses reader-history staging; every current identity inventory also includes new family. Existing historical coverage retained. | Executed watchdog/cancelled/null/absent-phase refusals; pass |
| Selection reaches consuming tests | New fixture is an explicit color suite input. Independently selected changed new fixture, compatibility source and motion contract: all select color-motion-contract with no conservative fallback. Existing migrated current-built helpers require new observed family rather than old footer bytes. | Pass; existing pr-targeted/staging/production allocations |

The expected-value migrations target outputs created by the current builder (publication helper, production controller, staging journey comparison and current platform tuple reproduction). They do not replace historical fixtures/goldens. The old observed footer test is extended to test both old and new fixtures. Test-profile JSON's issue41 escape spelling changes no parsed meaning.

## Actual bounded execution

Executed once on the pinned prepared bytes:

```sh
node --test --test-name-pattern='observed runtime families retain|unknown, conflicting, mixed|licensed contracts reject every|current route phases refuse|producer refactoring preserves client' tests/color-motion-contract.test.cjs tests/article-browser-evidence.test.cjs
```

Raw completion (tool chunks `248391`, `3218b7`):

```text
ℹ tests 5
ℹ suites 0
ℹ pass 5
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1853.354275
exit_code 0
```

These five selected tests contain meaningful corruption/refusal matrices and actual current document-hook checks. This is a bounded source check, not measured branch coverage or actual new browser interaction.

Additional read-only final assertions (chunk `e6d3fd`, exit0):150 projection leaf values equal primary manifests;88 production file hashes correct; production parent/dirty provenance preserved;7 evidence digests correct;152 old runtime tuples unchanged; exactly3 new runtime tuples;10 old tracked fixtures unchanged; explicit selection for all3 checked owners. No implementation or acceptance tests were authored by this reviewer.

## Failure retention, regenerated source and remaining acceptance

Inspected the retained first `admission-tests.log`:97pass/1fail of98, failure at `tests/color-motion-contract.test.cjs:169` through `artifact.build`, which explicitly reported generated-only output stale after the producer input change. That result remains failed. Its mechanism matches the changed semantic-client producer input and canonical generation dependency; changing the assertion or suppressing generated freshness would have weakened the guard. The final packet instead pins regenerated `docs/site-revision.json` and `site/output-lock.json`, and the same generated-record assertion appears successful in the current retained run.

At final readback, `admission-tests-final.log` SHA256 `239ba9b68167192f115ed3117f7d8914d83c0bea1b4f65e5a60be5f07b015c30` had completed accounting:

```text
ℹ tests 144
ℹ suites 0
ℹ pass 144
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 99152.275821
```

This is inspected orchestrator-run evidence, not a second whole-suite execution by this reviewer. Its process exit receipt and full command/source association remain the orchestrator's responsibility; I observed the completed raw log and final unchanged15-pin check. The stale-generation failure is not erased by the later pass.

No new browser run was performed here, and browser ZIP/artifact origin was not independently authenticated by this reviewer. The previous actual Chromium report remains bounded to its exact runtime bytes and40 planned observations; its `fullGate: false` remains material. Production family registration names actual guarded output but does not make the dirty derivation production-eligible. The next clean candidate still needs applicable exact-source Basic/profile/rights/package/hosted/staging and protected release checks through existing routes. No native completion, rights, source, byte/frame or timing budget was weakened in the inspected delta.
