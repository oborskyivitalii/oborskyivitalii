# Code reviewer — first independent result

Verdict: **No substantive implementation regression found in the inspected correction; runtime/release admission remains blocked by missing current-source evidence and runtime-family admission.** This is a bounded code review, not a release approval. No reconciliation or peer verdict was supplied before this result.

## Identity and scope

- Reviewer: `/root/reader_runtime_code`, distinct nonauthor Code role. Parent supplied a no-conversation-inheritance task; actual launcher receipt remains the orchestrator's responsibility. Provider context/memory internals are unknown.
- Repository: `/workspace/scratch/83aaf5811f83/release-repo`; clean native Git checkout observed before and after checks.
- Candidate: `223456b4b928017703dedf1cca352ca4c5affedf`; tree `eb37f5eeb60f059d77a471a4af019ecee93c6851`; comparison `d3a49960714e5f158afba23d02dd0f8e871cb28e`.
- Packet SHA256: `b726f00ba9c4b65d37bc6c034be64aa6bf708ff2d06e90971f92eaf1b586fe6c`. Independently hashed every file in its manifest: all matched.
- Common prompt SHA256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code prompt: `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Read README, root AGENTS, relevant CONTRIBUTING review/failure/acceptance protocol, canonical MEMORY handoff, relevant repository-map entries, CODE-STYLE, site source contract, check-profile contract, issue169 policy and R9 release-intent source. No nested AGENTS were found under the affected directories. No current peer review files, private chat or parent scratch notes were inspected. Some broad map/source reads were output-truncated; the relevant owners and correction diff were then read directly.
- Inspected actual navigation correction and associated archive/reader/navigation tests, resource fixture, article evidence validator/test changes, profile dependency additions and selection regression. Read the diagnostic harness's identity/completion/accounting boundaries. Generated/publication-wide and earlier PR changes outside this correction were not comprehensively re-reviewed.

## Findings and admission disposition

### A1 — Blocking admission evidence need; no newly identified code defect

Locations: `tools/quality/color-motion-contract.cjs:885–946`, `:986–1000`; `docs/site-revision.json` engine; `review/issue-169/r9/reader-runtime-probe.cjs:35–38`, `:1184–1239`.

The current generated base engine is `68fa384f47c646e4f2bc7d96c645f42efa6dabf9b84f5f514af4b959f561f72c`. The maintained known family still pins the earlier footer-navigation bytes (`d2cacfa7…`), while candidate authored navigation SHA256 is `ed6ac4f1…`. A direct current-engine query returns `readerPaperRequired: false` and `articleReadingMode: 'entry'`, because this engine has no reviewed family. These defaults are **not** evidence that the corrected reader satisfies the current stationary/paper contract. The Color selector separately rejects an unknown family, preserving the admission boundary.

Treatment: retain the refusal. Obtain the actual complete raw outcome of run `42112795903`, verify workflow/source/tree/artifact/browser supply bindings and all 40 cases/24 normal legs, and preserve any failure before deciding the next bounded action. This task received its status as running and did not inspect a completed run; no pass or failure is inferred. Even a fully passing diagnostic explicitly has `fullGate: false` and does not admit a runtime. Any subsequent family registration must bind actual candidate base/plain/staging/production identities and file hashes, retain current evidence requirements, and receive affected review. Native Basic/source/hosted/platform/performance/staging/production gates remain separate under issue169 AC04/AC05/AC07/AC08/AC11 and DELIVERY/INDEPENDENT/VISUAL. Do not substitute the older footer family's green results.

## Code and test assessment

The capture listener records the outgoing mounted document before archive bubble listeners change its geometry and avoids writing through the already-selected incoming history entry. Recent state is checked against history index, page and exact URL; the 128-entry bound and forward-branch pruning prevent unbounded accumulation and abandoned-branch reuse. Reader disclosure state, scroll and focus consume the same recent-state lookup. The arrival guard prevents a debounce timer from retiring target state before final focus restoration. Principal initial-snapshot admission remains limited to the original validated document; other principal snapshot paths remain unresolved. Mounting against the actual browser URL fixes immutable-history resource/header rebasing while preserving the original history address.

The completion change moves `completedBy === 'animationend'` from article-paper-only validation to both route phases for paper-required reviewed families. Negative tests cover watchdog, cancellation, null and missing values across flights/nativeHistory and both phases; the older-family compatibility assertion remains. This strengthens refusal rather than accepting a fallback. It does not automatically cover the unregistered candidate engine, as A1 records.

Profile changes add direct consuming-owner edges without changing test lifecycles or introducing historical snapshots into ordinary selection. Selection tests assert these explicit edges and an unrelated theme negative. The frozen resource projection is labeled non-live and dirty-generation-derived; its use in a VM resource test does not establish actual browser/generated-package acceptance.

Reviewed CS01/CS04/CS05/CS06/CS07/CS08 concerns: ownership/dependency direction, bounded state, focused readable changes, interrupted navigation/stale async ownership, actual browser base semantics, existing motion/resource budgets and meaningful negative test allocation. No budget increase, perpetual scheduler, author-content/PDF replacement or social write was present in the inspected correction. No nonblocking improvement is required for this scope.

## Actual checks and limits

Executed:

```text
node --test tests/navigation.test.cjs tests/archive.test.cjs tests/reader-mode.test.cjs tests/article-browser-evidence.test.cjs tests/test-profile-selection.test.cjs
```

Result: exit 0, **145 passed; 0 failed/cancelled/skipped/todo**, approximately 11.34 seconds. Also ran `git diff --check d3a4996 223456b` successfully, verified candidate/tree/clean status and all packet file hashes, and queried current-engine evidence policy as described in A1.

These tests exercise VM/native-source contracts and validator refusals; they are not a browser run. No whole CI, browser diagnostic, hosted surface, physical device, PDF visual parity, production or rights/archive acceptance was executed here. Live GitHub refs/run completion were not independently fetched. The original accepted R9 text, PDF and five visuals remain acceptance inputs; this review does not replace their prior editorial/rights decisions or their required delivery verification.

## Same-role continuation — finite admission proposal, before implementation

This continuation follows the preserved first result. The orchestrator supplied completed primary evidence and the proposed data shape; no peer verdict was read. This is reuse of this role's own review, not a newly fresh first judgment. Candidate remains clean `223456b4b928017703dedf1cca352ca4c5affedf`.

**Conclusion: the proposed finite plain/staging row and normal guarded production derivation are source-evidenced and suitable for the next bounded implementation step.** Actual final registration bytes and the production tuple still require the promised delta review. This permits constructing evidence; it supplies no hosted/staging/release completion claim.

Evidence independently checked:

- Raw report SHA256 `b61435e2ce2d9cd036c7e64910ddfe1a05143b374e7ae02e384e09af32074d3e`; original diagnostic ZIP SHA256 `8419636406b3c5867f59295ea3b6280d6f0a5551c7e92e268882fba430ae4f9e` matched supplied values.
- Report contains 40 unique planned/actual cases, all pass; four normal/no-JS width contexts all pass, zero context errors/console errors/request failures, no unobserved inventory or evidence errors. Complete leg accounting is 16 original plus 8 added-history captured/passed legs. Elapsed 134249ms remains below 240000ms. Start/end worktree are clean. Workflow/checkout/candidate source and tree match the reviewed candidate; raw source-file digests match current files. Authenticated browser archive receipt records pass with zero pre-consumer launches. This evidence establishes the report's bounded observed result, not the entire delivery gate.
- Plain manifest SHA256 `57d633fcbc4cf2cdc62fc3eb09e4223456896775bea7e1d25fe8352cf020f482` equals the report's actual `manifestSha256`; report components equal its components. Independently ran the existing artifact verifier over the complete private plain public tree successfully.
- Staging manifest SHA256 `713f52109b3357a7403c0144ed16c0c8bf2775bf8194bc29ffa11577cb17630f` exactly equals the JSON manifest printed by the supplied actual build log. It also equals the private staging manifest structurally, and its complete private public tree passes the existing artifact verifier. That build log subsequently fails with `unreviewed Color motion runtime`, so its generation observation must not be described as successful preview admission.
- Independently revalidated all 24 raw observed legs with `article.validateArticleBlocks` using the existing footer family's inherited block/paper policy. All 48 phases pass full block/paper validation and record native `animationend` completion. This explicitly exercises the policy intended for inheritance despite the currently unknown candidate family.

The exact finite values supported by those observations are:

| Field | Observed value |
| --- | --- |
| Base client/engine | `68fa384f47c646e4f2bc7d96c645f42efa6dabf9b84f5f514af4b959f561f72c` |
| Plain Color fingerprint | `b6f3a98b4b0fb438ec1747952f050baa4b016fb4f6d942b8b364e37638af2768` |
| Staging Color fingerprint | `ace81eb56ccb8fca35099e960d684ca90aa855733c7a8e9dfe35eab66da84f78` |
| Combined archive hash | `bf1b9e42356b282f3c08f7763a7a59263241c752df5dd9ee776a6b0bf86b0caa` |
| Combined navigation hash | `0c447ce8a4a8a02835753d144939e14842bd407f735273e8820cf1ff9121cb3e` |

Compared with the existing footer family's plain/staging file pins, only archive and navigation hashes differ. Styles, theme and space match their respective inherited edition pins. The base value is independently present as `site/output-lock.json`'s `components.client`; adding only this exact client to `reviewedDocumentClients` activates additional semantic-hook verification after fingerprint/byte verification, rather than creating a wildcard compatibility allowance.

Inspected `tools/release/edition.cjs:112–141` and `tools/site/edition.cjs:17–190`: the public release adapter first selects the input Color manifest, rejects candidate previews and invokes the existing artifact-verified edition builder. Consequently a finite plain row with production absent permits deriving the production identity through the normal public adapter from a private **plain**, uneditioned artifact copy; the staging artifact cannot be decorated twice. Inheritance must explicitly override `production` to null/absent at this intermediate point: spreading the footer family without that override would retain its old production fingerprint under a second family. Keep the existing footer family intact.

The normal adapter derivation can be recorded as observed output of that exact producer/input, even when the private admission-source checkout is modified. Its inherited `sourceCommit`/`sourceDirty` fields identify the original artifact and do not turn the modified derivation checkout into a clean, eligible final source. Retain both facts, preserve the actual output/producer identity and perform final tuple registration/review on the real proposed candidate. Do not call the lower-level edition builder directly to bypass the Color selector, invent a production hash or reuse the old production fingerprint.

A1's previously unavailable diagnostic result is now observed as passing within its stated scope. Its remaining runtime-registration and full DELIVERY/INDEPENDENT/VISUAL obligations stay open. No implementation or test source was edited and no production derivation was executed by this reviewer.

## Same-role final delta review — prepared finite admission

**Verdict: no blocking code defect found in the prepared admission delta.** The finite family, semantic-client addition, observed fixture and current-fixture migrations are supported by the supplied primary evidence and preserve the inspected refusal boundaries. This is acceptance of the reviewed code/data shape, not clean-source CI, staging or release acceptance.

This is a continuation of this role's preserved first result and proposal review, with no current peer verdict consumed. Reviewed packet SHA256 `affddd872b54b87669eede7a91eae60445997eeea49c89e9a277ea35dbebeeb8`; all **15 path/byte pins matched at start and end**. The source is explicitly a prepared dirty delta on `223456b`/tree `eb37f5e…`, not a new clean commit. Application navigation/archive/scroll-entry bytes remain the packet's original browser-observed source. The probe and raw report hashes also remain as previously verified. Common and Code role prompts are unchanged from the first result.

Inspected actual changed family/client/validator tests, profile dependencies, current publication/release/staging fixture migrations, the new observed runtime projection, production manifest/parent, private partial registry and its complete source diff. Existing footer family/fixture bytes remain unchanged; the actual family diff only appends the new row. The partial registry differs from final registry only in its production comment and `production: null` becoming the observed hash. There is no guard replacement, low-level adapter alteration or unknown-runtime fallback in that diff.

The new production fingerprint is `c8c444e30127b60e1dac052ab6a2b53d3ff48f40efc68d526cc7c71f17151ebb`. Independently checked the production manifest, parent manifest, partial registry, partial diff and staging-log SHA256 against the new fixture evidence. All matched. Plain/staging/production fixture projections match the actual manifest source identity, dirty flag, artifact digest, variant, edition, derivation, projected components and every canonical/immutable runtime file entry. The production parent is the exact observed plain fingerprint and artifact digest, with production absent in the preparatory registry. Production output and parent honestly retain `sourceDirty: true` and frozen clean-HEAD tree identity. Complete production public bytes pass `artifact.verify`; the ordinary production edition verifier passes its metadata/social/sitemap checks. These observations support deterministic tuple registration without turning private derivation into release eligibility.

The single added base client enables semantic checks only after matching the actual runtime fingerprint and generation bytes. Independently ran semantic verification across current generated routes/articles, then verified two missing/forged-control mutations are rejected. Regenerated principal and article aliases equal their previous bytes after substituting only old/new generated route-version identifiers; current base engine remains `68fa384f…`. Thus the observed HTML regeneration does not change the tested article text or runtime behavior. Generated static review previews outside the packet were not comprehensively re-reviewed here.

The three actual projected tuples select the new family, all continue to require publication rights, and full ordinary/immutable file pinning remains mandatory. Independently executed **69 negative tuple mutations** across three editions (missing/substituted canonical and immutable files, unknown fingerprint, wrong base engine and wrong edition); all were refused. Existing tests also extend aggregate/browser-prelaunch refusal, publication-rights and completion tests to the new family. The completion tests retain the native-event negative cases; no fallback acceptance or budget change was added.

The changed current-built assertions now name reader-history, while the old observed footer fixture remains in the dual-family regression. The new fixture has a direct permanent color-motion-contract selection edge; independently selected that changed path and verified the consumer appears with no conservative fallback. The registry's unrelated Unicode escaping difference preserves the same JSON string value and changes no lifecycle or scheduling policy.

Failure accounting is retained: the original raw run reports 97 passed/1 failed of 98, failing at `artifact.build` with stale generated output; its actual error lists the new expected route versions and old removed snapshots. Canonical regeneration is consistent with the added producer-input client registration; no refusal was weakened to address it. At final read, the separate current five-suite log contains completed accounting of **144 passed, 0 failed/cancelled/skipped/todo**, duration about 99.15 seconds. I inspected that raw log, not its launch/process handle; its process exit and campaign source receipt remain the orchestrator's observation to preserve. I did not rerun those whole suites. One reviewer-only comparison script initially used an invalid `execFileSync` options argument; it was corrected and the bounded alias comparison then completed successfully. This was not a product/test failure.

No source files were edited by this reviewer. Final registration is code-reviewed for the packet's exact prepared bytes. A1's unknown-family code/data issue is addressed by this delta; independent-role completion, final clean-source checks, native/hosted platform evidence, staging/protected merge/production rights/archive and actual served-byte verification remain separate open obligations. A changed relevant pin requires affected re-review.
