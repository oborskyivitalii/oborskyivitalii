# Independent exploratory / interaction QA — first result

Reviewer: `/root/reader_runtime_exploratory`; owner issue169 / PR170; 5 November 2026. Scope: bounded reader/runtime diagnostic and admission preflight, not release acceptance. No source/test implementation, external writes, delegation, shared-browser control, author chat or current peer verdicts. Raw artifact extraction was subsequently authorized by the orchestrator. Provider memory/context internals and the parent's actual launch parameters are not observable from this role; the orchestrator must retain that launch receipt.

## Conclusion

The actual diagnostic supports its bounded interaction claims on clean candidate `223456b4b928017703dedf1cca352ca4c5affedf`, tree `eb37f5eeb60f059d77a471a4af019ecee93c6851`. No blocking interaction defect was found within the inspected charter. This is **not runtime-family admission, hosted delivery, full CI, performance or production acceptance**. The report itself preserves `fullGate:false` and says the unknown runtime family remains unadmitted. AC04/05/07/08/09/10/11 receive bounded evidence only; none is wholly accepted by this review.

## Inputs and identity

- Packet `/workspace/scratch/5ba265a57f36/reviewer-packet.json`, SHA256 `b726f00ba9c4b65d37bc6c034be64aa6bf708ff2d06e90971f92eaf1b586fe6c`.
- Common contract `agents/reviewers/README.md`, SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/exploratory-interaction-qa.md`, SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Read README, root AGENTS, relevant CONTRIBUTING protocol, acceptance issue169, release-intent primary instruction, SITE-CHECK-PROFILES QA allocation, diagnostic workflow/probe and changed navigation/history source. Reviewed actual diff against `d3a49960714e5f158afba23d02dd0f8e871cb28e`; inspected existing navigation history regression cases and profile routes. No applicable nested AGENTS was found in the repository.
- Local HEAD/tree matched the packet and working tree was clean. Probe SHA256 `09e995a1726da63b7eeea7778f12a1af93a68f79798c35f6b1b36c98975984d9` matched the packet and executed report. All ten report `sourceFiles` hashes were independently matched against local candidate bytes.
- GitHub run `42112795903`, attempt1, job `127544466135` completed success. Initially pending observations and unavailable job logs were treated as unobserved; no pass was inferred before the final artifact arrived.

## Independently selected charter and actual evidence

Within six minutes of review, prioritize the changed state boundaries: filtered Writing → accepted R9 reader → Back; refreshed visible heading → Forward → reader → Back; repeated footer next/back with actual CSS completion; ordinary no-JS links; readable reader resources and keyboard viewer recovery. Reuse the existing 40-case, 240-second diagnostic instead of launching another browser campaign. I inspected actual automated browser output; I did not personally operate the browser or execute another matrix.

Environment: Ubuntu24 Linux x64, Node24.19.0, Playwright1.63.0, Chromium153.0.8010.12/revision1243. Four contexts: 1440×900 and390×844, each normal/no-JS. Normal media motion available; observed normal screenshots use dark theme and no-JS screenshots light theme. This does not establish both themes in each mode.

| Journey / expected result | Actual observation |
| --- | --- |
| All planned cases finish with explicit accounting | 40 unique IDs, 40pass,0fail,0not-observed; four contexts pass; 134249ms within240000ms;68PNG screenshots/four traces retained. |
| Original repeated Writing/article/Back/footer/back legs survive |16/16 original normal legs captured/passed;8/8 added history legs captured/passed. Filtered query and activation focus/scroll restored. Example mobile article Back restores3832px; Forward-back restores1076px; footer Back restores3832px with footer anchor focus. |
| Refreshed visible H2 text actually animates and completes | Four Forward cases have native `animationstart`/`animationend` on the same live heading ink node, exact refreshed text,0.7s elapsed; no cancellation. Both route block phases complete by `animationend`. Heading screenshot independently shows current filtered heading in view. |
| Actual footer anchor box completes its departure | Four footer-next cases preserve same-node native start/end pairs on `A.scroll-continue`, `routeLayer:self`,700ms keyframes/0.7s elapsed; route and return settle. This is stronger than merely observing a lifecycle event or timeout fallback. |
| Five figures and accepted PDF/local resources survive in all four contexts | Five decoded figures per context; exact order, alt, caption and dimensions checked against accepted publication bytes; no measured horizontal overflow. PDF200,549590bytes, SHA256 `75e052d6a5c386ae79cb1a51d59cdf42e53d3a7279bf0db31c227ee145bb18b4`. Normal reader inventories19local targets; no-JS15; exact served bytes and local fragments checked. |
| Viewer recovers after keyboard/button close | Both normal widths pass Enter/open, modal focus, Escape focus return/clone release, reopen/button close and focus return. Inspected mobile screenshot shows visible Close focus and readable image/caption/actions. |
| No-JS native navigation works | Both widths actually activate Back to Writing, More writing and footer credits, then native Back;200 responses and exact manifest document hashes. |
| No hidden application request/console failure | All four contexts have empty page errors,console errors and request failures; evidenceErrors empty; public bytes verified before/after; worktree clean before/after. |

I visually inspected these original artifact screenshots: `normal-390-intro.png`, `no-js-390-intro.png`, `normal-1440-ending.png`, `normal-390-viewer.png`, `no-js-390-ending.png`, `normal-390-cycle-2-footer-back.png`, and `normal-1440-normal-1440-cycle-2-forward-reader-heading-refreshed.png`. Reader headings and controls fit, image viewer actions are visible, native PDF/end navigation remain legible. Screenshot positions can begin below sticky navigation because the probe deliberately scrolls selected targets; these are sampled viewports, not a full-page visual audit.

## Evidence retained

Directory: `/workspace/scratch/5ba265a57f36/diagnostic-42112795903/`.

- `navigation-diagnostic-42112795903-1.zip`: artifact13453453811,99408689bytes, SHA256 `8419636406b3c5867f59295ea3b6280d6f0a5551c7e92e268882fba430ae4f9e`; downloaded bytes match the GitHub artifact digest.
- `r9-reader-runtime-probe.json`: SHA256 `b61435e2ce2d9cd036c7e64910ddfe1a05143b374e7ae02e384e09af32074d3e`.
- Executed artifact digest `3f2ecb9e4dcf87109fbdb9be6bf0eb5a5c18c25bdfdc3766bc3cc0f278d3a075`, manifest SHA256 `57d633fcbc4cf2cdc62fc3eb09e4223456896775bea7e1d25fe8352cf020f482`; exact clean source/workflow/candidate tuple all223456b. Color engine/variant fingerprint `b6f3a98b4b0fb438ec1747952f050baa4b016fb4f6d942b8b364e37638af2768`.

## Findings, allocation and acceptance limits

No new reproduced defect or regression proposal is required by these observations. Retain the existing history/cache regressions in `tests/navigation.test.cjs`, archive/reader/evidence guards and existing source-test profile selection; the browser cases remain explicit diagnostic coverage through `.github/workflows/site-navigation-probe.yml` / `chromium`. Do not turn this diagnostic result into the enduring admission selector or erase earlier failed evidence. Existing hosted/content/runtime admission owners must supply their own exact-source evidence; no new device/browser matrix or budget increase is proposed.

Not observed here: hosted/TLS/header behavior, release admission/registry eligibility, full Basic/source suite outcomes, immutable direct-entry journeys in an actual browser, interrupted navigation/recovery, reduced-motion and other browser/platform cells, exhaustive figures/viewer interactions, PDF page rendering, complete manuscript comparison, assistive technology or physical devices. Existing source cases for duplicate/branch/128-entry history were read, not executed by this role. Four traces are retained but were not exhaustively replayed. Supplemental staging/preview manifests were offered after charter selection; I did not inspect them and infer no acceptance from them.

No human author/content/release permission is requested by this review. Actual staging, protected merge and production delivery remain separate evidence/state transitions under the existing process.

## Evidence identity clarification — 5 November 2026

The final response's label “Report SHA256” referred to this review Markdown file, whose SHA256 before this appended clarification was `f31b4eca5510002ff2658a136b61ae5280682371158a5949bdd2a9c498e5c465`. The label was ambiguous; it did not identify the raw diagnostic JSON.

Rechecked the retained ZIP directly against the current extracted file without modifying either: `r9-reader-runtime-probe.json` inside the ZIP and on disk are byte-for-byte equal, both 7615514 bytes, SHA256 `b61435e2ce2d9cd036c7e64910ddfe1a05143b374e7ae02e384e09af32074d3e`. The retained ZIP SHA256 remains `8419636406b3c5867f59295ea3b6280d6f0a5551c7e92e268882fba430ae4f9e`. There is no raw-evidence difference to preserve. This appended clarification changes only the review Markdown's digest and does not change its first conclusion or any raw evidence.

## Final admission delta review — 5 November 2026

Same-role continuation after the independently preserved browser result and identity clarification. No peer results or author conversation were consulted. Inspected packet `/workspace/scratch/5ba265a57f36/admission-final-packet.json`, SHA256 `affddd872b54b87669eede7a91eae60445997eeea49c89e9a277ea35dbebeeb8`; all 15 path/byte hashes matched both on entry and immediately before this append. This is a prepared **dirty delta** on HEAD `223456b4b928017703dedf1cca352ca4c5affedf`, HEAD tree `eb37f5eeb60f059d77a471a4af019ecee93c6851`, not a new clean candidate. The packet plus its 15-file manifest identifies this inspected scope; HEAD alone does not.

Conclusion: no blocking finding within this admission delta. The added finite `issue169-reader-history` family and document-client identity preserve the already observed interaction semantics. No additional browser matrix was necessary for these registry/client/test/producer-metadata changes. This conclusion reuses the previous actual browser evidence for unchanged application behavior and does not assert another UI execution.

Independently compared every tracked file under `site/engine`, `site/templates` and `site/publications/sdlc-out-of-balance` against223456b: no changed bytes. The diagnostic probe and `tools/quality/article-browser.cjs` are also byte-identical to223456b. Examined generated article/Writing/revision diffs: snapshot addresses, content hashes and dependent provenance changed after producer-input regeneration; these current generated documents are not newly browser-observed documents. The accepted manuscript, PDF and five visual source assets have no changes in this delta.

Read actual registry/client/test diffs. The new family inherits the prior reader contract and mandatory publication rights, then binds only the specific new base engine, archive/navigation bytes and three exact edition fingerprints. `runtime-compatibility.cjs` adds one explicit document-client identity and retains fingerprint/hash/document-hook verification. No selector wildcard, unknown-family bypass, changed animation validator or changed motion/byte budget appears in these diffs.

Executed a small independent in-memory admission check without editing source/tests or launching browsers. For each of plain, staging and production, actual fixture tuples select the precise family; article reading remains stationary, flight check remains blockFlight, whole-block/paper/deferred-media/interactions predicates remain true for both base engine and variant fingerprint, and publication rights remain required. Unknown identity, previous-family mixed navigation, absent immutable navigation and wrong edition are rejected. Compared 152 successfully returned prior edition descriptors between223456b and the prepared registry: unchanged. The existing `tests/article-browser-evidence.test.cjs` now includes the new family and keeps watchdog/cancelled/missing completion rejection for both history directions; its validator implementation and native completion semantics remain unchanged from the actual observed source. These microchecks are admission checks, not interaction executions.

The runtime projection's plain/staging/production source fields, variant, edition, derivation and all ten projected runtime-file records were independently compared with the supplied actual manifests: no differences. Plain manifest SHA256 `57d633fcbc4cf2cdc62fc3eb09e4223456896775bea7e1d25fe8352cf020f482` matches the original browser report's manifest identity. Staging manifest SHA256 `713f52109b3357a7403c0144ed16c0c8bf2775bf8194bc29ffa11577cb17630f` is exact clean build data from a failed unknown-runtime guard, not staging acceptance. Raw diagnostic JSON retains SHA256 `b61435e2ce2d9cd036c7e64910ddfe1a05143b374e7ae02e384e09af32074d3e`.

Production manifest SHA256 `e090cbc23f0e3dd9110d9b07e3fb694871b5eec31bc63094509723865e6bed0e` honestly has `sourceDirty:true`; it is controlled compatibility derivation data. Parent manifest SHA256 `a59c0d95bf1d12463f4013974ac4bd05d124da3e7fbe2feba75aeea24fa6265f`, partial registry `c5e62e437f52a750470b5744a3e3dd51a7f65a99b68ef4a23a59108200a37faf` and prepared diff `018a620c770525c30f1a956d0bd8d3d8365b61e384242390025210a6026b0f6e` match the projection's provenance. The inspected partial diff registers plain/staging and explicitly leaves production:null. Final production fingerprint `c8c444e30127b60e1dac052ab6a2b53d3ff48f40efc68d526cc7c71f17151ebb` comes from the supplied normal edition derivation; neither this artifact nor registry registration supplies new browser, clean-source CI or release eligibility.

Allocation remains the existing color-motion-contract/evidence/release-controller/staging-regression owners. The new fixture is added to the directly consuming source-test inputs and profile-selection assertion. Historical fixtures and older family identities are retained. No new campaign or regression proposal is needed from this continuation.

Remaining gates: final clean committed candidate and exact-source required Basic/source/hosted checks, current generated-document/package binding, authenticated staging, protected merge, production rights/archive and actual served article/PDF verification. The supplied current source-test log had emitted passing cases but lacked final total/exit accounting when inspected; this review does not count it as a completed pass or erase the retained first 97-pass/1-fail run. Original unobserved platform/device/performance/PDF-rendering limits remain. These gates concern evidence and state; they do not reopen author permission already supplied.
