# Issue 169 / PR 170 — White-box QA, prepared security correction

Date: 2026-11-06. Reviewer task: `/root/secrets_whitebox`. Role: distinct nonauthor White-box QA. Scope: the supplied bounded security correction at `/workspace/scratch/20e98a342431/author-site`, through verified stable staging and then STOP/show; no merge or production authorization.

## Result and assurance limit

No blocking implementation or test defect found in the inspected prepared correction. All ten value derivations, nine retained native finding locations, ledger preservation and three archived Git-byte identities independently verify. The focused existing tests pass, including their negative cases. This supports the bounded correction; it does **not** establish clean-head native security, complete current CI, hosted/stable staging or any whole issue AC.

Isolation disclosure: the task states an explicit none-fork request. Actual launcher acceptance belongs in the parent's launch receipt; provider model/context internals are unknown. I did not inspect MEMORY, author conversation or current correction peer outputs. While subsequently checking the changed original-path locator, `git diff --cached -- review/issue-169/native-reviews/code-final.md | tail -n 16` unintentionally displayed deleted historical code-review prose about its old C4 fixture-selector finding. This occurred after the present guard/value tests and the no-blocker progress observation; it was not used as an oracle for this correction. It nevertheless exceeded the task's blanket no-peer-report reading boundary. This result must not be described as an unqualified clean first judgment; use a fresh replacement for that assurance. All factual calculations below remain bounded observations that can be repeated independently.

## Exact inputs

- HEAD/base: `186f28c0ad8f94b21c350d50608d337f64c66708`; base tree: `8b09d57484b1102e2b3f9affc020b9a3d12cc297`. Working tree is a staged, dirty prepared candidate, not a clean commit. No unstaged diff was present.
- Packet: `security-candidate-packet.json`, SHA256 `ef50c5c287b771d25fc1ce181b18a41fe6767249c1f07ee4dc2bd1b9306b95d1`. Every referenced pin matched at inspection and final recheck.
- Packet patch: SHA256 `6b2d91b772a159333c21770c9a7b1cf118f636f92d6cddb845cdb5e5d478d9a5`; reproduced byte-for-byte by `git diff --cached --binary -- . ':(exclude)MEMORY.md'`. The intentional metadata exclusion explains its difference from a whole-index patch.
- Common prompt: `agents/reviewers/README.md`, SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role prompt: `agents/reviewers/white-box-qa.md`, SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Guard: `tools/quality/scanners.cjs`, SHA256 `3b23f919236d99a1b22f6665b4634985f9576280255a96f57de2865b74b1afba`.
- Test owner: `tests/quality-sources.test.cjs`, SHA256 `1b740df70248cf221857ee51fcf3daf132a9206d946d100fdb351d885f9dc092`.
- Ledger: `tools/quality/secrets-reviewed-checksums.json`, SHA256 `7335e6c06a4cf3e21902df2ed67f6476859a08bc2cfef21e0b61e0a7215f7b03`.
- Proof archive: `review/issue-169/stage-security-proof.json.gz`, SHA256 `5c33454b6810abf84426425b8a217c7df072949df2cc85f90c4b5d451c1c15ca`.

Read authoritative root AGENTS, CONTRIBUTING, README, repository map, acceptance contract and issue policy/snapshot; relevant CODE-STYLE, scanner README, release/check-profile and RI contracts; actual guard/test/source/proof bytes. There are no additional nested AGENTS in this repository inventory. MEMORY text was excluded. Original historical review payloads were compared as bytes without rendering their bodies, apart from the accidental locator-diff exposure disclosed above.

## Risk, structural fault and independent oracle

| Risk / AC | Fault and scenario | Oracle / actual check | Observation |
| --- | --- | --- | --- |
| AC05/11, exact admission | New public directory becomes a path/type/hash wildcard | Enumerate guard set; execute exact-tuple test over both inventory paths and both generations | Four finite tuples only; each still requires its exact ledger entry |
| AC05/CS08, fail closed | Missing ledger, altered path/type/value or unsupported Base64 entry bypasses review | Existing tests independently construct the finding/ledger and assert refusals | All original refusals remain and execute for both generations |
| AC05, authority/schema/bounds | Extra neighboring ledger, malformed metadata/row, duplicate ID, missing/directory/symlink/oversized/invalid JSON input is admitted | Existing closed-ledger, metadata, duplicate and regular-input tests | Pass; 2,000,000 bytes accepted, 2,000,001 rejected, for each closed input |
| AC05, existing SRI routes | Inventory exception broadens publishing/browser integrity admission | Existing selected-lock, package-field, installed-package and drift/refusal tests | Pass; unchanged separate proof requirements |
| AC05, exact disposition | Hash-shaped credential mistakenly accepted as public data | Recompute public referents, original source/line bytes and detect-secrets SHA1 IDs | Ten exact derivations verified below; unknown tuples remain blocked |
| AC05, historical preservation | Appended records alter prior reasons/order or archive compression loses evidence | Compare base Git JSON data and raw bytes; decompress archives and rederive Git blob OIDs | 3,151-row prefix preserved; exactly ten additions; three original reports lossless |
| AC05, source/RI routes | Compression silently removes inventory, exceeds bound or leaves stale owners | RI and RI/CI verify; binary mutation and hash-bound rejection tests; catalog diff | Fresh, mapped and fail closed; unchanged 250 MB hash bound |
| AC04/05/11, release boundary | Dirty local pass is treated as native/stable admission | Inspect retained native and prepared report identities and controller routes | Native predecessor failed; prepared local pass is distinct; live delivery remains unobserved |

These are structural cases and bounded observations, not measured statement/branch coverage. Browser/UI, async cancellation and interactive states have no new surface in this correction. Native staging is applicable but was not executed by this reviewer.

## Admission and original refusals

`scanners.cjs:482–487` retains the two original `41ceb5699f64d5bfeaccc5850d0cf398a19b10c9` inventory tuples and adds only the two exact `eb3400c0b18476eb7e38e5a430d52a263f917b89` tuples. `secretReviewEntry` still restricts checksum-companion Base64 records to the finite set (or the existing distinct browser path), and `reviewedSecretFinding` still requires `reviewed.has(key)` plus its appropriate proof/finite-tuple condition.

| State, for each of the two inventory paths | Base implementation/ledger | Prepared candidate |
| --- | --- | --- |
| Original `41ceb…` tuple, exact ledger present | Admitted | Admitted |
| New `eb340…` tuple, exact ledger present | Absent from base; a proposed Base64 row fails base finite-entry validation | Admitted |
| Either finite tuple, empty reviewed map | Refused | Refused |
| Exact ledger map but changed finding path, detector type or value | Refused | Refused |
| Arbitrary Base64 value or other catalog path proposed in checksum ledger | Invalid entry | Invalid entry |

The changed test at `tests/quality-sources.test.cjs:793–844` nests the original checks under both hashes. Its expected true/false values are explicit independently supplied assertions, rather than values copied from the guard set. Removing admission breaks its positive expectation; admitting without a ledger or broadening matching breaks its refusals. Source diff inspection confirms the original seven expectation categories and both invalid-entry variants remain. The surrounding unchanged tests exercise closed inputs, malformed row/metadata partitions, all ten within/across-ledger duplicate placements, regular-file/boundaries and exact legacy dispositions.

## Independent value derivations

Let `S` be `docs/article-snapshots/60b4eb071b9f8367227354032aec04364d783b02fb8f6f8d7d3cb59a05949bcc/the-sdlc-is-out-of-balance.html` and `D` its directory. Each table suffix is the exact detect-secrets `hashed_secret`; SHA1 was independently calculated over the literal value. All first nine occur in retained native `detect-secrets.json` with precisely the proof's original line numbers. Their original file SHA256 pins independently match `git show 186f28c:<path>`; values remain in current files. The tenth matches the pinned current test bytes and the later prepared raw report at line 803.

| # | Owner / original line | Finding SHA1 suffix | Independently verified referent |
| --- | --- | --- | --- |
| 1 | `.github/repository-intelligence/agent-context.json:41064` | `eb3400c0b18476eb7e38e5a430d52a263f917b89` | SHA1 of public directory D; directory exists, with the expected snapshot |
| 2 | `.github/repository-paths.json:748` | `eb3400c0b18476eb7e38e5a430d52a263f917b89` | Same public directory, separately located in this exact inventory |
| 3 | `S:145`, materials binding | `239eff03f73cb653046fe877418db8bcdfbdde28` | Recomputed SHA256 `ce917b057b33baa5f9963f5c588c40849432024d4009e574d041377b6c23e41a` |
| 4 | `S:145`, rights binding | `df34e166e25fbbc57619b0c3a712708457b929c1` | Recomputed SHA256 `377a71083ffdf51ffbe849e34a0dfa684678126c9d8e19aaf097c7f34d237bc0` |
| 5 | `tools/check_site_seo.cjs:416` | `4281b49ac162f351840f1b563699e9eedfc0f0cb` | Actual commit `d5e915feb3ba02d7a80325664c9d1d10a2ac494e`; rehashed commit object OID matches; ancestor check exit 0 |
| 6 | Same owner:419 | `2e663e5b6b333b10049bcf7f057fece8ccc7f647` | Prior Git `tools/site/render-records.cjs` SHA256 `24f1bec530b762009a6b03a1d91700e7ee5c56345a0b8d9a4a4c6f0ff561038c` |
| 7 | Same owner:420 | `598f7e14fe23f4157fc5b8a746329bbc9110e83c` | Current producer bytes SHA256 `85a0478ec37ffd65778b6f10dad08d420c42559ec2faeb15786ff983e7c4006c` |
| 8 | Same owner:423 | `ce1e43ee9450a23deccfe23ec6dc10a4e58014ae` | Prior Git `tools/site/validate-catalog.cjs` SHA256 `6a61f3af40e94c42b4240c1afb21a2a25474f2cf58381a2c40f12dea12becc6c` |
| 9 | Same owner:424 | `26abf2a7f125158e2b17f711047cfbf37167ca45` | Current producer bytes SHA256 `4da744f7bbe52cc96be5df9c6f035bf1de8c9cb394baf8f1d2b1f8af1b6b7ef1` |
| 10 | `tests/quality-sources.test.cjs:803` | `d2eda48bc42e72b636d6c3ffbc045eb9b3245338` | Literal selector `eb340…` equals SHA1(D); SHA1(selector) equals this finding |

For materials I independently constructed the recursively key-sorted declaration with selected public approved items, hashed it and separately recomputed its approval binding. The PDF bytes at the actual assets owner hash to `36269db33a71781084053ae40cc41e411a0106bea5e593ef0b08414014c4ca40`. For rights I acquired the current validated/rendered article facts, independently constructed the rights object from metadata/source/edition/media facts and hashed it without calling `editionNotice`. Both results equal the attributes in S. Reconstructing the article input/component/version object independently yields version `60b4eb071b9f8367227354032aec04364d783b02fb8f6f8d7d3cb59a05949bcc`; actual snapshot HTML hashes to `bbf8cf9e1fd980800a1e2dad9a2d60ebc29369923353601eff43e48dc533d040`, matching the revision. Thus D is tied to the current producer/source, not merely a hash-shaped public string.

## Ledger and storage preservation

Base checksum ledger has 3,151 rows, prepared ledger 3,161. Parsed prefix equality is exact, including row order/reasons; added IDs are exactly proof findings 1–10 and no others. The only metadata change is appended scope text. The prior-data digest reproduces `a2d41404c6d5ef3b1b03c13d32d69a07fdc10ae042d37d311c37ae8fe0818629` using UTF-8 Node `JSON.stringify` of the entire parsed original ledger, without spacing/newline. This serialization was clarified factually by the parent after my initial array-only diagnostic; the result was independently recomputed from Git bytes.

Other ledger files remain byte-identical to base: baseline SHA256 `8bff933ce846d5b1a0fa9a357f629c07d49af8626270ea40cfd658b760e293b0`; reviewed SHA256 `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb`; publication SHA256 `12482735843772e7041ea8b83eaad126362b4bdf644dad1a7951edc42055e696`. The current loader executes successfully without duplicate IDs across the four closed files.

| Original review | Decoded bytes | Recomputed original Git blob | Decoded SHA256 |
| --- | ---: | --- | --- |
| `code-final.md.gz` | 16,889 | `04d8f2cbed9ecb95dc87e32133f871f8b5267d6b` | `7d643cd15a3a80d49b3b86c6425d2e0d3eaadcecdc95932282eeefebae7761bd` |
| `exploratory-predecessor.md.gz` | 16,977 | `f2402ed4d605df0581da9101df55fe5aa958bda0` | `0a75d41689412c7a23f73ab65c65927cbb6c553b881d38857a496fababce73b9` |
| `requirements-final.md.gz` | 14,790 | `7aa5ef8b629646198da6294f0ee6e026fa74aa5b` | `5f7dcb18434ee3faf55799701086fd88722a58b5724ca1605445144a48c216bc` |

Each gzip decompressed byte-for-byte equal to its base Git file; I rederived blob identity with `SHA1("blob "+length+NUL+bytes)`. Original-path locator links and all five added catalog entries exist. No executable or parsed source was compressed. Gzip exclusion in detect-secrets and binary hashing in RI predate this delta; neither scanner input rule nor resource bound changes here. Current RI content-mode source bytes total 249,977,711, leaving 22,289 bytes under 250,000,000. Derived output records are excluded by the actual RI algorithm. Further tracked receipts/source changes can consume that margin and must reverify current-source RI; the preserved former over-bound observation is not erased.

## Actual executions and evidence

All reviewer commands were bounded to 60 seconds; no full scanner/browser/source campaign was rerun, no tests or implementation were edited, and no external writes/delegation occurred. The only reviewer output file is this artifact. Tests' own temporary fixtures are their existing implementations and clean up in `finally` blocks.

1. `timeout 60s node --test --test-name-pattern='only actually verified RI/coupling|the two public inventory paths|closed secret ledgers|browser SRI findings|browser integrity proof|public npm integrity dispositions|secret ledgers reject|secret ledgers require|all historical secret dispositions' tests/quality-sources.test.cjs`
   - Exit 0; native accounting: tests 11, suites 0, pass 11, fail 0, cancelled 0, skipped 0, todo 0; duration 261.028401 ms.
   - All eleven selected named cases passed: verified RI/coupling fields; inventory exact tuples; closed exact ledgers; browser exact IDs/proof; browser drift; browser malformed/missing/symlink/bounds; publication exact path/current lock; malformed metadata/entries; duplicate IDs; regular inputs/JSON/bounds; historical dispositions.
2. `timeout 60s python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify`
   - Exit 0: `Repository Intelligence context is fresh.`
3. `timeout 60s python3 tools/check_ri_ci.py verify`
   - Exit 0; pass true, 17 checks, 19 layers; source digest `c63c9de9a88ec93534000bf765aeedf18e1a0921bc6e535f7b8448f6f4aa593f`; live GitHub state explicitly false.
4. `timeout 60s python3 tools/check_code_style.py`
   - Exit 0; pass true, 156 scanned files, zero legacy occurrences. Scope is the bounded inline-style/CSS-owner/history/literal-import guard only.
5. `timeout 60s python3 -m unittest discover -s tests -p test_repository_intelligence.py -k 'binary_byte_changes'`
   - Exit 0; Ran 1 test in 0.013s; OK. Existing binary mutation changes freshness and is rejected.
6. `timeout 60s python3 -m unittest discover -s tests -p test_repository_intelligence.py -k 'hash_bounds'`
   - Exit 0; Ran 1 test in 0.002s; OK. Existing oversized binary fault is rejected rather than silently omitted.
7. Read-only Python/Node calculations described above: exit 0 for all completed identity, value, snapshot, archive and raw-report bindings. Two initial reviewer diagnostics failed visibly and were diagnosed before correction: Node's default 1 MiB `execFileSync` buffer produced ENOBUFS for the large prior ledger (then increased only this diagnostic buffer to 4 MiB); an incorrect reviewer PDF lookup under publications produced ENOENT (the actual target function routes file materials to assets, and that exact owner then verified). Neither was a candidate test failure or accepted pass; no failed campaign was retried.

Registry/CI disposition: reuse `tests/quality-sources.test.cjs`, permanent in `pr-targeted`, `staging` and `production`, owned by `guides/SITE-CHECK-PROFILES.md`; both changed guard and ledger are already declared inputs. Navigation directly runs the source suite; normal source/shard selection remains intact. RI freshness, RI binary mutation/hash-bound tests and RI/CI coupling already have navigation routes. No new duplicate suite or changed budget is needed. Native security remains the existing scanner/prepublication/staging workflow route.

## Native versus prepared evidence and AC impact

Retained native run 42227207673 attempt 1, artifact 13505454566, identifies the exact base/tree and reports security **false**, with Semgrep/Bandit true and secrets error `9 untriaged secret candidates`. Its detect-secrets raw hash `cd34b7c2400e8da7aaf5a693b28b54f9d95ff7b419697fd9f54a6acbc93c9629` matches its security manifest, with 9,216 raw candidate rows. All nine proposed native tuples and lines are independently present. This failure is preserved and not converted into a pass.

Additional parent-supplied primary evidence, inspected independently: `prepared-check-receipts.json` binds the supplied packet and raw prepared reports. All seven named receipt files matched their stated sizes/SHA256. Prepared `security.json` SHA256 `5549f2742883271dce7cec04976ee3c179ee273c6b77cc503782c90201697210` reports all three engines true; each engine raw file independently matches its manifest hash. Prepared secrets: 1,662 tracked text files, 9,222 candidates, 380 generated admissions, proof 47 files/450 checksum IDs. The actual prepared raw report contains the tenth selector at line 803. These are retained local observations, not a fresh reviewer scan. The report carries the predecessor commit/tree/artifact fields and has no hosted run/attempt; the receipt explicitly identifies dirty prepared source. It cannot supply native clean-head security or stable staging acceptance.

AC05/CS08 and AC11 receive bounded behavioral/structural QA evidence, subject to the isolation disclosure above. Whole AC05/AC11 and delivery-related criteria remain pending: actual independent role admission, final-source checks/CI, controller source/artifact binding and hosted/stable staging are separate gates. No merge, production, external publication or issue closure was observed or authorized by this review.
