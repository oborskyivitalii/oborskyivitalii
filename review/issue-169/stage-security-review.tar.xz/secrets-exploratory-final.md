# Exploratory / Interaction QA — issue169 / PR170 security correction

Verdict: no blocking finding in the bounded changed operator journeys actually exercised. This is a completed independent exploratory result for the prepared dirty candidate, not a current hosted security/staging pass or release authorization. Whole AC05/AC11 and DELIVERY remain pending their other required evidence.

## Identity, authority and independence

- Role/task: Exploratory / Interaction QA, `/root/secrets_exploratory`; first result for this prepared security candidate. Distinct nonauthor review; no implementation, accepted test edits, external writes or delegation.
- Repository: `/workspace/scratch/20e98a342431/author-site`; HEAD/base `186f28c0ad8f94b21c350d50608d337f64c66708`, base tree `8b09d57484b1102e2b3f9affc020b9a3d12cc297`. Candidate has staged changes; it is not a clean checkout and has no new commit identity in this receipt.
- Packet: `security-candidate-packet.json`, SHA256 `ef50c5c287b771d25fc1ce181b18a41fe6767249c1f07ee4dc2bd1b9306b95d1`; supplied patch SHA256 `6b2d91b772a159333c21770c9a7b1cf118f636f92d6cddb845cdb5e5d478d9a5`. All packet source/evidence pins matched, and were rechecked immediately before writing this report. The packet's path/byte pins plus patch identify the reviewed prepared subset.
- Common contract `agents/reviewers/README.md`: SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/exploratory-interaction-qa.md`: SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Launch brief explicitly requested none-fork isolation. The accepted task is observable here; the orchestrator's exact spawn argument/accepted response receipt must accompany it. Provider model/context/memory internals are unknown and are not attested by this report. No author conversation, MEMORY, parent scratch diagnostics or peer conclusions were read. The three retained historical review archives were decoded solely for byte comparison, with no report-body interpretation or output.
- Scope: proceed through existing required checks to verified stable staging, then STOP/show author; no merge/production. Owning issue snapshot and existing AC IDs were read. AC05 source/evidence hygiene and AC11 distinct review execution are directly affected; article/visual/publication acceptance is not replaced.

Read authoritative instructions and actual relevant sources: root AGENTS/CONTRIBUTING/README, reviewer common/role, repository map, acceptance policy, CODE-STYLE relevant source boundaries, scanner/check-profile/release-gate contracts; `scanners.cjs`, its actual diff, focused existing test, closed review ledgers, compressed factual proof, supplied native failed security report, and current public bytes. `git ls-files '*AGENTS.md'` reported only the root guide. Reports linked by the packet are review subjects, not independent pass evidence.

## Charter fixed before execution

Exercise the changed finite secret-admission path as a tooling operator: load actual ledgers; try both retained and new inventory identifiers at both authorized paths; remove ledger authority, change path/type/value; check all ten prepared exact review tuples and their source locators. Then follow retained-evidence locators to gzip payloads and verify byte preservation. Establish browser applicability against actual public/authored output parity. Use at most 60 seconds per check; no full scanner/browser campaign, deployment or speculative rerun. Dynamic commands below used a 55-second timeout; every one completed normally in well under one second.

Environment: Linux workspace, Node v24.22.1, Python3.12.14, local Git object access. `SITE_REPORT_DIR` was set to the existing evidence directory when importing the scanner. Existing test fixtures may use temporary files; no source or test file was changed.

## Executed actions and observations

| Journey / expected result | Actual action and raw result | Disposition |
| --- | --- | --- |
| Exact candidate dependencies remain bound | SHA256-checked every packet pin and the supplied patch; all matched. Recheck before report also matched. Git HEAD remained the supplied base with staged candidate changes. | Pass, prepared subset only |
| Current ledgers load without schema/size relaxation | Imported the production `scanners.cjs` export and called `loadSecretReviews()` on the actual checkout: `CURRENT_LEDGER_LOAD 16117`. | Pass |
| Existing and new inventory generations both admit only finite tuples | For both inventory paths, tested hashes `41ceb5699f64d5bfeaccc5850d0cf398a19b10c9` and `eb3400c0b18476eb7e38e5a430d52a263f917b89` through actual `reviewedSecretFinding`. Exact tuple returned true; empty ledger, unrelated path, altered hash and Hex-type substitution each returned false. | 20 actual checks passed |
| Ten exact prepared dispositions work without accepting altered values | Loaded nine native proof entries plus one prepared test-selector entry. Actual admission returned true for all10; replacing each hash with `a` repeated40 returned false. Combined harness output: `PROOF_TUPLES 10`, `FINITE_ADMISSION_CASES 40 passed`. | 20 further actual checks passed |
| Focused maintained CLI regression remains executable | `timeout 55s env SITE_REPORT_DIR=/workspace/scratch/20e98a342431/evidence-169 node --test --test-name-pattern='the two public inventory paths each require their exact reviewed tuple' tests/quality-sources.test.cjs`. Native output: `tests 1`, `pass 1`, `fail 0`, `cancelled 0`, `skipped 0`, `todo 0`, `duration_ms 109.31834`; tool exit0. | Pass; one selected test, not the full suite |
| Factual proof can be followed back to exact source | For each of10 entries, loaded its original Git file or current changed test, matched whole-file SHA256, verified exact value at originalLine and recomputed the scanner's SHA1 identifier. Independently verified snapshot directory exists/nonempty, actual ancestor commit relationship, four producer-file byte hashes at historical/current refs, and test selector derivation from the public snapshot path. Both HTML values were found in their named native binding attributes. Output: `ALL_10_LOCATORS_AND_REFERENTS_PASSED`. | Pass for locators/referents; HTML binding digest recomputation not repeated |
| Original review evidence stays recoverable through original-path locators | Read only the three new short `.md` locator stubs, resolved each relative `.md.gz` target, decoded to memory and compared full bytes against the corresponding base Git blob. All3 were identical. Raw sizes: code16889, requirements14790, exploratory16977 bytes. | Pass, lossless local navigation |
| Delta introduces no changed site/browser interaction | Read every tracked `docs/` and `site/` file, computed its Git blob identity from actual bytes and compared against the base tree: `PUBLIC_AUTHORED_BYTE_PARITY {files:366,bytes:36240897,mismatches:[]}`. `git diff HEAD --name-only -- docs site` was empty. | Pass, exact local parity |

Raw execution output is retained in this task's tool transcript: focused native test chunk `f9310f`;40-case admission and public-byte harness chunk `1dc8d3`; original archive byte/readback chunk `5fe6df`;10 source-locator/referent checks chunk `1efa30`. These bounded observations are summarized here without converting them into an unexecuted complete scanner pass.

Decoded original archive SHA256s:

| Original path under `review/issue-169/native-reviews/` | Decoded SHA256, equal to prior Git bytes |
| --- | --- |
| `code-final.md` | `7d643cd15a3a80d49b3b86c6425d2e0d3eaadcecdc95932282eeefebae7761bd` |
| `requirements-final.md` | `5f7dcb18434ee3faf55799701086fd88722a58b5724ca1605445144a48c216bc` |
| `exploratory-predecessor.md` | `0a75d41689412c7a23f73ab65c65927cbb6c553b881d38857a496fababce73b9` |

## Findings, applicability and allocation

No blocking defect observed in the examined current/new exact admission, missing-authority refusals, changed-value/path/type refusals, proof-locator recovery or archive byte-preservation journeys. The changed production set adds exactly two new path+type+hash tuples; the four old/new finite tuples still require individual ledger authority. The tests extend the existing loop rather than weakening those refusals.

Public browser/UI work is reasoned not applicable to this bounded delta: all366 actual public/authored files are byte-identical to base and the changed runtime is build/check tooling. No browser was launched and no desktop/mobile/perceptual pass is claimed. GitHub's hosted gzip download/display affordance was not observed; local locator resolution and actual decompression were exercised. Hosted site/current security/staging is a separate applicable mandatory gate, not N/A.

The focused case already has an owner/route: `tests/quality-sources.test.cjs` is permanent under `guides/SITE-CHECK-PROFILES.md`, allocated to `pr-targeted`, `staging`, `production`; `.github/workflows/navigation.yml` includes it in the bounded profile/gate fixture job, and the registry retains `node tools/quality/source-tests.cjs --profile production`. Keep its existing negative refusals and source selection. No new mandatory browser/device matrix or duplicate full campaign is proposed. Archive decoding/byte equality remains this bounded operator observation and the factual storage proof; it is not a new runtime/browser test claim.

AC impact: this result supplies only this role's completed independent scoped review toward AC05/AC11. It does not close either whole criterion or article/copy/visual/delivery criteria. Exact launch admission remains the orchestrator's receipt responsibility. Current native security, Basic/RI/CI, other three role results, complete required hosted staging and exact served stable origin remain necessary. No merge, stable promotion or production was executed by this reviewer.

Limits: no full security engine invocation, full source suite, browser campaign, live GitHub/hosted artifact download, current served staging verification, physical-device observation, empirical coverage percentage or general security guarantee. Native failed run42227207673 remains preserved as failed; targeted local admission cannot erase or replace it. No dynamic failures occurred in the executed checks, so no campaign rerun or corrective implementation was performed.
