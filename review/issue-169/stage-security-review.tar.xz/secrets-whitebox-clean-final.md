# Issue 169 / PR 170 — independent White-box QA

## First independent verdict — 2026-11-06

**PASS for the bounded prepared security correction; no blocking implementation or test finding.** This is a dirty, manifest-pinned candidate, not a new clean Git commit or a hosted acceptance result. The ten new exact dispositions have independently checked noncredential derivations. Old/new inventory admission, unknown-value refusal, closed-ledger authority, historical data preservation, scanner failure propagation and lossless storage are protected in the inspected scope.

This result supplies this White-box execution only. AC05 and AC11 remain pending as whole criteria. Fresh exact-source native security/CI, complete owner staging and actual stable-promotion verification remain required. The authorized stopping point is verified stable staging, then STOP/show; no merge or production is authorized here.

## Execution, inputs and isolation

- Role/task handle: distinct nonauthor White-box QA, `/root/secrets_whitebox_clean`; first judgment for this prepared candidate. I authored no implementation or accepted test changes and delegated no work.
- Requested isolation: task explicitly identifies a fresh `fork_turns="none"` launch. Its parent-side accepted launch response/agent ID is not present in this execution's supplied material and must be attached by the orchestrator. No model/effort override or separate provider execution identifier was supplied here. Provider model/context/memory internals remain unknown; shared filesystem access is not a security sandbox.
- Repository: `/workspace/scratch/20e98a342431/author-site`; owner issue 169, PR 170. Local HEAD/base `186f28c0ad8f94b21c350d50608d337f64c66708`, base tree `8b09d57484b1102e2b3f9affc020b9a3d12cc297`.
- Packet: `/workspace/scratch/20e98a342431/evidence-169/security-whitebox-packet.json`, SHA256 `c02405772bbd414c9d50e964afd3547fb1cd5c21b7656a084ba634ae83606419`.
- Prepared diff: `security-whitebox-candidate.patch`, SHA256 `fce381eb3f5e97894eca8a6b1c1ad5d175a1e49c84a46fe474cc59cf5adfcf50`. Its protected historical Markdown deletion hunks and MEMORY text were intentionally omitted. All 16 current changed paths match the packet's changed-path manifest.
- Common prompt: `agents/reviewers/README.md`, SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role prompt: `agents/reviewers/white-box-qa.md`, SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- All 31 supplied path/byte pins and the diff digest matched. They matched again after bounded verification. MEMORY was never read as prose; only its current byte digest was compared with the generated RI input pin.
- Read root README, AGENTS, CONTRIBUTING, CODE-STYLE, acceptance policy/contract, applicable RI/profile/source owners, changed scanner/test/ledger/proof data and supplied primary native/prepared reports. The AGENTS inventory found only the root applicable AGENTS.
- Exposure: no current dirty-candidate peer report, parent scratch note, private chat or protected historical review prose was inspected. A live `get_pr_info` metadata request also returned the PR description, including the author's summaries of earlier base-candidate reviews/checks. Those assertions were not an oracle for this judgment. The candidate follow-up's claims were likewise treated as review subjects. The original three historical review texts were handled only as bytes/hashes, never displayed or decoded into prose.

Live PR metadata independently showed open, Draft, unmerged; head was the base above and target `main` was `8cf15883125892710633b17133d9ee0fc4b23b92`. The combined-status endpoint returned `statuses: []`; this endpoint response does not establish check-run success or absence. No external mutation occurred.

## Independent exact-value checks

For every row, I checked SHA256 of the original source bytes, the specified original line, SHA1(value) against the exact scanner ID and an actual matching raw scanner finding. Rows 1–9 match the retained native report; row 10 matches the prepared raw report and current test bytes. The ledger additions are exactly this set, with no extra ID.

| # | Exact path / rule | Scanner hash | Independent derivation |
| --- | --- | --- | --- |
| 1 | `.github/repository-intelligence/agent-context.json` / Base64 | `eb3400c0b18476eb7e38e5a430d52a263f917b89` | SHA1 of the actual current public snapshot-directory literal below; current native build check passes. |
| 2 | `.github/repository-paths.json` / Base64 | `eb3400c0b18476eb7e38e5a430d52a263f917b89` | Same literal in its other exact inventory owner; a separate ledger tuple is required. |
| 3 | Current article snapshot HTML / Hex | `239eff03f73cb653046fe877418db8bcdfbdde28` | Native `article-materials.load` reproduced `data-materials-binding` = `ce917b057b33baa5f9963f5c588c40849432024d4009e574d041377b6c23e41a`. |
| 4 | Current article snapshot HTML / Hex | `df34e166e25fbbc57619b0c3a712708457b929c1` | Native `articles.editionNotice` reproduced `data-article-rights` = `377a71083ffdf51ffbe849e34a0dfa684678126c9d8e19aaf097c7f34d237bc0`. |
| 5 | `tools/check_site_seo.cjs` / Hex | `4281b49ac162f351840f1b563699e9eedfc0f0cb` | Actual commit `d5e915feb3ba02d7a80325664c9d1d10a2ac494e`; Git object type is commit and it is an ancestor of the pinned base. |
| 6 | `tools/check_site_seo.cjs` / Hex | `2e663e5b6b333b10049bcf7f057fece8ccc7f647` | SHA256 of `tools/site/render-records.cjs` at that ancestor = `24f1bec530b762009a6b03a1d91700e7ee5c56345a0b8d9a4a4c6f0ff561038c`. |
| 7 | `tools/check_site_seo.cjs` / Hex | `598f7e14fe23f4157fc5b8a746329bbc9110e83c` | SHA256 of its complete current `render-records.cjs` bytes = `85a0478ec37ffd65778b6f10dad08d420c42559ec2faeb15786ff983e7c4006c`. |
| 8 | `tools/check_site_seo.cjs` / Hex | `ce1e43ee9450a23deccfe23ec6dc10a4e58014ae` | SHA256 of `tools/site/validate-catalog.cjs` at that ancestor = `6a61f3af40e94c42b4240c1afb21a2a25474f2cf58381a2c40f12dea12becc6c`. |
| 9 | `tools/check_site_seo.cjs` / Hex | `26abf2a7f125158e2b17f711047cfbf37167ca45` | SHA256 of complete current `validate-catalog.cjs` bytes = `4da744f7bbe52cc96be5df9c6f035bf1de8c9cb394baf8f1d2b1f8af1b6b7ef1`. |
| 10 | `tests/quality-sources.test.cjs` / Hex | `d2eda48bc42e72b636d6c3ffbc045eb9b3245338` | SHA1 of `eb3400c0b18476eb7e38e5a430d52a263f917b89`, which itself is SHA1 of the verified public directory literal. This is the exact tuple-selector test constant. |

Public directory literal: `docs/article-snapshots/60b4eb071b9f8367227354032aec04364d783b02fb8f6f8d7d3cb59a05949bcc`.
The exact HTML path for rows 3–4 is that directory plus `/the-sdlc-is-out-of-balance.html`.

No disposition depends merely on hash shape or public appearance. The native rights/material functions were invoked with the actual canonical article ID `sdlc-out-of-balance` and current source/resources. The maintained native builder's `--check` independently accepted the generated tree and output lock.

## Preservation and structural invariants

- Companion rows: 3151 predecessor rows are structurally identical to the new ledger prefix, including order and reasons; exactly ten rows are appended, producing 3161. Only the existing `scope` metadata string is extended; schema, owner, issue and reviewed date remain unchanged. The proof's `priorLedgerDataSha256` is SHA256 of compact JSON serialization of the **whole parsed predecessor ledger**, preserving insertion order, and matches `a2d41404c6d5ef3b1b03c13d32d69a07fdc10ae042d37d311c37ae8fe0818629`. It is not a digest of the findings array alone.
- Other ledger bytes equal the base exactly: baseline `8bff933ce846d5b1a0fa9a357f629c07d49af8626270ea40cfd658b760e293b0`; historical reviewed `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb`; publication `12482735843772e7041ea8b83eaad126362b4bdf644dad1a7951edc42055e696`.
- The scanner delta adds only the two new exact inventory keys to the existing finite set and adjusts its comment. Both old keys remain. A key still requires its own exact ledger record; no path/type/value wildcard or generic Base64 path was introduced.
- `secretReviewEntry` still verifies fixed metadata/entry schemas, exact normalized relative paths, allowed rules, disposition/reason and ID consistency. The closed four-file input list, duplicate rejection, regular-file/symlink check and 2,000,000-byte ledger limit remain.
- `reviewedSecretFinding` still joins path/type/hashed value. Base64 admission still requires the exact inventory key, or the existing separate current publication/browser SRI proof. Unknown values and altered paths/types do not gain admission.
- Current generated checksum proof, detector rules, tool pins, profile registry, source worker, prepublication controller, workflows, RI producer and website builder are byte-identical to base. Native/prepared detect-secrets version 1.5.0, all 27 plugins, plugin limits and filters match.
- Failure flow still retains raw reports, attempts sibling engines after a failure and rejects failed prerequisites. Existing actual-control-flow tests exercise this; no timeout, worker, case or budget change appears in the bounded diff.

| Preserved historical review | Git blob | Decoded SHA256 | Original / gzip / locator bytes |
| --- | --- | --- | --- |
| `code-final.md` | `04d8f2cbed9ecb95dc87e32133f871f8b5267d6b` | `7d643cd15a3a80d49b3b86c6425d2e0d3eaadcecdc95932282eeefebae7761bd` | 16889 / 7422 / 129 |
| `exploratory-predecessor.md` | `f2402ed4d605df0581da9101df55fe5aa958bda0` | `0a75d41689412c7a23f73ab65c65927cbb6c553b881d38857a496fababce73b9` | 16977 / 7383 / 142 |
| `requirements-final.md` | `7aa5ef8b629646198da6294f0ee6e026fa74aa5b` | `5f7dcb18434ee3faf55799701086fd88722a58b5724ca1605445144a48c216bc` | 14790 / 6425 / 137 |

For all three, gzip decompression equals the exact prior Git bytes, not just a claimed checksum. Original size, decoded SHA256, Git blob, gzip size and gzip SHA256 match the proof. Each original path contains its archive filename locator. The detailed Git identities reside in the compressed proof; the small original-path locators do not themselves repeat those hashes. No active test/tool/site/workflow consumer of these three Markdown bodies was found; two old ledger reason strings retain historical path references. Their prose was not inspected.

The net archive-plus-locator saving is 27,018 bytes. Current RI content-input sizes sum to 249,977,711 bytes under the unchanged 250,000,000-byte cap, leaving 22,289 bytes. This measured margin applies only to this pin: adding receipts or other source bytes requires rebuilding/verifying RI again.

## Risk → scenario → oracle → check allocation

| Risk / AC | Structural fault and scenario | Independent oracle | Actual check / owner route |
| --- | --- | --- | --- |
| AC05: overbroad inventory exception | Old/new value on either inventory path; missing ledger; changed path, type or value; invalid companion key | Only the four enumerated tuples, each with a ledger entry, can pass | Existing `the two public inventory paths each require their exact reviewed tuple`; executed with the other bounded source cases below |
| AC05: admission authority expansion | Neighboring ledger, malformed schema/path/rule/ID, duplicate ID, missing/nonregular/symlink file, invalid JSON, 2 MB boundary | Closed four-ledger authority; unknown/invalid input fails visibly | Existing closed-ledger, malformed, duplicate, bounded-input and historical-preservation tests; executed |
| AC05: suppressing a genuine secret | Missing producer verification; wrong SRI field/lock/install; changed path/value | Producer-derived fields and exact current proof remain necessary | Existing RI/coupling and publication/browser SRI positive/negative tests; executed |
| AC05: incomplete scanner execution accepted | One engine failure or invalid prerequisite with later engines available | Retain failure and raw evidence; do not turn partial execution into pass | Existing independent-engine and actual category-control-flow tests; executed |
| AC05: false public-value proof | Ten literal IDs copied incorrectly or without referents | Original Git source/line/SHA1 plus actual raw finding, actual Git ancestry/source SHA256 and native binding output | Read-only proof commands, actual native article functions and native builder check; executed, ten exact rows confirmed |
| AC05/11: evidence lost to storage optimization | Archive differs, missing locator or changed historical oracle | Decode exactly to prior Git bytes; keep path locator and detailed immutable proof | Byte/hash checks for all three, active-consumer search and RI checks; executed without historical prose |
| AC05: tests present but unselected | Changed scanner/ledger/test not routed to a maintained suite | Registry declares actual input dependency and selected CI invocation | `quality-sources.test.cjs` is permanent in pr-targeted/staging/production, maps scanner and all four ledgers; navigation `test-profile-regressions` runs it in job `navigation` under mapped ready-PR scope; current RI-CI verify passes |
| AC05: stale generated inventory | Catalog/archive/source bytes changed without refreshed projections | Canonical regeneration must match current generated outputs | RI verify plus all 29 RI regression tests; executed |

The same suite also runs through source-test selection/shards in `site-checks.yml`; staging/production source profiles and prepublication retain their existing routes. No new suite or proposed test was authored. These are selected scenarios and structural inspection, not a measured branch-coverage percentage or full release campaign.

## Actual bounded execution and primary evidence

All final commands below exited 0 without a signal or timeout. No full source/native/staging campaign was rerun.

1. `timeout 60s node --test --test-reporter=spec --test-name-pattern='the two public inventory|closed secret ledgers|secret ledgers reject|secret ledgers require|all historical secret|only actually verified|browser SRI|browser integrity proof|public npm integrity|independent scanner engines|actual scanner category' tests/quality-sources.test.cjs`
   - 13 tests, 13 pass, 0 fail/cancelled/skipped/todo; reported 512.913606 ms.
   - Includes both generations of each exact inventory tuple, missing-ledger and wrong-path/type/value refusals, ledger schema/authority/size negatives, unchanged SRI proof requirements, historical rows and actual sibling-failure behavior.
2. `timeout 60s python3 -m unittest discover -s tests -p test_repository_intelligence.py`
   - 29 tests in 34.828 s, `OK`, no skips reported. Includes byte mutations, binary freshness, catalog/instruction routing, bounds and reviewer-route cases.
3. `timeout 60s python3 tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify`
   - `Repository Intelligence context is fresh.`
4. `timeout 60s python3 tools/check_ri_ci.py verify`
   - pass; 19 layers, 17 checks; source digest `c63c9de9a88ec93534000bf765aeedf18e1a0921bc6e535f7b8448f6f4aa593f`; `live_github_state_verified: false`.
5. `timeout 60s python3 tools/check_code_style.py`
   - pass, 156 scanned files, 0 legacy occurrences, bounded automatic scope only.
6. `timeout 60s node tools/site/build.cjs --check`
   - `{"built":["index","research","writing","talks","credits"],"reused":[],"removed":[]}`; canonical generated tree/output lock accepted. This check cleans its temporary generation directory; no authored source was changed.
7. Read-only Python/Node byte/proof commands: ten source/line/hash/raw matches; five Git/producer referents; two native bindings; predecessor ledger prefix and whole-data digest; all other ledger bytes; three gzip/Git equality/identity checks; final 31 pins and changed-path manifest.

Retained native failure: run 42227207673, attempt 1, artifact 13505454566, archive SHA256 `9f43457d1f8594f008a1b48b402bdad80a484b2b1cbc916d575407463d8e4be4`. `failed-42227207673/security.json` SHA256 `d838fd053a3a7fcef7e54ab841aa68fe17ed8d84dc947d871bac7dcea382bbf3`; raw detect-secrets SHA256 `cd34b7c2400e8da7aaf5a693b28b54f9d95ff7b419697fd9f54a6acbc93c9629`. All raw report byte counts/hashes referenced by both inspected security wrappers match the retained files.

Native accounting is 26 prepublication guards completed, **25 passed / security failed**. Source-tests passed in 201708 ms. Security failed after 76613 ms with exit 1, no signal, and nine untriaged candidates; Semgrep and Bandit engines passed. Prepublication `pass`, `fullGate`, `productionEligible` and `deploymentAuthorized` are all false. The failed result is preserved and is not waived.

The supplied dirty-local `prepared-security/security.json` reports all three engines passing; secrets accounting is 1662 tracked text files, 9222 candidates, 380 generated admissions across 47 proof files / 450 checksum IDs. Its raw detect-secrets SHA256 is `684551b590a73329fb68339d7d5143e8d1e606ae94c0aff98e810cfe08d98baa`. This corroborates local diagnosis only: its wrapper still names the base commit/tree and has no hosted run identity or dirty-source manifest of its own. The packet pins the prepared source separately. I did not treat the wrapper as current clean/native/staging acceptance. The proof's earlier additional-finding `freshRawReportSha256` (`96d5caecdeeb0a0e497c27bcb0daa2c034eead30d8decfa4565a24a114e89b8a`) is not the current prepared raw report; that earlier raw file was not independently available through the supplied primary report path. Row 10 was instead independently matched to the current prepared raw report and source.

## Reviewer diagnostic errors retained separately

These were errors in my read-only diagnostic commands, not candidate test failures; their initial outputs remain in the execution record. Each follow-up corrected the identified command/input assumption rather than retrying an unchanged campaign.

- A Node `git show` read used the default child-process buffer and failed `ENOBUFS` / SIGTERM, exit 1. `git cat-file -s` then measured the ledger as 1,659,338 bytes, exceeding that default buffer; a bounded 2,000,000-byte buffer resolved the read.
- An RI invocation omitted required `--config` and exited 2 with usage. The explicit documented config invocation passed.
- An article diagnostic supplied the public slug `the-sdlc-is-out-of-balance` as an internal ID and was rejected, exit 1. The canonical publication metadata established ID `sdlc-out-of-balance`; both native binding checks then passed. That earlier diagnostic also compared a findings-array digest with the whole-ledger digest; direct serialization inspection resolved the mismatch without modifying evidence.
- An overstrict diagnostic asserted that every small locator repeats all Git hashes; its Python component failed an assertion (the combined shell's later successful search masked that component's status). Byte-only inspection showed all three locators contain their gzip filename, while detailed identities are in the proof. The actual lossless/Git/hash/size checks all pass. No locator prose was displayed.

## Findings, AC effects and limits

No defect requiring a source/test change was found. The protected invariant is finite exact tuple admission backed by individual reproducible noncredential evidence, with all unknown/malformed candidates and failed checks remaining blocking. Original ledger history, scanner types/thresholds/inputs and resource limits remain intact.

AC05 receives bounded security/negative-case/storage/RI/style evidence, not complete source/release acceptance. AC11 receives one independent White-box result only, subject to the orchestrator's actual launch receipt. Editorial meaning, rights decisions, PDF/visual acceptance and other unchanged R10/Writing/DevCon behavior were not re-reviewed here; the bounded diff contains no edits to their public source/runtime/assets. No UI/operator surface was added by this correction. Browser/device/hosted execution is not observed by this review and remains with the existing owner staging route.

Keep current full AC checkboxes pending except the historical Draft milestone; do not infer clean CI, successful stable staging, merge, production or publication from this report. Any relevant byte change after this pin requires affected re-review and current-source verification. This is the first independent result; no reconciliation or peer-verdict revision followed it.
