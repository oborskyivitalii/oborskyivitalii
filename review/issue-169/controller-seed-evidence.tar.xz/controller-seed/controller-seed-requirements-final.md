# Requirements & Acceptance — prepared fixed controller seed

Verdict: **the inspected candidate conforms to the accepted fixed-input preparation boundary; no blocking requirements defect found.** The focused isolation/refusal case passes. Full controller accounting/timing, negative control, other independent roles and exact-source/native delivery checks remain pending; this is not an unconditional readiness or staging acceptance.

## Identity and inspected scope

Continuation of `/root/fix_requirements` following its own `controller-seed-requirements-preflight.md`, not a new clean-context first judgment. Prior generic-memo/default-cloning findings remain preserved and are outside the implemented design. No current peer report, parent scratch note or private history was read. No source/test mutation, test/campaign execution, delegation or external write was performed; only this assigned report was written. Existing provider/context/isolation limits remain unchanged.

Candidate packet SHA-256 independently verified: `4b2f317e8d51d34f7291c5c1e6a1cfa7c1225c3fc721c3b1db18797465a49e6e`. Actual dirty tree has only `tests/release-controller.test.cjs` modified over baseline `3c4393dc3ddd2c4a324ac91f4bfef4485cfc2534`. Its SHA-256 is `ae261cc44e020042ebc51fa0517f7b04dea0a3d19a4f7e95fc970698436f7cbe`; all eight packet file hashes matched actual bytes. Supplied diff SHA-256 `61c3b39c6d3ffc77509826d69e70e84f07e2f7d13a61668def39c1e9be2d6f82` independently matches the actual working-tree diff exactly. `git diff --check` succeeds.

Common/role prompt identities remain `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` and `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. The unchanged shared delivery helper and product compiler hashes are `4bf3c43e42c63d5006d209d7c85acaceb86ad62b457e36c29882d71056b66adf` and `07a3801b5b7bec3e19d12005a0011b3591b63db08e1bfd6f2f4b5b9c77d2d8a3` respectively.

## Preserved oracles and design assessment

Independently compared baseline and candidate text. The original constructor's operations from source creation through returning fixture state are byte-for-byte unchanged; only ownership of the supplied temporary directory changes. Every original test from the first original test through EOF is byte-for-byte unchanged, SHA-256 `0ad162b521c9a2a35fab4656c91927d6efb7274d174c46795abde3119f6efd6e`. Original 30 cases are retained; candidate adds one isolation case, for 31 total. This is stronger preservation evidence than checking test names/counts alone.

The module before hook creates a new private seed directory and invokes that real constructor. Existing edition build, rights compilation with actual source/Git/media, package CLI, raw evidence hashing and archive creation run once; no old checked-in artifact or fabricated pass is introduced. Global module after-hook cleanup is registered before hooks execute, and the root is assigned before expensive preparation, so ordinary setup failure still leaves a cleanup target. No setup exception is caught or converted to success. Per-test temporary cleanup remains through the unchanged delivery helper.

Each `releaseFixture(t)` copies the complete seed tree with `fs.cpSync`, then performs one `structuredClone` on the complete returned data graph. This preserves any internal graph aliases within one copy and prevents shared objects between cases. Four explicit path fields are relocated to the new test tree; no broad replacement of source/report contents occurs. The resulting inputs are fixed snapshots, not new compiler requests under later changed dependency state. The 14 inspected original callers still make their original controller/Pages/CLI/rights verification calls and mutations on the independently prepared trees.

The generic cache defects do not apply as dependency-equivalence claims: no cache key, successful validation memo, source-input hit branch, environment identity assumption or shared delivery-helper change exists. Git provenance is actually established during one current seed preparation, and its full source clone is copied as part of fixed test data. Neither this review nor the candidate asserts that later producer/Git mutations constitute equivalent fresh-source compilation; such new caller preconditions would require the original constructor or a new assessment.

Additional primary owner snapshot `issue169-current.json`, SHA-256 `a696b69f0001d019645a108307f22a9f5990715e5cf2816957ed9b3d92c1c89f`, was verified and inspected for current owner/acceptance boundaries. It retains issue169 open, PR170 ownership, required independent/exact-source/delivery gates and whole-AC pending status except historical AC06. Its historical publication authorization does not override the current task packet's narrower stable-only stop boundary. The active after-run/observer stream has no completed result incorporated here; baseline accounting is the completed first 27 observer records, not later appended phase records.

## Intent / requirement / evidence matrix

| Requirement / linkage | Actual oracle and source | Observed result and limitation |
| --- | --- | --- |
| Preserve original 30 cases and unique integration/refusal coverage | Actual diff, exact original suffix comparison and unchanged constructor operations | Preserved structurally; original bodies include actual action CLIs, altered rights/archive/robots refusals, recovery and policy cases. Full execution pending |
| Complete independent file state | New case inventories all relative file paths and SHA-256 bytes for seed/two clones; artifact enumerator rejects symlinks/non-files; each cloned file requires nlink 1 | Focused pass supports complete byte/path equality and independent files, including copied Git/source/public/evidence/sidecars |
| No seed path leakage | New case requires serialized cloned fixture data to contain no seed temporary prefix; helper explicitly relocates temp/assets/source/rights-source roots | Focused pass; original source records contain relative paths and original aggregate clone preserves graph structure |
| Independent nested mutable objects | New case mutates first proof rights flag, first returned report policy and first source tree field; compares second and seed to original deep snapshots | Focused pass; no cross-case object alias observed |
| Changed copy reaches real refusal | First clone's actual `rights.json` policy changed; real `rights.readPublication` must refuse with archived-report-changed message | Focused pass; not a generic throw-only assertion |
| Clean second copy remains valid | Second clone/seed byte inventories unchanged; real edition verification and frozen publication read succeed with exact inventory digest | Focused pass; later original cases still supply additional controller/CLI mutation coverage |
| Actual setup, bounded lifetime and cleanup | Module-local seed only, one actual constructor, global before/after plus unchanged per-test cleanup | Source conforms. No cross-process/run cache or additional framework. Injected setup-failure/cleanup behavior not independently executed by this role |
| Preserve custom/dynamic source paths | Original pending/confirmed-policy, Color/social and staged-source authentication cases remain outside fixed constructor and unchanged; shared helper/product/rights-suite hashes unchanged | Preserved structurally; independent native-current-article CLI remains original |
| Actual focused validation | `fixture-baseline-fix/copy-case.tap` plus empty stderr | 1 test/pass, zero fail/cancel/skip/todo; overall 3090.024829 ms, test body 359.06702 ms. Setup is included in overall time |
| Meaningful regression detection | Proposed alias/omitted-tree negative control | Pending; no negative-control success invented |
| CS07 throughput | Retained before module 30/30 in 69692.28964 ms; new complete 31-case module with all old cases and new copy cost | After timing/accounting pending; no measured speedup/native margin claim yet |
| AC05/AC11 and actual delivery | Current-source Basic/style/RI/owner selection, distinct Code/QA, native source/security/staging/hosted/stable source/article/PDF observation | Pending. Dirty local result is not clean-head admission |

## Findings and remaining gates

No blocking requirements finding remains in the inspected implementation. Examined risks were preserving fresh-constructor preconditions, setup failure propagation/lifetime, copied source/Git completeness, path relocation, shared mutable graph/files, validator suppression, loss of original case bodies, default/custom/native fixture scope, and overclaiming partial validation or speedup.

Accept only this exact source or obtain affected delta review. Preserve the original native timeout and diagnostics. Finish full controller execution/accounting and comparable timing plus the planned meaningful negative control; retain failures and check final source hashes. Required Code/QA/current-source checks and native source/security/staging/hosted gates remain. Verified stable staging then STOP/show is still the current task boundary; no whole-AC, merge or production acceptance follows from this prepared-candidate review.
