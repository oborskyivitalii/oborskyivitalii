# Code Reviewer — first independent result

Verdict: no blocking code findings in the supplied one-file fixture-seed candidate. This is bounded code-review acceptance, not readiness, security, full-source, native-platform, stable-staging, merge or production approval. Required current-source checks and other role results remain separate gates.

## Identity and inputs

- Role/task: distinct nonauthor Code Reviewer, `/root/controller_seed_code`; first judgment. No implementation, external writes or delegation performed. Only this assigned report is written.
- Repository: `/workspace/scratch/20e98a342431/author-site`; owning issue169, Draft PR170. Observed `HEAD` is `3c4393dc3ddd2c4a324ac91f4bfef4485cfc2534`; observed status contains only `M tests/release-controller.test.cjs`. This is a dirty candidate, not a clean tested commit.
- Original bounded intent from supplied task/packet: repair staging throughput while preserving tests, rights/CLI/source/security checks and original budgets; reach verified stable staging, then STOP/show; no merge or production action in this task.
- Candidate packet SHA-256: `4b2f317e8d51d34f7291c5c1e6a1cfa7c1225c3fc721c3b1db18797465a49e6e`.
- Actual `git diff` and supplied `controller-seed.diff` SHA-256 agree: `61c3b39c6d3ffc77509826d69e70e84f07e2f7d13a61668def39c1e9be2d6f82`.
- Inspected candidate `tests/release-controller.test.cjs` SHA-256, checked initially and after checks: `ae261cc44e020042ebc51fa0517f7b04dea0a3d19a4f7e95fc970698436f7cbe`.
- Common contract `agents/reviewers/README.md`: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/code-review.md`: `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`. Both read before first judgment.
- Referenced fixture `tests/fixtures/delivery.cjs`: `4bf3c43e42c63d5006d209d7c85acaceb86ad62b457e36c29882d71056b66adf`; rights owner `tools/release/rights.cjs`: `07a3801b5b7bec3e19d12005a0011b3591b63db08e1bfd6f2f4b5b9c77d2d8a3`.
- Neutral current issue raw supplied during review: `issue169-current.json`, SHA-256 `a696b69f0001d019645a108307f22a9f5990715e5cf2816957ed9b3d92c1c89f`; issue body/ACs inspected, not conversation comments. Relevant obligations are AC05/11 source-bound independent review and applicable delivery obligations in AC04/07/08/09/10. The narrower STOP/show task boundary controls this review.

## Inspected scope and reasoning

Read the common/role contracts, root AGENTS, README, relevant repository-map entries, CONTRIBUTING independent-role/iteration sections, guides/CODE-STYLE, .github/ACCEPTANCE, issue169 policy and native-check allocation; no nested AGENTS applies. Read the actual complete candidate, actual diff, preimplementation factual packet and relevant fixture/rights/public-artifact/source-worker/format owners. No MEMORY, current peer reports, parent scratch/history, or private conversation was read.

The changed owner keeps the original data-construction body byte-for-byte, puts its one execution in a module `before` hook, and holds the private temporary root until module `after`. Root identity is assigned before construction, giving teardown an address even for partial construction failure. Each call registers its own cleanup before copying. The copied tree includes the fixture's source/public/assets/rights-source Git files; the original shared-clone alternate remains an original fixture property, not a new claim that Git object storage is physically independent.

`fs.cpSync` creates per-case regular files; `structuredClone` creates a separate returned data graph. The four absolute location fields owned by this descriptor are relocated (`temp`, assets `directory`, `source.directory`, `rights.sourceRoot`). Archive and rights identities describe relative inventories, source/tree tokens and bytes; relocation does not rewrite those identities. The new test checks that no descriptor retains the seed path, complete file-byte inventories match, regular-file link counts are one, file/object mutation leaves seed and sibling data unchanged, tampered rights bytes are refused, and a sibling still passes edition/archived-rights validation. Inventory walks reject symlinks/non-files.

All 14 original call sites were read in full:

| Candidate line | Existing scenario | Dependence assessment |
| --- | --- | --- |
| 152 | Local Pages/licensing verification before draft writes | Own copied tree is mutated only after fixture return; actual action subprocesses remain. |
| 456 | Failed-owner-main compensation | Consumes fixed record and fresh API state. |
| 513 | Production metadata and actual 404 bytes | Actual edition verification/admission/size checks and later byte tamper remain. |
| 744 | Raw evidence uploads and immutable acceptance | Mutates copied assets and fresh API state; actual controller calls remain. |
| 800 | Draft rejection modes before writes | Mutates fresh remote fixture state; fixed archive input is suitable. |
| 841 | Exact draft selection and resume | Consumes fixed archive plus fresh API state. |
| 859 | Rights asset tamper/restoration refusal | Mutates copied rights file/remote bytes; validators still execute. |
| 893 | Unprotected Releases and moved tags | Consumes fixed archive plus fresh API state. |
| 918 | Failed/missing live observations | Mutates live observations/API state, not data producers. |
| 936 | Bookkeeping failure and recovery | Mutates API behavior/state after fixture creation. |
| 966 | Successor/rollback identities and labels | Constructs successor record from its own cloned data. |
| 1001 | Compensated remote success refusal | Mutates API callbacks/state after fixture creation. |
| 1105 | Publication/control credential separation | Consumes own fixed archive and independent mock clients. |
| 1247 | Live report reduction | Constructs fresh staging/reports and mutates their clones after fixture creation. |

None requires a fresh release/rights build after its own producer, hook or environment mutation. The pending-owner-policy, explicit Color/current native article/provenance/social inputs remain on their original direct construction paths. No general rights compiler memo, production-owner change, validator replacement, environment monkey patch, removed CLI call, source/security route change or budget change occurs in this diff.

CS01/04/05/06/07/08/10 reviewed: local test owner, explicit descriptor boundary, ordinary CJS/plain objects, bounded module lifetime and teardown, unchanged production/check budgets and existing suite selection. Runtime/content/CSS rules are inapplicable to this one-file test change. Existing source-test discovery/worker routing selects the module and therefore its additional case; no new suite is needed. Maintaining this helper requires keeping its fixed-input precondition: future cases that mutate producers/environment before construction must use their direct constructors or revisit the seed contract.

## Actual checks and evidence

1. Compared actual Git base and candidate text: original cases 30, candidate cases 31; the entire file suffix from the first original case onward is exactly equal, proving all existing case bodies and intervening helpers are retained. Original constructor body is exactly equal. Original 14 helper calls remain; candidate has 16 because the new isolation case makes two calls.
2. `node --test --test-name-pattern='fixed release fixture copies' tests/release-controller.test.cjs`: exit0; tests1/pass1/fail0/cancelled0/skipped0; duration3514.70638ms (case399.617123ms). This independently exercises module setup, actual full-tree copying, relocation, object/file isolation, actual refusal and positive validators, and teardown.
3. Read-only pinned Prettier3.6.2 API comparison with repository settings, on `tests/release-controller.test.cjs` only: identical/pass. `git diff --check -- tests/release-controller.test.cjs`: exit0.
4. Supplied historical baseline summary reports27 compiler calls/48948.67349ms with38195.505195ms of repeated output compilation. Supplied focused raw `copy-case.tap` has tests1/pass1; stderr empty. These are bounded supplied observations, not independently repeated throughput proof.

The parent reserved the full module run; I did not duplicate it. I did not execute native platforms, full source/security/Basic, hosted checks, stable staging or production. No cross-source/cross-platform throughput conclusion follows from the focused case. Current-source full accounting and measured end-to-end improvement remain pending outside this review.

## Findings and assurance limits

Blocking findings: none found in the inspected code and test boundary. Nonblocking changes requested: none. No requirement, oracle or permission is weakened by this conclusion.

Operationally this reviewer received a distinct review assignment and has consumed only the listed permitted inputs. The launch contract requires explicit requested/accepted `fork_turns="none"`; the actual parent launch-tool receipt is outside this reviewer's visible inputs and must establish that request/acceptance separately. I do not infer it from a role name. Provider memory injection, model identity, effort or internal context isolation are unknown and are not attested by this report. No author/peer conversation exposure was observed in the permitted material. Source hashes identify inspected bytes; they do not attest provider internals, comprehension or release acceptance.

Post-result source recheck: candidate test hash is still `ae261cc44e020042ebc51fa0517f7b04dea0a3d19a4f7e95fc970698436f7cbe`. The shared worktree now also reports `M MEMORY.md`; that file was not read. The one-file source judgment above does not review that concurrent change. The parent subsequently supplied locations of full-run and fault-injection raw evidence; these were not consumed before the first judgment and are not incorporated as my executed checks.
