# Exploratory / Interaction QA — first judgment

Date: 2026-11-06. Role/task: `/root/controller_seed_exploratory`; distinct nonauthor reviewer. Owner: issue169 / PR170. **PASS for the bounded CLI/controller charter; no findings.** This is not acceptance of native throughput, stable staging, publication, or the complete suite.

## Inputs and source identity

- Repository: `/workspace/scratch/20e98a342431/author-site`; local HEAD `3c4393dc3ddd2c4a324ac91f4bfef4485cfc2534`. Observed dirty state: only `tests/release-controller.test.cjs` modified, 72 insertions / 2 deletions. This is a dirty prepared candidate, not a clean checkout or a newly verified live GitHub head.
- Common contract: `agents/reviewers/README.md`, SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role prompt: `agents/reviewers/exploratory-interaction-qa.md`, SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Packet: `controller-seed-candidate.json`, SHA256 `4b2f317e8d51d34f7291c5c1e6a1cfa7c1225c3fc721c3b1db18797465a49e6e`.
- Actual inspected test: SHA256 `ae261cc44e020042ebc51fa0517f7b04dea0a3d19a4f7e95fc970698436f7cbe`, rechecked after the action. Actual Git diff inspected; packet diff SHA256 `61c3b39c6d3ffc77509826d69e70e84f07e2f7d13a61668def39c1e9be2d6f82` matched the supplied file.
- Supplemental issue snapshot: `issue169-current.json`, SHA256 `a696b69f0001d019645a108307f22a9f5990715e5cf2816957ed9b3d92c1c89f`; inspected its issue body as authority, not review opinion. The bounded task preserves AC05/AC11 source-bound review obligations and does not complete either whole criterion. The packet's current stop at verified stable staging/no merge/no production governs this review action.
- Read applicable root AGENTS/README and relevant repository-map routes, fixture owner `tests/fixtures/delivery.cjs`, controller publish/restore paths, rights reader, source-worker and `tools/quality/test-profiles.json` registration, and relevant `SITE-CHECK-PROFILES` source/staging rules. No nested AGENTS exists under tests/agents.

## Independently derived charter

Within five minutes and one existing test invocation: use the operator-visible Node CLI to walk a representative fixed-fixture mutation → refusal → corrected retry → immutable historical-restore refusal journey. Determine whether copied fixture state still reaches real rights/archive validators, whether corrected bytes allow progress in the same case, and whether seed/case lifetime ownership makes that journey meaningful. Do not execute the full module or the new isolation case; those are separately assigned. Do not implement, delegate, or write to external services.

The applicable surface is source-test CLI/API interaction with a synthetic GitHub fixture. A browser/UI check is reasoned not applicable: the entire actual diff changes only test setup and a test, with no delivered UI/runtime code. Real GitHub, hosted staging, native device/browser behavior and stable staging were not observed, rather than treated as passing or N/A.

## Executed action and observed result

Environment: Linux container, Node `v24.22.1`, repository cwd above. Command:

```sh
node --test --test-reporter=tap --test-name-pattern '^a changed rights release asset' tests/release-controller.test.cjs
```

Raw files in this report's directory:

| File | SHA256 |
| --- | --- |
| `exploratory-rights-refusal.tap` | `9377f02dbec71d1da8f9d2c9c54e71daccd03b3ad2aaa2b4804e8ae191c8acbf` |
| `exploratory-rights-refusal.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `exploratory-rights-refusal.exit` | `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa` |

Observed: exit0; one test passed, zero failed/cancelled/skipped/todo; total CLI duration3067.025219ms; selected test duration62.456535ms; empty stderr. Filtered-out tests are not counted as executed. Raw execution handle: exec session26709, completion chunk `ee30c3`.

| Journey partition | Expected oracle from actual existing case | Observed |
| --- | --- | --- |
| Append whitespace to local archived rights bytes | `publishArchive` rejects `/archived rights bytes changed/`; synthetic refs remain empty | Executed/pass within selected test |
| Restore exact original local bytes, retry draft publication, then publish activation | Real controller calls complete using corrected copy | Executed/pass within selected test |
| Append whitespace to retained remote rights bytes while updating synthetic transfer size/digest consistently | `restoreArchive` still rejects `/archived rights bytes changed/` against frozen archive identity | Executed/pass within selected test |

These are actual assertions in `tests/release-controller.test.cjs:858–889`, not separately instrumented stage traces. TAP proves the case completed; it does not prove unasserted remote-write properties. In particular, the first refusal explicitly checks no refs, not every possible synthetic call. Controller source confirms `archive.verifyRights` precedes tag creation; listing may occur first.

## Source diagnosis and lifetime boundary

At test lines24–31, the original constructor prepares a private seed in a top-level before hook, and a top-level after hook removes it. Lines77–88 allocate a new case-owned temporary directory, recursively copy the whole seed, deep-clone the data graph and relocate the four directory-bearing fields. Each case directory is removed by that case's `t.after` (`delivery.cjs:63–66`). The chosen action therefore mutates a case copy while its source seed remains alive for the file. The seed is fixed for this worker's module lifetime; this is not a persistent cross-run cache or a claim of freshness after arbitrary in-process source replacement.

The fixture's Git source is included in the copied tree. Its existing `git clone --shared` behavior uses repository object storage; copying that tree does not establish an independent durable Git object-store lifetime after the source checkout disappears. The source checkout remains available during this bounded execution, which matches the inspected test-worker boundary. No stronger portability or provider isolation claim is made.

Real validator locations examined: `controller.cjs:477` calls archive rights verification before publication writes; `controller.cjs:377–450` authenticates immutable restore inventory/source and checks rights against the record's frozen report SHA256. The remote-tamper partition changes the fixture's transfer digest too, so its rejection checks the frozen archived identity rather than merely a transport-size mismatch. `rights.cjs:528–532` routes publication reading to the frozen reader; the new isolation test calls this existing reader rather than a replacement validator.

Independent text comparison against HEAD found30 original top-level cases and31 candidate cases. The entire suffix starting at the first original case is byte-identical, so all30 original case bodies remain unchanged. The actual diff retains the original construction statements in the extracted constructor. New isolation assertions were source-inspected only; their separate execution was not duplicated.

## Supplied raw evidence and disposition

Inspected supplied `controller-before.tap` (SHA256 `b7af7ac6c26b559f515ed53f8b8ec560a7063336650f76a404548d461398e18b`):30/30 pass, total69692.28964ms. Inspected compile timing rows/summary (`compile-times-before.jsonl` SHA256 `67a862964ce04b387e94e57881a974ed5d3c685ccc20467c2374919ab2a6fc68`): repeated digest/cost observations support the stated investigation target but are not my independently executed baseline. Supplied `copy-case.tap` SHA256 `b9fa6ef92c4aa51fc5bd7efdd52c2d674a2de7055b309e269ef1bec712dd49ed` reports one pass; I did not rerun it and do not claim it as my execution. None proves full native improvement or stable staging.

No new regression proposed: the existing changed-rights case already covers the selected mutation/recovery partitions. Preserve it in the existing permanent `release-controller.test.cjs` suite. Registry lines1794–1801 map it to `pr-targeted`, `staging`, `production`, with surviving production route `node tools/quality/source-tests.cjs --profile production`. `SITE-CHECK-PROFILES` retains serial cases per isolated file worker, mandatory source accounting and unchanged300-second limits. The orchestrator owns full-module/current-source/native/hosted validation and subsequent stable-staging decision; this review supplies only this bounded source-test interaction result.

## Independence and assurance limits

This first judgment was written before reconciliation. I read no peer result, parent scratch history, private conversation or MEMORY. The parent supplied task sources and one neutral owner snapshot. No source/test implementation or external write occurred; only assigned raw receipts and this artifact were written. Requested/accepted clean-context launch parameters must be established from the orchestrator's tool receipt; they cannot be independently proven by this reviewer. Provider model/context internals and possible platform memory injection are unknown. This is an operational read boundary, not OS isolation or provider attestation.
