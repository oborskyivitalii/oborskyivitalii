'use strict';
const fs=require('node:fs'),rights=require('/workspace/scratch/20e98a342431/author-site/tools/release/rights.cjs');
const original=rights.compile;
rights.compile=function(...args){const start=performance.now();let result;try{result=original.apply(this,args);return result;}finally{if(args[2]?.sourceRoot?.endsWith('-rights-source'))fs.appendFileSync('/workspace/scratch/20e98a342431/fixture-baseline-fix/compile-times-before.jsonl',JSON.stringify({pid:process.pid,sourceRoot:args[2]?.sourceRoot,elapsedMs:performance.now()-start,digest:result?.inventoryDigest})+'\n');}};
