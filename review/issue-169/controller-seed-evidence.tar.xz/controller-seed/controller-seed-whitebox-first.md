# White-box QA — first independent result

Date: 2026-11-06. Reviewer task: `/root/controller_seed_whitebox`; distinct nonauthor White-box QA, first phase. Owner issue169 / PR170. No source edits, external writes, delegated work or peer-report reads. Reviewer read only scoped authoritative source, supplied neutral packets and explicitly supplied raw execution evidence. A filename inventory incidentally listed a requirements-preflight filename; its content was not read. Parent conversation/MEMORY were not inspected.

## Verdict

PASS for this bounded fixed-fixture isolation change: no blocking source defect found. The new test passes on the candidate and the supplied child-only shallow-copy fault fails at the intended nested-object equality assertion. All 30 original cases and their shared remainder are byte-identical; complete current raw TAP contains all 30 names plus the new case, 31/31 passed. This is local source/fixture assurance, not native, stable staging, security, release or whole-issue acceptance. Those gates remain pending.

## Identity and inspected scope

- Git HEAD/base `3c4393dc3ddd2c4a324ac91f4bfef4485cfc2534`; work branch/origin tracking ref observed at that tip. Dirty preparation: only `tests/release-controller.test.cjs` modified, 72 additions / 2 deletions. No claim of clean checkout or refreshed remote GitHub state by this reviewer.
- Candidate SHA256 `ae261cc44e020042ebc51fa0517f7b04dea0a3d19a4f7e95fc970698436f7cbe`, rechecked after execution; diff SHA256 `61c3b39c6d3ffc77509826d69e70e84f07e2f7d13a61668def39c1e9be2d6f82`.
- Neutral packet `controller-seed-candidate.json` SHA256 `4b2f317e8d51d34f7291c5c1e6a1cfa7c1225c3fc721c3b1db18797465a49e6e`; referenced preflight packet read as proposed design, not accepted verdict. Supplied live issue snapshot SHA256 `a696b69f0001d019645a108307f22a9f5990715e5cf2816957ed9b3d92c1c89f` read; relevant AC05 and AC11 require source-bound independent review while delivery remains separate.
- Common reviewer contract SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; White-box prompt SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Read root README/AGENTS/CONTRIBUTING, repository-map owners, applicable acceptance mapping and QA test-allocation profile. No nested AGENTS found in the repository inventory. Inspected full changed constructor/hooks, all 14 original fixed-fixture callers, independent pending-policy/Color/social/staged-production constructors and retained CLI/provider-negative scenarios. Inspected delivery helper, artifact byte inventory, edition builder/verifier, rights reader/compiler paths and frozen-reader delegation.
- `tests/fixtures/delivery.cjs` SHA256 `4bf3c43e42c63d5006d209d7c85acaceb86ad62b457e36c29882d71056b66adf`; `tools/release/rights.cjs` SHA256 `07a3801b5b7bec3e19d12005a0011b3591b63db08e1bfd6f2f4b5b9c77d2d8a3`.

Actual requested/accepted spawn parameters must be recorded by the orchestrator; this reviewer cannot independently observe its spawn call or provider context internals. Provider model/history-injection internals are unknown. This is an operational reading boundary, not a security sandbox attestation.

## Structural risk / scenario / oracle / check

| Risk / requirement | Structural fault and scenario | Independent oracle and check | Result / boundary |
| --- | --- | --- | --- |
| AC05; preserve complete fixture input | Missing files, changed bytes or shared writable files during copying | New case inventories every regular file recursively, including dotfiles and Git metadata, compares path/hash arrays and requires nlink=1; artifact inventory rejects symlinks/nonfiles | Own focused case passes; no metadata/empty-directory/mode coverage claimed |
| AC05; per-case paths | Copy metadata still points to seed | Four actual path fields relocate relative to fresh temp root; JSON string contains no seed root; validators consume second copy | Own case passes; constructor currently returns only these four absolute path locations |
| AC05; per-case graph | Shallow copy aliases proof/rights/source record | Mutate first copy; second and seed must retain original nested values | Own case passes; supplied shallow-copy fault fails at line135 as intended |
| AC05; rights refusal preserved | Corrupt first archived rights JSON while intact neighbor should remain accepted | Actual rights.readPublication must throw matching archived-report-change refusal; second copy must pass actual rights/edition verification | Own case passes; this is frozen archived verification, not fresh source/checkout/security acceptance |
| Preserve original assertions/rights/CLI/source checks | Reuse suppresses producer/environment-specific scenario or changes existing body | All 30 original bodies and remainder byte-identical; 14 callers take fixed zero-parameter constructor; no caller changes real constructor hooks/environment before its fixture; pending-policy, Color/social and staged derivation still build through their separate original constructors | Source inspection plus supplied complete 31/31 raw TAP; no branch coverage percentage inferred |
| Partial setup/copy cleanup | Prepare or cp throws before fixture return | Seed root assigned before prepare; module after registered before execution; case temporary registers cleanup before cp | Structurally retained cleanup path; setup-failure injection not executed in this allocation |
| Existing staging throughput budget | Reduction removes repetitions while retaining meaningful validators | Fixed prepare body remains unchanged; one seed plus per-case trees; subsequent controller/edition/rights/CLI calls remain actual calls | Supplied local raw shows shorter module and 14 compile observations vs27; native four-worker/deadline behavior not observed |

The preparation boundary is fixed local test data, not memoized validation: no shared helper/product validator was changed and no cross-module/process invalidation equivalence is asserted. All cases using the seed pass the same original constructor inputs; later mutations affect copies. The copied `.git` metadata retains the original helper's `git clone --shared` object-database dependency; copying metadata does not establish a private Git object database. This preserves the original dependency rather than proving filesystem isolation from the repository. Rights source/custom/producer variants remain outside this fixed constructor.

## Executed and reused evidence

Own executed command (one run only):

`node --test --test-reporter=tap --test-name-pattern '^fixed release fixture copies' tests/release-controller.test.cjs`

Process exit0; complete TAP: tests1, pass1, fail0, cancelled0, skipped0, todo0; case359.227576ms; module3194.969031ms. Raw `controller-seed-whitebox-isolation.tap`, `.stderr` (empty), `.exit` (0). TAP SHA256 `b689da3a7e238198094260762679d830d2dd534d69e3fd4d4b158efe92c08f35`.

Read supplied raw rather than rerunning allocated parent campaigns:

- `controller-after.tap` SHA256 `11e3db7ac7a44a98107f2f92fed481093c5e3929842145db84cca54708fe1f79`: complete tests31/pass31/fail0/cancelled0/skipped0/todo0, 39480.343895ms; stderr empty. Independently parsed every passing name: all30 original names present plus new case. Baseline raw contains all30 original names and module69692.28964ms. Local difference is ~30.212s /43.35%; this single observation is not a native timing guarantee.
- `compile-times-after.jsonl`: 14 raw compile rows; one fixed seed, separate pending+confirmed rights, Color/staging and staged-production rows remain. The supplied summary reports baseline27 and combined append-stream split at the driver phase boundary; that observer attribution is not independently instrumented by this reviewer.
- `shallow-copy-fault.cjs` SHA256 `71271c1d5980e1054ad927222bc38c371ae099cc53cb4e3b640fdb756a365fb5`: child module loader replaces only result structuredClone with shallow nested copies, checks target exists, leaves disk source unchanged. `shallow-copy-fault.tap` SHA256 `6e4140e1372008c6e6ecd36e0d63fe3ff0027d3ff961569ee7b1c6e107c65fe3` has test1/fail1/pass0, no skips/cancellation and ERR_ASSERTION at candidate135:10: second proof rights.pass became false instead of true. Fault receipt records exit1 and unchanged candidate hash. This demonstrates detection of nested aliasing, not all conceivable fixture faults.

## Allocation, findings and remaining observations

No blocking findings. Risks examined: tree-byte omission, stale paths, regular-file linkage, mutable nested aliases, archived-rights corruption, lost original scenarios/negative assertions, setup/copy cleanup, constructor fixedness and remaining source validators.

Reuse existing permanent `tests/release-controller.test.cjs`, registered in `tools/quality/test-profiles.json` for pr-targeted/staging/production, owned by SITE-CHECK-PROFILES and surviving route `node tools/quality/source-tests.cjs --profile production`. No new suite, profile removal or budget change is needed. Full source-test profile/native workflow selection/execution is reserved to the orchestrator; reviewer did not run it.

Remaining gaps: no measured branch coverage; no setup-failure, copy-failure or hardlink fault injection; no independent live provider, hosted/native/security scan or stable staging observation; no merge/production authorization or action. Required exact-candidate source/style/CI/other-role and stable-stage gates remain outside this bounded result. Stop/show after stable staging remains the accepted operational scope.
