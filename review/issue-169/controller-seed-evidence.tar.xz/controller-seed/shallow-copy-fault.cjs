'use strict';
const fs=require('node:fs'),Module=require('node:module');
const original=Module._extensions['.js'];
Module._extensions['.js']=function(module,file){if(file==='/workspace/scratch/20e98a342431/author-site/tests/release-controller.test.cjs'){const body=fs.readFileSync(file,'utf8');const needle='const result = structuredClone(releaseSeed);';if(!body.includes(needle))throw Error('fault target absent');return module._compile(body.replace(needle,'const result = {...releaseSeed, source:{...releaseSeed.source}, rights:{...releaseSeed.rights}};'),file);}return original(module,file);};
