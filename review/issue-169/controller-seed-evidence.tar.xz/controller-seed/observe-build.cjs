'use strict';
const fs=require('node:fs'),builder=require('/workspace/scratch/20e98a342431/author-site/tools/site/build.cjs');
const original=builder.build;
builder.build=function(...args){const start=performance.now();try{return original.apply(this,args);}finally{fs.appendFileSync('/workspace/scratch/20e98a342431/fixture-baseline-fix/build-times-before.jsonl',JSON.stringify({pid:process.pid,root:args[0]?.root,elapsedMs:performance.now()-start})+'\n');}};
