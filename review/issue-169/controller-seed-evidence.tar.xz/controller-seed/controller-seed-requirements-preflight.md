# Requirements & Acceptance — fixed controller input seed

Verdict: **the proposed narrow fixed-data preparation is acceptable to implement, subject to the copy/isolation and retained-oracle obligations below.** All 14 current `releaseFixture(t)` callers were inspected. None requires constructor re-execution after its own producer, Git, filesystem, environment or module-hook mutation; their behavior under test begins with the already prepared fixed archive input. No caller exclusion is needed for the inspected source. This verdict does not accept an implementation or establish native deadline margin.

## Identity and boundary

Continuation of `/root/fix_requirements`, not a fresh-context execution. Prior findings against generic rights-result memoization and default cloning remain preserved; they are not silently waived. This proposal has a different boundary: produce one fixed input using the real unchanged constructor in a module setup hook, then copy that input privately for the known controller cases. It does not claim that later changed Git/hook/environment state is equivalent for a fresh source compilation.

Packet SHA-256 independently verified: `8eb7ef98c61c235af1f74279724893214525cee0965eb4526eac88302018db0f`. Repository clean at `3c4393dc3ddd2c4a324ac91f4bfef4485cfc2534`, tree `439a8e92b41988cbda6d9a870a4c553beb445e3d`. All five supplied source/prompt hashes matched actual bytes:

- Controller test `acdc7f22dc63c75ff17b1dc72ccae386c3bbd57e4889d5b2d4d3e28afede40f1`.
- Shared delivery helper `4bf3c43e42c63d5006d209d7c85acaceb86ad62b457e36c29882d71056b66adf`.
- Product controller `f323e7fed6ced8a8499842fec7ab72183b9e58cba271ee1c3cfedd3bd9badbff`.
- Common prompt `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; requirements prompt `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`.

Inspected original constructor, all 14 calling test bodies, other custom constructors and mutation sites in the file, controller admission/archive helpers and deterministic package construction. No code/tests/campaign/external write/delegation performed. Only this assigned report is written. No peer report bodies, parent scratch notes or private chat history read. Provider context/memory isolation remains unobserved, and this continuation supplies no new launch assurance.

## Actual caller assessment

`releaseFixture` has only the test-lifetime context parameter; it accepts no variable source, policy, producer or candidate. It always constructs the same source commit placeholder, production edition, confirmed rights report, seven fixed evidence files, deterministic package and fixed archive metadata. Actual product edition/rights/archive preparation still executes once during setup and must fail the module if invalid. Package owner uses fixed gzip timestamp and deterministic tar entries, supporting byte parity for the relevant packaged output.

| Existing caller location | Behavior under test after fixed input is prepared | Fresh constructor execution required? |
| --- | --- | --- |
| `:82` draft archive action order | Actual compose/verification/publish-refusal child CLIs, package/rights/source/tag mutations and provider-not-reached assertion | No; these CLIs and later mutations must still execute |
| `:386` first-release compensation | Deployment/branch/label source identity and invalid recovery refusal | No; mutations are to the case's fake API after preparation |
| `:443` production edition/Pages | Actual edition verification, already-applied refusal, Pages build/404 parity, admission and altered robots rejection | No; subsequent validators/build remain real |
| `:674` archive uploads/immutability | Actual publish/activation/restore, retained byte/digest parity and tampered archive refusal | No |
| `:730` draft discovery refusals | Orphan/moved source/asset/extra/ambiguous/permission rejection before remote writes | No |
| `:771` exact draft discovery/resume | Idempotent release selection and no duplicate writes | No |
| `:789` changed rights release asset | Local rights-byte mutation and remote restored-rights mutation rejected by real controller paths | No; current mutation/assertions remain essential |
| `:823` unprotected releases/moved tags | Actual immutability and source-tag refusals using independent API | No |
| `:848` failed/missing live observation | Rejection for each live-proof flag; accepted transition only on full proof | No |
| `:866` failed bookkeeping/recovery | Label-write failure, Pages recovery gate and unrelated branch refusal | No |
| `:896` successor/rollback | Immutable transition identities and actual live PR label changes | No |
| `:931` compensated remote success | Response-loss recovery and previously-accepted-state decisions | No |
| `:1035` credential role split | API-client method failure hooks after fixture creation; actual publication/transition/recovery calls | No; hooks affect controller operations, not fixture producers |
| `:1177` live report reduction | Actual Pages composition and report mutations, optional-diagnostic scope and retained staging refusal | No |

The file has no existing producer monkeypatch/module-cache override or module before hook requiring fresh fixture creation for those callers. Its environment overrides are scoped to subsequent child commands, not mutations before `releaseFixture`. The API overrides in compensation/credential tests are created after the fixture and operate on per-case mock clients. The generic rights-policy test at `:478`, Color/social metadata constructions, current staged-source authentication constructions and their actual validation paths do not use this fixed constructor and must remain unchanged. The independent native-current-article CLI test lives in the rights suite and is unaffected.

## Required implementation/validation obligations

| Intent / owner linkage | Observable acceptance condition | Gate |
| --- | --- | --- |
| Preserve fixed construction | Keep original constructor operations/assertions and real edition/rights/package/archive preparation; run it once before case hooks. A constructor exception fails setup, never supplies a partial seed | Source review and actual suite setup |
| Fixed data, bounded lifetime | One private seed owned by this test module/process; no public generic memo API, input-key framework or cross-run/cross-module/disk persistence | Diff scope restricted to controller test |
| Independent complete files | Copy the complete seed temporary tree, including production/public/artifact/rights source clone, packaged archive, evidence and sidecars, into each new test directory. No hardlink/symlink alias to seed. Source and public roots must be independent | Complete sorted relative-path/byte inventory parity of seed and copies; verify relevant regular-file/link properties |
| Independent objects and valid paths | Clone data independently per caller, preserving the data graph where aliases matter. Rebind only explicit fixture path fields (`temp`, assets directory, source directory, rights sourceRoot) to the case tree. Never leave a case path pointing to seed or return the seed object | Path-boundary and deep mutation-isolation proof; inspect all path fields rather than broad string replacement |
| Clone mutations remain real | A corrupted clone's rights/public/package/metadata must reach and fail the original actual validator. A second clone and the seed remain unchanged; their real validators still pass. Mutate returned nested report/proof objects as well as a file | Meaningful isolation/refusal regression in the existing controller test module |
| Preserve all original scenarios | All 30 existing tests, original mutations, refusal assertions, actual CLI/controller/Pages calls and other fixture construction routes remain. Only 14 identical setup repetitions are replaced with copies; do not claim 14 fresh compiler/Git runs afterward | Full diff review and completed original module accounting |
| Preserve actual producer/Git failures in setup | The seed is generated from the current real inputs/toolchain/Git and is not checked-in old data. Setup failure propagates; no success result is manufactured. Later cases operate on fixed input data and do not request a new provenance compilation | Actual setup plus source review; no generic dependency-invalidation guarantee claimed |
| Correct cleanup scope | Register seed cleanup at module after-hook lifetime, not an after-hook attached to the before-hook context that could destroy it before cases. Register cleanup before expensive setup so partial setup cannot leak. Per-case cleanup remains independent | Hook/lifetime review and completed execution; seed survives cases then is removed |
| Performance evidence | Compare same complete controller module against retained 30/30, 69.692-second baseline and actual compile-call observations. Include copy/setup overhead and count all test executions; no fixed speedup promise | Bounded exact-source local measurement before native campaign |
| AC05/AC11 and delivery | Apply appropriate CS01/CS05/CS07/CS08/CS09, separate affected Code/QA review, current-source Basic/style/RI/owner selection, actual native source/security/staging/hosted verification at original budgets | Pending; verified stable alias/source/article/PDF then STOP/show |

Complete clone-byte parity is an oracle for faithful copies of the prepared seed. When comparing a separate fresh constructor to the seed, deterministic source/public/archive/report values should match after explicit path normalization; Git reflog timestamps and temporary-directory metadata are incidental and must not be falsely claimed byte-identical. No incidental exception may hide public/source/report/package content differences. This is a copy fidelity check, not a cache key or permission to disregard arbitrary input changes.

The prior generic memo blockers do not require revalidating Git history or every mutable producer on each copied test input here: the inspected callers do not request new source compilation after those inputs change. Their original validators still run against each independently mutated fixture. This acceptance boundary would no longer apply if a caller adds a producer/Git/environment precondition before obtaining its fixture; that caller must use the original constructor or receive a new requirements assessment.

## Findings and remaining gates

No blocking requirement defect remains for this narrower preimplementation design. Examined risks: suppressing a fresh-constructor oracle, hidden producer/environment mutation, incomplete source/Git/public tree copies, retained absolute seed paths, shared nested objects, cross-case corruption, lost altered-rights refusal, premature seed cleanup, setup failure leakage and overclaiming reduced setup as native success. The implementation/QA obligations above are not yet observed passes.

Keep the previous native timeout and all diagnostics. After preparation, obtain source-bound final requirements and distinct Code/QA results on actual code, demonstrate unchanged scenarios plus copy/isolation/refusal, and measure actual controller-module savings. Proceed through unchanged exact-source/native/security/staging gates only on supported evidence. No source/security/stable/whole-AC acceptance is supplied by this preflight; no merge or production action is authorized.
