# Requirements & Acceptance preflight — issue169 / PR170

## Verdict

**PASS for the requirements preflight needed to prepare main integration.** No blocking ambiguity in the authorized integration scope was found. This is not acceptance of an integrated candidate, CI, stable staging, article/PDF presentation, publication or whole AC completion. No implementation, tests, external service writes or delegation were performed.

Role/execution: distinct nonauthor Requirements & Acceptance Reviewer, task `/root/requirements_preflight`, first preflight judgment. The supplied launch states explicit `fork_turns="none"`; actual accepted launch receipt belongs to the orchestrator. Provider context/model internals are unknown. No peer outputs, parent scratch notes or unrelated memory were inspected. A bounded Git path comparison included MEMORY.md bytes only to classify equality; its contents were not read or used as authority.

## Inspected identity and scope

- Packet SHA256: `4946894f95d29cf8de892f6136e2191f609044c1480a7485e9a6ad1bb7c1c7d7`; independently reproduced. All ten declared dependency hashes match immutable publication-head bytes or supplied scope/dated-issue files.
- Base: `8cf15883125892710633b17133d9ee0fc4b23b92`, tree `1f8e758a6c4565b12b8112477e77b9637f4938a9`.
- Publication head: `558682775b9798a961f91a86673000a0b13e34d9`, tree `206cd6a7c002de24267b567c51e029167d1b2744`.
- Integrated controller main: `312fbe4347eda332aa8ade885b07c98beadd6da5`, tree `ebe45c3549ae4af19d373820ef195d5d8ea03dbd`; immutable parents are the supplied base and accepted controller head `d06640cb53ca09f47b132c1a0bbea0b1b1cc22c9`.
- `controller.diff` SHA256 independently recorded: `e9123e751eb70c691ca2e3caa3cc39484d6089fcdd3ac7329903a17f5308f930`. Inspected its relevant policy, compatibility, Research/Writing carrier, archive, scanner-policy and profile-selection hunks; large fixture/checksum data were bounded structural inspection, not independent provenance/security certification.
- Read supplied scope, dated owner issue, immutable AGENTS, CONTRIBUTING, common launch contract, requirements role prompt, issue169 policy, staging contract, relevant check-profile/style sections and publication-head `review/issue-169/native-check-allocation.md`. No candidate integration exists in this packet. No live GitHub state or hosted bytes were independently observed.

The dated scope resolves earlier publication authorization: this continuation ends after verified stable staging and article/PDF inspection, then STOP/show. PR170 merge and production activation are excluded. Original AC01–AC11 stay intact; historical AC06 remains the only whole accepted checkbox. R10, hero plus four explanatory figures, five-page PDF, site-first distribution and later paired reciprocal links remain required. Earlier three/six-visual or unresolved-link language is historical and explicitly superseded, not a reason to regress the current edition.

## Findings and required treatment

No new blocking requirement defect. The following integration risks require evidence before final acceptance:

1. **Medium, integration preservation gate — divergent authoritative controls and ledgers.** Immutable base-to-head comparisons show divergence on `.github/acceptance/issue-169.json`, `tools/quality/bandit-policy.json`, `tools/quality/secrets-reviewed-checksums.json`, `tools/quality/test-profiles.json`, `tools/check_site_seo.cjs` and several affected test modules. A blanket choice of either side can discard publication-specific checks/entries or controller corrections. AC05/11 and CS01/04/08/10 require semantic reconciliation, preservation of all original ledger rows and refusal scenarios, current-source scanner proof and complete selected-test accounting. Treat this as an integration gate, not an existing observed defect. Generated output/RI/output locks also diverge and must follow resolved authored owners, not manual selection of old rendered bytes.
2. **Medium, wrong-source acceptance risk — accepted controller is not staged publication evidence.** `controller.diff` adds exact runtime families, synthetic compatibility fixtures and native archive verification. Fixture metadata explicitly distinguishes private dirty production derivations and previously failed unknown-runtime staging builds from release eligibility. SITE-STAGING requires current head/base/producer/run/attempt and stable promotion identity. AC05/09/10/11 need fresh PR170 source admission and full current staging; the PR173 admission or older R9 browser records cannot satisfy them. Reuse only demonstrably unchanged bounded observations with their original attribution.
3. **Low, traceability precision — maintained allocation contains explicitly historical R9/final-URL wording.** `native-check-allocation.md` opening rows reference R9 and final URLs after release; its later R10 and 6-November distribution amendments correctly supersede them. Final reconciliation evidence should cite the current amendments explicitly so reviewers do not accidentally demand platform posting before staging or replace planned links with invented live evidence. No new owner decision or AC rewrite is needed.

## Intent / AC → allocation → present observation

| Intent / AC | Check or decision required on integrated PR170 | Observed result and boundary |
| --- | --- | --- |
| Preserve R10 argument, accepted scope and author apparatus; AC01/02/03/07/08 | Before/after identities for manuscript, semantic edition, PDF and five visual sources; native publisher/provenance validation; final editorial/visual review | Scope and current amendment inspected; preserved bytes and rendered candidate not yet observed |
| Repository/control hygiene; AC05/11, CS01/04/05/07/08/09/10 | Four completed independent final roles plus affected corrections; current Basic, pinned format/lint/security/advisories, style guard; RI build/verify, RI regression and RI/CI coupling; clean exact-head owning policy | Requirements preflight completed only. Hash/parent inspection is not execution of these checks |
| R10 PDF/platform parity and planned distribution; AC04/09 | Native publisher validation, article/material/budget/history/profile cases selected by registry; PDF byte/page/link parity and all five pages inspected; complete eight platform exports retain planned ordinary article/material links | Allocation supports the dated site-first sequence; no local/native/hosted PDF or platform view inspected here |
| Writing discovery, reader recovery and related destinations; AC09/10 | Retain current publication/tag/index owners; selected site-engine/executive/content/reader/material suites and exact controller compatibility cases; actual desktop/mobile normal/no-JS reader, nonself related destinations, PDF download | Writing carrier bounds and negative cases exist in controller diff; no runtime pass claimed |
| Stable staging and STOP; AC05/09/10/11 | Fresh raw-head Basic/RI/owning admission; owner full staging via trusted controller; complete single-attempt selected jobs/scanners/browser/performance evidence; exact stable alias/immutable candidate article/PDF identity and actual interactions | All pending for the integrated candidate. Optional isolated staging-regression evidence cannot replace stable promotion |
| Retain publication boundaries; AC04/06/09/11 | Keep historical Draft milestone; PR170 stays unmerged, production inactive; show actual stable URLs/results and remaining gates | Supplied scope explicitly authorizes integration/staging, excludes merge/production; live state not reverified by this reviewer |

## Next gate and limits

Proceed with the bounded authored-owner reconciliation; preserve R10 and the complete controller fixes. Then bind the completed candidate/diff and all relevant source hashes to four final role executions and current selected checks before stable-staging acceptance. Exact selection belongs to the maintained registry and trusted controller, not a historical fixed module count. Any failure retains its original raw evidence and requires diagnosis before a fresh attempt.

No additional author permission is required for the already authorized reversible integration or staging. New semantics, relaxed scanners/budgets or a changed acceptance oracle would require renewed requirements review. PR170 merge, production activation, whole-issue completion, platform publication and live reciprocal-link equivalence remain outside this preflight and cannot be inferred from its verdict.
