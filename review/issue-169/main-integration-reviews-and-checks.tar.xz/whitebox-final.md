# White-box QA — final integration first judgment

Verdict: **No blocking source/test defect found in the bounded inspected integration.** This result supports proceeding to the pending complete current-source/native/hosted gates; it does not establish delivery, editorial/PDF visual acceptance, production eligibility, or whole-issue acceptance.

## Identity and boundary

- Role: distinct nonauthor White-box QA; first judgment for this final integration candidate. Task `/root/whitebox_integration`.
- Requested launch context in assignment: explicit `fork_turns="none"`; no model override supplied. Actual tool receipt is orchestrator-owned. Provider model/history-injection internals are unknown; operational read restriction is not provider attestation.
- Candidate inspected: `ed18fcf1c59c31521f58816117c08cf777872cdc`, tree `c766f20b887c1de7b61e80d0dd30fbe2aa7e1231`. HEAD matched and working tree was clean during checks.
- Prior publication `558682775b9798a961f91a86673000a0b13e34d9`; accepted integrated main `312fbe4347eda332aa8ade885b07c98beadd6da5`.
- Packet `final-packet.json` SHA256 `8584ff100cee29bb3f93342fe9882f3e09bf80f60f192505518d8ab95afb76e7` independently matched. All 24 manifest entries and all 8 dependency entries matched their supplied byte hashes.
- Common prompt `agents/reviewers/README.md` SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/white-box-qa.md` SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Read supplied intent/current issue, acceptance policy, root AGENTS, README, relevant CONTRIBUTING/REPOSITORY-MAP/profile routing, actual diff and changed tests/SEO reconciliation owners, fallback and frozen edition verifier. No nested AGENTS files were present in the repository inventory. No peer outputs, parent notes, private history or unrelated memory were read. Candidate historical claims were treated as review subjects. No implementation, accepted test edits, external writes or delegation.

Accepted intent is integration and verified stable staging of R10 followed by STOP/show; PR170 merge/production/platform posting remain excluded. Focus is AC05/09/10/11, with existing original gates retained.

## Risk → structural check matrix

| Risk / AC | Structural failure | Scenario and independent oracle | Existing check / disposition | Observation |
| --- | --- | --- | --- | --- |
| AC05 provenance | A wildcard successor, forged ancestor or missing producer admits drift | Exact Git ancestor bytes, historical issue159 record and current producer must agree; reject missing/extra lineage, changed hashes and current source bytes | `executive.test.cjs`: Writing carrier proof; Research carrier reconstruction; permanent pr-targeted/staging/production | 2 selected cases pass, including their mutation refusals |
| AC05/09 reader dependency closure | Wrong room/depth/fragment or altered resource silently resolves | Only canonical passive Writing resource, exact declared one-resource closure, root and ../../ depth are accepted; unsafe script/event/external-use vocabulary refused | `site-engine.test.cjs`: Writing resources; permanent pr-targeted/staging/production | 1 selected case passes |
| AC05/09 transfer | Resource omitted, counted incorrectly or bound to wrong route | Full actual gzip contribution and exact bytes/digest must be present; omission/subtraction/wrong-route corruptions must reject | Same Writing resources case; existing route-size validator | Five accounting/binding mutations reject; existing-resource branch executes on this candidate |
| AC05/09 production archive | Manifest refresh hides missing article sitemap/indexing/canonical/social fields | After recomputing file manifests, semantic inventory and publication metadata must still reject six mutations | `reader-controller.test.cjs`: frozen production archives; permanent pr-targeted/staging/production | 1 selected case passes; fixture restored and reverified between mutations |
| AC05 source binding | SEO imports succeed only accidentally or stale Home HTML passes | Fresh cloned CLI must accept current authored Home and reject restored stale body | `content-rendering.test.cjs`: fresh SEO CLI; mandatory content + permanent source profiles | 1 selected case passes |
| AC05 historical retention | Compression replaces rather than preserves history | Decode each new archive and compare directly to immutable prior Git blob bytes, separately identify archive bytes | Bounded Python/Git manual case; historical record under issue169 | Both exact byte comparisons pass; locators explicitly deny active rendition/visual acceptance |
| AC05/09/10 source preservation | Integration changes accepted manuscript/assets/runtime or semantic generated output | Compare candidate tree paths to prior publication, not a narrative assertion | Bounded `git diff --name-only ... -- site docs tools/site tools/release` | Empty: these complete subtrees are unchanged |
| AC05/11 evidence reuse | Old source/line proof is presented as current scanner admission | Recompute each newly appended public checksum against actual current source and Git ancestor; retain historical qualification | Manual five-row review; current security/native campaigns remain orchestrator-owned | Values independently authenticate; qualification below |

This is structural test design and bounded execution, not a branch-coverage measurement. No concurrency/cancellation/UI implementation changes occur in the integration diff; real native/hosted/browser failure paths remain unobserved here, not inapplicable.

## Source and provenance results

`verifyResearchCarrier` now authenticates one exact reader successor and separately authenticates the existing four-input Writing successor. The common fallback after hash must agree before current bytes are accepted. Historical before bytes are checked via Git rather than inferred from the new record. The original issue159 amendment remains byte-identical to prior publication. Existing wrong geometry/resource/current-source refusals remain and execute. No fallback/runtime implementation changed in this integration.

All 3161 prior checksum ledger rows, order and reasons are an exact prefix of the 3166 candidate rows. The five appended rows resolve to three public values: immutable Git ancestor `8cf1588…`, predecessor fallback SHA256 `66822a96…`, and current fallback SHA256 `0060c45f…`. Recomputed predecessor/current fallback bytes match their claimed SHA256; every appended scanner value hash equals SHA1 of the exact public value.

Evidence qualification (nonblocking after direct recomputation here): retained `trusted-controller-security-proof.json.gz` has historical source/line bindings for the two SEO literals; those bindings are not current after integration restructuring. Its three JSON-record bindings remain exact. Current SEO source SHA256 is `ddbc2df7c08b126a7905cba82bc06efc7692e61899c7e174d559650dba6def3b`; actual predecessor literal is line329, line SHA256 excluding newline `cc86a26915ba0cf2cd025a7ed6b0cecc070150f2b9147f023ea0af9b0ac43825`; actual successor literal is line333, line SHA256 `a9fa0125bc4f68ab537cd6fcfc4e3ca06a0e725e19d38232343a95c83585cffe`. Preserve historical proof as historical; bind any current security acceptance to actual fresh scan/current receipt. This review supplies only the bounded exact-value recomputation, not a security-suite pass.

Archive identity independently observed:

| Retained historical file | Decoded bytes | Decoded SHA256 | Comparison |
| --- | ---: | --- | --- |
| `review/site-v1-20261002-v6-index.html.gz` | 1426481 | `10a9fdbea57b561825b2200e86eef2cf7db339969d716c17d44469c959a22ce3` | Exact prior Git bytes |
| `review/site-visual-proposal-20261002.html.gz` | 1984277 | `1edeec65628118060cc2e0184d54a7b64752c3aa2c2cbbcb0941ae6315690a54` | Exact prior Git bytes |

Both original-path locators contain matching relative gzip download links and state that decompression is required. They do not claim the locator is the old rendition. This preserves source bytes, while direct old-path interactive viewing now requires the explicit download/decompression step. Active public output is unchanged. I did not treat preserved historical captures as new visual acceptance.

## Executed commands and literal results

All four selected Node invocations used `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node`, prefixed with `timeout 20s`, from the candidate root. No timeout or signal occurred. Literal outputs below are retained in this sole assigned artifact; commands were not a broad/full-suite run.

```text
--test --test-name-pattern='Research carrier reconstructs|Writing carrier proof' tests/executive.test.cjs
✔ Writing carrier proof rejects altered source, geometry and resource bindings (242.125269ms)
✔ Research carrier reconstructs the accepted scene and rejects unknown producer or geometry identities (517.981853ms)
ℹ tests 2
ℹ suites 0
ℹ pass 2
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 865.828081
exit 0

--test --test-name-pattern='Writing resources retain exact' tests/site-engine.test.cjs
✔ Writing resources retain exact geometry, finite closure and complete transfer admission (284.435563ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 391.603088
exit 0

--test --test-name-pattern='frozen production archives verify' tests/reader-controller.test.cjs
✔ frozen production archives verify native article inventory and indexed metadata (976.543147ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1128.730621
exit 0

--test --test-name-pattern='fresh SEO CLI accepts' tests/content-rendering.test.cjs
✔ fresh SEO CLI accepts current authored Home text and refuses stale approved body bytes (7878.078559ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 7963.896314
exit 0
```

Manual Python commands used `hashlib.sha256(path.read_bytes())` for every packet manifest/dependency, `gzip.decompress` plus `git show prior:path` for each archival identity, and parsed-ledger prefix comparison plus per-ID source/value checks. They exited0 and returned packet hash match, empty manifest/dependency mismatch lists, both `decoded_equal_prior True`, ledger prior-prefix equality True, and predecessor/current fallback equality True/True. A preliminary guessed manuscript path was absent; no preservation inference used that miss. Preservation conclusion comes from the empty complete-subtree Git comparison.

Inspected supplied raw evidence without relabelling it: `pinned-controller.tap` reports13/13 but producerDirty:true, syntheticSourceLabels:true, providerCalled:false, productionEligible:false; `affected-first.tap` reports94/95 with the missing index-only Research snapshot ENOENT; `index-corrected-case.tap` reports1/1 for that parser case; `ri-build-v3.log` reports only a build of2568files/266directories. These are their bounded original observations, not proof of a complete current-head campaign.

## Remaining gates and limits

No blocking finding was established. Full current-source Basic/source/security/RI/style and actual owner stable staging remain pending in the supplied packet and are owned by the orchestrator. The absent-resource setup branch in the new Writing test is not exercised on this candidate because publication already contains the exact resource; historical both-form receipts are not substituted as a fresh current execution. No measured coverage, native browser, hosted HTTP, five-page PDF visual review, authenticated stage promotion or production action was performed by this role. All unchanged human/editorial/rights and source-bound AC gates remain distinct.
