# Requirements & Acceptance — final integration first judgment

**Verdict:** no blocking requirement or acceptance-linkage defect found in the inspected integration. This is a bounded source review, **not acceptance of stable staging or issue completion**. Current full source/security, native admission, three other final-role results and exact stable article/PDF observations remain required and were not inferred from prior green runs.

## Identity and review limits

- Role: distinct nonauthor Requirements & Acceptance; final-integration first judgment, 2026-11-06; task `/root/requirements_integration`.
- Candidate inspected: `ed18fcf1c59c31521f58816117c08cf777872cdc`, tree `c766f20b887c1de7b61e80d0dd30fbe2aa7e1231`; working tree clean before and after inspection.
- Publication predecessor: `558682775b9798a961f91a86673000a0b13e34d9`; integrated protected main: `312fbe4347eda332aa8ade885b07c98beadd6da5`.
- Packet SHA-256 verified: `8584ff100cee29bb3f93342fe9882f3e09bf80f60f192505518d8ab95afb76e7`. All 24 manifest entries and all supplied dependency hashes matched inspected bytes, including common prompt `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`, role prompt `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6` and issue policy `fcdf6622a5e6a0ba7e62fad828b82e14b2c6e8c75a96b18f97f12d1abc87025e`.
- Read original intent/dated issue, README, root AGENTS (no nested AGENTS found), relevant repository-map routes, dated MEMORY, CONTRIBUTING independent-review/acceptance protocol, acceptance policy/allocation, actual selected Git delta and candidate controls/tests. Candidate reports were review subjects, not proof of their own claims.
- Explicit none-fork launch was stated in task; the orchestrator must retain the actual accepted launch receipt. Provider model/context internals and wider memory injection are unknown. No peer output or author chat was deliberately inspected; this is an operational boundary, not provider isolation attestation.
- No external writes, implementation/test changes, recursive delegation or browser work. Broad checks belong to the orchestrator. Live GitHub state and served staging surfaces were not independently observed in this execution.

## Requirements and evidence assessment

The latest supplied scope is clear and assessable: integrate the accepted controller into PR170, admit the exact current source, complete the existing full owner staging profile, inspect the stable R10 article/PDF, and STOP/show. PR170 merge, production activation and platform posting are excluded. Earlier production authorization in the dated issue remains history; it does not override this narrower continuation. `review/issue-169/2026-11-06-main-controller-integration.md:10–17` preserves that distinction.

The stable AC IDs retain their original meaning and later dated amendments. The five-page R10 PDF and hero plus four figures are the current obligations, superseding historical quantities. The policy deliberately delegates native, editorial, visual, copy and delivery acceptance to named gates; RI/style cannot prove those outcomes. The allocation's dated R10 and planned-link amendments resolve the historical R9 introductory wording. No new editorial requirement or test oracle was introduced by this integration.

| Intent / AC | Independent oracle or required gate | Observed source/result and remaining boundary |
| --- | --- | --- |
| Preserve accepted R10 source/PDF/figures and discovery; AC01–04/07–10 | Exact authored/public byte identity to publication predecessor; existing publisher/material/history checks and later served-reader inspection | `git diff predecessor HEAD -- site docs` has no paths. This establishes preservation of those tracked bytes, not successful current generation, readability or served equivalence. |
| Preserve Research/Writing provenance; AC05/10 | Exact historical Git lineage, equal fallback successor, unchanged accepted scene; negative producer/geometry cases | `tools/check_site_seo.cjs:314–379` independently verifies the dedicated record, historical fallback and agreement with Writing proof. Executed pinned Node `--test --test-name-pattern='Research carrier reconstructs' tests/executive.test.cjs`: **1/1 pass**, no skips/failures, about 0.53s. |
| Keep applicable cases selected; AC05/11 | Maintained registry inputs and permanent staging/production profiles | Executive and content-rendering add `trusted-reader-producer.json` inputs at registry lines621/1647. All four affected modules retain pr-targeted/staging/production routes. Archive inventory/canonical/robots negatives remain in reader-controller. Selection inspection is not actual complete-suite execution. |
| Keep security review exact; AC05/11 | Exact-ID ledger selection, preserved disposition and current raw scanner/context validation | 3,161 publication checksum rows are retained byte-for-field; exactly five main-only rows are appended, 3,166 unique IDs total. All main IDs remain represented. Bandit policy, frozen secret baseline and other reviewed-secret ledger equal publication bytes. Full current security execution remains pending. |
| Preserve historical evidence without increasing RI limits; AC05 | Original Git bytes equal decoded archive; locators retain inspection route; complete current RI verify | Independently decompressed both gzip files and compared against predecessor Git blobs: **1,426,481/1,426,481 bytes** and **1,984,277/1,984,277 bytes**, exact equality. Locators explicitly state historical status. Active tools/tests/site references search found no consumers of these historical paths; only catalog/generated metadata references. Existing 250MB limit remains. Current RI build log says built; verify is not supplied as passed. |
| Current admission and independent roles; AC05/11 | Exact-source Basic/RI/RI-CI/style/security/owning checks and four actual role results | Supplied pinned-controller TAP reports 13/13 on a dirty prepared producer, with synthetic labels, providerCalled false and productionEligible false. Supplied four-module run contains a real ENOENT; supplied isolated corrected parser case passes1/1. These do not establish a complete final-source campaign or native admission. |
| Stable article/PDF and related reading; AC09/10 | Matching owner stage source/tree/artifact/alias; actual desktop/mobile/no-JS article/material/related observations; PDF bytes/MIME/pages/readability | **Not observed.** Historical controller staging is a prerequisite, not PR170 staging evidence. Current matching native/hosted/stable records and five-page inspection remain the next delivery gates. |
| Stop at staging; AC04/05/09/11 | No PR170 merge/production/platform writes; preserve whole-AC pending states | Candidate report/MEMORY explicitly retain STOP/show and only historical AC06 as complete. Whole remaining criteria cannot be ticked by this review or staging alone. |

## Nonblocking finding and integration risks

**RA-1 — Low, conflict-disposition precision.** `2026-11-06-main-controller-integration.md:33–36` says “preserve existing rows/reasons” without naming precedence for overlapping IDs. Independent comparison finds **63 shared main/publication IDs with different reason text**. Candidate retains the publication reason for all63; path, rule and false-positive disposition agree, no main-only row is dropped, and main's separate security proof remains retained. Therefore no scanner widening or lost selected disposition is observed. Treatment: explicitly record publication-row precedence for shared IDs, preservation of the five main-only rows and retained controller proof. Do not describe the union as byte-identical retention of both conflicting reason sets. Current exact-source security review must still validate selected source/context; neither reason text nor prior main acceptance supplies that result. Affected AC05/11.

Archiving changes how two historical previews are opened, but not their retained original bytes. Original-path locators plus lossless archives satisfy the inspected historical-retention obligation; the absence of active consumers and explicit historical labels make this a bounded archival adjustment rather than an acceptance-oracle replacement. Search coverage was active tools/tests/site and authoritative guides/configuration; arbitrary external bookmarks and human download behavior were not observed.

No additional owner decision is needed to continue already authorized reversible preparation and staging. The outstanding requirements are evidence gates, not a request to expand scope. Before final delivery, bind all current results to the final candidate (re-review affected meaning if it changes), reconcile the other role findings, complete native admission and full matching owner staging, inspect stable R10 reader/PDF, then STOP. Do not merge PR170, activate production, claim platform posting or close the issue.

## Supplementary inspected evidence identities

The packet names the following external snapshots/logs by local reference. Their independently observed SHA-256 values bind this result to the actual bytes read:

| Source | SHA-256 |
| --- | --- |
| `issue169-scope.txt` | `60808d2a8ed3b4fc6d452b35971156a38d4f781657839c6d1599e66ea28f06ee` |
| `issue169-current.md` | `0ab9ce6e03cd50f6360b780ba21d3f20c26d021584d4552102b9da8f3d7d8cf6` |
| `integration.diff` | `e33017058e9725d7f21b15a09f0650d79ba3385bc2fc3456d263e60c51ce5001` |
| `pinned-controller.tap` | `6b0f51008cea73cbb61c544414a52e0a66b92ffdc9e6c5cd9a6db998b304be2d` |
| `affected-first.tap` | `0c500dc90ca9831ec6adfbbdd66006d9a63ec8cb0ca57ae95e275128e653a6b6` |
| `index-corrected-case.tap` | `7556d7eae05e3b0a45b56389694afadf4e6448f596ebbe8fe089d874eaf2d4fc` |
| `ri-build-v3.log` | `2b5757ff1b3c97637ed2e7f6df534651bdb257f5d0aa56aa8db769d55b3dd8e6` |

This first judgment is preserved independently; no correction or peer reconciliation has been incorporated.
