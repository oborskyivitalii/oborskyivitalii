# Final integration — Code / changed-artifact first judgment

**Verdict: no blocking code/artifact findings in the inspected integration.** This is a bounded source review, not native/stable acceptance or release approval. AC05/09/10/11 remain dependent on the current-source checks, other required roles and actual delivery observations.

## Identity and boundaries

- Role/task: distinct nonauthor Code / changed-artifact, `/root/code_integration`, first judgment.
- Candidate: `ed18fcf1c59c31521f58816117c08cf777872cdc`, tree `c766f20b887c1de7b61e80d0dd30fbe2aa7e1231`.
- Publication baseline: `558682775b9798a961f91a86673000a0b13e34d9`; integrated main: `312fbe4347eda332aa8ade885b07c98beadd6da5`. Merge commit `46b9fb96517a3b7d7c114db55704cf4a6c656317` has exactly those parents.
- Packet SHA256: `8584ff100cee29bb3f93342fe9882f3e09bf80f60f192505518d8ab95afb76e7`.
- Common prompt SHA256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256: `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- All packet manifest and dependency hashes matched the inspected files, including a final readback. HEAD remained the supplied candidate; Git working status was clean before writing this assigned output.
- Launch was supplied as explicit `fork_turns="none"`; accepted launch/handle proof belongs to the orchestrator. Provider model/context internals are unknown. I did not inspect peer outputs, parent scratch notes or unrelated memory, delegate, implement, or write externally. The candidate's own reports were treated as review subjects.

## Independent inspection

Read the original/current issue scope, acceptance mapping, repository/common/role instructions, applicable CONTRIBUTING review protocol and CODE-STYLE. Inspected the actual publication-to-candidate delta and main-side source, Research/Writing records, new archive inventory negatives, resource admission tests, profile allocation, checksum ledger and historical archive proof. The publication-to-candidate delta is 24 paths; there is no delta in `site/`, `docs/`, staging/release/site producer owners or the output lock. Thus this integration does not alter the accepted manuscript/PDF/runtime/public bytes relative to the publication baseline.

The Research reconciliation retains the immutable accepted Research record and its exact predecessor byte checks. The separately hard-pinned reader successor must match the prior fallback hash and its actual Git ancestor; the existing Writing successor must yield the same current fallback hash. All other current producer bytes still pass through their Writing bindings. Exact Research/Writing SVG reconstruction and native route resource checks remain present. This addresses provenance compatibility without substituting current geometry for historical acceptance.

The added tests preserve meaningful negative behavior: missing/extra/mutated reader successor fields; corrupted accepted predecessor; wrong route/depth/fragment/duplicate or absent resource; unsafe passive SVG; omitted transfer bytes/resource identity; and frozen article sitemap, inventory, indexing, canonical and social metadata failures. The frozen archive tests recompute the outer artifact manifest after mutation, so rejection must come from the inner edition contract. The fresh SEO CLI fixture now copies its newly required reader record.

Every test row and every declared input from both parent registries survives. Publication lifecycle/profile/disposition metadata is unchanged; main differences are the retained publication-specific purpose/disposition descriptions. Hosted profiles equal both parents. Executive and content-rendering rows explicitly include the new reader-record dependency. No test budget, scanner implementation or admission bound changed in this delta.

Checksum reconciliation is a stable-ID union: all 3,161 publication rows survive byte-for-byte as parsed records; all five main-only rows are appended, yielding 3,166 unique IDs. All 1,790 main IDs survive with identical non-reason fields. For 63 shared IDs, main's generic proof reason differs from publication's pre-existing, more specific reason; the integration retains publication's unchanged reason and both proof files remain available. This is not byte equality of both whole parent ledgers. The five added records bind only exact public predecessor/current fallback identities and reference retained source proof. Current security/scanner execution remains a separate required check.

The two gzip archives independently decoded to the exact original Git bytes from publication5586827: 1,426,481 bytes for `site-v1-20261002-v6-index.html` and 1,984,277 for `site-visual-proposal-20261002.html`. Recorded original/archive hashes, byte counts and Git blobs matched. Original paths now explicitly identify themselves as archive download locators; relevant tools/tests/site searches found no active consumer. Catalog removals versus main are exactly the ten absent generated snapshot directory/file entries described by the candidate report; publication catalog entries are retained.

## Checks actually executed

Using pinned Node `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node`, with a 20-second timeout for each invocation:

| Source case | Result |
| --- | --- |
| `tests/executive.test.cjs`, pattern `Writing carrier proof\|Research carrier reconstructs` | 2/2 pass; 0 failures/skips/cancellations, 861 ms |
| `tests/site-engine.test.cjs`, pattern `Writing resources retain` | 1/1 pass; 0 failures/skips/cancellations, 438 ms |
| `tests/reader-controller.test.cjs`, pattern `frozen production archives verify` | 1/1 pass; 0 failures/skips/cancellations, 1,033 ms |

Also independently recomputed packet/dependency hashes, archive byte/hash/blob proof, both-parent registry input retention, catalog removals and ledger identity/record accounting with read-only Python/Git commands.

Read supplied raw evidence: pinned-controller case 13/13 pass with dirty prepared producer/synthetic-source/provider-not-called limitations; initial affected campaign's index-only ENOENT failure; corrected parser case 1/1 pass; RI build reporting 2,568 files/266 directories. These establish their bounded prepared observations, not a final candidate-wide campaign.

## Remaining evidence and disposition

No code fix is requested by this review. Root owns broad/current source, Basic, formatting/lint/security/RI and owning checks; I did not rerun those suites. Current native/stable staging and served article/PDF/browser behavior were not observed. The candidate reports correctly leave those pending. This result supplies neither source-admission completion nor author/maintainer approval and cannot authorize PR170 merge or production.
