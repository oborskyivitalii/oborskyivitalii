# Exploratory charter — DevCon completed-event correction

Role: distinct nonauthor Exploratory / Interaction QA. Owner #169, PR #170; prepared candidate based on `29de0a05575e44c1637ee0fba1c59f786af306e4`, not a clean checkout. Packet SHA-256: `db7f1ba4ebfd65f1c3627db5c954c58dadc4c3a3cebfb72ff13fd21864213969`.

Read common contract SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` and exploratory role `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`. Checked root instructions, README, relevant repository-map ownership, site source contract and profile mapping. MEMORY, peer reviews and parent notes were not read. Provider memory internals are unknown; requested isolation is an orchestrator receipt, not independently observable here.

Source inspection: `site/content/events.json` SHA-256 `6c584ae43e52a1e8cc25151a792bd5d274f2f99126f7593b098bf346ac2cb96a`; Talks metadata `2d6a64e397594a81eb04fafe9f807617ae7479e3f9291b2093032994e1b7b3b5`; generated `docs/talks.html` `5f04c894234158fe0bf9fba18489921669df26d51a98ddb54b2c12f25fdbdfc6`. All match packet. Source places DevCon after `other-talks`, once, with past tense, date-only 4 November 2026 and one official programme link. This is source evidence, not a browser pass.

## Designed browser journeys

1. Open the corrected immutable preview Talks route; check Upcoming contains PMDay Winter and excludes DevCon. Follow Upcoming and Other talks section anchors; verify visible heading/card association.
2. Open the preserved DevCon fragment directly. Confirm full title, conference/Bucharest metadata, 4 November 2026, past-tense account, and programme destination. Inspect card links for absence of invented recording/slides. Observe settled layout after animation before judging visibility.
3. Navigate to Writing, locate the native SDLC article in the 2026 AI-assisted delivery archive, and confirm the R10 placement remains outside featured reading paths; return to Talks if time permits.

Bound: next browser phase at most three minutes, each check at most 60 seconds. Native Chromium is reported socket-blocked; no relaunch planned. Corrected preview access pending; **zero UI cases executed**. Physical-device, full accessibility and release acceptance are unobserved. Existing content/browser profiles remain the regression owners; no new suite proposed for this bounded editorial correction.
