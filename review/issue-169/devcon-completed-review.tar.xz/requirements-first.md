# Requirements & Acceptance — preimplementation first judgment

Verdict: **PASS for the bounded content correction; final acceptance pending.** The proposed route fits the supplied author-confirmed occurrence and existing event schema. No requirement needs a new renderer, schema, SEO adapter or release route. This does not approve merge, publication or whole issue169 completion.

Identity: reviewer `/root/devcon_requirements`, first preflight execution; nonauthor, no implementation or test changes. Requested isolation is explicit none-fork according to the supplied task; provider-internal history/memory behavior is unknown. I did not read MEMORY, peer outputs, parent scratch notes or private history.

Inspected source: clean Git HEAD `29de0a05575e44c1637ee0fba1c59f786af306e4`; packet SHA256 `09e8f80f94473488abc5e19be5ff1bc61c675f4a0fa700b1a2b7aa05b949e36a`. Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. AGENTS, CONTRIBUTING, events, Talks metadata, both event/content tests and issue169 acceptance hashes matched the packet. Read README, site contract, map, relevant check-profile sections, actual event renderer/SEO reconstruction and issue126 factual amendment. Only root AGENTS exists.

The existing source still incorrectly puts DevCon first in `upcoming-talks`, says “I’ll be speaking”, and includes an announced time. Moving that one record to the front of `other-talks`, marking it a conference talk in Bucharest and using a date-only `2026-11-04` faithfully narrows the facts to those confirmed in the packet. Preserve the exact title, anchor and official programme link; neither language badge nor new media is justified. `other-talks` is the existing suitable completed-event group, although its heading does not literally say “past”.

The proposed route description is **truthful and already approved historical copy**: issue126's three metadata `before` values contain it exactly. Winter remains upcoming; the Autumn recording exists in the unchanged event collection. Omitting DevCon from that short description does not contradict its completed card. `restoreEventsCatalog` validates current data-produced HTML before restoring its frozen frame, so this event change needs no producer alteration. Final SEO execution must still prove the complete reconstruction.

| Supplied intent / requirement | Check or gate | Preflight observation |
| --- | --- | --- |
| DevCon occurred, appears once outside Upcoming | Rendered card count, anchor uniqueness, group boundary and past-tense assertions; actual browser | Schema supports it; not implemented/executed |
| Preserve 4 November, title, anchor, programme; omit unconfirmed time/media | Exact independent constants and negative assertions | Current source gives immutable values; planned date-only narrowing is consistent |
| Other records and Winter unchanged | Compare non-DevCon event objects/cards and their relative order against base | Existing tests already provide historical preservation oracles; retain their strength |
| Truthful descriptions across HTML/OG/Twitter | Exact historical description and generated head assertions; SEO check | All three historical strings verified |
| Writing/R10/manuscript/PDF/deck/speech unchanged | Scoped diff and generated/source identity comparisons | No change yet; final check required |
| New preview, same owner/PR | Exact-source Basic/RI and applicable source suites; hosted preview/browser evidence | Pending; existing route remains authoritative |

Nonblocking traceability finding: `.github/acceptance/issue-169.json` remains broad article/release acceptance and does not itself express this DevCon increment. Record this dated correction and its observable checks under the existing owner/PR without weakening or ticking the wider ACs. The packet is sufficient preflight intent, but I did not independently fetch live owner/PR text.

Nonblocking test-maintenance caution: `tests/content.test.cjs` currently requires DevCon at `cards[0]` and the old timed announcement. Replace those obsolete expectations with completion/group/date invariants while preserving exact previous-card comparisons and tamper negatives. Generic data-to-output equality alone cannot establish the new editorial truth. Test edits can affect CI classification; “data-only content” must not be used to bypass the unchanged selector's applicable checks.

Limits: bounded source inspection only; no tests, browser, hosted preview, external facts or live refs observed. Next gate: implement within scope, run mapped checks, and obtain final source-bound Requirements plus the other three independent results on the actual candidate.
