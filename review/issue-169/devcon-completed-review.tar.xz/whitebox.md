# White-box QA — first independent judgment

**Verdict: PASS for the bounded source/HTML correction; no findings.** This does not accept browser parity, Basic, RI, hosting or whole-release gates.

Identity: `/root/devcon_whitebox`, owner #169 / PR #170, prepared dirty worktree at base/HEAD `29de0a05575e44c1637ee0fba1c59f786af306e4`. No implementation edits, external writes or delegation. No MEMORY, peer reports, private history or parent notes read. Launch receipt must establish requested `fork_turns="none"`; provider memory/context internals are unknown.

## Inputs and identity

Read candidate, common/role contracts, README, root AGENTS, CONTRIBUTING, repository-map owner entries, site source contract, mapped check guidance, acceptance metadata and actual changed source/tests. No nested AGENTS was found under site/tools/tests.

SHA-256:

- Packet: `db7f1ba4ebfd65f1c3627db5c954c58dadc4c3a3cebfb72ff13fd21864213969`.
- Common: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- White-box prompt: `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Diff over events, Talks metadata, content test versus base: `320b19464aad42d769c30350ff211b7c611c0677fa23916e671e99da67dee5e0`.
- Generated Talks: `5f04c894234158fe0bf9fba18489921669df26d51a98ddb54b2c12f25fdbdfc6`.

Independently verified every packet source-manifest hash against inspected bytes. Only those three authored files plus generated artifacts differ. Engine, templates, SEO adapter and event tests are unchanged.

## Risk → structure → scenario → oracle/check

| Risk / requirement | Structural failure and scenario | Independent oracle / executed check |
| --- | --- | --- |
| Completed status/location | Card remains upcoming or duplicates after moving | Exactly one DevCon object; first in other-talks; Winter sole upcoming; direct JSON comparison and existing completed-DevCon content case |
| Preserved facts | Incorrect date, title, anchor or programme URL | Compare prior Git object; exact date-only 2026-11-04; existing HTML assertions and SEO reconstruction |
| No invented detail | Old announced time or new media survives | Single unchanged programme destination; no time/slides/recording/future wording; existing negative tamper cases |
| Other content unchanged | Relocation alters neighboring cards or R10/Writing | Other event objects deep-equal base in order; four other generated pages byte-identical; no article/Writing/engine/template changes |
| Renderer/reconstruction integrity | Duplicate identity, unsafe URL, malformed date, source/output mismatch | Existing events suite rejects invalid records, inertly escapes text and rejects tampered output/producer bytes |

## Execution and limits

Executed `timeout 60s node --test tests/content.test.cjs tests/events.test.cjs`: **exit 0**, 19 tests, 19 pass, 0 fail/cancelled/skipped/todo; 4105 ms. Existing negative cases rejected changed date, future tense, programme URL and inserted slides. These suites map to registered content/permanent source routes in SITE-CHECK-PROFILES/test-profiles.

Executed a separate read-only Node probe: all manifest hashes matched; exact event comparisons passed; `restore(html,page)` passed for index/research/writing/talks/credits; unchanged-page byte comparisons passed. **Exit 0**. Raw terminal results are calls `4d6af4`/`f66fc9` and `5a06c6`/`bb09a2`.

Coverage is scenario-based; no branch percentage claimed. Native Chromium was reported unavailable and was not relaunched. Browser rendering, responsive interaction, hosted delivery, full Basic and RI remain unobserved here and belong to orchestrator delivery checks. Temporary test fixtures are cleaned by existing suites; no new tests were authored.
