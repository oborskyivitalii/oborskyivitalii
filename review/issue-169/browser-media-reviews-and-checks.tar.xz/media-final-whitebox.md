# White-box QA — final media controller candidate

First independent result, 2026-11-07. Role/task: White-box QA, `/root/media_final_whitebox`. Verdict: **no blocking implementation finding in the bounded inspected change; four selected checks pass**. This is local structural/component assurance, not current-head hosted staging, native runner, maintainer acceptance, or whole-issue acceptance.

## Identity and boundaries

- Repository: `/workspace/scratch/b15f3a872203/controller-media`.
- Base: `312fbe4347eda332aa8ade885b07c98beadd6da5`.
- Candidate: `a001da89397f17668e8b3627f9f9cb42608ccdb3`; tree `0053dcac497e0088e35ca4033e9bb386076a6697`.
- Clean worktree observed before and after checks. Source was not edited.
- Supplied diff and actual `git diff --binary` base-to-candidate independently match SHA-256 `c03ec4dceffefa45e5e14e63a25be5825f691ec432d0e923cfad0ca753d4e56e`.
- Packet: `/workspace/scratch/b15f3a872203/reconcile-review/media-controller-final-packet.json`; SHA-256 `a17a6357ccb3ba715399d81ee4c9b822f472478b179cf96d9806d8ef57856db9`. Every `files` and `raw` manifest entry was independently SHA-256 checked; no mismatch.
- Common prompt `agents/reviewers/README.md`: SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role prompt `agents/reviewers/white-box-qa.md`: SHA-256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Read root instructions, purpose, current handoff, relevant repository map/owners, common and role prompts, supplied original issue/scope, changed executable/test source, media producer/adapter, workflow consumer steps, profile mapping and supplied raw evidence. No nested `AGENTS.md` exists under the inspected `.github`, `tools`, `tests`, or `agents` trees.
- Requested launch isolation was reported as none-fork in the task. Actual parent-side launch receipt must establish the accepted parameter; provider model/context/memory internals are unknown. I did not inspect peer results, parent private notes or private chat history. Packet candidate rationale and MEMORY claims were treated as review subjects, not acceptance oracles.
- Four existing cases, within ten-minute bound; no delegation or external writes. Only assigned review artifact written. No source/test authored by this reviewer.

## Accepted invariant and structural review

Issue169 scope restores declared browser-fixture media dependencies in staging and production consumers, preserves cases/budgets and accepted R10/site/docs, and stops after verified stable staging. AC05/11 require current-source independent review/checks; AC09/10 still require actual delivered reader/PDF/journeys. This review contributes only its own bounded portion.

`.github/actions/publication-media/action.yml:6–34` obtains the canonical interpreter output, asks that exact executable for the requirement, installs the returned canonical pin, verifies installed Pillow and WebP against the existing owner, and exports the interpreter only after success. `execFileSync` preserves a path containing spaces and Windows backslashes as one executable, without a shell substitution. Extraction, installation, or verification exceptions stop before environment export. Existing action code does not swallow failures. `setup-python` and Node versions remain pinned.

`.github/workflows/site-release-checks.yml:407–408,470–471,609–610` prepares dependencies separately before fixture collection in Linux production, the native Windows/macOS matrix, and staging. Reading the actual job steps established this placement; the component check also parses the workflow and tests ordering. The historical separate capture job's Pillow12.3 installation is not the functional fixture interpreter or canonical producer pin; it is not a substitute for these added per-job preparations.

`tools/quality/analytics-browser.cjs:453–480` now copies the canonical requirements declaration alongside the producer owners and budgets. It does not copy the quality venv or quality Node installation. Copied producer source resolves the declaration relative to its copied root; the explicit selected interpreter crosses the process boundary through `SITE_MEDIA_PYTHON`. The guard in `tools/publishing/web-media.py` continues to reject a missing/ambiguous pin, wrong Pillow or wrong codec. The fixture does not silently fabricate article media or omit failed evidence.

`tools/quality/staging-regression.cjs:286–293` now rejects startup/collection failures before validating the dependent article evidence. The article validator remains mandatory immediately afterward. The raw failed report contains actual `No module named 'PIL'`, zero analytics, and the former secondary selected-article error; the change preserves the causal failure for diagnosis without granting passage.

Cleanup is unchanged: `analytics-browser.run` encloses fixture creation/scenario work in `try/finally` and removes the temporary directory even if preparation throws. Functional collection uses `Promise.allSettled` before processing groups and refuses cleanup failure. This source inspection is not executed cleanup fault coverage. No new browser navigation/cancellation state machine or user interface is introduced by this patch.

## Risk → check matrix

| Risk / AC | Structural fault and scenario | Independent oracle | Executed check / route |
| --- | --- | --- | --- |
| Fixture dependency closure / AC05,09,10 | Copied root lacks a required owner; real hosted/offline producer rebuild | Actual build check, manifest/snapshot verification, all route and legal-source bytes | `actual analytics browser fixture builds its real hosted and offline producer dependency closure`; permanent `tests/analytics.test.cjs`, source-full/changed-path registry |
| Real media guard / AC05,09 | Selected Python lacks Pillow; copied root loses canonical pin; then declaration restored | Empty venv must fail with actual PIL import error; selected actual interpreter must emit correct digest/dimensions/MIME and canonical Pillow; missing declaration must fail; restored declaration succeeds in fresh child | `copied analytics media producer needs its declared pin and actual selected interpreter`; same permanent analytics suite; web-media/requirements now mapped inputs |
| Setup ordering, Windows path binding, failed export / AC05,11 | Browser jobs omit setup; install or verification fails; Windows executable has spaces/backslashes | All three jobs prepare before collectors; same literal executable used throughout; export absent on failure | `every fixture-building browser job prepares the same canonical media interpreter`; permanent `tests/quality.test.cjs`; action glob and producer/pin mapped inputs; staging and production jobs consume action |
| Primary failure diagnostic / AC05 | PIL preparation failure is obscured by missing dependent article evidence | With startup failure, error contains primary PIL failure; after clearing startup failure, missing selected article evidence still rejects | `functional collection failures remain visible before secondary missing article evidence`; permanent `tests/staging-regression.test.cjs`, existing source/staging contract route |

The action component case executes the action's JavaScript in a VM with recorded child-process and environment-file effects. For each POSIX/Windows path it tests success plus injected install and verification exceptions. It is not an actual Windows process or actual pip execution. The media case does execute real Python and real Pillow, creates its own empty venv without pip, deletes/restores only the isolated copied pin, and uses fresh child processes; it is not a mocked import error.

## Actual bounded execution and raw receipt

Pinned Node: `v24.19.0` at `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node`.
Actual available interpreter: repository `tools/quality/toolchain/venv/bin/python`, Python3.12.14, Pillow13.0.0, WebP1.6.0 (queried before execution). No interpreter override was supplied for the test invocation.

Command, repository cwd:

```sh
/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node --test --test-name-pattern='^(actual analytics browser fixture builds its real hosted and offline producer dependency closure|copied analytics media producer needs its declared pin and actual selected interpreter|functional collection failures remain visible before secondary missing article evidence|every fixture-building browser job prepares the same canonical media interpreter)$' tests/analytics.test.cjs tests/staging-regression.test.cjs tests/quality.test.cjs
```

Raw completed tool output (session38594; exit0, no signal reported):

```text
✔ actual analytics browser fixture builds its real hosted and offline producer dependency closure (756.486375ms)
✔ copied analytics media producer needs its declared pin and actual selected interpreter (1131.351248ms)
✔ every fixture-building browser job prepares the same canonical media interpreter (57.088622ms)
✔ functional collection failures remain visible before secondary missing article evidence (19.508839ms)
ℹ tests 4
ℹ suites 0
ℹ pass 4
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1990.322575
```

Four selected top-level cases comprise the entire executed campaign. Negative branches are internal assertions of those cases, not additional claimed independent campaigns. No failed campaign was blindly retried. No quantitative branch/coverage measurement was taken.

## Retained evidence and limits

Supplied `media-clean-action.json` binds the exact action SHA-256 `cc2477b02dd5f684e398f87cfb51fd11f3ffcc4be223a31bcc11a70b86208873`, reports Pillow absent before actual action execution, action exit0, exact interpreter export, Pillow13/WebP1.6 verification, and selected R10 fresh copied producer media/download parity. Its packet hash was verified. `fixture-copy-closure-after.json` reports R10 canonical-pin copy, exact media/downloads and fresh copied producer exit0. These are retained bounded evidence, not my reexecution; the latter originally describes a prepared working subset. They support the mechanism but cannot stand in for exact-head native/hosted controller acceptance. No new clean install was performed within this four-case allocation.

Raw failed staging functional evidence still reports failure; performance success does not repair that obligation. No current-head hosted browser/reader/PDF observation, actual Windows/macOS action execution, clean network dependency installation, setup-python runtime download behavior, filesystem cleanup fault injection, wrong-Pillow/wrong-codec injection, pin-extraction exception injection, or full source/security/RI campaign was executed here. Those gaps are explicitly unobserved, not waived or declared not applicable. Current browser jobs and whole original acceptance remain required; maintainer reviewed_sha remains separate.

No finding requires an implementation correction from this bounded review. Remaining gaps belong to the existing controller native/staging and release/acceptance gates; this result authorizes none of merge, stable promotion, production or issue closure.
