# Exploratory / operator QA — first independent result

Verdict: **PASS in the bounded local operator scope; no candidate findings.** This is not hosted staging, native cross-platform, full source-suite or publication acceptance. Whole issue169 criteria remain open except the already accepted historical AC06. Stable R10 staging and STOP remain the authorized endpoint.

## Identity and independence

- Role/execution: Exploratory / Interaction QA, `/root/media_final_exploratory`, first result. No delegation, source edits, external-service writes, peer results or author private history were used.
- Supplied launch states requested `fork_turns="none"`; actual tool launch/accepted response must be recorded separately by the orchestrator. Provider model/context/memory internals are unknown. I cannot attest to platform internals or infer accepted launch parameters from a role label.
- Repository: `/workspace/scratch/b15f3a872203/controller-media`; base `312fbe4347eda332aa8ade885b07c98beadd6da5`; inspected and final clean candidate `a001da89397f17668e8b3627f9f9cb42608ccdb3`, tree `0053dcac497e0088e35ca4033e9bb386076a6697`.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Packet: `media-controller-final-packet.json`, SHA256 `a17a6357ccb3ba715399d81ee4c9b822f472478b179cf96d9806d8ef57856db9`; supplied diff SHA256 `c03ec4dceffefa45e5e14e63a25be5825f691ec432d0e923cfad0ca753d4e56e`. Every packet `files` entry was rehashed at completion: zero mismatches.
- Genuine publication producer: `/workspace/scratch/b15f3a872203/repo`, clean `ec35807bec4a233cf7e80eb39f455c1f6b19434a` before and after exploration. No publication source was modified.

## Independent charter and actual surface

Charter fixed before execution: exercise (1) canonical setup and interpreter handoff, (2) cold copied real-R10 fixture preparation and fresh-process rebuild, (3) missing dependency/pin refusal and recovery, (4) primary collection error visibility. Bound: four cases, maximum ten minutes. Actual runtime exploration ran 2026-11-07 00:32:10Z–00:34:24Z; no full failed campaign was retried.

This change alters a composite Actions setup, a source-fixture dependency copy and validation error ordering. CLI/process and operator diagnostic behavior are the applicable interaction surface. No product UI/browser runtime changed, so new product visual/accessibility journeys are reasoned not applicable to this correction. Actual native Actions and hosted article/PDF journeys remain **not observed**, not N/A.

Inspected owners: root README/AGENTS/MEMORY, repository map owner rows, common/role prompts, issue169 intent/scope/ACs, applicable CONTRIBUTING/acceptance/staging/check-profile instructions, actual executable/test diff, `web-media.py`, `article-media.cjs`, `article-materials.cjs`, workflow staging/Linux/native consumer ordering and test registry. No nested AGENTS existed under the affected `.github`, tools, tests, guides or agents trees. Large combined source output was truncated initially; relevant operator owners were subsequently read directly. Candidate historical review assertions were not used as verdict evidence.

Runtime: Linux; pinned Node `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node` v24.19.0; observed Python3.12.14. Temporary environment `/tmp/media-exploratory-9yr477v8`; isolated Python path deliberately contained spaces. Managed environment status tool was not exposed and `/etc/codex/network-policy.json` was absent, so runtime policy/credential readiness is unknown. Normal inherited pip configuration was preserved; exact setup used cached declared Pillow wheel successfully.

## Executed cases and retained observations

| Case | Expected independent oracle | Action / actual observation | Result |
| --- | --- | --- | --- |
| 1. Setup handoff | The declared owner supplies the exact pin, the selected interpreter receives that pin and verifies owner codec/version before export. Paths with spaces remain executable. | Created isolated Python3.12.14 venv `python with space`; extracted and executed the actual action heredoc with pinned Node and temporary `GITHUB_ENV`. Pip installed `pillow==13.0.0`; actual verification printed `Publication media: 13.0.0 1.6.0`; exit0. Environment file contained exactly `SITE_MEDIA_PYTHON=/tmp/media-exploratory-9yr477v8/python with space/bin/python` plus newline. | Executed/pass for action body on Linux. setup-python action itself was not run locally. |
| 2. Real R10 cold preparation | Copied producer has its declared source pin and builds real selected article/media/downloads without copying a quality venv; a fresh process checks that produced result. | Called candidate `analytics-browser.buildFixture(temp/r10-source, publicationRoot)`. Actual full fixture preparation completed. Quality-toolchain directory contained only `requirements.txt`. Spawned pinned Node `tools/site/build.cjs --check` in that copied root with selected Python: exit0; built index/research/writing/talks/credits, removed none. Actual article `articles/the-sdlc-is-out-of-balance.html` contains R10 and its PDF link. Linked PDF was byte-equal to canonical source asset and digest-equal to material target, 869208bytes, SHA256 `36269db33a71781084053ae40cc41e411a0106bea5e593ef0b08414014c4ca40`. `loadArticle` selected five assets. | Executed/pass for local producer/reader link/PDF byte parity. No browser/visual/PDF layout acceptance inferred. |
| 3. Refusals and recovery | Missing Pillow and missing canonical pin are real errors; restoring each dependency allows a fresh child process to encode the same R10 image. | Used copied actual producer and selected hero asset in fresh Node/Python children, with PYTHONPATH/PYTHONHOME removed. Empty no-pip venv exited1 with `No module named 'PIL'`. Selecting prepared interpreter exited0. Temporarily removed copied requirements pin: exit1 naming exact missing requirements.txt. Restored original bytes: exit0. Both successful results reported same source digest, image/webp, 1672×545, Pillow13.0.0. Only disposable fixture files changed. | Executed/pass; two expected negative outcomes preserved. |
| 4. Operator failure diagnosis | Existing primary collection failure must surface before the secondary lack of article evidence; clearing it must still expose article evidence gate. | Read actual packet failed stage-functional report; used its startupFailures with controlled validator fixture/selected-article manifest. Candidate validator first threw `browser startup or collection failed`, with actual PIL error intact. After clearing startupFailures it threw `selected articles require actual browser evidence`. No missing-article acceptance was bypassed. | Executed/pass for diagnostic priority and retained downstream gate. |

Raw evidence from tool execution is retained here (tool execution chunk IDs `f445f6`, `a51a5e`, `f58478`, `9796cb`, `4414d3`, `a8730a`, `5de1c6`, `aba37f`):

```text
CASE1_STATUS 0
Successfully installed pillow-13.0.0
Publication media: 13.0.0 1.6.0
CASE2_FRESH_STATUS 0
{"built":["index","research","writing","talks","credits"],"reused":[],"removed":[]}
CASE2_LINKED_PDF article-media/36269db33a71781084053ae40cc41e411a0106bea5e593ef0b08414014c4ca40/reading-r10.pdf 869208 36269db33a71781084053ae40cc41e411a0106bea5e593ef0b08414014c4ca40
CASE2_SELECTED_ASSETS_COUNT 5
CASE3_ABSENT_PIL 1
Error: Lossless article media preparation failed: No module named 'PIL'
CASE3_RESTORED_PYTHON 0
[{"sourceDigest":"3fb21ca8f7aae0ebe85f9da0cc5aaf5e124deb916d9fc625d3a46e4dfd33293f","mime":"image/webp","width":1672,"height":545,"pillow":"13.0.0"}]
CASE3_ABSENT_PIN 1
Error: Lossless article media preparation failed: [Errno 2] No such file or directory: '/tmp/media-exploratory-9yr477v8/r10-source/tools/quality/toolchain/requirements.txt'
CASE3_RESTORED_PIN 0
[{"sourceDigest":"3fb21ca8f7aae0ebe85f9da0cc5aaf5e124deb916d9fc625d3a46e4dfd33293f","mime":"image/webp","width":1672,"height":545,"pillow":"13.0.0"}]
CASE4_RAW_STARTUP_FAILURES [{"engine":"chromium","error":"Lossless article media preparation failed: No module named 'PIL'\n"}]
CASE4_PRIMARY browser startup or collection failed
+ actual - expected
+ [ { engine: 'chromium', error: "Lossless article media preparation failed: No module named 'PIL'\n" } ]
- []
CASE4_CLEARED_PRIMARY selected articles require actual browser evidence
CASE4_PASS
PACKET_SOURCE_MISMATCHES []
CANDIDATE_CLEAN True
PUBLICATION_CLEAN True
```

Three exploratory observer scripts failed during case2 readback; these are **executed/fail in reviewer instrumentation**, not source defects or erased passes. First, after successful fixture build and fresh-process check, I incorrectly tried nonexistent `docs/snapshot.json` (ENOENT). Second, I incorrectly expected a generated PDF filename to contain `sdlc` (assertion false). Third, I incorrectly resolved the material target against `site/publications/...` (ENOENT). Inspection of actual output and canonical `article-materials.cjs` established `docs/article-media/<digest>/reading-r10.pdf` and source `site/assets/publications/sdlc-out-of-balance/materials/reading-r10.pdf`. I corrected readback instrumentation and inspected the existing result; the already successful builder/check were not rerun. These readback failures limit no claimed runtime result and are retained to avoid representing all exploratory commands as green.

## Findings, AC impact and allocation

No candidate finding arose from setup/handoff, copied closure, dependency refusal/recovery or operator diagnostic journeys. Local results support this correction's AC05/09/10/11 verification preparation; they do not close those criteria or authorize merge/production.

Existing/proposed case allocation through `guides/SITE-CHECK-PROFILES.md` and `tools/quality/test-profiles.json`:

| Scenario | Existing suite/profile/workflow/job or disposition |
| --- | --- |
| Canonical setup ordering/interpreter binding/failure before export | Existing `tests/quality.test.cjs`, pr-targeted/staging/production source routes. Actual action in `site-release-checks.yml` staging, linux, native jobs; native Windows/macOS execution deferred to current-head Actions. Linux local body execution recorded above. |
| Copied pin, actual media producer, missing pin/Pillow recovery | Existing `tests/analytics.test.cjs`, pr-targeted/staging/production. Current independent real-R10 fixture exercise is targeted diagnostic evidence, not an additional required CI campaign. |
| Primary collection failure before missing article | Existing `tests/staging-regression.test.cjs`, pr-targeted/staging/production; production surviving route `node tools/quality/source-tests.cjs --profile production`. |
| Stable R10 article/media/PDF and downstream browser gates | Existing full owner staging journey remains pending actual hosted run/inspection under SITE-CHECK-PROFILES and SITE-STAGING; no duplicate campaign/new profile proposed. |

I authored no accepted source/tests. No additional permanent regression is proposed: existing cases own the exercised failures. Remaining limits: no current-head hosted/native run, no physical-device/human usability proof, no production effect, no exact-head maintainer decision, no full acceptance suite claim. Orchestrator must reconcile actual launch evidence and other mandatory roles before advancement, preserve full budgets/cases, and complete the authorized stable-staging gate before STOP/show.
