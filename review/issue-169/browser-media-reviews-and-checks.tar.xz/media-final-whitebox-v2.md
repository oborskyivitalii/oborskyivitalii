# White-box QA — correction continuation

2026-11-07, own-role continuation `/root/media_final_whitebox`. **No blocking correction finding; three selected checks pass on candidate6833004.** The collector continues to refuse its controlled primary failure, joins both browsers' cleanup, and requires article evidence after collection succeeds. The correction aligns the test with that existing invariant. Full current-source acceptance remains pending; the retained1196/1198 failure is not a passing run.

## Source and execution identity

- Repository `/workspace/scratch/b15f3a872203/controller-media`, base `312fbe4347eda332aa8ade885b07c98beadd6da5`.
- Previous reviewed candidate `a001da89397f17668e8b3627f9f9cb42608ccdb3`, tree `0053dcac497e0088e35ca4033e9bb386076a6697`.
- Correction candidate `6833004eea60e805bf3415436cdb050d08a5b622`, tree `f2481a12b945fafa94b046f6c1fafe52e104c17d`. Clean worktree before and after checks; no source/test edits or external writes by this reviewer.
- Packet `/workspace/scratch/b15f3a872203/reconcile-review/media-controller-v2-packet.json`: SHA-256 `3d84369a21b66c18a1e3ce9ec4eb4a812a107895da048d98716babee4350eca6`. Independently verified every supplied `files` and `raw` hash; no mismatches.
- Supplied v2 diff and independently computed `git diff --binary` base-to-candidate both have SHA-256 `471b1bd68c5df0cb5750f792dce32ceba30877abddfa064920c7b53d6bf5a45f`.
- Common prompt SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; White-box QA prompt SHA-256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`. Reread both.
- First report preserved unchanged at `/workspace/scratch/b15f3a872203/reconcile-review/media-final-whitebox.md`, SHA-256 `3610061f5cd8ed6c7accf80c1cbb4ee56cbdff8513ce57474c4cf88734c8d1fe`.
- This is a declared correction continuation using my own prior result, neutral correction packet/raw evidence, and subsequent primary ZIP relocation receipt. It is not a newly fresh first judgment. No peer results, parent private notes, or private history inspected; no delegation. Provider model/context/memory internals remain unknown; actual initial none-fork admission is recorded by the orchestrator, not introspectable here.

## Changed source and independent interpretation

The actual old-to-new Git delta contains only `tests/article-browser-evidence.test.cjs`, the dated correction observations, and generated RI context identities. There is no implementation or bundle-manifest/compiler delta.

At `tests/article-browser-evidence.test.cjs:1019–1022`, the existing negative changes its expected exception pattern from `/require actual browser/` to `/controlled article collection failure/`. The injected failure itself, required startupFailures payload, one admitted Chromium article call, no article calls when not selected, both-engine closure assertion, and successful five-observation article validation are unchanged. The revised pattern independently matches the error injected by this test; it cannot turn a missing exception into a pass because `assert.throws` remains mandatory.

At `tools/quality/staging-regression.cjs:286–293`, unchanged reviewed code rejects nonempty startupFailures before validating missing dependent articles. At `:582–632`, collection catches and retains the actual engine error and closes each launched browser in `finally`; `collectFunctional` joins both groups through `Promise.allSettled` and rejects cleanup failures. The corrected test exercises real collection orchestration and validation with controlled browser helpers. It therefore covers the primary rejection and cleanup integration, not merely an exception string in isolation. It is not an actual browser process test.

Retained source-run raw evidence has source identity a001da89/tree0053dcac, exit1, signalnull,1198tests,1196pass,2fail,0cancelled/skipped/TODO. One failure is the stale secondary-error pattern with the actual primary controlled error visible. The other is the scanner-control fixture's expected final secrets-engine pass failing because its unchanged offline bundle prerequisite reported `Stale offline bundle`. Original TAP, stderr and JSON remain retained and hashed; the targeted pass is not substituted for the original record.

## ZIP prerequisite diagnosis

Additional primary receipt `/workspace/scratch/b15f3a872203/reconcile-review/media-zip-relocation.json` independently matches SHA-256 `13133fa49bd4c8fa9eb958e97675ee5f0b1aa51d2283fd894885cecf22248326`.

I read the unchanged `tools/build_site_bundle.py:9–11,74–90`: its optional binary output is a shared sibling-parent `deliverables/site-v1-20261004-v11.zip`; `--check` always reconstructs and compares the committed manifest and also compares the optional ZIP if present. Thus absence of the optional binary does not suppress the source reconstruction or committed manifest/digest validation.

Independently read and hashed the preserved ZIP and the two exact supplied manifests, then compared the manifests with `git show` at their source commits:

| Evidence | Observed value |
| --- | --- |
| Preserved ZIP bytes | 6,515,810 |
| Preserved ZIP SHA-256 | `22b4adf7a2c694438912aba7388700a2965114f2a1d2c32a39ee4fb9de053a3c` |
| Publication ec35807 manifest SHA-256 | `36872cd19f47832a33960e8a33c54659f9006de5c7972517735a8c056a1bacf2` |
| Publication manifest expected ZIP | `22b4adf7a2c694438912aba7388700a2965114f2a1d2c32a39ee4fb9de053a3c` |
| Controller6833004 manifest SHA-256 | `d173888735df813a57dcbcc6b59d818a0129ae0b6b125a4d38cb5359d1306269` |
| Controller manifest expected ZIP | `6e9c1a80f44daa5aff5a197a750df692f5cedfa31ca31cbb8c561fb98d615473` |
| Original shared default ZIP path | Absent now |

These observations establish that the preserved binary matches the publication manifest and differs from the controller expectation, consistent with the shared-output collision. I did not observe the historical rename operation directly. The receipt records it; preserved bytes and current absence were observed directly. No optional ZIP, compiler, checksum, or manifest was modified by this reviewer.

The scanner-control test and scanner implementation are byte-identical to the previous candidate. The test still asserts overall failure, continued later engines, false failed engine states, actual command accounting, retained reports/redaction, and no execution with invalid artifact identity. Its controlled engine results do not establish a real scanner/security clean bill. Its source-bound bundle prerequisite now completes in the current corrected environment.

## Bounded check design and route

| Risk / AC | Scenario and protected oracle | Check and existing route | Result |
| --- | --- | --- | --- |
| Lost primary refusal or unjoined cleanup / AC05,09,10 | Selected article collection throws controlled primary error; both engines close; no selection skips article call; normal selected collection retains five observations | Existing corrected `tests/article-browser-evidence.test.cjs` case; permanent pr-targeted/staging/production source registry | Pass |
| Secondary diagnostic masks real collection failure / AC05 | PIL startup failure refuses with primary diagnostic; clearing that failure still refuses missing selected article evidence | Existing `tests/staging-regression.test.cjs` primary-error case; permanent pr-targeted/staging/production source registry | Pass |
| Prerequisite/engine failure is hidden by fixture cleanup / AC05,11 | Controlled early engine/feed failures retain failed aggregate and later independent results; invalid identity runs no engines; unchanged bundle prerequisite checks current source | Existing `tests/quality-sources.test.cjs` scanner-control case; permanent pr-targeted/staging/production source registry | Pass |

All three registered suites survive through `node tools/quality/source-tests.cjs --profile production` under `guides/SITE-CHECK-PROFILES.md`. This continuation selected three cases instead of repeating the prior unchanged four-case media campaign. No requirement/oracle relaxation beyond the corrected diagnostic expectation was found.

## Actual execution receipt

Cwd repository above; pinned Node executable `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node` (v24.19.0 verified in first review; same path reused).

```sh
/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node --test --test-name-pattern='^(the staging collector exercises articles only on its admitted Chromium and joins failures and cleanup|functional collection failures remain visible before secondary missing article evidence|actual scanner category control flow keeps later engines and reports failed prerequisites honestly)$' tests/article-browser-evidence.test.cjs tests/staging-regression.test.cjs tests/quality-sources.test.cjs
```

Raw completed output, session16303, exit0, no signal reported:

```text
✔ the staging collector exercises articles only on its admitted Chromium and joins failures and cleanup (37.207364ms)
✔ actual scanner category control flow keeps later engines and reports failed prerequisites honestly (3421.524616ms)
✔ functional collection failures remain visible before secondary missing article evidence (30.02473ms)
ℹ tests 3
ℹ suites 0
ℹ pass 3
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 3541.294082
```

Three selected top-level cases, below four-case/ten-minute bounds; no unchanged failed full campaign rerun. No measured branch coverage or coverage percentage claimed.

## Reused evidence, findings and remaining gaps

I independently compared old commit bytes with current files and found unchanged: staging and analytics implementation, action and workflow, web-media producer and canonical requirements, bundle compiler and committed manifest, scanner implementation and scanner-control test, and prior analytics/staging/quality test owners. The prior direct real-Pillow/empty-venv/missing-pin tests, workflow failure/export/path checks, and closure check remain applicable to those unchanged bytes as historical bounded evidence. The newly changed collector expectation is independently reexecuted here. Prior claims of absence of these new full-source observations are superseded by this report's retained failure accounting.

No blocking correction defect found. Severity/findings: none in inspected delta. The source-bound ZIP diagnosis and revised expected primary error explain the two retained failures without weakening refusal, source reconstruction, browser cases or budgets. AC05/11 receive this bounded correction review; they remain open pending the remaining current-source/native/hosted/maintainer obligations. AC09/10 receive no new actual reader/PDF observation.

Full current-source1198-case execution, actual scanner engines, Windows/macOS setup/runtime, clean dependency installation, current-head hosted staging/reader/PDF, and maintainer reviewed_sha are not supplied by this three-case campaign. The orchestrator must finish the existing applicable checks and gates before advancement. This result grants no merge, stable alias promotion, production or issue closure.
