# Exploratory / operator QA — correction continuation v2

Verdict: **PASS for the affected bounded operator correction; no candidate findings.** This is a continuation of my own first review, not a newly fresh-context execution. The original report is preserved byte-for-byte at `media-final-exploratory.md`, SHA256 `f8df72998d932843653601c50cd502c884aaba3988b1a8d1d7b359db5c4be72a`. No peer verdict, author private history, recursive delegation, accepted source/test edit or external-service write was used.

## Exact source and review boundary

- Role/execution: Exploratory / Interaction QA, `/root/media_final_exploratory`, correction phase. First-phase independence and provider-observation limits remain as recorded; requested launch parameters and accepted tool response belong to the orchestrator receipt. Provider internals remain unknown.
- Repository `/workspace/scratch/b15f3a872203/controller-media`; previous candidate `a001da89397f17668e8b3627f9f9cb42608ccdb3`; corrected clean candidate `6833004eea60e805bf3415436cdb050d08a5b622`, tree `f2481a12b945fafa94b046f6c1fafe52e104c17d`; protected base `312fbe4347eda332aa8ade885b07c98beadd6da5`.
- Packet `media-controller-v2-packet.json`, verified SHA256 `3d84369a21b66c18a1e3ce9ec4eb4a812a107895da048d98716babee4350eca6`; full packet diff SHA256 `471b1bd68c5df0cb5750f792dce32ceba30877abddfa064920c7b53d6bf5a45f`. All packet source and raw evidence hashes matched, zero mismatches.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`, unchanged and reused.
- Additional neutral primary input: relocation receipt `media-zip-relocation.json`, SHA256 `13133fa49bd4c8fa9eb958e97675ee5f0b1aa51d2283fd894885cecf22248326`. Its named files were independently inspected below.
- Publication source remained clean `ec35807bec4a233cf7e80eb39f455c1f6b19434a` before/after. The authorized stable staging then STOP endpoint, whole AC states and publication/production boundaries remain unchanged.

The actual three-file delta comprises one test regex change, a dated review addition and generated RI identities. `tests/article-browser-evidence.test.cjs:1019` now expects `controlled article collection failure` rather than `require actual browser`. The collector test already injects exactly that error, verifies its startupFailures content, and checks Chromium/Firefox cleanup. No action, media pin, copied-fixture implementation, functional validator, budget, scanner/compiler or bundle manifest changed in this correction.

I compared actual current bytes against the previous reviewed commit for the composite action, site-release workflow, analytics-browser fixture, staging-regression validator, web-media owner, requirements pin, article-media and article-materials owners: all identical. Thus first review's Linux setup/body, interpreter path with spaces, real-R10 fixture/fresh-process build, PDF byte parity and media dependency refusal/recovery evidence is reused only for those unchanged surfaces; no new execution of those unchanged producer campaigns is claimed.

## Charter and actual operator rewalk

Charter fixed before checks: rewalk the collector's corrected failure expectation and cleanup, independently retain primary/secondary diagnostic behavior, check scanner failure reporting against unchanged bundle prerequisites, and verify the optional ZIP disposition with exact bytes. Bound: maximum four cases/ten minutes; four cases executed, completed by 2026-11-07 00:41:02Z. Pinned Node v24.19.0 remained `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node`. No unchanged failed full campaign was rerun.

| Case | Expected | Actual action and observation | State |
| --- | --- | --- | --- |
| 1. Collector failure, no-article and success journeys | A controlled original collection error is visible, success retains article observations, absent article selection does not collect articles, all admitted browsers close. | Ran current actual named test `the staging collector exercises articles only on its admitted Chromium and joins failures and cleanup` with pinned Node. Source inspection confirms its three states (articles success/failure and no articles), controlled helper boundary and cleanup assertions. Test passed, 25.818935ms. This is a collector/process test, not actual browser operation. | Executed/pass |
| 2. Operator diagnostic progression | Corrected regex must not make secondary article evidence disappear; real original media failure still appears first. | Directly passed packet failed report's actual PIL startupFailures into current `validateFunctional` with selected-article manifest. Observed expected PIL error. Then cleared startupFailures and observed `selected articles require actual browser evidence`. | Executed/pass |
| 3. Scanner prerequisites and aggregate failure reporting | Failed first scanner does not suppress later engines or permit false category success. Canonical controller bundle must reconstruct its committed manifest. | Ran actual unchanged named scanner control-flow test alongside case1; pass, 3518.7271ms. Read retained failure and actual scanner test source. Independently invoked bundle owner's pure `build()` and compared generated manifest bytes with committed manifest: equal; payload SHA256 `6e9c1a80f44daa5aff5a197a750df692f5cedfa31ca31cbb8c561fb98d615473`. Compiler, manifest, scanner and scanner test bytes all match prior reviewed commit. | Executed/pass |
| 4. Optional shared ZIP disposition | Displaced task artifact is preserved under its own publication identity while the controller optional output cannot confuse the controller prerequisite. | Receipt's old shared ZIP path is absent. Preserved ZIP exists, 6515810bytes, SHA256 `22b4adf7a2c694438912aba7388700a2965114f2a1d2c32a39ee4fb9de053a3c`. Publication manifest hash/ZIP binding match receipt; controller manifest has the distinct expected controller ZIP digest above. | Executed/pass for current state and exact bytes; the historical rename itself is receipt evidence, not an operation I witnessed. |

The actual command for cases1/3 was:

```sh
/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node --test --test-name-pattern='the staging collector exercises articles only on its admitted Chromium and joins failures and cleanup|actual scanner category control flow keeps later engines and reports failed prerequisites honestly' tests/article-browser-evidence.test.cjs tests/quality-sources.test.cjs
```

Raw observations from this continuation (execution chunks `f0ef2c`, `852417`, `219329`, `c2dead`, `25f300`, `60db59`):

```text
✔ the staging collector exercises articles only on its admitted Chromium and joins failures and cleanup (25.818935ms)
✔ actual scanner category control flow keeps later engines and reports failed prerequisites honestly (3518.7271ms)
tests 2; pass 2; fail 0; cancelled 0; skipped 0; todo 0
duration_ms 3645.657684
V2_PRIMARY_PIL_RETAINED
V2_DOWNSTREAM_ARTICLE_GATE_RETAINED
BUNDLE_RECONSTRUCTED_MANIFEST_MATCH True
BUNDLE_RECONSTRUCTED_SHA256 6e9c1a80f44daa5aff5a197a750df692f5cedfa31ca31cbb8c561fb98d615473
OPTIONAL_SHARED_ZIP_EXISTS False
PRESERVED_ZIP_BYTES 6515810
PRESERVED_ZIP_SHA256 22b4adf7a2c694438912aba7388700a2965114f2a1d2c32a39ee4fb9de053a3c
PUBLICATION_MANIFEST_SHA256 36872cd19f47832a33960e8a33c54659f9006de5c7972517735a8c056a1bacf2
PUBLICATION_MANIFEST_ZIP 22b4adf7a2c694438912aba7388700a2965114f2a1d2c32a39ee4fb9de053a3c
CONTROLLER_MANIFEST_SHA256 d173888735df813a57dcbcc6b59d818a0129ae0b6b125a4d38cb5359d1306269
CONTROLLER_MANIFEST_ZIP 6e9c1a80f44daa5aff5a197a750df692f5cedfa31ca31cbb8c561fb98d615473
RAW_MISMATCHES []
MISMATCHES []
CANDIDATE_CLEAN True
PUBLICATION_CLEAN True
```

## Failure preservation, diagnosis and disposition

I inspected retained full-source TAP rather than treating the correction summary as an oracle. That campaign remains **failed**, exact prior clean source a001da89:1198 tests,1196pass,2fail,0skipped/cancelled. The collector refusal failed because the old regex demanded a secondary missing-evidence message while the validator actually exposed the injected original `controlled article collection failure`. The v2 test now expects the original error, consistent with the already reviewed diagnostic invariant, and leaves cleanup/success assertions intact.

The other retained failure was the scanner control test's secrets prerequisite: actual error `python tools/build_site_bundle.py --check` / `Stale offline bundle`. Canonical bundle owner checks committed manifest bytes and, **if present**, the sibling optional ZIP. Current reconstructed controller payload matches its unchanged committed manifest; the preserved ZIP matches the publication manifest's different digest. This supports the documented shared-output collision diagnosis without relaxing the check. The original failure stays preserved. Current targeted two-test result is diagnostic correction evidence, not a replacement full1198-test pass.

Case4 receipt names preserved artifact `/workspace/scratch/b15f3a872203/reconcile-review/publication-site-v1-20261004-v11.zip`, former shared output `/workspace/scratch/b15f3a872203/deliverables/site-v1-20261004-v11.zip`, and the two repositories' exact committed manifest paths. I inspected only those supplied paths. I did not move or alter artifacts.

## AC impact, allocation and limits

No unresolved operator defect was found in the v2 delta. Case1 maps to existing `tests/article-browser-evidence.test.cjs`; cases2/3 retain existing `tests/staging-regression.test.cjs` and `tests/quality-sources.test.cjs` ownership. Registry inspection confirms all three use pr-targeted/staging/production profiles and surviving route `node tools/quality/source-tests.cjs --profile production` under `guides/SITE-CHECK-PROFILES.md`; no new suite, duplicate campaign or permanent test is proposed. Case4 is local diagnostic artifact provenance, not a hosted release requirement. No accepted source/tests were authored by this reviewer.

The results support AC05/09/10/11 preparation and correction evidence only. Current full-source acceptance, native Actions, all other required source/security/RI checks, the four-role reconciliation, exact-candidate maintainer/controller gate and real stable R10 article/PDF browser inspection remain separate. Product UI/visual/accessibility behavior did not change, so new product UI journeys are reasoned not applicable to this delta. Native/hosted surfaces are not observed, not N/A. This continuation does not authorize PR170 merge, production or closing whole criteria. Complete the existing stable-staging route and STOP/show.
