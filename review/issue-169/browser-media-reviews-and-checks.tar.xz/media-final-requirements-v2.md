# Requirements & Acceptance correction review — v2

**Verdict: no blocking requirements or acceptance-linkage defect in this correction.** The narrow changed oracle and failure diagnosis preserve the prior accepted review invariants. This permits continuation to the required current-source checks and remaining review gates; it does not establish full source acceptance, staging acceptance, maintainer trust, merge or publication.

## Identity, chronology and limits

- Role/task: `/root/media_final_requirements`, nonauthor Requirements & Acceptance reviewer, correction phase. This is the same role continuation, not a newly fresh first review. No peer verdicts or parent private history were inspected.
- Prior first judgment remains intact at `/workspace/scratch/b15f3a872203/reconcile-review/media-final-requirements.md`, SHA256 `aef43e86e7c86df5d209e4d70c9c3e553576466bf64a4f73c6cd153e648d202c`.
- Previous candidate `a001da89397f17668e8b3627f9f9cb42608ccdb3`; current candidate `6833004eea60e805bf3415436cdb050d08a5b622`, tree `f2481a12b945fafa94b046f6c1fafe52e104c17d`; protected comparison base remains `312fbe4347eda332aa8ade885b07c98beadd6da5`.
- V2 packet SHA256 `3d84369a21b66c18a1e3ce9ec4eb4a812a107895da048d98716babee4350eca6`; all listed source/raw hashes matched. Actual complete base-to-current diff and supplied diff both hash to `471b1bd68c5df0cb5750f792dce32ceba30877abddfa064920c7b53d6bf5a45f`.
- Common/role prompt bytes remain unchanged from the first report. Provider internals remain unknown; launch-parameter acceptance belongs to the orchestrator receipt.
- Additional neutral primary evidence requested and received during correction: `/workspace/scratch/b15f3a872203/reconcile-review/media-zip-relocation.json`, SHA256 `13133fa49bd4c8fa9eb958e97675ee5f0b1aa51d2283fd894885cecf22248326`, and its exact referenced ZIP/manifests. This is disclosed correction evidence, not peer reconciliation.
- Local Git source was clean at inspection and after targeted execution. No source/test changes, external writes or delegation were performed. Live GitHub/native CI and hosted readers were not observed.

## Actual delta and requirements judgment

Only three tracked files differ from the prior reviewed candidate: `tests/article-browser-evidence.test.cjs`, the existing controller review report and generated RI source identity. The sole executable/test change is the assertion at `tests/article-browser-evidence.test.cjs:1019`: the collector-failure scenario now requires `controlled article collection failure` rather than the secondary `require actual browser` message. The surrounding controlled error injection, exact startup-failure inventory, both-engine cleanup, admitted-Chromium-only article call, article/no-article branches and success article-observation checks are unchanged.

This correction matches the already reviewed requirement to retain and surface the primary collection failure. It preserves a refusal and strengthens the expected diagnostic specificity; it does not remove the article-evidence requirement or authorize incomplete reports. The retained source TAP independently shows the old regex mismatched an assertion containing the original controlled collection error at `staging-regression.cjs:288`. No material intent/AC/oracle relaxation was introduced.

The second retained source failure is `actual scanner category control flow keeps later engines and reports failed prerequisites honestly`, at `tests/quality-sources.test.cjs:1981`. Raw output shows the secrets engine failed its real `python tools/build_site_bundle.py --check` prerequisite as a stale bundle, rather than the intended later-engine success. The scanner fixture and scanner implementation are unchanged. Actual compiler inspection confirms `OUTPUT = ROOT.parent / "deliverables/site-v1-20261004-v11.zip"`; `--check` reconstructs the ZIP and always verifies the committed manifest, while also comparing optional ZIP bytes if that output exists. Sibling checkout roots therefore share that optional destination.

I hashed the actual preserved 6,515,810-byte ZIP: `22b4adf7a2c694438912aba7388700a2965114f2a1d2c32a39ee4fb9de053a3c`. It matches the supplied publication manifest (`36872cd19f47832a33960e8a33c54659f9006de5c7972517735a8c056a1bacf2`) and differs from the controller manifest's expected ZIP `6e9c1a80f44daa5aff5a197a750df692f5cedfa31ca31cbb8c561fb98d615473`. The old shared optional destination is absent; the preserved file remains available at `/workspace/scratch/b15f3a872203/reconcile-review/publication-site-v1-20261004-v11.zip`. These observations support the report's sibling-artifact diagnosis and preservation statement. The historical rename operation itself is evidenced by the supplied receipt rather than a reviewer-observed action.

`tools/build_site_bundle.py`, controller committed bundle manifest, `tools/quality/scanners.cjs`, scanner-control test, media action/producer/fixture implementation and SITE-STAGING trust contract are byte-identical to the prior candidate. No `site/` or `docs/` delta exists against protected base. The corrected environment removes a foreign optional generated artifact; it does not remove the compiler's committed-manifest or reconstructed-digest checks. Concurrent sibling exports could recreate this pre-existing environmental interference, so subsequent full acceptance must continue to record the actual isolated environment and source identity.

The appended review section honestly retains the original clean a001da8 source result:1198cases,1196pass,2fail, no skip/cancel/TODO. It states the correction and requires affected checks followed by full current-source acceptance. It does not claim that the later targeted2/2 replaces the failed full campaign. Original raw JSON/TAP/stderr remain present and their packet hashes match.

**Findings:** no blocking defects. Examined risks were changing an oracle solely to hide failed collection; weakened article/cleanup coverage; silently bypassing a stale bundle; changed compiler/scanner/manifest; erased original failure; fabricated source identity; and overstated current-source or hosted acceptance.

## Acceptance trace and actual checks

| Requirement / AC | Evidence or gate | Correction outcome |
| --- | --- | --- |
| Preserve primary failure and article refusal; AC05/09/10 | Actual changed collector test and prior diagnostic-priority invariant | Refusal still required; expected error now names the original controlled cause. Independent targeted collector test passed on6833004. |
| Preserve scanner and generated-artifact integrity; AC05/11, CS01/04/08 | Unchanged scanner/compiler/manifest plus preserved foreign ZIP comparison | Actual ZIP hashes confirm publication origin and controller mismatch; actual scanner-control test passed with original shared optional output absent. |
| Retain failures and diagnose before retry; AC05/11 | Original full-source JSON/TAP/stderr and appended review section | Original1196/1198 failed result remains retained; correction is source/environment specific. No full current-source pass is claimed. |
| Source-bound reviews/style/checks; AC05/11 | Current relevant checks and all mandatory independent roles | This role's correction review is complete. Other roles/full current-source/Basic/RI/scanner/native gates remain outside this observation and must be completed. |
| Controller trust | SITE-STAGING.md:182,191–198, unchanged | Maintainer complete-diff review and full-current-head `reviewed_sha` remain required. No new attestation supplied; old PR173 acceptance cannot accept6833004 or any later final head. |
| Stable R10 endpoint and publication boundaries; AC09/10 | Protected controller integration, refreshed PR170, actual full current owner staging and stable reader/PDF inspection | Pending. Preserve STOP/show after verified stable staging. PR170 merge/production remain out of scope; whole issue ACs remain open except historicalAC06. |

Four bounded correction cases were used: (1) packet/actual delta/failure-accounting inspection; (2) collector oracle and cleanup execution; (3) scanner-control execution; (4) actual preserved-ZIP/source-manifest and unchanged compiler/trust verification. Execution used pinned Node24.19.0:

```sh
/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node --test --test-name-pattern='^(the staging collector exercises articles only on its admitted Chromium and joins failures and cleanup|actual scanner category control flow keeps later engines and reports failed prerequisites honestly)$' tests/article-browser-evidence.test.cjs tests/quality-sources.test.cjs
```

Observed exit0, tests2/pass2/fail0/cancelled0/skipped0/TODO0, duration3508.821883ms. The supplied targeted receipt separately records2/2; my execution is the independent bounded observation above. No full campaign was rerun by this reviewer.

## Evidence reuse and next gate

Reuse the first report's unchanged dependency setup, source-closure, error-order, scope and trust analysis because actual byte comparison confirms unchanged implementation and policy. Rechecked the changed consumer oracle, full-source failure disposition, environmental artifact provenance and amended documentation. No new authorization or material requirements revision is needed for this correction. Complete current-source required checks and affected independent correction reviews, retain the original failed run, and then obtain the existing maintainer decision for the actual final controller head before protected integration. This review supplies none of those external decisions or native outcomes.
