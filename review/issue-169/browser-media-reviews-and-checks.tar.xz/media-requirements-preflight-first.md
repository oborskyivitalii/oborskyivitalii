# Requirements & Acceptance — first preflight

Date: 2026-11-07. Role/task: independent nonauthor Requirements & Acceptance, `/root/media_requirements_preflight`, first judgment. No implementation, source/test edits, external writes or delegation. Four bounded read-only cases below; under the ten-minute limit.

## Verdict and identity

**Requirements are sufficient for bounded corrective preparation and implementation under issue169; current staging acceptance and protected-controller integration remain blocked.** Restore the declared media dependency closure in the existing fixture/controller owners, preserve coverage and budgets, review the concrete candidate, and obtain a new exact-head maintainer control attestation before protected integration. Prior acceptance of PR173 `d06640cb53ca09f47b132c1a0bbea0b1b1cc22c9` does not attest a new workflow candidate. Do not merge PR170 or activate production.

Packet: `/workspace/scratch/b15f3a872203/reconcile-review/media-controller-preflight.json`, SHA-256 `3e924453d2f4c6b7fb50c07883d1057d5e148e897acf657786f7bf8a622ed66e`. All 24 supplied source/raw file hashes matched when inspected. Checkout clean at controller base `312fbe4347eda332aa8ade885b07c98beadd6da5`, tree `ebe45c3549ae4af19d373820ef195d5d8ea03dbd`, branch `work/issue-169-browser-media-controller`; no candidate diff yet. Publication source is separately bound by packet/raw reports to PR170 `ec35807bec4a233cf7e80eb39f455c1f6b19434a`, tree `e2c1ae7b8ed6dd41f3580d292d6e0c8ad89cbcf6`.

Common contract hash: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt hash: `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. Read root README/AGENTS/CONTRIBUTING/MEMORY, relevant repository-map owners, staging/check-profile/style/acceptance contracts, issue169 source and scope, workflow, analytics/staging/functional/media owners and relevant tests. Root AGENTS is the only AGENTS found. MEMORY is dated and stale relative to the packet/main; it supplied no live acceptance.

Launch assurance: task records actual requested `fork_turns="none"`; this execution did not inspect author/peer private notes or current peer results. Parent tool response and accepted launch parameters must be preserved by the orchestrator. Provider model/context/memory internals are unknown; no stronger provider isolation attestation is claimed. GitHub live state and artifact download provenance were supplied as dated packet facts; I verified local bytes, not remote state/settings or the artifact zip independently.

## Four inspected cases and findings

### 1. Intent, scope and immutable preservation — pass for preparation

Original owner remains169 and publication owner170. Latest supplied scope narrows the endpoint to verified stable staging then STOP/show, preserving accepted R10 manuscript/PDF/diagrams, site-first distribution and discovery semantics. AC05/09/10/11 are the affected acceptance links; historical AC06 remains separate. A controller dependency does not replace the publication owner or close whole issue acceptance. No material scope ambiguity requires delaying reversible preparation.

Minimal repair surface is the existing workflow's affected browser job dependency setup and the analytics fixture's finite declared dependency inventory, with meaningful dependency/wiring regressions and required source-bound review/RI evidence. Do not change article/media codec behavior, canonical dependency versions, runtime/site/docs, case selectors, assertion outcomes, timeouts, budgets, scanner controls, permissions or admission logic merely to get green. Any necessary expansion must be justified by observed dependency use and returned to affected review. CS01/04/05/07/08/09/10 remain applicable; style evidence belongs in the existing AC05 mapping.

### 2. Failure diagnosis and fixture closure — blocking implementation defect, not an AC waiver

**F1 — High: mandatory fixture media environment is absent in the observed staging job.** Evidence: workflow `.github/workflows/site-release-checks.yml:578–616` installs Node/browser tools but no declared media Python environment. Raw `stage-functional.json` has `pass:false`, zero analytics rows, one Chromium startup failure `Lossless article media preparation failed: No module named 'PIL'`, then final error `selected articles require actual browser evidence`. The collector calls analytics before article observations (`tools/quality/staging-regression.cjs:612–620`), so the final missing-article message is downstream evidence incompleteness, not evidence of an article rendering defect. Treatment: supply the required declared media environment in the actual browser job, then verify preparation plus complete analytics/article observations; do not suppress either check.

The independent media contract is explicit: `tools/site/article-media.cjs:10–36` selects `SITE_MEDIA_PYTHON`, existing venv, or `python3`; `tools/publishing/web-media.py:17–36` reads the canonical pin and requires exact Pillow and WebP versions. Canonical requirements line52 is `pillow==13.0.0`, codec contract `1.6.0`. Installing arbitrary/latest Pillow or adopting capture tooling's separate12.3.0 pin cannot satisfy this oracle.

**F2 — Medium: finite copied fixture dependencies need explicit closure verification.** `analytics-browser.cjs:421–470` copies the site/publishing/offline owners but omits `tools/quality/toolchain/requirements.txt`; the copied media script declares that exact input. `tests/analytics.test.cjs:436` currently forbids the entire quality-toolchain directory. Treatment: verify each execution path through the copied fixture; include the canonical requirements bytes if consumed there and update the assertion to allow that declared data file while still excluding installed dependency trees/venv. Do not copy the whole environment or weaken isolated fixture behavior. This is a source-derived closure risk; the failed native report stops at missing PIL and does not itself prove the later pin-read outcome.

Raw first failure remains retained. Prepublication has26 passing guard rows and `fullGate:false`, `productionEligible:false`, `deploymentAuthorized:false`. Stage performance passes with two Lighthouse rows, two route samples and four flights. These observations neither fill the zero analytics rows nor establish staging success. No unchanged full campaign was rerun here.

### 3. Staging and production consumer closure — required affected-scope audit

**F3 — High: a staging-only dependency repair leaves production functional consumers exposed.** Workflow Linux production (`:378–424`) and native Windows/macOS (`:431–481`) call `functional.cjs`; `functional.cjs:839–847` calls the same analytics collector even for Windows smoke. Those jobs currently install Node/browser dependencies without media Python setup. Requirements must cover canonical dependency setup and interpreter reachability in staging, Linux production, Windows smoke and macOS WebKit, preserving their respective existing selectors/conditions and matrices.

Do not turn this audit into unauthorized production publication or require every optional full diagnostic as a new publication prerequisite. `SITE-CHECK-PROFILES.md:295–307` says full production regression is optional/nonblocking, with its failures/skips retained. Validate changed wiring and applicable native/runtime evidence honestly; a local fixture does not prove hosted or native success. Build/static already have maintained Python setup for their existing distinct roles. Performance and captures are not proved to call analytics here; capture's existing Pillow12.3.0 installation serves another owner and is not justification to alter it without demonstrated use.

Preserve staging's exact contract (`SITE-CHECK-PROFILES.md:244–263`): 4 normal +2 no-Canvas journeys,2 navigation rows,10 capability failures,7 analytics rows, applicable article/Color observations,2 Lighthouse trials,2 route samples and4 flights. Preserve production engine/native/full/smoke coverage. The15-minute operational target does not permit changing hard limits or product budgets.

### 4. Protected-main authority and final acceptance — blocked until new gate

**F4 — Blocking external decision at integration: no new exact-head maintainer control attestation exists.** `guides/SITE-STAGING.md:175–197` requires the full route and explicit complete-diff review with `reviewed_sha` equal to the full current head for executable tools/tests/workflows; missing/wrong/old SHA refuses. It explicitly says review a new head again rather than copying an old attestation. The supplied acceptance is only PR173 d06640cb, already merged312fbe4. It cannot authorize the next candidate's exact trust decision.

Prepare a concrete, reviewable correction and complete its applicable checks/four independent roles before requesting the exact-head decision. The existing candidate evidence route supports inspecting changed staging implementation before main (`SITE-STAGING.md:364–366,485–486`); ordinary `/stage` still runs protected main. Do not treat a publication-branch workflow edit as an installed controller repair. Follow protected admission and normal integration, then refresh PR170 against current main and execute its full existing owner staging route. Maintain current head/base/run/attempt/artifact/alias leases.

## Traceability matrix

| Intent / criterion | Check or decision oracle | Observed result / next evidence |
| --- | --- | --- |
| AC05, AC11 — source-bound requirements/review/hygiene | Packet hashes, actual current-source checks and four distinct completed roles; CS mapping, RI/CI, owning policy | Hashes match; this is preflight only; candidate and final roles/checks pending |
| AC05, AC09, AC10 — functioning fixture and exact article/PDF/media observations | Canonical media versions + full existing staging functional report and artifact/source identity | Missing PIL; analytics0/7 and article evidence absent; repair and exact candidate observations pending |
| Preserve coverage/budgets and failed evidence | Original staging/production profile selectors, refusal cases and raw accounting | First native failure retained; separate stage-performance pass cannot admit staging |
| Trusted-main workflow installation | Complete concrete diff, new full-head reviewed_sha, applicable protected admission and normal merge | Prior d066 acceptance only; new attestation/integration pending |
| Verified stable staging then STOP | Successful exact PR170 owner stage; promotion and served alias/article/PDF byte inspection | Failed current run42314101070/attempt1; verified stable staging not established |
| Original whole issue acceptance / release boundary | All original AC conditions and author/live gates | Keep issue open; no PR170 merge or production; no new whole AC pass |

## Next gate and limits

No unresolved owner choice blocks bounded implementation preparation. Resolve F1/F2/F3 in the authorized minimal owners, preserve the original failure, then review the exact candidate and run applicable source/wiring/native evidence. Before protected controller integration, request the new exact-head maintainer decision required by F4. PR170's verified stable staging and explicit stop are the authorized endpoint. This report is neither final candidate acceptance nor production authorization.
