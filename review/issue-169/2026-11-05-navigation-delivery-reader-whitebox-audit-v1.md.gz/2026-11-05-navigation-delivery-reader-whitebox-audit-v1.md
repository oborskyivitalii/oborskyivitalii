# Navigation, delivery routes and reader foundation — White-box audit v1

2026-11-05 UTC; issue169 / PR170. Independent initial inventory for the requested pre-production audit. Same-role continuation, not a newly isolated reviewer. No peer conclusions read; no source/test edits, builds, browser launches or campaigns run. Only this report is written. Git refs are locally observed; GitHub live checks/state were not refreshed by this bounded read-only task.

**Result: updates required before advancing current runtime evidence.** Existing coverage is substantial; the audit found a concrete completion-oracle hole, stale current-family references, and selective dependency omissions. This is not a reader-completeness or release pass.

## 1. Exact scope

Clean initial HEAD `d3a49960714e5f158afba23d02dd0f8e871cb28e`, tree `64b5bf1c039b82abe3de0ae726c726e41aeaf0a9`; local `origin/main` `8cf15883125892710633b17133d9ee0fc4b23b92`. End readback keeps the same HEAD and application/test bytes; only other reviewers' new report paths were visible, not read. The PR diff has 499 paths, including native R9 source/media, generated/retained output, runtime, producer, delivery, CI and historical evidence. No site template itself changed against this base, but the generic article/template and reader contracts are affected consumers.

Read applicable root/common/White-box instructions, README, map entries, MEMORY (dated, stale relative to this HEAD), source/check/release owners, registry, relevant workflow routes, source/tests and fixture declarations. Historical source packet remains an intent reference, not current-source evidence.

| Key source | SHA-256 |
| --- | --- |
| `site/engine/navigation.js` | `bab45afc73a36333f4b4ee3e81a7fc4fa19762f50d92dd5b82dad345fb82011b` |
| `site/engine/archive.js` | `0c1300428b3088c1fb4f6ba86461f228efabd3175100c7c1219df13631a1ccd3` |
| `site/engine/scroll-entry.cjs` | `c3a51a1148da710c2fd0add270cb8615bac6a5dd71a3430db5c6e5f32b83252e` |
| `tools/quality/article-browser.cjs` | `b52c67fca8ce592531d1574b5886b95d2dd95f614b460bcecf460c229f36b05c` |
| `tests/article-browser-evidence.test.cjs` | `8fc6a66ff761cf611511c75a5c8027d1fe4b4c03c86040f6588944ea1a8e0b06` |
| `tests/color-motion-contract.test.cjs` | `f8de24044530c67caf18bdde398e9e80e1280acbe238a0e03fc5b793ececdd9f` |
| `tools/quality/test-profiles.json` | `55b420167dc3b669f28c94e4a683d305c05fc994e6124dc1ed1eb9003ad546d5` |
| `.github/workflows/site-checks.yml` | `d558533020175d569ab112520320bd55728cdbd2eac6c9fec0dd8080e0537250` |

## 2. Inventory and disposition

Registry validation/selection were executed read-only, not test execution: 127 registered modules = 98 JavaScript + 29 Python. JavaScript has 78 permanent, 18 diagnostic and 2 task snapshots. Across both languages: 88 permanent, 18 diagnostic and 21 task snapshots. Current whole-PR selection is platform, 81 selected JavaScript modules plus the three Basic modules (`theme`, `archive`, `flight`). This includes all 78 permanent JavaScript modules plus affected diagnostics. Staging selects 75 plus the three real Basic modules; production source profile selects all 78. Python remains a separate runner/ownership route.

216 paths trigger conservative unknown-source selection, predominantly historical compressed evidence; this is conservative extra work, not dropped coverage. Do not weaken the classifier just to accelerate this mixed platform PR. The complete registry is accounted for; source reading does not measure branch coverage.

| Surface / actual changed owners | Maintained contract and delivery route | Disposition |
| --- | --- | --- |
| Native reader/compiler/template/materials: `tools/site/articles`, producer, R9 publication/media | `site-articles`, `reader-mode`, publishing/profile/safety/history, article-media/materials/budgets/candidate-source; source content/staging/production profiles; browser `articleJourney` | Retain. Covers AST/source preservation, contents/references, image/citation dialogs and native fallback, print/disclosure/history cleanup, deferred media, canonical/language metadata, cold output and private isolation. Recheck current edition/runtime through actual gates. |
| Writing/archive/tags: archive, navigation, article-tags | `archive`, `article-tags`, local catalog/content tests; hosted publication-tag journey; article filtered activation/Back/Forward | Retain new foreign-owner/ink preservation test and all same-Writing query/hash/reset/print/no-JS cases. Extend actual shared-owner boundary fixture below. |
| Native routing/history/cancellation: navigation, flight, scroll-entry | `navigation`, `site-articles`, `scroll-entry`, flight/fixture tests; hosted article and principal journeys | Retain endpoint, focus/scroll capture before inert, retarget/abort, native snapshot rebasing, both directions, block Off, stationary reading and direct-entry history. Completion oracle needs correction. |
| Aliases, immutable snapshots/runtime/media, no-JS/offline | `edition-retention`, `content-release`, `site-articles`, `article-delivery`, `article-offline`, reader fallback cases | Retain transitive closure/cycle/missing-edge/byte/bound/collision/staging isolation negatives. No-JS principal tests and native links are distinct from JS success. Full browser article fallback inventory is normal1440/390 and Off/noCanvas/noJS390; targeted R9 diagnostic additionally has noJS at both widths. |
| Hosted preview and staging | `local-browser` preview: four principal rows plus conditional five-case representative article journey. `staging-regression`: Chromium/Firefox principal matrix, Chromium article journey; gate/host/package/review-flow tests | Retain source/artifact/origin/edition/rights binding and cleanup refusal. Preview smoke is not staging/full acceptance. Current article descriptor inventory contains R9 as the single representative; generic reference fixtures still cover richer reader features. |
| Production/rollback/rights/archive | release-controller/archive/rights, pages-delivery, staging tests; protected staging-based publisher and live exact-byte/indexing checks | Retain guarded derivation/leases/rollback and mandatory rights. Source profile named production and optional full hosted regression are separate. Full 390/12/39 regression remains optional under the current documented policy, not newly mandatory because of this audit. |
| Content versus platform selection | content-delivery/baseline/release/fixture plus test-profile-selection | Retain economical content only for exact accepted compatible authored changes. Engine/template/tool/workflow/mixed changes use platform. Current PR is platform; old accepted content/runtime evidence cannot cover it. |
| Eight source shards and workflow artifact namespace | test-profile-selection, quality/workflow-artifacts, RI/CI and browser-supply tests | Retain exact eight receipts, complete module/TAP accounting, stderr/process errors, clean before/after, original 300000ms deadline; empty plan is inapplicable/pass:null. No missing matrix slot becomes success. |
| Historical/diagnostic cases | 18 diagnostic modules, 21 task snapshots; frozen reader receipts and exact footer runtime golden; manual R9 40-case observer | Keep explicit separate ownership. Do not rotate old receipts into current browser evidence or promote task snapshots into routine source coverage. Do not delete refused/failed/not-observed evidence. |

## 3. Findings and exact evidence

**F1 — high: current route-block evidence can admit watchdog/cancellation.** `tools/quality/article-browser.cjs:1288` validates frame/unit inventories, direction, identity and 1000ms plan, but `completedBy === animationend` is required only inside reader-paper validation. A Writing departure has no reader paper. A read-only controlled call used `tests/fixtures/article-flight.cjs.currentJourney` with reviewed `issue169-footer-routes-staging`, first validated the intact five-case report, then changed only the Writing-to-reader Forward departure completion. `watchdog`, `cancelled`, `null`, and absent `completedBy` all still returned `{documents:1, observations:5}`. No browser evidence was fabricated; this proves validator acceptance of four invalid synthetic inputs. It overlaps the actual failed299 ownership class. Require actual successful completion for every applicable current block phase, with explicit compatibility treatment for genuinely older report shapes; preserve native frames and original deadlines.

**F2 — high pending current-family migration: fresh producer tests still assert the old footer family.** `tests/color-motion-contract.test.cjs:97` equates a freshly computed runtime version with `issue169-footer-routes-plain`; `:1131` rebuilds current source and asserts all three old footer IDs. Current output-lock client/served base engine is `bc0bc4c430599eb8448a7289d818649f7ebaa534889c8bd289d5d30b545ab943`; the old family base is `72702f750f37e9cc6678b2d1181da57aa8c121293ebf70c9deae4e7aec568237`. Those are different contracts. This was source/identity inspection, not a rerun or claimed test failure. Do not waive these positives or guess a family: obtain actual new diagnostic/three-edition bytes, independently review the new tuple/client hooks, then migrate only fresh-current expectations. Preserve old footer golden and all old-family negatives.

**F3 — medium: isolated changed-owner selection omits actual direct consumers.** All eight pairs below were checked through actual `source-tests.select(root,'pr',{changedPaths:[owner]})`; each omitted the listed test from both selected modules and Basic. The current whole PR is conservatively fully selected, so this is a future focused-selection hole, not evidence that its present campaign dropped these tests.

| Changed owner | Omitted directly consuming test |
| --- | --- |
| `tools/site/html.cjs` | `tests/reader-mode.test.cjs` |
| `tools/site/articles.cjs` | `tests/reader-mode.test.cjs` |
| `tools/quality/color-motion-contract.cjs` | `tests/article-browser-evidence.test.cjs` |
| `tools/site/html.cjs` | `tests/color-motion-contract.test.cjs` |
| `tools/release/edition.cjs` | `tests/pages-delivery.test.cjs` |
| `tools/staging/color.cjs` | `tests/site-engine.test.cjs` |
| `tools/check_site_seo.cjs` | `tests/content-rendering.test.cjs` |
| `tools/site/articles.cjs` | `tests/release-controller.test.cjs` |

Add exact relevant inputs and selector regression assertions. A broad transitive require walk also found numerous indirect dependencies; that is only a search aid, not a finding or justification to allocate every module everywhere. Review direct consumers by their actual assertions first. Existing explicit navigation/archive mutual inputs correctly protect their current shared-owner change.

**F4 — medium: maintained evidence family loop omits issue169.** `tests/article-browser-evidence.test.cjs:301` says every current identity but its family list stops at `issue5-review-markdown`; it omits native-tags and footer-routes, while these inherit mandatory reader behaviors. Add already admitted issue169 families to the existing positive/negative loop; add the new current family only after evidence-based admission. Preserve the separate legacy reports that intentionally lack newer observations. The live collector already performs filtered Writing → article → Back → Forward; do not incorrectly report this sequence absent.

**F5 — narrow sequence realism.** The new archive foreign-history test deliberately stubs the address owner, while `navigation.test.cjs:23` tests actual functions with `articles:{}`. Its principal/snapshot/embedded cases are useful but do not directly assert known article alias/snapshot ownership or initial-article fallback. Extend that existing fixture with one declared article, exact initial Writing snapshot and initial article, unknown/off-origin negatives; keep same-Writing query/hash behavior. A composed before/during-departure preservation counterexample already exists in this role's prior receipt, but that receipt is not a permanent test. Prefer one bounded maintained integration of real owner + archive mutation over a new large matrix.

## 4. Bounded update plan and acceptance

1. Correct F1 in the maintained validator and its existing evidence tests. Keep a valid full report; mutate each applicable departure/arrival across normal and native-history inventories to watchdog/cancelled/missing and require refusal. Keep missing frames, wrong direction/source/navigation ID, reader paper and stationary-reading negatives. Cover actual live owned text layers through the unchanged 40-case diagnostic; never infer them from a busy timeout.
2. Update the eight verified dependency mappings with isolated-owner selector assertions; inspect other direct consumers exposed by the same compact audit rather than blindly adding the entire require graph. Extend the existing actual router boundary fixture and evidence-family list as above. No new module/campaign or relaxed budget is needed.
3. Keep current runtime unadmitted until fresh unchanged-oracle diagnostic succeeds on a coherent committed candidate. Then bind the exact new plain/staging/production tuples and reviewed client semantic hooks to independently observed bytes/golden lineage, retaining historical families, rights, unknown/mixed/wrong-base/wrong-edition/canonical/immutable refusals. Migrate the two fresh-current assertions only at that point.
4. After separate nonauthor review, execute the affected component/evidence/selector tests, then ordinary exact-source Basic/all eight source shards/RI/format and applicable hosted preview/staging/controller routes. Keep full hosted regression's existing policy disposition. Live production requires its own exact artifact and origin checks. Do not rerun a failed unchanged campaign or call the diagnostic a full gate.

Reader foundation is present and has meaningful native-first source tests: AST/template identity, semantic tables/citations/contents, media priority/deferral, image/source dialogs, focus/disclosure/history/print cleanup, metadata and immutable closure. This inventory does not establish exhaustive accessibility, device usability, every browser/route sequence, or current delivery acceptance. The missing current completion guard and pending runtime/source evidence prevent claiming it complete for production today. Proposed checks above are not executed results; only registry/selector calls, identities and controlled validator acceptance were executed in this audit.
