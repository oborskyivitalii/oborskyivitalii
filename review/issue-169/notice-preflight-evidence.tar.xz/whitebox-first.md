# White-box QA — first independent result

Verdict: **PASS for the bounded validation-order correction and its strengthened existing regression case.** No blocking implementation or test finding. This is a dirty prepared-candidate review, not acceptance of a clean commit, a complete source campaign, stable staging, merge or production.

## Identity and boundaries

- Role/task: distinct nonauthor White-box QA, `/root/fix_whitebox`, first judgment. No implementation, delegation, external service writes, prior narrative reviews, MEMORY, peer outputs or parent notes were read. Only the source packet, actual owners/source/diff and permitted raw evidence were used.
- Packet: `timing-fix/candidate-packet.json`, SHA-256 `704c78bd7938e109f8f5fa19ce3d1a73ef7f1210ca726d1fcb990819c92dd877`, verified from bytes.
- Common prompt: `agents/reviewers/README.md`, SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt: `agents/reviewers/white-box-qa.md`, SHA-256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`, both verified and read.
- Repository: `/workspace/scratch/20e98a342431/author-site`, issue 169 / PR 170, packet base `8cf15883125892710633b17133d9ee0fc4b23b92`. Observed HEAD `e50c63de071de6837cf9b6405569bb9a68afd5da`, HEAD tree `1c9d8054afdb0e13377c6ccbcd14b92860653d99`. Exactly `tools/release/rights.cjs` and `tests/release-rights.test.cjs` were modified. The prepared bytes are not represented by that committed tree.
- Actual binary diff SHA-256: `f4c54d22d3da6e87dcf181521a7f0d428b49fd95c414222b2e679d780e15962a`.
- Reviewed compiler SHA-256: `07a3801b5b7bec3e19d12005a0011b3591b63db08e1bfd6f2f4b5b9c77d2d8a3`; reviewed test SHA-256: `1dd519a2cb41c55e720e5c13dcf72c5c8afee96ab486a6bec5e635f145d86517`. Both hashes and the diff were checked again after the focused execution and were unchanged.
- Inspected scope includes README, root AGENTS, applicable CONTRIBUTING review/failure protocol, issue-169 acceptance policy, acceptance/style guidance, REPOSITORY-MAP owners, rights compiler and frozen-verifier call sites, article selection/media call path, delivery fixture, relevant registry and workflow routes, and the two-file diff. `rg --files -g AGENTS.md` found only the root instructions.
- My observable context contains the bounded task/source packet rather than an author work narrative. I cannot inspect the actual parent spawn request/accepted fork parameters, provider model/context internals, or prove absence of provider memory injection. The orchestrator must retain its actual `fork_turns="none"` launch/acceptance receipt. Shared filesystem/tool access is an operational boundary, not OS sandboxing or provider attestation. This report does not supply those unavailable assurances.

## Independent structural oracles

The accepted scope requires malformed public legal copies to fail without repeatedly reconstructing hosted article/media, while every valid-input source, edition, media, rights and inventory guard remains mandatory. A general throw is insufficient: an unrelated upstream failure could conceal a bypass. Success alone is also insufficient: a shortcut that never reconstructs would appear fast. The smallest informative combination is notice-specific refusal with zero media render calls, valid restoration with an actual render, and propagation of a deliberately failing renderer.

| Risk / acceptance link | Structural fault | Scenario | Independent oracle | Existing check / route |
| --- | --- | --- | --- | --- |
| DELIVERY/AC05, bounded fix: repeated reconstruction | Hosted selection executes before rejection | Each of the 16 existing hidden/inert/raw-text/ambiguous wrapper mutations | Notice/parser-specific refusal and cumulative media render count remains zero | Strengthened `publication comment and inert-template wrappers...` case in permanent `release-rights` suite |
| DELIVERY/AC05: rights bypass for speed | Validation removed or a permissive early return inserted | Metadata and artifact are rehashed consistently around malformed notices | Frozen metadata alone remains acceptable, but both current compilation and full frozen verification refuse | Same case retains its original metadata assertion and full frozen refusal for every mutation |
| DELIVERY/AC05: success path accidentally skipped | Hosted reconstruction omitted after valid notice guard | Restore all exact original fixture bytes and original artifact record | Compilation succeeds; notice list and hosted edition report match the original; render count is positive | Same case, restoration tail |
| DELIVERY/AC05: downstream failures swallowed | Reconstruction failure caught/ignored or replaced by success | After valid restoration, renderer throws a unique Error object | The exact Error object escapes compile | Same case, injected hosted-media failure tail |
| DELIVERY: source/media coverage weakened | Required checks or inventory paths removed | Read valid path through hosted/room/file/source inventories | All existing calls/assertions retain their prior conditions and outputs; report property position unchanged | Actual two-file diff plus compiler/source inspection; broader campaigns remain separate |
| Independent guard sensitivity | Assertion passes regardless of ordering | Retained old-order compiler fault control with current strengthened test | Nonzero result specifically at zero-render assertion, actual 1 versus expected 0 | Existing raw `old-order-negative-control.{json,tap}`; no duplicate mutation execution |

All 16 original wrapper functions remain unchanged: comment, template, JSON script, style, hidden/inert containers, nested hidden/inert/template forms, quoted `>` attribute, self-closing template/hidden element, two malformed hidden-attribute forms, textarea and SVG/foreignObject. The loop continues restoring every original public byte after each mutation. The mock is installed after staging fixture creation, so its zero count excludes necessary setup reconstruction. Node's test-scoped mock owns restoration; the fixture owns temporary-directory cleanup.

Source flow at `tools/release/rights.cjs:391` remains artifact verification → commit/tree format checks → manifest/provenance/assets validation → public notices → hosted reconstruction → room/generated inventory → all public-file bases/retained closure → index/source/report construction. Only notice validation moves. `publicNotices` reads authored/source/public bytes and validates escaped full legal copies; no source or public writes occur in that function. `hostedInventory` still performs source selection, exact edition identity, production clearance, notice checks, asset provenance/byte checks, equivalent-JPEG checks, fallback geometry, resource closure and download classification. `articles.select` still calls `article-media.render`. The report still emits `publicNotices` in the same property position, now from the earlier result. The compiler's self-hash necessarily changes; unchanged whole-report digest is not an appropriate oracle.

This inspected diff changes no profile, worker count, scanner, parser, codec, cache or deadline. Existing independent failure surfaces were retained rather than replaced by timing-only assertions.

## Executed check and retained raw evidence

I executed exactly one existing focused case, with a 120-second outer cap, from the reviewed dirty repository:

```text
timeout --signal=TERM 120s node --test --test-isolation=none --test-name-pattern='publication comment and inert-template wrappers' tests/release-rights.test.cjs
```

Tool result `52be1f`: exit 0, no signal or timeout; wall 6.520377961 seconds. Complete native output:

```text
✔ publication comment and inert-template wrappers cannot hide otherwise exact full license copies (6489.094598ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 6515.692155
```

The one native test contains the 16 mutation iterations and the positive/failure-propagation tail. This is executed scenario evidence, not a measured branch-coverage percentage. No extra raw file was written: this report preserves the complete execution output and command.

I independently read the retained old-order fault control. Its compiler SHA-256 `1730fb1090799cdb81ece8af66102c73bb90732de4d99e8d19734f213757ceb6` matches `git show HEAD:tools/release/rights.cjs` computed during this review. Its strengthened-test SHA matches this candidate test. It exited 1 after about 4.08 seconds, with exactly one failed test and no cancellation/skips/TODOs, at `tests/release-rights.test.cjs:851`: `invalid notices must precede hosted reconstruction`, actual `1`, expected `0`. Thus the new ordering assertion demonstrably distinguishes the old fault. I did not mutate or rerun that control.

Original staging raw `stage-42237763419/prepublication-source-tests-runner.json` records clean source `e50c63de...`, 75 selected modules, status failed, ETIMEDOUT at 300000 ms and no final native accounting. Its timing stream records release-rights finishing at 204611 ms under four workers. The original failure remains a failure, regardless of this local focused pass.

The retained original focused CPU run completed 1/1 in 30.262 seconds. The unchanged-test-body after-order run completed 1/1 in 3.676 seconds. Retained spawn-observer data show 17→1 `web-media.py` children and 51→3 publishing-AST children across those diagnostic runs. The observer wraps `spawnSync`, not repository production code. These observations support the specific repeated-work mechanism; instrumentation/environment differences and the later strengthened test mean they are not a timing SLA or proof that all staging pressure is resolved. The strengthened-v3 retained run also reports 1/1 pass. The component TAP was still partial when inspected, so I claim no completed component-suite result from it.

## Allocation, limits and disposition

`tests/release-rights.test.cjs` is already permanent in `tools/quality/test-profiles.json`, with `pr-targeted`, `staging`, and `production` profiles and both changed files as inputs. The change extends its existing meaningful case and needs no duplicate suite/registry entry. `guides/SITE-CHECK-PROFILES.md` retains the unchanged source runner's four-worker, 300-second and 16 MiB bounds. `.github/workflows/site-checks.yml` runs registry-derived source shards and rejects missing/failed source results before successful Basic aggregation. This review adds no test-selection exception or deadline adjustment.

Unexecuted here: entire rights/component/source matrices, native Basic/scanner checks, exact clean committed-source checks and authenticated staging. Browser/device behavior is not a changed surface of this correction; the CLI/build validation surface is applicable and the focused test exercised it. Existing downstream boundary cases and no-hosted-article branch were inspected as unchanged, not newly executed. No quantitative coverage claim, stable-staging claim or live-deployment observation is made.

No findings require a source correction within this bounded change. Preserve this first result, the failed original stage and the fault-control evidence. Before advancement, bind the final candidate bytes to the reviewed hashes, retain the actual launch isolation receipt, complete the required broader exact-source checks and verify stable staging under the original policy. Stop/show remains the authorized release boundary.
