# Code review — first independent result

Verdict: no blocking or nonblocking code findings in this bounded two-file correction. This is approval of the inspected prepared correction for further verification, not clean-checkout acceptance, stable staging, merge, production, or issue closure.

Reviewer: `/root/fix_code`, distinct nonauthor Code reviewer, first judgment. This execution received the bounded source task; no author conversation, MEMORY, prior narrative review, current peer output, or parent notes were read. Requested launch isolation and provider-internal context/model behavior are different facts: this reviewer cannot attest provider internals. No delegation, source edits, tests, campaigns, or external writes were performed. Only this assigned result was written.

## Source identity and inspection

- Repository HEAD observed: `e50c63de071de6837cf9b6405569bb9a68afd5da`. Git status contained exactly modified `tools/release/rights.cjs` and `tests/release-rights.test.cjs`. This is a dirty prepared correction over the baseline, not a clean tested commit. Complete live two-file diff matched the supplied implementation diff.
- Packet SHA-256: `704c78bd7938e109f8f5fa19ce3d1a73ef7f1210ca726d1fcb990819c92dd877`.
- Implementation diff SHA-256: `f4c54d22d3da6e87dcf181521a7f0d428b49fd95c414222b2e679d780e15962a`.
- Common prompt SHA-256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code prompt: `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Inspected compiler SHA-256: `07a3801b5b7bec3e19d12005a0011b3591b63db08e1bfd6f2f4b5b9c77d2d8a3`; inspected test: `1dd519a2cb41c55e720e5c13dcf72c5c8afee96ab486a6bec5e635f145d86517`.
- Read original issue169 text from `timing-investigation/owner.json`, candidate intent/scope, README, root AGENTS, applicable CONTRIBUTING reviewer/iteration rules, common/Code prompts, CODE-STYLE, issue169 acceptance policy, mapped rights ownership and `guides/SITE-RIGHTS.md`. No nested AGENTS was found under affected tools/tests. Read compiler paths, fixture setup, the entire changed negative case, report construction/digest and affected article-media call ownership. The owning staging source selection includes this existing test module.

## Correctness and preserved contracts

At `tools/release/rights.cjs:398`, the existing `publicNotices` call now runs after artifact identity, commit-shape and manifest/provenance validation, before `hostedInventory`. Its returned array is used at the original report property position (`publicNotices`, after `legalCopies`, before `linkedPublications`). The helper performs reads and checks, with no observed mutations or media reconstruction. On successful immutable inputs it computes the same ordered `['credits.html', revision.routes.credits.url]` value. No report field is removed or reordered.

Whole report bytes and inventory digest are correctly expected to change because the report explicitly binds `compilerSHA256` to the modified source. Preservation of successful report semantics does not mean preserving the previous compiler identity or its derived inventory digest. Existing verification recomputes the report; archived verification remains source independent and unchanged.

The deliberate precedence change means invalid current Credits/legal notice markup is rejected before article/media reconstruction and before later inventory work. Artifact and manifest validation still precede that rejection. Successful notices still proceed through unchanged exact hosted selection, source/semantic edition checks, production rights status, notice copies, resource provenance/bytes, equivalent JPEG clearance, fallback geometry, asset/download closure, room resources, retained coverage, tag index and source inventory. No cache, scanner, profile, worker, parser, codec, or deadline change appears in the complete diff.

The test observer at `tests/release-rights.test.cjs:806` uses the test-context mock tracker, retaining the real renderer for the negative loop. Its zero cumulative call count covers all sixteen retained malformed wrappers. The notice-specific exception oracle excludes passing merely because unrelated reconstruction failed. Restoring the original artifact then checks notice and hosted-edition values and requires an actual renderer invocation. Replacing that scoped mock implementation with a sentinel error and requiring the identical thrown object checks that a renderer failure still propagates; it would detect swallowing/skipping reconstruction. `t.mock.method` is scoped to this test context and is restored when the test completes, including assertion failure. Temporary artifact lifecycle is already owned by the test fixture. No process-global observer or persistent implementation patch was added to repository sources.

Relevant manual style assessment: CS01/04 keep the existing owner and dependency direction; CS05 adds a descriptive local result without broad reformatting; CS06 uses scoped mock lifecycle; CS07 removes measured repeated work without raising bounds; CS08 extends the existing meaningful negative case with positive restoration and fault propagation. Automated style/Basic/native checks were not executed by this reviewer and remain separately required under CS08/10 and issue169 AC05/11.

## Primary evidence and limits

Read the failed `stage-42237763419` source-runner JSON and raw timing stderr. It binds a clean baseline source/tree and reports a 300000 ms `ETIMEDOUT`; the release-rights module itself completed successfully at approximately204606 ms. Therefore the original observation is campaign timeout pressure, not a proven rights assertion defect.

Read the raw CPU profile/time/TAP and independently reduced its sampled self time: `spawnSync` accounts for about26228 ms of the approximately30 s focused case. Child-count observations report17 media encoder subprocesses before the correction versus1 for the same unchanged test body after only the compiler reorder (AST subprocesses51→3; Git calls357→21). The after-case raw records report exit0 at approximately3.68 s. These measurements substantiate avoided repeated reconstruction for this case; they are not a forecast or pass for the full staging campaign.

Read `strengthened-case-v3.tap`: the final strengthened focused case reports1 pass,0 failures at approximately5.66 s. Read `old-order-negative-control.json` and its raw TAP: the strengthened test fails under the original compiler order specifically because the renderer call count is1 rather than0; recorded restored compiler/test hashes match this candidate. This is useful fault-control evidence for the new ordering oracle rather than a cosmetic assertion of source arrangement.

The parent-owned component TAP was inspected as raw output, but no completed terminal accounting was present at the time read; no component-suite pass is claimed here. This reviewer executed no tests. Clean-head source/native campaigns, exact-source CI, all four role results and actual hosted stable staging remain unobserved by this review. No release authorization is supplied.
