# Exploratory / Interaction QA — first judgment

- Reviewer: distinct nonauthor `/root/fix_exploratory`; first independent result, before reconciliation.
- Verdict: PASS for the bounded changed CLI/operator journeys examined. No blocking findings. This does not establish native source-campaign success, stable staging, rights approval or release acceptance.
- Candidate: repository `oborskyivitalii/oborskyivitalii`, owner #169, PR #170; dirty prepared two-file correction over `e50c63de071de6837cf9b6405569bb9a68afd5da`, baseline tree `1c9d8054afdb0e13377c6ccbcd14b92860653d99`, base `8cf15883125892710633b17133d9ee0fc4b23b92`. Not a clean tested commit.
- Packet: `timing-fix/candidate-packet.json`, SHA-256 `704c78bd7938e109f8f5fa19ce3d1a73ef7f1210ca726d1fcb990819c92dd877`.
- Diff SHA-256: `f4c54d22d3da6e87dcf181521a7f0d428b49fd95c414222b2e679d780e15962a`.
- Common launch contract: `agents/reviewers/README.md`, SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role: `agents/reviewers/exploratory-interaction-qa.md`, SHA-256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Candidate compiler SHA-256: `07a3801b5b7bec3e19d12005a0011b3591b63db08e1bfd6f2f4b5b9c77d2d8a3`; test SHA-256: `1dd519a2cb41c55e720e5c13dcf72c5c8afee96ab486a6bec5e635f145d86517`. All 20 packet file hashes matched at inspection. Compiler/test/common/role hashes and two-file-only dirty status matched again after execution.
- Environment: local Linux shell, Node `v24.22.1`; source under `/workspace/scratch/20e98a342431/author-site`. Last readback `2026-11-06T18:01:03Z`.
- Isolation: no author chat, MEMORY, current peer outputs or parent notes read. Only packet, relevant repository source/contracts and permitted raw evidence inspected. Actual runner launch receipt belongs to orchestrator; provider context/model internals are unknown.

## Independently chosen charter and bounds

Explore the actual changed tooling surface: malformed public notice rejection, recovery to normal hosted validation, then the operator's existing real edition/package CLI journey through valid sidecar creation, missing/stale records and wrong checkout identities. Preserve inventory versus rights approval boundaries. Bound: five-minute review; at most one existing focused CLI test case, hard 120 seconds; no full campaigns, implementation, delegation or external writes. Charter was recorded to the orchestrator before execution.

The website UI is unchanged by this correction. Browser/device/perceptual interaction is reasoned not applicable to this two-file validation-order change; no browser or physical-device proof is claimed.

## Actions, expectations and observations

| Journey | Expected | Observation and evidence | Classification |
| --- | --- | --- | --- |
| Candidate identity and actual diff | Exactly notice validation order plus existing negative-test strengthening; no worker/profile/deadline/scanner changes | Git HEAD/status/diff and every packet source digest matched. The compiler evaluates the same `publicNotices` function before `hostedInventory`, and inserts its returned value in the same report property position. | Executed/pass, source inspection |
| Malformed current Credits notices | Sixteen existing wrapper partitions fail at notice checking before media reconstruction; coherent rehashing cannot convert hidden/inert legal copy into valid notice evidence | Read `tests/release-rights.test.cjs:797` onward and `tools/release/rights.cjs:361` onward. Supplied `strengthened-case-v3.tap` reports one passing case, 5630.519522 ms; `old-order-negative-control.tap` fails with `1 !== 0` at the new zero-render assertion. JSON receipt identifies the restored compiler and strengthened test hashes matching this packet. These are read primary logs, not a case independently executed by this reviewer. | Read supplied execution evidence + source reasoning |
| Restore valid notices and retain downstream failure | Normal recompilation still reconstructs hosted material; a hosted-render error remains fatal | Existing strengthened case restores all artifact files between malformed iterations, checks restored notice/hosted-edition values, checks positive render call count and injects a unique render error that must propagate by identity. Supplied passing TAP covers those assertions; no code bypasses hosted validation on the valid path. | Read supplied execution evidence + source reasoning |
| Actual edition and package CLI journey | Staging and production emit exact nonpublic sidecars before upload/package; report remains `approvalPass: false`; missing/stale report and wrong commit/tree fail; valid package/content downstream path remains usable | Independently ran exactly the existing CLI case below. It passed in 41.94 seconds, exit 0. Its source assertions exercise both edition entrypoints, rights verify CLI, package gate and package CLI, missing/stale report negatives, source/tree mismatch negatives and later compatible-content package success/wrong-proof rejection. | Executed/pass, one focused CLI case |
| Rights authority and stale/source boundaries | Inventory success cannot grant approval, reuse wrong identity or substitute today's source for archive proof | Read compiler report `approvalPass: false`, `acceptance` requiring separate reviewer/record and identical inventory digest, checkout clean/commit/tree assertions, and frozen `reportBinding` requiring false approval and exact source/tree/candidate/artifact/file identity. Actual CLI case asserts false approval and stale/wrong identity rejection. | Source inspection + executed bounded CLI assertions |

The CLI fixture explicitly disables article preview for its principal-page CLI checks. Its success does not independently execute the malformed-hosted-media partitions or prove the real article's native pipeline. Those remain separate evidence.

## Raw independently executed result

Command, working directory `author-site`:

```sh
timeout 120s node --test --test-name-pattern='^publication actual edition and package CLIs freeze exact sidecars before any upload$' tests/release-rights.test.cjs
```

Exit code: 0.

```text
✔ publication actual edition and package CLIs freeze exact sidecars before any upload (41822.110232ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 41940.099962
```

## Regression disposition and acceptance limits

| Case / obligation | Maintained route | Disposition |
| --- | --- | --- |
| Existing strengthened malformed-notice/recovery/media-failure case | `tests/release-rights.test.cjs`; `tools/quality/test-profiles.json` registers `pr-targeted`, `staging`, `production`; `guides/SITE-CHECK-PROFILES.md` B/source route and `site-checks.yml` source shards/checks aggregate | Retain the meaningful regression in the existing suite; no duplicate test or campaign proposed. |
| Existing actual edition/package CLI case | Same release-rights suite/profile route; this review ran one case directly, outside native source accounting | Retain. No profile/worker/deadline change warranted by this observation. |
| Complete component/native/source campaigns | Existing registry and original budgets; orchestrator/component and native staging workflow owners | Not independently executed or accepted here. |
| Issue #169 AC04/AC05 DELIVERY and INDEPENDENT gates | `.github/acceptance/issue-169.json`, normal exact-source native/hosted workflow and four-role protocol | This bounded result contributes review evidence only; it cannot close delivery or all independent gates. |
| Stable staging and source/served artifact binding; external exact-edition rights acceptance | Existing staging/admission flow and separate rights authority under `guides/SITE-RIGHTS.md` | Not observed. Local CLI fixture success does not fulfill them. |

No findings in examined notice failure ordering, restoration/downstream validation, sidecar-before-package, approval separation, missing/stale report, and wrong source/tree journeys. No timing improvement or end-to-end timeout elimination is inferred from this local CLI result. Unchanged evidence reused consists of the actual CLI test source and source-bound supplied strengthened-case/negative-control raw logs; prior narrative reviews were not reused.

