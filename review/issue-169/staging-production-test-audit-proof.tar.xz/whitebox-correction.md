# White-box QA correction — preserved first correction result

## V1 independent result

WB01 is corrected at the collector/validator source boundary. The declared PDF target is now derived from the selected descriptor; exact origin/base/href, one occurrence, nonempty label, status200, descriptor digest and PDF MIME are required. Every collected capability head passes through this guard. The network collector refuses redirects, hashes actual response bytes and propagates request/body failures. Both later external platform links may coexist without this PDF collector fetching them. The original historical-reference checks remain.

The prepared V1 packet SHA-256 is `e78097fb614c348e477f7a7fc14709d934526f18ee8a4cbdb8544f4c1d362186`, prepared diff SHA-256 `bdb8efc2193ed60a2d58ac23cd4fcf9ae507d1fbe5dc48b349d5fd2e526f254f`. All six supplied source hashes matched at inspection. Source remains a dirty preparation over head `efe397d90348077234396fa621548689677a9407`; this is not a clean-commit pass. First WB01 judgment remains unchanged in whitebox.md.

Actual independent execution: `node --test --test-reporter=tap tests/article-browser-evidence.test.cjs tests/reader-controller.test.cjs`, exit0,36 tests including12 controller subtests,36 pass,0 fail/cancel/skip/TODO,10.200s. Raw: `whitebox-logs/correction-targeted.tap`. The controller case records current candidate controller and producer separately with producerDirty=true, synthetic labels and productionEligible=false. I authored no implementation or accepted tests.

Additional independent in-memory probe: missing, duplicate, foreign-origin, wrong-base and self-consistent substituted PDF all rejected; correct native PDF plus both external platform links accepted; GET and body failures rejected. Raw script/log: `whitebox-logs/correction-probe.cjs` and `.log`. An earlier inline version of my probe had a JavaScript parse error before any case ran; it supplied no result, and only the corrected explicit probe executed these8 cases. No candidate-source retry or change was involved.

## Remaining handoff finding WBC01 — P3

The new controller test directly invokes the current `tools/staging/color.cjs` and `tools/staging/edition.cjs` producers through `tests/fixtures/delivery.cjs`, but its registry inputs omit both. Actual `source-tests.cjs.select(root,'pr',{changedPaths:[path]})` for either path omits `tests/reader-controller.test.cjs`. Both staging and production profiles do include it. Raw selection result: `whitebox-logs/correction-selection.json`.

Add both producer paths to the existing reader-controller row in `tools/quality/test-profiles.json`. This preserves the intended smallest targeted selection for future producer changes. The current prepared delta selects the suite through its own test/fixture edits; this finding does not erase the current36 executed passes. Affects AC05 test handoff/route completeness, not a demonstrated public runtime defect.

## Test handoff versus release

The current-consumer fixture meaningfully checks actual generated staging/production bytes with12 separate synchronous consumer subtests. Absolute controller module imports keep its dependency closure inside the selected checkout. The external mode explicitly requires a40-hex expected SHA, exact HEAD equality and clean tracked/untracked state before imports. The fixture reports synthetic source labels and cannot establish live rights/release/provider acceptance.

The supplied raw pinned-controller run against `8cf15883125892710633b17133d9ee0fc4b23b92` independently reports2 passing rights subtests and10 failing consumer subtests (11 failures including the parent). This is the actual pending controller compatibility stop; current-candidate36/36 does not clear it. The runbook makes the pinned-controller case an explicit reconciliation action; ordinary source-profile success defaults to current-consumer checks, so the external result must remain separately recorded before another stage attempt.

The supplied actual browser collector stderr shows Chromium failed on socket creation before the material journey ran. The correction has source/unit request evidence; actual served-link collection remains pending. No full staging, production, native browser or performance campaign was executed by this role. The new documentation correctly limits full five-route counts and keeps reader performance explicitly separate.

This is a continuation using this role's own first judgment and neutral source/raw evidence. No peer verdict or parent analysis was read. Provider/launch internals remain unobserved. No implementation, external write or delegation occurred.

## V2/V3 integration follow-up — final bounded result

The V1 correction result above was preserved before this follow-up with SHA-256 `bae2e1dec436f29260be767d9996456ca3d3515b6a4ba4fc42cc9301971c495c`.

I independently inspected V2's fixture integration: `journey` adds explicitly synthetic descriptor-derived materials to the controlled head; the actual collector/validator is unchanged, and the added evidence test validates the unmodified current fixture before corruption. Its scope is appropriate for source fixtures and cannot supply actual browser evidence. The V2 packet SHA-256 is `fb554bb9eecd7050a1a0000a2184d63f5d1f5f76f5df1a514cfade75169c5969`. My V2 whole-packet hash guard detected the concurrently corrected registry and stopped before behavioral execution; that result was not silently accepted as a matching V2 packet.

V3 is the reviewed integration identity: packet SHA-256 `02902c9ef0094824eb77796fa794b6726ed2c6455375255f3cec6a92526fe06d`; prepared diff SHA-256 `a941c245e42dea4a97690f367b136f457b921e92f4793ce0debbe2eff738b4aa`. All seven source hashes matched at the actual follow-up check. Registry SHA-256 is `f98200e8ff4189f493a9c5adce44db105c396e35e265fe4a5173b051642b83f7`.

The only additional registry delta adds `tools/staging/color.cjs` and `tools/staging/edition.cjs` to the existing controller suite. Actual PR-selection probes now select `tests/reader-controller.test.cjs` for either producer path: **WBC01 resolved**. Permanent staging/production selection already passed in V1 and is unchanged.

Executed V3 bounded integration probe, exit0: unchanged `currentJourney` fixture validates against the exact current generated descriptors/engine at a separately chosen `/base/` URL; removing its PDF from each of the five individual capability observations fails the declared-download guard. This guards against a fixture that only works after each consumer patches in materials. Raw result: `whitebox-logs/correction-v3-integration.json` SHA-256 `d2eb62d3f43ddef72ee21f7726e129b04e9335c7cbbcde3541093b92bc5356cc`. This probe and the36-test V1 run are reported separately; I did not claim to have rerun the entire36-test set on V3. The changed fixture integration should retain the parent's affected-suite regression result as a separate execution.

**Final test-handoff verdict: accepted for this reviewed correction scope.** WB01 and WBC01 are resolved in prepared V3; no further blocking test-source finding found. The pinned protected-controller incompatibility and unexecuted actual browser material collection remain release/staging stops or pending evidence as described above. Source/probe success does not supply them. The optional full reader-performance disposition remains explicit and adds no new publication dependency. No public manuscript/PDF/media byte changed in this correction.
