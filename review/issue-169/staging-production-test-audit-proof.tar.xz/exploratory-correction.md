# Exploratory / Interaction QA — prepared correction

**Verdict: the six-path test/runbook correction passes this bounded exploration. Release advancement remains blocked by the retained pinned-controller incompatibility.** These are separate conclusions: the new case correctly exposes a release problem; its red pinned-controller result is not evidence that the test update is defective.

This is a correction continuation of `/root/explore_route_audit`, not a newly fresh first judgment. The first result `/tmp/issue169-review/exploratory.md` is unchanged at SHA-256 `3ffd54d7e6e06871d9d0f1e5ee9966dd7e51a132e854488193ed39e1a0594073`. No peer output was read, and no implementation, external write, delegation or full campaign was performed. Raw author-supplied check evidence was read as primary observations, not as a verdict.

## Inputs and source identity

- Original owner #169 / PR170 and original packet/common/role identities remain those in the first result.
- Prepared packet `/tmp/issue169-review/prepared.json`: SHA-256 `e78097fb614c348e477f7a7fc14709d934526f18ee8a4cbdb8544f4c1d362186`.
- Prepared diff `/tmp/issue169-review/prepared.diff`: SHA-256 `bdb8efc2193ed60a2d58ac23cd4fcf9ae507d1fbe5dc48b349d5fd2e526f254f`.
- Producer HEAD remains `efe397d90348077234396fa621548689677a9407`, committed tree `47babebd5e0bd5681f44175ce98aff51503194aa`. The reviewed candidate is explicitly the six-path dirty preparation, not that commit's unchanged bytes. All six path hashes matched the prepared packet when checked.
- Pinned-controller worktree `/tmp/issue169-review/trusted-main`: detached `8cf15883125892710633b17133d9ee0fc4b23b92`, tree `1f8e758a6c4565b12b8112477e77b9637f4938a9`, clean on readback.
- Examined all six actual changed paths: profile guide, quality README, article browser implementation, article browser evidence tests, reader-controller tests and registry. Existing source-profile contracts and first-result scoped evidence were reused only where unchanged.

## Charter and capabilities

Bound: five minutes, each command below 180 seconds; actual longest new case ~9.1 seconds. Independently exercise documented current-versus-pinned controller selection and missing/wrong/dirty pin failures, then call the new generic PDF collection API with the real current PDF bytes and targeted hostile input/response variations. Walk the documented local/current/pinned/optional-full/live distinctions as an operator.

No browser was launched. The supplied actual browser attempt failed before startup with Chromium's `socket() failed: Operation not permitted`; that is capability-blocked, not observed browser behavior. It was not retried unchanged. The request API adapter below is source/API interaction with real local bytes and controlled responses, not a served HTTP/browser observation.

## New executed interaction matrix

Raw evidence: `/tmp/issue169-review/exploratory-correction-logs/`.

| Action | Expected versus observed | Result |
| --- | --- | --- |
| Documented targeted controller case with default current producer | All five staging and seven production consumers accept current generated article packages. Observed 12 consumer leaves plus parent, 13/13 pass, zero skips/cancelled/TODO, ~9.1 sec. Diagnostic identifies current mode, actual producer/controller commit/tree, dirty producer, synthetic source labels, no provider call and `productionEligible:false` | Executed/pass; `current-controller.tap` |
| External clean pinned checkout, omit `SITE_TEST_CONTROLLER_SHA` | Reject before constructing or accepting consumer evidence. Observed exit 1 at `pin controller SHA`, one failed parent, no consumer subtests | Executed expected rejection; `missing-sha.tap` |
| External trusted checkout, supply producer SHA instead of its actual SHA | Reject exact identity mismatch. Observed exit 1 at `wrong controller source` with actual `8cf1588…`, expected `efe397d…` | Executed expected rejection; `wrong-sha.tap` |
| External root points to dirty producer with matching committed SHA | Reject clean-controller requirement even though SHA matches. Observed exit 1 at the clean-status assertion listing the six dirty prepared paths, before consumers | Executed expected rejection; `dirty-controller.tap` |
| PDF collector uses current real R10 descriptor and 869,208-byte local PDF, ordinary `/author` base | One request to exact native destination, redirects disabled; bytes/digest/status/MIME admitted; no external reciprocal request | Executed/pass via request adapter; `pdf-api-probe.json` |
| Same with `/author/` trailing slash | Same exact accepted destination and one request | Executed/pass |
| Native href changes origin, base directory or adds query | All three rejected before request; external Medium link never requested | Executed/pass negative partitions |
| Correct href returns changed bytes, 302 or HTML MIME | Each rejected after one controlled request; successful real PDF accepts `application/pdf; charset=binary` | Executed/pass negative partitions |
| Validate registry and inspect routes for both changed suites | Registry validates; both remain permanent in PR-targeted/staging/production; new current-controller case is inside existing reader-controller module; total permanent JS inventory remains 78 | Executed/pass; `registry-operator.json` |

The PDF API probe directly uses `observeMaterials()` against `sdlc-out-of-balance:en`, native `article-media/36269db33a71781084053ae40cc41e411a0106bea5e593ef0b08414014c4ca40/reading-r10.pdf`. It validates collection and rejection logic, not PDF visual fidelity or live host availability.

## Retained supplied observations and interpretation

I read the supplied raw `focused-after.tap` (36/36), `route-contracts-after.tap` (82/82), `pinned-controller-after.tap`, and `actual-material-collector.stderr`. The first two were not independently replayed because the new API and controller cases above covered the changed interaction charter and no new failure justified a full repetition.

The pinned raw log has twelve consumer leaves: ten fail and two rights leaves pass; native Node accounting includes the failed parent, hence thirteen total / eleven failed / two passed. It records pinned mode and actual controller/producer identities. Examples include `Unsupported room fallback resource` from the pinned snapshot consumer. This is actual incompatible consumer behavior on the prepared producer artifacts, not a browser or hosted observation. I did not rerun that unchanged failed case. Its failure continues to stop staging until the trusted controller owner is reconciled through the existing route.

The current-controller success cannot replace that failed pinned result. The new test's absolute imports select the external checkout's consumer closure; fixture/packaging producer helpers remain current and their source labels are expressly synthetic. The test performs no provider action and grants no release/rights decision. The default current-controller diagnostic accurately records the dirty producer instead of claiming a clean committed candidate.

## Operator walkthrough and findings

No new blocking defect was established in the correction itself. Examined risks were a silent fallback to candidate modules when a controller pin is missing/wrong, accepting dirty external controller bytes, swallowing one consumer failure before independent remaining consumers execute, PDF links checked only for a named historical article, external backlink requests added to native PDF checks, and full-profile documentation overstating article performance/live coverage.

The operator route is now findable and actionable from quality README: verify main SHA, create a detached clean controller checkout, set both explicit environment variables, invoke only the named existing case, inspect identities and stop on any failure. The guide and registry make the default current result a distinct observation from cross-revision compatibility.

The revised full-production section agrees with the accepted staging-based policy: full diagnostic is optional; five-route 390/12/39 and principal-route Lighthouse counts do not claim article performance; reader diagnostics are separate; isolated production candidates may use staging transport/indexing policy while live production still needs its own checks. Nothing in these docs turns a source/unit/API pass into live availability, PDF layout, rights acceptance, staging promotion or production readiness.

AC05/11 gain a bounded correction review with retained failures and source identities. AC09/10 receive stronger selected-origin PDF-link/status/digest/MIME assertions, but browser/no-JS rendered collection and actual website/material delivery remain unobserved here. The supplied failed browser launch does not close them.

## Regression mapping / remaining route

| Case | Existing suite / profile / execution owner | Disposition |
| --- | --- | --- |
| Generic descriptor-bound PDF validation/collection | `tests/article-browser-evidence.test.cjs`; permanent PR-targeted/staging/production; actual `articleHead` in two normal widths plus Off/no-Canvas/no-JS | New API cases explored; real browser observation remains blocked |
| Current generated staging/production packages versus selected controller | `tests/reader-controller.test.cjs`; default permanent current-controller case; explicit pinned-controller invocation during release-route reconciliation | Current passes; pinned retained failure remains stop; missing/wrong/dirty CLI partitions explored |
| Full production principal matrix versus separate reader performance | Existing profile/workflow owners and optional `performance.cjs` / `reader-performance.cjs` diagnostics | Documentation disposition reviewed; no extra publication dependency or duplicate campaign proposed |
| Exact native PDF layout and live canonical/material destinations | Existing native PDF/author/live release observations under #169 | Not observed here; existing owners remain responsible |

No additional test implementation is requested by this result. Preserve the failed pinned record and obtain fresh affected review/check evidence after any controller reconciliation; do not substitute local current-controller success.

## Evidence hashes

- `current-controller.tap`: `b08647ac5fd2d36c1c25000523a024a48798b2962af29af92257bcb759224a29`
- `missing-sha.tap`: `3e4da75ad76e05d639ea7f941856516562eeddff98552d8c2979b3dcc22344c4`
- `wrong-sha.tap`: `9bf61e6983899b1a82f3a2ea8d2f61bb0bd7cdfeb54229996041c89f5abff4f5`
- `dirty-controller.tap`: `a8adfd230c691993db97ca3f975679bb52da3669afefe20dcc431d290f0d5bbc`
- `pdf-api-probe.json`: `b0399071d83ca93020a3d56afb2f2d8971f8c5cd6e2995a1377b73b5d0ac46d5`
- `registry-operator.json`: `72b33adc1a6c80d7b0e8aa4841ba5f533705ea67a8c5be4cc0f124509450ce46`
