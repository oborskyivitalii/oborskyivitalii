# Requirements & Acceptance — fixture correction v2

Owner #169 / PR170. Affected read-only continuation by `/root/requirements_stage_prod`; nonauthor. First and correction judgments remain intact; correction1 SHA256 is `cbe9cb874bcf704987db04c3bf551bb5c4e0cd138f2585aaaaecdacfe43f610a`. This is not a fresh-context first judgment. No peer verdict files were read.

**Accept the bounded fixture/test correction and the separately identified registry-input delta. No blocking requirements/test-correctness defect found. Staging/release readiness remains blocked as recorded previously. Refresh the source packet before claiming its final identity.**

Reviewed packet SHA256 `fb554bb9eecd7050a1a0000a2184d63f5d1f5f76f5df1a514cfade75169c5969`; supplied full prepared diff SHA256 `e4677616319a386cc7f571aa022796a3c9b1f3b6d813ee2826bc6c54905af7f5`; dirty base `efe397d90348077234396fa621548689677a9407`. Actual fixture/test source and unchanged `currentJourney`/content-delivery integration were inspected. Six packet input hashes match. During final hashing, the registry changed beyond the packet: `tools/quality/test-profiles.json` actual SHA256 is `f98200e8ff4189f493a9c5adce44db105c396e35e265fe4a5173b051642b83f7`. Its only further delta adds `tools/staging/color.cjs` and `tools/staging/edition.cjs` as direct inputs of `reader-controller`; both are used by that new test and this addition is appropriate. This post-packet source exposure was disclosed to the parent and is explicitly included here, rather than claiming seven original hash matches.

The parent supplied the factual observation that prior synthetic currentJourney data failed the updated material validator; the original failure remains retained. No peer verdict was read. Correction1's focused positive setup overwrote `head.materials` before validation, so its pass did not establish the unmodified shared fixture's validity. V2 now directly checks that baseline before any deliberate replacement/corruption.

| Requirement / AC | Actual delta | Assessment |
| --- | --- | --- |
| RQ3 / AC09/10: shared fixture satisfies declared material contract | `tests/fixtures/article-flight.cjs` derives synthetic material target/status/digest/MIME/label from descriptor downloads; an empty declaration stays empty. `currentJourney` preserves the head in all five capability cases. | Appropriate fixture maintenance. The helper report and added comment explicitly label these as controlled synthetic responses, never browser/hosted observations. Real collector and validator are unchanged. |
| AC05/11: prove the valid fixture before mutations | The current-article test first passes the original unmodified currentJourney into the actual validator; existing external-link and missing/wrong-link/status/hash/MIME negatives remain. | Closes the exact setup gap without weakening the oracle. |
| Relevant existing consumer | `tests/content-delivery.test.cjs:214` constructs currentJourney with actual selected descriptors/engine/base and passes it through the normal content gate. | The selected existing content-gate integration passes after v2. |
| AC05 registry allocation | The additional direct Color/staging-edition test dependencies are now explicit registry inputs. | Appropriate selection correction; source identity must use the observed registry hash above and refreshed packet. |

Own actual bounded checks:

- Two selected current-article/material collector tests: 2/2 pass, zero failure/cancel/skip/TODO, exit 0, 0.201s. Raw `requirements-logs/correction-v2.tap` and `.stderr`.
- `node --test --test-name-pattern 'distinct content gate inherits accepted platform' tests/content-delivery.test.cjs`: 1/1 pass, zero failure/cancel/skip/TODO, exit 0, 2.843s. Raw `requirements-logs/correction-v2-content.tap` and `.stderr`.

No full campaign, browser retry, source edit, external write or delegation was performed. Actual targeted execution remained within two minutes. Unchanged v1 review is reused only within its original source scope; the fixture/test delta and observed registry additions were re-read.

This review resolves the synthetic-fixture integration for the descriptor-download oracle. The failed complete-source timeout/missing historical-source evidence, Chromium socket/startup refusal, actual protected-controller incompatibilities, final clean-candidate checks and remaining independent/live gates are all unwaived. No article/PDF/media input, runtime gate, matrix, timeout, budget or publication authority changed.

Final-write source drift: after inspecting registry `f98200e8...`, the final verification observed a further concurrent registry change to SHA256 `d31947f04520637bdc60f958adb4f528d98007a17a340076679b40cb9e7f1d3d`. That later registry state was not reviewed and is excluded from this acceptance. The fixture/test acceptance and actual 3/3 targeted checks remain source-bounded to their listed prepared-v2 hashes; the entire latest working candidate cannot inherit this review until a frozen refreshed manifest identifies and reconciles the remaining registry delta. No failure or gate is waived by this report.
