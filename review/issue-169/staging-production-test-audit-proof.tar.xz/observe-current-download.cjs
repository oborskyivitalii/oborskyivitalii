'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root='/workspace/scratch/94faff7d674c/repo';
const directory='/tmp/issue169-review/native-package';
const record=JSON.parse(fs.readFileSync(path.join(directory,'staging-package.json')));
process.env.SITE_PUBLIC_DIR=path.join(directory,'public');
const artifact=require(root+'/tools/quality/artifact.cjs');
const api=require(root+'/tools/quality/article-browser.cjs');
(async()=>{
 const {server,url}=await require(root+'/tools/quality/serve.cjs').start();
 let browser;
 const rows=[];
 try{
  browser=await require(root+'/tools/quality/toolchain/node_modules/playwright').chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  const [key,descriptor]=Object.entries(record.source.components.articles)[0];
  for(const width of [1440,390]){
   const context=await browser.newContext({viewport:{width,height:900},javaScriptEnabled:false});
   try{
    const page=await context.newPage();
    await page.goto(url+'/'+descriptor.alias);
    const head=await api.inspectHead(page);
    await api.observeMaterials(page,head,descriptor,url,key);
    rows.push({width,mode:'no-js',key,materials:head.materials,pass:true});
    await page.locator('#article-materials a').first().evaluate(el=>el.remove());
    const missing=await api.inspectHead(page);
    await assert.rejects(()=>api.observeMaterials(page,missing,descriptor,url,key),/exact declared download/);
    rows.at(-1).missingNativeLinkRejected=true;
   }finally{await context.close();}
  }
  console.log(JSON.stringify({sourceCommit:record.source.sourceCommit,publicDigest:record.source.artifactDigest,collectorDirty:true,browser:browser.version(),executable:'/usr/bin/chromium',managedPinnedBrowser:false,hosted:false,fullGate:false,productionEligible:false,rows},null,2));
 }finally{await browser?.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
