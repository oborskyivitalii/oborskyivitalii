# Exploratory / Interaction QA — independent first result

Verdict: **no blocking defect found in the bounded CLI/operator charter**. This is a preflight result, not a full staging, browser, native PDF or production acceptance pass. No implementation or external mutation was performed.

## Identity and boundary

- Role/task: distinct nonauthor Exploratory / Interaction QA, `/root/explore_route_audit`, first result. No recursive delegation, peer verdicts, author notes, private chat or MEMORY were read. The supplied packet's issue body contains historical author/candidate claims; they were treated as subjects, not accepted verdicts. Provider model/context internals and account/project memory injection beyond the launch boundary are unknown.
- Repository `/workspace/scratch/94faff7d674c/repo`; base `8cf15883125892710633b17133d9ee0fc4b23b92`; clean inspected HEAD `efe397d90348077234396fa621548689677a9407`; tree `47babebd5e0bd5681f44175ce98aff51503194aa`. Working tree stayed clean.
- Owner #169 / PR170; source packet `/tmp/issue169-review/packet.json`, SHA-256 `ed72094a03c1530d908c09e4a9b398cacab7b4f5e2dce1fc531d1b29256fb463`; manifest SHA-256 `260c7d662c49554fe3e5ce0358c5442299cb68d6c691959fa18f8c93f6008cdb`. All 17 manifest entries were recomputed without mismatch.
- Common prompt `agents/reviewers/README.md`: SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/exploratory-interaction-qa.md`: `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Inspected sources: actual base/head diff (scoped to the article evidence, current catalog fixtures, staging reporting and content fixture changes), README, root AGENTS, REPOSITORY-MAP routes, CONTRIBUTING review/failure sections, acceptance/source/style/profile/release/staging contracts, executable source selector, public artifact builder, packaging link checker, content fixture, article print entry and release workflows. The initial broad diff/stat output was truncated; no assertion of line-by-line complete PR inspection is made. No nested AGENTS was found outside historical review material.
- Runtime: Linux, Node `v24.22.1` (host differs from CI's pinned `24.19.0`), shared filesystem. Repository publishing dependencies were initially absent, then became available during the review; no claim of fixed dependency availability across first/second commands. Browser archives/native devices were not installed by this reviewer.

## Independently chosen charter

At most eight minutes of bounded checks, no individual command above 180 seconds, no hosted campaign: follow an operator from profile selection to actual source contracts, current public artifact construction/verification and packaging input validation; exercise fixture composition beside the now accepted R10 article and historical source preservation; verify failure/readiness reports cannot promote incomplete evidence; distinguish a plan, synthetic evidence and current-source delivery proof.

The applicable interaction surface is the CLI/operator workflow. Browser, physical-device and platform-editor observations are applicable downstream surfaces but unavailable/unexecuted here, not N/A.

## Action and outcome matrix

Raw files are under `/tmp/issue169-review/exploratory-logs/`.

| Case / expected | Observed | Status / evidence |
| --- | --- | --- |
| `source-tests.cjs --profile staging --head HEAD --plan`: select all permanent current contracts minus the actual Basic baseline; never claim execution | 75 modules, baseline 3 (`theme`, `archive`, `flight`), `status: planned`, `pass: null`; article browser/material/media/retention/tag/publisher and release/staging contracts included | Executed/pass; `staging-plan.json` |
| Corresponding production plan: preserve full permanent selection | 78 modules, no delegated baseline, `status: planned`, `pass: null` | Executed/pass; `production-plan.json` |
| Targeted source execution: article interaction validator, staging operator report state, synthetic content preparation, profile/scheduling/accounting negatives | Initial command: 66 cases, 64 pass, 2 fail, zero skips/cancelled/TODO, ~10.8 seconds. Both failures were publisher dependencies absent before fixture construction. Failure output retained. Article interaction and reporting/selector contracts passed | Executed initial failure, environment cause diagnosed; `targeted.tap` (Node default spec text despite suffix), `targeted.stderr` |
| Recovery after observed dependency change: rerun only affected fixture module, preserving initial failure | Exact declared unified/remark versions became present. `node --test --test-reporter=tap tests/content-fixture.test.cjs`: 3/3 pass, zero skips/cancelled/TODO, ~15.3 seconds. This includes the live catalog plus synthetic draft, Writing count label, and already accepted local article's frozen Git provenance | Executed/pass after environment repair; `content-fixture-with-deps.tap`, `.stderr`. The 64 unchanged passes were reused; no full campaign replay |
| Build selected current artifact in reviewer output, then verify bytes/closure and sizes | Build/verify/sizes all exit 0. Artifact binds clean HEAD/tree; current article is `sdlc-out-of-balance:en`, R10 `sdlc-out-of-balance-en-r10-20261106`, `candidate: false`, `reading-r10.pdf` in declared downloads | Executed/pass; `artifact-build.log`, `artifact/artifact.json`, `artifact-verify.log`, `artifact-sizes.log` |
| Run actual package local link/fragment checker against built public closure | `tools/staging/package.cjs.checkLinks(...)` exits 0 | Executed/pass; `package-links.log`. Successful full production packaging/rights acceptance is not claimed |
| Existing staging reporting tests actually call `pkg.build` on their isolated fixture and distinguish smoke-reviewable candidate from failed/missing full gate | Both operator reporting cases passed, including source/provider mismatch and stale-main rejection | Executed/pass in targeted command; `targeted.tap`. This is controlled packaging/report evidence |
| Immutable workflow artifact identities stay distinct by stage/attempt | `workflow-artifacts.check()` reports 106 unique uploads, ID consumption true | Executed/pass; `operator-summary.log` |
| Investigate hardcoded `pmday-two-shifts` print invocation rather than assuming current R10 coverage | That publication exists. Profile guide lines 173–198 explicitly identifies it as PR79's optional technical diagnostic, selected only by `content_fixture`. Direct `article-print.cjs pmday-two-shifts ...` reached publisher PDF export and failed because locked managed Chromium is unavailable | Executed/blocked capability; `legacy-print.log`. It is neither a stale missing ID nor R10 PDF evidence |
| Probe whether `--head` on a full-profile plan authenticates source | A different valid commit still yields the same planned inventory. `select()` uses changed refs only for PR/content; staging/production are unconditional permanent inventories. Expected rejection was not observed. Output stays planned/pass:null; workflow separately checks exact HEAD and runner reports actual source | Executed diagnostic observation; `wrong-head-plan.log`. Do not use full-profile plan arguments as an identity receipt |
| Full hosted staging/production, native browser PDF, physical-device, actual live/canonical and platform-editor observations | Not run under assigned scope; managed Chromium absent locally | Not observed, not N/A and not passed |

## Findings and AC impact

No blocking code/test defect was established in this charter. Examined risks were omission of the new native article from routine full selection, false current-vs-historical identity, synthetic fixture assumptions about an empty native catalog, frozen Git provenance lost in copied fixtures, incomplete full-gate evidence appearing promotable, broken artifact link closure, and stage/attempt artifact collision. The bounded interactions passed once the evidenced dependency setup became available.

The missing initial publisher dependencies and managed Chromium are environment limits, not evidence that CI's installed pinned path fails. Initial failure remains retained; the subsequent fixture pass does not erase it. The host Node version mismatch also limits CI equivalence.

The full-plan `--head` behavior is an operator caveat, not an acceptance bypass established here: planning does not bind an execution source and emits no pass. Use actual execution report source and the workflow's checkout guard when evaluating AC05. No source modification is requested on this observation alone.

AC05/11 receive only this completed bounded review plus targeted results. AC09's matching accepted PDF/native rendering/live links and AC10's actual desktop/mobile/no-JS related-reading behavior remain downstream observations. Their complete acceptance is not implied by validators, artifact bytes or this report. No publication, staging promotion or merge authority is supplied.

## Existing regression allocation and next route

| Case family | Existing suite / profile / workflow | Disposition |
| --- | --- | --- |
| New current article inventory + frozen provenance + synthetic construction | `tests/content-fixture.test.cjs`; permanent staging/production and targeted PR through registry; optional real `content-fixture.cjs` via release browser job | Existing cases executed; retain allocation, no duplicated campaign proposed |
| Reader/native fallbacks, immutable material links, current reader-block and historical compatibility | `tests/article-browser-evidence.test.cjs`; permanent staging/production; real observations from `article-browser.cjs` under staging regression / existing functional jobs | Source negatives executed; real browser journeys not observed here |
| Partial/failed full gate plus candidate reporting | `tests/staging-reporting.test.cjs`; permanent staging/production | Existing controlled CLI/package cases executed |
| Inventory, scheduling, failed/empty/partial/skipped accounting, shard identities | `tests/test-profile-selection.test.cjs`; permanent staging/production and directly targeted PR | Existing cases executed |
| Current artifact closure, downloads and local fragments | `artifact.cjs` build/verify/sizes plus `package.cjs.checkLinks`; existing build/package route | Actual local commands executed; rights/deployment remain existing owners |
| Current accepted PDF layout and live article/material URL | Existing article/material/release and post-production routes; author/native PDF observation as required by AC09 | Deferred to existing exact-source hosted/native route; optional historical PR79 print cannot substitute |

No additional regression case is proposed without an established source defect. Continue the existing exact-source route after all roles reconcile; preserve independent first results and all initial failures.

## Evidence hashes

- `staging-plan.json`: `68b6c53bf00d67966e111a3b4fd02d254ab95d8382d38838ba10436e2eeb8185`
- `production-plan.json`: `252c1dd5ca951511784504b04368d73dc1ea8bfc8751833f5e0be1172402f967`
- `targeted.tap`: `137bbdfc6b47012bdf4772d4a447e3e7fb74cff2c1adc24daa2be6c94544616d`
- `content-fixture-with-deps.tap`: `1be73ad4bc55d29568e1cd26a51007a37473cbb3431cff28cc8a3100e1d2bc0d`
- `artifact-build.log`: `28187c775143260eb0b3738c370f23655e7bfe58ad419828874661e172863a19`
- `artifact-sizes.log`: `cdc00ddacae8edb72d2eacb834f0c63939673f01371b644c686ee1011e0797a9`
- `package-links.log`: `99138219d39a814d1edca54009b519010af28306bb20a769f259b1d96c96a3e8`
- `legacy-print.log`: `88482a2f2d7dd5512acf1ecfe1108c9bf76cc60e6d65e4dd5a6360fbdaa11a22`
- Built current public artifact digest: `eadb3043f18e507ee190b84f2cc32d0ac2af2208aa51a6fddaaa88e48dafdb17`.
