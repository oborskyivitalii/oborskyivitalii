# White-box QA — final frozen delta

**Accepted for the reviewed test/config handoff.** WB01 and WBC01 remain resolved. No new blocking finding in V4. This is continuation/correction review, not a newly isolated first judgment. Earlier first and correction receipts remain intact at whitebox.md and whitebox-correction.md.

Identity: prepared V4 packet SHA-256 `871006e2859759373b40dedc7045bd9a7cd15b116a48b3aa9c7cc003c78f34ba`; prepared diff SHA-256 `33e8195b1fd0058a90d4072364738af7905a27301bbe15bde33241a3147a380e`; dirty preparation over `efe397d90348077234396fa621548689677a9407`. All8 supplied source hashes match. Compared with V3, only `tests/test-profile-selection.test.cjs` and `tools/quality/test-profiles.json` changed. Reviewed PDF collector/validator, synthetic fixture, controller test and documentation bytes are unchanged; prior bounded correction evidence is reused only for those identical bytes.

The new registry inputs explicitly select release-controller and content-delivery integration consumers when the shared article-browser oracle changes. Existing rendition producer routes still select reader-controller. The new regression invokes actual selection, requires no conservative fallback and checks each intended consumer; this protects the route rather than only checking JSON text.

Executed:

- `node --test --test-reporter=tap --test-name-pattern='reader oracle and rendition changes select their actual integration consumers' tests/test-profile-selection.test.cjs`: exit0,1 selected test,1 pass,0 fail/cancel/skip/TODO. Raw `whitebox-logs/final-selection.tap`.
- Four independent in-memory fault probes remove each added oracle/rendition mapping from a cloned registry. Actual current plans select the consumer; each altered plan omits it while conservativeFallback remains empty. Thus the regression's inclusion assertion detects the intended mapping loss without being masked by unknown-source full fallback. Exit0; raw `whitebox-logs/final-selection-negatives.json`. No source mutated.

No new runtime/public content changes, browser campaign or full source campaign. No peer conclusions or parent analysis read. No implementation, external mutation or delegation.

This accepts the bounded test-source correction and allocation. It does not clear the independently observed protected-main controller incompatibility or supply actual served PDF/browser collection, staging, merge or production evidence. Those pending release-route observations remain explicit in the previous receipt and supplied raw records. The full production five-route diagnostic still makes no article-performance claim.
