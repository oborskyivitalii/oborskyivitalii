# Exploratory correction V2 fixture addendum

The first correction result remains unchanged at `/tmp/issue169-review/exploratory-correction.md`, SHA-256 `82851fff5762946b8038054ea304f0c7004d67f337da9119eb13a51170962c15`.

V2 packet SHA-256 `fb554bb9eecd7050a1a0000a2184d63f5d1f5f76f5df1a514cfade75169c5969`; V2 diff SHA-256 `e4677616319a386cc7f571aa022796a3c9b1f3b6d813ee2826bc6c54905af7f5`. This is a targeted correction continuation. The packet disclosed a prior missing-material integration failure; no peer verdict or peer log was consulted.

The delta adds explicitly synthetic descriptor-derived PDF materials to the existing `article-flight.cjs` journey fixture and asserts that the unchanged real-current fixture passes the article evidence validator. The real collector is unchanged. Both comments and fixture browser identity make its synthetic status clear. This does not fabricate hosted observation.

Independent new interactions:

- `node --test --test-reporter=tap --test-name-pattern='current article downloads|material collection' tests/article-browser-evidence.test.cjs`: 2/2 passed, zero skips/cancelled/TODO, ~0.33 seconds. Evidence `v2-download-tests.tap`, SHA-256 `056abb9657daa12c6516a9bc9a5e267a7e975d8de4c63871f27dc11a2f695159`.
- A first full-packet hash guard stopped before fixture interaction because the registry changed during review: actual `f98200e8ff4189f493a9c5adce44db105c396e35e265fe4a5173b051642b83f7` versus V2 expected `5cefc949395f4171dfd7e1f515aeadf6b282792e155bb75c7b7b92397658c9ad`. The failure was disclosed to the orchestrator. Its direct stderr is retained in tool execution `8d637b`; `v2-fixture-probe.json` is empty, not passing evidence. A whole-V2-manifest match is not claimed.
- A bounded follow-up checked the exact V2 hashes of all three directly relevant files (`tests/fixtures/article-flight.cjs`, `tests/article-browser-evidence.test.cjs`, `tools/quality/article-browser.cjs`) before probing. The unmodified current synthetic journey passed. Mutating only one row's PDF digest rejected each of normal1440, normal390, Off390, no-Canvas390 and no-JS390 separately. Evidence `v2-fixture-bounded-probe.json`, SHA-256 `63989d416ad5d6a2a794e5ded07f57c4eafcccec14bf39597499935f6874bf6d`. This is synthetic validator interaction, not browser evidence.
- The concurrent registry delta was inspected: reader-controller inputs additionally name `tools/staging/color.cjs` and `tools/staging/edition.cjs`, which the new producer fixture actually uses. This matches its dependency route. It does not alter permanent profile membership or the actual PDF collector.

No new defect was found in the fixture delta. Reuse the unchanged controller guard/API results from correction1; do not relabel them as a fresh full campaign. The existing actual pinned-controller incompatibility still blocks release advancement, and real browser collection remains blocked before browser startup. Parent integration execution is outside this review's claimed observations. Bind final acceptance to the final updated manifest after concurrent registry edits settle.
