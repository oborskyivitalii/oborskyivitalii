# Requirements & Acceptance — staging/production test preflight

Phase: first preflight judgment, preserved before peer reconciliation. Owner #169 / PR170. Reviewer task `/root/requirements_stage_prod`; nonauthor, read-only. No implementation, external write, dispatch, merge, publication or delegation performed.

## Verdict and identity

**CHANGES REQUIRED for a reconciled test handoff; safe to implement the bounded test/oracle corrections below. No new author decision is needed for the existing scope. Stage/production advancement is not approved.** The request is to reconcile the complete existing staging and production routes with PR170, preserving their scenarios, source identity, refusals and budgets. It does not require running optional full diagnostics during this audit, nor promise that every future environmental problem can be predicted.

- Inspected clean HEAD `efe397d90348077234396fa621548689677a9407`, tree `47babebd5e0bd5681f44175ce98aff51503194aa`; base/local main `8cf15883125892710633b17133d9ee0fc4b23b92`. Working tree clean at initial inspection. Live GitHub identity is supplied as dated packet/evidence, not independently fetched by this role.
- Packet SHA256 `ed72094a03c1530d908c09e4a9b398cacab7b4f5e2dce1fc531d1b29256fb463`; manifest SHA256 `260c7d662c49554fe3e5ce0358c5442299cb68d6c691959fa18f8c93f6008cdb`. Every manifest-listed file hash matched. Raw verification: `requirements-logs/manifest-verification.json`.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`.
- Requested `fork_turns=none` is stated by the launcher; provider internals/model/context injection remain unknown. No platform isolation attestation is claimed. No current peer output, parent scratch notes, MEMORY or reviewer-verdict file was read. The authoritative `native-check-allocation.md` necessarily included dated R9 execution/review summaries alongside its AC mapping; this incidental exposure was disclosed to the parent and is not used as current acceptance evidence.
- Source reading: root README/AGENTS, CONTRIBUTING, common/role prompt, relevant acceptance/style/source/staging/release/profile/quality contract sections and map owners; executable registry, source selector/worker/shards, staging/full browser collectors and aggregates, controller checkout/verify route, release/live/rights interfaces, material browser checks, representative current source/fixtures. No nested AGENTS was found. Actual base/head executable diff is retained at `requirements-logs/changed-executable.diff` (1,151,495 bytes); review was focused on active owners/interfaces rather than treating every historical ledger entry or generated binary as reviewed behavior.

## Preserved independent findings

### RQ1 — High: the test obligation misses the actual protected-controller/candidate-artifact boundary

Evidence: `.github/workflows/site-color-review.yml:361` checks out `github.sha` for the privileged publish consumer, and `:379` runs `tools/staging/review-flow.cjs verify`. That consumer calls package/snapshot validation. `tools/site/fallback.cjs` at protected base `8cf1588` permits an external room fallback only for Research; candidate HEAD permits Research and Writing. Current native package declares both resources. Candidate tests and prepublication can therefore pass while the real trusted consumer rejects the same package.

Actual primary evidence: run `42275940284`, attempt 1, publish checkout `8cf1588`, then `Unsupported room fallback resource`, exit 1 before provider upload. A bounded pure replay of the exact protected-base resolver against the retained native package passes Research and rejects Writing; HEAD accepts both. Raw replay: `requirements-logs/protected-consumer-fallback.json`. This is not a hypothesis about source-runner timing.

Affected AC: AC05/11 exact-source review/route evidence and AC09/10 delivery of the current reader/PDF. The failed publish gate remains failed; green candidate source tests cannot replace it.

Treatment in existing owners: extend the staging/package/review-flow test allocation to include the actual independently pinned protected consumer plus candidate-produced package and controller-owned dependencies. The oracle must distinguish (a) verified compatible packages, (b) explicit early incompatibility with no upload/promotion, and (c) historical/malformed/tampered packages still refused. Check the complete relevant consumer path, not only a single resolver or a candidate-supplied fingerprint. Retain package/source/tree/controller identities and the original failed run. Reconcile controller compatibility through the existing trusted-owner mechanism before any new stage attempt; this finding grants no permission to execute candidate code with provider credentials or relax the checker. Keep #169/PR170 as execution owner.

### RQ2 — Medium: the operational README still contradicts the maintained production policy

`tools/quality/README.md:188` says to run complete production validation before admission; `:193` says Color remains staging-only. Current `guides/SITE-CHECK-PROFILES.md:301` and `guides/SITE-RELEASE-GATES.md:15` make the full diagnostic optional and nonblocking; the separately frozen production edition explicitly supports Color. `tools/release/staging-policy.cjs` authenticates successful staging and identical merged source trees, while production live checks remain separately mandatory.

Affected AC: AC05/11 accurate check allocation, and AC09/10 honest release evidence. These conflicting instructions can cause unnecessary full campaigns or the wrong variant/origin oracle during this requested reconciliation.

Treatment: correct the existing quality README to the current canonical route. Preserve `validation_level` (coverage) versus `profile` (origin/indexing), optional diagnostic completeness when explicitly selected, separate production edition/rights/archive and actual served-byte/live smoke. No new pipeline, reduced matrix or blanket device/host pass is justified. Current canonical guides/controller already settle the policy; no additional author choice is required.

## Later treatment-specific input and assessment

After the above source/evidence inspection, the parent supplied a proposed treatment: generalize material checks from `reader-reference` to declared downloads and consider conditional article coverage in optional full production diagnostics. This section records assessment of that proposal; it is not presented as a newly independent fresh-context finding.

### RQ3 — High for acceptance linkage: current R10 PDF is outside the browser material oracle

Independent source confirmation after that input: `articleHead` in `tools/quality/article-browser.cjs:135` fetches and hashes material responses only when the key equals `reader-reference:en`; `validateArticleJourney` at `:2081` likewise validates response status/hash only for that key. Current generated article inventory contains only `sdlc-out-of-balance:en`, whose descriptor declares `downloads` including `article-media/36269db33a71781084053ae40cc41e411a0106bea5e593ef0b08414014c4ca40/reading-r10.pdf`. `site/publications/sdlc-out-of-balance/materials.json` independently names the same PDF digest. Its browser material links are collected but not subjected to that response oracle.

AC09 requires the actual article/PDF URL; AC10 requires valid native reader destinations. Hosted whole-file byte verification still checks the PDF resource, and snapshot generation validates one ordinary download anchor, but those checks do not prove that the displayed material anchor targets that declared resource at the selected origin/base.

**The proposed generalization is appropriate within current authorization.** Scope it to every declared `descriptor.downloads` resource in each exercised article, with zero/one legacy-compatible behavior as the canonical descriptor contract allows. Require an ordinary accessible native anchor to the exact declared immutable file, same selected origin/base, successful response and digest equal to the declaration; reject missing/duplicate/substituted links, foreign or wrong-base links, wrong bytes and unsuccessful responses. Do not accept a different self-consistent immutable PDF merely because its URL contains its own digest. Preserve optional-download semantics: the product must not preload/embed/fetch the PDF automatically. Explicit test-client GETs are observations, not product behavior.

Extend the existing article-browser-evidence fixture/test owner with an ordinary non-reference article and meaningful negatives. Preserve any reference-specific feature-inventory checks separately. The registry already routes that suite to permanent PR-targeted/staging/production and changed-helper selection; update its inputs/purpose only if the actual dependencies change.

### Optional full-production article coverage

The full `functional.cjs` collector/`validate.cjs` aggregate currently own the five-room matrix and do not collect article journeys. Staging and actual post-production `local-browser.cjs --smoke` do invoke the bounded article journey. Therefore the existing 390/12/39 full-functional counts must never be described as article coverage, nor as proof of current PDF-link behavior.

A conditional separate article subsection in the existing full diagnostic is a justified reconciliation if implemented: consume the same frozen article descriptors and admitted browser(s), retain exact article/engine/origin/source identity, and require its own complete result when articles are selected. Reuse the existing bounded journey/material oracle; keep the original five-room functional/navigation/analytics counts, native/Windows/Color allocations, performance limits and report failures unchanged. It must not become an extra mandatory publication dependency or silently substitute for actual production-origin checks. The minimum acceptable handoff is an explicit disposition and honest no-article-coverage statement; if claiming complete applicable article coverage in this diagnostic, collector **and aggregate** must enforce it with missing/duplicate/wrong-source/failure negatives. An implementation-only collector call without an aggregate requirement is insufficient.

## Scope / acceptance matrix

| Intent / AC | Existing owner / oracle | Observed state and required next evidence |
| --- | --- | --- |
| Audit every affected test route; AC05/11 | Registry + source selector; PR Basic/shards; staging prepublication; production source profile | Current selector: 75 staging modules plus 3 Basic modules; 78 production modules. Preserve lifecycle distinctions: permanent versus targeted diagnostics/task snapshots. No full campaign run by this role. |
| Exact staging source admission; AC05 | `local.cjs --prepublication staging`, prepublication validator and raw TAP | Native exact-head run passes all guards. Source 1203/1203, zero failure/cancel/skip/TODO, 225214ms; original 300000ms child / 330000ms wrapper retained. Do not infer a single-runner defect merely from historical 81-module timeout. |
| Current stage controller compatibility; AC05/09/10/11 | Protected checkout → review-flow → package/snapshot | RQ1 failed on actual current package. Early cross-revision compatibility assertion and trusted-owner reconciliation required before another stage. |
| Bounded staging platform browser/performance | Registry + `staging-regression.cjs` + `staging-gate.cjs` | Retain 4 normal + 2 no-Canvas journeys, 2 navigation, 10 failure, 7 analytics, Color2, 2 mobile Lighthouse trials and original CPU/flight limits. No new hosted campaign in this audit. |
| R10 article/PDF/related reading; AC09/10 | Existing article journey, source/material/tag checks, hosted byte inventory | Current inventory has one R10 article, so representative selection presently includes it. Five article cases: desktop/mobile normal plus Off/no-Canvas/no-JS at mobile. RQ3 material response binding needs extension; no new article source/PDF/visual edits. |
| Optional full diagnostic | `site-candidate-evidence.yml` → release-checks → functional/validate/native/performance/captures | Remains optional, full when selected. Preserve 390 functional / 12 navigation / 39 analytics, supplemental Windows40/8/26 and Color12, Lighthouse30/soak300s. Conditional article observations must be separately accounted; no source pass or plan is full native evidence. |
| Real production admission/live verification; AC05/09/10 | staging-policy/controller/rights/archive/live + bounded production browser smoke | Requires authenticated completed staging, protected identical-tree merge, independently frozen production edition, exact rights/archive and actual served edition/PDF/canonical/indexing/404 checks. None supplied as completed by this role. |
| Author/reviewer ownership; AC11 | Four distinct actual source-bound roles + author gates | This is one preflight role only. Preserve others and affected re-review after test/oracle changes; no whole AC closure. |
| Test/tool changes; AC05 style subcondition | CS01/04/05/07/08/09/10, existing formatter/lint/style/RI/CI | Test/fixture/check code stays with existing owners, bounded checks and refusal negatives; no expanded budget, parallel service or new release engine. Final exact-source checks/reviews still required. |

## Actual bounded checks and limits

1. Input manifest verification: all hashes match. Selector inspection computed the above current inventory without executing suites.
2. Four selected source-selection/shard/distribution oracle tests passed (4/4, no skips), 0.285s command wall time. Raw output `requirements-logs/source-shard-oracles.tap` and `.stderr`.
3. Three selected article/staging evidence-completeness/collector-failure tests passed (3/3, no skips), 0.276s. Raw output `requirements-logs/article-staging-oracles.tap` and `.stderr`. These use controlled fixtures and are not browser execution or full suite acceptance.
4. Pure protected-consumer replay: expected current Writing incompatibility reproduced; Research control passes. No upload or filesystem source mutation. This diagnostic adds evidence to the retained native failure, not a green stage result.
5. Read original native prepublication report and source accounting plus actual publish failure. Parent-supplied neutral evidence arrived before judgment; no parent verdict was accepted. Native ZIP digests supplied: prepublication `8298a73fa9d267fb69352a12bf6c7a990d8a91e964db1521085cd25f86b1b639`; package `3a89b3b9951ffd1c702d054a19ccca6a3e86545ef3ad54f9c28ffbd0d4abab35`. This role inspected extracted evidence, not independently the ZIP transport/authentication API.

No test process exceeded 180s; total own targeted execution is below 2s. Native evidence is readback from its original run. No full browser/platform/production campaign, physical device, external platform editor or live public observation was performed. Parent production-source execution is not duplicated or claimed here. No hard timing-budget change is recommended: the 15-minute operational target remains distinct from unchanged hard worker/job/product limits.

Primary evidence SHA256: native prepublication report `311e5ab8e8bafc3d1660fd8ca8f30ec6e06a8ae90dc982a6a552e5716d2d698c`; native source runner report `3987b37844f4a00b9c15266b11be9c5b37671c63d5415b81b1fa8027ccb57e41`; native staging package record `b85c741ff5ef09aa3ae58c9bb94254d5288a212ff1469ec696af49103621ad90`; publish log `38352dfd245aae4e4c21fd08ba5a6051426754f0a600d521e25ce05aa5739ad1`.

## Next gate

Record this audit allocation under #169/PR170, implement only the evidenced existing-owner test/oracle/documentation corrections, preserve the actual failed stage proof and obtain affected nonauthor reviews on the resulting candidate. Resolve RQ1 before another stage attempt; an honest incompatible result stops dependent publication. RQ3 requires meaningful non-reference PDF-link negatives and an actual affected collector observation before AC09 can claim its browser check. Document optional-full article disposition, current exact-source results and remaining live gates. No user permission question or new issue is required for these bounded test updates; a change to the protected trust/admission architecture would require its own explicitly reviewed treatment rather than an improvised bypass.

## Post-preservation assessment of the second proposed treatment

After the first artifact was written (SHA256 `ab95318d60395fee184025125f01c11d7796aecfb91056038d394cb522810178`), the parent supplied a more concrete proposal: extend `tests/reader-controller.test.cjs` with current-generated staging/production consumer integration, optionally selecting a pinned read-only controller checkout via `SITE_TEST_CONTROLLER_ROOT`; use independent subtests for package/snapshot/runtime/rights/route-size/production-edition consumers; generalize download observations, preserve reference checks, and correct the README. No implementation was provided or inspected at this stage. The initial verdict/findings above are preserved verbatim.

This is an appropriate bounded implementation route under the existing owner, subject to these acceptance conditions:

- Independently pin and verify the selected consumer root/ref and relevant bytes; the current candidate must not silently supply the supposed protected consumer. Record clean source/controller identities and whether default-current or pinned-controller mode ran. A current-current pass does not satisfy the actual current-protected boundary.
- Generate the actual current article/edition/material/retained closure once through the existing producer; do not isolate away R10 with a synthetic catalog and call that the current artifact. Check the same consumed package bytes without later repair or regeneration.
- Independent consumer subtests must retain each failure and original error while returning overall failure if any mandatory consumer fails. Ensure invoked modules/dependency closures actually come from the selected controller checkout, rather than mixing a protected top-level function with candidate helper modules. No process-global export interception or privileged candidate execution is justified.
- The explicit pinned-controller invocation must be part of this audit's recorded required check allocation, not merely a dormant environment-variable option. Its expected incompatible result is useful detection and remains a staging blocker; adding a test does not itself make the protected controller compatible.
- Download negatives should cover wrong same-origin path, different self-consistent immutable digest, foreign/wrong-base URL, missing/duplicate link, MIME, failed response and changed bytes, without weakening optional native-download behavior or reference feature checks. Source-only fixture success still needs affected actual collector observation before claiming hosted acceptance.
- Keep execution bounded and preserve original budgets/matrices. Additional full-production article collector work is not necessary merely to add the proposed consumer integration test; record its separate diagnostic coverage disposition honestly as described above.

With these conditions, **requirements preflight permits the proposed test/fixture/documentation implementation to begin**. Final candidate review and actual protected-consumer/staging/production live gates remain open.
