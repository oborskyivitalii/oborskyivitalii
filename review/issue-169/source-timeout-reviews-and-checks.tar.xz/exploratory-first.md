# Independent Exploratory / Interaction QA — first result

Verdict: PASS for the bounded changed CLI/operator surface; no blocking findings. This does not establish native CI, stable staging, reader/PDF acceptance, controller trust or whole issue acceptance.

Identity: /root/timeout_exploratory, distinct nonauthor exploratory role, first judgment. Inspected prepared dirty subset on HEAD550c7f242b88870796f3920332e620ff4e4ca795, not a clean committed candidate. No parent conversation, peer results, unrelated MEMORY, implementation/test edits, delegation or external writes were used. Requested launch isolation is supplied by the orchestrator; provider internal context/model/memory behavior is unobserved.

## Source identities and authority

Authority: supplied intent.txt and issue169.json, original AC05/11 and pending AC09/10. Approved scope is one shared source execution allowance 300→600seconds, source reporting grace still30seconds, enclosing source jobs10→20minutes; preserve all cases/scanners/workers/site budgets. Endpoint remains normal stable R10 staging, actual reader/PDF observations, STOP/show; no PR170 merge or production.

Packet manifest SHA256: 8a39b499f332d3989e9ab2634543fa76cdf72032ba4ac81c6bb8655c636b3f4e.
Supplied candidate.diff SHA256: 1a0e39ebb525257c1bee7727fe35d5be35b5d90e0fe97d3e11ff0592e6877129.
Common contract SHA256: 2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb.
Role prompt SHA256: 280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a.

Read own common/role prompts; root AGENTS (only AGENTS found), README, applicable CONTRIBUTING review/failure rules, acceptance owner and issue policy, repository map relevant owners, changed guides/source/tests/workflow caller paths, existing local.cjs derived wrapper. Sources in the manifest were hash compared after the interactions. Hash changes to metadata are disclosed below. Executable/workflow/test/guide bytes still matched supplied packet at comparison. The source-timeout report is candidate rationale, not independent evidence of its claimed earlier reviews.

## Charter and applicability

Bound: approximately five minutes of local read-only CLI/operator exploration, four CLI boundary journeys, one exported-limit observation and four selected existing regression cases. Linux with supplied Node24.19.0. Charter: walk documented source invocation and prepublication-report interpretation; distinguish planning from acceptance, bad input from valid profiles, dirty-source refusal, inner timeout from outer reporting allowance, and source runtime from website performance. Inspect all three enclosing source-job callers and workflow budgets.

Website browser/visual/device interaction is reasoned not applicable to this delta: actual `git diff -- site docs` returned0bytes and changed executable behavior is a CLI source-process allowance/workflow timeout. Native browser/PDF and physical-device observations remain unobserved; they remain required later for publication AC09/10. No claim that this review executes hosted Actions.

## Executed actions and observations

1. Actual CLI `node tools/quality/source-tests.cjs --profile production --plan`: expected a plan with no acceptance claim; observed status0, profile production, status planned, pass null,78modules.
2. Same CLI with staging: observed status0, profile staging, planned/pass null,75modules. These counts describe this candidate selection, not an assertion that cases were executed.
3. Same CLI with made-up profile: expected visible refusal; observed status1 and stderr `unknown source profile made-up`.
4. Same production plan with `--require-clean`: expected dirty candidate refusal; observed status1, `source tests require clean checkout` with actual dirty paths. This is an expected guard result, not a failed acceptance campaign.
5. Actual module load: observed `{timeoutMs:600000,reportGraceMs:30000,maxBufferBytes:16777216}`; `wrapperTimeout()` observed630000. Inspection of local.cjs timeout dispatcher confirms only source-tests uses that derived wrapper; other prepublication commands retain180000. Four-worker selection and accounting code have no candidate diff.
6. Operator workflow navigation: site-checks/checks line19, site-color-review/build line205 and site-release-checks/build line152 each have timeout-minutes20. Their actual source/prepublication call sites are present. Diff changes only those timeout values in the three workflow files. Other staging/release job limits remain untouched. 20minutes is an enclosing cap, not a promise every guard can consume its own maximum serially.
7. Followed guides' allowance/reporting owner links. Current amended source/report prose is600/630seconds; staging operational15-minute target remains measured optimization feedback, separate from hard site/browser/performance budgets. Historical25October allowance wording and browser300-second soak are contextual, not active source deadlines. No retry or acceptance downgrade is introduced.

Executed command (absolute Node24.19.0 executable):

```sh
node --test --test-name-pattern='explicit source reporting retains actual failed process streams and source|one source execution retains every selected native case|prepublication preserves inner source timeout evidence|actual preflight producer and consumer agree' tests/test-profile-selection.test.cjs tests/publication-records.test.cjs tests/prepublication-reuse.test.cjs
```

Actual stdout, process exit0:

```text
✔ actual preflight producer and consumer agree on complete source guards and immutable reports (540.190134ms)
✔ prepublication preserves inner source timeout evidence before its distinct outer deadline (80.984277ms)
✔ explicit source reporting retains actual failed process streams and source before the CLI exits nonzero (246.648382ms)
✔ one source execution retains every selected native case and rejects unavailable or empty modules (610.877267ms)
ℹ tests 4
ℹ suites 0
ℹ pass 4
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 941.778271
```

These are meaningful existing process/refusal/accounting/report-boundary tests. First reporting test runs a real failing child CLI and observes nonzero/report/raw output. Inner timeout/preflight cases use controlled execution seams: they verify ETIMEDOUT remains failed, original partial TAP/stderr survive and scanner deadlines remain180seconds; they do not wait600seconds or constitute real scanner execution. The selected cases all passed. The CLI error/refusal probes are expected negative partitions, not failures to rerun.

## Findings, allocation and limits

No blocking or nonblocking defect found in approved behavior. Examined accidental budget weakening, hidden successful planning, dirty-source admission, unavailable/empty cases, partial inner-timeout evidence, wrong wrapper accounting and caller omission. No implementation/test fix is proposed.

Existing case allocation follows SITE-CHECK-PROFILES: source-runner failure/complete-accounting cases → tests/test-profile-selection.test.cjs; inner-vs-outer timeout evidence → tests/publication-records.test.cjs; immutable producer/consumer report agreement → tests/prepublication-reuse.test.cjs. These existing registered source suites route through the source runner PR/staging/production selection and Basic/source site-checks/checks, staging site-color-review/build and reusable site-release-checks/build. The production/staging plan observation confirms registered selected inventory, not source execution. No duplicated campaign or new regression is proposed. Native full source/profile/hosted runs, RI freshness and exact final commit acceptance remain orchestrator-owned pending checks.

Concurrent metadata finalization was observed: .github/repository-paths.json differed from supplied packet and .github/ri-ci-map.json became dirty (digest/input identity refresh). Neither is silently asserted reviewed at supplied byte identity. repository-paths diff at final inspection is12added catalog lines; ri-ci-map diff changes reviewed-source digest/input hashes. Their final provenance/RI checks must be verified on final source; no executable drift was found. This allowed metadata finalization does not invalidate bounded executable/guide observations, but this result is not acceptance of unknown future metadata/source.

Manifest comparison differences at final result preparation:

```json
{
  "/workspace/scratch/2a813bd5ee7b/repo/.github/repository-paths.json": {
    "packet": "e23fccc8d7c97f4bc06c570de49c2076dace669a589f6eb35dae6de57e967f02",
    "inspected": "2ad3399d662306806f8d5b51418aabdccf2565f4bb6c13795b8271ae08e97f4d"
  }
}
```

Inspected manifest path/hash identities after interactions:

```json
{
  "/workspace/scratch/2a813bd5ee7b/intent.txt": "913f91238a13856215adaeef19eee53e1f1bf3cf048e1b6918e8eed184c6a11e",
  "/workspace/scratch/2a813bd5ee7b/repo/.github/ACCEPTANCE.md": "6469a66a36171404ce8448d75c3c5d96dc43563c76af41d4d2367598836fcaa8",
  "/workspace/scratch/2a813bd5ee7b/repo/.github/acceptance/issue-169.json": "8792a5dfca5eefebbdd1ab2f65a641179c6a87253d4906028f0b3cb7f3532471",
  "/workspace/scratch/2a813bd5ee7b/repo/.github/repository-paths.json": "2ad3399d662306806f8d5b51418aabdccf2565f4bb6c13795b8271ae08e97f4d",
  "/workspace/scratch/2a813bd5ee7b/repo/.github/workflows/site-checks.yml": "9e5167051fe15c71224ff51ae8e453caf078538ab6d9666541f0e794c62fdbff",
  "/workspace/scratch/2a813bd5ee7b/repo/.github/workflows/site-color-review.yml": "fc5861456ad5240f1179a68c127593265bc883bac0adebb65cc016d9bcdd76bc",
  "/workspace/scratch/2a813bd5ee7b/repo/.github/workflows/site-release-checks.yml": "f05ce4a8fbc8bb93f540726d35b9acba344ec0dcb5a3c1b8dcb2ae58014a077d",
  "/workspace/scratch/2a813bd5ee7b/repo/AGENTS.md": "ad4f179ec04c7af12867229d70598a660c5ae41f3cb456cafd02aca3d12a9988",
  "/workspace/scratch/2a813bd5ee7b/repo/CONTRIBUTING.md": "804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442",
  "/workspace/scratch/2a813bd5ee7b/repo/agents/reviewers/README.md": "2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb",
  "/workspace/scratch/2a813bd5ee7b/repo/agents/reviewers/code-review.md": "26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697",
  "/workspace/scratch/2a813bd5ee7b/repo/agents/reviewers/exploratory-interaction-qa.md": "280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a",
  "/workspace/scratch/2a813bd5ee7b/repo/agents/reviewers/requirements-acceptance.md": "010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6",
  "/workspace/scratch/2a813bd5ee7b/repo/agents/reviewers/white-box-qa.md": "832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f",
  "/workspace/scratch/2a813bd5ee7b/repo/guides/SITE-CHECK-PROFILES.md": "e60dd82f5d3090398a51be5b3181fa3d81737947f8a73e5e4867755d88cf8aee",
  "/workspace/scratch/2a813bd5ee7b/repo/guides/SITE-STAGING.md": "3d03824d99b3387cd0561486d0ef65f03283cfa1ae3b761f84fd9ebb1a896758",
  "/workspace/scratch/2a813bd5ee7b/repo/review/issue-169/2026-11-07-source-timeouts.md": "ab133391d3279959351f203c113de9e4c854ff4586f4557366da79152ef91a8a",
  "/workspace/scratch/2a813bd5ee7b/repo/tests/prepublication-reuse.test.cjs": "4373bf79fbe598cf757c0c0acacfbee33f0471c541cc2b91fb66de3290cee2df",
  "/workspace/scratch/2a813bd5ee7b/repo/tests/publication-records.test.cjs": "2b01019eceb40b56e5133a97c509977833aed8a7b0f835b6d4e05c54a7172105",
  "/workspace/scratch/2a813bd5ee7b/repo/tests/test-profile-selection.test.cjs": "ac74d0142245f53264924557febfbaf8d8c7698e35eeac4c2469e5211b7cead5",
  "/workspace/scratch/2a813bd5ee7b/repo/tools/quality/README.md": "104105ed0384a7a1846e355bf1ee1991fac146383d8c052667507eb206e90da9",
  "/workspace/scratch/2a813bd5ee7b/repo/tools/quality/source-tests.cjs": "d9a870982b7ec3698696ce2192c0cfc25ae156785f9ab7cfaa3507c0fd2338cf",
  "/workspace/scratch/2a813bd5ee7b/reviews/candidate.diff": "1a0e39ebb525257c1bee7727fe35d5be35b5d90e0fe97d3e11ff0592e6877129",
  "/workspace/scratch/2a813bd5ee7b/reviews/issue169.json": "05dab249efb8cb930ae8e830e60a80c9efbc7f4af60aa626489e459d83c3a474"
}
```
