# Requirements & Acceptance — final scoped candidate review

Role/execution: distinct nonauthor `/root/timeout_requirements`, continuation of its own preflight. First result remains intact at `reviews/requirements-first.md`. This final is a correction/final continuation, not a newly fresh execution. No peer outputs or parent conversation were consulted; the candidate's own change record was inspected as review subject, not accepted as proof. No implementation/tests, external services or delegation were used.

## Verdict

**PASS for the bounded timeout requirements and their acceptance linkage in this prepared candidate; no remaining blocking requirements findings.** This is source-level requirements acceptance, not whole-issue acceptance, readiness, measured runtime success or staging/publication proof. AC05/AC11 remain pending their complete required checks/roles/gates; AC09/AC10 still need actual served R10 reader/PDF/related-reading observations. No issue criterion is newly tickable from this result.

The complete supplied issue169 body is now available (snapshot `updated_at: 2026-11-07T01:31:37Z`) and its original AC05/AC11 obligations agree with the policy's independent review/source-evidence gates. Its historical scope amendments preserve the existing publication route and the current STOP/show endpoint. The separately supplied explicit user timeout approval in `intent.txt` permits the specific timing exception; it does not waive exact-source review, protection or delivery evidence. The live issue snapshot predates this timeout amendment, so append the dated authorized decision and its review/check reference through the normal issue route before claiming a complete AC05 handoff. This is evidence bookkeeping already required by the repository protocol, not a new owner permission request or implementation defect.

## Preflight dispositions

| First finding | Actual final source inspected | Disposition |
| --- | --- | --- |
| Additional PR Basic caller otherwise retains a shorter effective source allowance | `.github/workflows/site-checks.yml` checks job now20min; `site-color-review.yml` build now20min; `site-release-checks.yml` build now20min. No other jobs changed. | Resolved. The affected parents permit the approved source cap and reporting grace. Actual total duration still must be observed; twenty minutes is a cap, not a completion guarantee. |
| Owner prose says all hard timeouts unchanged | `guides/SITE-STAGING.md` and `guides/SITE-CHECK-PROFILES.md` explicitly name the7November600s source/20min parent exception; `tools/quality/README.md` agrees. Scanner180s, reporting30s, browser/site budgets and15min operational target retain their distinct meanings. | Resolved. No new performance relaxation or retry policy is implied. |
| Full authoritative owning AC text absent | `reviews/issue169.json` contains original full AC01–11 and dated amendments. AC05 requires exact identities/receipt/checks/four roles; AC11 requires explicit actual roles/executions/author decisions. | Input gap resolved for this scoped review. Whole gates remain pending, as intended. |

## Requirement → oracle/gate → observation

| Requirement / affected AC | Check or gate | Observed final candidate and limits |
| --- | --- | --- |
| Approved source limit10min | Canonical export plus existing process/report test oracles | Direct read-only Node observation returns `timeoutMs:600000`, `reportGraceMs:30000`, `maxBufferBytes:16777216`, wrapper630000. Only the source deadline changes in `source-tests.cjs`. |
| Separate wrapper/report allowance | Existing publication-records and prepublication-reuse tests | Updated expected values600000/630000 retain the independent30s relation; the timeout regression still requires false pass, ETIMEDOUT, original partial TAP/stderr, wrapper failure and180000 for other guards. Tests were inspected, not executed by this reviewer. |
| Preserve selected tests, refusals/accounting and bounded resource behavior | Source-selection/process tests, actual native source result, unchanged owners | Diff changes only existing expected timing constants/messages in three test files. No assertions/cases are removed. Worker, selector registry, `local.cjs`, prepublication runner and budgets are byte-identical to base. Existing skip/unavailable/empty/accounting/source-mutation failures remain. Their execution remains a separate gate. |
| Preserve R10/site/docs and hosted semantics | Full diff, final native source/artifact binding and actual stable staging | Prepared tracked diff has no site/docs path or hosted case/budget change. No new source-cost optimization, framework, concurrency or scanner-policy amendment appears. Actual integration/served-byte evidence remains pending. |
| AC05 source-bound hygiene | Existing CURRENT-RI/RI-CI/STYLE; native Basic and owning checks; explicit roles/delivery gates | CS01/04 canonical ownership, CS05 focused changes, CS07 finite allowances, CS08 existing behavioral regressions, CS09 guard limits and CS10 traceability are mapped in the candidate change record. No deterministic execution receipt was supplied/claimed as this review's observation. |
| AC11 actual role/review ownership | Four distinct completed source-bound executions and required author/protection decisions | This file is only the Requirements result. Other role completion, launch acceptance and provider internals are not established by this file. Preserve exact final candidate comparison after metadata/receipt work. |
| AC09/AC10 endpoint | Normal full stable staging, desktop/mobile/no-JS reader and five-page PDF/content/related-link inspection | Not observed here. Current intent remains STOP/show after actual verified stable staging; PR170 merge and production are excluded. |

## Inspected identity and limits

Prepared base HEAD `550c7f242b88870796f3920332e620ff4e4ca795`. This is a dirty prepared candidate, not a clean committed final head. At inspection the tracked changes are repository catalog, the three named workflow parents, profile/staging/quality owner prose, three timing-oracle test files and the canonical source timeout. One untracked authored timeout change record is included by manifest. No untracked file was silently called committed evidence.

- Candidate manifest SHA-256 `8a39b499f332d3989e9ab2634543fa76cdf72032ba4ac81c6bb8655c636b3f4e`: all24 listed path bytes matched on independent verification.
- Supplied diff SHA-256 `1a0e39ebb525257c1bee7727fe35d5be35b5d90e0fe97d3e11ff0592e6877129`; actual Git changed-path inventory inspected and consistent with the timeout change plus catalog work.
- Full issue snapshot SHA-256 `05dab249efb8cb930ae8e830e60a80c9efbc7f4af60aa626489e459d83c3a474`.
- Intent SHA-256 `913f91238a13856215adaeef19eee53e1f1bf3cf048e1b6918e8eed184c6a11e`.
- Common contract SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA-256 `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. Both remain byte-identical to the already read mandatory contracts.
- Canonical source-test candidate SHA-256 `d9a870982b7ec3698696ce2192c0cfc25ae156785f9ab7cfaa3507c0fd2338cf`; full per-path identities are preserved by the verified manifest.

Unchanged evidence reused only for source constraints directly compared against base: worker, local wrapper owner, prepublication runner, test-profile registry, budgets and acceptance policy. The first review's caller/prose assumptions were rechecked against actual changed bytes. The source-manifest/catalog's Unicode-escape normalization is semantically mechanical; new timeout evidence entries carry no executed-test claim by their presence. Final generated catalog/RI/receipt bytes may still change and were not treated as already complete.

No runtime campaign or tests were executed. One Node export observation, hash comparisons, Git status/diff inventory and source/oracle inspection establish this bounded verdict. They do not establish native CPU adequacy, CI20min completion, actual remote protection state, launch isolation attestation, hosted Pillow behavior, browser performance or reader/PDF correctness. Recompare inspected executable/config/test bytes to the final candidate; material changes require affected re-review. Next gate: actual remaining four-role/check receipts and exact-source native/controller staging through the existing protection route, then full R10 stable staging and STOP/show.
