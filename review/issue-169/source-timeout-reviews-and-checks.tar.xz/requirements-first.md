# Requirements & Acceptance — first preflight result

Phase: preflight, no implementation changed. Role: Requirements & Acceptance, distinct nonauthor task `/root/timeout_requirements`. Repository HEAD observed `550c7f242b88870796f3920332e620ff4e4ca795`; `git status --short` produced no entries. Scope: the approved 300000 → 600000 ms source-runtime allowance and 10 → 20 minute enclosing build allowance, prerequisite integration and full stable staging, then STOP/show. No PR170 merge or production action is authorized by this packet.

## Verdict

The bounded timeout intent is clear, necessary as an explicit owner choice, and independently assessable. It changes an execution allowance, not the definition of test success or website performance. **Preflight identifies an affected-caller requirement that must be treated in implementation; completed-candidate acceptance remains pending.** Full issue AC acceptance is not established: the packet contains the issue policy but no live or explicitly dated complete issue-169 body/AC pass-condition snapshot. I cannot compare the policy to that absent owner text. Obtain/retain that primary authority for final whole-AC claims; this is not a request to invent new intent or permission.

No implementation, tests, external state or peer verdicts were read/written outside this assigned source scope. No delegation. No tests executed; this is bounded requirements/source inspection, not a runtime result.

## Findings and required treatments

1. **Medium — affected parent can still cut off the newly allowed source runtime.** `site-checks.yml:19` retains a 10-minute job while lines 103–120 invoke `local.cjs --delivery` and the shared source runner. Setup, formatting and lint consume that same job budget; the 600000 ms child allowance plus reporting cannot fit in 10 minutes. `site-color-review.yml:205` and `site-release-checks.yml:152` are likewise enclosing build owners; both run source/prepublication checks. Updating only the controller's build leaves shared-runner consumers with a shorter effective allowance and risks losing final accounting/artifact upload. **AC05** exact-source native check evidence and preserved failure evidence are affected. Treatment: explicitly account for all these affected callers in the proposed change/requirements disposition. Apply the approved enclosing allowance where the requirement is intended to hold, or document a defensible narrower caller scope with its existing operational limit; do not silently describe every shared caller as having ten runnable minutes. Non-source jobs with unrelated 10-minute budgets do not thereby need changes.

2. **Low — prose currently says all hard timeouts remain unchanged.** `SITE-STAGING.md:397` and `SITE-CHECK-PROFILES.md:263` preserve worker/scanner limits. The approved exception supersedes only the shared source execution cap and relevant enclosing build cap. Treatment: make that narrow exception explicit in the affected owner prose. Preserve the 15-minute end-to-end optimization target and its distinction from hard site/browser budgets; actual duration must be measured, not inferred from the increased timeout. **AC05** consistency/evidence is affected.

3. **Evidence limit — original full owning AC text unavailable.** `.github/acceptance/issue-169.json` supplies AC05/AC11 intent plus external gates, not the authoritative complete issue body. The policy itself says deterministic RI/style results do not prove delivery, review or semantics. Final acceptance must reference the live/dated original pass conditions as well as this policy; no whole AC can be ticked from this preflight. **AC05/AC11** remain pending, as do AC09/10 reader/PDF observations.

## Intent/AC → check/gate → observed source

| Obligation | Independent check or gate | Current observation / acceptance limit |
| --- | --- | --- |
| 5 → 10 minute source cap | Inspect canonical `executionLimits`; exercise existing process/report regressions | `source-tests.cjs:10` is still 300000. Existing report assertions at test-profile-selection lines 1335/1441 encode 300000 and must follow the approved value. No execution yet. |
| Parent allows source completion and reporting | Inspect callers, wrapper relation and exact CI execution | `wrapperTimeout()` is source cap + 30000; `local.cjs` derives the source task bound through it. Other guards retain 180000. Do not introduce a second competing hard-coded source timeout. Build parents and site-checks are currently ten minutes. |
| Preserve full selected cases/accounting/failures | Existing source-selection, unavailable/empty/skip, timeout, mutation and raw-stream tests; final native source accounting | Tests already reject skipped/unavailable/empty or incomplete accounting and retain timeout streams. Worker preserves all selected files, priority order and concurrency cap four. Static inspection only; preserve these bytes/semantics except bounded oracle changes. |
| Preserve host/site/performance constraints | Existing hosted staging/production profiles and size/performance/scanner checks | No site-budget relaxation is within scope. The 15-minute operational target is nonblocking optimization feedback; the hard product budgets remain required. |
| AC05 source-bound hygiene/style | CURRENT-RI, RI-CI, STYLE and independent/delivery gates from issue policy | Relevant CS01/04 owner and single-limit concerns, CS05 readable authored code, CS07 measured speed/bounded resources, CS08 proportional verification, CS09 guard limits and CS10 issue/AC/PR evidence obligations must be mapped in author evidence. No check executed and no pass claimed. |
| AC11 actual independent roles | Four distinct completed source-bound role results, isolation/execution receipts and correction treatment | This file supplies only one role's preflight. Runtime/provider internals and parent launch record are not independently observable here. No inference from a role name or digest alone. |
| Stable staging then STOP/show | Exact-source native checks, actual staging gate/promotion, reader/PDF inspection | Historical runs in intent are historical evidence only. New candidate and actual reader/PDF remain unobserved. Whole delivery and issue closure are not authorized by this result. |

## Next gate and inspected identities

Implement the bounded requirement with the caller/prose treatment, then provide completed exact diff, source-bound tests and actual checks for final review. Preserve source-test timeout failure as failure; keep 16 MiB buffer, 30000 ms report grace, worker concurrency, module inventory, scanners, refusals, rights and promotion protections. Integrating PR174 or rebasing creates a changed candidate that requires source-bound verification and four completed role results before advancement. Do not reuse old green staging as proof of the new source.

Input intent SHA-256 `913f91238a13856215adaeef19eee53e1f1bf3cf048e1b6918e8eed184c6a11e`. Preflight manifest SHA-256 `430f9f73d30ade5a3d659c1ee923a438fe9a0ad1063869c3dae441fcde963aac` was read and its cited paths inspected; the additional necessary owners below are explicitly identified by inspected bytes. No peer outputs, unrelated memory or parent conversation were consulted.

- `agents/reviewers/README.md` SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`
- `agents/reviewers/requirements-acceptance.md` SHA-256 `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`
- `AGENTS.md` SHA-256 `ad4f179ec04c7af12867229d70598a660c5ae41f3cb456cafd02aca3d12a9988`
- `CONTRIBUTING.md` SHA-256 `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442`
- `.github/ACCEPTANCE.md` SHA-256 `6469a66a36171404ce8448d75c3c5d96dc43563c76af41d4d2367598836fcaa8`
- `.github/acceptance/issue-169.json` SHA-256 `8792a5dfca5eefebbdd1ab2f65a641179c6a87253d4906028f0b3cb7f3532471`
- `tools/quality/source-tests.cjs` SHA-256 `792aec87f4abb3aec8c97b4a8d33cd958a643b8f6c77aaac4c5683d45aaf5086`
- `tools/quality/source-test-worker.cjs` SHA-256 `fb99cd3aacc0e98470fcf2a4cc50fd159a54d9705bb422824fc9842c43b63945`
- `tools/quality/local.cjs` SHA-256 `ea8550ebac5b2f62147c60c8e0b70a54f6e60d20643cf190ec45c6a5d693f96d`
- `tools/quality/prepublication-runner.cjs` SHA-256 `46038e1ba99fa96975c6b9b103483e52d5273407bd56edc0d52a24456337d102`
- `tests/test-profile-selection.test.cjs` SHA-256 `08e0ac9bce886f3d58923d43f8c1563144e17b8cd02f96bca16b12fa08fed1af`
- `tests/staging.test.cjs` SHA-256 `ecf337f9e72cc47caf87e2e384f78184583706a76f9b18717dfa8ddb5582b3b4`
- `.github/workflows/site-color-review.yml` SHA-256 `d184fb3e54d5c3a42901f10597313e4cd4da0f5d3d51cb0f7ba3ab30a9f4dbe2`
- `.github/workflows/site-release-checks.yml` SHA-256 `0f35df2fde69e851e05518db0dc46d70fb91216a7ba9cdddcabe35b1e9675d4d`
- `.github/workflows/site-checks.yml` SHA-256 `6ec06f40b53f23631a282adbcd38d42e6637b74e244851adb95dbfdebb523dcd`
- `.github/workflows/site-staging.yml` SHA-256 `6e52d1ed8fa57bb5609bafed212da26c393596fc101d2387427526fab3e0a895`
- `guides/SITE-STAGING.md` SHA-256 `44c37986027125585e54787337da6debdd014b0b5b70c87518f92ed74d62f63a`
- `guides/SITE-CHECK-PROFILES.md` SHA-256 `8aaec290895f365599e9d5f8cdc2b513a1334c2aae572cd3da8fc55f6ae3699e`
- `guides/CODE-STYLE.md` SHA-256 `cdef877504055734d653af12237fc708f3e3636dd15dfc0703f71e0f6c87ee40`
