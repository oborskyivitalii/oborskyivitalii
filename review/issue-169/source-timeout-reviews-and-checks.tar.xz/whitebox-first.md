# White-box QA — first independent result

Verdict: **PASS for the bounded prepared timeout behavior; no blocking findings.** This does not establish native final-head acceptance, whole issue acceptance, or actual staging/reader/PDF acceptance. Final metadata drift is disclosed below.

## Identity and inspected scope

Role/task: White-box QA, `/root/timeout_whitebox`, first judgment. No delegation, implementation/test edits, external writes, parent scratch/history, peer output or unrelated MEMORY reads. Inspected supplied intent and captured issue169, README, AGENTS/CONTRIBUTING, common/role prompts, acceptance policy, relevant repository map/RI ownership and affected quality/profile/staging sources. No applicable nested AGENTS was found in affected source areas. Candidate self-analysis claims were review subjects, not trusted verdicts.

HEAD `550c7f242b88870796f3920332e620ff4e4ca795` plus dirty prepared delta, not a clean checkout. Manifest SHA256 `8a39b499f332d3989e9ab2634543fa76cdf72032ba4ac81c6bb8655c636b3f4e`; diff SHA256 `1a0e39ebb525257c1bee7727fe35d5be35b5d90e0fe97d3e11ff0592e6877129`. Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`. All 24 manifest entries matched initially. At final inspection only `.github/repository-paths.json` differed; exact observed digest is retained in `whitebox-inspection.log`. Thus behavioral findings bind to unchanged reviewed executable/test/workflow bytes; final metadata completeness remains separate.

Actual launch parameters/accepted receipts are the orchestrator's separate evidence. Provider model/context/memory internals are not independently observable by this reviewer. Shared filesystem is not isolation.

## Structure and bounded risk matrix

The changed executable limit at `tools/quality/source-tests.cjs:10` is 600000 ms. `executeSource` supplies it to `spawnSync`; unchanged `wrapperTimeout` adds 30000 ms, producing 630000 ms. `local.cjs` chooses that wrapper only for source tests and leaves other guards at 180000 ms. The three actual source-containing jobs parse to 20 minutes. Their existing failure artifact upload conditions retain `always()`.

One batch, selected-path validation, strict accounting, source stability and raw failure retention remain intact. `run` persists original stdout/stderr before status/accounting assertions can throw; timeout and incomplete/skip/fail/mutated-source branches cannot turn green. Worker scheduling and the four-worker ceiling are unchanged.

| Risk / AC | Structural scenario and independent oracle | Actual check and allocation |
| --- | --- | --- |
| Allowance and wrapper / AC05 | Inner timeout is 600000, outer 630000, other guards 180000; injected ETIMEDOUT stays failed and retains original TAP/stderr in staging and production | `publication-records.test.cjs` inner-timeout case, passed; source profiles, staging/release build |
| Raw evidence / AC05 | Real failing process retains original >8000-byte output, exit 1 and failed structured report | `test-profile-selection.test.cjs` explicit source report, passed; PR/source profiles |
| Accounting / AC05 | Skip/TODO/cancel/missing/duplicate/partial/empty cannot pass; selected native leaf cases remain present | Existing TAP/accounting, one-execution and report cases, passed; PR/source profiles |
| Mutation / AC05 | Changed source after execution stays failed despite otherwise passing child | Existing explicit report case, passed |
| Cancellation/overflow / AC05 | Actual bounded native 500 ms timeout, overflow and abort fail with retained partial streams; SIGTERM/SIGINT reap owned children | Existing asynchronous guard and source cancellation cases, passed |
| Worker limit / AC05 | Maximum four simultaneous files while queued selected cases complete | Existing simultaneous-file scheduler case, passed |
| Caller closure / AC05 | Actual enclosing jobs each allow 20 minutes | PyYAML parsing: site-checks/checks, site-color-review/build, site-release-checks/build; all assertions passed; native workflows pending |
| Producer/consumer / AC05 | Real preflight producer/consumer agree on inventory, immutable evidence and derived wrapper | Existing actual producer case in `prepublication-reuse.test.cjs`, passed |
| Source binding / AC11 | Detect shared-tree drift rather than presenting stale bytes as current | Initial 24/24 match; final metadata-only drift disclosed and retained |

## Executed evidence

Pinned runtime `/workspace/scratch/2a813bd5ee7b/node-v24.19.0-linux-x64/bin/node`, observed v24.19.0.

1. `node --test --test-name-pattern='explicit source reporting|explicit reports preserve|one source execution retains|TAP accounting rejects|prepublication preserves inner source timeout|actual preflight producer' tests/test-profile-selection.test.cjs tests/publication-records.test.cjs tests/prepublication-reuse.test.cjs`
   Exit 0; 6/6 passed, zero fail/cancel/skip/TODO; 1234.371815 ms. Raw evidence `whitebox-check.log`.
2. `node --test --test-name-pattern='asynchronous native guard limits|source scheduling cancels owned child processes|source scheduling caps simultaneous' tests/publication-records.test.cjs tests/test-profile-selection.test.cjs`
   Exit 0; 5/5 reported tests passed (three top-level cases including two signal subcases), zero fail/cancel/skip/TODO; 686.330524 ms. Raw evidence `whitebox-check-boundary.log`.
3. Independent YAML parsing and digest inspection passed, subject to disclosed final catalog drift. Receipt `whitebox-inspection.log`.

## Limits and dispositions

No branch instrumentation or coverage percentage was measured. Injected timeout verifies failure/report propagation without waiting ten minutes; actual 600-second wall-clock expiry is source/option inspection, not a ten-minute execution. The independent actual 500 ms native timeout and signal cases exercise termination. Existing fixture tests wrote only temporary directories; no accepted source/tests were authored.

Full source campaign, hosted workflow cancellation/upload, final generated RI/catalog completeness, scanners, final native head and actual R10 staging/reader/PDF were not executed. Product UI changes are absent. AC09/10 remain with actual delivery owners; this bounded role contributes AC05/11 evidence without completing whole criteria. Job-wide 20-minute ceilings cover setup and all guards and do not guarantee every independent guard can consume its individual maximum. Later catalog/RI/receipt finalization is acceptable only without behavioral change and must not overstate this observation; changed relevant source needs affected re-review.
