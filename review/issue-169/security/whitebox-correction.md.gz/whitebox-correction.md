# White-box QA — targeted correction review

**Verdict: RQ-F1 storage-wrapper repair verified; metadata closure still blocked by WB-C1 below.** This is a same-role continuation after my preserved first judgment, not a fresh independent execution or a full security/release pass.

Candidate packet `/workspace/scratch/f4dcb060a703/security-review/candidate-v2.json` SHA256 `5bc4016c79109d2b0a8671cd41807dd7aeb154cde4b67d4da6738aa407a9db72`; prepared tree `0aea2dcd15d8e870a945bd3bb4a44f3f172bdf40`; base `95d3e78d7e76d3e267351b8ca1efff206f99b748`. This remains a prepared subset, not a clean checkout. Common/role prompts and their identities are unchanged from my first output.

## WB-C1 — Medium: new execution receipt omits Requirements' disclosed write-tree deviation

Location: `review/issue-169/security/reviewer-executions.json.gz`, decoded line24, `launches[0].deviation`, records `None reported.` for Requirements. The retained `requirements-first.md.gz` explicitly states on decoded line14 that its diagnostic invoked `git write-tree`, which can materialize a Git object, and that no index/worktree content changed. The same new execution metadata correctly records this issue for Code on decoded line46 but omits the Requirements execution's equivalent disclosure.

Mechanism and AC impact: a completed report's disclosed capability deviation is lost when mapped into the canonical per-execution receipt. The reviewer contract requires requested/accepted/observed facts and actual limitations; AC05/AC11 cannot treat this receipt as complete accounting of the first executions. This is an evidence-metadata defect, not evidence of source/test/policy alteration or conversation contamination. I did not invoke `git write-tree` in either white-box phase.

Treatment: preserve all first outputs and correct the Requirements deviation field to faithfully record the observed command and its stated no-content-change boundary. Align any summary purporting to list all read-only deviations and obtain affected metadata readback. No scanner rerun is required for that deterministic disclosure. The orchestrator decides protocol disposition using actual capability facts; a changed role label or my result cannot erase the deviation.

## Independently verified closure and invariants

| Case / protected invariant | Executed result |
| --- | --- |
| Exact candidate byte identity | All167 repository pins and both external pins match actual SHA256; no removed v1 pin |
| Old failed provenance retained | `provenance-v1-stale.json.gz` archive SHA256 exactly matches the original v1 provenance pin |
| Repair is deterministic | Deep comparison of decoded old/new provenance shows exactly two changed values: receipt5 archiveSha256 and decodedSha256; all other fields unchanged |
| Correct final storage manifest binding | Compressed SHA256 `74ed76ec554fcb5830d3d904b4b665ff68d28fa7312fa166a8439a05f6589647`; decoded SHA256 `ca4f2fa84e859b5eacc6aa00db7ddc39293e21b7b38fb713ab25e7eaa6b63b41`; both match corrected wrapper |
| All receipt bindings, not only changed entry | All8 compressed and decoded SHA256 pairs match; each decoded target equals the corresponding original source bytes, decoding the original source where explicitly gzipped |
| Fault sensitivity | The same comparison rejects the preserved stale wrapper's actual historical-storage hash bindings and accepts the corrected8/8 wrapper; no files mutated |
| Original raw failure retained | Actual failed ZIP SHA256 matches artifactSha256 and its detect-secrets.json digest matches rawDetectSecretsSha256 |
| Verbatim first outputs | Four compressed first outputs decode byte-for-byte to their actual original local outputs; all4 decodedResultSha256 fields match; archived v1 packet is verbatim |
| Reuse of first-phase white-box observations | All45 overlapping relevant tools/tests/prompts/security core-evidence pins are unchanged; prior50-archive byte equality, exact admission and targeted negative results remain scoped to those unchanged inputs |

V1→v2 pin changes are the provenance wrapper, dated report and four RI/navigation views, plus seven added receipt/history files. Actual policy, ledgers, proof, native producer evidence, scanner/rules/tests and the50-report storage manifest are unchanged. I rehashed these sources rather than relying on the author's delta description. My original `whitebox-first.md` remains unchanged, SHA256 `5fc35c26dcaf434adb00e67381c9f7088daf53183e0e840480c1f4077f43e22d`.

Executed bounded Python stdin diagnostics from the repository used hashlib, gzip, JSON comparison and ZIP reads only; all commands exited0. No whole scanner, source suite, browser or18-case campaign was rerun, because their inputs are unchanged. No Git-object, repository, source/test/policy or external writes were performed; only this assigned correction report is written.

## Chronology and real limits

My first output was preserved before reconciliation. During this continuation I read the new execution metadata, my own verbatim receipt, the dated factual summary, and Requirements' completed first finding/disclosure. That post-first exposure is declared; it does not retroactively become a fresh context. The RQ-F1 repair conclusion above comes from actual byte comparisons. Peer verdicts were not adopted as proof of data correctness.

Requirements' RQ-L1 explicitly retains a semantic-classification coverage limitation. This correction does not claim to close that cross-role obligation, replay nine producers, prove the eight generated exclusions or reconstruct unavailable archival artifacts. My prior executed per-ID/span/referent checks and their precise limits remain unchanged. Any genuinely unresolved classification or source dependency remains blocking until actual relevant evidence addresses it; no consensus or `blocked:0` field resolves an unknown.

Provider context/model internals and any OS/provider isolation remain unknown. Added launch metadata records requested none-fork parameters and returned task names; it is not provider attestation. Staging/full regression, protected integration, production rights/archive and actual served delivery remain unobserved here and mandatory. RQ-F1 alone is closed from this white-box perspective; WB-C1 requires correction before the metadata can be treated as complete.
