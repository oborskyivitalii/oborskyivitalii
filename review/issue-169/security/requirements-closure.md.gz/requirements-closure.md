# Requirements & Acceptance — affected RQ-F2 closure

**Verdict: RQ-F2 closed. No remaining Requirements finding blocks this bounded metadata/security-maintenance candidate.** The original first judgment and correction report remain preserved. This is an affected same-role continuation, not a fresh reviewer execution, full scanner validation, hosted acceptance or publication approval.

## Exact inspected input

- Candidate-v3 packet SHA-256 independently recomputed: `40b82a1607e0b10be6ffa0ed8f53fb9afbfb3c705e338e78e139525590556ef6`.
- All 173 repository pins and both external pins matched actual bytes. Supplied prepared tree `904d4de3eba163d64180136f78b4baf1691d1615`; base `95d3e78d7e76d3e267351b8ca1efff206f99b748`. Prepared subset, not a clean checkout. This continuation did not recompute the Git tree/diff identity or invoke Git object-writing commands.
- Compared the v2/v3 pin maps: six changed metadata/navigation/report paths, six added packet/receipt/history files, no removed pin. Security data, proof/classifications, actual historical-storage manifest, scanners/rules/version/test/native/public inputs retain the previously reviewed identities. The earlier bounded evidence therefore remains applicable to those unchanged inputs.

## RQ-F2 repair and preservation

The current `reviewer-executions.json.gz` SHA-256 is `d907a137b86cca9139d22dbc83e9766bedfc94d6a5150f4c25b8c3c68f70cdeb`. Its Requirements row now explicitly records the diagnostic `git write-tree`, its ability to materialize Git objects, the failure to meet a strictly read-only Git boundary and the absence of reported source/test/policy/worktree/index-content edits. This agrees with the preserved Requirements first report. Code receives the same explicit disclosure; White-box/Exploratory fields refer to their verbatim executed diagnostics and limits rather than claiming blanket absence of deviations.

Independently decoded and compared the old/current execution objects: only the four `deviation` fields and `chronology` changed; role/task/requested fork/model/effort metadata, source/prompt/result bindings and other fields are equal. The inaccurate v2 wrapper remains at `reviewer-executions-v2-inaccurate.json.gz`, SHA-256 `185946e67df7bc768204974a3778364833a525f2086d658b8164cfa4c08b524a`, exactly the wrapper inspected in my correction report. The four correction archives independently decode byte-for-byte to the four actual local correction reports. Archived candidate-v2 likewise equals the original v2 packet bytes.

All four current first-result digest bindings still match actual decoded first outputs. The dated report explicitly explains both Requirements and Code disclosures, preservation of the inaccurate wrapper and the metadata-only treatment. This repairs the inaccurate summary without changing or concealing the underlying execution fact. RQ-F2 is closed on source/evidence comparison, not a vote or inferred risk waiver.

## Remaining conditions and limits

RQ-F1 remains closed: independently rechecked all eight corrected provenance compressed/decoded hash pairs, all passing. RQ-L1 retains the bounded factual reconciliation and semantic/archival limits described in `requirements-correction.md`; no newly unbound/nonpublic tuple or source/classification change was identified by this metadata delta. No exhaustive semantic reread, historical dirty/private artifact recreation, generated-proof regeneration or new native producer/scanner execution is claimed.

Provider model/context internals remain unavailable. Recorded actual none-fork launch is an operational isolation measure, not provider attestation or an OS sandbox. This continuation uses its own earlier judgments and declared post-first reconciliation sources; it is not a newly clean context. Only this assigned output was written; no implementation/test/policy/repository/external mutation or delegation occurred.

Actual resulting-head applicable CI/RI/checks, completed affected correction receipts, successful authenticated staging, identical-tree protected merge, production rights/archive and actual served article/PDF verification remain required observations. The original failed staging result remains failed. Author-manual platform publication and the later reciprocal-link pair keep their accepted separate scope. No whole publication AC, merge, production delivery or issue closure follows from this bounded review closure.
