# Exploratory / Interaction QA — targeted correction

Verdict: the affected developer/evidence retrieval flow is corrected. The current wrapper now authenticates the actual fifty-report storage manifest, and the obsolete wrapper remains recoverable. No new blocking finding reproduced in this targeted review. This closes the exploratory portion of the metadata correction; Requirements owns its original RQ-F1 closure. This result does not establish successful CI, staging, production or publication.

## Continuation and source identity

This is the same-role continuation of `/root/security_exploratory_final`, not a fresh independent execution. It received the factual correction description after its first result. Other roles' archived reports were inspected only for byte/hash preservation; their verdicts were not substituted for these checks. The original `exploratory-first.md` remains unchanged, SHA256 `f399c568f3525a2fa8a8b2f2094dcc13b9cdfbea4ea65da9b556d98862880240`.

- Packet `candidate-v2.json`: independently calculated SHA256 `5bc4016c79109d2b0a8671cd41807dd7aeb154cde4b67d4da6738aa407a9db72`.
- Prepared tree `0aea2dcd15d8e870a945bd3bb4a44f3f172bdf40`, base `95d3e78d7e76d3e267351b8ca1efff206f99b748`. Still a prepared subset rather than a clean checkout.
- All 167 packet path/byte pins independently matched. Common and role prompts retain their v1 identities and instructions.
- Three-minute charter: verify the two changed wrapper values, preserved obsolete evidence, lossless first results, discoverability through current indexes and unchanged substantive source. No repo/source/test/policy/Git-object writes, external writes or delegation. Only this assigned report is written.

## Executed checks and outcomes

| Expected operator outcome | Own action and observed evidence | Result |
| --- | --- | --- |
| Current wrapper binds the current evidence | Decoded `provenance.json.gz`; recomputed both archive and decoded SHA256 for every target in its eight receipt rows. Eight rows matched both hashes, zero mismatches. | Pass |
| Fix is limited to the observed inconsistency | Compared old and new parsed wrappers. Exactly two fields changed, both in receipt index5 for `historical-storage.json.gz`: `decodedSha256` and `archiveSha256`. All other parsed wrapper fields were identical. | Pass |
| Fifty-report identity is accurate | Decoded storage manifest contains50 records. Actual decoded SHA256 is `ca4f2fa84e859b5eacc6aa00db7ddc39293e21b7b38fb713ab25e7eaa6b63b41`; archive SHA256 is `74ed76ec554fcb5830d3d904b4b665ff68d28fa7312fa166a8439a05f6589647`. These equal the corrected wrapper values. | Pass |
| Original failure of evidence binding remains inspectable | Compared `provenance-v1-stale.json.gz` bytes against the original v1 tree's `provenance.json.gz` via read-only `git show`. Exact equality. | Pass |
| First results and their actual input survive reconciliation | Decompressed `candidate-v1.json.gz`: byte-identical to the original packet. For all four first-result archives, recomputed decoded hashes against `reviewer-executions.json.gz` and compared to their existing scratch result files. Four hash matches and four verbatim matches. No peer narrative was needed. | Pass |
| Operator can find current and historical evidence | Verified the repository map, path catalog and generated agent-context index each include the stale wrapper, execution manifest, exploratory first receipt and v1 packet archive. Dated maintenance report identifies RQ-F1, preserves the stale wrapper and requires affected verification before advancement. | Pass |
| Earlier substantive checks remain reusable | Compared v1/v2 packet pins and prepared-tree changed paths. Only six existing metadata/index/report files changed and seven packet/receipt archives were added. Bandit policy, all security ledgers, scanners, rules, toolchain requirements, per-ID proof, historical-storage manifest and all public source/runtime remain byte-identical. | Pass |

My first review independently verified all fifty decoded historical reports against Git but did not catch the stale outer provenance hashes. The corrected flow now verifies both layers. Its earlier archive equality, exact admission/expiry probes, source-span correspondence and eleven selected existing negative-control results remain evidence for unchanged bytes. They are not relabeled executions on a new hosted head.

The execution manifest records requested none-fork launches, accepted task names and lossless first results, and discloses the Code role's `git write-tree` diagnostic. I observed consistency of these recorded identities and receipt bytes; I did not independently observe provider internals or the original external launch events during this continuation. No provider isolation or model identity attestation is supplied.

## Disposition and limits

Retain these hash comparisons as targeted issue169 AC05/AC11 diagnostic evidence. No new suite or accepted regression was authored; no scanner, whole test suite or browser campaign was repeated. Existing test/profile/workflow dispositions and all first-result semantic-provenance limitations remain applicable. The two-wrapper-hash regression oracle is exact recomputation of both stored and decoded bytes whenever a referenced receipt changes.

Current-source hosted stage/full/regression, control admission, merge, production rights/archive, served article/PDF verification and later author-manual platform observations remain required and unobserved here. A prepared metadata correction and four preserved reports do not complete those gates.

Recorded UTC: 2026-11-06T10:32:07.679930+00:00
