# Independent Exploratory / Interaction QA — first result

Verdict: no blocking defect found within the bounded source/developer-flow charter. This is a candidate review result, not successful hosted delivery or permission to publish. AC05/AC11 remain dependent on the other required independent roles and the actual resulting-head checks; original publication ACs remain open until their real observations exist.

## Identity, source and independence

- Role execution: `/root/security_exploratory_final`; first independent result. No implementation, accepted tests, policy changes, external writes or delegation performed. Only this assigned artifact was written; executed fixture suites used their existing temporary directories.
- Packet: `candidate-v1.json`, SHA256 `6a785b2ed898c2d4561b768a0894bdb516d017f7115ed29ec2f5fe4ff868f512`.
- Prepared subset, expressly not a clean checkout: base `95d3e78d7e76d3e267351b8ca1efff206f99b748`, tree `bb277b3e0ea4f9277e17064f08a30f5286c1917b`; declared diff SHA256 `6957c545ac71ac7018fa27a590abd0848d836b570afdc390da115763aad96b32`. All 160 packet path/byte pins were independently computed and matched.
- Common prompt `agents/reviewers/README.md`: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/exploratory-interaction-qa.md`: `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`. Both read.
- Read original issue169 snapshot, original production intent and maintenance scope; README, root AGENTS, map, actual scanner/triage owners, policy and ledger metadata, relevant fixture tests and check-profile/CI routing. Proposed proof and maintenance claims were treated as candidate assertions. No MEMORY, current peer outputs, parent scratch notes or preflight reviewer Markdown was read. Archived historical reports were compared as bytes only, without reading their narratives as current judgments.
- The orchestrator must retain its actual none-fork launch receipt. This result does not attest provider model/context internals; they are unknown. The read boundary is operational isolation, not an OS sandbox or provider attestation.

## Charter and capabilities

Six-minute bounded charter: walk an operator from the failed security gate through exact renewal/admission, unknown/rejection handling, finite expiry, lossless historical evidence retrieval and onward release gates. Use the actual Node/Python source and temporary-fixture surfaces. No public UI/runtime changed and no local browser surface was supplied. A new browser campaign is therefore inapplicable to this correction; the actual hosted/browser/production gates are unobserved and still mandatory for the overall website release.

Original outcome remains accepted R10 article/PDF/visuals published by the existing controller, site-first verification, then manual LinkedIn/Medium publication by the author. This correction may repair security data/storage only; it cannot replace native/article/PDF acceptance, source-bound delivery, publication rights or served-edition verification.

## Own executed exploration and evidence

| Journey / oracle | Action and actual observation | Result |
| --- | --- | --- |
| Source-bound entry | Computed packet SHA256 and all 160 supplied file pins. All matched. Inspected base-to-prepared-tree changed paths rather than claiming a clean checkout. | Pass |
| Real failed findings admitted by current finite review | Called the unchanged `bandit-triage.review` against decoded `failed-bandit.json.gz`, actual current policy and complete report file inventory. At `2026-11-06T12:00:00Z`: 48 raw / 48 reviewed. | Pass |
| Deadline boundary and recovery requirement | Repeated the same read-only call at `2026-12-06T23:59:59.999Z`: admitted 48/48; at `2026-12-07T00:00:00Z`: rejected with `Bandit review expired: tools/check_repository_layout.py:B404:12`. Deadline still requires renewed review after expiry. | Pass |
| Wrong source / finding / coverage / malformed inputs | Ran existing selected fixture tests, including source edits, shifted lines, symlinks, new/missing/duplicate scanner findings, severity and coverage errors. Those negative inputs remained rejected. | Pass |
| Exact secret admission; unknown fields cannot borrow known hashes | Existing closed-ledger and generated-field fixtures reject wrong path/rule/hash, malformed metadata, duplicate IDs, invalid/oversized/symlinked inputs, arbitrary fields, same-value prose/external URLs and unauthorized article-resource owners. | Pass |
| Proposed proof identifies actual source bytes | Independently read each record's current source and hashed every declared UTF-8 occurrence span. 1,181 spans across 1,025 records; zero SHA1 mismatches. This establishes literal/source correspondence, not automatic acceptance of claimed provenance. | Pass, bounded oracle |
| Predecessor and frozen truth | Independently compared companion row prefixes against base Git: publication 3,630 retained + 1; checksum 2,135 retained + 1,016. Prefix objects/order were identical. Frozen baseline and historical reviewed ledger bytes matched base Git exactly. Bandit retains 48 entries; its intentional renewal is not claimed prefix-identical. | Pass |
| Retrieve archived evidence without rewriting history | Independently decompressed all 50 historical paired reports and compared against exact base Git bytes. 50/50 exact. Every original-path stub names its existing gzip; tested stubs explain decoding and link the storage proof. Stubs themselves do not embed immutable commit references; the linked manifest carries those identities. | Pass |
| Preserve accepted reader artifact/runtime | Base-to-prepared-tree path inspection found no changed `site/`, `docs/`, `tools/site/` or `tools/release/` paths. No browser/PDF visual observation or new hosted delivery is inferred from this. | Pass for unchanged-source boundary |
| Release operator handoff | Candidate report and evidence README explicitly keep failed staging, skipped publication, prepared-local checks and future resulting-head staging/production separate. They retain author-manual external posting and later reciprocal-link update. | Pass for readable protocol |

The exact executed existing-suite command was:

```sh
node --test --test-name-pattern='Bandit admission|closed secret ledgers|secret ledgers reject|secret ledgers require|generated checksum collection rejects|article resource names|only actually verified RI' tests/quality-sources.test.cjs
```

Observed Node output: 11 tests, 11 pass, 0 fail/cancelled/skipped/todo; duration approximately 3.27 seconds. These are independent reruns of narrowly selected negative controls, not a rerun of the scanner campaign or the full source suite. Two initially guessed workflow filenames did not exist; actual workflow inventory/RI routing was then inspected, and no coverage claim depends on those failed lookups.

## Findings, risk assessment and limits

No actionable blocking defect was reproduced in these journeys. In particular, renewed policy remains bound to current source/line/rule/coverage and a finite deadline; no wildcard, broad generated-field or unknown-as-checksum exception was found. The one Basic Auth record is an exact synthetic rejection fixture in `tests/publishing-profile.test.cjs`, not evidence of permission to admit real credentials. Candidate literal credentials are intentionally omitted from this report.

The 333 qualified archival records deserve their stated limitation: public checksum/receipt/runtime identity purpose can be supported by retained source declarations without reconstructing original dirty/private artifacts or proving historical events. I inspected the classification inventory and representative retained-runtime declaration and the proof/source span bindings; I did not independently recreate every historical artifact or re-prove every classification's full semantic provenance. The 1,181 hash checks must not be presented as that stronger assurance. A newly discovered unsupported/nonpublic use would remain a blocker despite an exact ledger tuple. The source classifier is human-reviewed data; existing admission logic does not independently establish all of those semantic claims at runtime.

All fifty archives are byte-lossless. Compression changes human navigation: readers follow the locator and decode gzip. This is explicit in the stubs; the stronger claim that current Markdown preserves all former rendered anchors is neither made nor verified. No executable-reader absence was comprehensively re-proved in this charter; the storage manifest's consumer claims remain review subjects for changed-artifact review.

No native scanner campaign, current clean-commit CI, hosted stage/full/regression, browser/device interaction, native PDF appearance, actual production rights/archive, merge/control admission or served website/PDF observation was executed here. Local prepared scanner receipts were inspected as reports, not relabeled own executions. Actual original run42196241166 remains failed and is not superseded by this verdict.

## Regression disposition and next gates

Reuse the existing eleven executed cases; no new accepted tests were authored. Owner `guides/SITE-CHECK-PROFILES.md`, permanent `tests/quality-sources.test.cjs`, registered profiles `pr-targeted`, `staging`, `production`, surviving route `node tools/quality/source-tests.cjs --profile production`. Actual changed policy/companion files are listed as suite inputs in `tools/quality/test-profiles.json`. RI/CI also maps `test-profile-regressions` to `.github/workflows/navigation.yml`, job `navigation`, which explicitly includes this suite. Hosted source selection is owned by `.github/workflows/site-checks.yml`; actual security scanning remains in `.github/workflows/site-release-checks.yml` via `node tools/quality/scanners.cjs security`. None of those hosted jobs was run by this reviewer.

Retain the actual-policy deadline probe and fifty-archive equality observations as bounded manual/diagnostic evidence under issue169 AC05/AC11. A future storage-format change should repeat decoded-byte equality and locator checks; a future renewal should reuse source/line/new-finding/expiry rejection fixtures. Proposed repetitions are not executed new campaigns. Proceed only through all required candidate-role review and actual resulting-head delivery gates; preserve full publication acceptance and all unresolved external observations.

Recorded UTC: 2026-11-06T10:27:39.693116+00:00
