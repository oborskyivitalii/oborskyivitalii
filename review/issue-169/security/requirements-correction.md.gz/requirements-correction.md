# Requirements & Acceptance — same-role correction and reconciliation

**Verdict: RQ-F1 is closed by verified correction. Acceptance remains blocked by RQ-F2, an inaccurate execution-receipt deviation field.** This is a continuation of the same Requirements execution after its preserved first result, not a fresh independent first judgment. No source/security-data risk is newly accepted by repairing receipt metadata.

## Inspected identity and chronology

Candidate-v2 packet SHA-256 independently computed as `5bc4016c79109d2b0a8671cd41807dd7aeb154cde4b67d4da6738aa407a9db72`; all 167 repository pins and both external pins matched. Supplied prepared tree is `0aea2dcd15d8e870a945bd3bb4a44f3f172bdf40`, base remains `95d3e78d7e76d3e267351b8ca1efff206f99b748`. This remains a prepared subset, not a clean checkout. I did not rerun git write-tree or independently recompute v2's diff digest/tree. Common/role instruction identities are unchanged from the first report.

Compared v1/v2 pin maps: six changed paths (three navigation JSON owners, generated map, dated maintenance report and provenance wrapper), seven added evidence/receipt files, no removed pin. The three changed security policies/companions, frozen ledgers, scanner/triage/rules/version/test bytes, proof, 50-report storage manifest and public sources retain v1 identities. Their previously independently checked findings/source/prefix/limit evidence therefore remains applicable; the metadata correction does not require a new scanner/browser campaign.

First Requirements output was preserved before peer reconciliation. For this continuation only, I read the completed Code/White-box/Exploratory first reports and preflight inspector appendix, and inspected execution metadata. Those facts inform reconciliation; they are not claimed to have been available to my first judgment. No implementation, policy/test/repo/external writes or delegation occurred in this continuation; only this assigned report was authored. Provider context/model internals remain unavailable. Actual none-fork launch is operational isolation only, not provider/OS attestation; launch execution evidence is retained by the orchestrator.

## RQ-F1 correction — closed

Independently decoded old/new provenance wrappers and compared the parsed objects. Exactly two values changed, both in the historical-storage receipt:

| Field | Correct final value |
| --- | --- |
| archiveSha256 | `74ed76ec554fcb5830d3d904b4b665ff68d28fa7312fa166a8439a05f6589647` |
| decodedSha256 | `ca4f2fa84e859b5eacc6aa00db7ddc39293e21b7b38fb713ab25e7eaa6b63b41` |

All other receipt fields and nonreceipt structure are equal. The retained `provenance-v1-stale.json.gz` has SHA-256 `67e06f7e6741e4a13d8408eba1262d7f6c6fbbae2121c5fea71198e83ae766eb`, exactly the v1 packet's original provenance wrapper identity. All eight corrected wrapper receipt pairs independently match both actual compressed and decoded bytes. The actual historical-storage manifest remains unchanged and the first review's 50/50 Git-byte equality evidence remains valid. RQ-F1's failure mechanism is repaired, with history preserved.

Independently compared each archived Requirements/Code/White-box/Exploratory first report to its actual local first output: all four byte-identical after decoding. All four recorded decoded-result hashes match. Archived candidate-v1 packet also decodes to the original packet bytes. No report was silently revised during reconciliation.

## RQ-F2 — Medium: Requirements deviation incorrectly recorded as absent

**Location:** `review/issue-169/security/reviewer-executions.json.gz`, `launches[]` row with `role: requirements`, `deviation: "None reported."`.

Actual `requirements-first.md` expressly records that this reviewer invoked `git write-tree` to obtain the prepared index tree identity; the command can materialize Git objects and exceeded the requested strictly read-only Git boundary. The execution metadata currently preserves this disclosure for Code but omits the same disclosed Requirements deviation. The metadata archive inspected here has SHA-256 `185946e67df7bc768204974a3778364833a525f2086d658b8164cfa4c08b524a`.

**Requirement impact:** AC05/AC11 and the common execution-receipt contract require accurate requested/observed/deviation facts. A verbatim first report preserves the fact, but does not make a contradictory summary accurate. This is an execution-evidence accuracy blocker, not a discovered defect in the security classifications, policy behavior or public site.

**Treatment:** correct the Requirements deviation record, reconcile every role's actual disclosures, regenerate affected deterministic identities and retain this result. Verify the final packet and affected metadata through correction review; do not alter the original first reports. The orchestrator acknowledged this finding and stated that it will provide a deterministic updated packet after current correction reads finish. No later unseen edit is accepted by this report.

## RQ-L1 reconciliation — bounded coverage substantiated; exhaustive assurance remains unavailable

The original Requirements limitation was not a demonstrated credential or unknown tuple. It required actual affected role coverage rather than trusting `blocked: 0` in author/proof text. The now-completed source-bound results supply concrete additional observations:

- Code independently checked all 48 actual Bandit contexts/trust-relevant paths; recomputed 552 declared/additional byte equalities and 145 Git-object claims; verified exact ledger prefixes and all occurrence bindings. Its semantic surrounding-context reading was representative, not an exhaustive reread of every qualified declaration.
- White-box independently resolved 1,136 actual JSON/fenced-JSON field/property bindings, recomputed 518 matching declared referents and 145 Git-object-bearing records, executed all 1,017 exact tuple positives and 3,051 path/rule/hash mismatch refusals, and eight Bandit fault cases. Twelve selected existing tests passed. Its admitted tuple executions establish exact admission behavior rather than semantic safety by themselves.
- Exploratory independently exercised finite deadline admission/refusal and eleven existing failure/control tests, plus archive retrieval and source boundaries. It explicitly retained qualified archival and dynamic-consumer limitations.
- The separate inspector appendix reports an actual read-only replay of all nine producer records and explicit binding refinement for the 34 formerly indirect matches. I verified that its final compact proof compressed SHA-256 `4535f2822cdbe037dfb4d9af369e2cf9188d3f82c6ba534aa62f7fb416142b95` and decoded SHA-256 `c0188b391b820959c50b565041670a446a86b5d7fb0f9f680c055ecae76ba5ca` identify the current unchanged proof. This is that inspector's replay, not my execution. Its eight generated-proof exclusions were checked as a set dependency, not replayed by that inspector or this continuation.

I independently re-enumerated the 333 qualified records: 269 archival file checksums, 12 archival receipt identities, 35 frozen-fixture declarations, 12 runtime compatibility identities, three diagnostic pins and two retained HTML identities. Every one retains a public noncredential-purpose explanation, the explicit qualified recommendation and limitations. Their actual field roles include typed checksum/identity values/properties and declared runtime/source metadata. No new unbound or nonpublic tuple was identified by the available factual checks. The per-ID proof/classifications and these purpose claims remain individually challengeable evidence, not a new automatic runtime admission authority.

On that factual coverage, RQ-L1 does not identify an additional actionable candidate defect. It is reconciled as a real assurance limit rather than waived by three favorable verdicts. No result supplies exhaustive manual semantic rereading, original dirty/private artifact reconstruction or historical event authentication. Those missing historical observations are not required to pretend a retained public checksum declaration is an actual recovered artifact. Any actual unsupported/nonpublic context discovered later remains a blocker regardless of a current exact ledger entry. The generated-proof dependency has retained source-bound set evidence; full producer regeneration was not newly executed here and must not be claimed.

## Remaining gates and disposition

| Obligation | Correction disposition |
| --- | --- |
| RQ-F1 authentic final archival manifest | Closed: exact two-hash repair and all eight byte pairs independently verified |
| RQ-F2 truthful execution deviations | Open; deterministic execution-metadata correction and affected identity verification required |
| Preserved intent, original AC IDs, publication boundaries | Unchanged; no new owner decision or exception supplied |
| Exact-source/local checks vs delivery | Existing bounded results reusable for unchanged inputs; actual resulting-head required CI/RI/delivery checks remain pending |
| Four role execution and correction evidence | Four actual verbatim first outputs present; execution metadata must accurately describe disclosures; affected correction findings remain gates |
| Accepted staging / protected identical-tree merge / production rights/archive / served article-PDF | Not observed; existing mandatory gates remain pending |
| Platform posting and reciprocal links | Author-manual after verified site; later paired reciprocal link update retains its existing separate scope |

No whole publication AC is newly complete. Preserve the failed original staging run, all first results and both provenance versions; repair RQ-F2 before advancing acceptance of this review receipt set.
