# White-box QA — first independent result

Verdict: **PASS for the bounded white-box data/guard review; no candidate defect demonstrated.** This is not a full scanner, staging, production or release acceptance result. AC05/AC11 receive this actual role execution only; their other gates remain pending.

## Inputs and boundary

- Owner #169 / PR #170; original issue snapshot and its original editorial intent, dated website release authorization and site-first distribution amendment inspected. Candidate scope is security data renewal/classification and lossless report storage, not article/runtime/scanner changes.
- Prepared subset, not a clean checkout: base `95d3e78d7e76d3e267351b8ca1efff206f99b748`, prepared tree `bb277b3e0ea4f9277e17064f08a30f5286c1917b`.
- Packet `/workspace/scratch/f4dcb060a703/security-review/candidate-v1.json`, SHA256 `6a785b2ed898c2d4561b768a0894bdb516d017f7115ed29ec2f5fe4ff868f512`. Independently hashed all 160 supplied repository pins and both external pins: no mismatches.
- Common contract SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Read actual root instructions, README, repository map, relevant check-profile/source owners, actual diff, scanner admission helpers and existing tests. Did not inspect MEMORY, parent notes, current peer outputs or preflight reviewer narratives. Programmatic occurrence/fenced-JSON checks read relevant source bytes without rendering their surrounding review prose. Candidate proof classifications and recorded historical executions were treated as claims.
- No delegation or implementation/source/test/policy/external writes. Only this assigned result artifact is written. Provider model/context internals are unknown; the orchestrator owns actual launch-parameter evidence. No provider isolation or OS sandbox assertion is made.

## Risk → structure → independent oracle → executed case

| Risk / AC | Structural fault | Independent oracle and executed case | Result / route |
| --- | --- | --- | --- |
| AC05 security data | Baseline replacement, reordered/reason-altered predecessor rows | Compare all four old Git ledgers to candidate bytes/ordered prefixes; global ID uniqueness | Both frozen ledgers byte-identical; all predecessor rows/data/order identical; no duplicate among 16,107 loaded IDs. Existing source-security suite |
| AC05 exact admission | Cross-path/rule/value allowance | Load actual candidate ledgers, exercise all 1,017 appended tuples and mutate path, rule and hash separately | All exact tuples admitted; all 3,051 mismatches rejected. Existing source-security suite |
| AC05 per-ID binding | Proof points to unrelated literal or field | Independently hash all 1,181 source spans and check line coordinates; parse actual JSON/fenced JSON and resolve exact typed paths, including redacted key representations | All 1,025 unique record IDs accounted; all 1,136 JSON field/property bindings verified; no occurrence/line mismatch |
| AC05 referent identity | Same digest elsewhere mistaken for declared source | Recompute declared matching referent bytes, allowing explicitly retained gzip-decoded bytes; independently reconstruct Git object header/body hashes and type | 518 declared matching referent checks and 145 Git-object-bearing record checks succeeded; no binding mismatch |
| AC05 scanner renewal | Expiry, rule/line/source drift, missing coverage or scanner errors admitted | Actual failed raw Bandit report + current policy + tracked Python inventory; clone negatives against current data | 48 findings / 16 Python files admitted; 8 independently injected faults rejected; deadline inclusive through 2026-12-06 23:59:59.999Z |
| AC05 source preservation | Scanner/rule/version/budget weakened | Compare scanner, generated proof helper, triage, rules, requirements, quality tests, advisory exceptions and toolchain lock with base | Inspected owners byte-identical; closed four-ledger list and 2,000,000-byte bounds unchanged |
| AC05 archive storage | Historical evidence lost or executable source hidden | Decode each of 50 archives and compare original Git bytes plus digest/stub link; scan executable source text for exact affected report paths; compare archived paths to current unresolved proof paths | 50/50 byte-equal, 1,206,112 original bytes preserved; no exact-path executable consumers or overlap with appended-untriaged source paths found |
| AC05 fail-closed behavior | Existing guards do not detect intended fault | Targeted existing source suite covering Bandit, closed ledgers, browser proof and arbitrary generated-field/resource negatives | 12 selected tests passed; no failure/cancellation/skip |

These are boundary/data-partition and fault-injection checks, not measured branch coverage. Source analysis is separate from execution.

## Actual observations

Ledger counts: frozen baseline 4,957 → 4,957 (1,996,285 bytes), frozen reviewed 4,368 → 4,368 (1,999,782 bytes), checksum 2,135 → 3,151 (1,659,338 bytes), publication 3,630 → 3,631 (1,925,483 bytes). All remain within the unchanged individual limit. The 1,017 additions equal the proof record set after excluding eight records already assigned to existing generated proof; no extra or missing append was observed. All appended records retain exact path/rule/hashed-value authority. This does not make arbitrary metadata fields automatically safe.

The sole Basic Auth finding is a synthetic password substring in an intentionally rejected public-origin URL, in `tests/publishing-profile.test.cjs:126`. Surrounding source places it in the invalid-origin table; no actual credential literal is reproduced here. The other 1,024 proof records are Hex entropy findings. Historical declarations explicitly qualify unavailable original dirty/private/artifact bytes and event authenticity; a checksum declaration alone was not counted as reconstruction of those bytes.

All 63 proof source pins, five consumer pins and ten producer-input pins were independently rehashed with no mismatch. Source positions expose the expected digest/Git/route/fixture metadata roles, rather than authentication use. Current-byte checks and qualified archival declarations remain different evidence classes. The 269 archival file declarations, 12 archival receipt declarations, 35 frozen-fixture declarations, 12 runtime compatibility declarations, three diagnostic pins and two retained HTML identities do not authenticate the historical event or unavailable original artifact.

Bandit policy still has 48 entries. Ordered comparison found changes only in 48 deadlines, 48 rationales, five source hashes and four line coordinates; no rule, severity, confidence, finding-line digest or owner changed. Actual raw report admission recomputed source/line binding. Renewal preserves a trusted repository/developer-tooling boundary; it supplies no hostile-code sandbox guarantee.

## Commands and raw result accounting

Executed from `/workspace/scratch/f4dcb060a703/repo`:

1. `node --test --test-name-pattern='Bandit|closed secret|secret ledgers reject|public inventory paths|generated checksum collection rejects|arbitrary fields|unauthorized owners|browser integrity' tests/quality-sources.test.cjs` — exit 0; 12 tests, 12 pass, 0 fail/cancel/skip/todo; 3.305 seconds. Cases include source/rule/line/coverage, expiry/symlink, malformed/duplicate ledgers, browser field/lock/install drift and arbitrary generated-field/resource rejection.
2. Independent read-only Node stdin harness called `bandit-triage.review` on retained `failed-bandit.json.gz`, actual policy and `git ls-files tools` Python inventory. Positive result 48/16; cloned expired/rule/line/source/coverage/scanner-error/missing/confidence cases all threw as required (8/8); exact final-millisecond deadline positive passed. Then `loadSecretReviews`/`reviewedSecretFinding` executed all 1,017 appended positive and 3,051 mismatch cases — exit 0.
3. Independent Python stdin diagnostics used `git show 95d3e78:<path>`, gzip decode, SHA256/SHA1, typed JSON lookup and `git cat-file -t/<type>` object reconstruction. Counts/results appear above; final checks exited 0. A first diagnostic stopped on a referent stored as `<path>.gz`; after inspecting that storage case the follow-up explicitly checked decoded retained bytes. A naive field diagnostic also reported redacted key names as KeyError; resolving each actual key through its detector hash removed all 110 representation mismatches. Neither was a product failure or an unchanged rerun.
4. Original failure ZIP was hashed and opened directly: detect-secrets report has 408 result paths and 9,092 raw findings. Raw original archive remains retained. This is not a claim that every raw finding was rescanned in this review.

No new test is authored or accepted. These diagnostics supplement the existing `tests/quality-sources.test.cjs` source-security coverage mapped by `guides/SITE-CHECK-PROFILES.md`; full hosted security remains with the existing staging/regression owner/controller.

## Findings and real limits

No blocking defect found in the exercised data-admission, source-binding, renewal or archive-preservation paths. No fixes proposed.

This six-minute review did not replay the nine native producers, regenerate the full generated-proof authority for the eight excluded records, independently reconstruct unavailable historical artifacts, execute the whole scanner, measure branch coverage, or launch a browser. Native replay claims in candidate evidence were not inherited as my own execution. Exact-path executable consumer search is bounded; it does not prove absence of every possible future/dynamically constructed consumer. Archive preservation verifies bytes and accessible stub references, not historical narrative truth.

No changed public UI/runtime was observed in this diff; browser behavior was therefore outside this data review, while hosted staging/full regression and production remain mandatory and unobserved. This role result alone cannot close AC05/AC11 or authorize advancement past remaining source-bound independent roles and release gates.
