# White-box QA — affected storage continuation

**Storage checks PASS; exact-source provenance closure remains BLOCKED by WB-S1.** This is the same role continuing after its first, correction and metadata-closure outputs. No fresh-context claim or full security/release verdict is made.

Packet candidate-v4 SHA256 `a0feb8a8d17c8e09076723a7a96386f91ca8304b9e1230bcb0f4fbfdd2ee28ae`, prepared tree `3d6fd1617885f5efe83ec9999b2319c4edea1bca`, base `95d3e78d7e76d3e267351b8ca1efff206f99b748`. All198 repository pins and both external pins independently match actual bytes. Prior outputs are preserved.

## WB-S1 — Medium: updated receipt's declared local source still contains the old50-record manifest

Location: `review/issue-169/security/provenance.json.gz`, `receipts[5].source` and `.decodedSha256`.

The updated receipt correctly authenticates the actual60-record target archive and its decoded bytes, whose SHA256 is `9cf9a6b129388d1a57ab74663a29e058fc06b2b605338dfc52a5d5bcef017730`. It still identifies `/workspace/scratch/f4dcb060a703/security-review/historical-storage.json` as its source. That actual source remains the50-record version, SHA256 `ca4f2fa84e859b5eacc6aa00db7ddc39293e21b7b38fb713ab25e7eaa6b63b41`. Seven other source/decoded receipt bindings continue to match; this one no longer does.

Failure mechanism / AC impact: target-byte authenticity is intact, but the source→retained-target evidence chain now points at different bytes without declaring that difference. AC05/AC11 exact-source traceability cannot treat this source field as the source of the final manifest. This is a metadata discrepancy, not loss of any archived original report or evidence of credential admission.

Treatment: retain the original50-record source and accurately point the final manifest receipt to its actual immutable60-record source, or explicitly distinguish predecessor source and final derived manifest with separate byte identities. Obtain affected readback of the corrected reference and bytes. No scanner or browser rerun is needed for this repair.

## Executed checks and results

| Protected invariant / case | Observed result |
| --- | --- |
| Exact newly archived content | All10 added gzip files independently decode byte-for-byte to `git show <sourceCommit>:<original-path>`. Archive/decoded SHA256 and byte lengths match every manifest row and packet pins. |
| Existing archival content preserved | Rechecked all60 records:60/60 Git/decoded/hash/length/original-path locator checks pass; no duplicate original path. |
| Original locations remain useful | Each locator links the correct paired gzip and the storage manifest; example locator inspected directly. Decoded historical narratives were compared as bytes, not inherited as judgments. |
| No unresolved candidate hidden | Added10 original paths have no overlap with the current nonexcluded per-ID proof source paths. |
| No exact executable consumer hidden | Searched executable source text in tools, tests, site and workflow directories for all10 exact original paths: no matches. This is a bounded consumer check, not proof against every dynamically constructed future read. |
| Manifest / diagnostic consistency | `final-storage-correction.json.gz` newArchives equals exactly the current manifest's10-row suffix. New original bytes total130,893; archive bytes57,391. Reported savedBytes68,776 includes replacement locator overhead, consistent with the storage operation rather than archive-size subtraction alone. |
| Current target receipt hashes | All8 compressed/decoded target hash pairs pass, including current60-record manifest. This target check does not erase WB-S1's separate source mismatch. |
| Unchanged guard and admission inputs | All57 overlapping relevant core/evidence pins match v3, excluding only the intentionally changed storage manifest/provenance. Policy, ledgers, proof, native evidence, scanner/test owners and prior results remain exact. |
| Fixed RI bound retained | RI producer, RI-CI owner and RI contract match base bytes. Actual constants remain32,000,000 per hash file and250,000,000 total hash bytes, plus existing text/file/count limits. |
| Current deterministic RI freshness | `python -B tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify` exited0: Repository Intelligence context is fresh. |
| Prior packet retained | Archived candidate-v3 bytes equal the actual supplied v3 packet. |

The retained correction measurement records250,014,131 hash bytes against unchanged250,000,000 limit, an overrun of14,131 bytes. I inspected that retained measurement and independently verified current RI freshness/bound-owner bytes; I did not reproduce the historical failed build or mutate an old tree. No claim is made that the historical failure was independently rerun.

Read-only Python diagnostics used hashlib/gzip/JSON and Git show; all substantive byte/source checks completed. An initial RI invocation omitted required --config and exited2 with CLI usage; after reading the actual owner's command, the configured verify exited0. No source/Git-object/external writes or full scanner/browser/test campaign occurred. Only this assigned report is written.

## Chronology, AC impact and limits

The ten report additions preserve the previously accepted lossless-storage method and fixed resource limits. Earlier White-box security checks remain reusable for unchanged inputs; the storage verification above covers the affected paths. WB-C1/RQ-F2 execution disclosures remain intact. WB-S1 is a new affected metadata finding and requires correction before this source chain is called complete.

This continuation preserves all earlier semantic-adjudication, native-replay, generated-proof, archival-authenticity and consumer-search limits. Any genuinely unresolved classification or source dependency remains blocking. Provider internals remain unknown; operational launch receipts are not OS/provider isolation proof. Hosted security/staging/full regression, protected integration, production rights/archive and served delivery remain separate mandatory gates. Whole AC05/AC11 and publication are not established by these storage observations.
