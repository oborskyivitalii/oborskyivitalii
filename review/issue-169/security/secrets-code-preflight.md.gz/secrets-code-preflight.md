# Code / security secrets preimplementation inspection

Verdict: the failed secret gate is not yet eligible for a blanket false-positive disposition. A constrained exact-record correction is supported for proved public values and the single synthetic authentication fixture. The 1,016 hosted versus 1,024 local accounting difference and historical/producer provenance require explicit reconciliation before implementation acceptance. No implementation, policy, test or external state was changed.

## Identity and bounds

- Role/execution: distinct nonauthor Code / security inspector, task `/root/security_secrets_inspection`, first preimplementation judgment. Actual orchestrator fork parameters/provider context internals are not observable from this execution and are not independently attested here. No MEMORY, parent notes, private history or current peer artifacts were read. Historical tracked candidate manifests were inspected as data, without adopting their verdicts.
- Owner169 / PR170. Original source packet authorizes production continuation of accepted R10 through existing checks and controller; manuscript/PDF/runtime, scanners, source/rights/artifact bindings and limits remain protected. AC05/11 require source-bound review; AC04/09 require actual website delivery and URL verification. This report supplies neither publication acceptance nor a credential-risk waiver.
- Inspected clean Git HEAD `95d3e78d7e76d3e267351b8ca1efff206f99b748`, tree `28a95e053b0036bc7e1e947232847dd51ce410ff`, packet base `8cf15883125892710633b17133d9ee0fc4b23b92`. `git status --short` was empty.
- Packet `/workspace/scratch/f4dcb060a703/security-review/packet.json` SHA256 `1862a1dacb7b3d3622e20b519c320d1ec7794eb89f1f1a8fd248f8e6c3fc7b26` independently matched.
- Actual retained stage ZIP `staging95-preflight-42196241166.zip` SHA256 `f07cb361798e5c35ec326f5a1f6e755331abdfa570128264bc9930a7055397de` independently matched. Its `security.json` binds the same source/tree/run42196241166 attempt1 and reports `pass:false`, failed engines Bandit/secrets.
- ZIP `detect-secrets.json` was byte-identical to the supplied local report, SHA256 `e3ea55b6318c052c94005e70f860d53b5133a7900879e264134b67b650649f3a`. The local **filtered** helper input is separate from the raw scanner report. Its1024 findings must not be described as the exact hosted1016.
- Read root AGENTS, README, scoped REPOSITORY-MAP entries, CONTRIBUTING failure/review protocol, CODE-STYLE, release-gate security rules, reviewer common contract and code role prompt; no applicable nested AGENTS was present under tools/agents.
- Read-only actions: source/schema/line inspection, report/ZIP hash/readback, tracked-byte/gzip-decoded SHA256 comparison and local Git object existence/type inspection. No full scanner, release campaign, verification rerun, network mutation or recursive delegation.

## Findings and treatment

### F1 — blocking: historical declarations do not prove recomputed original bytes

Locations include `review/issue-169/distribution/candidate-v*.json`, `r10/candidate-manifest*.json`, R9 input manifests, `release/manifest-timing*.json`, and runtime fixture evidence fields. The diagnostic independently located every local Hex candidate token by comparing SHA1(token) with the detector's hashed identifier; it did not print token values. Across1024 local records:532 token values equal actual current tracked-file or gzip-decoded SHA256;145 are available Git object IDs;1 is the explicit negative BasicAuth fixture;346 require further producer/historical provenance. The categories are mutually exclusive using byte equality first, Git object existence second. There are600 unique Hex detector hashes. Git-object matches represent104 distinct objects:80blobs,17commits,7trees.

These are conservative **comparison categories**, not completed dispositions. A SHA256 match also needs the declared field/referent binding; Git existence alone does not prove a claimed commit/path relationship. The346 residual records are not established genuine credentials, but their syntax/field names and repetition also do not prove false positives. In particular, `tests/fixtures/reader-resource-links.json` explicitly says its origins are prepared dirty generation; runtime projections distinguish dirty private derivation from clean CI. Preserving those limits is mandatory.

Treatment: a per-record proof should name exact path/type/hashed-value, all observed source occurrences, source-file SHA256, field meaning, actual referent/producer, verification command and result, and one explicit evidence class: (a) bytes independently recomputed now; (b) Git object/path identity verified now; (c) canonical producer recomputed now; (d) preserved archival declaration/synthetic fixture identity with original bytes unavailable. Class(d) may support a narrowly reviewed public historical-identity disposition only where the retained source itself establishes public noncredential purpose; it must never claim independent recomputation or original artifact authenticity. Where this provenance is absent, leave the candidate unresolved. The preserved failed hosted result remains unchanged. AC05/11 and security release gate are affected.

### F2 — blocking:1024 local versus1016 hosted requires exact reconciliation

`tools/quality/scanners.cjs:969` applies proof-backed generated findings in addition to exact ledgers; local frozen R3/R4 history availability can therefore change filtering. The packet reports eight unresolved context-dependent values. I observed the raw ZIP/report identity but did not execute the helper or generated proof and did not establish which eight are the difference. Do not append1024 rows on the assumption that they are the hosted failure set. Reconcile by exact path/type/hash with the actual generated-proof source context, recording exclusions and their proof. Missing local historical objects are a diagnostic limit, not authority to alter admission logic or claim scanner parity. AC05/source binding and scanner gate are affected.

### F3 — concrete supported false positive: one negative authentication test

`tests/publishing-profile.test.cjs:126`, type `Basic Auth Credentials`, hashed identifier `9d4e1e23bd5b727046a9e3b4b7db57bd8d6ee684`. The literal appears in a loop of deliberately invalid public production origins and is immediately passed to policy loading with an expected public-origin rejection. It is a synthetic username/password fixture on a reserved example host, not an application credential. Record that exact tuple with this test/source proof; preserve the literal, negative assertion and detector behavior. Do not generalize by credential type, test directory, example host or line alone.

### F4 — blocking implementation constraint: the natural historical ledger has no usable space

`tools/quality/scanners.cjs:433-537` has a closed four-ledger list, a strict2,000,000-byte bound per regular non-symlink file, exact metadata/entry keys and global duplicate rejection. Companion `secrets-reviewed-checksums.json` allows Hex only apart from already exact declared Base64 cases. It **cannot** accept the BasicAuth fixture without changing the scanner, which is excluded here.

Observed ledger bytes: baseline1,996,285; historical reviewed1,999,782; checksum companion1,238,968; publication1,924,551. The historical reviewed ledger has only218bytes free, insufficient for a clear normal exact BasicAuth review row. Preserve baseline and historical reviewed bytes. A supported bounded route is append proved Hex rows to the existing companion and the one exact BasicAuth fixture row to `secrets-publication.json`, whose existing schema explicitly permits BasicAuth and has75,449bytes free. Bind its appended scope/reason to owner169 and this source proof; preserve all predecessor rows/order/reasons. Validate final byte bound and global duplicate IDs. A neighboring new JSON file is not an admission authority. No detector/threshold/input-list/schema/generated-proof change, broad path exclusion, baseline rewrite or historical compaction is justified.

## Strong concrete proof available now

- All seven newly untriaged `site/rights.json` values (lines330,342,346,350,354,358,362) match actual declared PNG/PDF bytes. The R10 PDF token also matches both the public article-media PDF and authored material PDF and the exact `site/output-lock.json:219` value. This is actual byte equality, not an inferred checksum shape.
- `site/publications/sdlc-out-of-balance/materials.json:19` matches the R10 PDF bytes; line27 matches the declared PDF review Markdown bytes. Its semantic and approval-binding tokens still need their respective canonical producer proof; byte equality of the PDF does not establish approval.
- All local fields in the archive-storage inventories can be compared to actual compressed bytes and decompressed originals without trusting the archived narratives. The diagnostic hashed gzip payloads but did not consume their reviewer conclusions. The complete per-path table below records the matching accounting.
- `tools/check_site_seo.cjs:389` matches an available predecessor Git commit; line392 matches current `tools/site/html.cjs` bytes. Line391 still needs `git show predecessor:path` SHA256 and exact successor relation, rather than inference from the before/after field names.
- The two print-title block tokens in profile line50/51 are consumed by `blockDigest` in `tools/publishing/profile.cjs:449-460`; they need digest recomputation on their uniquely selected AST nodes. They are not raw manuscript SHA256. No such producer execution was performed here.
- Runtime registrations in `tools/quality/color-motion-contract.cjs:888-908` and `tools/site/runtime-compatibility.cjs:23-24` are declared public compatibility fingerprints. Trace each to the frozen fixture and retained exact native/production projection bytes; if only a historical projection survives, explicitly use archival-declaration classification. Do not recreate a dirty source from a later clean commit and call it the original.

## Recommended acceptance checks after a separately authored correction

Use one proof record per exact new tuple, preserve source SHA256 and inherited ledger prefixes, check all four ledgers' schemas/bounds/global uniqueness, compare frozen baseline and historical reviewed byte hashes, and bind the final appended-ID set to the reconciled actual candidate set. Review positive current-byte, Git/path, producer, archival and negative-auth examples independently. Existing scanner tests/guards and the unchanged release-security lane then provide actual behavior evidence on the final source. No claim of full secret history coverage, no discovered-credential clearance and no production approval follows from this preflight.

## Complete local candidate accounting

The following table covers all62 filtered source files. “Bytes” means token equals a computed actual tracked-file/gzip-decoded SHA256; “Git” means an available local object identifier only. “Needs proof” remains open pending field binding/producer/archive proof. One detector record may aggregate repeated equal token occurrences; a future proof must account for those occurrences separately.

| Source | Total | Bytes | Git | Fixture | Needs proof |
| --- | ---: | ---: | ---: | ---: | ---: |
| `docs/article-snapshots/7b1e3fbe23136bd07787e2d8348f94036213d2bb9a3ef16d618ffd2cb87ba7d1/the-sdlc-is-out-of-balance.html` | 2 | 0 | 0 | 0 | 2 |
| `docs/article-snapshots/bcad10190551a8e82e0713817d284c87d64b2995574d01f8a1df22182ea4e003/the-sdlc-is-out-of-balance.html` | 2 | 0 | 0 | 0 | 2 |
| `docs/articles/the-sdlc-is-out-of-balance.html` | 2 | 0 | 0 | 0 | 2 |
| `review/issue-169/2026-11-05-native-r9-content-retention-requirements-preflight.md` | 8 | 6 | 0 | 0 | 2 |
| `review/issue-169/2026-11-05-native-r9-diagnostic-requirements-preflight.md` | 10 | 4 | 0 | 0 | 6 |
| `review/issue-169/2026-11-05-native-r9-diagnostic-requirements-reconciliation.md` | 11 | 6 | 0 | 0 | 5 |
| `review/issue-169/2026-11-05-native-r9-diagnostic-result-requirements.md` | 4 | 1 | 0 | 0 | 3 |
| `review/issue-169/2026-11-05-native-r9-requirements-delta.md` | 21 | 12 | 0 | 0 | 9 |
| `review/issue-169/distribution/archive-manifest.json` | 4 | 4 | 0 | 0 | 0 |
| `review/issue-169/distribution/candidate-v1.json` | 29 | 7 | 1 | 0 | 21 |
| `review/issue-169/distribution/candidate-v2.json` | 35 | 15 | 1 | 0 | 19 |
| `review/issue-169/distribution/candidate-v3.json` | 36 | 19 | 1 | 0 | 16 |
| `review/issue-169/distribution/candidate-v4.json` | 36 | 21 | 1 | 0 | 14 |
| `review/issue-169/distribution/candidate-v5.json` | 41 | 26 | 1 | 0 | 14 |
| `review/issue-169/distribution/local-checks.json` | 2 | 1 | 1 | 0 | 0 |
| `review/issue-169/distribution/receipt-storage-archive.json` | 4 | 4 | 0 | 0 | 0 |
| `review/issue-169/distribution/requirements-final.md` | 9 | 8 | 0 | 0 | 1 |
| `review/issue-169/distribution/requirements-preflight.md` | 33 | 16 | 0 | 0 | 17 |
| `review/issue-169/distribution/requirements-v3.md` | 13 | 10 | 0 | 0 | 3 |
| `review/issue-169/r10/candidate-manifest-v2.json` | 53 | 29 | 2 | 0 | 22 |
| `review/issue-169/r10/candidate-manifest-v4.json` | 54 | 33 | 2 | 0 | 19 |
| `review/issue-169/r10/candidate-manifest.json` | 32 | 8 | 2 | 0 | 22 |
| `review/issue-169/r10/history-archive-manifest.json` | 24 | 24 | 0 | 0 | 0 |
| `review/issue-169/r9/corrections-input-manifest.json` | 12 | 8 | 2 | 0 | 2 |
| `review/issue-169/r9/diagnostic-input-manifest.json` | 21 | 12 | 2 | 0 | 7 |
| `review/issue-169/r9/footer-fix-input-manifest.json` | 17 | 3 | 1 | 0 | 13 |
| `review/issue-169/r9/forward-owner-input-manifest.json` | 13 | 5 | 2 | 0 | 6 |
| `review/issue-169/r9/native-launch-receipts.json` | 25 | 18 | 6 | 0 | 1 |
| `review/issue-169/r9/reader-audit-correction-input-manifest.json` | 18 | 10 | 1 | 0 | 7 |
| `review/issue-169/r9/reader-audit-correction-v2-input-manifest.json` | 20 | 12 | 1 | 0 | 7 |
| `review/issue-169/r9/reader-audit-correction-v3-input-manifest.json` | 20 | 13 | 1 | 0 | 6 |
| `review/issue-169/r9/reader-audit-final-delta-input-manifest.json` | 6 | 3 | 1 | 0 | 2 |
| `review/issue-169/r9/reader-runtime-probe.cjs` | 4 | 1 | 0 | 0 | 3 |
| `review/issue-169/r9/runtime-admission-input-manifest.json` | 14 | 2 | 2 | 0 | 10 |
| `review/issue-169/r9/runtime-review/admission-final-packet.json` | 17 | 12 | 0 | 0 | 5 |
| `review/issue-169/r9/runtime-review/html-successor-packet-v2.json` | 4 | 1 | 1 | 0 | 2 |
| `review/issue-169/r9/runtime-review/html-successor-packet.json` | 22 | 15 | 2 | 0 | 5 |
| `review/issue-169/r9/runtime-review/reviewer-packet.json` | 24 | 15 | 3 | 0 | 6 |
| `review/issue-169/release/cache-candidate-v2.json` | 22 | 16 | 4 | 0 | 2 |
| `review/issue-169/release/cache-candidate-v3.json` | 53 | 47 | 4 | 0 | 2 |
| `review/issue-169/release/cache-candidate.json` | 20 | 13 | 4 | 0 | 3 |
| `review/issue-169/release/historical-storage.json` | 9 | 8 | 1 | 0 | 0 |
| `review/issue-169/release/manifest-timing-corrected.json` | 1 | 0 | 0 | 0 | 1 |
| `review/issue-169/release/manifest-timing.json` | 2 | 0 | 1 | 0 | 1 |
| `review/issue-169/release/missing-historical-blobs.json` | 79 | 0 | 79 | 0 | 0 |
| `review/issue-169/release/packet.json` | 16 | 12 | 4 | 0 | 0 |
| `review/issue-169/release/receipt-storage.json` | 20 | 20 | 0 | 0 | 0 |
| `review/issue-169/release/regeneration-parity.json` | 8 | 7 | 1 | 0 | 0 |
| `review/issue-169/release/reviewer-executions.json` | 5 | 5 | 0 | 0 | 0 |
| `site/output-lock.json` | 1 | 1 | 0 | 0 | 0 |
| `site/publications/sdlc-out-of-balance/editions/sdlc-out-of-balance-en-r3-20261031.json` | 4 | 0 | 2 | 0 | 2 |
| `site/publications/sdlc-out-of-balance/editions/sdlc-out-of-balance-en-r4-20261101.json` | 4 | 0 | 2 | 0 | 2 |
| `site/publications/sdlc-out-of-balance/materials.json` | 4 | 2 | 0 | 0 | 2 |
| `site/publications/sdlc-out-of-balance/profile.json` | 2 | 0 | 0 | 0 | 2 |
| `site/rights.json` | 7 | 7 | 0 | 0 | 0 |
| `tests/fixtures/r9-footer-runtime.json` | 20 | 5 | 2 | 0 | 13 |
| `tests/fixtures/r9-reader-history-runtime.json` | 24 | 2 | 2 | 0 | 20 |
| `tests/fixtures/reader-resource-links.json` | 4 | 1 | 1 | 0 | 2 |
| `tests/publishing-profile.test.cjs` | 1 | 0 | 0 | 1 | 0 |
| `tools/check_site_seo.cjs` | 3 | 1 | 1 | 0 | 1 |
| `tools/quality/color-motion-contract.cjs` | 11 | 1 | 0 | 0 | 10 |
| `tools/site/runtime-compatibility.cjs` | 2 | 0 | 0 | 0 | 2 |

## Inspected dependency byte identities

- `AGENTS.md` SHA256 `f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01`.
- `CONTRIBUTING.md` SHA256 `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442`.
- `agents/reviewers/README.md` SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- `agents/reviewers/code-review.md` SHA256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- `tools/quality/scanners.cjs` SHA256 `d5ce0402b9abfd5f9e3d385e31991fded746d40b018cadc49099fc620d6cfde1`.
- `tools/quality/generated-checksums.cjs` SHA256 `42b9b51d0608ba4def4c3bf6408bddad8775de51ee7e697f457e50ee59c37383`.
- `tools/quality/secrets-baseline.json` SHA256 `8bff933ce846d5b1a0fa9a357f629c07d49af8626270ea40cfd658b760e293b0`.
- `tools/quality/secrets-reviewed.json` SHA256 `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb`.
- `tools/quality/secrets-reviewed-checksums.json` SHA256 `36b5ebb2cd21ed9d1c2d30a10c8d524f53fb4b751bc32a5773b9d9335935946b`.
- `tools/quality/secrets-publication.json` SHA256 `e3d2106a32a691670a390ed59384905230bf14019fe4929667c4683f40fb6c72`.
- Filtered diagnostic input SHA256 `eaeaa69c58c7b9a020a4c0d0e4c1016146fda8ace5b88aade817654be2da75dd`.

Limits: this bounded preflight inspected classification mechanisms and all candidate paths/line contexts, not the full PR diff or complete credentials history. It supplied no original dirty-build byte reconstruction, native artifact rerun, full producer execution, scanner replay or end-to-end release result. Packet/current-source identity was stable during inspection; subsequent relevant changes require affected review.
