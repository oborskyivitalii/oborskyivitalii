# Independent Code / Changed Artifact preimplementation review — Bandit

First judgment, 2026-11-06. Reviewer task `/root/security_bandit_inspection`; nonauthor, read-only inspection. Owner #169 / PR170. **Disposition: existing narrowly scoped tooling classifications can be substantively revalidated; current admission remains blocked.** No additional source vulnerability or required production-code fix was found in these 48 contexts under their expressly documented developer-tooling trust boundary. This is not a blanket risk acceptance or permission to execute hostile candidate code with privileged credentials.

## Identity and limits

- Inspected clean repository HEAD `95d3e78d7e76d3e267351b8ca1efff206f99b748`, tree `28a95e053b0036bc7e1e947232847dd51ce410ff`; task base `8cf15883125892710633b17133d9ee0fc4b23b92`.
- Packet `/workspace/scratch/f4dcb060a703/security-review/packet.json`, SHA256 `1862a1dacb7b3d3622e20b519c320d1ec7794eb89f1f1a8fd248f8e6c3fc7b26`, independently recomputed. Issue snapshot read from packet path; original R10 production intent preserves source, scanner cases, checks and limits, with manual platform publication later.
- ZIP `/workspace/scratch/f4dcb060a703/release-diagnosis/staging95-preflight-42196241166.zip`, independently verified SHA256 `f07cb361798e5c35ec326f5a1f6e755331abdfa570128264bc9930a7055397de`.
- Retained `bandit.json` SHA256 `9236d506595cafad7e398e1b27fe9b013b6e098d8ab14686dd404bbbb1f09364`, generated `2026-11-06T09:42:16Z`. Raw report: 48 findings, 43 LOW / 5 MEDIUM, 40 HIGH / 8 MEDIUM confidence, 3,822 LOC, 17 metric file entries, zero errors, zero nosec and zero skipped tests. No new scanner execution was performed.
- Read root instructions, README, repository map, CONTRIBUTING, common/Code reviewer prompts, CODE-STYLE, security scanner/triage/policy owners, acceptance trust-boundary paragraphs and relevant workflow source. No applicable nested AGENTS was found in repository tracked files. MEMORY, parent conversation/notes and peer reports were not read. Launch parameters and provider-internal isolation are orchestrator evidence, not independently observable by this child.
- Bounded actions: Git status/ref/log/show/diff; source/AST inspection; ZIP/JSON/hash/line binding diagnostics. No full campaign, package installation, external writes, policy/code/test changes or delegation. This report is the sole written file. No credentials were printed.

## Blocking findings

1. **HIGH, admission/evidence:** all 48 entries and the owner policy expired at the end of `2026-11-03`. `bandit-triage.cjs` checks expiry before later bindings and correctly rejects the live stage. The raw failure is `Bandit review expired: tools/check_repository_layout.py:B404:12`. A date-only edit would suppress that first failure while leaving the changed-source/line failures below. Impact: #169 AC05/AC11 and production security gate; treatment: preserve failed report, record actual dated per-context review, then narrowly update the existing disposition records only after required independent review. This report does not choose or authorize a future expiry.
2. **MEDIUM, source/evidence:** the five `tools/check_ri_ci.py` rows pin obsolete SHA256 `6bd4f27642e43d2afdd6b452fa80fe6c8a5092991fa83d5b83a4f11c7906cf46`; current SHA256 is `e02ff0e3efd55fed749e9ab0c7993a050a5cb76c003df96c33f26e2dad2b7cb4`. Four finding lines moved: B102 301→360, B607/B603 375→438, B105 430→493; import B404 stays16. All five exact finding-line SHA256s are unchanged. Seven other source files and all their existing line identities are exact matches. Impact: same AC/gate; treatment: source/line rebind only with actual reviewed delta and preserved rules, levels, confidence, owners, cases and scanner. No new finding disposition is required by the inspected source delta.

## Trust boundaries and per-file assessment

B404 records imports rather than a distinct execution surface. B603 calls use argv arrays and default shell=False; arguments do not become shell text. B607 is a real environment assumption: Git/Node resolve through trusted CI/developer PATH. This review does not assert absolute executable identity or a hostile-candidate sandbox. B102 deliberately executes repository-owned module/test bytes with ordinary interpreter privileges; path/selector validation bounds selection, not the effects of those module bodies. Removing exec mechanically would not remove the inherent test-execution trust boundary. B105 contexts are boolean report state, with no authentication consumer or secret string.

- `tools/check_code_style.py`: B40413; B607/B603249 read fixed `git show` at literal frozen BASELINE, with safe relative path validation; B105270 returns boolean success metadata. Checked safe_path and baseline call construction. Existing scoped classification remains justified; trusted Git/PATH/root remain assumptions.
- `tools/check_repository_layout.py`: B40412; B60390 builds fixed `git -C root ls-tree`, literal frozen BASE, optional fixed flags and pathspecs after `--`; B607/B60399 fixed `git show` baseline lookup; B102227 compiles exactly `root/tools/repository_intelligence.py`, then treats Markdown body as data; B607/B603431 fixed tracked/untracked inventory; B105496 boolean result. Checked file_path validation and callers. Root is the checked-out repository, not a sandbox. Existing classifications remain justified.
- `tools/check_ri_ci.py`: B40416; B102360 loads repository tests selected from mapping, after safe_path validation and expected unittest-discovery argv shape; B607/B603438 fixed Git helper called with validated full commit SHAs or literal operations; B105493 boolean result. No mapping-provided shell command is executed by the static workflow parser. Its lexical parse/reachability guarantee remains limited; it is not proof remote jobs passed. Detailed delta below. Existing contexts remain justified after exact rebind.
- `tools/issue_acceptance.py`: B40416; B102191 loads sibling repository_intelligence to parse Markdown, never evals Markdown; B607/B603196 fixed Git helper whose callers use literal metadata operations; B607/B603201 fixed ls-files; B607/B603214 git diff explicitly disables external diff/textconv; B607/B603219 fixed untracked inventory; B102262 compiles one selected repository test module from current bytes; selector regex permits named test/class/method, not expression text; B607/B603312 invokes fixed Node Basic argv with300s local timeout; B105352/473 boolean report state. Read policy schema, test loader, source identity and command callsites. Existing MEDIUM exec classification remains real trusted code execution, and appropriate only for reviewed repository/developer execution as `.github/ACCEPTANCE.md:103` explicitly states. No hostile-input isolation is claimed.
- `tools/quality/browser_archives.py`: B40414; B607/B603106 fixed Node/runtime path and internally selected describe/probe command, browser allowlist chromium/firefox/webkit, shell-free argv and120s timeout; B607/B603174/176/263 fixed Git rev-parse/status. Checked describe callers pack/restore and authenticate. Restore describes installed runtime before fetching; probe launch is producer-only. B105451/489 are boolean report fields. Browser flow separately handles a scoped read token through API calls; those booleans are unrelated to authentication. Existing scoped classifications remain justified; no credential value was inspected or emitted.
- `tools/quality/python_toolchain.py`: B105124 is True returned only after locked installed-graph checks. No credential or authentication behavior in that expression. Revalidation remains justified; separate audit compatibility exceptions are not authorized or changed here.
- `tools/repository_intelligence.py`: B40417; B607/B603193 fixed git ls-files --stage -z inventory with15s timeout. Inspected bounded scan, symlink/path validation and tracked-mode rejection. Repository root enters as one argv item; no shell interpolation. Existing classification remains justified.
- `tools/run_repository_tests.py`: B10247 compiles current selected test files, intentionally bypassing stale bytecode. Read selected_modules, enduring_suite, import state restoration; tests directory is explicit ordinary developer input, numbered issue modules excluded and direct symlink files rejected. This is not safe execution of arbitrary hostile tests; current source states ordinary enduring regressions. Existing MEDIUM classification remains justified within that boundary.

## Actual prior-baseline delta

Policy top-level inspected baseline is historical `7b86ff1e3128b09060d8c5422f6884ed8ccbfef7`; later per-row revalidations supersede original source hashes. Therefore I located actual matching prior `check_ri_ci.py` bytes through Git history, independently hashing revisions. Matching revision: `323451562fc8e89e31fc604ac94536fec18820a1` (SHA256 above). Comparing that revision with inspected HEAD yields exactly the same changed Python file/scope as task-base→HEAD:67 insertions,4 deletions in71changed lines.

- Old line119/current119 adds `source_shards_reachability` through current167: static exact-string requirements for eight shards, pinned runner/timeout/checkout/command forms, forbidden optional upstream failures, exact downstream needs and first fail-closed matrix-result check. It does not launch a subprocess, import candidate module, eval workflow data or change test selector inputs.
- `workflow_commands` old119/current170 gains optional `reachability_adapter`. Around old211/current262, only exact `source-shards-v1` in ready-pr scope enables the reviewed Basic adapter; otherwise existing needs rejection remains. Around old217/current272, adapter uses its exact always()/Draft guard; original branch remains.
- `validate_definition` old361/current420 forwards the adapter field from mapped data into the static validator. Validation still requires command discovery and then resolve_tests.
- Independently compared attribute-free Python AST: `safe_path`, `resolve_tests`, `fixed_diff`, and `verify` are identical old/current. Finding statements and line hashes are identical; their moves are insertion-only consequences. Import is unchanged. The new parser route does affect control validation, so this is substantive review rather than an assertion of whole-file AST equality. It adds no executable command/selector authority to these Bandit contexts.
- Complete relevant base→HEAD inspection also found12insertions/2deletions in `scanners.cjs`, all in two exact public-inventory secret-fingerprint handling paths. Bandit engine/triage invocation and scope are unchanged; those secrets decisions are outside this assigned Bandit judgment. `bandit-triage.cjs` and `bandit-policy.json` have no task-base→HEAD diff.

## Exact 48-row reconciliation

Each row below was independently matched by path, test_id, test_name, severity, confidence and current line SHA256 against existing policy. For unchanged files the exact line number also matched. For changed check_ri_ci rows, matching used the preserved unique rule and line hash. Duplicate opening call-line hashes in issue_acceptance at214/219 are disambiguated by their unchanged exact line numbers and enclosing Git call AST; line hashes alone are not unique identifiers.

| Path | Rule | Policy line → raw line | Severity / confidence | Source/line result |
| --- | --- | --- | --- | --- |
| `tools/check_code_style.py` | B404 | 13 → 13 | LOW / HIGH | source + line exact |
| `tools/check_code_style.py` | B607 | 249 → 249 | LOW / HIGH | source + line exact |
| `tools/check_code_style.py` | B603 | 249 → 249 | LOW / HIGH | source + line exact |
| `tools/check_code_style.py` | B105 | 270 → 270 | LOW / MEDIUM | source + line exact |
| `tools/check_repository_layout.py` | B404 | 12 → 12 | LOW / HIGH | source + line exact |
| `tools/check_repository_layout.py` | B603 | 90 → 90 | LOW / HIGH | source + line exact |
| `tools/check_repository_layout.py` | B607 | 99 → 99 | LOW / HIGH | source + line exact |
| `tools/check_repository_layout.py` | B603 | 99 → 99 | LOW / HIGH | source + line exact |
| `tools/check_repository_layout.py` | B102 | 227 → 227 | MEDIUM / HIGH | source + line exact |
| `tools/check_repository_layout.py` | B607 | 431 → 431 | LOW / HIGH | source + line exact |
| `tools/check_repository_layout.py` | B603 | 431 → 431 | LOW / HIGH | source + line exact |
| `tools/check_repository_layout.py` | B105 | 496 → 496 | LOW / MEDIUM | source + line exact |
| `tools/check_ri_ci.py` | B404 | 16 → 16 | LOW / HIGH | source rebind; line hash exact |
| `tools/check_ri_ci.py` | B102 | 301 → 360 | MEDIUM / HIGH | source rebind; line hash exact |
| `tools/check_ri_ci.py` | B607 | 375 → 438 | LOW / HIGH | source rebind; line hash exact |
| `tools/check_ri_ci.py` | B603 | 375 → 438 | LOW / HIGH | source rebind; line hash exact |
| `tools/check_ri_ci.py` | B105 | 430 → 493 | LOW / MEDIUM | source rebind; line hash exact |
| `tools/issue_acceptance.py` | B404 | 16 → 16 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B102 | 191 → 191 | MEDIUM / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B607 | 196 → 196 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B603 | 196 → 196 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B607 | 201 → 201 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B603 | 201 → 201 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B607 | 214 → 214 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B603 | 214 → 214 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B607 | 219 → 219 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B603 | 219 → 219 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B102 | 262 → 262 | MEDIUM / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B607 | 312 → 312 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B603 | 312 → 312 | LOW / HIGH | source + line exact |
| `tools/issue_acceptance.py` | B105 | 352 → 352 | LOW / MEDIUM | source + line exact |
| `tools/issue_acceptance.py` | B105 | 473 → 473 | LOW / MEDIUM | source + line exact |
| `tools/quality/browser_archives.py` | B404 | 14 → 14 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B607 | 106 → 106 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B603 | 106 → 106 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B607 | 174 → 174 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B603 | 174 → 174 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B607 | 176 → 176 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B603 | 176 → 176 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B607 | 263 → 263 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B603 | 263 → 263 | LOW / HIGH | source + line exact |
| `tools/quality/browser_archives.py` | B105 | 451 → 451 | LOW / MEDIUM | source + line exact |
| `tools/quality/browser_archives.py` | B105 | 489 → 489 | LOW / MEDIUM | source + line exact |
| `tools/quality/python_toolchain.py` | B105 | 124 → 124 | LOW / MEDIUM | source + line exact |
| `tools/repository_intelligence.py` | B404 | 17 → 17 | LOW / HIGH | source + line exact |
| `tools/repository_intelligence.py` | B607 | 193 → 193 | LOW / HIGH | source + line exact |
| `tools/repository_intelligence.py` | B603 | 193 → 193 | LOW / HIGH | source + line exact |
| `tools/run_repository_tests.py` | B102 | 47 → 47 | MEDIUM / HIGH | source + line exact |

## Current source identities

| File | Findings | SHA256 | Binding |
| --- | --- | --- | --- |
| `tools/check_code_style.py` | 4 | `351fb58d39f7f9866bca52f04bc0ebb3f049600c9e3a694602b06cc04f443d3e` | unchanged exact source |
| `tools/check_repository_layout.py` | 8 | `bb72d6bd8f5d8d2eea158023168ddd7ff99fc37513d9a51e45273caddd18c42b` | unchanged exact source |
| `tools/check_ri_ci.py` | 5 | `e02ff0e3efd55fed749e9ab0c7993a050a5cb76c003df96c33f26e2dad2b7cb4` | stale policy source pin; five entries affected |
| `tools/issue_acceptance.py` | 15 | `c4d98db96844f19d73e4f66d389d3c54b5f0eead60029395d77d970c18950a97` | unchanged exact source |
| `tools/quality/browser_archives.py` | 11 | `923246e127acc3d16283859279000b56371150314c205d8f345166cdf9ac29e1` | unchanged exact source |
| `tools/quality/python_toolchain.py` | 1 | `0bc77dbfb3763758b06f0c46d62b9778a70b988593a3f0a3687fce2b3e508905` | unchanged exact source |
| `tools/repository_intelligence.py` | 3 | `dad68d88d241c2cd223081d6a28961c1aa7abc19c0f4c223c9c3382c562aa792` | unchanged exact source |
| `tools/run_repository_tests.py` | 1 | `389d90fd8fd02a4587e3cf3c5543ffe00cde1caee8614e88a262d72dbb12924d` | unchanged exact source |

## Prompt and control identities

| File | SHA256 |
| --- | --- |
| `AGENTS.md` | `f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01` |
| `CONTRIBUTING.md` | `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442` |
| `agents/reviewers/README.md` | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| `agents/reviewers/code-review.md` | `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697` |
| `guides/CODE-STYLE.md` | `cdef877504055734d653af12237fc708f3e3636dd15dfc0703f71e0f6c87ee40` |
| `tools/quality/scanners.cjs` | `d5ce0402b9abfd5f9e3d385e31991fded746d40b018cadc49099fc620d6cfde1` |
| `tools/quality/bandit-triage.cjs` | `597454f795bf287c7eee5765db0b88589741e96c3f991091669db14275884564` |
| `tools/quality/bandit-policy.json` | `45a2ec82fc755c0edc93e5ec7b7314d2d970f213ad3c69a28e6d1897862feb5c` |

## Required next bounded treatment

A dated review-backed update of existing48dispositions plus exactly the five-source/four-line rebind is supported by inspected evidence. Preserve all raw findings, original MEDIUM levels, rule/test/confidence, per-row owners, line hashes, coverage inventory, scanner1.9.4, limits and failure accounting. Do not replace the gate, skip Bandit, add nosec, broaden matching or treat fresh dates as substantive review. Choose the next review deadline as an explicit owner-policy decision justified by this review, then have a distinct reviewer inspect the actual policy diff; this preimplementation judgment is not approval of uninspected edits.

Current production remains blocked by retained Bandit failure and the separately reported secrets gate. This review establishes no secrets classification, hosted success, privileged CI isolation, production artifact acceptance or release approval. No attack execution, live GitHub check or fresh full campaign was performed. Recheck source hashes against any later candidate before reusing this result.
