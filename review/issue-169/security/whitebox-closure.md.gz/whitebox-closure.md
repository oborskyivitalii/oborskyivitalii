# White-box QA — WB-C1 / RQ-F2 metadata closure

**PASS: WB-C1 is closed for candidate v3.** The equivalent omitted-disclosure defect identified as RQ-F2 is corrected in the inspected execution wrapper. No new defect found in this bounded metadata delta. This is the same White-box role continuing after its first and correction outputs; no fresh-context execution is claimed.

Candidate packet `/workspace/scratch/f4dcb060a703/security-review/candidate-v3.json` SHA256 `40b82a1607e0b10be6ffa0ed8f53fb9afbfb3c705e338e78e139525590556ef6`, prepared tree `904d4de3eba163d64180136f78b4baf1691d1615`, base `95d3e78d7e76d3e267351b8ca1efff206f99b748`. All173 repository pins and both external pins independently match their actual bytes; this remains a prepared subset, not a clean checkout.

## Executed closure checks

| Protected invariant / fault | Actual read-only check and result |
| --- | --- |
| Disclosure matches the actual role source | Requirements' intact first output, decoded line14, explicitly discloses git write-tree and possible Git-object creation. Code's intact first output, decoded line30, does likewise. Both current execution rows explicitly retain that operation, the non-read-only boundary, and reported no source/test/policy/index-content alteration. WB-C1's mismatch is removed. |
| Repair does not rewrite first execution identity | Deep comparison of old/new execution wrappers finds only four deviation strings and chronology changed; every requested launch, accepted task handle, prompt/packet/tree identity and result reference/digest remains exact. |
| Prior inaccurate evidence preserved | `reviewer-executions-v2-inaccurate.json.gz` archive hashes exactly to the v2 wrapper pin. Its Requirements row still contains the former inaccurate None-reported claim. This retained negative contrasts with the corrected row and actual first-report disclosure. |
| First results remain immutable | All4 compressed first outputs decode byte-for-byte to their actual original local outputs, and all4 decodedResultSha256 fields match. No first result is substituted by a correction. |
| Corrections and prior packet remain immutable | All4 correction archives decode exactly to their actual prior outputs; archived candidate-v2 bytes equal the supplied v2 packet. |
| Existing source/guard results can be reused | All52 overlapping core tools/tests/prompts/security-evidence pins are unchanged. Storage manifest, proof, policy, ledgers, native evidence, scanner and tests remain exact; no source-verification campaign is invalidated by this delta. |
| Prior RQ-F1 closure preserved | Recomputed all8 provenance archive/decoded hash pairs against actual targets:8/8 match. |

Observed v2→v3 pin delta consists of the execution wrapper, dated report, four RI/navigation views, and six added preserved packet/correction/wrapper archives; no v2 pin is removed. The dated report now explains that Requirements also disclosed git write-tree, preserves the inaccurate wrapper and keeps affected closure pending at that recorded point in chronology. Its earlier Code disclosure is retained. Other rows refer to actual verbatim limits instead of asserting an unverified absence of all deviations.

Two bounded Python stdin diagnostics executed from `/workspace/scratch/f4dcb060a703/repo` using pathlib/hashlib/gzip/JSON only; both exited0. No source/Git-object/external writes, scanner, browser or full test campaign occurred. Only this assigned closure file is written.

My first output remains SHA256 `5fc35c26dcaf434adb00e67381c9f7088daf53183e0e840480c1f4077f43e22d`; correction remains `e544bcb06358854a3461eb918df509c5e5225953002d773630102c2403a89601`. Both are preserved separately. Post-first reconciliation exposure includes execution metadata, retained Requirements/Code operational-disclosure lines and hash-only comparison of other result/correction bytes. No peer verdict is adopted as a test oracle.

## AC impact and limits

This resolves the specific inaccurate-execution-accounting obstacle to AC05/AC11. The actual git write-tree deviations remain disclosed historical facts; metadata repair cannot turn those runs into strictly read-only executions. The orchestrator remains responsible for their protocol disposition. Requested/accepted tool metadata supplies an operational none-fork record, not evidence of provider model/context internals or OS isolation, which remain unknown.

Prior White-box checks and limits are reused only for unchanged inputs. This closure does not expand per-ID semantic adjudication, replay native producers, re-prove excluded generated fields, reconstruct unavailable archival artifacts or settle another role's remaining coverage limits. A genuinely unresolved classification/source dependency remains blocking. Hosted source security/staging/full regression, protected integration, production rights/archive and actual served checks remain separate mandatory gates; this metadata result cannot establish them or close the whole issue.
