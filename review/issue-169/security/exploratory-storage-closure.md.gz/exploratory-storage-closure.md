# Exploratory QA — affected storage closure

Verdict: no new blocking defect reproduced in the affected retrieval/evidence flow. The ten added historical archives are byte-lossless, all sixty locators lead to existing archives, and the updated storage manifest and provenance wrapper agree. This is a same-role continuation, not fresh independent review or successful website delivery.

Scope: two-minute read-only diagnostic review of candidate-v4; no scanner, whole suite, browser campaign, Git-object/repo/source or external writes. Only this report is written. Prior first and correction results remain intact. Post-first metadata and factual reconciliation were exposed in this continuation; peer verdicts were not used as substitutes for these observations. Provider context/model internals remain unknown; operational none-fork receipt metadata is not provider attestation.

Packet SHA256 independently matched `a0feb8a8d17c8e09076723a7a96386f91ca8304b9e1230bcb0f4fbfdd2ee28ae`; prepared tree `3d6fd1617885f5efe83ec9999b2319c4edea1bca`, base95d3e78. All198 supplied path/byte pins independently matched. This remains a prepared subset rather than a clean checkout.

| Expected flow / invariant | Own action and actual observation | Result |
| --- | --- | --- |
| Recover original report bytes | Decompressed every historical-storage manifest row and compared to its exact `sourceCommit:path` using read-only `git show`; recomputed stored and decoded hashes. Sixty records, zero byte/hash failures. | Pass |
| Preserve earlier accepted storage evidence | Compared the current manifest's first50 records to the v2 manifest read from its prepared tree. Exact ordered prefix equality. | Pass |
| Navigate from original paths | All sixty original-path stubs name their existing gzip archive. Existing decoding/storage-proof route is retained. This does not assert former rendered anchors survive compression. | Pass |
| Current wrapper identifies current manifest | Independently recomputed archive and decoded SHA256 of all eight provenance receipt targets. Eight matched, no stale binding. | Pass |
| Keep actual chronology and prior role work | Own archived correction decompresses byte-identically to its original scratch report. Current execution metadata explicitly records both Requirements and Code `git write-tree` disclosures and points to original verbatim results; no new provider-isolation claim was observed. | Pass |
| Retain fixed-bound failure truth | Read `final-storage-correction.json.gz`: measured250014131 against fixed250000000, difference14131. The record preserves failure at `tools/staging/state.cjs` and lists the ten new archives and saved68776 bytes. Arithmetic is consistent. No RI config or producer change exists in v2-to-v4 prepared-tree diff. | Pass for recorded failure and unchanged rule |
| Keep substantive correction unchanged | Compared v2/v4 packet pins and prepared-tree path delta: policy, ledgers, classification proof, scanners/rules/toolchain/tests/public/native source stay byte-identical. Delta consists of historical report storage plus receipt/index/status metadata. MEMORY was hash-compared only, not read. | Pass |

An initial relative-path lookup ran from scratch and found no RI files; it was corrected by using the repository working directory. No conclusion relies on that failed lookup. The fixed-bound record is retained author evidence: I checked its arithmetic, unchanged source identity and actual lossless storage delta. I did not rerun RI build/verify or independently observe its new successful execution in this continuation. In particular, subtracting recorded savings from the earlier failure is not a fresh final-source inventory measurement; receipt/index growth can also consume bytes.

No full executable-consumer search was repeated. Claims that archived reports have no parsed/executable consumers and lie outside untriaged paths remain bounded source-review subjects, not facts inferred from compression. All semantic provenance and qualified archival limits from my earlier review remain applicable. The public source boundary remains unchanged, so earlier exact admission/expiry and eleven negative-control observations may be reused for those unchanged bytes, with their original execution identities.

Disposition: retain this sixty-archive equality/locator/wrapper diagnostic under issue169 AC05/AC11. No accepted tests or registry entries were authored. Existing scanner/source/profile routes remain unchanged. Actual current-source RI/CI receipts, all required affected-role closures, complete owner staging, control/merge/rights/archive and served article/PDF verification must remain separately evidenced. No hosted/stage/production/platform pass is inferred here.

Recorded UTC: 2026-11-06T10:41:03.532787+00:00
