# White-box QA — WB-S1 source-reference closure

**PASS: WB-S1 is closed for the inspected source-reference correction.** The final60-record source, predecessor50-record source and unchanged approved target are now separately and accurately bound. No new defect found in this bounded delta. This remains the same role's affected continuation; all earlier reports, findings and limits remain preserved.

Input: `/workspace/scratch/f4dcb060a703/security-review/source-reference-fix-packet.json`, SHA256 `d4240230fac83293621139f4ea817482e4361edb49bf14bca3ae397c59b8ce2f`; prepared tree `9eeccfc21f07da7b5338f3a856c852f57cf632d3`. Previous packet is the preserved candidate-v4 SHA256 `a0feb8a8d17c8e09076723a7a96386f91ca8304b9e1230bcb0f4fbfdd2ee28ae`. This is a prepared subset, not a clean checkout.

## Actual checks and results

| Invariant / fault | Independent observation |
| --- | --- |
| Current pinned bytes | All198 repository pins match; no removed v4 pin. The packet has no externalPins list; sourceFix external source identities were separately verified directly below. |
| Exact affected delta | Compared current pins with v4: only provenance.json.gz and generated agent-context.json change. Read old wrapper through Git show at the supplied v4 prepared tree; its archive hash matches the v4 pin. |
| Documentary correction only | Deep wrapper comparison finds four changes, all within receipts[5]: source, sourceSha256, predecessorSource and sourceCapture. Every other wrapper field, including all target archive/decoded hashes, remains equal. |
| Actual final source | `/workspace/scratch/f4dcb060a703/security-review/historical-storage-60-9cf9a6b12938.json` contains60 records, has current mode0444, and hashes to `9cf9a6b129388d1a57ab74663a29e058fc06b2b605338dfc52a5d5bcef017730`, matching sourceSha256 and decodedSha256. Its bytes equal the decoded approved target. |
| Predecessor retained accurately | Original `/workspace/scratch/f4dcb060a703/security-review/historical-storage.json` remains50 records, SHA256 `ca4f2fa84e859b5eacc6aa00db7ddc39293e21b7b38fb713ab25e7eaa6b63b41`, matching both my prior observed bytes and the explicit predecessorSource identity. Those50 rows equal the final manifest's first50 rows. |
| Target unchanged and reproducible | In memory, encode actual final-source bytes using gzip.GzipFile(filename='', compresslevel=9, mtime=0): result is byte-identical to approved historical-storage.json.gz. Target archive remains SHA256 `38b76cdb38053c03436059d298f80574cda045a42f3d22bb6174a07c65cb8eba`, the unchanged v4 pin. |
| Complete receipt source chain | All8 source→decoded byte comparisons, compressed target SHA256 and decoded SHA256 checks match. The former50→60 mismatch is removed. |
| Current navigation / fixed bounds | Configured RI verify exits0 with Repository Intelligence context is fresh. Producer/config/bound owners are unchanged from the already inspected v4 inputs. |

Diagnostics were bounded read-only Python stdin comparisons using hashlib/gzip/JSON, one Git show read of an existing tree, and `python -B tools/repository_intelligence.py --config .github/repository-intelligence-config.json verify`; all exited0. Re-encoding used BytesIO, so no temporary archive or source was written. Python gzip.compress uses a different header on this runtime and did not reproduce the target; the explicitly parameterized GzipFile method did reproduce every byte. This is an encoding-method difference, not a target integrity failure.

The recorded sourceCapture explicitly calls the final source a digest-named snapshot of the authored final manifest and disclaims independent generation or historical-event proof. The observations support current snapshot/source/target equality and reproducible encoding. They do not establish how the manifest was originally authored, that a historical capture event occurred as narrated, or that mode0444 is an OS-enforced immutability boundary. No stronger source-generation assertion is inherited.

## Acceptance impact and remaining limits

WB-S1's exact-source traceability defect is repaired for AC05/AC11. All reviewed core policy/ledger/proof/native/public/scanner/test and60-report storage bytes remain unchanged, so the prior affected storage and guard results may be reused within their original scope. The original WB-S1 report remains intact as the first finding; this closure does not rewrite it.

No scanner, browser or full test campaign was run. No Git-object, source, policy, test, repository or external write occurred; only this assigned report is written. This continuation is not a fresh context, and provider model/context internals remain unknown. Previous semantic-adjudication, native-replay, excluded-field, archival-authenticity and bounded consumer-search limits remain. Any genuinely unresolved classification/source dependency remains blocking. Hosted source security/staging/full regression, protected integration, production rights/archive and actual served delivery are separate mandatory gates; none is supplied by this documentary closure.
