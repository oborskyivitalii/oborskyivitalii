# Requirements & Acceptance — independent security-maintenance preflight

Date: 2026-11-06. Owner: #169. Execution: PR170. Phase: first independent preimplementation judgment. Verdict: **bounded maintenance diagnosis and evidence preparation fit the existing authorized website-production task; security acceptance and dependent release advancement remain blocked.** No completed maintenance candidate was supplied, so this is not implementation approval or final acceptance.

## Input identity and inspection boundary

- Repository checkout: `/workspace/scratch/f4dcb060a703/repo`; actual HEAD `95d3e78d7e76d3e267351b8ca1efff206f99b748`; tree `28a95e053b0036bc7e1e947232847dd51ce410ff`; base `8cf15883125892710633b17133d9ee0fc4b23b92`. `git status --short` was empty at inspection.
- Supplied neutral packet: `/workspace/scratch/f4dcb060a703/security-review/packet.json`; actual SHA256 `1862a1dacb7b3d3622e20b519c320d1ec7794eb89f1f1a8fd248f8e6c3fc7b26`. All listed source-file SHA256s matched at inspection.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Requirements prompt SHA256 `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`; CONTRIBUTING SHA256 `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442`.
- Owner snapshot `/workspace/scratch/f4dcb060a703/release-diagnosis/issue169.json`, SHA256 `fcca751ea21a7742ef4ca8eabe0dd89b1e966013ed7b059d33e086c0f7893376`, observed snapshot updated 2026-11-06T08:38:01Z. This is dated supplied evidence; no independent live GitHub query was performed.
- Raw archive `/workspace/scratch/f4dcb060a703/release-diagnosis/staging95-preflight-42196241166.zip`; verified SHA256 `f07cb361798e5c35ec326f5a1f6e755331abdfa570128264bc9930a7055397de`.
- Read root instructions, README, relevant map routes, common/role prompts, CONTRIBUTING independent-review/failure protocol, acceptance/RI contracts, release security contract, quality README, scanner and Bandit/generated-checksum/triage owners, policy/ledger metadata, supplied owner snapshot and raw reports. No nested AGENTS existed beneath tools/.github/agents/guides. No MEMORY, parent notes, peer output or private conversation was read. Registry/rule code inspection was bounded and is not a full security audit.
- No delegation, tests, scanner reruns, implementation/policy changes or external writes were performed. Only this assigned report was written. Actual no-conversation-inheritance launch receipt belongs to the orchestrator; provider-internal context/model isolation is unknown to this reviewer.

## Findings and required treatments

### RQ-S01 — Blocking: expired Bandit acceptance cannot be repaired by date alone

`tools/quality/bandit-policy.json` has 48 rows, all governed by reviewBy 2026-11-03. Raw stage `bandit-triage.json` fails expiry. Actual raw Bandit has 48 findings, zero scanner errors, 43 LOW and 5 MEDIUM findings across eight Python files. Rules: B404=6, B607=14, B603=15, B105=8, B102=5. These observations neither classify the findings nor establish safe reachability.

Policy-vs-raw comparison of `(path, rule, line, test_name, severity, confidence)` shows four raw-only and four policy-only tuples. All four differ inside `tools/check_ri_ci.py`; four reviewed line hashes also mismatch. Its actual source SHA256 is `e02ff0e3efd55fed749e9ab0c7993a050a5cb76c003df96c33f26e2dad2b7cb4`, differing from policy. The seven other policy file digests match. Policy coordinates B102:301, B607:375, B603:375, B105:430 correspond to current raw B102:360, B607:438, B603:438, B105:493; B404:16 remains at the same coordinate. This is correspondence evidence, not proof that context is unchanged. Base-to-head source diff adds source-shard reachability validation and changes workflow interpretation.

Treatment: re-examine actual current finding contexts and call/input/PATH/exec/fixture trust boundaries, including the changed RI validator, against the raw current report; retain each finding and coverage accounting. Reconcile exact source/line/rule signatures. Renew only findings supported by an independently reviewed, specific rationale and a justified finite review condition/expiry. Fix any actionable finding within scope. Record risk acceptance separately from false positives, with the required owner/issue/scope/expiry decision. This reviewer supplies no blanket renewal or safety decision. AC05/AC11 and the mandatory security gate remain open.

### RQ-S02 — Blocking: unclassified secret candidates lack an acceptance oracle

Actual raw `detect-secrets.json` contains 9,092 findings in 408 files: 8,918 Hex, 75 Base64, 94 Secret Keyword, and 5 Basic Auth candidates. The actual security engine reports 1,016 untriaged candidates after its admissions. The supplied local-filter observation of 1,024 has not been reconciled here with stage bytes, line coordinates, generated proof and integrity admission inputs. Neither count establishes that candidates are false positives or real credentials.

Treatment: retain a hashed-only exact tuple inventory and reconcile actual stage findings through the existing admission sequence, with stage artifact/source bytes and the producer/integrity proofs that were used there. Account for every raw occurrence and deduplication rule. Then inspect every remaining candidate's exact source context privately and record its noncredential provenance or actual security treatment; an aggregate count or a checksum-shaped substring is insufficient. Never print candidate values. Distinguish source mismatch from a new finding. Include any unknown/unreadable candidate as unresolved. New current-candidate findings require the same treatment.

`scanners.cjs:433–535` admits a closed list of four ledgers, with exact path/type/hash identities, no duplicates and a 2,000,000-byte bound each. Their inspected sizes are 1,996,285; 1,999,782; 1,238,968; 1,924,551 bytes respectively. Preserve historical baseline and frozen ledger bytes. A proved exact checksum record may use the existing appropriate nonfrozen companion if its actual schema/meaning and remaining capacity allow it. Measure final bytes; do not enlarge bounds or add arbitrary admission authorities. Proof-driven generated admission must remain field/path/line/source-bound and reject stale, wrong-field and unknown data. Any modification of proof authority is a substantive control change requiring renewed Requirements and Code/QA review.

`triage-secrets.py` is a manual aid, writes the historical baseline, and contains a broad metadata-JSON classification branch. Running it unmodified or accepting its labels wholesale would not satisfy preservation or independent per-candidate classification. It is not the authorized shortcut. AC05/AC11 and mandatory security acceptance remain open.

### RQ-S03 — Gate linkage: preserve authorized intent while adding explicit maintenance proof

The owner snapshot explicitly authorizes website production through the existing native/review/staging/merge/production process and reserves platform posting for the author later. Its dated amendments supersede the older preparation-only and three-figure boundaries. No new owner, publishing engine, article/PDF/runtime amendment, general scanner project or platform publication is necessary for this correction.

Keep #169/PR170 and stable AC IDs. Before substantive code/config edits, add an explicit maintenance subcondition under AC05/AC11 in the dated owning review route: unchanged accepted R10 manuscript/PDF/visual/runtime bytes; exact raw candidate reconciliation; current justified Bandit dispositions; classified exact secret identities; unchanged scanner engines/versions/rules/coverage/budgets/limits; negative controls and source-bound review. Record style rule/check allocation if code/config changes. This sharpens the existing security obligation without changing editorial acceptance to suit a fix.

## Traceability and current observations

| Intent / AC | Required oracle or owner gate | Observed result / next evidence |
| --- | --- | --- |
| Existing R10 website production; AC04/09 | Existing controller; accepted stage → identical merged source tree → frozen production edition → served article/PDF verification | Not supplied as successful. Stage42196241166 prepublication is clean at the stated source/tree but fails security. |
| Preserve accepted manuscript/PDF/figures/runtime; AC07/08/09/10 | Exact before/after byte manifests plus unchanged applicable native/runtime checks | No change performed here; preservation must be proved for the future maintenance diff. |
| Security/repository hygiene; AC05 | Complete Semgrep/Bandit/secrets execution, unchanged coverage and policies, exact-source RI/CI/owning checks | Raw Semgrep: 0 findings, 0 errors, 365 scanned paths; Bandit and secrets block. Existing Basic/RI/owning green is packet context, not re-executed proof. |
| Exact security dispositions; AC05/11 | Source-bound independent classification, meaningful failure controls and current scanner acceptance | Missing candidate classifications/current renewal decisions. No acceptance inferred from hashes or policy row counts. |
| Independent review; AC05/11 | Four completed distinct none-fork source-bound roles; affected correction review | This is Requirements preflight only. Completed candidate and other roles remain required. |
| Manual LinkedIn/Medium later; AC04/09/11 | Author editor/posting; actual article URLs and equivalence/backlinks; later paired materials update | Remains pending and does not block initial website publication. No platform action authorized to this reviewer. |

## Actual diagnostics and next gate

Read-only diagnostics verified Git head/tree/clean status; packet/file/archive hashes; raw report checksums, keys and counts; Bandit policy/source/line/signature reconciliation; ledger metadata and byte sizes; and the base-to-head RI validator diff. Raw prepublication has 26 checks, exactly one failure (`security`), with original security timeout 180,000 ms and elapsed 86,639 ms. Keep that failed campaign intact. Raw security binds artifact digest `9806762fa00dcdeeb73f2efb11434ff8b81ef0e672a9029e8081fbdc5bcb59d5` and stage run42196241166/attempt1; failure is not a staging pass.

Raw report SHA256s: `prepublication.json` = `06d073dc227f712d0e6e938742edfb36d68d6325677c8d6eb0e24d8b45c0a8f8`; `security.json` = `2e78fd7b644c08bdfa69d45d445e091ec6ef74a21b015395ceb00645067666e2`; `bandit.json` = `9236d506595cafad7e398e1b27fe9b013b6e098d8ab14686dd404bbbb1f09364`; `detect-secrets.json` = `e3ea55b6318c052c94005e70f860d53b5133a7900879e264134b67b650649f3a`.

The smallest next action is a bounded artifact-context reconciliation and private per-candidate classification, plus changed-source Bandit context review, before proposing exact policy/data changes. Then prepare a minimal reviewed maintenance diff, retain old failures and exact classifications, run the existing targeted `tests/quality-sources.test.cjs` selection with its stale/unknown/wrong-field/source/expiry/coverage negatives, applicable Basic/RI/CI/owning checks and security scan. If control logic changes, review and test its specific invariants through the existing profile/RI routes. Preserve all original limits and no-new-debt obligations.

A completed new candidate needs fresh affected independent Requirements/Code/White-box/Exploratory results and exact-source staging admission. Old evidence may support only demonstrably unchanged bytes and the claims it actually observed; it cannot confer a successful stage on a changed tree. The existing user production authorization persists; a real new scoped risk exception requires its substantive reviewed decision, and a missing credential classification cannot be converted into permission to release. No website/production or whole-issue completion is established by this preflight.
