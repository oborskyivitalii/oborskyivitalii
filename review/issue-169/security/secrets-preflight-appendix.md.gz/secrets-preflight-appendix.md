# Secrets preflight evidence appendix

The first report remains unchanged. Neutral reconciliation gives1024 prior tuples,1016 remaining,8excluded,0added. All eight exclusions are the four source/Git/semantic fields in each frozen R3/R4 edition after pinned history became available to the unchanged producer. Source95 and the actual stage artifact remain unchanged. This reviewer inspected the set relationship but did not execute that producer.

The inventory indexes all1024 prior tuples, with exact1016_member selecting the actual remaining scope. A separately marked prospective policy tuple binds current check_ri_ci.py SHA256 to its five source-pin occurrences; it is not claimed scanner-observed. Each record preserves source identity, exact character/UTF8 spans, parsed field or redacted context, declared referents, byte comparisons and Git identity/tree relations. No ledger or scanner was edited.

Archive SHA256 5d18793fc1254b2c3e48e9c3e558fea3f19f74bd5361f81df7383481aeb97546; decoded JSON SHA256 c93e3e455c984b2b029965e7c2196e7f3f2962df26efddd2a4c556519a2ea9b0.

| Comparison category | Original records |
| --- | ---: |
| available-git-identity | 145 |
| residual-needs-provenance | 346 |
| synthetic-negative-auth-fixture | 1 |
| tracked-or-decoded-byte-equality | 532 |

| Evidence class | Original records |
| --- | ---: |
| proved-byte-equality-declared-binding-needs-review | 34 |
| proved-declared-file-bytes | 498 |
| proved-git-object-identity-field-meaning-recorded | 145 |
| proved-historical-blob-byte-equality-declared-binding-needs-review | 2 |
| proved-synthetic-negative-auth-fixture | 1 |
| public-canonical-producer-field-needs-recomputation | 10 |
| public-diagnostic-script-pin-needs-original-byte-proof | 3 |
| public-frozen-fixture-identity-declaration-original-artifact-unproved | 35 |
| public-historical-file-checksum-declaration-original-bytes-unproved | 269 |
| public-historical-identity-declaration-original-bytes-unproved | 12 |
| public-prior-producer-checksum-needs-git-path-byte-proof | 1 |
| public-runtime-compatibility-fingerprint-needs-producer-or-archive-proof | 12 |
| publication-source-or-semantic-field-needs-producer-proof | 2 |

| Residual refinement | Records |
| --- | ---: |
| proved-historical-blob-byte-equality-declared-binding-needs-review | 2 |
| public-canonical-producer-field-needs-recomputation | 10 |
| public-diagnostic-script-pin-needs-original-byte-proof | 3 |
| public-frozen-fixture-identity-declaration-original-artifact-unproved | 35 |
| public-historical-file-checksum-declaration-original-bytes-unproved | 269 |
| public-historical-identity-declaration-original-bytes-unproved | 12 |
| public-prior-producer-checksum-needs-git-path-byte-proof | 1 |
| public-runtime-compatibility-fingerprint-needs-producer-or-archive-proof | 12 |
| publication-source-or-semantic-field-needs-producer-proof | 2 |

Public historical declarations are distinguished from unknown unbound literals by actual typed fields, explicit referents and retained source identity. This proves a declaration, not original missing bytes or an event. Dirty/private/incomplete/not-executed states survive. Equality with an unrelated file does not establish the declared referent. Qualified archival review must never claim independent original-byte recomputation. Missing producer/byte proof remains open where recorded.

Unknown unbound tuples: 0. No scanner replay, original dirty-build reconstruction or release pass is claimed. Prospective policy proof covers only the one source-hash tuple; substantive48-finding Bandit judgments belong to the separate review.

Further independent inspection replayed the supplied native producer script after removing its final file-write statement. All9 exact source-bound producer matches succeeded: rights/material attributes across the two current HTML copies, material semantic/review binding, the two uniquely title-adjacent AST blocks, and exact predecessor Git-show HTML producer bytes. The original native-producers.json was not modified. These9 records now have their own replay binding in the inventory.

All34 initially indirect byte matches now include explicit sibling/prefix/retained-file or same-role binding evidence, with inferred and historical projection limits kept distinct. Referent binding does not transform a frozen dirty manifest into a recomputed original artifact. Remaining unrefined byte-binding records: 0.

Final proof archive SHA256 a586d615a2e61202c50761b85ce5ba4fa5c86b4d5528e18b72006f5f93a9fbcb; decoded JSON SHA256 72f5e9d4b8352d51909ed8b80692dda2de07f7c3ee5f00e3512e4e29b53ee838. The earlier archive digest identifies the superseded initial inventory bytes; first preflight report remains unchanged.

Compact final per-ID proof: secrets-final-per-id-proof.json.gz; archive SHA256 4535f2822cdbe037dfb4d9af369e2cf9188d3f82c6ba534aa62f7fb416142b95; decoded JSON SHA256 c0188b391b820959c50b565041670a446a86b5d7fb0f9f680c055ecae76ba5ca; compressed bytes 110031. It retains every original comparison category and separately refines source-bound purpose/referents/consumers/archival limits. Counts: {"original_records": 1024, "original_remaining": 1016, "excluded": 8, "prospective": 1, "all_records": 1025, "current_plus_prospective": 1017, "blocked": 0}. All62 original candidate source-file bytes independently match95Git; only the separately prospective policy record uses prepared security data. Actual unknown/nonpublic bindings remaining blocked: 0. Qualified archival recommendations establish public metadata purpose while preserving missing original-byte/event limits. Every recommendation remains subject to separately authored exact ledger rows and fresh candidate review.
