# Requirements & Acceptance — seven-entry catalogue correction

Verdict: **PASS for the bounded taxonomy/owner correction against unchanged requirements.** The prepared fix restores classification to the existing oracles without changing their meaning. Current CI, corrected test success and full stable staging remain unobserved; this is not Ready/staging acceptance.

Same-role continuation `/root/r12_requirements_clean`. Packet SHA256 `871a09b247eb7a7a66f6a6597dc06d4474254075a90f091000990747ac9825ea` and all its referenced file hashes verified. Actual HEAD/base `0d64a5c2f4fa91c96381758397eb0c0c1093b69b`; this is a **prepared dirty subset**, not a clean checkout. Inspected catalogue SHA256 `b544e41499d44bcb153f171b73ee004524d24a0f9bb0cf0ce993f67810725046`; exact delta SHA256 `a31e68926b97440903237d760642cf36ffa7bf7bb5565ee7a9240ba00731300f`. Worktree also contains a changed mixed parent review report, which I did not inspect; it is outside this correction verdict.

No peers, MEMORY, excluded mixed rationale, implementation/test edits, external writes or delegation. Provider/context limitations remain as previously qualified. Only this assigned artifact written; no tests were executed by this role.

## Actual source assessment

Independent semantic JSON comparison finds exactly seven changed catalogue entries. Three current publication-owned files—the R12 PDF asset, edition record and material review record—retain `role: source` and change owner from site/README.md to guides/ARTICLE-WORKFLOW.md. That is the actual publication inventory contract's required owner for admissible publication bookkeeping. It does not claim runtime ownership or create a cheaper delivery route for unrelated controls.

Four entries—the retained pre-approval article/Writing snapshots and their directories—change `role: source` to `history`, keeping site/README.md ownership. These are byte-frozen historical outputs, as already established by own source-bound preservation review, not active authored HTML. The formatter's existing classifySource rejects active source roles inside its declared retained-directory exclusion. Correcting the false source classification therefore respects historical byte preservation; it does not newly exclude genuine active source or weaken formatter scope.

I independently byte-compared current manuscript, PDF and native article HTML with base: unchanged. Actual formatter producer, source-test selector and both supplied failing-test owners also compare byte-identical to base. No guard/oracle/test rewrite occurs. Original full-main→candidate allocation remains applicable because inherited archive/RI/protocol/rights/site changes still exist; metadata compatibility cannot erase those complete-diff obligations. No publication/stable/merge authority is added.

## Retained failure and next checks

Raw `/tmp/issue169-r12/stable/nav-failure.log`, SHA256 `80667043013f59d2d536622077a4cf38dea92b4937a401aafcdb7adb2111c4a4`, actually reports121tests,118pass,3fail,0skipped. Two failures originate from retained article HTML being declared active source inside formatter exclusions; the third is current publication inventory compatibility returning false. Actual source mechanisms and the seven-entry changes align with these failures. This is an evidenced correction hypothesis, not a rerun result.

| AC / invariant | Observation / disposition |
| --- | --- |
|AC05/11 owner/classification integrity|Seven metadata changes align with existing actual contracts; guard/test bytes unchanged|
|AC07/08/09 accepted paper and frozen history|Current manuscript/PDF/HTML unchanged; historical snapshots correctly identified as history|
|AC05 full route and current evidence|Retain failed native run; affected tests and regenerated RI/maps/current checks remain required|
|AC04/06 phase|Ready/current checks/full stable then STOP unchanged; no merge/production/platform permission|

After regeneration, obtain the bounded affected-test/current-source result and applicable four-role correction outcomes, then follow the existing full route. Do not claim corrected CI/full stable success from this review or from the prior118passing tests alone.
