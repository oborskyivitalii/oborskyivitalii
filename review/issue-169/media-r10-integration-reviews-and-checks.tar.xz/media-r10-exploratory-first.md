# Exploratory / Interaction QA — first independent result

Verdict: no blocking findings in the bounded changed operator/CLI journeys. Four designed cases executed and passed after two explicitly diagnosed reviewer-harness errors in case 4. This result supports the local integration preparation only; it does not accept native hosted R10 diagnostics, stable staging, controller trust, public release, or whole issue acceptance.

## Identity and boundary

- Role/task: nonauthor Exploratory / Interaction QA, `/root/media_r10_exploratory`, first result. No source/test implementation, external writes or delegation.
- Candidate `9588ba60b6ad43e127d61bd5d6e94f5c0d858dea`, tree `bd2942de1b767ff71673d6430c7e0d9f9fffad3c`; publication base `ec35807bec4a233cf7e80eb39f455c1f6b19434a`, proposed controller `550c7f242b88870796f3920332e620ff4e4ca795` (PR174). Actual candidate first parent is `440634c8ad617a4ac6c16cf1a294131d6ee4172c`; base/controller comparisons here are integration deltas, not a claim that candidate itself is a two-parent merge.
- Accepted neutral source packet SHA256 `a96add99dcd339a02b57a554a4f1d799b3dfab76b6bd745c98406174cc8547df`. Initially read the earlier packet (SHA256 `9afb7ec5555613c6ea5475fd1d6dc3a902819422a86edf92a8a65798fcfd87ef`) including excluded preflight filename/hash only. Never opened that preflight or any peer output. Broad repository-map/file inventory exposed artifact paths only, not peer verdict bodies. Provider context internals remain unknown; none-fork launch evidence belongs to orchestrator receipt; shared filesystem/instructions are not OS isolation.
- Common contract SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`. Read both before judgment.
- Read root AGENTS/README and relevant map routes, original issue169 intent/scope and owning acceptance, actual action/workflow, fixture copier, rendition adapter/Python owner/pin, functional validator, scoped tests and guide/registry changes. No nested AGENTS found in affected .github/tools/tests/guides/agents trees. No unrelated memory/history or peer reports read.
- Source hashes of every file listed in the neutral packet revalidated at completion: all matched. HEAD unchanged; `git status --short` empty. `git diff --exit-code ec35807 9588ba60 -- site docs` returned 0. These preserve all accepted article, diagram, PDF, generated download and runtime bytes against publication base.

## Charter, actual surface and observations

Four-case/eight-minute bound; local interaction probe sequence completed within the bound. Main observed surface is CLI fixture preparation/fresh child process plus operator locator restoration and validator diagnostics. Python 3.12.14 at `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3`, Pillow13.0.0, WebP1.6.0, Node24.22.1 on Linux. Used genuine integrated current repository fixtures, explicitly selected canonical interpreter through SITE_MEDIA_PYTHON; copied fixture had canonical requirements but no copied quality venv. Did not rerun the full source campaign.

| Case | Expected journey | Actual observation | Disposition |
| --- | --- | --- | --- |
| 1 | Build actual R10 analytics fixture and invoke copied media producer in fresh Node/Python children | buildFixture compiled current R10 article in 3600ms. Actual2160×630 asymmetry source produced65044-byte WebP; source digest/pixel digest matched, Pillow/WebP canonical. Encoded bytes equal accepted docs asymmetry-r9.webp. | Executed/pass |
| 2 | Missing dependency/pin must fail, restoration recovers | Empty venv refused with No module named PIL. Deleting copied requirements refused with exact missing-file path. Restoring canonical pin and interpreter produced identical output. | Executed/pass |
| 3 | Follow both historical HTML locators to recover exact original HTML | Parsed actual href, read gzip, decompressed to temporary local HTML, compared byte-for-byte to git-show base original. v5:1360413bytes; v7:1304407bytes. Both exact. Locator explicitly instructs decompression and disclaims new acceptance. | Executed/pass, two partitions |
| 4 | Startup/collection error remains primary with absent article evidence; valid report recovers | Validator reports browser startup or collection failed and includes actual PIL message. After complete controlled journey attached, valid controlled report accepted. Missing mandatory journey remains rejected. | Executed/pass; controlled report, not browser evidence |

Reviewer-harness failures retained in literal raw result below: first used nonexistent sf.reports(); corrected to exported functional(). First recovery fixture omitted mandatory article journey and correctly failed the validator; added existing controlled journey for recovery only. No candidate/test edit and no unchanged full campaign rerun.

## Findings, risks and limits

No findings requiring changes. Examined canonical dependency ownership across actual fixture/fresh processes, fatal missing dependencies and pin restoration, accepted-media byte preservation, historical gzip recoverability and primary error precedence. Action, fixture copier, functional validator and workflow bytes are identical to proposed controller across controller-to-candidate diff; publication-base delta adds setup to three browser consumers. Registry adds existing-suite selection inputs, retains publication-specific inputs; no case/budget gate removal observed in inspected deltas.

AC05/09/10/11: this bounded evidence supports source-bound hygiene, preserved reader/media/material bytes and local collection recovery. Whole ACs remain open: native current integrated browser diagnostics, exact served article/PDF, stable staging and external delivery were not observed. PR174 exact-head maintainer review/trust remains separate. No network install/action execution, Windows/macOS execution, browser UI interaction, physical device, visual/editorial/PDF review or independent provider isolation attestation is claimed. Source preservation plus CLI observations cannot establish actual hosted reader usability.

Existing regression mapping: cases1–2 → tests/analytics.test.cjs (existing copied-producer/cold-fixture cases), cases4 → tests/staging-regression.test.cjs and tests/article-browser-evidence.test.cjs, all existing pr-targeted/staging/production source profiles through tools/quality/test-profiles.json. Native consumer route remains site-release-checks staging-browser and production functional jobs under SITE-CHECK-PROFILES; this review does not replace them. Case3 is bounded manual/operator history recovery owned by review/issue-169 and source-history gate. No new suite, mandatory browser matrix or duplicate full campaign proposed.

## Literal bounded interaction result

```json
{
  "charter": "Four cases within eight minutes: integrated genuine fixture and fresh copied producer; missing Pillow/pin recovery; gzip locator restoration; primary diagnostic and bounded recovery.",
  "candidate": "9588ba60b6ad43e127d61bd5d6e94f5c0d858dea",
  "tmp": "/tmp/r10-explore-KTuyrp",
  "python": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3",
  "cases": [
    {
      "case": 1,
      "expected": "Actual integrated R10 fixture compiles; fresh copied producer emits canonical media without copied venv.",
      "observed": {
        "status": 0,
        "media": {
          "sourceDigest": "65741f7bf96495d834a4163e4122b2c03d0b5e0e966048679bf144d4925a7249",
          "mime": "image/webp",
          "width": 2160,
          "height": 630,
          "rendition": {
            "schema": 1,
            "kind": "webp-lossless",
            "sourceSha256": "65741f7bf96495d834a4163e4122b2c03d0b5e0e966048679bf144d4925a7249",
            "pixelSha256": "96d374cdc6629f8571e5f42a4937b8ed81bc35d5550aec68d15e2fdce08757f3",
            "iccSha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            "pillow": "13.0.0",
            "webp": "1.6.0"
          },
          "bytes": 65044
        },
        "elapsedMs": 3600,
        "fixtureArticle": true,
        "pinSHA256": "aca230d90b81c5e62440dba6d25348ac5954f324446bab54fd2a30b7cf0daa46"
      },
      "pass": true
    },
    {
      "case": 2,
      "expected": "Missing PIL and missing source pin remain fatal, then exact pin/interpreter restoration recovers.",
      "observed": {
        "absentStatus": 1,
        "absentPrimary": "Error: Lossless article media preparation failed: No module named 'PIL'",
        "missingStatus": 1,
        "missingPrimary": "Error: Lossless article media preparation failed: [Errno 2] No such file or directory: '/tmp/r10-explore-KTuyrp/fixture/tools/quality/toolchain/requirements.txt'",
        "recoveredStatus": 0,
        "identicalOutput": true
      },
      "pass": true
    },
    {
      "case": 3,
      "partition": "v5",
      "expected": "Locator directs to exact recoverable original HTML.",
      "observed": {
        "href": "site-v1-20261002-v5-index.html.gz",
        "bytes": 1360413,
        "sha256": "f090b1dd11fc6bcb01c8bc95e9c4f0a04ddbfaaaf3d5c661e01b33522524f62e",
        "matchesOriginal": true
      },
      "pass": true
    },
    {
      "case": 3,
      "partition": "v7",
      "expected": "Locator directs to exact recoverable original HTML.",
      "observed": {
        "href": "site-v1-20261002-v7-index.html.gz",
        "bytes": 1304407,
        "sha256": "b275a449e2cc45d72481bea09e0a4a47be96d1beff506ccdc2008d99eaceff2e",
        "matchesOriginal": true
      },
      "pass": true
    },
    {
      "case": 4,
      "expected": "When collection fails and article evidence is absent, primary startup failure is reported; complete controlled report recovers.",
      "observed": {
        "primary": "browser startup or collection failed\n+ actual - expected\n\n+ [\n+   {\n+     engine: 'chromium',\n+     error: \"Lossless article media preparation failed: No module named 'PIL'\"\n+   }\n+ ]\n- []\n",
        "recovered": "validateFunctional returned successfully after valid controlled article journey attached",
        "evidenceKind": "Controlled report interaction, not browser evidence"
      },
      "pass": true
    }
  ],
  "harnessFailures": [
    "TypeError: sf.reports is not a function\n    at [stdin]:23:16\n    at runScriptInThisContext (node:internal/vm:219:10)\n    at node:internal/process/execution:451:12\n    at [stdin]-wrapper:6:24\n    at runScriptInContext (node:internal/process/execution:449:60)\n    at evalFunction (node:internal/process/execution:283:30)\n    at evalTypeScript (node:internal/process/execution:295:3)\n    at node:internal/main/eval_stdin:51:5\n    at Socket.<anonymous> (node:internal/process/execution:205:5)\n    at Socket.emit (node:events:526:24)",
    "Correction1 recovery fixture omitted mandatory articles; validator refused: selected articles require actual browser evidence. Added existing controlled journey for recovery only."
  ],
  "acceptedRenditionComparison": [
    {
      "file": "docs/article-media/8082d70ee11d652202f57db57cb427c704de971ba734b26905febc1ee000526f/asymmetry-r9.webp",
      "equal": true
    }
  ],
  "nodeVersion": "v24.22.1",
  "finalCandidate": "9588ba60b6ad43e127d61bd5d6e94f5c0d858dea"
}
```
