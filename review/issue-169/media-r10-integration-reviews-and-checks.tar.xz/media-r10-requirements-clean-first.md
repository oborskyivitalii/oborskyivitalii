# Requirements & Acceptance — first independent integration review

Completed 2026-11-07. Role: nonauthor Requirements & Acceptance reviewer. This is my literal first result, before peer reconciliation.

## Verdict

No blocking requirements or acceptance-linkage defect found in the bounded integration delta. The candidate is consistent with preparation of owner-triggered **staging-regression diagnostic evidence**. This does not accept integrated native execution, stable staging, controller trust, PR170 merge, production or whole issue169 completion. Those observations/decisions remain pending.

The current user scope is stable R10 staging followed by STOP/show, with no PR170 merge or production. Integrating proposed controller174 on the Draft publication branch for isolated diagnostic evidence does not supply the separate maintainer exact-head reviewed_sha decision needed for174 or trusted-main admission. Prior173 acceptance cannot transfer to174.

## Identities, authority and bounds

- Repository inspected: `/workspace/scratch/b15f3a872203/repo`; working tree was clean at inspection.
- Candidate HEAD `9588ba60b6ad43e127d61bd5d6e94f5c0d858dea`, tree `bd2942de1b767ff71673d6430c7e0d9f9fffad3c` verified locally. Its direct parent is `440634c8ad617a4ac6c16cf1a294131d6ee4172c`; the comparisons below use the supplied publication and controller source tips, rather than claiming those are both direct parents of this receipt commit.
- Publication source `ec35807bec4a233cf7e80eb39f455c1f6b19434a`; proposed controller174 source `550c7f242b88870796f3920332e620ff4e4ca795`; protected main recorded by supplied packet `312fbe4347eda332aa8ade885b07c98beadd6da5`.
- Neutral source packet `/workspace/scratch/b15f3a872203/reconcile-review/media-r10-integration-neutral-packet.json`, SHA256 `a96add99dcd339a02b57a554a4f1d799b3dfab76b6bd745c98406174cc8547df` verified. All38 repository file hashes and5 raw input hashes matched the packet at inspection.
- Common prompt `agents/reviewers/README.md`: SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/requirements-acceptance.md`: `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. Read both, root AGENTS, README, CONTRIBUTING independent-quality/iteration policy, repository map, acceptance owner and applicable check/staging/release owners. The repository inventory showed no nested AGENTS.
- Original issue text and current scope were read from the packet-bound `/workspace/scratch/b15f3a872203/issue169-current.md` and `issue169-scope.txt`. The dated amendments explicitly supersede historical planning-only wording; current whole ACs remain open except historicalAC06.
- Four bounded read/check cases below, within the assigned8minute budget. No source/test edit, full campaign, external write or delegation. Only this assigned review artifact was written.

I received the neutral role task and user/project instructions, not an author diagnosis or peer verdict. I did not inspect earlier integration preflight, other packets, interrupted/current peer outputs, parent scratch notes/history, unrelated memory or archived reviewer results. Candidate integration report claims were treated as subjects to verify, not verdicts. Shared filesystem and project instructions are not isolation. I cannot attest provider model/context internals or independently observe the orchestrator's actual launch request/accepted fork parameters; that execution receipt remains the orchestrator's obligation. No live GitHub refresh was performed in this local bounded review; remote state beyond the supplied dated sources is unobserved.

## Actual cases and observations

### 1. Authority, packet and acceptance preservation

Verified the supplied packet/file/raw digests and inspected the actual `.github/acceptance/issue-169.json` and original issue amendments. The candidate acceptance owner is byte-identical to publication EC35807. AC01–AC11 and their external gates are not renumbered or reduced. The machine checks explicitly establish RI/style/routing only; editorial, evidence, visual, copy, delivery and actual independent-review gates retain their separate meaning. The current R10 editorial gate preserves the five-page PDF and hero plus four figures. No new author acceptance was inferred.

### 2. Both-source integration and unchanged obligations

Inspected publication→candidate and controller→candidate deltas and relevant sources/tests. `site/` and `docs/` have **no delta at all** from EC35807, preserving manuscript, PDF, media, source provenance, output and related reading as exact bytes. `tools/quality/format-parity.cjs` and `source-test-worker.cjs` are also unchanged, preserving publication's parser and timing/order corrections. Budget file, acceptance owner, staging trust/review-flow owners, release owners and scanner policy/input files inspected through the bounded diff are unchanged.

The workflow, canonical media action, analytics fixture producer and functional validator are exact174 bytes. Existing publication test deltas are retained: quality artifact-shard assertions and current issue169 reviewed-runtime fixture. All127 publication registry test rows preserve every prior field and input; controller inputs are also retained. The few controller metadata differences are publication's existing purpose/disposition wording, rather than a dropped test/route. Hosted profiles and other non-source-profile registry fields are exactly EC. Shared PR input union has no dropped parent entries or unexplained new entries. The publication guide is an exact prefix of the candidate guide, and controller's final media section is retained exactly.

Inspected `.github/actions/publication-media/action.yml`, all three workflow consumer placements, `tools/publishing/web-media.py`, fixture pin-copy change and associated test oracles. The action obtains the Pillow pin from the canonical producer, uses the selected Python for installation and verification, checks Pillow and WebP before exporting `SITE_MEDIA_PYTHON`, and is placed before collection in staging/Linux/native jobs. This is a feasible, observable dependency contract; the source-test installation in another job is not substituted for browser-job preparation. Positive/negative source tests cover missing Pillow, missing copied declaration, restoration, explicit interpreter and failure-before-export. I inspected these tests; I did not execute their installed-Python/browser scenarios.

### 3. Historical byte recovery

Actually decompressed each new gzip in memory and compared it byte-for-byte with `git show EC35807:<original path>`:

| Original | Decoded bytes | Decoded SHA256 | Result |
| --- | ---: | --- | --- |
| `review/site-v1-20261002-v5-index.html` |1360413|`f090b1dd11fc6bcb01c8bc95e9c4f0a04ddbfaaaf3d5c661e01b33522524f62e`|Exact original recovered|
| `review/site-v1-20261002-v7-index.html` |1304407|`b275a449e2cc45d72481bea09e0a4a47be96d1beff506ccdc2008d99eaceff2e`|Exact original recovered|

The original-path locators link their gzip siblings and explicitly require decompression; they do not claim a new active rendition or visual acceptance. Recoverability is demonstrated. Original-path direct preview behavior intentionally changes to a locator; no current site/docs or active runtime change was found. Historical evidence is retained rather than silently deleted. This check establishes decoded-byte recovery, not a browser visual re-review of historical previews.

### 4. Evidence meaning and diagnostic boundary

Read the raw EC native reports, current staging validator/registry and authoritative staging route contract. Prior prepublication report is bound to EC35807/treee2c1ae7b, has26passing checks and explicitly `fullGate:false`, `productionEligible:false`, `deploymentAuthorized:false`. It cannot pass the changed integrated source. Raw `stage-functional.json` is failed, has no analytics observations, retains startup failure `Lossless article media preparation failed: No module named 'PIL'`, and shows the secondary missing-article summary. That supports the dependency/diagnostic requirement, not a successful staging claim.

Executed one direct read-only current-candidate Node probe: functional validation with selected articles and a PIL startup failure rejects with that primary error; after clearing startup failures it still rejects missing article evidence; `registryCheck()` succeeds. Output: `PASS: primary collection failure retained; missing article evidence still rejected; unchanged staging registry accepted.` This proves the bounded validator behavior only, not browser installation or actual collection.

`guides/SITE-STAGING.md` owner table and explicit label route preserve immutable-preview-only staging-regression evidence, separate queue and no stable alias update; ordinary `/stage` remains protected-main controlled. The trust/review-flow implementation has no EC delta. Existing staging case selection,15minute budget and false full/production eligibility assertions remain intact in `staging-regression.cjs`; moving startup-error validation does not waive article validation. The integration report explicitly retains pending exact174 trust and normal full owner staging, then STOP/show.

## Intent / AC / evidence mapping

| Requirement / AC | Check or owner gate | Observed result and impact |
| --- | --- | --- |
| R10 article meaning, evidence, figure/author apparatus; AC01/02/03/07/08 | Exact source preservation; EDITORIAL/EVIDENCE/VISUAL | `site/` and `docs/` unchanged from EC. No new semantic/visual acceptance claimed or performed. Existing source-bound decisions can be reused only for demonstrably unchanged scope. |
| Distribution and retained history; AC04/06 | COPY/HISTORY; original amendments; gzip comparisons | Planned site-first flow unchanged; AC06 historical only. Both historical originals recovered exactly. No external posting, publication or PR170 merge observed. |
| Source-bound review/hygiene; AC05/11 | CURRENT-RI/RI-CI/STYLE and four completed independent roles | Packet identities/current local source inspected; this role completed only. Integrated native/RI/check campaign and other roles are not accepted by this report. Prior-source green reports are not current-source proof. |
| Matching PDF and live delivery; AC09 | VISUAL/COPY/DELIVERY; native current-source publisher/Basic/hosted gate | PDF/output bytes unchanged, but actual served integrated R10/PDF and stable alias remain unobserved. Gates stay open. |
| Related reading; AC10 | Existing source/profile cases plus desktop/mobile/no-JS visual and hosted checks | Site/output, case/profile/budget owners preserved. No new native interaction observation; old controller/EC results do not pass integration. |
| Primary collection failure and canonical dependency closure; AC05/09/10/11 | Action/fixture sources, negative test oracles, direct validator probe | Source obligation complete; bounded local validator behavior passes. Actual native action/toolchain/OS/browser execution still required. |
| Diagnostic versus trusted-main/stable; AC05/11 and current scope | Owner-only label route; exact174 reviewed_sha; protected main; full owner stage | Existing route unchanged, report keeps trust pending. Diagnostic pass cannot authorize trust, stable promotion, merge or production. |

## Findings, risks and next gate

No new requirements defect or weakened acceptance gate found within the inspected delta. Risks examined: inherited stale green evidence, loss of publication selection during conflict resolution, changed R10/PDF bytes, hidden case/budget/scanner relaxation, historical evidence deletion, collection failure masked by secondary article errors, and diagnostic promotion confused with maintainer trust. The checks above found preservation or explicit pending disposition for each.

Outstanding gates are material limits, not new defects to waive: completed source-bound four-role integration review with auditable launch/isolation receipts; current integrated source/Basic/RI/applicable checks; native owner-triggered diagnostic exercising actual R10 and canonical media preparation; maintainer exact174 reviewed_sha and protected-main integration; refreshed PR170 normal full owner stable staging and actual stable reader/PDF inspection. Follow the current user boundary: then STOP/show, without PR170 merge or production. Revalidate hashes/refs if any relevant source moves. This report does not certify browser/OS compatibility, broad security, coverage, deployment or formal requirements compliance.
