# Requirements continuation — R10 candidate integration route

2026-11-07. Independent Requirements & Acceptance continuation by `/root/media_requirements_preflight`. This is a targeted continuation of my preserved first preflight, not a newly fresh first judgment. Three bounded read/check cases; under five minutes. No peer reports, implementation edits, external writes or delegation.

**Verdict: the proposed route is allowed for diagnostic evidence within current scope.** Integrate proposed PR174 into Draft PR170, preserve accepted R10 sources, then use the existing owner-triggered `staging-regression` label route to test actual publication bytes with the candidate workflow. This does not install the controller on protected main, authorize stable staging promotion, satisfy maintainer attestation, merge PR170 into main, or authorize production. The user endpoint remains verified stable R10 staging then STOP/show.

Observed local identities: controller PR174 `550c7f242b88870796f3920332e620ff4e4ca795`, tree `6ec624231c54b5690cdac1d18a8102cd8b6700b3`; publication checkout `ec35807bec4a233cf7e80eb39f455c1f6b19434a`, tree `e2c1ae7b8ed6dd41f3580d292d6e0c8ad89cbcf6`. Both clean when checked. Controller comparison base312fbe4 is the previously supplied protected-main identity. Remote PR/head/status, resulting integrated commit/tree, run, owner event and served bytes were not observed in this continuation.

## Case1 — Scope and existing owner evidence route

`guides/SITE-STAGING.md:345,362–366` explicitly permits an owner `staging-regression` label on an open same-repository PR, uses separate concurrency, does not update stable staging, and permits review of changed staging implementation before protected main integration. `review-flow.cjs:50–63,87–110` validates the literal label, owner sender/actor, same repository/open current-head lease and selects `mode:preview`; Draft status does not block evidence (`prototype` excludes evidence events). Workflow `site-color-review.yml:506–527` invokes the reusable candidate workflow with `validation_level:staging`, `full:true`, staging profile, automated-only and exact source/public/prepublication artifact bindings. Therefore keeping PR170 Draft is compatible with this diagnostic route.

Qualification to the proposed description: browser candidate jobs have no provider deployment secret, but **the entire workflow is not literally unprivileged**. Its existing preview `publish` job uses the preview environment and Wrangler deployment secret (`:343–397`), and comment jobs have PR write permission. Those are existing authorized preview-route effects. Do not change their permissions, credential boundaries or source selection, and do not characterize the entire pipeline as having no external effects.

`promote` requires a main-ref dispatch/comment and full staging mode (`:550–556`), so label evidence cannot satisfy it. The trusted `change-admission-receipt` additionally requires staging mode, full, promotion and merge-admission success (`:793–809`); no candidate label run can substitute for that receipt. I verified the controller diff does not change `site-color-review.yml` or `review-flow.cjs`.

## Case2 — Exact integration evidence and pending gates

Before treating an execution as candidate evidence, retain:

- Integrated PR170 full head and tree, both merge parents, base/controller identities, complete merge diff and conflict resolutions. Show that the controller action is actually present at the source checked out by the reusable browser jobs. Local actions resolve from that checkout; a550 controller-only pass is not evidence about R10 EC or its future merge.
- Accepted R10 manuscript/PDF/diagrams and authored site/generated output identity across integration. Regenerate/check any legitimately coupled metadata from its owner; do not weaken source or public identity checks to keep an old hash.
- Actual label event, owner sender/actor, open same-repository PR, workflow/ref/SHA, run ID and attempt, current head/base leases, target source, immutable preview URL and all exact public/package/prepublication artifact IDs, upload digests and report bytes. Record the PR merge ref/workflow execution identity separately from the raw PR source head.
- Canonical media installation/interpreter/version output and complete selected reports on the integrated R10 source: source guards, static/host/staging, analytics and article evidence, all original route/failure/navigation/performance cases and budgets. Preserve failed/incomplete attempts and full job accounting. A convenient local pass or performance-only pass cannot fill missing browser observations.

Fresh affected review of the integration/resolutions and current-source Basic/navigation/owning/style/RI/CI evidence remain required before readiness. Reuse evidence only for demonstrably unchanged relevant bytes; peer summaries do not replace actual four-role results. This continuation does not accept the final code or native execution.

The maintainer control decision remains pending for the exact complete head being admitted to protected main (`SITE-STAGING.md:175–197`). PR174550c7f2 needs its own exact-head `reviewed_sha`; prior PR173d066 acceptance cannot transfer. If PR170 contains control changes at its later admission, its actual selected delta/head also requires the applicable control attestation. Candidate diagnostic success cannot supply either decision.

After protected controller admission/integration, refresh PR170 against current main; obtain the existing required raw-head checks and permitted ready state, then run the actual owner/main full staging route. Only its successful promotion, HTTP/alias/article/PDF verification and authenticated receipt can establish verified stable staging. Stop/show then; PR170 main merge, production, issue closure and unfulfilled whole ACs remain pending.

## Case3 — Historical frozen rollback compatibility

**No demonstrated rollback-path regression from this local action.** The action is added only to Linux/native/staging jobs in `site-release-checks.yml`; production rollback does not invoke that reusable workflow or the action. `site-production.yml` checks out current controller `github.sha`, authenticates/restores the frozen archive, composes frozen bytes and deploys Pages. `tools/release/actions.cjs:273–289` handles rollback by restoring an accepted archive, unpacking the recorded package digest, verifying the archive and edition, then returns before publish-only staging admission. Automatic failed-transition rollback restores the separately retained previous Pages artifact (`site-production.yml:315–335`). The entire production workflow and `tools/release/` owners are unchanged between312fbe4 and550c7f2. Staging recovery owners are likewise unchanged.

This is a bounded source-path compatibility conclusion, not an executed live rollback. Historical archive fixtures/native recovery evidence are reused only if their actual owners/inputs remain unchanged. No rollback dispatch is authorized or necessary for this question.

Separate limitation: invoking the *new optional full diagnostic workflow* with a historical candidate SHA that lacks `.github/actions/publication-media` may fail local-action resolution after checkout. That would concern old-source diagnostic compatibility, not actual frozen production rollback. Do not claim arbitrary old-source diagnostics are proved compatible; any such requirement needs its own exact invocation and expected contract. Current proposed R10 integration must include the action and is the authorized test target.

## Inspected source identities

| Source at controller550c7f2 | SHA-256 |
| --- | --- |
| `guides/SITE-STAGING.md` | `44c37986027125585e54787337da6debdd014b0b5b70c87518f92ed74d62f63a` |
| `.github/workflows/site-color-review.yml` | `d184fb3e54d5c3a42901f10597313e4cd4da0f5d3d51cb0f7ba3ab30a9f4dbe2` |
| `tools/staging/review-flow.cjs` | `bbd2d4888721b5364e2b26719c3ee91a3eea7a520e4e8f0350dfa2c634a04acc` |
| `.github/workflows/site-release-checks.yml` | `0f35df2fde69e851e05518db0dc46d70fb91216a7ba9cdddcabe35b1e9675d4d` |
| `.github/actions/publication-media/action.yml` | `cc2477b02dd5f684e398f87cfb51fd11f3ffcc4be223a31bcc11a70b86208873` |
| `.github/workflows/site-production.yml` | `6428be26a7400e14bb11c74afa8911ecff883d8f35ce0ef29721aaba2b787955` |
| `tools/release/actions.cjs` | `3f6b1b82ed1ca25b7ec26e3b8f5d00403db057ef5e54c1eeaf02ba4a552b500d` |

No live run/admission/publication acceptance is inferred from these hashes. Provider internals remain unknown; parent preserves launch metadata. First preflight remains intact and this continuation is separately recorded.
