# White-box QA — first independent result

Verdict: PASS for the bounded media-controller integration examined; no blocking implementation finding. This does not accept current integrated native/hosted staging, stable promotion, trusted-main controller admission, PR170 merge or production. Those observations/decisions remain pending.

## Identity and boundaries

- Role: distinct nonauthor White-box QA; task `/root/media_r10_whitebox`; first judgment, 7 November 2026. No source/test edits, external writes or delegation. Four bounded scenario groups; no full source campaign.
- Repository `/workspace/scratch/b15f3a872203/repo`; owner issue169, publication PR170, proposed controller PR174.
- Candidate `9588ba60b6ad43e127d61bd5d6e94f5c0d858dea`, tree `bd2942de1b767ff71673d6430c7e0d9f9fffad3c`; base `ec35807bec4a233cf7e80eb39f455c1f6b19434a`; controller `550c7f242b88870796f3920332e620ff4e4ca795`. Candidate has direct parent `440634c8ad617a4ac6c16cf1a294131d6ee4172c`; comparisons below use the supplied publication-base and controller sides, not an invented two-parent commit.
- Accepted packet: `media-r10-integration-neutral-packet.json`, SHA256 `a96add99dcd339a02b57a554a4f1d799b3dfab76b6bd745c98406174cc8547df`. Recomputed packet digest and all 38 referenced repository file digests matched.
- Read both reviewer contracts before judgment: common README SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; white-box prompt SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Original packet `9afb7ec5555613c6ea5475fd1d6dc3a902819422a86edf92a8a65798fcfd87ef` listed an earlier preflight filename/hash. I read that listing only, never the preflight file or its conclusions. Parent supplied the neutral replacement before this judgment. Explicitly excluded earlier/current peer outputs, parent scratch notes and private history. Candidate claims and packet observations were review subjects, not oracles. Supplied original issue text contains historical execution summaries; these were not used as current acceptance.
- Actual launch parameters and provider-observed model/context internals belong in the orchestrator receipt; I cannot attest to them from inside this role. Shared instructions/filesystem are not OS isolation. No claim about unknown provider history injection.

## Primary sources and expected invariants

Read root AGENTS, README, map navigation, applicable CONTRIBUTING review/failure rules, original `issue169-current.md` intent/AC01–11, scope text, `.github/acceptance/issue-169.json`, profile inventory/route, actual changed workflow/action/collector/test sources and relevant unchanged media producer. No nested AGENTS was found. Did not use MEMORY as acceptance evidence or inspect unrelated memory. Relevant AC05/11 require actual source-bound review; AC09/10 retain native PDF/reader/related-reading and actual delivery gates. The accepted integration must preserve R10 site/docs, original case/budget/scanner obligations and the timing/parser corrections; missing interpreter/package/pin remains an error. Each browser job must prepare its own interpreter; export only after verification. Primary collection failure must remain visible without allowing missing article evidence or bypassing cleanup.

Inspected both-side diffs for media sources/workflow/tests and the registry/guide union. Versus publication base, production workflow changes are exactly six added setup lines; collector source changes are copied pin plus assertion ordering. Actual action/workflow/analytics collector/staging collector/analytics test bytes match PR174. Compared unchanged site/docs, canonical media producer/pin, parser/timing owners, budgets/scanner rules and issue policy directly against base. These are byte/source checks, not runtime coverage measurements.

## Risk → scenario/oracle → maintained check mapping

| Case / AC risk | Structural fault and scenario | Independent oracle | Actual check and maintained route |
| --- | --- | --- | --- |
| 1 / AC05,09,10 | Copied producer loses its pin or uses an interpreter without PIL; restored source remains poisoned/cached | Fresh process must refuse absent PIL and absent copied requirements, then produce matching source identity/dimensions/MIME/canonical Pillow with restored pin | Existing `tests/analytics.test.cjs` copied-media test; permanent `pr-targeted`, `staging`, `production` source suite; source checks in site-checks `checks` and staging/production producer routes. Native consumers are release workflow `staging`, `linux`, `native`. |
| 2 / AC05,11 | One consumer lacks setup, installs through another executable, exports before failed install/verify | All three jobs prepare unconditionally before functional collection; canonical pin owner and explicit selected interpreter; zero export after installation or verification exception | Existing `tests/quality.test.cjs` canonical interpreter test, workflow/action source inspection; same permanent profiles, release jobs `staging`, `linux`, `native`. VM cases cover POSIX and Windows paths, successful setup and injected pip/verification failures. |
| 3 / AC05,09,10 | Primary collection error masked by downstream missing articles; ordering fix accidentally waives article/cleanup gates | Recorded PIL/controlled article error is primary; with primary cleared, missing required article evidence still fails; successful article-enabled collection gives five observations, disabled gives none; Chromium and Firefox both close | Existing startup diagnostic test in `tests/staging-regression.test.cjs` plus existing controlled collector test in `tests/article-browser-evidence.test.cjs`; permanent profiles above; native `staging-regression.cjs` and staging gate route. |
| 4 / AC05 and preserved AC09/10 | Conflict resolution drops input selection, changes accepted R10/parser/timing/budgets, or gzip changes history bytes | Current relevant registry inputs contain both-side unions; actual exact-base selector retains all four suites; decompression equals pre-change Git blob; accepted owners unchanged | Retained read-only Python/Node comparison below. Permanent registry source tests and RI/history inventory; existing Basic/source/repository/hosted B/R/O/H obligations remain. This direct preservation check supplements them and does not replace native gates. |

Profile mapping follows `guides/SITE-CHECK-PROFILES.md` (bounded staging, permanent test lifecycle, browser fixture media dependencies) and actual `tools/quality/test-profiles.json`. Selection is explicitly observed; no suite execution is inferred from selection.

## Executed results and literal accounting

Working directory for commands: `/workspace/scratch/b15f3a872203/repo`. Runtime Node `v24.22.1` (hosted workflow requests 24.19.0). `SITE_MEDIA_PYTHON` was unset; existing `tools/quality/toolchain/venv/bin/python` was present. Case1 selects that real interpreter, creates a clean no-PIL venv without pip, and exercises fresh Node/Python child processes; it does not stub encoding. All temporary fixtures are cleaned by the existing tests.

Case1 command:
```text
node --test --test-name-pattern='copied analytics media producer needs its declared pin and actual selected interpreter' tests/analytics.test.cjs
✔ copied analytics media producer needs its declared pin and actual selected interpreter (3584.450897ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 3750.258418
exit 0; no signal
```

Case2 command:
```text
node --test --test-name-pattern='every fixture-building browser job prepares the same canonical media interpreter' tests/quality.test.cjs
✔ every fixture-building browser job prepares the same canonical media interpreter (101.45662ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 223.480298
exit 0; no signal
```

Case3 command:
```text
node --test --test-name-pattern='functional collection failures remain visible|the staging collector exercises articles only' tests/staging-regression.test.cjs tests/article-browser-evidence.test.cjs
✔ the staging collector exercises articles only on its admitted Chromium and joins failures and cleanup (30.46407ms)
✔ functional collection failures remain visible before secondary missing article evidence (27.649257ms)
ℹ tests 2
ℹ suites 0
ℹ pass 2
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 141.404338
exit 0; no signal
```

Case4 preservation probe: Python read neutral packet and SHA256-verified each `files` entry; for each v5/v7 HTML, compared `gzip.decompress(current .gz)` to `git show ec35807:<original-path>` and checked locator target; asserted empty `git diff --name-only ec35807 9588ba60 -- <owner>` for site/docs, format-parity, source-test-worker, web-media, requirements, budgets, security-rules and issue169 policy; asserted exact PR174 bytes for action/workflow/analytics/staging/analytics-test. Output (exit0):
```text
packet a96add99dcd339a02b57a554a4f1d799b3dfab76b6bd745c98406174cc8547df
manifest files verified 38
historical exact gzip 5 1360413 f090b1dd11fc6bcb01c8bc95e9c4f0a04ddbfaaaf3d5c661e01b33522524f62e
historical exact gzip 7 1304407 b275a449e2cc45d72481bea09e0a4a47be96d1beff506ccdc2008d99eaceff2e
accepted site/docs, parser/timing, canonical producer/pin, budgets/scanners/policy unchanged vs base
actual media controller sources exactly equal PR174 bytes
```

Within Case4, actual `source-tests.cjs.select(process.cwd(),'pr',{base:'ec35807bec4a233cf7e80eb39f455c1f6b19434a',head:'9588ba60b6ad43e127d61bd5d6e94f5c0d858dea'})` returned:
```json
{"profile":"pr","modules":75,"relevant":["tests/analytics.test.cjs","tests/article-browser-evidence.test.cjs","tests/quality.test.cjs","tests/staging-regression.test.cjs"]}
```
The first supplementary registry-union probe then failed with `TypeError [ERR_INVALID_ARG_TYPE]: The "options" argument must be of type object. Received type string ('utf8')` at its local `execFileSync` call. This was reviewer probe code, after successful selection, not candidate execution. Diagnosis: Node requires `{encoding:'utf8'}` as the third argument. Corrected only that probe invocation, without changing any source/test or rerunning a failed campaign. It compared current row inputs against both `git show ec35807:tools/quality/test-profiles.json` and `git show 550c7f24:...`; completed exit0:
```text
Four relevant registry entries retain both parent input unions.
```

Final readback: `git status --short` empty; HEAD/tree still exactly candidate/tree above. Prompt hashes matched. No emitted partial TAP or skipped tests counted as success: four selected existing Node tests passed4/4; four scenario groups completed. No branch/line coverage percentage measured.

## Retained native failure and limits

Read primary supplied raw `failed-staging-current/stage-functional.json`: source `ec35807bec4a233cf7e80eb39f455c1f6b19434a`, tree `e2c1ae7b8ed6dd41f3580d292d6e0c8ad89cbcf6`, pass false; startup failure Chromium `Lossless article media preparation failed: No module named 'PIL'\n`; secondary report error `selected articles require actual browser evidence`. That independently supports the missing-PIL failure and the diagnostic masking risk. It is not a current candidate pass. Supplied `prepublication-current/prepublication.json` is source EC, run42314101070/attempt1, pass true, with explicit per-check commands/statuses; it remains prior-source evidence. Did not turn its summary into current-source full accounting or open referenced unsupplied runner logs.

Source inspection confirms `validateFunctional` still calls `validateArticleJourney` immediately after requiring empty startup failures; exact journey/navigation/failure/analytics checks remain. `collectFunctionalEngine` retains `finally` close and close errors in startupFailures; `Promise.allSettled` joins engine cleanup. Controlled collection test executes successful closes and article failure handling, not real browser launch or real close-failure injection. Source ordering preserves error refusal; it does not prove hosted successful collection.

Unobserved: actual actions/setup-python download and pip wheel availability/codec on hosted Linux, Windows, macOS; real integration browser collection, native current source campaign, full R10 diagnostic, exact stable alias/artifact, PDF visual rendering and desktop/mobile/no-JS author review. Setup action VM does not execute pip/verification code; actual local producer verifies the installed canonical dependency while encoding, but cannot attest hosted setup. Full workflow matrix, scanner runtime, RI regeneration and production admission were not run by this bounded role. No current hosted or trust acceptance follows. Preserve existing source/Basic/RI/style/lint/security/advisory, original browser/performance budgets, independent roles and maintainer exact-head review gates.

No blocking finding in inspected scope. Native runtime and human delivery limitations above stay open under AC05/09/10/11; no whole AC is closed by this review.
