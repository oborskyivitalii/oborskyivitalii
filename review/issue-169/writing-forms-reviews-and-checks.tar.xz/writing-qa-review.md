# Writing forms correction — White-box QA first judgment

Verdict: PASS for this prepared one-test-file correction, with no blocking findings. This is bounded local test evidence, not clean-Git, full-suite, hosted, protected-merge, staging, production, or whole-AC acceptance.

## Identity and source boundary

Role: distinct nonauthor White-box QA, task `/root/writing_qa`, first judgment on this correction. Actual launch acceptance/none-fork receipt belongs to orchestrator; provider context/model internals are unobserved. Read only supplied sources and necessary repository owners. Did not read peer verdicts, parent notes, private history, or requirements-writing-forms content. A broad filename inventory exposed a peer report filename only, not its contents; it was not used as evidence. No delegation, implementation, external writes, browser, or full campaign.

Prepared dirty delta: controller HEAD `8f330c33fb9f84db3dccf3faa3aec109cd8cdbde`, only `tests/site-engine.test.cjs` modified. Producer HEAD `558682775b9798a961f91a86673000a0b13e34d9`. Both verified locally. Applicable source instruction inventory found no nested AGENTS under tests/tools/quality. Root instructions, README, memory, acceptance, reviewer common/role prompt, registry/profile routing and source owners inspected. Remote GitHub refs were not independently fetched in this bounded role.

Packet SHA256 `7dc87898f07cacb1d6e9e07937370c07900fb43fe318ffa8548ff113e12ac2b9`; manifest `fc3bf381afd019a41dd034813acfa84fefe5e01ffe7c5e499d732d9beb205f30`; diff `cb9f25140d462516480bcf4209842ca7af339f6a9a9ccfba23a76036df119f9b`. Common prompt `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`; changed source `d33a0577d09deb4a9fc968a07373e61d27c22ef1585713825270cfd277afccb6`. Every manifest entry and actual git diff matched supplied identities; rechecked all manifest entries before writing this result. Full identities retained in `writing-qa-hashes.log`.

## Risk to check matrix

| Risk / AC contribution | Structural fault and scenario | Independent oracle | Executed check |
|---|---|---|---|
| AC05 source/test integrity | Extraction silently differs from permanent test | Exact body byte comparison, allowing only root-relative require relocation | PASS extraction comparison |
| AC09/10/11 delivery regression support | Absent-resource main accidentally omits or doubles resource | Exact sum of HTML gzip plus each declared dependency; resource occurs once; increase equals actual resource gzip | Main canonical named test + independent arithmetic interception PASS |
| AC09/10/11 delivery regression support | Existing PR170 resource overwritten or counted twice | Existing resource record must exactly match raw/gzip/hash; assets and fallback preserved; total unchanged | Exact current extracted test with actual PR170 modules/docs + arithmetic interception PASS |
| AC05/11 fail-closed regression support | Transfer omission, closure omission, missing fallback evidence, wrong digest, unsupported route accepted | Actual validator must throw for each distinct mutation after baseline acceptance | Both roots: all five refused with distinct intended errors |
| AC05/11 geometry/security | Changed setup relaxes geometry/closure/resource refusals or budgets | Unchanged surrounding test and validator; canonical equality, two prefixes, invalid route/declarations/depth/bytes/fragment and unsafe SVG refusals retained | Named test PASS on both forms; scoped diff inspection |

The AC mappings above identify contribution only; acceptance policy retains separate human/hosted/delivery requirements.

## Actual execution and arithmetic

Pinned `/tmp/issue169-review/node-v24.19.0-linux-x64/bin/node`, each command bounded by timeout45s.

- Canonical: `node --test --test-name-pattern='Writing resources retain exact geometry' tests/site-engine.test.cjs`: exit0, 1 test / 1 pass / 0 fail / 0 skipped, 271ms. Raw `writing-qa-main.tap`.
- PR170: `PRODUCER_TEST_ROOT=/workspace/scratch/94faff7d674c/repo node --test /tmp/issue169-controller-fix/producer-writing-test.cjs`: exit0, 1 test / 1 pass / 0 fail / 0 skipped, 310ms. Raw `writing-qa-producer.tap`.
- Own targeted same-realm source-body execution intercepted validator calls without replacing validator decisions. Main: actual resource gzip17285; total111524 →128809, exactly +17285, resource count1. Producer: total110033 →110033, increase0, resource count1. Each form made six validator calls: baseline accepted and all five mutations refused. Raw `writing-qa-arithmetic-corrected.log` (exit0, 502ms).
- First arithmetic harness used `vm.runInNewContext`; exit1 retained in `writing-qa-arithmetic.log`. Its baseline failed because cross-realm arrays have distinct prototypes under deepStrictEqual, despite identical values. Diagnosed this harness artifact from stack and equal array contents, then changed only harness execution to same-realm Function. Candidate source and oracle unchanged. This failed diagnostic is not reported as a candidate failure or suppressed.

Five mutation errors, in order, on both actual forms: incomplete route transfer accounting; route size resource closure differs; missing route fallback size evidence; route resource size identity; unsupported route size resource. These establish meaningful detections rather than five throws caused by a broken baseline.

Supplied primary evidence inspected: old PR170 test failed on assets-array versus undefined assumption (0/1); current PR170 extracted test and canonical main passed (1/1 each). Own executions corroborate current results. Existing-resource assertions verify exact record and preserve source arrays; absent branch inserts once. Diff contains no budget, validator, runtime, controller, or security changes. Current size admission independently enforces exact dependency closure, digest path identity, total arithmetic, SVG count and original size caps.

## Disposition and limits

Retain permanent `tests/site-engine.test.cjs` ownership in test-profiles (`pr-targeted`, `staging`, `production`; surviving `node tools/quality/source-tests.cjs --profile production`) and SITE-CHECK-PROFILES. No test lifecycle/oracle/budget change required. Existing extraction is an intentional bounded diagnostic and does not constitute native PR170 whole-suite execution. No measured branch-coverage percentage is claimed. Arbitrary malformed pre-existing fixtures and whole-suite/native CI/controller/hosted routes were not executed here; source assertions and existing validator cover their relevant guards, and native required runs remain orchestrator-owned. No finding requires implementation treatment within this delta.
