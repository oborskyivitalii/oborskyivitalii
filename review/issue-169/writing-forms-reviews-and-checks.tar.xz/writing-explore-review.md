# Exploratory / Interaction QA — Writing setup correction

Verdict: no findings in this prepared one-test-file delta. This is bounded correction evidence, not clean Git acceptance, a native PR170 full-suite result, or release approval.

Owner #169 / PR #173. Candidate is dirty `tests/site-engine.test.cjs` over `8f330c33fb9f84db3dccf3faa3aec109cd8cdbde`; external producer is `/workspace/scratch/94faff7d674c/repo` at `558682775b9798a961f91a86673000a0b13e34d9`. Both heads were read locally. `git status --short` contained only the intended test modification; live remote refs/checks/deployments were not observed in this review.

## Charter and applicability

Independent charter before any peer reconciliation: execute the actual Node test surface against inline and already-external Writing; inspect actual resource accounting to distinguish an absent resource from an admitted one; check exact resolved geometry and retained negative refusal journeys. Bound: three minutes, individual commands at most 45 seconds, no full suite/browser campaign, no implementation, external writes or delegation. Only this report and own raw logs were written.

The delta changes controlled test setup only. It changes no browser code, documents, CSS, templates, controls, navigation, focus behavior or hosted runtime. Browser/perceptual/device interaction is therefore not applicable to this delta. Hosted state, physical-device behavior and human usability were not observed and are not inferred from Node results. CLI/test execution and failure reporting are the applicable interaction surface.

## Identity and independence

Read common and role prompts before assessing source. Common SHA-256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; exploratory prompt SHA-256: `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.

Packet SHA-256: `7dc87898f07cacb1d6e9e07937370c07900fb43fe318ffa8548ff113e12ac2b9`. Supplied manifest SHA-256 `fc3bf381afd019a41dd034813acfa84fefe5e01ffe7c5e499d732d9beb205f30` and diff SHA-256 `cb9f25140d462516480bcf4209842ca7af339f6a9a9ccfba23a76036df119f9b` match packet. All 14 manifest file hashes matched inspected bytes. Actual worktree diff exactly matched supplied diff. Test SHA-256: `d33a0577d09deb4a9fc968a07373e61d27c22ef1585713825270cfd277afccb6`.

Task handle is `/root/writing_explore`; packet says requested none-fork isolation. Actual orchestrator tool response and provider memory/model/context internals are not available from this execution and cannot be attested here. No parent notes, private conversation history or peer review contents were read; a directory listing exposed filenames only. Necessary repository owners and supplied primary evidence were inspected. No peer verdict informed this result.

## Executed journeys

| Case | Expected | Observed |
| --- | --- | --- |
| Supplied old test against actual external producer | Expose inline-only setup assumption | Retained before TAP fails at `assert.equal(...assets, undefined)` with the actual one-element Writing SVG array. This failure is preserved, not relabeled as pass. |
| Exact extracted current test | Body equals candidate test except module path adaptation | Independently compared complete test body: exact equality after the sole fallback require-path adaptation. |
| Inline current main candidate | Create controlled resource record and add its gzip once | Native canonical selected test passes, 1/1. Probe sees no prior Writing declaration/file/row resource, gzip 17,285, original transfer 111,524; branch adds 17,285 once, producing controlled 128,809. |
| Native external producer modules/docs | Preserve actual record and transfer | Extracted exact test passes, 1/1. Probe sees the canonical 53,669-byte resource, SHA matching its path, gzip 17,285, exactly one row occurrence and total transfer 110,033. Existing-resource branch asserts identity and never adds gzip or overwrites assets. |
| Geometry and finite resource resolver | Canonical output at root and nested relative depth; refuse wrong inputs | Both passing test executions assert resolved output exactly equals canonical geometry for prefixes empty and `../../`; both execute wrong route, absent/duplicate assets, wrong depth, changed bytes and wrong fragment refusals, plus script/event-handler/external-use refusals. |
| Transfer admission mutations | Retain all five refusals | Both passing test executions reject removed gzip, removed asset, removed fallback evidence, corrupted SHA and unsupported index resource. Mutation list is unchanged in diff. |

Own executions used `/tmp/issue169-review/node-v24.19.0-linux-x64/bin/node`, with no network/browser/provider calls. Commands were the extracted test under `PRODUCER_TEST_ROOT` and native `--test --test-name-pattern=Writing resources retain exact geometry tests/site-engine.test.cjs`. Each completed in under one second. Raw own Node output used the environment default human reporter despite the `.tap` filenames; supplied before/after files are TAP. No unchanged failed campaign was rerun: the before result is inspected retained primary evidence, and executions exercise the corrected candidate.

## Evidence and scope

Own logs: `writing-explore-identity-and-runs.log`, `writing-explore-producer.tap`, `writing-explore-main.tap`, `writing-explore-accounting.log`, all beside this report. Primary retained evidence inspected: `writing-current-producer-before.tap`, `writing-current-producer-after.tap`, `writing-main-after.tap`, and `producer-writing-test.cjs`.

`tools/quality/artifact.cjs:105` independently enforces finite route declarations, exact resource closure/identity, exact transfer equality and existing budgets. The prepared diff alters none of those validators or budgets; all five transfer mutations remain. Resource identity, both setup branches and retained refusal behavior are supported by the executions above.

Existing case owner is `tests/site-engine.test.cjs`, permanently registered in `tools/quality/test-profiles.json:952` for `pr-targeted`, `staging` and `production`; surviving full route is `node tools/quality/source-tests.cjs --profile production`. This targeted review does not claim that full route executed here. No duplicate browser/device regression is proposed for a test-setup-only correction.

AC05 and AC11 receive this source-bound role result subject to the orchestrator recording actual launch/result receipts. AC09 and AC10 receive only correction compatibility/refusal evidence; their broader PDF/copy/visual/delivery requirements are not established by this test. None of the four whole ACs is closed here. The packet's stop boundary remains controller prerequisite, then PR170 stable staging STOP; no PR170 merge or production authorization follows.
