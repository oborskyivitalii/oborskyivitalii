# Code review — Writing setup correction

Verdict: no blocking code findings in the prepared one-file delta. This is a bounded correction review, not whole-AC, native full-suite, staging, release or merge acceptance.

## Inspected identity and scope

- Owner #169 / prerequisite PR #173; controller HEAD `8f330c33fb9f84db3dccf3faa3aec109cd8cdbde` with only `tests/site-engine.test.cjs` dirty. This is a prepared working-tree delta, not clean Git acceptance.
- Candidate test SHA-256 `d33a0577d09deb4a9fc968a07373e61d27c22ef1585713825270cfd277afccb6`.
- Packet SHA-256 `7dc87898f07cacb1d6e9e07937370c07900fb43fe318ffa8548ff113e12ac2b9`; manifest SHA-256 `fc3bf381afd019a41dd034813acfa84fefe5e01ffe7c5e499d732d9beb205f30`; diff SHA-256 `cb9f25140d462516480bcf4209842ca7af339f6a9a9ccfba23a76036df119f9b`.
- All 14 manifest entries matched actual local bytes. Worktree diff exactly matched supplied diff. Producer repository HEAD independently read as `558682775b9798a961f91a86673000a0b13e34d9`.
- Common reviewer contract SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code role SHA-256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Read root AGENTS, README, MEMORY as dated handoff, relevant repository-map entries, CONTRIBUTING review/failure sections, CODE-STYLE, site source contract, check profiles and issue-169 acceptance policy. No nested AGENTS found under tests or agents.

## Correctness assessment

At `tests/site-engine.test.cjs:114–147`, existing external resources must equal the one canonical resource name; its raw length, gzip length and SHA-256 must exactly equal canonical bytes. The native size row's fallback pointer must also match. This branch does not rewrite any record or increment transfer bytes. `artifact.validateRouteSizes` then verifies exact ordered asset closure and recomputes complete transfer accounting, so omitted or duplicate transfer cannot be accepted by this preservation branch.

For the absent-resource form the setup creates one resource record, declares one asset, sets the exact shared asset list and adds gzip once. That preserves the former controlled-fixture semantics. The full diff leaves the five negative transfer/inventory/hash/unsupported-route mutations and all earlier geometry, unsafe-content, duplicate-resource and route/depth refusal cases unchanged. No runtime/controller/security/content source or budget is changed.

Reviewed applicable CS01/04/05/07/08 concerns: the correction stays in its existing test owner, uses explicit readable state and exact byte-derived sizes, preserves budgets, and retains behavioral failure assertions. It adds no dependency, runtime effects, duplicate production owner or hosted-performance claim. The test registry still assigns this file permanent PR-targeted/staging/production routes. No material maintenance issue identified within this delta.

## Primary evidence and own checks

- Retained `writing-current-producer-before.tap`: one test, one failure at the old strict `assets === undefined` assertion; actual value is the canonical external Writing resource. The diff independently confirms that old assertion was removed. The overwritten extraction is not a retained executable old-test snapshot, so I do not claim to have independently replayed the old failure.
- Retained after TAP: exact extracted current test against actual producer and canonical test on controller each report 1 passed / 0 failed / 0 skipped.
- Independently compared extraction to the complete canonical current test: exact equality after only its fallback require path is adapted to producer root. Its two-line harness explicitly binds build/artifact to that same root.
- Own Node24.19.0 bounded targeted canonical run: exit0; 1 passed, 0 failed/cancelled/skipped/todo. Log: `writing-code-main.tap`.
- Own Node24.19.0 bounded extracted producer run with `PRODUCER_TEST_ROOT=/workspace/scratch/94faff7d674c/repo`: exit0; 1 passed, 0 failed/cancelled/skipped/todo. Log: `writing-code-producer.tap`.
- Own hashes, full supplied diff/raw evidence, prompt-policy reads: `writing-code-raw.log`; extraction/diff/source readback: `writing-code-binding.json`.

These observations support this test correction's bounded AC05/AC11 code-review contribution. They do not establish AC09 PDF/external-edition parity, AC10 public related-reading behavior, complete AC05/AC11 independence or delivery acceptance, or current R10 staging. Required native integration and staging remain separate.

## Limits and independence

Read-only source/evidence inspection and two single-test executions only; commands bounded45s. No implementation, test authorship, recursive delegation, browser, full campaign, external write, GitHub fetch or live provider/deployment observation. No peer report contents, parent scratch notes or private conversation history consumed. Directory inventory exposed filenames only, not peer verdicts. The first combined owner/map read was truncated; required primary test/diff/evidence and relevant map/source sections were read separately.

Actual parent launch tool parameters/accepted response and provider model/context internals are not observable to this child; the orchestrator must attach its actual launch receipt and enforce isolation admission. No claim of provider-attested clean isolation is made. The managed runtime status tool was not exposed in the registry; no network operation was attempted. Retained historical source-wide results were not used to assert current acceptance.
