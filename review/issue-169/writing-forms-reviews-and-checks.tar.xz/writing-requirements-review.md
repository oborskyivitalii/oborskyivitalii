# Requirements & Acceptance — final prepared delta

2026-11-06. Reviewer task `/root/writing_requirements`; nonauthor first judgment. **PASS for the bounded prepared test correction; no blocking requirement or oracle defect found.** This is not whole-issue, clean-commit, native-suite, merge or staging acceptance.

## Inspected identity and bounds

Owner #169 / prerequisite PR #173; controller checkout HEAD `8f330c33fb9f84db3dccf3faa3aec109cd8cdbde`, dirty only `tests/site-engine.test.cjs`. Actual delta is 22 insertions/15 deletions in that file. Producer checkout HEAD `558682775b9798a961f91a86673000a0b13e34d9`, observed clean. Local repository/ref/status inspected; fresh GitHub refs/checks/deployment state were not observed in this read-only role.

Packet SHA256 `7dc87898f07cacb1d6e9e07937370c07900fb43fe318ffa8548ff113e12ac2b9`; manifest `fc3bf381afd019a41dd034813acfa84fefe5e01ffe7c5e499d732d9beb205f30`; actual diff matches packet diff `cb9f25140d462516480bcf4209842ca7af339f6a9a9ccfba23a76036df119f9b`. Every manifest file hash matched inspected bytes. Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`.

Read root instructions, README, map entries, dated MEMORY, applicable CONTRIBUTING review/acceptance protocol, common/role prompts, owner acceptance mapping, actual diff/test, artifact validation and permanent registry selection. No nested AGENTS under tests/agents were found. No peer output contents, parent notes or private history were read. The directory listing exposed filenames only. No implementation, external write, browser campaign or delegation occurred. Launch isolation is supplied as fork-none requested; actual launcher receipt/provider context internals are outside this role’s observations.

## Requirement assessment

The accepted narrow requirement is necessary and independently testable: current inline main and already-external PR170 Writing are valid inputs; the regression must preserve exact canonical geometry/resource bytes, finite closure and complete transfer accounting. The removed `assets === undefined` assertion was an invalid setup precondition on the latter input, as the supplied raw before TAP shows: it rejects the actual declared Writing resource before checking accounting.

The correction changes setup only. When a resource is already declared, it requires exactly `[resource.name]`, exact raw/gzip/SHA256 record and matching fallback name. It preserves measured row totals and assets, allowing unchanged production validation to reject defects. Otherwise it constructs the controlled record and adds its actual gzip exactly once. The test still requires the valid case to pass and the same five independent mutations to fail: omitted gzip, omitted asset, missing fallback evidence, wrong resource digest and resource declaration on an unsupported route. I compared the positive assertion/five-mutation suffix with HEAD: byte-identical. Geometry/depth/unsafe-SVG negatives are unchanged. No runtime, admission implementation, budget, profile or oracle was edited.

No blocking requirement defects found. Risks examined: accepting the wrong existing resource; double charging existing resources; hiding an incomplete transfer row; deleting/weakening negative checks; losing permanent CI routing; treating extraction success as native acceptance. Each is protected by the actual assertions/unchanged validator or retained as an explicit later gate.

## Traceability

| Intent / AC linkage | Check or owner gate | Observed result and limit |
| --- | --- | --- |
| Both legitimate Writing input forms; AC05 / delivery support | Current canonical named test on controller tree, Node24.19 | Independent run 1/1 pass, no skipped/cancelled, `writing-requirements-main.tap`; prepared dirty tree only |
| Existing exact native PR170 resource; AC05 / delivery support | Extracted actual current test using producer modules/docs | Exact extracted body matched current source except explicit root import adaptation; independent run 1/1 pass, `writing-requirements-producer.tap`; not native suite acceptance |
| Preserve exact closure/transfer/security refusals; AC05 | Same positive assertion and five mutations; unchanged artifact budgets/validator | Suffix equality verified; both bounded executions pass; raw hash evidence in `writing-requirements-hashes.log` |
| Failure diagnosis | Supplied `writing-current-producer-before.tap`, after TAPs and HEAD source comparison | Old undefined-resource assertion fails on actual external resource; historical execution is corroborated, not represented as a new independent replay |
| Native current staging/production route coverage; AC05 / DELIVERY | Permanent site-engine registry path | Existing profiles remain pr-targeted/staging/production with production source-tests route; full runs not executed here |
| AC09 PDF/external editions; AC10 related reading | Native/hosted publication and visual/copy gates | No publication content changes; those outcomes not reverified or passed by this test |
| AC11 independent role ownership | Four completed distinct source-bound roles and orchestration receipts | This artifact supplies only Requirements result; other roles and provider isolation admission not independently observed here |

## Acceptance and next gates

The delta preserves requirement meaning and existing oracles; no new intent/AC decision is needed for this prepared correction. It supports bounded iteration acceptance only. Leave whole AC05/09/10/11 status to their complete evidence and gates. Native Basic/publisher/profile checks on the final exact committed source, all four accepted role receipts, protected prerequisite integration, refreshed PR170 controller compatibility and full authenticated stable staging/served article/PDF verification remain separate observations. Stop/show staging per supplied current scope; this result authorizes neither PR170 merge nor production activation.

Unchanged evidence reused only for byte-identical oracle/validator/registry source; no prior broad-suite result was promoted to the changed candidate. Primary logs were hashed during this review. The supplied packet binds source files but not all producer/docs/raw bytes in its own manifest; my identity/log checks establish this bounded observation, not an immutable full native source bundle. Final candidate rehash and proper native source binding remain the orchestrator’s acceptance responsibility.
