# Requirements & Acceptance — offline output correction applicability

Verdict: **PASS for regenerating the existing nine maintained offline outputs under unchanged requirements.** Actual supplied reconstruction logs and seven preview tests pass within their scopes. The failed full-stage run remains failed; no current full-stage success, security waiver or deployment authority is inferred. Existing full stable then STOP boundary remains.

Same-role continuation `/root/r12_requirements_clean`; packet SHA256 `cf5b132ded4b83b13ae3cf47c96e678035be080ecbfd021c02cb0775dc94f3db` verified and every listed file/log digest matches. Prepared dirty subset at basef60fbe2903cf514bcd1b0b9e8b45f2629822aa4a, not a clean-source execution. Worktree status shows exactly seven existing HTML exports plus their two existing manifests changed. No peers, MEMORY or mixed parent rationale read. No implementation/test edits, external writes or delegation; only this assigned artifact written. Provider/context limitations remain as previously stated.

I independently compared current preview/bundle/checksum producers, preview tests, manuscript and PDF with base: byte-identical. `git diff BASE -- docs` is empty. Existing site/README contract explicitly says all five interactive offline entry files embed all routes, so a content edit regenerates those review exports even where hosted route bytes stay unchanged. These maintained v11 exports therefore differ from immutable historical snapshots: refreshing them from their canonical current producers is required rather than preserving stale derivatives. No new editing source, workflow, test oracle or scope is introduced.

The actual generated-checksum owner reconstructs previews, compares expected bytes and invokes bundle `--check`; stale output refusal remains intact. Supplied offline-previews-check.log reports page/gallery/source/evidence hashes fresh; offline-bundle-check.log reports handoff/entry hashes fresh. Supplied offline-preview-tests.tap completes7tests,7pass,0fail/skip; cases include main content/CSS/source links, complete handoff link resolution, query/fragment intent, input/output manifest identity, embedded executable sources and exact historical capture distinction. Supplied checksum-proof.json records `pass:true`, but contains only pass/keys, not detailed proved identities: do not describe that compact receipt as a complete security scan or full-stage result.

Raw prepublication.json is bound to f60fbe2903cf514bcd1b0b9e8b45f2629822aa4a, with pass=false and deploymentAuthorized=false. Its source-tests/basic and other named checks are historical observations at that source, not new-candidate success. Retain the first run and its stale-output failures. The packet's1255source-case/23guard quantities are supplied context; I did not inspect the full underlying source-test accounting, so they are not independently recounted here.

| Obligation | Result / next gate |
| --- | --- |
|AC05 maintained derivative freshness|Existing producer ownership and actual bounded preview/bundle freshness logs align with nine-output refresh|
|AC07/08/09 accepted paper and served assets|Manuscript/PDF/producers/tests exact-base; docs unchanged; prior paper findings reusable|
|AC05 security/check integrity|Generated-checksum stale-proof requirement unchanged; no ledger/guard waiver; complete current scan/stage still required|
|AC05/11 full source/run accounting|Failed full run preserved; fresh candidate identity/RI/current checks and existing full route required|
|AC04/06 authority|Full stable then STOP; no merge, production, platform revision or broader archive task|

After committing/regenerating source-dependent identities, use the existing current-source full-stage mechanism and its complete-attempt accounting. Do not combine an older source's passing jobs with this dirty subset to declare success. Verify actual stable article and accepted PDF, show the result, then stop.
