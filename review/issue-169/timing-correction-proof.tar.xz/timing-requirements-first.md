# Requirements & Acceptance — first preflight judgment

2026-11-06. Owner #169 / PR170. Read-only timing failure diagnostic; no implementation, test modification, external write, delegation or campaign rerun. This first result precedes peer reconciliation and must remain intact.

## Verdict

The requested bounded repair is authorized and has sufficiently clear preservation requirements. **Advancement/staging acceptance is blocked by the observed current-source timeout.** The supplied evidence supports investigating delayed scheduling of `tests/test-profile-selection.test.cjs`; it does not yet establish that moving that suite alone will fit the complete campaign in 300 seconds. Requirements do not authorize a deadline, worker, case, scanner, selector or admission relaxation. Final review remains required on the actual correction.

Inspected checkout HEAD `53102d7d55012d6bd954d7d4b248d75dc75e9600`, clean; tree reported by native evidence `f07f15dde663943842783e559b058c00539c15eb`; base `312fbe4347eda332aa8ade885b07c98beadd6da5`. Local `main` still names `8cf1588…`; that is a stale local ref, not proof of live protected main. Live GitHub refs/run identity were not queried in this bounded review and require orchestrator receipts. Source packet SHA256 `da14519f5f42c888177a98064afa899882d652f77696c3bb3512c8f53e986e4c`; every listed source manifest entry matched inspected bytes. Scope file SHA256 `60808d2a8ed3b4fc6d452b35971156a38d4f781657839c6d1599e66ea28f06ee`.

Inputs: root README/AGENTS/MEMORY, repository-map ownership routes, CONTRIBUTING failure/review/acceptance protocol, common reviewer contract and this role prompt, CODE-STYLE, SITE-CHECK-PROFILES, acceptance policy #169 and native-check-allocation, scoped source runner/worker/test sources and base-to-candidate targeted diff, raw failed-native runner JSON/stderr/TAP. No nested tracked AGENTS was found. No peer output or author scratch/private history was inspected. MEMORY was treated as dated handoff; its review claims were not adopted. Provider model/context internals and unobservable account-history behavior are unknown; launch parameter evidence belongs to the orchestrator, not this self-report.

## Four bounded inspection cases

1. Scope/authority and AC linkage: completed by inspection. Latest scope limits this session to verified stable staging then STOP; no PR170 merge or production. Older DELIVERY gate text describes later whole-issue release obligations and does not authorize them now. AC IDs remain unchanged, and whole ACs remain pending where later gates apply.
2. Exact source and raw failure accounting: completed by inspection. Native runner JSON has staging profile, 75 selected modules, clean source before/after, `status: failed`, `pass: false`, `ETIMEDOUT`, 300000ms bound and 16777216-byte output limit. Native Node is v24.19.0. Observed final accounting arrays are empty.
3. Critical-path and preservation surface: completed by inspection. Raw stderr records capacity4, all75 dequeued, 74 completed with `wrapperPassed:true`; the only unfinished wrapper is `tests/test-profile-selection.test.cjs`, dequeued at290036ms. It had approximately9964ms before the process deadline. Last completed wrapper was release-archive at298113ms. TAP contains1146 emitted top-level `ok` records, no `not ok`, and no complete final accounting; those partial observations are not a pass.
4. Existing correction oracles and next gates: completed by inspection. Worker retains process isolation, cap4, abort/cleanup, native TAP and summary failure handling. Existing profile tests cover ordering, nonempty native accounting, capacity ceiling, timeout reporting, source mutation, termination cleanup and refusal cases. No dynamic tests or campaigns executed by this reviewer; the four-case/ten-minute bound was applied to inspection.

Raw evidence identities:

| File in failed-native | SHA256 |
| --- | --- |
| prepublication-source-tests-runner.json | 8edea52a4ee1db403e1c14367ab6057079e0626e7e7817c6a62f66d985d92441 |
| prepublication-source-tests-runner.stderr | 712b1fb349bb299cd09e37714d082aa63fdb65a734137e9e7d5810b84051027f |
| prepublication-source-tests-runner.tap | 26ad1ebe94a0ec62979a15d9711aeea35e7ebb20bf72da2552fbf5c0d57b54c7 |

## Findings and treatment

**Blocking, observed execution failure — raw runner JSON execution/status and source-test-worker.cjs:14–28,76–79.** The permanent profile-selection suite is absent from the priority list and remains the final lexically queued file. In this native run it began with under10s left and had no completion when the whole process timed out. This blocks AC05/11 source admission and therefore stable staging; it does not demonstrate an assertion defect in that suite. Preserve this failed run and partial accounting. The smallest evidence-linked hypothesis is earlier scheduling of this suite within the unchanged selected inventory and unchanged four process workers. Confirm actual suite duration before attributing the timeout solely to queue position; retain all later modules and prove complete accounting after correction.

The 74 completed wrapper durations sum to1174263.699975ms. Dividing by four gives293565.924994ms before the unfinished module's full duration and orchestration overhead. These overlapping wall durations are not CPU measurements and can change with scheduling/contention, but they show very little fixed-duration margin. **Do not promise that priority movement alone suffices.** If a bounded measurement shows infeasibility, investigate a measured setup/fixture bottleneck with semantic parity rather than guess, remove cases or change topology. New distributed runner capacity/sharding for this failed prepublication campaign is not established as an authorized repair by the cap4 constraint.

**Low, documentation mismatch — guides/SITE-CHECK-PROFILES.md:49–52 vs source-test-worker.cjs:14–28.** The guide says Space/executive start first; the candidate worker starts rights/controller/Pages first. The newer topology section describes historical sharding separately. Update only the scheduling description when the evidenced schedule is finalized; preserve the300s/16MiB/cap4/zero-skip and failure text. This affects AC05 traceability and CS04/05/08, not a new acceptance oracle.

**Evidence limitation, admission receipt required — diagnostic-packet.json and supplied raw evidence.** Packet hashes the source files but initially does not bind scope-file or raw-log bytes, nor identify the native workflow run/attempt/download origin. This report supplies inspected file hashes; the orchestrator must retain provenance and a complete immutable evidence manifest before claiming source-bound GitHub acceptance. This does not block read-only preparation or an evidenced authorized fix. Independent launch receipts likewise must record actual requested/accepted isolation; this report cannot attest unseen provider internals.

## Acceptance matrix

| Intent / AC | Required oracle or gate | Observed result / next evidence |
| --- | --- | --- |
| Preserve accepted R10/AC01–04,07–10 | Existing accepted source plus byte parity of site/docs manuscript/PDF/figures | No correction authored; final timing-only delta must retain accepted site/docs bytes and existing planned-link/DevCon semantics |
| AC05/11 current native source | Entire current selected module inventory, cap4/process isolation,300s+unchanged30s reporting grace,16MiB; all actual native cases pass, zero skips/TODO/cancelled, clean exact source before/after | Failed native53102d7,75 modules,74 wrappers complete, no final accounting; fresh full exact correction run required after bounded verification |
| AC05 style/routing | CS01/04/05/07/08/09/10, bounded guard, pinned format/lint, RI build/verify and RI-CI/owning policy as affected | Inspected only; current correction checks pending |
| AC05/11 independence | Four distinct completed nonauthor source-bound roles, applicable corrections and launch/packet receipts | This is first Requirements preflight only; other executions not inspected/claimed |
| AC05/09/10 delivery | Existing owner staging/controller route; exact hosted artifact/stable alias/source identity; real R10 reader desktop/mobile/no-JS, interactions/materials/related reading; PDF digest/MIME/five pages | Not observed; source admission must pass first. Staging requires actual run evidence, not preview or fixture proof |
| Scope STOP boundary | Report exact source/run/limits and leave PR170 unmerged/production inactive | Binding latest scope. Whole ACs with merge/production/manual platform or other later gates remain open |

## Next bounded action and gate

Record the question before execution: does profile-selection's complete isolated duration exceed the native~10s remaining slot, and does placing it earlier reduce the complete critical path without displacing another module beyond300s? A targeted same-source/same Node/cap4 measurement with raw wrapper timing supplies information; stop after its planned bounded comparison and retain failures. Such measurement is diagnostic only. A worker-priority correction and its narrowly affected existing order fixtures/docs are permissible if evidence supports it; unrelated fixture rewriting, selection/case changes, scanner waivers and budget/topology changes are not established by this finding.

After correction: affected functional and failure/cleanup/cap/accounting checks, four actual independent roles, exact clean current-source full required native/security/RI/owning checks, normal full owner staging, actual stable R10/PDF verification, then STOP/show. No same-source failed full rerun before a recorded evidence-linked correction, and no receipt-only eligibility reset.
