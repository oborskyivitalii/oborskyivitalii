# Source-runner timing diagnostic — first result

Date: 2026-11-06. Role: Code diagnostic, nonauthor; task `/root/timing_diagnostic`.
Candidate: `53102d7d55012d6bd954d7d4b248d75dc75e9600`; base `312fbe4347eda332aa8ade885b07c98beadd6da5`.
Packet: `diagnostic-packet.json`, SHA-256 `da14519f5f42c888177a98064afa899882d652f77696c3bb3512c8f53e986e4c`.
Common prompt SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code prompt SHA-256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.

## Judgment and assurance

The retained native staging source run is failed, not a partially accepted pass. Its immediate mechanism is the unchanged 300000ms deadline reached while the last selected module was still executing. The expensive work is distributed across many modules; moving one last module earlier is not evidence of adequate runtime margin. No fix implementation or future-candidate acceptance is supplied here.

This execution received author messages before this first report: a release-rights dependency-copy hypothesis and a Preview PASS statement, followed by the author's profile/copy timing observations and parser/cache hypotheses. I disclosed the first exposure immediately to the orchestrator. I did not read peer artifacts or author scratch outputs, and all measurements below came from my own permitted source/evidence reads or bounded commands. Nevertheless this is **not a clean independent first judgment** under the launch contract. A fresh reviewer is required wherever that level of acceptance is needed. Provider model/context internals are unknown. The requested none-fork parameter is the orchestrator's receipt to establish; this report cannot attest it.

## Inspected sources and evidence

Read common/role prompts, root AGENTS/README, relevant map/protocol/style/profile/acceptance owners and issue169 scope. Read source-tests, source-test-worker, local, prepublication-runner, test-profile-selection, release-rights fixture/CLI integration, executive hot tests, SEO normalizer/restoration, format-parity helper boundary, artifact build and relevant fixture helpers. Inspected the complete scoped source-worker/profile-test diff; the other three named runner files have no base-to-candidate diff. No nested AGENTS files were returned for tools/tests. No GitHub or remote writes; no implementation or delegation. Repository remained clean before/after diagnostics. MEMORY and unrelated historical reports were deliberately not consumed under the review's private-history boundary.

Manifest hashes for the five supplied runner/test owners match the packet. Additional inspected owner SHA-256: release-rights `1dd519a2cb41c55e720e5c13dcf72c5c8afee96ab486a6bec5e635f145d86517`; executive `3be20bc027883f23b394b420ddbdbe23cebc32bf57bf5b70715a18ca98e63202`.

Raw retained evidence: `failed-native/prepublication-source-tests-runner.{json,tap,stderr}` and enclosing source-test streams. Native report binds clean source/tree `f07f15dde663943842783e559b058c00539c15eb` before and after execution.

## Observed bottleneck

- Node v24.19.0; available/configured concurrency 4; 75 selected modules; 75 dequeues, 74 completion events.
- Execution ETIMEDOUT at 300000ms; no final native tests/pass/fail/cancelled/skipped/todo accounting arrays. Emitted leaf successes do not establish completion.
- Only `tests/test-profile-selection.test.cjs` lacks a completion event. It dequeued at 290036ms, leaving 9964ms to the deadline. Last other completion: release-archive at 298113ms.
- Completed wrapper durations sum **1174.264 worker-seconds**, already **293.566 seconds** at an ideal four-worker work lower bound before unfinished profile work. This is a work-volume/resource-margin problem as well as a scheduling tail.

| Native completed module | Wrapper seconds | Dequeued seconds |
| --- | ---: | ---: |
| release-rights | 155.054 | 0.005 |
| executive | 115.229 | 85.182 |
| space | 105.447 | 73.811 |
| pages-delivery | 85.169 | 0.013 |
| publication-records | 75.937 | 68.133 |
| release-controller | 73.801 | 0.010 |
| pages-migration | 68.116 | 0.017 |

The largest retained leaf is release-rights' `publication actual edition and package CLIs freeze exact sidecars before any upload`: **77.430s**, approximately half that module. It builds a native-current-article fixture and exercises actual artifact/Color/staging/production/package CLIs, missing/stale/wrong-source refusal cases, and a content successor. These checks must remain.

Executive's measured hot leaves include contact/title reconciliation **22.054s**, response reconciliation **15.491s**, article metadata reconciliation **14.123s**, practical-positioning reconciliation **12.682s**, and hierarchy verification **10.114s**. These retain meaningful independent mutation checks. The source confirms that full restoration repeatedly invokes strict HTML normalization along evolving document states, and each cold helperContracts call starts a Python process. The retained timings identify the expensive test families, **not a measured breakdown of Python startup versus parse versus Git work**.

`local.cjs` makes source-tests exclusive in prepublication; prepublication-runner honors that exclusivity. This evidence does not support blaming concurrent sibling guard jobs for the native source-test deadline. Source-tests keeps process isolation, max four file workers, 16MiB bound and strict complete accounting. Its outer 330000ms wrapper only allows report flush; it is not an extra source-execution budget.

## Own bounded diagnostics

Pinned interpreter: `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node`, v24.19.0. These are local targeted diagnostics, not a repeated native full campaign.

1. Existing test-profile-selection module, direct Node TAP, timeout90000ms: status0; **48 tests/48 pass**, all fail/cancelled/skipped/todo0; wall **8892.464ms**, native TAP duration8835.869ms. Slowest leaf1243.724ms. This disproves an unconditional local hang; it does not establish performance under the native four-file contention. No assertion/budget was changed.
2. Current tools/publishing directory copied to disposable temp directory, unfiltered: **26.485ms**, 1162files/21304651bytes; cleanup3.781ms.
3. Same source copied with node_modules path filter: **1.514ms**, 22files/246608bytes; cleanup0.084ms. Installed node_modules inventory was1142files/21059580bytes. Source fixture has14 calls. Extrapolated local copy+cleanup saving is only about **0.40s** across those calls; not a demonstrated explanation for155s. `release-rights.test.cjs:43–49` incorrectly places its filter on mkdirSync rather than cpSync; correcting that is a valid small fixture defect, but no5–10% runtime improvement is established by this measurement.
4. Attempted syscall-count diagnosis of the existing executive contact/title leaf with strace and60000ms cap. strace failed before Node execution: `PTRACE_TRACEME: Operation not permitted`. A minimal capability probe confirmed the restriction. No case result or parser-count inference comes from this failed instrumentation.

An in-memory scheduling calculation reused retained durations and substituted the local8.892s profile duration solely as an explicit estimate. Current ordering simulates298.907s; all measured durations descending simulates295.833s, versus work lower bound295.789s. Moving only profile into priority slot13 simulates300.153s. These are illustrative predictions, not native checks: durations change with contention. Even the optimistic LPT estimate has only4.167s headroom. Do not accept a reorder-only fix from this arithmetic.

## Findings, proposed treatment, and next smallest measurement

**Blocking evidenced failure — source-test completion, source-tests.cjs:executeSource and source-test-worker.cjs:priority/runFiles.** Affected issue169 AC05/AC09/AC10/AC11 and CS07/CS08 evidence: retained run cannot establish the required complete source gate. Preserve the failed raw evidence. Keep all75 modules, named cases, strict accounting,300000ms deadline,16MiB output and max4 workers. A same-source full rerun without an evidenced correction is not justified.

**Small fixture defect, nonblocking as an isolated defect — tests/release-rights.test.cjs:43–49.** The dependency-copy filter is ineffective on mkdirSync, while cpSync copies installed dependencies. Move the predicate to the actual copy boundary and retain real required toolchain declarations. Our copy comparison supports the intended file reduction and only a small local timing reduction; do not advertise it as resolving the native timeout.

**Highest-value next diagnostic — release-rights.test.cjs:889–1080.** Retained77.430s actual-CLI leaf is the clearest single measured concentration. Before editing, time each existing CLI invocation plus fixture preparation/build and cleanup in one selected-leaf execution, with original commands, inputs, assertions and30s per-CLI deadlines. Distinguish generation, artifact/source proof, rights/edition verification, and negative package checks. Stop after one bounded case. That would locate a concrete repeated expensive operation without removing CLI coverage.

**Next alternative — tests/executive.test.cjs:804–859 and tools/check_site_seo.cjs:createHTMLNormalizer/restoreContentAmendment.** Measure parser invocations and bytes for the22.054s contact/title leaf with an allowed bounded observer. Candidate treatments include batching independent hash-verified snapshot normalization using the existing normalizeMany boundary or eliminating duplicated cold parsing of byte-identical immutable inputs within existing cache limits. Those are hypotheses until measured; do not skip normalization of evolving documents, broaden approved snapshots, relax duplicate/malformed checks, grow cache budgets, or collapse independent mutation assertions. strace is unavailable here, so use an explicitly scoped observable seam rather than claiming syscall evidence.

**Documentation mismatch, nonblocking — guides/SITE-CHECK-PROFILES.md:50–52.** It says selected Space/executive start first; inspected worker and native dequeues start release-rights/controller/Pages. Update the wording to match the final accepted scheduling policy if that owner is touched. This prose does not establish performance correctness.

No proposed future fix is accepted by this diagnostic. No independently proven5–10% safe work reduction was found within these four bounded attempts; the report deliberately leaves that evidence question open.
