# Executive parser diagnostic — continuation

This continues `/root/timing_diagnostic` after the preserved first report. It is a targeted reconciliation diagnostic with prior author-message exposure disclosed in that report; it is not a fresh first judgment or acceptance of a changed candidate.

The selected existing leaf was `approved contact and decorative title reconciliation retain changed destinations and copy` in `tests/executive.test.cjs:804–859`. The observer wrapped actual `child_process.spawnSync` calls to the existing format-parity Python helper and `execFileSync` calls in a disposable external preload. It preserved actual command, arguments, input, output, exception and return behavior; it recorded only input SHA-256, UTF-8 byte lengths, language, status and duration. No HTML, private input or environment values were emitted. No repository edits were made by this role.

First attempt passed1/1 in11164.682ms but the collector read only stderr, while the Node test harness forwards child stderr through TAP stdout comments. The resulting zero counts in `timing-executive-observer.json` are **invalid observation**, not evidence of no parsing. After disclosing the instrumentation limitation, one corrected observer attempt of the same selected leaf stored hashed metadata in disposable temporary files and read them back. No additional scenario was selected.

Corrected attempt: pinned Node v24.19.0;90000ms cap; exit0;1test/1pass; fail/cancelled/skipped/todo all0; wall11565.334ms; leaf11409.890ms. Exact metadata is retained in `timing-executive-observer-v2.json`.

| Observation | Measured result |
| --- | ---: |
| Actual Python parser calls |359 |
| Requests across those calls |448 |
| Unique input SHA-256 identities |448 |
| Repeated exact input rows |0 |
| Parser subprocess elapsed total |10788.187ms |
| Calls with one request |335 |
| Calls with at most32KiB total request bytes |320 |
| Elapsed in those≤32KiB calls |9491.986ms |
| Total input UTF-8 bytes |6405577 |
| Parser call min/median/max |20.330/28.790/170.884ms |
| Git execFileSync calls |59 |
| Git elapsed total |211.833ms |

Parser subprocess time accounts for about93% of selected-case wall time. This establishes the measured cost center. It does **not** isolate interpreter startup from HTML parsing/serialization. All448 input identities are unique: the proposed repeated-exact-input/LRU-eviction explanation is contradicted for this selected leaf. Growing or changing cache eviction has no demonstrated benefit here.

The feasible reduction direction is to amortize Python process invocation across **independent** normalization inputs while preserving the canonical parser, original request/output coverage and byte/entry bounds. Existing normalizeMany already batches some independent snapshots:24calls contain multiple requests, while335 remain singletons. Evolving document states are genuinely different inputs; removing their strict parsing or calling them approved snapshots would weaken behavior. A phase-batched restoration API for independent documents could preserve intermediate checks, but would be a real refactor requiring before/after parity and negative-case evidence, not a trivial cache adjustment. A persistent parser process is another possible mechanism, but introduces protocol/lifecycle/failure accounting responsibilities; this diagnostic does not establish it as the safest change.

No implementation is approved or supplied. No measured5–10% safe reduction has yet been demonstrated. The observer does identify a suitable target for a bounded prototype comparison, and decisively rules out the suspected repeated-input cache mechanism for this case.

Source hashes remained unchanged for observed owners:

- tests/executive.test.cjs: `3be20bc027883f23b394b420ddbdbe23cebc32bf57bf5b70715a18ca98e63202`
- tools/check_site_seo.cjs: `ddbc2df7c08b126a7905cba82bc06efc7692e61899c7e174d559650dba6def3b`
- tools/quality/format-parity.cjs: `385c1e24982638b87a9bf50d5b83e472865d2c7fec4f6931146e200ffd640004`
- tools/quality/format-parity.py: `2f26d71bac62d7ed20579834a4d835bbae2a433e36ff80515714bb05c920b2d7`

The shared checkout was being changed by the author during this continuation: first source-test-worker, later its profile test and profile guide. These are outside this selected executive leaf's execution. The continuation is therefore an observation of the unchanged hashed owners in a dirty shared checkout, not a clean-source campaign receipt. The original first report's clean before/after observation applies only to its earlier phase.
