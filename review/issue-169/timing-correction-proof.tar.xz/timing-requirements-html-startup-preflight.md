# Requirements & Acceptance — HTML helper startup preflight continuation

2026-11-06, owner #169 / PR170. Separate continuation after preserved `timing-requirements-first.md`; no peer output inspected, no implementation/tests authored or changed, no external writes or campaigns executed. The parent supplied a new concrete optimization hypothesis and raw observer file. This is preflight permission within existing accepted scope, not final correction acceptance.

## Verdict

**A narrowly routed `-S` invocation is permissible as an evidenced implementation experiment:** the same configured locked-venv Python executable and unchanged `format-parity.py`, used only for a nonempty batch whose every request is HTML, may skip unnecessary startup initialization provided real same-helper event/error parity is established and the speed effect is measured. This changes invocation rather than the accepted parser/contract. It does not authorize changing the helper's parser semantics, refusal rules, requests, output rows, selection, case inventory, scanner/toolchain checks, deadlines, buffers, process isolation or four-worker cap.

The current facts make startup a defensible investigation target. They do not yet prove that startup initialization accounts for a particular number of milliseconds or that this change resolves the full native timeout. The original failed campaign remains failed.

## Inspected identities and observations

Current HEAD remains `53102d7d55012d6bd954d7d4b248d75dc75e9600`. Working tree has the separate schedule-related changes in worker/profile tests/guide; this judgment concerns the as-inspected unchanged parity helper files, not acceptance of those separate modifications. Relevant SHA256:

| Input | SHA256 |
| --- | --- |
| tools/quality/format-parity.cjs | 385c1e24982638b87a9bf50d5b83e472865d2c7fec4f6931146e200ffd640004 |
| tools/quality/format-parity.py | 2f26d71bac62d7ed20579834a4d835bbae2a433e36ff80515714bb05c920b2d7 |
| tests/format-parity.test.cjs | 3127fc95fdbbef370acb77d0a18bb4fd1527f3ab5c0d8971b364b2c68552f2f9 |
| reconcile-review/timing-executive-observer-v2.json | 5a91d23c2c19027e07aaa01515f0905029018489a969360798dc582049a7a911 |

Four bounded inspection cases completed:

1. Raw observation: recomputed359 parser subprocess events,10788.186658ms total parser-event elapsed time,448 request rows,448 unique language/digest pairs, all `language: html`, all subprocess status0; observed complete original executive contact/title case has one pass, zero skips/TODO/cancelled/fail,11565.333505ms wall. Zero repeated inputs means cache reuse is not an evidenced remedy for this observation. The observer alone lacks source commit/tree, Python executable/version and locked-environment receipt, so its timing must retain its actual diagnostic attribution.
2. Implementation boundary: `format-parity.cjs:151–170` chooses the configured tools directory's venv interpreter, sends the whole JSON batch to the same helper, enforces subprocess failure and exact row count, throws on row errors or missing contracts. These behaviors must remain. `format-parity.py:8–11` imports only stdlib at startup. Its HTML branch225–229 constructs HTMLContract and feeds/closes the parser; it does not use site-installed packages or interpreter prefixes. YAML branch215–224 imports external `yaml` when requested. No parser rewrite or alternative oracle is necessary.
3. Existing independent oracles: `tests/format-parity.test.cjs` already exercises exact HTML duplicate-attribute errors, nonvoid self-closing refusals, SVG/foreignObject, MathML, entities, raw text, whitespace boundaries, semantic equality/inequality, plus exact mixed-language parser errors and YAML ordering. The direct-helper diagnostic test currently invokes normal Python; keep its expected errors and extend actual comparisons rather than infer unchanged semantics from source text.
4. Selection/preservation: parity tests are permanent PR-targeted/staging/production suites, selected by `tools/quality/format*`; executive tests also consume both helper paths. Existing registry routes cover the proposed owner change. Root protocol/CS01/04/05/07/08/09/10 and original current-source/independent/hosted requirements remain as in first preflight. No new suite, workflow, global Python flag or topology is justified.

## Required correction acceptance

| Requirement / AC | Observable oracle | Gate |
| --- | --- | --- |
| Exact HTML contracts and refusals, AC05/11 | Run the unchanged helper through the same locked-venv executable in normal mode and `-S` mode over identical ordered nonempty HTML batches; compare every returned row, complete contract/event values, exact errors, stdout/stderr and exit/error status. Include successful and refused rows together, not just first-row `helperContracts` exceptions | Required before claiming semantic parity |
| HTML-only scope | Behavioral invocation assertion establishes `-S` only for a nonempty all-HTML batch; normal mode for empty, HTML+YAML, HTML+Python/JSON, nonHTML, unknown/malformed request batches | Required. Use a safe routing predicate so null/missing-language input does not introduce a different earlier JS failure |
| Existing error propagation | Actual duplicate attributes, ordinary nonvoid self-closing and foreignObject refusal; subprocess nonzero/error, missing/malformed/incomplete helper output still fail through existing boundary | Preserve current failure behavior. Do not replace errors with a successful fallback or omit rows |
| Locked toolchain preservation | Same configured interpreter/helper paths and unchanged lock verification, YAML dependency and installed graph checks; record executable/version/environment for parity and timing runs | `-S` must not become a toolchain-verification waiver or global launcher change |
| Measured speed, CS07 | Bounded same-environment before/after raw observation of the same executive case/inputs, parser call/request counts and outputs; report actual wall/subprocess change and observer overhead | Diagnostic evidence only. Do not set a new timing threshold or promise campaign success from a one-case result |
| Full current acceptance, AC05/11 | Affected parity and executive suites, existing permanent failure/cap/accounting/cleanup coverage as relevant, exact-source Basic/full native/security/RI/owning checks, four source-bound completed roles | Required on actual changed candidate; partial diagnostic pass cannot supply this gate |
| Stable staging and AC09/10 | Existing full controller route, exact stable source/artifact binding, actual R10 reader and five-page PDF verification, then STOP/show | Prior source failure blocks advancement until replaced by successful current correction evidence; no PR170 merge or production |

## Risks, limits and next action

The route condition must inspect all requests; neither `some(html)` nor first-request selection is safe because YAML needs its normal dependency startup. Preserve empty-batch handling and invalid-input failure boundaries. No performance cache, batching omission, parser substitution, special accepted fixture result or weakened refusal is authorized. The all-HTML change belongs solely in helperContracts; mixed and nonHTML behavior stays on its original interpreter invocation.

The smallest next step is a bounded same-helper parity/timing diagnostic under the locked environment, followed by this focused invocation change if parity and effect support it. Preserve exact source/dirty state, interpreter identity, input/output digest and raw observations. Add meaningful routing/error parity assertions to the existing permanent suite. Re-review the actual delta and independently verify those assertions; this reviewer has authored only findings/treatments, not accepted tests or implementation. No new requirement or oracle meaning is approved, and provider context/model internals remain unknown.
