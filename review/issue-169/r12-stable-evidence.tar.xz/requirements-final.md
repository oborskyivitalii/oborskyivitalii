# Requirements & Acceptance — accepted R12 material/stable delta

Verdict: **PASS for the affected candidate requirements and proposed existing full-stable route.** No blocking material/source/phase defect found. This permits continuing the authorized current checks/Ready/full stable process subject to all required results; it does not establish that those checks or live stable staging passed. Stop after verified stable staging and show the result; no merge, production or platform revision/posting authority follows.

Same-role affected-candidate continuation `/root/r12_requirements_clean`, not a new clean-context claim. Own unchanged paper findings reused only after source-byte comparisons. No peer result, MEMORY content or excluded mixed parent rationale read. The allowed material review record's claims about prior other-role observations were treated as candidate claims, not independently adopted judgments. Provider/context internals remain unknown as earlier qualified. No implementation/test edits, broad test campaign, external writes or delegation; only this assigned output written.

## Identities and actual observations

Packet SHA256 `8d2918a37f8f691d12afdbcc7bf7717d0bc98171c864cdf276e6401a7902e2fe` verified; **every file digest listed in this packet matched**. Actual HEAD `0595f5f9dbef22c16e33da8dfb58e09782d9a2f5`, tree `0d4416dad63b49ba2cc1ff9ea401d7cef02c1bb6`, clean worktree. Prior accepted displayed source754c22a5bc7c641bc6a9f899dc3e2a2806780809; actual base/main allocation a9f576918defbed3950c8ab95b4161be26e56ade. Scope digest `ee81433f56afd467ed42eb2b8fbcf43f74e88bda04fad5def2bada6a8600ab30`. Common/role contracts retain their prior verified identities.

Material review record names actual author decision PR186 comment6762654946, exact displayed source/tree/preview, R12 edition/semantic/manuscript/PDF identity and the new full-stable-then-STOP boundary. Approval uses recording time2026-11-10T08:30:22Z and evidence SHA256 `6e01e9e5603b20c079272b8453ef8d10e81bbc4543911aedba73d7bfd96611b5`. I independently evaluated the actual existing producer's `reviewBinding`: computed `1ce2cc79f0c0f50b90bac9c8574ec6f95a70ffe0431f62ddfb953d629a64240a` equals declared approval. The record is consistent with the supplied primary author decision; I did not independently fetch the external comment in this bounded review.

Current generated article has the labelled native PDF anchor. Generated immutable PDF is byte-identical to accepted source PDF, SHA256 `c3686dce007b399d3fb175d5b235a51b1000500a3e4bc6f024be9767bfb33996`,516886bytes; prior five-page/font/content observations remain applicable. Markdown, profile and source PDF independently compare byte-identical to754c22a5. The semantic paper and visual research were therefore not re-audited.

All prior retained-manifest entries and their actual file hashes remain unchanged. New prior-preview article/Writing snapshot entries retain the exact pre-approval snapshot identities; historical R11 closure is preserved. Existing material/public/RI budgets remain requirements; this review checks selected PDF under2MB but does not substitute a fresh whole-candidate RI/public-budget execution.

EDITORIAL and HISTORY now explicitly record accepted R12 article/PDF, current checks/Ready/full stable then STOP. COPY continues to defer platforms until website publication. Original full issue gates remain separate. The retained historical DELIVERY/TECHNICAL release descriptions do not override the explicit current phase or authorize merge/production. No new engine/workflow/fixture guard is introduced in this material delta; supplied browser/material/history owners have no diff from754c22a5.

## AC and complete-diff allocation

| AC / obligation | Check / owner gate | Observed result or remaining gate |
| --- | --- | --- |
|AC07/08/09 accepted exact article/PDF|Author record and actual byte identity|Source/PDF/profile unchanged; exact material binding/evidence passes bounded inspection|
|AC09 native PDF availability|Existing material source/stale-binding tests; native/hosted reader→PDF|Generated labelled anchor and exact generated PDF verified; live desktop/mobile/no-JS download observation pending|
|AC05/09 history/rights|Retained manifest plus actual bytes; edition-retention/release-rights owners|All old retained bytes preserved; current producer/source checks remain required|
|AC04/05/06/11 phase|Issue acceptance policy and actual current-source Ready/stable results|Policy correct; stable live observations pending|
|AC05/11 full-main impact|Complete81-file main→candidate stat, profile/staging contracts; registry/controller selection|Conservative full route required; inherited archive/RI/CONTRIBUTING/policy changes included, not hidden by material-only delta|
|AC10 related/Writing journey|Existing hosted normal/mobile/no-JS and full staging jobs|Applicable existing checks remain required; no new matrix/engine needed|

The complete diff includes issue184 archive policy/inventory and historical HTML, RI/CI maps, CONTRIBUTING, rights/retained sources and generated site outputs. Thus parent79a275d→candidate alone is insufficient for test-impact selection. Existing full route correctly covers source/Basic, RI/coupling/style/owning-policy, publisher/material/retention/rights/archive, security and hosted platform/article/reader journeys with original budgets. The supplied stat establishes breadth, not actual selector execution or successful jobs. A source-bound complete selection receipt must retain each required, reusable or deferred disposition before broad staging; no additional test implementation is required by the unchanged oracles observed here. Existing material tests expressly cover null/private omission, selected approval identity, source/file/label/evidence staleness and unsafe/bounded targets. These remain appropriate independent failure oracles.

Native-check-allocation.md retains explicit historical R9/R10/R11 decisions. Those dated paragraphs must stay attributed to their editions rather than be read as new production/platform authority. Current scope and updated issue policy select R12 full stable STOP. PR185 remains an included unmerged dependency, requiring neither a separate stage nor implicit merge.

Next: collect applicable complete current-source checks and four actual affected-role results, then actual single full stable run with exact source/public/package/served bindings. Verify normal/mobile/no-JS reader and accepted PDF at stable, show the result and stop. Missing/failed/skipped/stale evidence remains pending regardless of this Requirements pass.
