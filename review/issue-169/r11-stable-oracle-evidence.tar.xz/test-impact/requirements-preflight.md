# Requirements & Acceptance — first preflight

**Verdict: PASS for dependent implementation within the proposed scope. No blocking requirement defect found. This is not a completed TP01–TP04, readiness, native CI or stable-staging acceptance.**

## Identity, independence and limits

- Role: independent nonauthor Requirements & Acceptance; first judgment before peer reconciliation.
- Repository: `oborskyivitalii/oborskyivitalii`, local clean HEAD `c8e0c3713b4e0eaf046efda0c10d6351ca11ff8a`, tree `edecd51c0c5e7402c97cdfff352d1400017ccb52`.
- Prepared correction base: `e75cbf0c2d5ae8f62c4444ff5fac1c8add0070d9`.
- Packet SHA-256: `5dd77066162f532d3fbbc8aeffef4410b311daeb8f23f1e2cea6b8476305da13`; all 14 supplied source-manifest hashes matched inspected bytes.
- Explicitly dated issue snapshot: `issue169.json`, updated 2026-11-07T10:09:36Z, SHA-256 `58b9b32dc50129ce4de1e7e8ea3334e190ba25937d2a515451819931643faf14`.
- PR snapshot: `pr170.json`, Draft, head e75cbf0, base096ed26, SHA-256 `6e8159dcaa6591f01fc5b748ccd5546200fa422e9f1c0e1d1e90ff0531e03d7a`. It predates prepared c8; it is scope/state evidence, not proof of c8 native execution.
- Launch task states actual `fork_turns="none"`; this reviewer did not inspect parent scratch notes, current peer outputs or private history. Shared platform/account/filesystem context is not isolation attestation. Provider-internal model/context injection and parent-side launch receipt are not independently observable here; orchestrator must retain the actual accepted launch receipt.
- Read root AGENTS, CONTRIBUTING, reviewer common/role contracts, README, REPOSITORY-MAP, MEMORY as dated handoff, acceptance policy, CODE-STYLE, test-profile/staging/release owners, actual test/workflow/selector/registry sources and relevant Git diff/history. No nested AGENTS was found in the supplied repository inventory.
- No implementation changes, external writes, recursive delegation, full suite or deployment. Only this assigned artifact is written.

## Requirement assessment and examined risks

The original user intent in the packet is clear and feasible: prevent predictable stale-test failures by reviewing all affected tests and their execution routes before advancing, while preserving independently justified historical/negative contracts. This does not authorize test rewriting merely because a current implementation differs. The proposal uses existing owners and review records; no additional pipeline, validator or infrastructure is needed.

Original issue AC05 requires source identity, repository checks and four completed distinct roles before readiness. AC11 requires explicit actual responsibilities/executions and author decisions. TP01–TP04 are bounded subcriteria of those obligations, not replacement acceptance or authority to close the article issue. The PR scope explicitly stops after full stable staging and reader/PDF inspection. Earlier broad publication instructions do not override this current narrower stop boundary.

No material requirement conflict or missing owner decision was found for implementing the proposed protocol and reusing the prepared c8 correction. The following are implementation obligations, not demonstrated passes:

1. Place the mandatory audit in the common pre-advancement route, not solely issue-completion guidance. Cover Ready/workflow/stage advancement and refresh when a relevant base, head, contract, oracle or selection route changes. A justified no-change disposition must remain valid.
2. Audit the complete current PR behavior/dependency delta against the current base, including base-side deletions/renames, producers/consumers, profile selection and hosted/production-admission dependencies. The narrow e75→c8 test diff is insufficient to establish TP01 for the whole publication candidate.
3. Record independent intended behavior and contract provenance before modifying an assertion. Distinguish obsolete tests, intentionally retained historical fixtures, diagnostics and unchanged reusable evidence; missing required updates block advancement.
4. Keep affected cheap checks before expensive staging, without treating them as a replacement for current full native/source/hosted/security/performance gates.
5. Retain failed runs and exact-source attribution. A protocol document, new review receipt or updated oracle cannot establish final native success, actual stable serving, editorial/platform publication or whole-issue completion.

## Independent c8 oracle inspection

`tests/prototype-admission.test.cjs:328–386` now distinguishes three separate invariants:

- Draft source/RI admission remains deferred.
- Prototype article-preview selection permits PR79 and PR170.
- Bounded Draft browser smoke remains PR79-only.

This distinction matches actual `.github/workflows/site-color-review.yml:219,464–475`. Git history independently locates the article-selection extension in `56f4bf90a0b77d180c2e662501c2c87092c08319`; e75 inherited it before c8 changed the test. c8 does not change workflow bytes. The supplied accepted scope requires the reviewed PR170 preview and preserves legitimate PR79-specific restrictions. Updating the article-selection oracle therefore repairs the asserted contract without widening runtime/admission behavior or deleting the PR79 smoke restriction.

The added evaluation covers prototype=true/false with PR79, PR170, another PR73, empty and missing number. Expected outputs are explicit, separate from the expression result; the exact-expression assertion constrains which workflow expression is evaluated. This is meaningful bounded positive/negative source-contract coverage. It is not GitHub expression-engine execution or hosted browser proof. No claim about arbitrary malformed GitHub inputs is necessary because the actual target producer supplies string outputs.

The permanent registry row includes this test, the staging flow/admission owners and all three workflow inputs, with pr-targeted/staging/production routes. No new suite or lifecycle is needed for these added cases. Existing meaningful wrong-source/stale/failed/current-main/tree admission tests remain untouched.

Actual bounded check:

`node --test --test-name-pattern='Draft admission stays deferred' tests/prototype-admission.test.cjs`

Observed on c8: exit0; 1 test, 1 pass, 0 fail/cancel/skip/TODO; ~96ms overall. This executes only the changed contract case and supplies no full-module or full-campaign acceptance.

## Traceability and current acceptance state

| Intent / criterion | Required check or owner gate | Independently observed state |
| --- | --- | --- |
| TP01: full changed behavior and dependencies mapped | Owning versioned audit: exact base/head; behavior/risk → oracle → suite/profile/workflow/job → disposition/result, including hosted and production admission | Proposal specifies this; full audit not yet implemented or accepted in this preflight |
| TP02: PR79/170 discrepancy corrected with restrictions retained | Actual workflow source/history; changed positive/negative test; unchanged admission/smoke restrictions; affected module/full native checks later | Source/oracle alignment verified; changed case passes1/1 locally; remaining module/native gates pending |
| TP03: common mandatory pre-advancement review and refresh | CONTRIBUTING canonical requirement, AGENTS route and check-profile allocation guidance; independent final review of actual edited owners | Existing guides presently emphasize QA findings and issue completion; proposed extension is necessary and authorized; implementation pending |
| TP04: affected local checks/four roles/native/full staging/STOP | Current exact-source local results, four completed nonauthor role receipts, latest native required checks, owner-triggered full stable stage and actual reader/PDF observation | Only this Requirements first preflight and one bounded case observed; all later gates remain pending |
| Original AC05 / AC11 | Policy maps CURRENT-RI/RI-CI/STYLE plus explicit INDEPENDENT/DELIVERY and related external gates | Mapping preserves semantic limits; deterministic checks do not prove agent execution; whole criteria remain open |
| Publication boundary / AC09–10 affected delivery | Exact accepted R11 assets and served reader/PDF, applicable desktop/mobile/no-JS/history/material checks | Not observed here; no merge, production or platform publication authority supplied |

## Next gate

Proceed with the read-only full test-impact audit and concise canonical protocol edits, using independently sourced oracles and the unchanged gate/budget constraints. Before any advancement, review the completed exact candidate (including material requirement/oracle changes), reconcile four role results and all required checks. Revalidate mutable Git/GitHub refs and live readiness then; the explicitly dated snapshots here cannot supply that later freshness.

**Blocking findings: none for dependent implementation. Pending acceptance remains pending; this preflight cannot mark TP01–TP04 or original whole article AC05/AC11 complete.**
