# Independent White-box QA — first result

2026-11-07. Role execution `/root/test_route_whitebox`; nonauthor, first judgment. Explicit source packet and role supplied by orchestrator; requested none-fork context is recorded by the orchestrator's actual launch receipt. Provider context/model internals are unknown. No peer result, parent scratch note or private history was read; no delegation, implementation, external write or stage was performed. Only this assigned output artifact is written.

## Verdict and scope

**c8's PR79/170 oracle correction passes the bounded white-box review. No further blocking executable stale-test assumption was found in the inspected main-to-candidate dependency/test routes.** This is preparation evidence, not complete TP01–TP04 acceptance or permission to advance: TP03's proposed permanent protocol edit was absent from the original c8 snapshot and needs its own delta review; exact final-source native checks and actual stable reader/PDF observations remain pending.

Pinned Git identities: main `096ed26abb018a52864d9f6fcea91e62731857d6`; prior publication `e75cbf0c2d5ae8f62c4444ff5fac1c8add0070d9`; candidate `c8e0c3713b4e0eaf046efda0c10d6351ca11ff8a`, tree `edecd51c0c5e7402c97cdfff352d1400017ccb52`. Packet SHA-256 `5dd77066162f532d3fbbc8aeffef4410b311daeb8f23f1e2cea6b8476305da13` matches the supplied bytes. Issue169/PR170 JSON are supplied primary snapshots, not freshly authenticated live GitHub observations.

Read root AGENTS, README, CONTRIBUTING, MEMORY (handoff only), REPOSITORY-MAP, reviewer common/role contracts, site source contract, check profiles, affected registry/selector, workflow consumers and changed active implementation/test sources. Only root AGENTS exists. Used complete `main...HEAD` path inventory, active executable/test/workflow direct-input inventory, relevant actual diffs and current generated article descriptors. This review checks affected test/oracle allocation; it does not replace the separate code review or claim exhaustive semantic review of every archival byte.

Shared-tree chronology: initially clean c8. At final read, AGENTS, CONTRIBUTING and SITE-CHECK-PROFILES were dirty due to concurrent author work. Those new protocol bytes are outside this first judgment; no current peer files were inspected. Tested executable/workflow/registry bytes below still match packet/c8. Initial AGENTS/CONTRIBUTING/check-profile identities are exactly the packet entries. Later protocol changes require delta review before relying on this result.

## Finding

**WB01 — Low, stale budget explanation**, `tools/quality/source-test-worker.cjs:14`: comment says “original 300-second deadline” while actual `source-tests.cjs::executionLimits.timeoutMs` is 600000 and current Ready shard workflow explicitly names 600 seconds. Mechanism: future impact audits could misclassify a legitimate historical failure/budget as current policy. TP01/TP03 clarity is affected; actual runtime still uses the current 600-second bound. Treatment: refresh the comment to current budget ownership, retaining historical 300-second observations as dated history. No budget change or full rerun is needed for this prose correction.

## Risk → structure → scenario → oracle → check

| TP/risk | Structural fault / scenario | Independent expected contract | Existing owner and actual observation |
| --- | --- | --- | --- |
| TP02 Draft selection | PR170 selected as ordinary Draft, PR79 retained, unrelated/missing PR excluded; non-Draft may not imply preview | Packet author-approved Draft article preview; source/RI admission remains deferred; smoke/diagnostics remain their existing allocation | `prototype-admission.test.cjs`:13/13 pass, including 2×5 actual expression truth table and exact workflow string |
| TP01 registry completeness | New tests, removed tests, wrong lifecycle, baseline duplication | Every actual module registered; permanent staging/production, diagnostic explicit/changed-helper, numeric snapshot owning-only | Registry validation pass; targeted selection/inventory tests9/9 |
| TP01 shard integrity | Missing/extra/substituted modules, omitted/failed matrix, incoherent empty receipts | Eight exact partitions with current source/raw TAP; empty means inapplicable, never passed | Existing bounded shard/Basic/empty negative tests selected and passed; no native shard campaign run |
| TP01 current PDF | Old R10/other filename, wrong path/host/hash/MIME/HTTP status or omitted material | Current accepted R11 material binding and ordinary native PDF anchor; external posting separate | Current descriptor derives `reading-r11.pdf` digest568c87…; article browser evidence tests pass including all capability rows and rejected substitutions |
| TP01 hosted allocation | Fixture/print branch accidentally confused with current article coverage | Existing PR79-only synthetic content/managed-print diagnostic is separate from admitted current article journeys | `site-color-review.yml`521/543 passes content_fixture only for79; staging collector independently consumes manifest article and validators require five capability observations |
| TP01 history/route lifecycle | Lost Back focus/scroll; stale retarget completion; footer box not animated; stale ink identity | Site contract: native geometry/history and complete route box lifecycle, preserved cancellation/fallback | navigation + scroll-entry + tags + offline modules128/128 pass; browser is still separate |
| TP01/Pillow/browser | Isolated browser job lacks media interpreter or wrong browser package | Canonical media action installed in each actual fixture-building job; native supply checks remain distinct | Targeted quality workflow/media/current-source tests3/3 pass; actual hosted startup not executed |
| TP01 functional/performance | Collection error masked by missing article, wrong runtime, ignored cleanup, changed budgets | Original error remains primary; exact bounded hosted matrix and failures preserved | staging-regression and article/material suite batch50/50 pass; synthetic fixture execution, no real performance measurements |
| TP01 distribution/material rights | Premature canonical/backlinks, unobserved reciprocal platform, invalid selected file | Planned destinations stay planned; site-first paired observed links and immutable review-bound file | article-materials negatives pass; registry routes publisher/profile/material changes to existing tests |
| TP01 staging→production | Current producer accepted by an incompatible controller; historical fixture mistaken current acceptance | Exact source/tree/controller and frozen archive/right/index/package proof; no reuse by merely renaming source | reader-controller current/pinned closure source inspected; source registry retains staging/production route. Cross-checkout/native runtime not re-executed here |
| TP03/TP04 advancement | Complete article/controller delta audited only after an expensive stage failure | Accepted proposal requires final pre-advancement impact record plus unchanged rationale and affected local/native gates | Protocol delta not judged here; all hosted/full native acceptance remains pending |

## Complete inventory allocation and dispositions

Registry runtime validation inventories **127 modules:88 permanent (78 JavaScript,10 Python),18 diagnostic and21 task snapshots**. Actual source selection on pinned full main→c8 delta returns80 additional PR JavaScript modules (75 nonbaseline permanent plus5 changed-helper diagnostics),75 staging additional modules,78 production modules. The three Basic baseline modules are theme/archive/flight. The full delta is not eligible for a content-only or repository-only shortcut. No source case was deleted or reclassified by c8; its diff changes only prototype test assertions/import/title/truth-table.

An independent direct-input scan covered **all80 changed active executable/test/workflow paths** under tools/site/tests/workflows, excluding retained frozen runtime copies; every path has a non-task registry input consumer. This establishes allocation coverage, not executed branch coverage or proof that every assertion is sufficient. Reviewed families and dispositions:

- Engine navigation/archive/article-tags/scroll-entry/flight: current route, history, deferred media, tags, block-motion and stale-callback cases remain selected. Current source-specific tests extend prior expectations; historical engine whitelists and old receipt negatives remain legitimate.
- Build/articles/HTML/fallback/offline/render-records/validate-catalog/previews/runtime compatibility: catalog semantics, native undated year handling, selected JPEG/PDF resources, exact offline closure and retained frozen client identity remain existing source/size/security consumers; no wholesale revision replacement.
- Publishing profile/kit/events and article-materials: changed planned-link/site-first semantics have actual positive/negative cases and registry routes. Historical observed edition IDs remain publication facts, not current rendering requirements.
- Edition-retention/Color/production edition/rights: declared immutable closures and reachable frozen dependencies remain current producer/controller/rights/archive tests; staging noindex and production historical retention differ intentionally.
- Source sharding/worker/workflow-artifacts/quality workflows: current600s process bound,20-minute enclosing build and eight Ready source partitions remain. A 300s string in the old-failure explanation of shard introduction is legitimate history; WB01 worker description is misleading current prose.
- Media/fixture/parser/browser: canonical interpreter action is present in actual full staging and production browser consumers; copied content fixture includes web-media requirement dependency. HTML-only `-S` is a stdlib parser optimization with parity/refusal test; mixed/nonHTML retains ordinary startup.
- Source-bound security ledgers/scanner exact checksum tuples: registry/source/advisory gates remain selected. Ledger refreshes cannot establish a hosted pass, and this review did not independently rerun expensive scanners.
- RI/style/coupling/owning Python: ten enduring Python modules remain registered; numerical issue snapshots are intentionally issue-policy-only. Additional changed historical/manual diagnostics are not promoted into routine stage/production.

### PR79 and fixed-revision distinctions

`SITE_ARTICLE_PREVIEW` build selection at Color workflow219 already intentionally admitted79/170 before c8. The test still expected79 only. c8 therefore repairs a stale oracle against independent accepted scope; it does not broaden the workflow or admission.

The remaining workflow79 guards at smoke465/470/475, fixture478/481, managed print484 and `content_fixture`521/543 are legitimate dedicated issue5/pmday diagnostic allocation. They do not select the real staged R11 reader. Full Ready/staging takes `staging-regression.cjs::collectFunctional` → `article-browser.cjs::articleJourney` using current manifest descriptors. Current docs contain exactly `sdlc-out-of-balance:en`, so the representative is R11, not pmday/reference. The manifest includes current PDF568c87… and all five current image assets. Old figure filenames such as asymmetry-r9 are content-preservation facts; renaming them merely for R11 would be wrong.

`article-print.cjs pmday-two-shifts` exports a separate authoring diagnostic, not current R11 PDF acceptance. Current R11 native served download is checked by `observeMaterials/downloadLinks` for exact URL,200,no redirect,hash,label,MIME across all five capability observations. The five-page source PDF's author visual acceptance is independent and not recreated by synthetic tests.

`reader-controller` retained old receipts explicitly label their old source; current generated controller case imports actual current sources, can pin an external controller, and rejects missing/wrong controller SHA/dirty external checkout. No hardcoded R9/R10 manuscript or PDF is used as the current hosted R11 oracle in the inspected routine consumer paths. Manual `site-navigation-probe.yml` explicitly remains issue169 R9 diagnostic, excluded from current hosted admission; its failure on a new revision would not justify changing normal gate semantics.

## Executed checks and raw accounting

Executor Node v24.22.1 (native workflow pins24.19.0); no toolchain/browser install, full source suite, native CI, full staging, production or external mutation performed. Commands were read-only except ordinary tests' isolated temporary fixtures.

1. `node --test tests/prototype-admission.test.cjs`: exit0;13 tests,13 pass,0 fail/cancel/skip/TODO; duration115.864826ms.
2. `node --test tests/article-browser-evidence.test.cjs tests/staging-regression.test.cjs tests/article-materials.test.cjs`: exit0;50 tests,50 pass,0 fail/cancel/skip/TODO; duration854.267153ms. Included current PDF wrong URL/host/hash/MIME/302/404 negatives, historical engine compatibility, cancellation/failure/cleanup and site-first reciprocal-material negatives.
3. `node --test --test-name-pattern='registry covers|production keeps|PR selection targets|reader and delivery owner|bounded source shard|required Basic source|empty PR shard|reader oracle|distribution guides' tests/test-profile-selection.test.cjs`: exit0;9 selected tests,9 pass,0 fail/cancel/skip/TODO; duration324.84368ms. Name filtering is intentional bounded allocation, not full module pass.
4. `node --test --test-name-pattern='every fixture-building|workflow selects|full hosted evidence' tests/quality.test.cjs`: exit0;3 selected tests,3 pass,0 fail/cancel/skip/TODO; duration1171.588458ms.
5. `node --test tests/navigation.test.cjs tests/scroll-entry.test.cjs tests/article-tags.test.cjs tests/article-offline.test.cjs`: exit0;128 tests,128 pass,0 fail/cancel/skip/TODO; duration13152.429888ms. Includes history retarget/native source fallback/route box/standalone PDF/JPEG/tag cancellation branches.
6. Inline actual registry validation and `select` for pinned full main→c8 PR/staging/production: exit0, counts80/75/78; no test execution falsely inferred from the plan. Inline direct-input scan: exit0,80 active executable/workflow/test paths, zero unmapped paths.

**Total executed selected cases203/203**, zero failed/cancelled/skipped/TODO. Tests' own retained fault injections were executed; no implementation/test mutation was authored by this reviewer. No coverage instrumentation was run, therefore no branch/statement coverage percentage is claimed. Full test accounting above derives from returned command output; raw tool execution chunks remain the primary receipts.

## Limits / remaining gates

TP01 has a useful source-bound impact audit and cheap checks, with no additional blocking stale routine oracle found. TP02 is locally observed. TP03 requires the forthcoming final protocol delta review. TP04 is only local preparation: native required jobs, independent four-role final-source review reconciliation, actual owner full stable stage, exact hosted reader/PDF inspection and STOP are still required. Current supplied issue/PR state may change; no live GitHub API refresh was performed by this reviewer. No merge, production, paid infrastructure or gate/budget reduction is authorized.

Permanent controller integration, source security/advisories, exact browser package restoration, actual performance budgets, stable promotion and production admission were inspected as consumers but not executed here. No local synthetic result can substitute for them. Visual editorial PDF/mobile/device judgments remain with their existing owners.

## Exact source identities (SHA-256)

| Path | Inspected/tested bytes |
| --- | --- |
| `agents/reviewers/README.md` | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| `agents/reviewers/white-box-qa.md` | `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f` |
| `tests/prototype-admission.test.cjs` | `3b6cd86a1eeb7397496a2cbe5de5282314411ab5c750d09f25945e4f5129dcfa` |
| `.github/workflows/site-color-review.yml` | `5d7c93ebc901204a26418e32003c7f8869b5ed7c153a3acbb32ca66deaf45e3e` |
| `tools/quality/test-profiles.json` | `583d1dd469fc12adc2cf66628a6486e9d11e5eaa0d3e170b5fdf4fbf63085a36` |
| `tools/quality/source-tests.cjs` | `d9a870982b7ec3698696ce2192c0cfc25ae156785f9ab7cfaa3507c0fd2338cf` |
| `tools/quality/article-browser.cjs` | `71d4749d11c0163ccefb6ac12f0c1954a85da2ce17523ce793f7c24cae325fb3` |
| `tools/quality/source-test-shards.cjs` | `d22729bb252d0aac71f05dcd313beda4534babb93a7f2a8869894cf59b38969c` |
| `tools/quality/source-test-worker.cjs` | `b6d4b3909a564905bc4ab5a4ff626107ab5e4922c55008cd97da9c23bf81b9f5` |
| `tools/quality/staging-regression.cjs` | `2b4d7c56272eedc9a8cc9cc1a81df17ad58ee1bea2c136ca4c143f8533801497` |
| `.github/workflows/site-release-checks.yml` | `f05ce4a8fbc8bb93f540726d35b9acba344ec0dcb5a3c1b8dcb2ae58014a077d` |
| `.github/workflows/site-production.yml` | `6428be26a7400e14bb11c74afa8911ecff883d8f35ce0ef29721aaba2b787955` |
| `docs/site-revision.json` | `b80ff3523e691272d3c93a6a0c615e84fe08fc8da6aa896d5f07c62f068e784b` |
