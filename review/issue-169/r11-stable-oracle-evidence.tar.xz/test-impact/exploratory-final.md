# Independent Exploratory / Interaction QA — first judgment

Completed 2026-11-07T10:24:48Z. Role execution `/root/test_impact_exploratory`.

**Verdict:** no blocking defect found in the bounded changed operator surface. The corrected source test and the actual selector preserve the distinction between PR79/170 article selection and PR79-only bounded Draft browser smoke. The new protocol gives an operator a usable route for reviewing the complete change before advancement, retaining correct tests, diagnosing failures and refreshing changed allocations. This is a scoped preparation result, not Ready/native/staging/reader/PDF acceptance.

This is my original first judgment, before peer reconciliation. I did not implement source/tests, invoke hosted workflows, write externally, delegate, run a full suite or run staging.

## Inputs, source binding and assurance

- Repository: `/workspace/scratch/a6215a1720e5/repo`; owner issue169, publication PR170. Local HEAD `c8e0c3713b4e0eaf046efda0c10d6351ca11ff8a`, incremental base `e75cbf0c2d5ae8f62c4444ff5fac1c8add0070d9`; local protected-main reference `096ed26abb018a52864d9f6fcea91e62731857d6` is their verified merge base. Working tree is dirty. This is a prepared byte-bound candidate, not a clean native checkout.
- Packet `/workspace/scratch/a6215a1720e5/evidence/final-packet.json`: SHA256 `215dfe2cf800b2d02eac45d02efd9a46bd9ca7671e183acccebd6bc7efdba15c`.
- Actual supplied `/workspace/scratch/a6215a1720e5/evidence/final.delta.diff`: SHA256 `dade4e034d709399a6b883f3b5ef1c012205a042573ae957638bb8387d0e6775`. Inspected all five changed paths: AGENTS, CONTRIBUTING, check-profile guide, prototype admission test, worker comment. Also compared the actual incremental worktree diff and verified no incremental site/docs/staging/workflow delta.
- Common contract `agents/reviewers/README.md`: SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role `agents/reviewers/exploratory-interaction-qa.md`: SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- All 15 packet manifest paths matched their supplied hashes at initial and final inspection. RI/history metadata changed concurrently; none of those frozen manifest inputs changed. No pass is claimed for later metadata checks.
- Original issue snapshot `evidence/issue169.json`: SHA256 `58b9b32dc50129ce4de1e7e8ea3334e190ba25937d2a515451819931643faf14`; PR snapshot `evidence/pr170.json`: SHA256 `6e8159dcaa6591f01fc5b748ccd5546200fa422e9f1c0e1d1e90ff0531e03d7a`. Inspected original issue intent/ACs and PR execution scope. The issue snapshot's `comments` field is a count, not comment bodies; the packet supplies the Nov7 test-impact amendment. I did not independently observe current remote GitHub state or that comment's full original text.
- Read root AGENTS/README/CONTRIBUTING, repository-map owner routes, relevant profile/registry/source CLI/workflow/staging/release owners. No nested AGENTS was present in the relevant supplied inventory.
- **Exposure disclosure:** root AGENTS requires tracked MEMORY reading, so I read current tracked MEMORY and saw authored summaries/local pass claims. I reported this before judgment and treated those claims as candidate material, not evidence. No parent scratch notes, current peer result files or private history were read. The orchestrator clarified that related tracked candidate MEMORY is permitted source; this clarification did not supply a verdict. The supplied original issue/PR snapshots themselves contain historical review claims, also not relied upon.
- Launch task reports explicit `fork_turns="none"`; I cannot independently inspect the parent's accepted launch response. Provider model/context/memory internals remain unknown. No provider isolation attestation is made.
- Environment observed: Linux 6.18.57 x86_64, Node v24.22.1 at `/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node`. This differs from workflow-pinned Node24.19.0. Managed-environment status tool was not exposed; no environment readiness claim follows.

## Independently selected charter

Bound: twelve operator action groups, approximately fifteen minutes, source reads plus cheap local CLI/test interactions. No source edits or full/expensive campaigns. The relevant incremental surfaces are prompt/protocol navigation and the source-selection/workflow-expression contract. Browser/UI behavior is unchanged in this delta; actual full stable reader/PDF interaction remains a later required gate, not an inapplicable task.

Explore whether an operator can: (1) find the mandatory test-impact route without author chat; (2) distinguish accepted intent from implementation/test agreement; (3) preserve historical/negative/no-change cases; (4) determine PR/staging/production allocation using the real CLI; (5) distinguish Draft article selection from browser admission; and (6) fail safely on dirty source/invalid requests without accidentally launching the full suite or writing a plan as execution evidence.

## Actions, expectations and observations

| Action | Independent expectation | Observed result / evidence |
| --- | --- | --- |
| 1. Follow AGENTS step11 → CONTRIBUTING pre-advancement → profile allocation → QA allocation | Find inputs, output owner and next gate without chat | Executed/pass. `AGENTS.md:57`, `CONTRIBUTING.md:97`, `guides/SITE-CHECK-PROFILES.md:31` and `:369` route to existing owning review, complete PR/base diff, AC/oracle/dependencies, dispositions, exact evidence and four roles. |
| 2. Tabletop unchanged historical fixture, obsolete assertion, unresolved intent and changed head | Correct unchanged tests may stay; obsolete expectation needs independent oracle; ambiguity/blockers halt advancement; changed inputs refresh affected allocation | Executed/pass as operator reading, not runtime enforcement. CONTRIBUTING prohibits rewriting to implementation/weakening guards and explicitly retains justified unchanged/historical/diagnostic coverage. Relevant base/head/behavior/dependency/oracle/selection changes require refresh. |
| 3. Read actual workflow, unchanged against e75 | Article preview and Draft browser exceptions are separate contracts | Executed/pass. `site-color-review.yml:219` admits article selection for prototype79/170. `:465/:470/:475` keep bounded Draft browser work79-only; `:521/:543` keep synthetic content fixture79-only. No workflow change in incremental scope. |
| 4. Evaluate extracted actual article expression plus the actual smoke condition over ten string-output combinations | Prototype79/170 select articles; prototype170 does not gain Draft smoke; Ready always disables preview selection and retains normal smoke | Executed/pass, ten rows below. VM evaluation is bounded local expression evidence, not GitHub Actions execution. |
| 5. Run `node --test tests/prototype-admission.test.cjs` | Corrected positive/negative cases pass with complete accounting; existing admission refusals remain | Executed/pass:13 tests,13 pass,0 fail/cancelled/skipped/todo; duration144.967518ms. Tests include stale/missing/skipped/forked/failed admission, latest attempt/tree and source-refresh refusal boundaries. Local Node24.22.1 only. |
| 6. PR CLI `--profile pr --base e75… --head c8… --plan` | Corrected module remains selected, plan cannot claim execution | Executed/pass: exit0,75 additional modules, includes prototype admission; three delegated Basic files; status planned/pass null. Unknown retained evidence archive conservatively selects full permanent additions. This commit plan does not include dirty protocol changes. |
| 7. Full PR/base CLI `--profile pr --base 096ed26… --head c8… --plan` | Full delta must retain wider obligations than the last correction | Executed/pass: exit0,80 additional modules,1013 changed paths,518 conservative fallback paths, includes prototype admission, platform classification; three delegated Basic files; planned/pass null. First tool response was output-truncated; a bounded second read-only planning invocation returned a compact complete summary. No test campaign was retried. |
| 8. Staging CLI `--profile staging --plan` | Permanent corrected module stays in staging | Executed/pass:75 additional modules plus three delegated Basic files, includes prototype admission, planned/pass null. No source suite executed. |
| 9. Production CLI `--profile production --plan` | Permanent corrected module survives in complete production source registry; does not authorize production | Executed/pass:78 modules, no delegated baseline, includes prototype admission, planned/pass null. This is source registry planning, distinct from production admission authenticating successful staging. |
| 10. Same incremental PR CLI with `--require-clean`, without `--plan` | Dirty candidate must refuse before any source campaign | Executed/pass expected refusal: exit1, `source tests require clean checkout`, listing dirty tracked files. Did not retry execution or weaken the guard. |
| 11. CLI `--profile unknown --plan` | Unsupported allocation must refuse | Executed/pass expected refusal: exit1, `unknown source profile unknown`. |
| 12. CLI `--profile pr --plan --report /tmp/exploratory-must-not-write.json` | A plan must not be persisted as execution proof | Executed/pass expected refusal: exit1, `--report requires execution, not --plan`; separate existence check returned false. |

The four CLI plan results are plans only. Full-base/head plan uses committed c8 bytes, not the dirty prepared protocol candidate. Final clean source selection/native evidence remains necessary after commit.

Actual expression matrix (`number` values are workflow output strings; missing is undefined):

| prototype | number | article preview | bounded/normal smoke condition |
| --- | --- | --- | --- |
| true |79 |true |true |
| true |170 |true |false |
| true |73 |false |false |
| true |empty |false |false |
| true |missing |false |false |
| false |79 |false |true |
| false |170 |false |true |
| false |73 |false |true |
| false |empty |false |true |
| false |missing |false |true |

## Findings and allocation

No changed-surface defect found. Risks examined: confusing article rendering selection with admission, broadening the PR79 synthetic diagnostic, changing tests merely to agree with implementation, losing unchanged/history refusal coverage, treating planning or dirty-source results as successful execution, and admitting a moved/failed source from old green evidence.

| Scenario / TP | Existing or proposed disposition | Suite/profile/workflow/job or manual owner |
| --- | --- | --- |
| PR79/170 positive article selection and nonselected other/missing PR; Draft deferral and PR79-only browser exception /TP02 | Reuse corrected test; executed locally13/13 | `tests/prototype-admission.test.cjs`, permanent; PR-targeted, staging, production registry row1725. Ready `site-checks.yml` source shards/aggregate; staging prepublication source allocation. No duplicate suite proposed. |
| Skipped/missing/failed/latest-attempt/tree admission /TP02/04 | Retain existing distinct negatives unchanged; executed in same13/13 | Same module; unchanged `review-flow.cjs`/`admission.cjs` owners. |
| Complete-delta selection versus incremental selection /TP01 | Retain actual source CLI/registry; planning observations only | `tools/quality/source-tests.cjs`, existing profile-selection owners and native source shard/aggregate route. |
| Upfront oracle/disposition/freshness operator walk /TP01/03 | Retain manual source-bound four-role review and existing owning artifact; no documentation-keyword test | CONTRIBUTING/profile QA allocation; orchestrator must refresh allocations on final source changes. This does not prove runtime enforcement of reviewer protocol. |
| Actual stable reader/PDF, mobile/no-JS/history/media/download /TP04 | Deferred required observation; not executed or waived here | Existing full owner `/stage`, source-bound native/full/stable gate, actual reader/PDF inspection, then STOP. No historical preview relabelled. |

## TP01–04 implications and limits

- **TP01:** this review confirms discoverability and meaningful retained PR/staging/production routes using actual selectors. It does not certify that every full PR change has a complete accepted disposition in the owning allocation; the orchestrator must reconcile the full current dirty candidate/base and remaining gates. No peer/author audit summary was substituted for that work.
- **TP02:** supported in this bounded scope: workflow expression unchanged, corrected module13/13, independent actual expression matrix, unchanged Draft/browser/fixture restrictions and existing refusal tests retained. Hosted Actions expression execution was not observed.
- **TP03:** supported by the actual operator walk: mandatory before Ready/new stage/promotion/handoff; explicit correct unchanged dispositions, independent intent/oracle, refresh and blocking treatment. Enforcement is a session responsibility; no new dispatcher was introduced or claimed.
- **TP04:** remains pending as a whole. This role contributes one completed bounded local result. Required final exact-source clean/native checks, other independent roles, current Ready admission, full owner staging and stable reader/PDF verification must complete on their actual sources. No PR170 merge/production/posting is authorized by this result.

No physical-device/usability/visual measurement was performed. No new UI browser test was appropriate to the incremental protocol/test/comment delta, while the original publication task's actual stable interaction gate remains required. Raw local commands/results are retained in this role's tool transcript; the table preserves selectors, exit/accounting, refusals and source limitations. Changed frozen source bytes require affected re-review.
