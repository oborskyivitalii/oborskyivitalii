# White-box QA — affected final review

Role `/root/test_route_whitebox`, 2026-11-07. This continues my preserved first judgment; it is not a fresh isolation claim. First artifact `/workspace/scratch/a6215a1720e5/evidence/whitebox-first.md`, SHA-256 `d95728d339a7813ce694689696f2f0ba2c9f7a7aed0530449e78d3372eb26989`, remains intact. Later inputs are the author's final delta/packet and owning allocation claims. Reading the owning artifact exposed its historical review summaries and Requirements preflight summary after my first judgment; these are candidate claims, not oracles or borrowed assurance. No current peer output files, author chat/private history or parent scratch were read. Provider internals remain unknown.

**Verdict: no blocking white-box finding in the final prepared protocol/test/comment delta. WB01 is resolved.** TP01/TP02 retain the first audit's bounded observations; TP03 now has the mandatory existing-owner workflow and adequate unchanged-test/evidence provisions. TP04 remains incomplete until exact final-head native checks, four-role reconciliation and actual full stable reader/PDF verification. This result does not authorize or establish staging, merge or production.

## Candidate identity

Base publication `e75cbf0c2d5ae8f62c4444ff5fac1c8add0070d9`; Git HEAD remains c8 `c8e0c3713b4e0eaf046efda0c10d6351ca11ff8a`, underlying tree `edecd51c0c5e7402c97cdfff352d1400017ccb52`, main `096ed26abb018a52864d9f6fcea91e62731857d6`. Final is a **prepared dirty candidate**, not that clean Git tree or a native pass.

Final packet SHA-256 `215dfe2cf800b2d02eac45d02efd9a46bd9ca7671e183acccebd6bc7efdba15c`; `final.delta.diff` SHA-256 `dade4e034d709399a6b883f3b5ef1c012205a042573ae957638bb8387d0e6775`. All15 referenced manifest file digests were independently recomputed and match. Owning allocation artifact, outside that15-entry manifest, independently bound as `review/issue-169/2026-11-07-r11-stable-staging.md` SHA-256 `a7f01d0d69c79a2a36fefcf7f48392f40a2fa62c3566bc4efe98c4b39036f5f4`.

| Final changed owner | SHA-256 |
| --- | --- |
| AGENTS.md | `31ef44be1936809de5690da0b505fba5cf600f62e9a33d34b9d90e806387ae4a` |
| CONTRIBUTING.md | `a175f65e207b653b323f81a7543bea5a80f1f49b8ab6c9666c63656727667f65` |
| guides/SITE-CHECK-PROFILES.md | `aea03f28069a9bc114800bd7d7e60af7bfc1411a4abc83e7b5d6b86b6bb57b57` |
| tools/quality/source-test-worker.cjs | `b6d4b3909a564905bc4ab5a4ff626107ab5e4922c55008cd97da9c23bf81b9f5` |
| tests/prototype-admission.test.cjs | `3b6cd86a1eeb7397496a2cbe5de5282314411ab5c750d09f25945e4f5129dcfa` |

## Affected re-review matrix

| Concern | Changed structure and independent expectation | Result / route |
| --- | --- | --- |
| Pre-advancement timing | CONTRIBUTING requires complete current PR/base impact review before Ready, new stage, promotion or handoff, including automatic-feedback distinction | Adequate TP03 requirement; AGENTS routes to actual anchor; no extra pipeline |
| Complete dependency closure | Both rename/delete endpoints, producers/consumers, fixture/environment/selection/evidence changes; source/hosted/staging/production allocation | Adequate TP01/TP03, source and hosted independent failure surfaces retained |
| Oracle authority | Accepted intent precedes tests; ambiguous behavior resolved first; no rewriting to agree with code or weakening refusals/budgets/scanners/gates | Adequate independent-oracle constraint; unchanged/historical/diagnostic dispositions expressly allowed |
| Freshness/reuse | Base/head/prepared manifest, affected refresh and byte identity for unchanged evidence | Adequate source binding; no requirement to rerun unaffected audits or invent tests for prose changes |
| Blocking behavior | Missing required updates/unresolved blockers stop advancement; cheap affected checks precede expensive stage, native/hosted remain | Adequate TP03/TP04 separation; review record does not claim final stage pass |
| Worker budget explanation | Replace false current300-second statement with current source-profile deadline | WB01 resolved; full-line-comment removal proves executable source equal to c8 |
| PR79/170 assertion | Same tested c8 bytes and unchanged workflow; Draft true/false×79/170/unrelated/missing/empty cases | Reuse own13/13 prototype execution; no additional test change or scope expansion |
| Owning allocation accuracy | Current module counts, manifest R11 representative/PDF, historical PR79 managed-print diagnostic distinction | Matches own first registry/consumer observations; claims of earlier local/native results remain attributed to their original refs |

## Actual checks and evidence reuse

No further full campaign was run. Reused **203/203 selected cases** from my first execution only after independently confirming unchanged test, workflow, registry, runner and browser consumer digests against the final packet/c8. The worker differs only in a full-line comment; Python removed full-line `//` comments from old/current worker strings and compared equal. This is textual executable-source equivalence, not a compiled-code proof.

New final-phase checks, all exit0:

- Independently recomputed packet/diff digests and all15 manifest rows; all matched.
- `git diff --check`: no whitespace diagnostics.
- AGENTS ≤100-line policy assertion passed.
- Actual changed-document source selections: AGENTS selects no additional JS and no conservative fallback; CONTRIBUTING selects publication-records/release-rights; SITE-CHECK-PROFILES selects delivery-observation, no fallback. These are plans, not test execution. The full mixed PR still selects80 additional PR /75 additional staging /78 production JS as first observed; its unchanged registry/selector bytes preserve those obligations.

No additional dynamic test is justified solely for the protocol prose/comment correction. Existing native source/RI/coupling/owning/security and final current-head admission remain required. The unchanged13/50/9/3/128 test batch accounting and Node24.22.1 vs pinned native24.19.0 distinction remain exactly as first reported; no synthetic result is relabeled a final-source native or real-browser pass.

## Remaining limits

The final prepared manifest/diff does not itself include later deterministic RI output, receipts, commit creation or remote checks. Verify those preserve reviewed meaning/bytes; relevant substantive changes require affected review. No live GitHub refresh, native workflow, current actual browser startup/performance/reader/PDF interaction, full stage, promotion, production-admission execution, paid service or external write occurred in this role.

Mandatory endpoint remains current-head native Ready source/navigation/owning acceptance → one authorized full owner stable stage → exact stable reader and served PDF verification → STOP/show. Whole issue acceptance and PR170 merge/production remain outside this review's completion claim.
