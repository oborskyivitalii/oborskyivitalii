# Independent Code diagnosis — native article tags after mounted Writing

Reviewer `/root/correction_code_clean`; same nonauthor correction-review execution. Local HEAD `3044b5cae6c95929267838751a9161262d589849`; worktree is dirty with post-C1 compatibility corrections and regenerated outputs. The inspected `site/engine` runtime owners remain unchanged from C1. The supplied hosted primary observation concerns preview `https://677969f9.oborskyi-author-ci-staging.pages.dev` and source short ref `b0e59ddd`; I did not operate that remote browser or independently bind its deployment receipt. No source edits, external writes, delegation or full campaign occurred.

## AC10 finding and corrected cause

**Blocking AC10 regression: tag enhancement indexes the canonical native alias but mounted Writing contains a pinned immutable article URL.** This is not a race caused by late history commit. In actual navigation source, the commit callback updates history before `mount`; `rebaseResources` also retains the correct pinned destination.

Primary Explorer facts supplied: direct Writing’s `ai-delivery` filter shows 8/30, including SDLC; article → mounted Writing shows 7/30 and SDLC has no `dataset.tags`, despite a correct settled native href. Independent source inspection explains exactly that pattern:

1. `tools/site/articles.cjs:394` intentionally rewrites article aliases to immutable snapshots inside principal immutable documents.
2. The actual C1 Writing alias links `articles/the-sdlc-is-out-of-balance.html`. Its verified Writing snapshot at `snapshots/692098d982e702276971275ef0dd72d7d43d6072fcfa38d44fd08c0a14540dbc/writing.html` links `../../article-snapshots/02a5f0e4d2d1f33915b052aab04d0373ab615372340b2d08b4817e47799a6684/the-sdlc-is-out-of-balance.html`.
3. Navigation reads that verified snapshot, resolves its resource URLs against the snapshot source, then rebases them for the mounted route. It correctly preserves the pinned article link.
4. `article-tags.cjs:245` builds its lookup only from canonical index URLs and calls `indexed.get(anchor.href)`. The immutable href has a different identity, so the local article never receives tags. External article URLs remain unchanged and still match. Archive filtering then treats the untagged row as outside every selected tag.

A read-only deterministic reproduction used the exact C1 Git blobs, not current regenerated bodies or fabricated documents. At both `/` and `/project/`: direct alias had 30 cards, 30 lookup matches and 8 AI-delivery rows; immutable Writing had 30 cards, 29 matches and 7 AI-delivery rows. The sole unmatched URL was the pinned SDLC article. This reproduces the primary observation without timing assumptions.

## Smallest robust treatment and verification hypothesis

Keep the canonical index schema and every actual link/navigation destination unchanged. In the tag owner’s metadata lookup, normalize only a same-origin URL under the exact project-root directory whose relative pathname matches `article-snapshots/<64 lowercase hex>/<bounded slug>.html`; map that lookup identity to the known canonical `articles/<slug>.html`. Join only to an existing canonical indexed entry. The normalization is for metadata matching only: never rewrite the anchor, weaken snapshot admission, change canonical metadata, or infer identity from title/basename across arbitrary paths.

External aliases must retain exact matching. Foreign origins, arbitrary schemes, sibling project roots, non-64-hex versions and unrelated paths remain untouched/unmatched. Preserve URL resolution under a trailing-slash project root, with no encoded-path workaround. Fragment/query behavior should be explicit for immutable metadata identity while the original navigation URL remains byte-for-byte untouched. Static HTML/no-JS continues to use its native link and complete archive; file/offline behavior must retain the current capability boundary.

Expected falsifiable test: the same validated native index yields SDLC’s exact four tags when the card links either to its alias or to a valid pinned snapshot under `/` and `/project/`. Mutations to origin/root/version grammar/path must not become native alias matches; external query-bearing URLs remain exact. The anchor href must remain the original immutable URL after tagging. Add a mounted Writing/native-article regression to existing tag/navigation/hosted selection, including desktop/mobile and Back/Forward, and compare filter membership/count with direct Writing. Current tag DOM tests exercise reader cache hydration with no archive cards, leaving this local snapshot identity gap uncovered.

No runtime correction has been implemented or accepted by this diagnosis. Requirements preflight, current-source tests, new runtime identity/byte admission and affected source/rights guards remain required. Prior reviewed runtime-family hashes cannot be reused as proof of unchanged runtime after editing `article-tags.cjs`.

## Separate review of completed post-C1 compatibility corrections

No additional blocking implementation finding in the completed source delta inspected here; this does not resolve the still-unfixed AC10 runtime finding or claim dynamic acceptance.

- Standalone `renderInteractive` now selects article-mode fallback resolution when an explicit selected article environment exists. Principal room validation remains strict. JPEG/JPG admission uses the existing bounded selected asset/hash path and `image/jpeg`; a focused test uses the actual SDLC hero bytes and rejects corruption. The original template exporter and actual media sources remain in use.
- The site-articles absence helper now excludes the verified resource union of all principal routes and exact declared retained files only, asserting emitted digest equality. It retains candidate alias/body/descriptor and cold/incremental negative oracles; it does not blanket-ignore article namespaces.
- Diagnostic writing variants now derive current native article versions, rewrite aliases and snapshots with the selected diagnostic engine, remove inactive article snapshots that would reference removed parent runtime, rebuild descriptors and validate complete closure. They remain explicitly non-full-gate diagnostics. Actual source/native articles are not replaced with synthetic publication bodies.
- Staging fixtures now attach actual verified components and correct PNG/PDF response MIME; current runtime test expectations use the already declared native production identity while preserving old identities. Source-bound producer guards include the two changed export producers with predecessor/current hashes and missing-entry negatives.
- The scanner exception set now contains exactly the catalog and generated-RI paths for the already reviewed public immutable-directory literal. Independently recomputed its SHA-1 and confirmed its literal presence in both actual inventories. A read-only admission check confirms each exact tuple requires its own ledger row, with missing-ledger, changed path/type/value refusal. This does not prove RI freshness or a full new scanner pass. The second ledger row is an exact addition, not a broad RI exemption.

No raw passing report for the entire current correction set was supplied for this judgment. Future runtime changes and final source/scanner/RI/hosted/rights/release gates remain separate. Existing failed campaigns stay failed/incomplete and must remain retained.

## Inspected current source hashes

| Source | SHA-256 |
| --- | --- |
| `site/engine/article-tags.cjs` | `e08a383dd762e51a434324e3d2c8b4ed222b00201971e665a644d5955f362d52` |
| `site/engine/archive.js` | `01d8803a9cc02edde612fa247a046cc9c295bc088ed8ba64e407ba00e34c35ed` |
| `site/engine/navigation.js` | `3a22652df63eac052030f3cc9119bc5b4b4acaab417775d22cf6458fa3176374` |
| `tools/site/articles.cjs` | `78eba91a08bd9a83d4c4c644216968ce99a80382631302792a7971f24ee57954` |
| `tests/article-tags.test.cjs` | `d1c6dadf51b9c5f3637e7c98f30bdfd165ab4b7b905a440e13abff91edb2590a` |
| `tools/build_site_previews.cjs` | `40d21b0be4e88ec9452350b62d3f9e5159fceb61f9dffd43fd25f731d203cf6e` |
| `tools/site/offline.cjs` | `23fc1d4c2da8b2345c37180a1a76803ff08f948b68e517969c48a7524791007b` |
| `tests/site-articles.test.cjs` | `95c27146b6d90b6c17922a5abaf602c43260f9ccd8f44575517c648a02a343af` |
| `tools/quality/writing-variants.cjs` | `80d2d8a1708b3d2063fda0f3b7dc6bc1339304c95752c67cb46c158f44ea8884` |
| `tests/staging.test.cjs` | `148ccf57c7e9b43c511a0886edf5787a85b54e13490b08fa7d39902fbcf484e4` |
| `tests/color-motion-contract.test.cjs` | `71f412ede5a752fd04fbe382b57f680561f36c4149b96a17f135c6cedc411fcb` |
| `tools/check_site_seo.cjs` | `3bc1382c9085c4e8cc1544b53d4797cbfd2a30c1968880ea2a0b304aaf5a23cd` |
| `review/issue-169/writing-carrier.json` | `281f0cd88fd249b3e18897b6e771fa8da0a16a0879a92319cab733c4d8fe1050` |
| `tools/quality/scanners.cjs` | `d5ce0402b9abfd5f9e3d385e31991fded746d40b018cadc49099fc620d6cfde1` |
| `tests/quality-sources.test.cjs` | `431cfaf1c25424f2b377a58cba51a807787ffeb1c97f80e114bb5a2b7ffe42e5` |
| `tools/quality/secrets-reviewed-checksums.json` | `06c641a4d0beff0e53489fbbed21f751a1bd535233a7a53373c6d06f042233eb` |


## Affected review — implemented tag lookup and embedded JPEG changes

The preceding diagnosis is preserved. Inspected the actual new runtime/test diff before final tuple freeze. **No blocking source-logic finding in the two implemented corrections. Final runtime identity acceptance remains pending the combined tuple packet and actual check results.**

| Inspected source | SHA-256 |
| --- | --- |
| `site/engine/article-tags.cjs` | `bc3cf3ff8141acc4963b10e409a38d054652e367f5cb343d5f8bd6348056d39c` |
| `site/engine/navigation.js` | `d5aad6583d06b68a08664cc54421446d1492ab46f35d249bb9536a7f2658f64d` |
| `tests/article-tags.test.cjs` | `a88f857081e50fc446f9901eeda2dcc500f6c2734190de0826e71ff660708d83` |
| `tests/article-offline.test.cjs` | `a6d0906148d06c64ae5fae6ee00f924575f07fcad48e031e798b5fb625fcc2d8` |

The tag helper normalizes only absolute same-origin snapshot URLs under the exact project-root snapshot prefix, with no username/password/search/hash and strict 64-lowercase-hex plus bounded-slug filename grammar. The result is used only as a key into the existing canonical index. External aliases and unmatched paths retain exact lookup; actual card hrefs are not mutated. No canonical index schema, routing admission or tag vocabulary was changed.

The new DOM-model mount test exercises eight positive/negative URL cases at each of two roots: native alias, actual current snapshot, exact external alias, foreign origin/root, malformed version, query and fragment. It checks exact tag assignment, preserved href and cleanup. This is appropriate failure detection for the observed metadata identity mismatch; it is a controlled DOM model, not hosted browser evidence.

The browser counterpart of JPEG admission changes only the finite extension-to-MIME path in `verifyEmbeddedAssets`. The 50-entry bound, exact selected resource inventory, content-addressed path/hash, MIME equality, 2,000,000-byte cap, strict base64, length and actual SHA-256 checks remain. The new test executes the actual extracted browser verifier with real native JPEG bytes and requires MIME and payload mutations to fail. It complements exporter-side JPEG verification rather than substituting fabricated publication content.

No test pass count is inferred while those runs are ongoing. The preliminary tag-only runtime family tuples were inspected only as pending work, not accepted: combined tag plus JPEG navigation bytes must be remeasured for all three editions. Its comment that all other runtime bytes stay unchanged should also reflect the JPEG navigation correction at final freeze. Previous family identities must remain exact. Final tuple/source binding, current native-browser round trip/filter membership, source/RI/scanner/rights and release gates remain separate. No implementation or duplicate campaign was performed by this reviewer.
