# Requirements & Acceptance — 25 exact native checksum dispositions

2026-10-31. Bounded independent per-row preimplementation review. No ledger append, source edits, full scan/test campaign, authored proposal-script execution, external writes or delegation. Existing source owners were invoked read-only only to recompute material/rights bindings and verify already produced runtime files.

**Verdict: all 25 proposed exact Hex false-positive rows are supported for append-only checksum-ledger disposition.** No blocking requirement/proof defect found in these rows. This acceptance concerns public-checksum classification only; it does not authorize new runtime compatibility, rights, source-suite success or website publication. Final actual ledger/source/scanner/hosted/release gates remain separate.

## Identity and audit

Primary proposal SHA-256 `63651ad13e7a7778be1a5727a0e90d7cd2b0e63bdde4e3d356e6f665036975e5`. Proposal source signature `f8722f039ccec34d0b837b1d111fc2b438230f5ef73cfdfb3052a7f9a799bf1b` equals the diagnostic's before and after signature. Proposal has exactly 25 unique tuples, all Hex; its file/type/hash/line set equals the diagnostic's complete 25 unknown findings, with no additional rule or Base64 case. Signature equality is the primary diagnostic's observation; this review did not independently recreate the entire source-signature algorithm or claim a clean final candidate.

Independently checked every row's actual source file SHA-256, exact line SHA-256, literal occurrence, 64-lowercase-hex shape, literal SHA-1 and full path/type/hash ID: **25/25 match**. Independently audited all 134 attached proof instances: current file hashes; JSON declaration fields; exact retained directory/hash/source/public-byte agreement; predecessor bytes obtained with `git show bd70996a386665e14f87440653e3a107fed15e43:<producer>`; and material/rights producer file hashes. No mismatches found.

Read the existing `article-materials` stable declaration algorithm and `articles.editionNotice`. Invoked existing read-only owners on the actual accepted source: materials binding recomputes `17067f5d00f887fb7a0ed4f13e6f03db6a843e13121a449ae896019f70b2f9e9`; rights declaration recomputes `034cb564e29b4d40a4d3f650dcc87ab669b9af6447a1dc269a9b337e52dfb56d`. Both exactly match all four corresponding document findings. This is declaration-digest recomputation, not a new rights/author decision.

For actual produced plain/staging/production directories in the proposal, independently read artifact fields, selected each through the existing exact motion contract, and hashed all five root plus five immutable runtime copies per edition: **30/30 actual file hashes match** the declared reviewed runtime hashes. Engine/fingerprint fields match their three finite family identities and all baseEngine fields match c36b2814…. No build/derivation was rerun; full cold generation, semantic behavior and current-source acceptance remain outside this false-positive audit.

## Per-row disposition

Rows are the immutable proposal order; literal prefixes below are labels, not alternate admission keys. The exact full file/type/hash tuple in each proposal remains the required ledger identity.

| Row | Source/meaning | Public literal prefix | Independent proof | Disposition |
| --- | --- | --- | --- | --- |
| 1 | Inactive 02a5 document engine | a404b4b436e6 | Exact retained five-file runtime directory and bytes | Accept exact Hex row |
| 2 | Inactive 02a5 document version | 02a5f0e4d2d1 | Exact retained snapshot path/hash/public bytes | Accept exact Hex row |
| 3 | Current bcad public document materials | 17067f5d00f8 | Stable material declaration recomputed | Accept exact Hex row |
| 4 | Current bcad public document rights | 034cb564e29b | Edition notice declaration recomputed | Accept exact Hex row |
| 5 | Preview producer predecessor pin | 54ca6b30753c | SHA-256 of exact bd70 Git producer bytes | Accept exact Hex row |
| 6 | Preview producer successor pin | 40d21b0be4e8 | SHA-256 of actual current producer bytes | Accept exact Hex row |
| 7 | Offline producer predecessor pin | 04970b8c3718 | SHA-256 of exact bd70 Git producer bytes | Accept exact Hex row |
| 8 | Offline producer successor pin | 23fc1d4c2da8 | SHA-256 of actual current producer bytes | Accept exact Hex row |
| 9 | Retained bcad document engine | c36b28140796 | Current revision/lock/actual tuple fields and retained runtime bytes | Accept exact Hex row |
| 10 | Retained bcad document version | bcad10190551 | Exact revision/lock/snapshot declaration and retained bytes | Accept exact Hex row |
| 11 | Retained bcad material binding | 17067f5d00f8 | Stable material declaration recomputed | Accept exact Hex row |
| 12 | Retained bcad rights binding | 034cb564e29b | Edition notice declaration recomputed | Accept exact Hex row |
| 13 | Retained manifest archive hash | f7da9f664674 | Current root/immutable/retained file SHA-256 | Accept exact Hex row |
| 14 | Retained manifest navigation hash | eac2248fde31 | Current root/immutable/retained file SHA-256 | Accept exact Hex row |
| 15 | Retained manifest bcad snapshot hash | 4aa1ae74ff48 | Actual public and retained snapshot SHA-256 | Accept exact Hex row |
| 16 | Retained rights archive hash | f7da9f664674 | Same independently checked exact file identity | Accept exact Hex row |
| 17 | Retained rights navigation hash | eac2248fde31 | Same independently checked exact file identity | Accept exact Hex row |
| 18 | Retained rights bcad snapshot hash | 4aa1ae74ff48 | Same independently checked exact file identity | Accept exact Hex row |
| 19 | Native-tags family baseEngine | c36b28140796 | Revision/lock/all produced edition fields and retained directory | Accept exact Hex row |
| 20 | Native-tags family archive hash | f7da9f664674 | Actual file SHA-256 and produced closure | Accept exact Hex row |
| 21 | Native-tags family navigation hash | 94ca7a7d3c1d | Actual produced root/immutable files and artifact fields | Accept exact Hex row |
| 22 | Native-tags plain fingerprint | 1f5551456a0f | Produced plain artifact fields/exact contract selection | Accept exact Hex row |
| 23 | Native-tags staging fingerprint | be64c404fc3f | Produced staging artifact fields/exact contract selection | Accept exact Hex row |
| 24 | Native-tags production fingerprint | 0af8ae2b7a0d | Produced production artifact fields/exact contract selection | Accept exact Hex row |
| 25 | Runtime compatibility known client | c36b28140796 | Exact current declared client and measured baseEngine provenance | Accept exact Hex row |

The inactive 02a5 values are preserved C1 identities, not assertions that C1 is current or newly accepted. The bcad source/rights/material values identify exact prepared bytes/declarations. Runtime family/compatibility literals are public code constants tied to produced artifacts; classifying them as false positives does not independently approve the compatibility code or measured behavior.

## Append and final gate constraints

Before append, none of the 25 full proposed IDs is already in the checksum ledger. Current checksum ledger SHA-256 `06c641a4d0beff0e53489fbbed21f751a1bd535233a7a53373c6d06f042233eb`, 1,222,298 bytes. General ledger SHA-256 remains `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb`, 1,999,782 bytes; it receives no row and no rewrite from this treatment.

Append exactly these 25 IDs to the existing checksum ledger with explicit provenance reasons; preserve every old row and metadata, exact closed schema, false-positive disposition, duplicate guard and 2,000,000-byte bound. Verify actual final prefix/semantic parity and cap after append/formatting. Do not add another tuple/rule exception, generic path/file allowance, detector/input/threshold/budget change or encoded/hiding representation. Existing exact Base64 restrictions remain untouched.

Recompute final source/RI/scanner evidence after actual append. The current diagnostic's 25 unresolved findings and earlier failed campaigns remain preserved; this review alone does not make them successful. Required independent Code/QA, full source/campaign accounting, rights/editorial/device and hosted/staging/production decisions remain separate. Source changes invalidate affected row proofs and require affected recheck. No peer verdict was used, and provider/internal-context assurances remain limited as in the original role receipt. Only this assigned report was written.

Additional exact receipt: `prepared-release-secret-component.json` SHA-256 `ddd40f1a1b58da33c5add0a96953be8267619f7a05f96bfe67f998345151c3b5`; checksum ledger count before append is 2,110, so the authorized append yields exactly 2,135 checksum rows. Canonical producer hashes independently match the proposal: article-materials.cjs `e599db3bb3a82a8d38741a301ee7513f4f0d4d433cb102df3abbe1a99a9f9cdd`; articles.cjs `78eba91a08bd9a83d4c4c644216968ce99a80382631302792a7971f24ee57954`.
