# White-box QA — exact scanner ledger data

**Scoped verdict: pass; no new blocker in the 388 exact ledger additions.** This is independent actual-data/schema/preservation/negative-behavior verification, not a full current scanner run or release acceptance. Earlier candidate reports/failures remain preserved. No implementation, external writes, delegation or duplicate broad campaign. The authored triage script was inspected and was not executed; it would overwrite primary evidence.

## Inputs and identity

- `issue169-checksum-proposals.json`: SHA256 `addd7e31ccde16ed41271f1d2fa4104c25784b733f199cde29079756c1a4cc18`.
- `release-detect-secrets.json`: actual SHA256 matches the proposal's `rawScanSHA256`, `b4e62aaa58541eeebde82d008097b4cdd71af0d5c544d0d0dad4841b418df7d0`.
- Current checksum ledger: SHA256 `072081727976ef774fa3b35d229a8741b2df1d67dbd32ee86bebe35f3f362fc6`, 1,227,081 bytes, 2,109 rows.
- Current general reviewed ledger: SHA256 `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb`, 1,999,782 bytes, 4,368 rows. It remains 218 bytes below the unchanged 2,000,000-byte bound.

The known exact catalogue Base64 guard retains its separate source review. Actual literal/context checks below do not introduce new detector exceptions.

## Independent bounded audit

Own audit completed successfully in 3.260 seconds. It read current source/artifact bytes, the immutable baseline, raw scan and proposals; reconstructed old prepared source in isolated temporary directories; called existing pure publisher/semantic/material/runtime identity owners; loaded all closed ledgers; and exercised exact tuple admission with mutations. It wrote only assigned review evidence. No full scanner or test module rerun.

All 388 proposals are unique exact path/rule/hashed-value tuples, present at their named raw scanner location. Each literal occurs on the actual current source line and independently hashes to its declared SHA1. Appended checksum/general-ledger tuples equal the proposal set exactly: 387 plus 1, with no missing or extra additions. Proposal unknown set is empty.

Independent public-proof accounting:

| Proof class | Count | What was established |
|---|---:|---|
| Exact file/artifact/native/path identity | 271 | Rehashed current files/accepted artifacts; reconstructed and verified both earlier packet manifests from immutable base+diff; recomputed publisher semantic/AST block, materials aggregate/reviewBinding, edition notice, runtime/client and predecessor Writing/source identities; byte-bound current retained route identifier |
| Local Git object identity | 19 | `git cat-file -t` confirms the exact local object exists; treated as an object identifier |
| Qualified historical assertion | 96 | Exact token exists in the specified immutable baseline file; this proves preservation of a public historical checksum assertion, not the truth of its underlying claim or current acceptance |
| Current catalogue directory literal | 1 | Actual directory/catalogue key exists; literal SHA1 matches the known exact Base64 tuple |
| Public scanner-reference prose | 1 | Exact matched literal consists of public scanner-function references and historical source SHA assertions; no credential or live acceptance value. Actual literal SHA1 and current source-line presence verified |
| **Total** |**388**| **No unproved or literal-mismatch rows** |

For the required scanner-data verification, source artifact bytes were processed for exact literal/hash membership only. No peer conclusion was emitted or used as authority; the one prose proof was assessed from the supplied neutral public literal, not a peer verdict.

## Schema, preservation and refusal behavior

`loadSecretReviews` successfully loaded the entire current closed set of 15,064 rows, exercising bounded regular input/schema/path/rule/exact-ID/duplicate validation. All 388 exact additions were admitted. Three mutations per addition were executed independently: prefixed wrong path, unknown detector type, and changed hashed value. **All 1,164 mutated tuples were refused**. This is finite negative testing, not measured branch coverage.

Both object comparison and raw per-entry JSON byte-span comparison against `bd70996a386665e14f87440653e3a107fed15e43` confirm that the old 1,722 checksum records and 4,367 general records are unchanged as exact prefixes. Ledger metadata is unchanged too. Admission remains a closed map of exact findings; current proposal data does not grant arbitrary Base64, generic entropy or path-wide approval. Browser/publication integrity proof requirements and existing schema/input limits remain as previously reviewed.

One preliminary diagnostic passed the configuration wrapper rather than its `.config` member to the client-fingerprint function, causing `client scene contract` undefined-versus 1. The actual API/test call was inspected, and the corrected independent derivation used `.config`. This was an audit-invocation error, not a candidate failure; no candidate changed or unchanged failing campaign rerun.

## Acceptance scope

The 388 additions satisfy their exact public-literal and closed-schema obligations within this source-bound audit. Historical assertions remain explicitly historical. This does not renew generated-field admission, independently prove the whole raw scan covers the latest final source, or establish current scanner/CI/hosted/production acceptance. The final current scanner run and its exact source/argv/exit/accounting receipt remain separate. No broader scanner threshold, input or budget change is accepted here.

Raw independent audit: `whitebox-ledger-review.raw.json`, SHA256 `1f4d1032c9c2bc8f9c2b863e3e006106114f56afe018548f0334f59becf53c91`.

## Later formatter-only identity reconciliation

After the full audit above, the checksum ledger was formatted. Independently decompressed the preserved pre-format bytes and confirmed their SHA256 equals the actually audited `072081727976ef774fa3b35d229a8741b2df1d67dbd32ee86bebe35f3f362fc6`. Parsed data is identical before/after, and all original 1,722 per-entry JSON byte spans remain unchanged against the immutable baseline. Only newly appended rows' indentation changed. The general ledger is unchanged.

Current checksum-ledger SHA256 is `857038d23586083aed328c1fa48998300ff9c11d4c0832e6c8f182dd14bd28a8`, 1,221,663 bytes. The data/schema/positive/negative conclusions above therefore apply without repeating the full audit. The earlier listed checksum hash/size identify the observed pre-format bytes; this paragraph supplies the current formatting identity. No new tuple or scanner acceptance is inferred. Independent reconciliation evidence: `whitebox-ledger-format.raw.json`.
