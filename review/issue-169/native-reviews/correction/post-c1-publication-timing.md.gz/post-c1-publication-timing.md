# White-box QA — publication-records timing diagnosis

**Causal result: observed expensive synchronous preparation and repeated source verification; no evidenced cancellation deadlock or case 12 deadlock.** The original 79-module campaign remains failed/incomplete. This diagnostic does not establish a full publication-records pass, current PR-profile acceptance, or the total module duration.

## Source and bounds

All diagnostic runs used local HEAD `3044b5cae6c95929267838751a9161262d589849`, with root's post-C1 working changes explicitly dirty. Root was editing other owners; execution receipts capture actual dirty lists and before/after scoped SHA values. The publication test and prepublication runner stayed unchanged, SHA256 `c8ec850da9ecd6c735a9c5b911f36a2e2a938702bbf7ecd3c610a10758cc7beb` and `46038e1ba99fa96975c6b9b103483e52d5273407bd56edc0d52a24456337d102`. Broader scoped dependency hashes remained stable within the full-module and focused phase runs. These are dirty diagnostics, not clean-C1 acceptance.

Each additional diagnostic was explicitly allocated by root after interpreting the preceding observation. No product/test code was changed, no source profile rerun, no limit increase, external write, delegation or peer-verdict inspection. Diagnostic scripts/hooks and raw artifacts are outside the checkout. Original failures/timeouts remain preserved.

## Diagnostic chain and accounting

| Diagnostic | External bound | Actual outcome | Information gained |
|---|---:|---|---|
| Initial programmatic launcher setup |60 s| Exit 1 in 0.164 s; no publication callback ran | Eval launcher propagated into child with missing hook argument; setup failure preserved separately |
| Corrected standalone programmatic full module |60 s| Hard timeout/SIGKILL at 60.004 s; four TAP passes plus case 5 complete event, no final summary | Precise incomplete boundary available, but subsequent callbacks can be hidden by buffering |
| Isolated cancellation case 6 |10 s| Exit 0 in 0.267 s; 1/1 pass | No intrinsic isolated cancellation deadlock |
| Direct CLI pair, native cleanup 5 + cancellation 6 |10 s| Exit 0 in 0.875 s; 2/2 pass | No deadlock from that ordered pair alone |
| Direct CLI full module |60 s| Hard timeout/SIGKILL at 60.006 s; incomplete TAP | Same apparent boundary removes programmatic outer-runner difference |
| Direct full module with callback-entry-only hook |10 s| Hard timeout at10.003 s; entered callbacks 1–12 | Cases6–11 actually advanced; the executing callback is case 12, not cancellation 6 |
| Isolated case 12 with external phase entry/return |20 s| **Exit 0 in 18.592 s; 1/1 pass**, no timeout,0 skips/cancellations | Fixture/guard phases are slow but all return; see measurements below |

The initial setup failure was corrected only after inspecting its stack and launcher structure; no publication test body had executed. The corrected launcher is a normal external script, not an unchanged rerun of the failed eval setup. Subsequent full-module CLI execution was allocated to discriminate runner environment, not to retry until green.

The callback-entry hook uses a Proxy over the original node:test function, preserves export properties/aliases, original options and callback arguments, and returns the original callback result/promise unchanged. It records callback invocation synchronously, avoiding TAP buffering ambiguity without adding await/microtask behavior. Phase hooks likewise preserve arguments/options/returns/errors and log only safe phase/command categories and durations; no environment/input values were logged.

## Actual callback and measured phases

Actual callback 12 is `tests/publication-records.test.cjs:543`: “preflight edition guard accepts production bytes on either host profile and rejects coverage-edition mismatches”. It was entered around 1.7 s in the callback instrumented run, after callbacks 5–11 had all been invoked. The earlier native-complete/cancellation boundary was a reporter-buffering artifact, not proof that those callbacks were stuck.

The isolated phase run observed:

| Phase | Duration |
|---|---:|
| Actual production fixture |3,484 ms|
| Actual staging fixture |2,925 ms|
| Rights compilation inside production fixture |2,672 ms|
| Rights compilation inside staging fixture |2,475 ms|
| Python media encoding inside production/staging |1,828 /1,771 ms|
| Four valid child edition guard commands |2,867 /2,971 /2,824 /2,970 ms|
| Two intended mismatched-edition guards |61 /75 ms|

Nested phase timings overlap their enclosing fixture durations and must not be summed twice. Every recorded phase entry has a return. The actual test ends successfully in 18.592 s overall. The cold native media work is repeatedly exercised while rights compilation selects current source articles; each valid child guard separately calls `readPublication(...,{verifySource:true})` and recomputes source-bound rights. Four successful child invocations intentionally vary host coverage profile while keeping the actual frozen edition correct; two negatives reject edition mismatch. Their semantics must be preserved.

This explains why a long synchronous test can suppress child heartbeat/IPC/TAP flushing while the outer CLI reports a live ChildProcess. Parent CLI handle samples continued every 5 s; the child had startup samples only during synchronous work. That observation alone is not an event-loop bug. Supplemental process-table sampling yielded no useful rows in this environment; no CPU utilization or OS blocked-state measurement is claimed.

## Interpretation and minimal fix hypothesis

The measured fixture plus four real child verifications account for almost the entire 18.6-second case. The module contains many additional current/historical rights/package cases, and the original campaign dequeued it only at 160,974 ms, leaving 139,026 ms before the fixed 300,000 ms deadline. **Cumulative repeated preparation/source verification is now a supported cost explanation**, while a later unknown hang remains unexcluded because no full module finished within this diagnostic allocation. The current evidence does not identify any defect in `advance`, `runParallel`, cancellation signals or promise cleanup; changing those owners would be speculative.

Minimal evidenced optimization hypothesis: avoid repeating demonstrably identical expensive fixture/media preparation while retaining independent copied outputs and all real admission/negative checks. A fixture cache must key the complete actual public/source/producer/rights input closure, return fresh independent records/files, and invalidate on any source/policy/history/codec change. A media cache would need equally exact source bytes, equivalent JPEG/geometry, encoder identity/configuration and selected executable binding. Neither is an accepted implementation here. Measure the chosen narrow optimization against the observed phases and have a nonauthor review its mutation-isolation and stale-input negatives. Do not replace real current article inputs with historical synthetic catalogs, omit guard variants or weaken rights/source verification.

A complete case-entry/return trace through the later module cases remains needed to establish total cumulative cost and rule out a separate later stall. Preserve all cases and the original source-profile limits. The failed/incomplete 300-second campaign cannot be repaired by profile changes, skipped cases, more time or reinterpretation of partial passes.

## Raw evidence

The `post-c1-publication-timing*` files include exact commands, dirty/source receipts, TAP, live case events, handle samples, external hooks and focused phase logs. Primary result files:

- `post-c1-publication-timing.json`, `.tap`, `.events.jsonl`, `.handles.jsonl`.
- `post-c1-publication-timing-setup.*`: preserved no-case launcher failure.
- `post-c1-publication-timing-cancellation.*` and `-pair.*`.
- `post-c1-publication-timing-direct.*`.
- `post-c1-publication-timing-callback.*`, including actual callback-entry records.
- `post-c1-publication-timing-phase.*`, including all entry/return timings and terminal one-case result.

No hosted/device/production behavior or full repository acceptance was observed. No implementation authored.

Evidence SHA256:

- `post-c1-publication-timing.json`: `fff880ca25c647add2e6e4b4986319b541cde60344f5c9f0d67e87b14535d439`.
- `post-c1-publication-timing.events.jsonl`: `0c84bf18bdd67431f12664a7ce4995f4e77256bb9fbfa099d7ae1da1c6559da9`.
- `post-c1-publication-timing-direct.json`: `bbf38fed21bcb2964179d7a40cc24a5a8a28622f5ce4497f25766c7b144b523f`.
- `post-c1-publication-timing-callback.entries.jsonl`: `b7231609bd291512d82142b1a7ade6f5d8abc144aef8bdd160de2b6b6f65333f`.
- `post-c1-publication-timing-phase.json`: `4730846543d9ec2604df92b8336d08cb7a934ba8ade2b4560182f926764506fd`.
- `post-c1-publication-timing-phase.phases.jsonl`: `adf6296d57a013e36c88bf49951dd00fa4f941e3569a41373489e7b0fc9658c3`.
- `post-c1-publication-timing-phase.tap`: `08ae14154752b3957e5289483ff461abfa0bcd76f2df977a838443d5136d2f07`.

## Final scheduling assessment — smaller next treatment

After the phase result, inspected the actual source-worker queue and original capacity/dequeue/completion records. The scheduler explicitly prioritizes publication-records only twelfth. The observed capacity is 79 files, available/configured parallelism 8, maximum concurrency 4. Publication dequeued at 160.974 s and had only 139.026 s left; it remained incomplete after that observed loaded duration. This is longer than completed release-controller (124.488 s), Pages-delivery (87.376 s), executive (82.986 s), Space (75.122 s) and Pages-migration (70.196 s). Release-rights is the one completed module longer than this lower bound, at 172.157 s. Publication therefore belongs in the first wave while retaining release-rights there.

**Preferred minimal treatment: swap publication-records with article-media in the existing explicit priority list.** Publication moves to the third first-wave slot and release-rights retains the fourth; the other queue positions and relative order remain unchanged except the swapped article-media entry. This preserves every selected module, existing process isolation, four-slot ceiling, 300-second/16-MiB source budget, strict test accounting and all test oracles. It changes scheduling rather than dropping work or asserting that missing results passed. Existing scheduler isolation/failure-accounting/capacity tests should retain the full selected set and include the new first-wave ordering.

This is an evidence-driven scheduling hypothesis, **not a verified deadline solution**. The sum of completed modules' observed wrapper wall durations is 1,013.270 s; adding only publication's 139.026 s lower bound gives 288.074 s as the ideal four-slot lower bound under a fixed-duration model. Wall durations vary with contention, so that model is not measured CPU work or a runtime prediction, but it shows the narrow budget margin. No module has yet been timed to completion here; later stalls remain unexcluded. The exact current profile must still terminate with complete accounting under its original limit before acceptance.

This priority-only treatment is smaller than introducing fixture/media caching and should be assessed first. The cache ideas in the preceding hypothesis section remain conditional alternatives requiring stronger keys and mutation-isolation proof if subsequent exact timing demonstrates a remaining cost problem. No cancellation or limit change is supported. No further full diagnostic was run after this recommendation. Timing/scheduler evidence: `post-c1-publication-timing-scheduling.json`.
