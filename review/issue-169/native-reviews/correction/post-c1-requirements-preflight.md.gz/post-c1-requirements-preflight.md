# Requirements & Acceptance — post-C1 preimplementation review

2026-10-31. Source: clean local `3044b5cae6c95929267838751a9161262d589849`, tree `f409f9017c825dfb26b8f2238cc7a2be6a74d5e2`, as bound by the primary execution record and diagnostic before/after receipt. This is a continuation after the preserved independent requirements judgments, based on actual sources/raw output; no peer verdicts were consumed. No implementation, external writes, delegation or campaign rerun.

**Verdict: the proposed bounded compatibility corrections are authorized and necessary; requirements are sufficiently clear for implementation with the inactive diagnostic-closure constraint below.** They repair existing export/diagnostic/staging/oracle paths for the accepted native article. They do not change accepted article meaning, illustrations/PDF, licensing, budgets, source boundaries or release authority. No additional author permission is needed. Failed/incomplete source campaigns remain failed/incomplete.

## Evidence and identity

Primary `pr-source-release.json` SHA-256 `0074f2f5ac212ffd76c16781d8fd1f573bd905bb6a4a94c8e3a4dc08bb69a136` says failed/pass false with ETIMEDOUT and empty aggregate accounting, same clean source before/after. It cannot establish whole-campaign success. Preserve its raw TAP/stderr and individual module outcomes; 78 completed wrappers or isolated emitted passes cannot replace missing final accounting.

Read the bounded follow-up raw `post-c1-whitebox-diagnostic.tap`, SHA-256 `4dbb9d4f86d32fbe9658e1b37bdfba67c8182a0fc7a21f845d12e9a3d6ca3028`: 78 cases, 57 passed, 21 failed, no skips/cancellations/TODO, `14518.53976 ms`; wrapper source-after is the same commit and clean. This is a five-module diagnostic, not replacement full-source acceptance. The failing cases reach room resource closure, article engine identity, erased article inventory, or obsolete current runtime expectations. Main retained TAP additionally contains the default/deletion article resource and native-template export failures.

Source hashes inspected:

| Source | SHA-256 |
| --- | --- |
| tools/site/offline.cjs | `04970b8c3718d886e2884e2ce63e488aea7a20aebce0bed8778cc7ff8e5288be` |
| tools/build_site_previews.cjs | `54ca6b30753cf343f906b9aa1d551a96212136a4882ec047c56a186e831285e6` |
| tools/quality/writing-variants.cjs | `383d928bd96dc6d12e81f0abee1545d3a0595bf33ac6091d896073bf79441f42` |
| tests/staging.test.cjs | `ecf337f9e72cc47caf87e2e384f78184583706a76f9b18717dfa8ddb5582b3b4` |
| tests/site-articles.test.cjs | `e658e65b7617c1342d3b86c38b82445ed145a8bed7b0407e2ad441151803a683` |
| tests/color-motion-contract.test.cjs | `b9d69267f01441f39ab1b7c0ac179817339b402c760898057b3d465c42ac79ce` |

## Observed requirement defects and bounded treatments

1. **High: standalone article export is incorrectly dispatched through the room fallback contract.** `articleExport` expands article resources via `inlineAssets`, then calls `renderInteractive` with page `writing`; `renderInteractive` unconditionally calls `inlineFallback(..., page)`. The strict room resolver consequently receives expanded article artwork instead of its declared room carrier. Dispatch by the actual article/room environment, so each reaches its own existing verified closure contract. Do not make the strict room resolver accept arbitrary expanded SVG or bypass resource verification. Test successful article and principal Writing paths plus undeclared/changed carrier refusal.

2. **Medium: existing standalone asset allowlist excludes the accepted hashed JPEG hero.** `offline.assets` allows exact content-addressed PNG/WebP/PDF and the special Writing SVG, with existing byte/hash limits; JPEG cannot reach export. Add only supported JPEG extension/MIME handling through the existing source-validated, hashed asset path. Preserve asset inventory/raw/transfer caps, fallback restrictions, asset hash verification and safe inline boundaries. Exercise genuine JPEG selection/export and mismatched/changed-byte rejection. Do not increase budgets to make a rendition fit; existing bounded rejection/hosted-edition guidance remains applicable if the real set exceeds the limit.

3. **High: diagnostic engine derivation leaves active article documents stale.** `writing-variants.derive` derives versions and rewrites only five principal alias/snapshot pairs while changing revision engine. Snapshot verification correctly rejects articles still declaring the parent engine. Extend derivation to all active article alias/snapshot pairs with recomputed version/hash/content identity and correctly rebased runtime/resource references, preserving source/semantic edition, visible meaning, media/download bytes, immutable input provenance and diagnostic/nonpublication flags. Keep strict snapshot and budget verification.

   **Additional integration constraint:** current derive removes the five runtime files from every old runtime directory and deletes principal snapshots, but leaves article-snapshots. Merely rewriting active articles can leave dormant retained raw article documents referencing removed runtimes. Either preserve each inactive immutable document's complete closure or omit inactive article snapshots coherently from this private diagnostic package, consistently with its existing principal-snapshot treatment. Do not leave orphan documents or loosen snapshot/dependency checks. This does not authorize deleting declared source/public production retention.

4. **Medium: controlled staging fixture loses actual accepted document inventory.** `tests/staging.test.cjs::fixture` copies actual public bytes and creates a manifest/gate without snapshot-verified components; package admission subsequently sees native article aliases as unexpected. Bind source and gate components to the same actual verified frozen revision; preserve actual article alias/snapshot/media inventory. Do not strip native files or replace the actual source with a legacy synthetic subset to make admission pass. Tests remain controlled package/HTTP models, not real provider/browser evidence; historical fixtures keep their own verified inventories.

5. **Medium: default/deletion article resource oracle confuses preserved declared inputs with new candidate leakage.** Permit only exact declared retained paths and all verified principal room resource paths, rather than assuming no article-namespaced file can exist or allowing only Research's carrier. Keep independent assertions that new draft article alias/body/assets are absent unless selected, and that rename/deletion cleans the candidate's unretained outputs with cold/incremental equality. No blanket article-media/article-snapshot allowance. Derive permitted resources from their authoritative finite retained/principal inventories, not from arbitrary actual output membership.

6. **Medium: current-production runtime tests demand the preserved former edition.** Actual accepted article sitemap changes production fingerprint to the separately admitted `40d235…` family while plain/staging remain Issue159. Update current production expectation to explicit `issue169-sdlc-production`; retain exact byte/immutable runtime/baseEngine/effects/rights assertions and explicit historical `e1464…` identity tests. Do not use the actual selected result itself as the expected oracle or admit unknown runtimes.

7. **Conditional exact-provenance integration:** preview/offline producer changes affect frozen SEO/source-carrier successor pins. Inspect actual affected producer dependencies and add only exact before/after source-bound amendments for changed owners, preserving predecessor geometry/content and all unchanged producer identities. No generic producer exception, arbitrary list broadening or historical record rewrite. Update registry selection/RI for changed paths through existing mechanisms.

## Acceptance linkage and next gates

| Intent/AC obligation | Required correction evidence |
| --- | --- |
| Existing native publisher; accepted source and distribution parity (AC04/07/09) | Actual selected export/document closure, JPEG MIME/hash preservation, unchanged semantic/media/PDF source and bounded export behavior. |
| Preserve visual/source and budget contract (AC02/08) | Exact fallback/producer successor proof, unchanged geometry/source boundaries, existing size and transfer caps; meaningful negatives. |
| Native inventory and source-bound verification (AC05/10) | Actual snapshot/component binding, exact finite retained/principal allowances, no new draft leakage, correct current/historical runtime distinction, current registry/RI mapping. |
| Independent review and release ownership (AC11) | Changed-candidate affected reviews, exact-source checks and honest campaign accounting; required hosted/device/rights/author and release decisions remain external gates. |

Choose the smallest affected verification after implementing the evidenced correction, retain all original failures and diagnostic logs, then run required acceptance on the final exact candidate under the existing failure-diagnosis protocol. No unchanged failed full campaign rerun is authorized merely to seek green output. Successful focused corrections do not erase the timed-out whole-source result. Current source, hosted, staging and release gates remain pending until their actual observations.

The operational reading boundary/provider-context limits from the original review remain. No clean provider internals, remote preview state, independent browser execution or production readiness is claimed here. Only this assigned preflight file was written.
