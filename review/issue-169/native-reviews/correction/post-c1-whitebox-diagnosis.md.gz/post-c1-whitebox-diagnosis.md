# White-box QA — post-C1 failed campaign diagnosis

**Advancement remains blocked.** Independently reproduced all five previously unshown failed modules with terminal stacks, on frozen clean source `3044b5cae6c95929267838751a9161262d589849`, tree `f409f9017c825dfb26b8f2238cc7a2be6a74d5e2`. Findings below distinguish real implementation gaps from stale test inputs/oracles. No source/test edits, external writes, delegation, peer verdicts or unchanged broad rerun.

## Preserved campaign and bounded diagnostics

Original `pr-source-release.json/tap/stderr` establishes 79 selected modules, unchanged 300,000 ms/16 MiB execution bounds, 78 completed wrappers, seven failed wrappers and unfinished `publication-records`. Aggregate accounting is absent; emitted passes do not establish a profile pass. The compact diagnosis's `selectedModules:3` is a reporting-count error from the files object; execution argv/capacity records and the actual module list establish 79. The two visible article-media/site-articles failures remain outside this delegated five-module diagnostic.

One authorized diagnostic campaign ran all five modules with `node --test --test-reporter=tap --test-concurrency=3`, a 148-second outer watchdog and no early stop on case failure. Complete result: **78 tests, 57 pass, 21 fail, 0 cancelled/skipped/todo**, Node duration 14,518.540 ms; wrapper exit 1, 14.611 seconds, no timeout. Source commit and clean state matched after execution. Raw exact command/stacks/status: `post-c1-whitebox-diagnostic.tap`.

| Module | Tests | Pass | Fail |
|---|---:|---:|---:|
| article-offline |17|10|7|
| browser-gate-variants |8|7|1|
| color-motion-contract |30|28|2|
| staging |18|10|8|
| writing-variants |5|2|3|
| **Total** |**78**|**57**|**21**|

One separately authorized focused publication case was selected after source/timing inspection, described below. No other test campaign or publication case was run.

## F-C1-1 — high: standalone article producer double-processes fallback as a room

Seven executed failures in `tests/article-offline.test.cjs` at 296,519,574,587,606,741,805 all reach `fallback.resolveRouteResource:277` via `offline.inlineFallback:279` and `build_site_previews.renderInteractive:138`, failing “Room fallback resource closure differs”.

Actual flow: `exportArticle:303` calls `offline.inlineAssets`, which already invokes article-mode `inlineFallback` and replaces its verified external Writing use with passive inline geometry. It then calls `renderInteractive(...,'writing',...,environment)` at 305. That function again invokes `inlineFallback(source,environment,page)`, selecting the room branch. Since the current Writing room now declares its external resource, the room resolver requires the exact use/href closure and correctly rejects the already-inlined article SVG. Earlier resource-free room behavior masked this integration error.

Treatment: maintain an explicit article-versus-room rendering context and inline the verified article fallback once, or use an idempotent article-mode pass after article inlining. Do not weaken room/resource closure validation to accept arbitrary inline geometry while a resource is declared. Keep ordinary room exports resource-aware. Current tests then need to reach their intended material/namespace/source/output-safety/PDF assertions, which these failures currently block.

Independent oracle/meaningful negatives: reconstructed geometry byte-equivalent to canonical Writing; no external fallback use after standalone inlining; missing/unknown/changed resource and passive-vocabulary violations rejected; body media payload finite and verified; original HTML/gzip budgets retained. Existing article-offline tests should own the article path; room/offline tests must preserve ordinary Writing/Research behavior.

## F-C1-2 — medium: private diagnostics transform only principal documents

One browser-gate case (`browser-gate-variants.test.cjs:479`) and three Writing cases (`writing-variants.test.cjs:130,207,311`) fail `snapshot.verify:233`: active article HTML lacks the new diagnostic engine. All stacks reach `quality/writing-variants.cjs:421`.

`derive:342-414` creates versions, rendered aliases and immutable pages only for `snapshot.routes` (the five principal rooms). It copies the full real source, changes revision.engine, rebuilds those rooms/runtime, and spreads the original `articles` descriptors unchanged. Current native article alias/snapshot therefore still carries the old engine, despite the diagnostic revision pointing to the new engine. This is an incomplete diagnostic producer, not evidence that the snapshot guard is too strict.

Treatment: transform the complete admitted active document inventory, including article alias/snapshot pairs and their descriptor/bootstrap/version references. Preserve article content/source/semantic identities, assets/downloads and scene; produce correct fresh immutable URLs/SHA values. Keep actual article inputs in the diagnostic fixture. Do not erase articles or bypass the engine check. Preserve private fullGate=false and exact control immutability/determinism.

Independent oracle: each active diagnostic document matches diagnostic engine/version and immutable SHA, complete native body preserved after only declared identity substitutions, parent/control bytes unchanged, assets/passive scene preserved, original size limits retained. Existing Writing/browser-gate tests should verify actual article pair identity and content in addition to five-room checks. Current strict verification usefully detects incomplete propagation.

## F-C1-3 — medium: two current production runtime oracles still expect the predecessor

`color-motion-contract.test.cjs:138` fails at 165 because actual production variant is `40d235...`, expected `e1464b...`. `:1089` fails at 1122 because `motion.select(production).id` correctly returns `issue169-sdlc-production`, expected `issue159-reading-paths-production`.

The admitted current article-aware production identity is already distinct and source-reviewed; this diagnostic confirms the selector returns it. These two current-build tests hard-code the previous production family while plain/staging identities remain valid. No selector/runtime admission defect is established by these assertions.

Treatment: bind current production assertions to the exact issue169 production tuple; retain issue159 production as a separate exact historical oracle. Keep byte equality and both root/immutable substituted-runtime negatives, edition mismatch, publication-rights requirements and unknown-fingerprint refusals. Do not accept any runtime merely because its scripts resemble the predecessor.

## F-C1-4 — medium: staging fixtures omit the real article descriptor inventory

Eight staging cases at 207,262,284,398,480,602,725,784 fail during setup/admission with “unexpected public input articles/the-sdlc-is-out-of-balance.html”; stacks reach `staging/package.cjs:91` → `snapshot.inventory:65`.

`tests/staging.test.cjs:fixture:105-131` copies current actual docs and creates source/gate from artifact.manifest, but does not populate source.components. `sourceGate` correctly passes only `source.components?.articles||{}` to finite inventory validation. With a real local article now present, its mutable alias is undeclared. The implementation's existing declaration requirement is functioning correctly. Several later tamper/HTTP/proxy assertions never execute because setup fails first.

Treatment: prepare source/gate components from verified current snapshots for valid fixtures and consistently refresh them after explicitly valid synthetic formula/legacy fixture mutations. Preserve intentionally invalid inputs in their negative scenarios. Do not allow every article alias by path regex or remove the accepted article from actual delivery fixtures.

Independent oracle: source descriptors, actual revision and exact mutable alias inventory agree; missing/forged components or alias/snapshot/assets remain rejected even with recomputed manifests. Keep historical fixture compatibility distinct from current native source and preserve original HTTP/redirect/cache/noindex/proxy negatives.

## Unfinished publication-records — cause not established

Original timing records show module dequeue at 160,974 ms and no complete event by the 300,000 ms cap, leaving 139,026 ms of observed wall time. Wrapper timing cannot identify the currently executing case or distinguish cumulative fixture cost from a stalled case/open handle. The module contains repeated modern/historical rights/package fixture work and explicit setInterval child fault-injection cases; these are hypotheses requiring evidence, not reasons to raise budgets or skip tests.

Specific bounded question selected: can the native timeout/overflow/cancellation child-case intrinsically leave the process alive? Ran only `^asynchronous native guard limits preserve partial streams and reject overflow and cancellation$` under a 15-second watchdog. **1 test/1 pass,0 fail/cancelled/skipped/todo**, case 625.004 ms, wrapper 0.817 seconds/exit 0, same clean source. Raw: `post-c1-publication-nativecase.tap`. This limits the intrinsic isolated child-cleanup-leak hypothesis. It does not prove aggregate-load cleanup or whole-module completion and does not identify the unfinished case.

Next useful diagnostic, outside this allocation: retain per-case start/end timing or test-runner dequeue/complete events for publication-records on the exact corrected candidate, preserving its existing budget and complete case inventory. Establish whether cumulative fixture work or a specific case accounts for the 139-second observed window before proposing caching/scheduling changes. Any fixture optimization must retain exact source-byte keys, independent mutation isolation and all meaningful refusals. Existing campaign remains failed/incomplete and must not be relabeled as passing.

## Mapping and remaining acceptance

These cases belong to existing registered article-offline, browser-gate-variants, color-motion-contract, staging, Writing diagnostic and publication-records suites through current source profiles; no new broad matrix or budget increase is needed. Findings affect source hygiene/check completeness and native delivery obligations under AC04/05/08/09/11 as applicable. Actual hosted/production behavior was not exercised. Exact source/RI/companion scanner findings remain independent gates. Following correction, obtain nonauthor source/test review and exact affected verification, then complete the unchanged current-source profile with final aggregate accounting; proposed treatments above are not implemented fixes or executed corrections.

## Raw evidence identities

- `pr-source-release.json`: `0074f2f5ac212ffd76c16781d8fd1f573bd905bb6a4a94c8e3a4dc08bb69a136`.
- `pr-source-release.tap`: `951016e6f1a3ee5c1fa15c340d6d29d6c89bf642b0c8d2f97ae18bdaace3845d`.
- `pr-source-release.stderr`: `9f6b1cbdb9750c5db0cb753884977d8fd6b98f3233f658f8be2ce444c53d7203`.
- `post-c1-whitebox-diagnostic.tap`: `4dbb9d4f86d32fbe9658e1b37bdfba67c8182a0fc7a21f845d12e9a3d6ca3028`.
- `post-c1-publication-nativecase.tap`: `27a1bfac99821c4ef1cc5945f3cfa9a3b61db458e72f4cb6d1f955547df676ca`.

Final source/dirty check: `3044b5cae6c95929267838751a9161262d589849`; status ``.
