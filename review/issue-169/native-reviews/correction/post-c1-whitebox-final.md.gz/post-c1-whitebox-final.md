# White-box QA — post-C1 combined runtime/corrections

**Affected-source verdict: no new blocker found.** The inspected native tag/JPEG changes preserve finite identity/rights guards and historical tuples; post-C1 compatibility fixes address the previously identified mechanisms. This is dirty prepared-source review, not a final clean PR-profile/hosted/production pass. Original campaign failures, incomplete runs and diagnostic setup failures remain preserved.

## Source identity and bounded verification

Packet `post-c1-runtime-packet.json` SHA256 `4fe1094a8c1463433e1c736d098c28efac1ba80d8a5e4286eb01251a0f6dd327` matches the supplied identity. All nine packet source hashes independently match. Current base HEAD remains 3044b5 with post-C1 working changes; the packet explicitly does not claim a clean candidate. Additional inspected compatibility/test/scheduler owners are SHA-bound in `post-c1-whitebox-final-runtime.raw.json`.

No accepted source/tests authored, external writes, delegation, broad campaign or duplicate affected suite. Independently executed only bounded read-only actual tuple/history/guard and controlled tag/JPEG checks. Source bytes and actual public runtime bytes were read; no existing tuple directories were modified.

Own actual results:

- All 15 canonical runtime files across actual `native-final-tuples/{plain,staging,production}` match packet and reviewed-family hashes; each corresponding immutable runtime copy also matches (30 file reads total).
- All 146 pre-existing reviewed runtime tuples are value-identical to the immutable 3044b5 owner's tuples, including issue159 and the earlier issue169 production-only identity. New plain/staging/production select the exact issue169-native-tags family. Inherited flight/reading/interaction/paper/whole-block/deferred-media behavior agrees with the predecessor.
- 12 altered tuple smoke cases refused: unknown coherent fingerprint, changed canonical archive hash, changed immutable navigation hash and wrong edition across all 3 renditions. All 3 missing-rights records refused before file access; publicationRequired remains true.
- 22 controlled mount scenarios across root and nested-project bases passed, including canonical/old pinned immutable identity lookup; foreign origin, outside root, wrong-length version, extra segment, credentials, query, fragment and unindexed slug refusal. Anchor href remained unchanged, and cleanup removed injected tag state.
- Actual JPEG payload accepted for both `.jpg` and `.jpeg`; 20 browser-verifier negative cases refused across MIME/data-URI mismatch, hash mismatch, zero/oversized/wrong length, altered bytes, malformed Base64, inventory mismatch and unsupported extension.

One preliminary audit evaluated a historical selector across VM object realms, whose strict object-prototype comparison rejected serialized-identical staging edition objects. This was an audit invocation limitation, not a candidate failure. The preserved setup log explains the correction: historical tuple values are compared by serialization and inherited primitive behavior directly, without legacy cross-realm object assertions. Completed results above come from the corrected audit.

## Structural risk/oracle matrix

| Risk / AC | Independent invariant | Inspection/result |
|---|---|---|
| Native tag identity / AC10 | Tags follow canonical publication identity while pinned destination stays unchanged; mapping cannot cross project root/origin or broaden URL forms | `publicationIdentity` maps only same-origin credential-free query/fragment-free exact-root `article-snapshots/<64hex>/<bounded-slug>.html` to the indexed canonical alias for lookup. It never rewrites href or admits an unindexed publication. Own 22 mount cases passed |
| JPEG counterpart / AC08,09 | Browser and producer accept the same finite existing rendition, retaining MIME/path/length/hash/inventory checks | Navigation adds only `jpe?g` and image/jpeg to the prior PNG/WebP/PDF vocabulary. 50-resource and 2 MB limits, safe path, content-addressed SHA, exact data URI/Base64 length and decoded-byte digest remain. Own 2 positives/20 negatives passed |
| Runtime/rights preservation / AC05,11 | Exact new triples must not relabel old families or lose mandatory rights/reader behavior | New family inherits issue159 policy/behavior, overrides exact base/archive/navigation/edition identities, leaves styles/theme/space unchanged. Actual 15-byte closure plus 12 mixed/unknown/edition refusals and 3 rights refusals verified; 146 historical tuples unchanged |
| Offline article correction / AC05,09 | Verified article fallback is inlined as an article exactly once; room closure remains strict | `renderInteractive` now selects article-mode null when articleKey exists, room-mode otherwise. Resolver itself is not weakened. Corrected article-media oracle checks JPEG MIME/SHA positively and still rejects JPEG-as-download, malformed PDF/native links and forged download accounting |
| Private diagnostics / AC05 | Every active article pair must move with diagnostic engine/version, while preserving accepted content/resource identity | derive now renders article alias/snapshot pairs, updates version/url/SHA/bootstrap substitutions, removes inactive private snapshots referencing removed runtime, and preserves declared media/download/source fields. Snapshot validation remains strict; fullGate=false/control-preservation remains. Direct article body parity is source-inspected; current explicit body-parity assertions primarily cover rooms, so an additional article-body comparison is a useful existing-suite enhancement, not an observed current defect |
| Staging fixture scope / AC05 | Actual current aliases must be declared, and valid synthetic mutations must refresh the same finite descriptors | Current fixture source/gate receive snapshot-verified components; positive formula fixture refreshes them after mutation. Unknown/missing/forged inventory refusals remain. Actual delivery article is retained rather than removed to satisfy a legacy count |
| Scheduling / AC05,11 | Earlier long module scheduling must preserve all selected work, limits, process isolation and strict accounting | Source diff is only the publication-records/article-media priority swap. Rights remains slot 4; publication now slot 3. Expanded 10-stub existing test preserves all selected assertions and exact ordering; no change to 79-module selection, 4-slot ceiling, 300-second/16MiB limits or failure propagation |

No branch-coverage percentage is claimed. Controlled mount/VM verification does not establish actual browser/device behavior. Suggested article-body parity enhancement remains allocated to the existing Writing diagnostic suite, not a new matrix or budget.

## Primary root-executed evidence inspected

- `native-jpeg-tags-tests.tap`: 3 tests/3 pass, 0 fail/cancelled/skipped/todo, 1,500.596 ms, complete accounting; its SHA matches the packet. This covers source JPEG integrity, browser JPEG MIME/payload refusal and mounted pinned tag lookup.
- `native-scheduling-order-exact.tap`: 1 test/1 pass, 0 fail/cancelled/skipped/todo, 909.761 ms, complete accounting. The source test executes 10 actual stub modules, checks all 10 assertions and first-wave/order preservation.
- `native-current-basic-v2.log`: actual pass summary, 16 focused theme/archive tests plus 10 flight tests, 0 failures/skips; generated/snapshot/size/geometry/syntax obligations reported, deploymentAuthorized=false.
- Earlier `post-c1-targeted-v2.tap` remains 105/103 pass/2 fail, not a current regression pass. The JPEG-refusal oracle is visibly corrected and the generated-staleness condition is separately refreshed; root's next affected regression is still pending. Earlier `post-c1-focused-v3.tap` remains 8/7 pass/1 fail and is not superseded into acceptance by this review.
- Wider `native-scheduling-tests.tap` has only a first case and no aggregate summary; it is explicitly **not counted as suite acceptance**, regardless of wrapper exit. The terminal exact-target test above supplies only its intended order evidence.

These are parent-executed primary outputs, independently read. Orchestrator must retain exact argv/source/exit receipts separately. Basic/exact unit evidence does not replace the upcoming affected regression or final 79-module profile.

## Remaining gates

Final immutable source/metadata/retained closure packet, nonauthor reconciliation, exact affected regression and the unchanged full 300-second current-source profile with complete accounting remain pending. Scheduling is an evidence-driven correction whose budget sufficiency is unproven until that run completes. No cancellation change is supported or accepted. No hosted native tag journey, JPEG viewer/device interaction or production activation was observed. Current scanner/source/rights/editorial/manual gates remain separate. No whole-AC or release-readiness tick is supplied by this report.

## Own audit identities

- `post-c1-whitebox-final-runtime.raw.json`: `ee625f56d62b65e5ef694eb7cf02de4158a9a455b32e8f571ce567517fcff9b4`.
- `post-c1-whitebox-final-tags-jpeg.raw.json`: `4b87f591203cc01a696fe99e54a0e611a822a13ee944d69b34e7e761dbe47b85`.
- `post-c1-whitebox-final-audit-setup.log`: `95d207f55cd8d8b8642ab1da6dd7d56e0ad60534ef64fb984ce3296003ad30ae`.
- `native-scheduling-order-exact.tap`: `2748436d21c568ba068c71e43dfa03387009edbdf2c65e6bea873d5d22e01e2a`.
- `native-current-basic-v2.log`: `8211901849ee57b2dee8fcc4c29a7b87997c2b71c21a8b0e75df3ffabc2575eb`.

## Later exact client-document guard companion

Root's later actual runtime regression `native-final-runtime-tests.tap` reported 82 tests / 81 pass / 1 fail. Its preserved failure was “Missing expected exception” for removing the current document's space-motion hook: `runtime-compatibility.verify` checked all five runtime hashes and recomputed client fingerprint, but returned before document-hook checks because the new exact c36... client was absent from the finite reviewedDocumentClients set. This is a real missing guard companion, not a reason to drop the negative oracle.

Independently inspected the correction: exactly one line adds `c36b28140796f556d7f6019efa223c5164e7ca55e880e1e6a64bb596283430da` to that set; removing that line reproduces the immutable 3044b5 source byte-for-byte. Old clients, complete runtime fingerprint verification and all document checks are unchanged. The exact known new client now receives the existing body/route/main/canvas/controls/footer/navigation/classes/meta checks on every active principal and article document pair. This strengthens the guard for the measured client; it introduces no generic runtime/hash or unknown-client bypass.

Primary `native-client-guard-test.tap` independently read: 1 test / 1 pass, zero fail/cancelled/skipped/todo, 313.948 ms. The actual source test preserves producer-refactor independence, five-file runtime hash tampering, missing live controls despite inert/template/comment lookalikes, missing fallback/footer and interface identity negatives. No duplicate test was run here. The failed 82-case run remains failed; the exact one-case correction pass does not become a whole-module pass.

The new companion hash is an addition to the earlier packet scope and must be carried into the final packet: `d8ed0a606a6e3f6c3f8081e3ed83a4c7efa0cb75713511a3464fabe5e802c6b9`. It changes producer/raw snapshot identities, while measured client c36... and the three Color runtime fingerprints remain unchanged. Final regenerated/raw retained closure and exact dependent regression/full-profile acceptance remain pending. Separate audit identity: `post-c1-whitebox-final-client-guard.raw.json`.
