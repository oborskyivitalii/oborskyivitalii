# Independent Code review — exact scanner ledger additions

Reviewer: `/root/correction_code_clean`, same nonauthor Code execution continuing its source-bound correction review. Date: 2026-10-31. This separate result preserves the prior report and does not alter scanned source. No implementation, external writes, delegation or new full scanner campaign occurred. The authored triage script was read and audited, not executed. Limited primary source-line lookups in preserved review prose were used solely to assess literal false positives; peer verdicts were not used as acceptance authority.

## Judgment and exact scope

**No blocking finding in the two proposed ledger additions.** The 388 proposed dispositions have exact source/literal bindings and are public checksum/path/prose false positives. This accepts their bounded data classification, not a current whole-source scanner pass, clean-source CI, generated/RI, hosted behavior or release eligibility.

| Input | SHA-256 |
| --- | --- |
| `issue169-checksum-proposals.json` | `addd7e31ccde16ed41271f1d2fa4104c25784b733f199cde29079756c1a4cc18` |
| `release-detect-secrets.json` | `b4e62aaa58541eeebde82d008097b4cdd71af0d5c544d0d0dad4841b418df7d0` |
| `triage_issue169_checksums.py` | `2cfb960b6e5e61a5eadf645ae3b0d9ae223ea19bf7bb0440fa15d40e2e4f08df` |
| `tools/quality/secrets-reviewed-checksums.json` | `072081727976ef774fa3b35d229a8741b2df1d67dbd32ee86bebe35f3f362fc6` |
| `tools/quality/secrets-reviewed.json` | `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb` |
| `tools/quality/scanners.cjs` | `c6a6f63965ffe668f40549ae779e40c76fca06e30937ef75b80d0474e5de8188` |
| `tests/quality-sources.test.cjs` | `39c3972ab04f741493ba3a0079b5d5b0b55b11a9c615197e5da506ab316d8d15` |

The checksum ledger grows from 1,722 to 2,109 rows: 386 Hex plus one separately guarded Base64 tuple. The general ledger grows from 4,367 to 4,368: one Secret Keyword prose false positive. Both preserve every old record, order and metadata against `git show HEAD`; their diffs append entries with only the necessary separator change to the former final record. Byte sizes are 1,227,081 and 1,999,782 respectively, within the unchanged 2,000,000-byte loader cap. The additions exactly equal the 388 unique proposal tuples; no extra, missing or duplicate tuple was found.

## Independent proof audit

For every one of the 388 rows, independently verified that the current exact source line contains the supplied literal, its SHA-1 equals `hashedValue`, and raw detector path/type/hash/line accounting agrees. The raw-scan digest also matches the proposal binding. All dispositions were examined through these checks, rather than sampled.

Independently checked the substantive proof classes:

- 204 SHA-256 values against actual current files and 38 against accepted R3 artifact files.
- 96 historical assertions against their literal occurrence in exact predecessor `bd70996a386665e14f87440653e3a107fed15e43` source. These prove preserved historical assertions, not that historical observations are fresh acceptance.
- 19 Git-object occurrences via actual local commit-object lookup.
- Eight prepared-source occurrences by reconstructing six distinct source hashes in memory from the actual base plus retained original/v2 unified diffs. Verified patch context and final SHA-256; no temporary checkout or authored script execution was used.
- Four predecessor producer-hash occurrences and two Writing SVG hashes directly from exact Git source bytes; three current identity fields against their exact structured-data owners.
- Eleven native AST/material/notice/production identity occurrences by recomputing the existing publisher, semantic block, edition notice and material-binding owners, or reading the exact preserved/current reviewed runtime descriptors. The production-runtime byte equivalence was independently established in the earlier correction review and is not broadened here.
- The one Base64 finding is the existing immutable-directory catalog key at line 13030; the other path-derived Hex occurrence recomputes the key’s SHA-1. Both remain exact public-path classifications.
- The sole Secret Keyword row was independently reproduced with the actual KeywordDetector against only its source line. Its extracted value is prose naming `reviewedSecretFinding`, scanner/test functions and historical source hashes; no credential is present. This does not validate the surrounding review’s conclusions.

No unexplained proof row remained in this 388-row audit. The proof script’s fallback to predecessor literals was treated as historical-assertion evidence only, never as current equivalence or publication proof. Its generated-proof/RI exclusions do not themselves supply whole-source scanner success in this report.

## Admission and meaningful refusals

Loaded all closed current ledgers through the actual scanner schema/duplicate/size validation. Independently verified exact runtime admission for all 388 tuples and rejection of 1,164 mutations (changed path, unsupported detector type and changed hashed value for each row). The separately reviewed Base64 exception still requires the exact checksum-ledger entry and complete known tuple; no generic catalogue/Base64 exemption, detector/input/threshold/budget change or encoded path was added. The previously inspected missing-ledger/schema negative tests remain applicable; no test campaign was repeated.

## Limits and remaining gates

These are append-only false-positive dispositions for exact bytes/tuples, not a general secret-detection guarantee. Historical prose and checksums retain historical status. The prior stale datasets are not accepted by this result. The final current-source scanner must still run with fresh generated/RI identities and report its own complete accounting; source CI, hosted/staging and production/release gates remain separate. Any changed reviewed ledger/source/proof identity needs affected re-review.
