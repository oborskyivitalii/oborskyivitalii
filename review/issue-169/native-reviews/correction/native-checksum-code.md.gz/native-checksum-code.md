# Independent Code review — 25 native checksum dispositions

Reviewer `/root/correction_code_clean`, continuing the nonauthor Code role. **No blocking finding in the 25 exact proposed Hex false-positive classifications.** This review accepts the proposed per-row public checksum classification; it does not assert that a ledger has been appended or that the final scanner/CI/hosted gates pass. No implementation, external writes, delegation or full scanner campaign occurred.

## Bound primary inputs

| Material | SHA-256 |
| --- | --- |
| `native-checksum-proposal.json` | `63651ad13e7a7778be1a5727a0e90d7cd2b0e63bdde4e3d356e6f665036975e5` |
| `prepared-release-secret-scan.json` | `dce5a84dbdc7e82aea7bea5f78a4a6c97605fad7f4fa352f69dcc6a9777d2b22` |
| `prepared-release-secret-component.json` | `ddd40f1a1b58da33c5add0a96953be8267619f7a05f96bfe67f998345151c3b5` |

The component diagnostic reports source signature `f8722f039ccec34d0b837b1d111fc2b438230f5ef73cfdfb3052a7f9a799bf1b` before and after, `sourceChanged:false`, 1,491 tracked text files and 355 generated admissions. Its 25 unknown tuples exactly equal the proposal set. I independently verified these primary bindings; this does not upgrade the component diagnostic to full security or clean-source acceptance.

## Complete per-row proof audit

Every row was checked, not sampled: exact current file SHA-256, exact line SHA-256, literal occurrence/context, SHA-1 of that literal, full path/type/hash ID, and matching raw detector line/type/hash. All are Hex High Entropy String findings. No unexplained or duplicate row remained.

| Rows | Independently checked semantic basis |
| --- | --- |
| 1–2 | Old inactive raw snapshot’s engine/site-route metadata matches its exact retained immutable runtime and snapshot directories; retained bytes/rights entries validate. This is historical prepared-rendition identity, not current runtime or prior publication acceptance. |
| 3–4, 11–12 | Recomputed current selected article’s stable public material binding `17067f…` and exact edition-rights notice digest `034cb5…` through `articles.select`, existing material loading and `editionNotice`; producer source hashes match. Both document copies contain those exact fields. |
| 5–8 | Before pins recomputed from `git show bd70996a386665e14f87440653e3a107fed15e43:tools/build_site_previews.cjs` and `:tools/site/offline.cjs`; after pins match actual current producer bytes. |
| 9–10 | Current client `c36b28…` independently derived by builder fingerprints. Current raw article version `bcad10…` independently recomputed from actual components, sorted public source digests, rendered native input, metadata and exact versioned/nonpreview flags; agrees with the current descriptor and retained metadata. |
| 13–18 | All six retained-manifest/rights occurrences match their actual public and source-retained archive, navigation or native HTML bytes plus exact structured hash fields. |
| 19–24 | Current client, archive/navigation byte hashes and three edition fingerprints match the exact measured descriptors and actual runtime/artifact bindings already independently reviewed. Every referenced structured field was read and matched; no unknown runtime family or publication-rights waiver was introduced. |
| 25 | Exact known current client in the compatibility guard agrees with the independently recomputed current client and validated retained runtime. This activates existing document-hook validation; it does not authorize a generic client. |

Checked every supplied primary proof: 22 immutable-directory relationships, 21 actual-file hash relationships, 85 structured declaration-field relationships, two Git predecessor pins and four material/rights derivation occurrences. All 50 current source-retained file hashes also match both retained and rights manifests. The two raw document generations retain their distinct identities/status.

The first independent version-digest diagnostic used unsorted input keys and therefore did not match the producer. I inspected the canonical `fileDigests` owner, corrected only my read-only diagnostic to its actual sorted-key contract and obtained the exact `bcad10…` version. This was a diagnostic serialization error, not a product failure or source change; no campaign was rerun.

## Bounded admission and refusal audit

The accompanying `native-checksum-code-negative-audit.json` contains all 25 per-row outcomes and their source/line bindings. Actual current closed ledgers refuse all 25, confirming that these remain proposals. A separate in-memory map with exactly those proposed full IDs admits all 25. Missing-ledger admission is refused for all 25; changed path, unsupported type and changed hashed value are refused for each row (75 mutation refusals). The projected map is explicitly not an actual appended ledger or a schema-authority change. Existing closed-ledger schema/loading, detector input scope, thresholds and caps were not changed.

Current checksum ledger remains 2,110 rows / 1,222,298 bytes, SHA-256 `06c641a4d0beff0e53489fbbed21f751a1bd535233a7a53373c6d06f042233eb`. General reviewed ledger remains 4,368 rows / 1,999,782 bytes, SHA-256 `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb`. Both are unchanged by this review and remain below the unchanged 2,000,000-byte cap. Only the checksum ledger needs the proposed append; all existing rows/order/metadata must be preserved when applied.

The final appended-byte identity, refreshed RI/source accounting, complete scanner/CI, current hosted behavior and production/release gates remain separate. Source/literal/proof changes require affected re-review.


## Subsequent actual append check

The initial proposal and projected-map audit above is preserved. After that audit, the orchestrator appended the exact 25 rows. Independently inspected the actual current ledger, loaded it through the closed schema/duplicate/size guard and verified the ordered appended IDs exactly equal the reviewed proposal, with no extra row. It now has 2,135 rows / 1,238,968 bytes, SHA-256 `36b5ebb2cd21ed9d1c2d30a10c8d524f53fb4b751bc32a5773b9d9335935946b`.

Reconstructed the prior ledger bytes by retaining its first 2,110 rows and unchanged metadata under the same JSON serialization. The reconstructed bytes are exactly 1,222,298 bytes and hash to the independently captured preappend SHA-256 `06c641a4d0beff0e53489fbbed21f751a1bd535233a7a53373c6d06f042233eb`. This independently proves preservation of the complete prior parsed data/metadata, beyond trusting the append receipt.

All 25 exact tuples are now admitted by the actual loaded ledger; all 75 changed path/type/value cases remain refused. The general ledger remains byte-identical at `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb`, 1,999,782 bytes. The initial `native-checksum-code-negative-audit.json` is unchanged; additional actual outcomes are recorded in `native-checksum-code-append-audit.json`. No blocking finding in the actual append; no new guard or detector change was needed. Final complete scanner/source/CI/RI/hosted/release gates remain separate.
