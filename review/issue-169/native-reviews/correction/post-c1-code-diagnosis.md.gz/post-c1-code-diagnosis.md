# Independent Code diagnosis — failed C1 source campaign

Reviewer: `/root/correction_code_clean`, nonauthor Code role. Source HEAD `3044b5cae6c95929267838751a9161262d589849`, tree `f409f9017c825dfb26b8f2238cc7a2be6a74d5e2`; observed clean checkout and report’s clean before/after identities agree. Inspected only the assigned article-media/site-articles failures and necessary actual producer owners, not other reviewers’ results. No implementation, external writes, delegation or campaign rerun occurred.

The 300,000 ms source campaign is **failed and incomplete**: its report has no final aggregate test accounting. Emitted passes and completed wrappers do not establish a full-source pass. This report diagnoses the visible assigned failures and proposes bounded treatment before another campaign.

## 1. Real standalone producer regression: article resolved twice as different document kinds

Severity: blocking for the existing standalone/export acceptance surface. TAP records `tests/article-media.test.cjs:128` failing at line 170 inside `exportArticle`, not at `verifyCandidateSource`. Candidate-source verification and its purpose/declaration negatives precede that export call and completed; the actual stack is:

`exportArticle` → `renderInteractive` → `offline.inlineFallback` → `resolveRouteResource` → “Room fallback resource closure differs”.

Mechanism: `tools/build_site_previews.cjs:303` first calls `offline.inlineAssets(source, environment)`. `tools/site/offline.cjs:301` resolves the selected article’s content-addressed Writing SVG into its exact inline paths. The producer then calls `renderInteractive(..., 'writing', ..., environment)` at line 305. Its line 138 unconditionally resolves that already-inline article as the principal Writing room. The room descriptor now declares a one-resource carrier and correctly requires a single `<use>` closure; expanded article geometry no longer has that representation. The strict resolver is behaving correctly. The error was exposed by Writing’s new principal resource, but the defect is document-kind dispatch/ordering in the shared standalone producer.

A compact read-only probe on the actual selected SDLC document reproduced the mechanism: article-mode `inlineFallback` expands the original use; a second explicit room-mode call throws the exact TAP error; repeating article mode is idempotent. No synthetic replacement document was used.

Minimal treatment: preserve the actual exporter and route/model sources, but make `renderInteractive` distinguish its explicit selected article environment from principal-room mode (or otherwise avoid the second room resolution after article resolution). Keep strict room closure verification, selected-article asset ownership, passive SVG validation, hashes and budgets intact. Do not patch the candidate-source verifier or relax `resolveRouteResource`. Verify the existing failing export plus an actual native article rendition, and preserve unknown-resource/corrupt-byte negatives.

## 2. Fixture assertions conflate candidate leakage with declared retained/principal resources

Severity: failing acceptance tests requiring oracle correction; no demonstrated builder leakage. `tests/site-articles.test.cjs:423` fails at line 429; line 556’s rename/deletion case fails at line 572.

The helper `filesWithoutPrincipalResources` (line 415) excludes only `revision.routes.research.assets`. The tests then require no path matching `/article|publications/` or starting `article-`. Their fixture copies the actual source-retained inventory before isolating the catalog and draft sources. The builder’s existing `retain` validates every declared immutable name/hash and emits it independently of current catalog selection. Therefore nine legitimate predeclared native retained entries (eight media including the shared fallback, one final raw snapshot) remain present; the new Writing principal resource also shares the `article-media/` namespace. These names satisfy the broad absence predicates even with `ordinary.articles` / `deleted.articles` correctly empty. Catalog isolation does not authorize deleting source-retained inputs.

Minimal treatment: exclude the complete verified principal-resource union across all five routes, plus only the fixture’s exact predeclared retained source inventory, after checking actual emitted hashes equal those declarations. Apply draft-leakage absence assertions to the remainder. Keep assertions that the synthetic candidate has no ordinary descriptor/body/listing, that its alias disappears after deletion, and that its unique undeclared asset/snapshot is absent. Do not ignore the entire `article-media` / `article-snapshots` namespace, derive exemptions from arbitrary current candidate descriptors, or drop the actual retained inventory. Cold/incremental equality and accepted rename/history/staging-isolation tests remain substantive guards.

## 3. Additional actual native-export limit observed during the diagnostic

Severity: blocking if the actual SDLC standalone rendition is required; separate from the template TAP failure. The first real-document probe reached `offline.inlineAssets` and immediately failed “Unsupported standalone article resource” at `tools/site/offline.cjs:229`. Actual selected SDLC media includes `hero-web.jpg`, whereas `offline.assets` permits only png/webp/pdf plus the Writing SVG and maps image MIME only to PNG/WebP. The PNG/WebP template does not reveal this JPEG path. I then isolated fallback resolution without invoking `inlineAssets` to establish finding 1 independently.

Minimal treatment if native standalone export is in the accepted surface: admit the already source-validated finite JPEG format through the existing asset/MIME path, preserving exact digest, size, selected closure and native rendition bytes; test a real JPEG-bearing article with matching `image/jpeg`, corrupt-byte refusal and unchanged budget. Do not substitute the current article or its hero with a fabricated PNG fixture to make delivery green. This diagnosis does not assert that fixing JPEG alone completes the real native export; the real export must then reach and verify its remaining checks.

## Source and evidence binding

| Material | SHA-256 |
| --- | --- |
| `tools/build_site_previews.cjs` | `54ca6b30753cf343f906b9aa1d551a96212136a4882ec047c56a186e831285e6` |
| `tools/site/offline.cjs` | `04970b8c3718d886e2884e2ce63e488aea7a20aebce0bed8778cc7ff8e5288be` |
| `tests/article-media.test.cjs` | `b0faec6a06f9da681f17017d0cb7bc59e52b989e91cf5def5266a678f3408622` |
| `tests/site-articles.test.cjs` | `e658e65b7617c1342d3b86c38b82445ed145a8bed7b0407e2ad441151803a683` |
| `site/retained/manifest.json` | `63419a290f8266e5765b8871c45ef072405e7dd1aa22687a09a427027fc4d5c6` |
| `pr-source-release.json` | `0074f2f5ac212ffd76c16781d8fd1f573bd905bb6a4a94c8e3a4dc08bb69a136` |
| `pr-source-release.tap` | `951016e6f1a3ee5c1fa15c340d6d29d6c89bf642b0c8d2f97ae18bdaace3845d` |
| `pr-source-release.stderr` | `9f6b1cbdb9750c5db0cb753884977d8fd6b98f3233f658f8be2ce444c53d7203` |

The two compact probes were read-only and together ran under two seconds. Other failed modules, the unfinished publication-records module, the RI metadata diagnostic, final source accounting and hosted/release gates remain outside this result. No fix is accepted until its affected source and meaningful negative oracles are reviewed and checked.
