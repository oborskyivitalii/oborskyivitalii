import hashlib,json,re,subprocess,tempfile,sys
from pathlib import Path
root=Path('/workspace/scratch/dbe331636386/native-r3'); evidence=root.parent/'native-r3-evidence'
files=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().strip('\0').split('\0')
text=[p for p in files if (root/p).is_file() and not p.endswith('.gz') and b'\0' not in (root/p).read_bytes()]
scan=(evidence/'release-detect-secrets.json').read_bytes() if '--reuse-scan' in sys.argv else subprocess.check_output([str(root/'tools/quality/toolchain/venv/bin/detect-secrets'),'scan','--no-verify',*text],cwd=root,timeout=90)
(evidence/'release-detect-secrets.json').write_bytes(scan)
js=r'''const fs=require('fs'),s=require('./tools/quality/scanners.cjs'),g=require('./tools/quality/generated-checksums.cjs'),c=require('./tools/quality/common.cjs');const r=JSON.parse(fs.readFileSync(process.argv[1])),old=s.loadSecretReviews(),pi=s.publicationIntegrityProof(),bi=s.browserIntegrityProof(process.cwd(),c.tools),p=g.proveGeneratedChecksums(process.cwd()),a=g.admitGeneratedChecksumFindings(r.results,p);const rows=[];for(const [f,list]of Object.entries(r.results)){if(['.github/repository-intelligence/agent-context.json','.github/ri-ci-map.json'].includes(f))continue;for(const v of list)if(!a.has(g.findingKey(f,v))&&!s.reviewedSecretFinding(f,v,old,pi,bi))rows.push({file:f,...v});}console.log(JSON.stringify({rows,generated:a.size,browserProof:bi.size}));'''
result=json.loads(subprocess.check_output(['node','-e',js,str(evidence/'release-detect-secrets.json')],cwd=root,timeout=90))
(evidence/'release-untriaged.json').write_text(json.dumps(result,indent=2)+'\n')
known={}
def remember(value,reason):
 if re.fullmatch('[0-9a-f]{40,64}',str(value)): known.setdefault(str(value),reason)
for p in files:
 f=root/p
 if f.is_file(): remember(hashlib.sha256(f.read_bytes()).hexdigest(),'SHA256 of current exact file '+p)
for p in (root.parent/'r3').rglob('*'):
 if p.is_file(): remember(hashlib.sha256(p.read_bytes()).hexdigest(),'SHA256 of accepted R3 artifact '+str(p.relative_to(root.parent)))
for file in ['site/output-lock.json','docs/site-revision.json','review/site-v1-static-previews-v11.json','review/site-v1-offline-bundle-v11.json']:
 obj=json.loads((root/file).read_text())
 def walk(v,parts=()):
  if isinstance(v,dict):
   for k,c in v.items():walk(c,parts+(str(k),))
  elif isinstance(v,list):
   for k,c in enumerate(v):walk(c,parts+(str(k),))
  elif isinstance(v,str): remember(v,'Exact current cold-generation-validated identity '+file+'#'+'/'.join(parts))
 walk(obj)
# Reconstruct both prepared correction source subsets from their actual base and patch.
for packetname in ['correction-packet.json','correction-packet-v2.json']:
 packet=json.loads((evidence/packetname).read_text())
 with tempfile.TemporaryDirectory(prefix='issue169-checksum-source-') as tmp:
  tmp=Path(tmp)
  for f in packet['files']:
   target=tmp/f['path'];target.parent.mkdir(parents=True,exist_ok=True)
   r=subprocess.run(['git','show',packet['base']+':'+f['path']],cwd=root,capture_output=True)
   if r.returncode==0:target.write_bytes(r.stdout)
  applied=subprocess.run(['git','apply',packet['diff']['path']],cwd=tmp,capture_output=True)
  if applied.returncode:raise RuntimeError('Prepared source patch reconstruction refused: '+packetname+' '+applied.stderr.decode())
  for f in packet['files']:
   target=tmp/f['path']
   if not target.exists() and (root/f['path']).exists() and hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256']:target.write_bytes((root/f['path']).read_bytes())
   if not target.exists() or hashlib.sha256(target.read_bytes()).hexdigest()!=f['sha256']:raise RuntimeError('Prepared source hash reconstruction differs: '+packetname+' '+f['path'])
   remember(f['sha256'],'Reconstructed exact prepared source '+f['path']+' from '+packet['base']+' and retained '+Path(packet['diff']['path']).name)
# Accepted native source/semantic identities are validated by the existing publisher.
js="const a=require('./tools/publishing/article.cjs').loadArticle(process.cwd(),'sdlc-out-of-balance');console.log(JSON.stringify({source:a.source.sha256,semantic:a.edition.semanticSha256}));"
for k,v in json.loads(subprocess.check_output(['node','-e',js],cwd=root)).items():remember(v,'Existing native publisher verified '+k+' identity of accepted sdlc-out-of-balance')

# Additional exact native derivations, not general entropy exclusions.
js=r"""const fs=require('fs'),a=require('./tools/publishing/article.cjs').loadArticle(process.cwd(),'sdlc-out-of-balance'),r=require('./tools/site/articles.cjs'),selected=r.select(process.cwd(),[],require('./site/content/catalog.json')).find(x=>x.key==='sdlc-out-of-balance:en'),m=require('./tools/site/article-materials.cjs'),d=JSON.parse(fs.readFileSync('site/publications/sdlc-out-of-balance/materials.json'));console.log(JSON.stringify({blocks:a.model.tree.children.map(n=>require('./tools/publishing/semantic.cjs').blockDigest(n)),renditions:selected.assets.map(v=>v.rendition||{}),notice:r.editionNotice(selected).digest,materialAggregate:selected.publicMaterials.html.match(/data-materials-binding="([a-f0-9]{64})"/)[1],materialBindings:d.items.map(i=>m.reviewBinding(d,i)),legacyProduction:require('./tools/quality/color-motion-contract.cjs').reviewedRuntime('issue159-reading-paths-production').variant.fingerprint}));"""
native=json.loads(subprocess.check_output(['node','-e',js],cwd=root))
for v in native['blocks']:remember(v,'Recomputed accepted native AST blockDigest via existing semantic owner')
for obj in native['renditions']:
 for k,v in obj.items():remember(v,'Existing source-select/codec-verified native image rendition '+k)
remember(native['notice'],'Recomputed exact native editionNotice digest')
remember(native['materialAggregate'],'Existing materials.load recomputed aggregate public materials binding')
for v in native['materialBindings']:remember(v,'Recomputed current exact public material reviewBinding using existing owner')
remember(native['legacyProduction'],'Exact preserved legacy reviewedRuntime production identity; not new admission')
identity=json.loads((evidence/'color-production-identity.json').read_text())
if not all(v['equal'] and v['actual']==v['previous'] for v in identity['runtimeComparison'].values()):raise RuntimeError('Runtime byte proof changed')
remember(identity['productionVariant']['fingerprint'],'Measured exact native Color production identity with all five runtime byte pairs equal in retained color-production-identity.json; separate admission tests preserved')
carrier=json.loads((root/'review/issue-169/writing-carrier.json').read_text())
for name,record in carrier['producerChanges'].items():
 b=subprocess.check_output(['git','show',carrier['predecessorSource']+':'+name],cwd=root)
 if hashlib.sha256(b).hexdigest()!=record['beforeSHA256']:raise RuntimeError('Carrier predecessor producer differs')
 remember(record['beforeSHA256'],'Recomputed exact Git predecessor producer '+carrier['predecessorSource']+':'+name)
oldsvg=subprocess.check_output(['git','show',carrier['predecessorSource']+':docs/writing.html'],cwd=root).decode()
oldsvg=re.search(r'<svg class="space-fallback"[\s\S]*?</svg>',oldsvg).group(0)
if hashlib.sha256(oldsvg.encode()).hexdigest()!=carrier['acceptedSvgSHA256']:raise RuntimeError('Carrier original SVG differs')
remember(carrier['acceptedSvgSHA256'],'Recomputed exact predecessor Writing SVG geometry hash')
retained=json.loads((root/'site/retained/manifest.json').read_text())
for name,digest in retained['files'].items():
 if name.startswith('article-snapshots/'):
  b=(root/'site/retained'/name).read_bytes()
  if hashlib.sha256(b).hexdigest()!=digest:raise RuntimeError('Retained snapshot changed')
  value=name.split('/')[1]
  if ('name="site-route" content="'+value+'"') not in b.decode():raise RuntimeError('Retained metadata identity differs')
  remember(value,'Exact retained immutable snapshot path/site-route identifier, SHA256 bytes bound in current retained source/rights manifests; not fresh producer or publication acceptance')

for key in json.loads((root/'.github/repository-paths.json').read_text())['entries']:
 if (root/key).exists():remember(hashlib.sha1(key.encode()).hexdigest(),'Recomputed SHA1 of exact current catalogue filesystem path '+key)

prior='bd70996a386665e14f87440653e3a107fed15e43'; old={}; proofs=[];unknown=[]
for row in result['rows']:
 f=row['file'];line=(root/f).read_text().splitlines()[row['line_number']-1]
 tokens=re.findall(r'(?<![0-9a-f])[0-9a-f]{12,64}(?![0-9a-f])',line) if row['type']=='Hex High Entropy String' else re.findall(r'[A-Za-z0-9+/]{20,}={0,2}',line)
 prose_reason=None
 if row['type']=='Secret Keyword' and f=='review/issue-169/native-reviews/correction/correction-requirements-clean.md' and row['hashed_secret']=='fa1f5b51466ca619a8a95da1ecc6bd6c6c4a7fcb':
  tokens=json.loads(subprocess.check_output([str(root/'tools/quality/toolchain/venv/bin/python'),'-c','import sys,json;from detect_secrets.plugins.keyword import KeywordDetector;print(json.dumps(list(KeywordDetector().analyze_string(sys.stdin.read()))))'],input=line.encode()))
  if 'reviewedSecretFinding' in line and 'Source SHA-256: scanners.cjs' in line:
   prose_reason='Exact keyword-plugin false positive in preserved independent-review prose naming public scanner functions and historical source checksum assertions; not a credential or current acceptance claim'

 if f=='.github/repository-paths.json' and row['type']=='Base64 High Entropy String':
  keys=re.findall(r'"([^"]+)"\s*:\s*\{',line)
  if len(keys)==1 and (root/keys[0]).exists():
   key=keys[0]
   tokens += [key[i:j] for i in range(len(key)) for j in range(i+20,len(key)+1)]
 tokens=list(dict.fromkeys(v for v in tokens if hashlib.sha1(v.encode()).hexdigest()==row['hashed_secret']))
 if len(tokens)!=1:unknown.append({'file':f,'type':row['type'],'hash':row['hashed_secret'],'line':row['line_number'],'reason':'nonunique literal'});continue
 value=tokens[0];reason=known.get(value) or prose_reason
 if not reason and len(value)==40:
  r=subprocess.run(['git','cat-file','-t',value],cwd=root,capture_output=True)
  if r.returncode==0:reason='Public local Git '+r.stdout.decode().strip()+' object identity '+value
 if not reason and f.startswith('review/issue-169/'):
  if f not in old:
   r=subprocess.run(['git','show',prior+':'+f],cwd=root,capture_output=True);old[f]=r.stdout.decode() if r.returncode==0 else ''
  if re.search(r'(?<![0-9a-f])'+re.escape(value)+r'(?![0-9a-f])',old[f]):reason='Public historical checksum/Git assertion preserved in exact '+prior+':'+f+'; historical assertion only, not current acceptance or new equivalence proof'
 if not reason and f=='.github/repository-paths.json' and row['type']=='Base64 High Entropy String':
  keys=re.findall(r'"([^"]+)"\s*:\s*\{',line)
  if len(keys)==1 and value in keys[0] and (root/keys[0]).exists():reason='Public generated immutable path fragment in exact existing catalog path '+keys[0]
 if not reason:unknown.append({'file':f,'type':row['type'],'hash':row['hashed_secret'],'line':row['line_number'],'literalLength':len(value),'reason':'needs additional exact source proof'});continue
 proofs.append({'path':f,'rule':row['type'],'hashedValue':row['hashed_secret'],'line':row['line_number'],'publicValue':value,'proof':reason})
(evidence/'issue169-checksum-proposals.json').write_text(json.dumps({'kind':'Exact current public checksum and review-prose false-positive proposals; independent review required. One known catalogue Base64 tuple uses a separately reviewed exact-ID schema/runtime correction; no detector/input/threshold/budget or generic entropy exemption.','rawScanSHA256':hashlib.sha256(scan).hexdigest(),'generatedAdmitted':result['generated'],'browserIntegrityProof':result['browserProof'],'proofs':proofs,'unknown':unknown},indent=2)+'\n')
print(json.dumps({'untriaged':len(result['rows']),'provedProposals':len(proofs),'unknown':unknown}))
