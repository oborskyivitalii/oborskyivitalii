# Requirements & Acceptance — source scheduling preflight

2026-10-31. Continuation after preserved C1 and runtime/tag preflights. No implementation, external writes, delegation or campaign rerun. Source worker before this proposed edit SHA-256 `fb99cd3aacc0e98470fcf2a4cc50fd159a54d9705bb422824fc9842c43b63945`.

**Verdict: swapping publication-records and article-media in the existing priority list is authorized as the smallest evidenced scheduling treatment.** Preserve every case, resource limit and reporting/acceptance rule. This is an evidence-supported scheduling hypothesis, not a prediction that the final full campaign will pass or finish.

## Actual evidence

Read source worker priority construction, isolated execution/concurrency/reporting/cancellation logic, existing source-tests limit owner and original raw timing. `pr-source-release.stderr` SHA-256 `9f6b1cbdb9750c5db0cb753884977d8fd6b98f3233f658f8be2ce444c53d7203` records 79 selected modules, available/configured parallelism 8 and effective concurrency 4. Article-media dequeued at 28 ms and completed at 36,486 ms (36,457.589 ms wrapper, failed). Release-rights dequeued at 49 ms and completed at 172,206 ms (172,156.985 ms, passed). Release-controller dequeued at 36,486 ms and completed at 160,974 ms (124,487.858 ms, passed). Publication-records was then dequeued at 160,974 ms, with no completion record before the 300,000 ms timeout—only 139,026 ms remained.

Actual priority is space, executive, article-media, release-rights, release-controller, …, publication-records at position 12. The worker orders the selected set using this list plus sorted remaining selected modules; priority affects start order, not selection. Limits remain source-tests.cjs `300000 ms` and `16 * 1024 * 1024` output bytes; worker uses `Math.min(4, parallelism)` process-isolated slots.

Read the bounded phase probe's primary report/phase records, not a reviewer conclusion. `post-c1-publication-timing-phase.json` SHA-256 `4730846543d9ec2604df92b8336d08cb7a934ba8ade2b4560182f926764506fd`; phases SHA-256 `adf6296d57a013e36c88bf49951dd00fa4f941e3569a41373489e7b0fc9658c3`. One selected edition-guard case completed in 18.592 s under its separate 20 s bound, with expensive repeated synchronous verification phases returning normally and unchanged relevant source hashes. Its input was explicitly dirty prepared C2 state. This supports costly synchronous work rather than a cancellation deadlock **for that bounded observation**; it does not diagnose every possible publication-records behavior or certify full-module duration.

## Required invariants and acceptance

- Swap only the two priority positions: publication-records starts in slot 3, release-rights stays in the first wave/slot 4, article-media remains selected at publication-records' prior position. The same selected 79-module set must execute exactly once; nonselected modules remain nonselected.
- Preserve four-slot ceiling, process isolation, 300 s campaign timeout, 16 MiB output bound, every assertion, mandatory suite inventory, failure/skip/TODO/cancellation/empty-file rejection, signal cleanup and complete source/report accounting. No caching, skip, retries-until-green, duration relaxation or false summary.
- Update the existing scheduling regression's explicit expected order where necessary, retaining coverage/uniqueness/concurrency checks. Keep original timed-out/partial source evidence intact.
- Verify the affected scheduling behavior and then actually complete the required final exact-source campaign with terminal accounting. If it still fails or times out, preserve it and diagnose the new evidence; reordering alone is not acceptance. Other current-source/runtime/RI/hosted/release gates remain applicable.

This changes execution economy under AC05 without changing acceptance requirements or publication intent. No new author decision is necessary. Requirements review does not supply Code/QA execution or final clean-source approval.

## Combined runtime packet — bounded current-delta requirements assessment

The supplied `post-c1-runtime-packet.json` SHA-256 is `4fe1094a8c1463433e1c736d098c28efac1ba80d8a5e4286eb01251a0f6dd327`; all nine source hashes independently matched when read. Packet explicitly describes dirty prepared source, not final clean acceptance. Inspected actual article-tags, navigation, runtime-family and tag-regression diffs against C1; no peer Code verdict was read.

The implemented tag lookup maps only exact same-origin/project-root article snapshot grammar with valid hash/slug and no credentials/query/fragment to an existing canonical index key. It preserves the original href; tests exercise root/subpath, direct alias, snapshot alias, external control and foreign/outside/malformed/suffixed nonmatches, plus teardown. This satisfies the narrowed source-confirmed AC10 correction; actual hosted native/direct tag parity remains pending.

Navigation JPEG handling extends only the existing content-addressed image filename/MIME branch; byte count, Base64 payload bounds, SHA-256 and descriptor checks remain in place. The new explicit family `issue169-native-tags` preserves historical families and inherits mandatory rights/reader behavior, with changed archive/navigation hashes and exact new base engine. It declares separate plain/staging/production fingerprints from the packet (`1f555…`, `be64c4…`, `0af8ae…`) rather than allowing unknown identities. Packet reports five-file verification for each edition; these booleans are primary assertions, not independently reexecuted byte verification by this role.

Raw packet tests are not uniformly green: `native-jpeg-tags-tests.tap` has complete 3/3; `post-c1-targeted-v2.tap` has 105 tests, 103 pass/2 fail; `post-c1-focused-v3.tap` has 8 tests, 7 pass/1 fail. The retained failures include actual reading-batch/runtime expectation and current article preview coverage. Later source fixes/results may supersede those affected assertions only with explicit final source/result binding. Do not label these packet runs successful because registration/source shape looks correct.

Requirements support the combined implemented direction without changing accepted content or security/runtime admission scope. Final current-delta independent acceptance remains incomplete: exact current clean source, all actual edition/runtime bytes, affected corrected tests, complete campaign accounting, source/RI/geometry/rights and hosted interaction observations still need their own evidence. No production-readiness or final AC completion is asserted.
