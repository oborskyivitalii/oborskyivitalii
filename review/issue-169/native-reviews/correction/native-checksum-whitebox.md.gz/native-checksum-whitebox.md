# White-box QA — 25 exact native checksum dispositions

**Scoped verdict: all 25 rows supported; actual append preserves prior data and exact refusal behavior.** No new guard, threshold, input, wildcard, cap or detector exception was introduced or accepted. This is a per-row data audit, not a full security scan or release-readiness result. No accepted source edit, external write, delegation, full scan or peer-verdict inspection.

## Inputs and chronology

Proposal `native-checksum-proposal.json` SHA256 `63651ad13e7a7778be1a5727a0e90d7cd2b0e63bdde4e3d356e6f665036975e5` contains 25 unique exact Hex findings and 17 unique public literals. Component receipt reports prepared signature `f8722f039ccec34d0b837b1d111fc2b438230f5ef73cfdfb3052a7f9a799bf1b` unchanged before/after, 355 generated admissions and 25 remaining unknowns. Independently matched all 25 proposal tuples and line positions to that unknown set and actual raw scanner findings. The prepared whole-source signature is a primary receipt; this audit independently binds every reviewed source/line/proof byte, rather than claiming to recompute an unspecified whole-source signature algorithm.

I observed the 2110-row checksum ledger before root appended. Root appended after its Requirements preflight while this independent White-box audit was pending. To preserve a distinct projected-map judgment, constructed the proposed map by removing proposed IDs from actual loaded data and adding only the25 exact proposed tuples; then separately checked actual append admission/parity. No other role's conclusion was used. This result supplies only the White-box review, not an attestation that referenced other-role reviews have executed.

## Per-row results

Every row's literal occurs in the actual current named source line; literal SHA1, line SHA256, whole source SHA256 and exact path/type/hash ID independently match. All 134 supplied proof bindings were independently checked, including actual file bytes, retained source/rights hashes, immutable predecessor Git bytes, producer SHA values and measured declaration fields. The latter were supplemented by independent owner arithmetic/actual runtime bytes, rather than accepted solely as self-asserted JSON fields.

| Proposal rows | Actual identity/context | Disposition |
|---|---|---|
|1–2| Frozen inactive 02a snapshot engine a404 and route 02a; exact retained HTML/runtime sources and hashes | Supported historical immutable identities; no fresh publication/client claim |
|3–4| Current bcad snapshot material and hosted-rights declarations | Stable material JSON binding and exact edition-notice JSON SHA independently recomputed |
|5–8| Preview/offline producer predecessor/current pins | Two immutable predecessor Git SHA256 values and two actual current producer SHA256 values recomputed |
|9–12| Retained bcad snapshot engine/route/material/rights metadata | Current client, route version and both declarations independently recomputed and matched to retained/current bytes |
|13–18| Retained manifest/rights archive, base navigation and bcad HTML hashes | All actual canonical/immutable/retained bytes and rights/source declarations agree |
|19–24| New Color family base client, archive/navigation and three edition fingerprints | Current base client math, actual five-file root/immutable closures and exact three edition descriptor fingerprints recomputed |
|25| Runtime compatibility's exact c36 client | Matches independently computed current client and validated retained five-file namespace |

All rows are accepted only as their exact public identity tuples. No unsupported row, literal mismatch or proof mismatch remained. Raw JSON contains 25 individual row receipts with exact IDs, source/line checks and proof counts.

Specific arithmetic safeguards: computed c36 client from actual builder inputs; computed current bcad article version from 18 source inputs, rendered main digest and the exact version formula; computed material binding from sorted public declaration fields; recomputed hosted rights from actual selected native article/resources/presentation; recomputed Color plain from actual effects and staging/production fingerprints from the actual producer descriptors. To observe the latter descriptors without mutation, temporarily intercepted the edition builder in the audit process only and restored it in finally; no tuple/output files were written. Actual runtime root/immutable files were independently hashed as counterparts. Frozen 02a remains qualified historical byte identity, not regenerated equivalence.

## Exact behavior and append preservation

Own bounded checks loaded the current closed ledgers and admitted all 25 projected tuples. **75 changed path/type/hash cases were refused**; all 25 actual appended tuples were separately admitted. The new data is checksum-only; the one previously reviewed catalogue Base64 exception is not broadened.

Actual appended checksum ledger: 2135 rows, 1,238,968 bytes, SHA256 `36b5ebb2cd21ed9d1c2d30a10c8d524f53fb4b751bc32a5773b9d9335935946b`. New ID set equals the25 proposal IDs exactly. Reconstructing the complete original 2110-row file from its unchanged raw entry prefix plus closing JSON suffix reproduces pre-append SHA256 `06c641a4d0beff0e53489fbbed21f751a1bd535233a7a53373c6d06f042233eb`. Thus prior records/metadata are preserved as exact bytes, not merely equivalent objects.

General reviewed ledger remains byte-identical: 1,999,782 bytes, SHA256 `d51e004bbb36d0354a0094fa5e9885bf9e9e52e19dfdd47bddd121c550f78cbb`. Both ledgers stay below the unchanged 2,000,000-byte input bound. No append or source modification was performed by this reviewer.

## Limits and evidence

No current full scanner run, generated-admission campaign, CI/profile, hosted or production pass is inferred. The component's 355 generated admissions are recorded primary evidence, not independently rerun here. Root's subsequent metadata regeneration must retain the reviewed source/data meaning and supply final current-source evidence. Earlier failed/incomplete campaigns remain unchanged. No coverage percentage or other reviewer execution is claimed.

Own raw results: `native-checksum-whitebox.raw.json`, `native-checksum-whitebox-math.raw.json`, `native-checksum-whitebox-version.raw.json`.

Evidence SHA256:

- `native-checksum-whitebox.raw.json`: `5f60158b6dc26660cf845b5620fbaf7afabc9fb6049c6fcc3e988d74b97a8f16`.
- `native-checksum-whitebox-math.raw.json`: `3f0e2633058081f64ce7012dcb76e29521aafda56e9c7128cdbc590120ce8406`.
- `native-checksum-whitebox-version.raw.json`: `5f5499078a03948e98599aad9691ea21075ec565b92bd3a945ffec25985b6c51`.
- `prepared-release-secret-component.json`: `ddd40f1a1b58da33c5add0a96953be8267619f7a05f96bfe67f998345151c3b5`.
- `prepared-release-secret-scan.json`: `dce5a84dbdc7e82aea7bea5f78a4a6c97605fad7f4fa352f69dcc6a9777d2b22`.
- `native-checksum-append.json`: `4d4516e17ef7e9bd77762ff34fd618410a3c370857f8c47fbf71807021dae913`.
