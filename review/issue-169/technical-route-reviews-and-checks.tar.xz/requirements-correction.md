# Requirements & Acceptance — correction continuation

Date: 2026-11-07. This continues this role's preserved `requirements-first.md`; it is not a fresh independent first review. Correction inputs included the orchestrator's description of RA-01's fix and the newly observed source-security failure/dispositions. No peer verdicts were read. No implementation/tests were authored, no external writes or delegation occurred.

## Inspected identity

Base `6430a8f018b68a55a7aad8b3dcc0b5a0711a8891`; current candidate `f80f06bd39e3200efe164df2c041a81a058ba413`. Verified current Git head and clean working tree at inspection. Correction packet SHA-256 `514acd8a27887c8e26d0cece157783fb0442235ed0253c56d13502037beabf55` matched; all five listed source hashes matched. Proof SHA-256 `d7126c08e8439c18b605ba1ab43441cb143493ce99eddab71aeca405812b0221` matched. Inspected actual admission/test/ledger diffs, unchanged scanner loader/admission rules, original failed report and raw detect-secrets findings. Only literal source-identity table lines 84–99 of the earlier preflight report were accessed for proof verification; its prose/verdict was not read.

## Verdict

**RA-01 resolved. The affected correction is acceptable at the requirements/source level, with no new blocking requirements finding.** The 16 new checksum dispositions have independent exact-value proof and preserve the prior ledger and scanner boundary. TR05's actual final security result remains pending in this judgment; no successful rerun, advisory campaign, native activation, bootstrap completion, ready/merge/publication or whole-issue acceptance is inferred.

## RA-01 recheck and AC impact

`tools/quality/delivery-admission.cjs:423–430` now selects the refusal action using the already computed protected `selection.repositoryOnly`. An unreviewed eligible technical head still receives `review-exact-control-head`, now with applicable source/security/RI/owning obligations and explicit website staging inapplicability. The full route still requests full checks and staging. Exact-head review, actor/event restrictions, workflow evidence selection and freshness code are unchanged.

`tests/delivery-admission.test.cjs` adds assertions for both the technical and full-route messages in the existing real-Git collection scenario. I independently ran that scenario on this exact candidate: **1 selected test passed**, exit 0, no failures/skips/cancelled/todo, 3.459 s (tool session 63284). This resolves the conflicting next action identified in the first result and restores TR07's operator guidance for AC05/AC11. It does not remove their external TECHNICAL gates.

## TR05 checksum disposition verification

The original report `/workspace/scratch/3db1b2682338/source-security/repository-security.json` remains an actual failed observation on `6430a8f`: repository-source security, website inapplicable, Semgrep passed, Bandit policy passed, secrets failed with 16 untriaged candidates. Scanner exit 0 alone was correctly insufficient for security acceptance. I did not treat this failure as a pass or an environment-only exemption.

I independently checked each of all 16 proof rows rather than relying on its `proved:true` field:

1. Read the named owner blob from immutable Git commit `183fbbee2f49736d08d1b82409692848a7a718fe` and recomputed its SHA-256 from actual bytes.
2. Matched that value and owner name to the indicated literal table line in `review/issue-169/technical-route-requirements-first.md`.
3. Recomputed SHA-1 over the literal SHA-256 string and matched the scanner's exact `hashed_secret`.
4. Matched path, detector type, hash and line to the original raw detect-secrets finding.
5. Matched the new ledger's exact path/type/hash ID and `false positive` disposition.

All 16 passed. These are public source byte identities with bounded false-positive explanations, not credentials or an unrestricted checksum exemption.

Parsed old/new ledger comparison established **all 1,790 old findings remain identical and in the same order**, including their reasons. All old top-level metadata remains equal. Exactly 16 new rows were appended, giving 1,806 findings. The file is 1,040,086 bytes, below the unchanged 2,000,000-byte per-ledger bound. Actual changed-path inventory confirms no scanner implementation, closed input-list, detector, threshold, toolchain, lock, selection/classifier or workflow edits in this correction; the active executable change is confined to the admission message and its test assertions.

Inspected `scanners.cjs` still admits only the four closed ledger inputs, regular nonsymlink bounded files, exact entry key sets, exact rule/path/hash IDs and unique IDs. Checksum ledger rules remain constrained; unrelated paths/types/hashes gain no new approval. I independently ran the existing ledger malformed-input and historical-disposition cases: **2 selected tests passed**, exit 0, no failures/skips/cancelled/todo, 0.202 s. The data comparison and raw source proof supply the correctness oracle; those tests support boundary preservation rather than certifying the appended reasons alone.

## Unchanged evidence and remaining gates

The earlier source-level review of TR01–04/06–08 is reused because technical routing, source selection/worker/Python runner, workflow definitions, scanner execution implementation and guide contracts are unchanged across this correction. Earlier full 67-test routing/admission and 3 scanner failure-propagation executions remain observations of their named `6430a8f` source; this continuation claims fresh execution only for the 1 admission and 2 ledger cases above. RI metadata changed to reflect corrected source and is not executable acceptance evidence.

| Obligation | Correction result | Still required |
| --- | --- | --- |
| TR07 / RA-01 operator action | Corrected source plus independent real-Git regression passed | Normal exact-candidate review/CI accounting |
| TR05 exact secret dispositions | 16/16 independently proven; all old rows/metadata and scanner boundaries preserved | Actual complete current-source security/advisory result; retain original failure |
| TR03 old-main full bootstrap | No admission/selection authority weakened | Native full-route integration evidence and applicable owner gates |
| TR06 reviewed SHA/App/freshness | No trust-gate change; targeted scenario passed | Live exact-head/App/native observations |
| TR08 actual activation | No activation claim made | Subsequent actual native technical run demonstrating intended omissions |

The durable final evidence archive referenced by the new reasons must contain the verified proof when packaged; scratch proof availability is not itself proof of a published archive. The orchestrator's ongoing full security rerun was not inspected as complete, so it remains pending. Live GitHub state, provider internals, App installation, website deployment and production were not observed. Preserve this correction result separately from the first judgment and bind later acceptance to the final unchanged source or perform affected re-review if it changes.
