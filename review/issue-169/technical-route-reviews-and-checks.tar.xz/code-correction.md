# Code correction review — f80f06b

Verdict: C1 is resolved. The 16 new secret-finding dispositions have independently verified public-checksum provenance and retain existing admission boundaries. Advancement is blocked by the new maintained-JSON formatting failure below. Successful current-source security/advisory and native activation remain separate gates, not inferred from this review.

## Phase and source

This is the original Code reviewer's targeted correction continuation after the first result was preserved, not a new clean first judgment. Correction instructions and author-provided factual packet/proof were received; no peer verdicts or author review conclusions were read. For checksum verification only, the 16 source-identity lines in the otherwise excluded literal requirements preflight were programmatically checked for owner path and digest; its conclusions were not consumed.

- Execution: `/root/technical_final_code`; nonauthor, read-only source/checks, no external writes/delegation; only assigned review artifact written.
- Previously reviewed candidate/base: `6430a8f018b68a55a7aad8b3dcc0b5a0711a8891`.
- Correction HEAD: `f80f06bd39e3200efe164df2c041a81a058ba413`; tree `625fae6eaa8ee0f0ad106843e8a9366446ab486e`. Initial status clean, verified directly.
- Correction packet SHA256: `514acd8a27887c8e26d0cece157783fb0442235ed0253c56d13502037beabf55`.
- Correction diff SHA256: `a6baf3faa29d712997c492ef0c281e48980fc5f5afcd71cf9cc5d4ad35ec4e84`.
- Checksum proof SHA256: `d7126c08e8439c18b605ba1ab43441cb143493ce99eddab71aeca405812b0221`.
- All five correction packet file digests verified. Common/role prompts and unchanged source assessments reuse the preserved first review; no changed prompt or source contract was supplied.

## Resolved C1

`tools/quality/delivery-admission.cjs:425–430` now chooses its next-action message using `selection.repositoryOnly`. Technical selection retains the exact reviewed SHA instruction and required source/security/RI/owning work while explicitly marking website staging inapplicable. The full route retains its full checks/staging instruction. Control trust, workflow evidence and review enforcement are unchanged.

The existing real-Git collection test now asserts both technical and full-route recovery messages. Fresh targeted execution with pinned Node24.19.0:

`node --test --test-name-pattern='real Git collection keeps candidate bytes' tests/delivery-admission.test.cjs`

Exit0, 1 test, 1 pass, zero failure/cancellation/skip/todo, duration1217ms. Its existing exact/no/stale reviewed-SHA and failing-source assertions also executed within the selected scenario.

## New finding C2 — blocking required formatting failure

Severity: medium acceptance/check blocker, no identified runtime security bypass.

Location: `tools/quality/secrets-reviewed-checksums.json:12538–12554`, newly appended16 single-line objects and closing array layout.

Evidence: the file is maintained JSON in the actual `sourceInventory`, and is not one of the frozen ledger exclusions in `tools/quality/format-scope.json`. Pinned Prettier3.6.2 directly reports it as unformatted:

`/workspace/scratch/2a813bd5ee7b/node-v24.19.0-linux-x64/bin/node tools/quality/toolchain/node_modules/prettier/bin/prettier.cjs --check --config tools/quality/prettier.config.json tools/quality/secrets-reviewed-checksums.json`

Exit1: “Code style issues found in the above file.”

Mechanism/impact: the correction appends minified authored configuration instead of the maintained two-space expanded JSON format. Required formatting in `.github/workflows/site-checks.yml` therefore cannot pass on f80. Affects TR04 and CS05/CS08 under AC05. The lack of whitespace warnings from `git diff --check` does not satisfy maintained formatter requirements.

Treatment: format the added ledger entries/closing layout, preserve the exact parsed JSON and all1790 prior finding records/order/reasons, then rerun the narrow formatter check and rebind generated source identities. Retain the f80 failed result. Parent has acknowledged this finding and will do a subsequent formatting-only correction after active source-bound campaigns finish; that change has not yet been inspected here.

## Independent per-value security verification

All16 rows in `technical-review/checksum-proof.json` were independently verified rather than trusting their `proved` flags:

1. For each named owner, read its immutable Git blob at `183fbbee2f49736d08d1b82409692848a7a718fe` and recompute SHA256.
2. Confirm that exact digest and named path occur at its actual recorded literal report line84–99.
3. Recompute SHA1 of the digest text and match the scanner's `hashed_secret`.
4. Match exactly one original raw `detect-secrets.json` row at the same path/line/type/fingerprint.
5. Match exactly one appended disposition with that path/type/ID and `false positive` disposition.
6. Confirm the previous ledger rejects that exact finding and the unchanged current admission function admits it through the newly appended row.

Result: 16/16 independently proved, each is a public source-file checksum; no credential, broad type/path allowance or detector exemption was found.

Compared parsed ledger before/after: all1790 prior rows, order, reasons and complete top-level metadata are identical; exactly16 new rows are appended. Actual closed `loadSecretReviews()` succeeds; updated ledger size1040086 bytes remains below the existing2000000-byte bound. Byte-compared the unchanged scanner, rules, other three ledgers, format owner/scope, test registry, routing code and workflow against6430a8f: ten control files identical. Thus detector/input/threshold/schema/size boundaries did not change.

Verified all four retained raw engine report byte counts/SHA256 against the failed source-security report, including raw detector report SHA256 `4d20f0faeb071336ffb3a300c728f5c131f46aeab328655e9a8e9a12344bbfc0`. The source report binds6430a8f/tree86a3fcdb and remains `pass:false`: Semgrep engine passed, Bandit engine passed via its existing triage, secrets failed with16 untriaged candidates. Those are retained observations at the original source, not a successful f80 security result.

One auxiliary unchanged-file check initially hit Node's default child-process stdout buffer (`ENOBUFS`) on the >1MB frozen baseline. This was check instrumentation, not source failure; increasing only that read's buffer to4MB completed the same bounded comparison. No implementation or acceptance campaign was rerun on that basis.

## Limits

Inspected actual correction diff, changed admission/test/ledger sources, proof and raw reports. The altered author review narrative remains outside the code-review scope. `git diff --check 6430a8f f80f06b` passed. This reviewer did not run the ongoing full security/advisory campaign, enduring Python/owning suite, hosted staging or native activation, and does not claim their success. The new ledger reason's archived proof destination must be delivered with the final evidence package; this review used the byte-verified local proof supplied in the packet. First-review findings and limits remain preserved, with C1 closed and C2 open for the next correction.
