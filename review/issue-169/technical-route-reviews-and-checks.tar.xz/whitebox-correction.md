# White-box QA — correction result

Verdict: no blocking defect established in this correction. The recovery message now follows the selected lane without changing eligibility or exact-head trust. The sixteen ledger additions admit exactly their proved path/type/value triples. Security rerun is pending and is not claimed passed.

This follows the preserved whitebox-first.md judgment; it is a correction continuation, not a fresh isolated first review. Inputs: base 6430a8f018b68a55a7aad8b3dcc0b5a0711a8891, candidate f80f06bd39e3200efe164df2c041a81a058ba413, correction-packet.json SHA256 514acd8a27887c8e26d0cece157783fb0442235ed0253c56d13502037beabf55, checksum-proof.json SHA256 d7126c08e8439c18b605ba1ab43441cb143493ce99eddab71aeca405812b0221. Packet and all five listed source hashes were independently verified. HEAD matched the candidate and git status was empty. No peer judgments, MEMORY, or author review prose were inspected. For checksum provenance only, a script tested the sixteen named immutable report lines for owner/hash binding and emitted no line contents.

## Risk, scenario, oracle and actual outcome

| Risk / affected requirement | Scenario and independent oracle | Actual outcome |
| --- | --- | --- |
| TR06 trust broadening through recovery correction | Inspect the complete admission delta: only nextAction text may vary; blockers, reviewedControl and selectedRoutes must remain identical | Only the repositoryOnly ternary constructing the message changed; trust and route logic unchanged |
| TR06/TR07 contradictory technical recovery | Existing real-Git admission fixture: unreviewed technical test change must remain blocked on review-exact-control-head while saying website staging is inapplicable | Passed, including new message assertion and existing absent/stale/exact-head and source-workflow failure assertions |
| TR02 full-route recovery | Same maintained fixture: full control change must retain full-check/staging instruction | Passed, including new full-route message assertion |
| TR05 hidden widening of old secret allowances | Parse previous/current ledgers; compare non-findings metadata and exact previous findings prefix, preserving order/reasons | All 1,790 previous rows and metadata identical; exactly 16 appended |
| TR05 false public-checksum attribution | For every proof row independently hash named Git183fbbee blob with SHA256, then SHA1 the literal digest to reproduce scanner identity | 16/16 source hashes and scanner identities reproduced |
| TR05 mismatched source location | Verify each immutable candidate report line contains the named owner and exactly the proved 64-hex digest | 16/16 bindings passed; no report prose emitted |
| TR05 overly broad exact dispositions | Load actual candidate ledgers through scanner API; each new exact path/type/hash must admit | 16/16 admitted |
| TR05 negative guards | For each new row change path, rule to Secret Keyword, or hashed value independently; none may admit | 48/48 refused |
| TR02/TR05 altered scanner authority | Compare scanner implementation, security-rules, registry, routing and source runner blobs between base and candidate | Identical bytes; closed ledger input list, exact matching and 2 MB ledger bound unchanged |
| TR01–TR04 unaffected routing | Compare routing, runner, worker and site-checks workflow across correction | Identical bytes; prior bounded routing/bootstrap evidence reusable |

## Executed checks and accounting

Pinned Node: /workspace/scratch/2a813bd5ee7b/node-v24.19.0-linux-x64/bin/node.

Executed command:

`node --test --test-name-pattern='real Git collection keeps candidate bytes|closed secret ledgers|secret review' tests/delivery-admission.test.cjs tests/quality-sources.test.cjs`

Observed completion: exit 0, 2 tests, 2 passed, 0 failed/cancelled/skipped/todo; duration 1,862 ms. Raw result chunk cd7f70. This is the correction's fully accounted targeted run; the first review's unaccounted launch remains unaccounted in its preserved record.

Independent stdin Node program loaded actual endpoint ledger JSON, asserted packet/source hashes, compared metadata and 1,790-row prefix, recomputed sixteen Git-source SHA256 and scanner SHA1 values, loaded the actual scanner API, exercised 16 positive and 48 negative admissions, and compared unchanged critical blobs. Exit 0; raw chunk faf3e3. Separate line-binding program: 16/16, exit 0, raw chunk fefb75. Source identity and unchanged workflow/runner/worker comparison: exit 0, raw chunk 3756f3.

Existing regression allocation remains tests/delivery-admission.test.cjs and tests/quality-sources.test.cjs in affected PR source tests, site-checks/checks, per SITE-CHECK-PROFILES. The exact value proof belongs with the retained technical security evidence; broad scanner/provenance exemptions are unnecessary. No maintained tests were authored by this reviewer.

## Reused evidence and limits

Reuse the first review's fourteen selection cases, obligation invariant and protected-main bootstrap observation because relevant routing/observer/runner/workflow bytes are unchanged. The first review's native activation, full Python and actual scanner/advisory execution limits remain. This correction does not establish Semgrep/Bandit/secrets rerun success; the supplied initial failed security result must remain retained. The added exact dispositions address proved public digest findings without changing scanning rules, inputs, thresholds or policy bounds. Actual subsequent technical native execution and website inapplicability remain external observations under TR08.

No production source, maintained tests or external services were modified. Temporary fixtures created by existing tests were cleaned by their existing teardown. No delegation occurred.
