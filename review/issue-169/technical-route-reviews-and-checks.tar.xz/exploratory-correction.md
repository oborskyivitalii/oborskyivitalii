# Exploratory / Interaction QA — correction review

Verdict: ACCEPT the inspected correction; E1 is resolved. No new exploratory finding in the bounded delta. This is acceptance of operator guidance and exact checksum dispositions, not native activation, a full security campaign pass or repository release acceptance.

## Sources and chronology

Same independent nonauthor task `/root/technical_final_exploratory`, correction phase on 2026-11-07. First judgment remains intact at `technical-review/exploratory-first.md`. Correction instructions, immutable diff and neutral proof were received after that first result. No current peer verdicts were read; no implementation, external writes or delegation occurred. For the newly authorized checksum proof, only the named literal checksum lines84–99 of the requirements report were accessed programmatically; no surrounding author/preflight conclusions were read. This is a continuation of the original reviewer, not a newly fresh context.

Candidate `f80f06bd39e3200efe164df2c041a81a058ba413`, delta base `6430a8f018b68a55a7aad8b3dcc0b5a0711a8891`; verified local HEAD and clean worktree. Correction packet SHA256 `514acd8a27887c8e26d0cece157783fb0442235ed0253c56d13502037beabf55`, diff SHA256 `a6baf3faa29d712997c492ef0c281e48980fc5f5afcd71cf9cc5d4ad35ec4e84`; all five packet file hashes matched actual candidate bytes. Proof SHA256 independently matched `d7126c08e8439c18b605ba1ab43441cb143493ce99eddab71aeca405812b0221`.

Common and role prompt identities remain respectively `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` and `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`. Original packet/instructions and limits remain applicable. Launch parameters/provider internals are not independently visible to this execution; retain the original orchestrator launch receipt.

## Actual charter and results

Bounded correction charter: rewalk missing/wrong/exact reviewed_sha recovery; confirm excluded controls and bootstrap remain full-route; challenge each new security disposition with changed path/rule/value and prove the immutable public checksum identity. Runtime is Linux/Git/pinned Node24.19.0. APIs and real temporary Git fixture interactions remain the actual surface. Browser/device work remains reasoned inapplicable to this technical delta, never passed website acceptance.

Ran existing four bounded admission cases through the name pattern `real Git collection|repository consumers require|head moved after selection|eligible App checks`, using an in-memory wrapper to capture actual exported collect results and additional semantic assertions. No accepted test/source modifications. Result4 passed/0 failed,1246ms. Raw exec chunk `41b87c` contains actual readbacks:

| Operator journey | Expected | Actual |
| --- | --- | --- |
| Ordinary technical test modification; no reviewed_sha | Block, exact head recovery, website inapplicable | Blocked repository lane; retains source/security/RI/owning; says website staging inapplicable |
| Same delta; stale reviewed_sha | Same refusal and recovery | Same correct blocked repository lane |
| Same delta; exact reviewed_sha | Eligible repository snapshot; no hosted dependency | Eligible repository snapshot, no blockers |
| Excluded executable wrapper; missing/stale reviewed_sha | Full-route refusal and staging guidance | Blocked current-full-route; full checks and staging still required |
| Wrapper with exact reviewed_sha | Full-route obligations remain | Existing fixture verifies5 evidence items/full staging route |
| Required source workflow fails | Refuse | Existing real-Git fixture assertion passed |
| Moved head, wrong App/attempt, missing durable upload/fresh finalization | Retain trust boundaries | Existing three named trust tests passed |

The correction's added assertions cover both technical and full branches. Additional wrapper assertions checked that recovery includes the actual candidate commit and that each staging phrase matches repositoryOnly. E1 is resolved at `tools/quality/delivery-admission.cjs:425–430`; no weakening of exact-head attestation was observed.

Invoked the actual protected selection API twice against immutable refs. Both the full corrected enabling candidate versus protected-main snapshot312fbe43 and the correction-only admission/security-policy delta versus6430a8f returned repositoryOnly=false, technicalRepository=false and required hosted H/H-PREVIEW. Thus neither the bootstrap nor the new scanner-ledger change acquires the technical exemption. Raw exec chunk `9204f1`.

## Security disposition boundary

Independently recomputed all16 SHA256 values from each named Git183fbbee blob. For every value: verified the named owner and digest at the literal report line; recomputed SHA1 of the checksum string to match scanner hashed_secret; matched exact path/type/hash/line to the original raw detect-secrets report; and matched the unique appended ledger entry. Every comparison passed. The original repository-security report remains pass=false and source-bound to6430a8f; no corrected full scan result is inferred. Raw proof exec chunks `5663bf` and `40efbd`.

Compared old/current ledgers as parsed objects: all prior findings, order, reasons and every non-findings metadata field remain identical; exactly16 entries appended. Actual `loadSecretReviews` accepted the candidate ledger. Exercised `reviewedSecretFinding` for16 exact positives and48 negatives: for every new row, neighboring path, changed detector type and unknown hashed value each remained unreviewed. Result16/16 positives and48/48 refusals. Actual scanner lookup remains exact path + detector type + hashed value; no detector-wide or arbitrary checksum exemption was introduced. Scanner implementation and configured input/rule/limit files are unchanged in this correction. Proof establishes these named public-file checksums, not absence of other secrets. Raw exec chunk `9204f1`.

## Reuse, allocation and limits

Independent blob comparison found36/39 originally packeted files unchanged. Selection/routing/Git-parser, source runner/worker and source workflow owners are byte-identical. Reuse original12-case selection exploration for unaffected registry/mode/type/rename/numeric/mixed boundaries. Re-executed affected admission coverage; newly exercised exact checksum lookup boundaries. Generated RI source-identity updates were inspected as metadata, without interpreting them as runtime acceptance.

E1 regression is now implemented in existing `tests/delivery-admission.test.cjs`, allocated through existing registry-selected source PR profile → site-checks/checks. Exact scanner-ledger boundary probes used existing exported scanner APIs locally; no new accepted test was authored. Full security/advisory/format/RI/owning campaigns remain assigned to their existing source/navigation/owning owners and require current-source results. A fresh security scan is pending in the correction packet; this review did not execute or claim it. Native old-main bootstrap and subsequent technical no-website delivery, installed App/service configuration, deployment and live protection state remain not observed here and required under TR03/TR08/TECHNICAL.

No source edits or external mutations. Only this assigned correction artifact was written. Preserve this correction separately from the first verdict.
