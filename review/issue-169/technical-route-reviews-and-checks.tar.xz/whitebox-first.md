# White-box QA — independent first result

Verdict: no blocking implementation defect established in this bounded review. TR01–TR07 have supporting structural and executed evidence below; TR08/native activation is not observed and remains an external gate. This is not whole-project acceptance.

## Identity and boundaries

Role: White-box QA, first judgment, task /root/technical_final_whitebox. Supplied immutable candidate HEAD 6430a8f018b68a55a7aad8b3dcc0b5a0711a8891, tree 86a3fcdb02d27659367bbefd4a36418f5304c559; delta base 183fbbee2f49736d08d1b82409692848a7a718fe; protected-main input 312fbe4347eda332aa8ade885b07c98beadd6da5. Local git status was empty before and after inspection. Actual provider model/context internals are unknown; no provider attestation claimed. No author handoff, MEMORY, issue169 authored review records, or peer outputs were read. No implementation, maintained tests, or external services were modified.

Packet SHA256 independently reproduced: be7f2642f5ebb8e032c37799c2b6a545104c73b5d67e603157efb03c9aa52312.
Candidate diff SHA256 independently reproduced: 8ed5474347b21fd4e17d84a5824ce7ab8261a6fc86274686bef3738c83d1220b.
Common prompt identity supplied: 2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb; white-box prompt: 832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f. Both prompts were read. Read root AGENTS/README, relevant REPOSITORY-MAP entries, CONTRIBUTING relevant routing/diagnosis/review sections, issue169 policy, changed routing/observer/scanner/workflow and tests, source runner validation, admission exact-head branches and changed profile/staging owner text. Only root AGENTS exists.

## Protected invariants and branch analysis

technicalSelection is an additional dependency disposition; it does not change control classification. A/M normal files are checked against both endpoint modes and rights sets. Existing registry rows and non-test fields are compared independently of candidate classification. Candidate registry objects are inert JSON. Any rejected record or nonmonotonic registry prevents technical eligibility. Admission retains policy.changed control attestation before selecting its first three source/repository/owning routes. Website obligations remain planned but explicitly inapplicable; they do not acquire passed evidence. Security/advisories are added as required source obligations; enduring Python stays required.

Inspected failure branches include unsupported Git modes, new unmapped modules, numeric task snapshots, modified old registry policy, changed identity path inventories, mixed runner/unknown input, protected-main bootstrap, source cleanliness/report failure handling and exact reviewed_sha attestation. Scanner wrappers use pre/post clean checks and preserve failure reports. Existing source runner independently validates actual module inventory, lifecycle/profile consistency and baseline ownership, so routing validation is not the complete source validation gate.

## Risk → scenario → independent oracle → actual outcome

The following 14 direct API cases used Node 24.19.0, real candidate registry/RI map data cloned into independent endpoint inputs, and routing.technicalSelection. Command was a node stdin program importing the candidate routing API, constructing A/M/D endpoint records, asserting eligible against each expected value, and printing all cases. Exit 0, no signal. Raw tool result chunk a90185 retains all expected/actual/rejected values; all 14 matched.

| Risk / AC | Scenario | Independent oracle | Actual |
| --- | --- | --- | --- |
| TR01 positive class | registered existing test M, 100644 | eligible | true |
| TR01 mode boundary | same file new mode 100755 | full | false |
| TR02 inventory | unregistered new .test.cjs A | full | false |
| TR01 numeric snapshot | new test_issue169_acceptance.py | full | false |
| TR02 control coupling | test M plus tools/run_repository_tests.py M | full | false |
| TR02 unknown mixed input | test M plus other.txt M | full | false |
| TR02 old provenance | test is rights input only in base | full | false |
| TR02 new provenance | test is rights input only in candidate | full | false |
| TR01 removal | existing test D | full | false |
| TR02 policy mutation | append PR shared input | full | false |
| TR02 old-row mutation | alter existing row lifecycle | full | false |
| TR02 RI compatibility | digest-only ri-ci-map refresh accompanies test M | eligible | true |
| TR02 RI path inventory | remove an identity input path | full | false |
| Existing repository disposition | test M plus README.md D | eligible repository metadata companion | true |

The last case documents interpretation of the owner wording “test deletions/renames”; the existing metadata disposition permits repository-only metadata changes. It is not evidence that test deletion is exempt. If TR02's abbreviated packet phrase intends every metadata deletion to be full, that would require an explicit scope clarification.

A further direct analyze + repositoryObligations check retained analysis.control=true; required R-PYTHON, B-SECURITY and B-ADVISORIES were all true. Hosted H/H-PREVIEW were required=false and state=planned. This protects TR04/05/06/07 at the obligation layer, without claiming actual scanners or Python ran.

TR03 independent bootstrap fixture: copied only the four protected-main observer/routing/git/json blobs into a temporary directory and loaded that old observer against the actual repository main/candidate immutable commits. Expected old-main full route; observed repositoryOnly=false, proposedLane=website, control=true, status=conservative. Exit 0; temporary files removed. Raw chunk 7a05c2. This demonstrates local old-code selection, not a hosted activation run.

## Existing checks and proposed allocation

Existing delivery-observation tests cover technical positive selection, all three exact repository tool owners, excluded controls, monotonic new registry rows, old policy mutation, deletion/rename/mode/symlink/provenance/unmapped inputs. Existing delivery-admission fixture covers absent/stale/exact reviewed_sha and failed source workflow refusal after technical selection. quality-sources tests cover source-bound scanner modes without artifact identity. These remain allocated to the maintained PR affected-source route in SITE-CHECK-PROFILES and site-checks/checks; admission fixtures protect the trusted change-admission path. Enduring Python is allocated to site-checks/checks for technical work; RI/coupling remains navigation; owning acceptance remains issue-acceptance.

Useful proposed additions (not authored or executed as maintained tests): preserve the independent base-only and candidate-only provenance partition, identity input-path removal, and old-main bootstrap as small delivery-observation regressions if existing broader fixtures do not already cover their exact combinations. Do not create a second full campaign.

## Execution accounting and limits

Executed and fully observed: 14 direct selection cases, one obligation invariant case, one old-main bootstrap integration, digest verification and Git identity/cleanliness. All completed with exit 0. No measured coverage percentage is claimed.

A targeted existing Node command was started with --test-name-pattern='technical|deleted, renamed|real Git collection' across delivery-observation and delivery-admission. Its initial call yielded no test output and its session handle was not retained in the returned reporting code. Completion and pass/fail were therefore not observed and this launch is deliberately excluded from the passing evidence. It was not blindly rerun.

No full source/Python/security/advisories campaign, GitHub Actions runner, App issuance, actual network advisory database query, production/site/browser deployment, or native subsequent technical run was performed by this reviewer. Exact-head and freshness behavior were structurally inspected; the maintained fixture outcomes from the unobserved launch are not claimed. Dynamic UI is genuinely absent from this repository-only change. Actual native activation and failure evidence remain required external observations.

No blocking finding established. Uncovered native execution limits must remain open and cannot be converted to passed ACs from fixtures.
