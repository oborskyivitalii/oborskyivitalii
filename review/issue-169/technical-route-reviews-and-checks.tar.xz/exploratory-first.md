# Exploratory / Interaction QA — first independent judgment

Verdict: REQUEST CORRECTION of one operator-facing guidance defect. Bounded selection and trust interactions passed; no admission bypass was found. Native integration/activation remains not observed and is not accepted by this review.

## Identity and source boundary

Role: independent nonauthor Exploratory / Interaction QA, task `/root/technical_final_exploratory`, first result on 2026-11-07, before peer reconciliation. No implementation, external writes or delegation. I did not read MEMORY, issue169 author/preflight records or peer verdicts. Parent launch tool parameters/provider internals are not independently visible to this execution; orchestrator must retain the actual none-fork launch receipt.

Repository `oborskyivitalii/oborskyivitalii`, issue169/PR174. Candidate `6430a8f018b68a55a7aad8b3dcc0b5a0711a8891`, tree `86a3fcdb02d27659367bbefd4a36418f5304c559`, delta base `183fbbee2f49736d08d1b82409692848a7a718fe`, protected-main snapshot `312fbe4347eda332aa8ade885b07c98beadd6da5`. Git HEAD/refs were verified locally; worktree remained clean. Live remote refs were not fetched by this reviewer.

Packet SHA256 `be7f2642f5ebb8e032c37799c2b6a545104c73b5d67e603157efb03c9aa52312`; candidate.diff SHA256 `8ed5474347b21fd4e17d84a5824ce7ab8261a6fc86274686bef3738c83d1220b`. Independently hashed all 39 packet file entries: zero mismatches. Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.

Read root AGENTS/README, reviewer common/role instructions, relevant CONTRIBUTING independence and acceptance policy, issue169 acceptance JSON, applicable map entries and source/staging/check-profile owners. Inspected actual changed selection/workflow paths, admission source and existing admission/observation fixtures. Repository map is very large; only bounded owner routing and relevant entries were relied upon, not complete comprehension of the full generated map. Runtime startup guidance read; environment-status tool was not exposed. No capability or readiness assertion is inferred from that absence.

## Charter and actual surface

Independent charter, selected before executing cases: within six minutes, walk a maintainer's regular-test maintenance journey through protected Git input selection, retained source/security/Python obligations, exact-head attestation refusal/recovery and App evidence freshness. Challenge mixed inputs, unknown tests, registry monotonicity, numeric task snapshots and Git mode/type/rename boundaries. Check the enabling candidate itself cannot obtain its new exemption.

This is repository/operator tooling. No changed website UI, rendered page, focus state or perceptual interaction exists in the candidate delta. Browser/device QA is reasoned not applicable to this bounded technical change; that does not mark any article/website acceptance passed. The applicable dynamic surface was actually exercised through exported selection/admission APIs against temporary real Git repositories and mocked GitHub responses. Real GitHub Actions, installed App, production/staging origin and post-integration native technical delivery were not exercised. Fixture/mock success cannot prove those surfaces.

Runtime: Linux shell, Git, pinned Node24.19.0 at `/workspace/scratch/2a813bd5ee7b/node-v24.19.0-linux-x64/bin/node`. All fixtures were temporary and removed; source files remained unchanged.

## Executed cases and independent oracles

Each temporary fixture copied the candidate policy inputs as inert files, committed a base, committed an isolated delta, and invoked `delivery-observation.selection(repo,base,head)`. The oracle came from packet TR01–TR07 and staging/check-profile owners: only bounded regular-test/allowlisted-tool changes select technical repository work; trust remains executable; website work becomes inapplicable; security/advisories and enduring Python remain required.

| Actual action | Expected | Observed |
| --- | --- | --- |
| Modify registered ordinary Node test | Technical/repository true | Pass, control=true |
| Add changed workflow alongside test | Full route | Pass, rejected workflow |
| Add unregistered Node suite | Full route | Pass, rejected new suite |
| Add new suite with monotonic registry row | Technical/repository true | Pass, control=true |
| Add numeric `test_issue169_acceptance.py` | Full route | Pass, rejected snapshot |
| Change test100644→100755 | Full route | Pass, rejected mode |
| Rename registered test | Full route; retain both endpoints | Pass, rejected old and new paths |
| Change an existing registry row | Full route | Pass, rejected registry |
| Add unknown mixed path | Full route | Pass, rejected unknown path |
| Modify exact allowlisted RI Python tool | Technical/repository true | Pass, control=true |
| Replace test with symlink | Full route | Pass, rejected type |
| Select actual enabling candidate versus protected main snapshot | Full route | Pass, repositoryOnly=false |

For all three positive fixture selections, additional executable assertions verified required `R-PYTHON`, `B-SECURITY`, `B-ADVISORIES` and that every hosted-category obligation had required=false. All twelve selection cases passed. Raw execution is retained in this task's tool result, exec chunk `3b81ff`.

Executed four existing admission tests through a bounded name filter: moved-head refusal, real-Git collection/exact-head review/source failure propagation, dedicated App and protected attempt consumer checks, pending-until-upload/fresh-finalization. Result4 passed/0 failed, duration4361ms. The real-Git test exercises missing/wrong/exact reviewed_sha and failed required source evidence. These are existing fixtures, not native service observations. Command: `node --test --test-name-pattern='real Git collection|repository consumers require|head moved after selection|eligible App checks' tests/delivery-admission.test.cjs` with the pinned executable above.

Then ran one targeted readback diagnostic using an in-memory wrapper around exported `admission.collect`, without source/test modifications, to capture the previously unprinted operator nextAction. This was targeted exploration of operator text after passing checks, not a rerun of a failed campaign. The single real-Git collection test passed; diagnostic output exposed the finding below. Raw tool result exec chunk `85fed0`.

## Finding E1 — medium, misleading staging recovery for eligible technical work

Location: `tools/quality/delivery-admission.cjs:423–428`, specifically nextAction string at428, newly relevant when changed selection admits executable technical deltas to the repository lane.

Actual observed readback for an ordinary registered test modification with missing/wrong reviewed_sha:

```json
{"state":"blocked","lane":"repository","blockers":["review-exact-control-head"],"nextAction":"Review the control diff, then dispatch this PR with reviewed_sha=fd4030a24f15458bc801e62d17b7bb5cffe2b171. Full checks and staging are still required.","technical":true}
```

The same journey with exact reviewed_sha produced eligible-snapshot, repository lane, no blockers, and no hosted workflow/staging dependency. Thus the error-recovery instruction directly contradicts the selected technical disposition and the documented operator route. A maintainer following it may perform unnecessary staging, defeating the user's stated outcome. Trust refusal itself is correct; no evidence that this text bypasses admission.

Affected requirements: TR07 website work explicitly inapplicable, and original intent to deliver technical maintenance without unnecessary staging; issue169 AC05/AC11 technical external gate. Treatment: make recovery guidance reflect the already selected lane, retaining exact-head review and all applicable source/trust obligations while omitting the staging demand for technical repository work. Preserve full-route guidance where staging is genuinely required. No source/test fix was authored by this reviewer.

## Regression allocation and remaining limits

| Case/risk | Existing or proposed check | Allocation/disposition |
| --- | --- | --- |
| Technical eligibility, registry, mixed paths, modes/types | Existing delivery-observation tests plus independent12-case temporary exploration | Existing `tests/delivery-observation.test.cjs` → registry-selected source PR profile → site-checks/checks; independent exploration executed only locally |
| Exact-head review, source failure, App/attempt/freshness | Existing four named admission tests | `tests/delivery-admission.test.cjs` → registry-selected source PR profile → site-checks/checks; executed locally with mocks |
| E1 recovery text matches selected lane | Proposed semantic nextAction assertions at existing real-Git admission fixture's missing/wrong reviewed_sha points, plus unchanged full-route case | Same existing admission suite/source PR route; proposed, not implemented or counted executed |
| Source security/advisories, enduring Python | Existing protected site-checks technical condition and source scanners/Python runner | Workflow/source inspected; native scanners/Python campaign not executed by this bounded reviewer |
| Actual old-main bootstrap and subsequent technical no-website run | Existing native source/navigation/owning/App delivery route, issue169 TECHNICAL gate | Native workflow/maintainer owner; not observed, remains required TR03/TR08 |
| Browser/physical-device/website delivery | No changed website surface | Reasoned inapplicable to this technical delta, never a website acceptance pass |

No full campaigns, network mutation, publishing or activation were performed. No branch protection/service state certification, measured coverage claim, security certification or general runtime guarantee is made. Source and fixture observations establish only the described bounded behavior. Preserve this first judgment intact before reconciliation.
