# Requirements & Acceptance — independent first judgment

Date: 2026-11-07. Role: nonauthor final Requirements & Acceptance. This is the first judgment on the frozen candidate, before reconciliation. No implementation/test edits, external writes or delegation were performed.

## Identity and scope

Repository `oborskyivitalii/oborskyivitalii`, issue #169, PR #174. Delta base `183fbbee2f49736d08d1b82409692848a7a718fe`; inspected head `6430a8f018b68a55a7aad8b3dcc0b5a0711a8891`, tree `86a3fcdb02d27659367bbefd4a36418f5304c559`; protected-main snapshot `312fbe4347eda332aa8ade885b07c98beadd6da5`. Worktree was clean at entry and after checks.

Verified packet SHA-256 `be7f2642f5ebb8e032c37799c2b6a545104c73b5d67e603157efb03c9aa52312` and adjacent diff SHA-256 `8ed5474347b21fd4e17d84a5824ce7ab8261a6fc86274686bef3738c83d1220b`. All 39 packet-listed source hashes matched. Read common reviewer contract and Requirements prompt, root instructions/README, repository navigation, CONTRIBUTING review/acceptance rules, acceptance policy/contract, changed runtime/workflow/tests and affected owner guidance. No nested AGENTS were found under affected tools/tests/.github/guides. Did not read MEMORY, excluded issue-169 author/preflight records or peer verdicts. Packet's original intent and explicitly accepted TR01–08 are the supplied authority; live issue/PR state was not independently retrieved in this bounded role.

## Verdict

**Changes requested for one medium operator-guidance inconsistency; source/security/trust/bootstrap implementation otherwise aligns with the supplied bounded technical scope.** This is not acceptance of native activation, bootstrap completion, PR readiness, publication or whole-issue closure. AC05/AC11 TECHNICAL gates remain pending until the finding and external evidence are resolved.

## Finding RA-01 — technical refusal still instructs full website staging

- **Severity:** medium; operator-visible requirements inconsistency, not a demonstrated admission bypass.
- **Exact source:** `tools/quality/delivery-admission.cjs:423–428`, especially line 428. This unchanged text gains a newly applicable technical-control path through changed protected selection.
- **Evidence/mechanism:** when any executable control delta lacks exact owner `reviewed_sha`, the collector correctly refuses with `review-exact-control-head`, but unconditionally sets `nextAction` to end with “Full checks and staging are still required.” Eligible technical deltas are still executable controls, so this branch applies to them. In contrast, `delivery-routing.cjs:514–554`, the changed selection, and `guides/SITE-STAGING.md:183–211` make hosted work inapplicable for that same class. The new real-Git admission test exercises the unreviewed technical refusal but asserts blockers only, leaving the contradictory action text unchecked.
- **AC impact:** conflicts with original intent to avoid unnecessary website staging and TR07's explicit website inapplicability. Exact-head trust is preserved, but the required next operator action is inaccurately specified. AC05/AC11 cannot claim a coherent completed technical flow yet.
- **Treatment:** select refusal guidance from the protected disposition. Technical repository work should request complete applicable source/RI/owning checks and exact control-head review; bootstrap/full-route work should retain full staging guidance. Have a nonauthor reviewer verify the amended behavior and a meaningful regression assertion. No change to the reviewed-SHA refusal or evidence gates is justified.

## Intent / requirement traceability

| Accepted obligation | Check or owner gate | Independently observed source/result |
| --- | --- | --- |
| TR01 bounded regular test A/M and three exact Python owners | Protected technical classifier; actual source inventory/affected suites | `technicalSelection` checks modes, A/M, exact owners and test inventory/lifecycle exclusions. Independent 67-test observation/admission execution passed. |
| TR02 monotonic registry; both sides, provenance, mixed/unknown conservatism | Registry validation, deep equality, raw Git collection; navigation verifies checksum-only RI compatibility | `inputs` parses both inert registry endpoints; prior rows/non-test fields must match; new rows require newly added regular paths. Negative registry/mode/type/rename/provenance/mixed cases passed. Existing RI-map semantics/path equality preserved. |
| TR03 enabling change uses old-main full route; cannot self-admit | Protected-base workflow checkout and selection; old-main full bootstrap remains external | Inspected main's old selection: executable control prevents repository-only. Workflow loads classifier from base before candidate checkout. Candidate vs protected-main direct diagnostic also returns `repositoryOnly:false`, `technicalRepository:false`, `control:true`. No native bootstrap execution observed. |
| TR04 affected Node, enduring Python, format/architecture/lint/RI/owning remain mandatory | Existing source workflow, navigation, acceptance workflows and independent review gates | New technical conditional runs enduring Python; existing format/architecture/local/source/lint steps remain. Source selector still validates complete actual test inventory; unchanged Python runner excludes numeric task snapshots only. Current format check passed. Supplied 142-test Python and corrected architecture logs inspected as supplementary evidence, not independently source-certified native runs. |
| TR05 locked source security/advisories without website artifact | Full pinned Python graph and verification, source scanner dispatch/reporting | Workflow installs requirements with no dependencies, verifies exact installed graph, runs both scanners in repository mode. Source scanners retain failure propagation and clean commit/tree binding; do not fabricate artifact digest. Independent targeted scanner regression run passed 3/3, including absent manifest and missing engines. No successful real advisory-feed/security campaign independently executed. |
| TR06 exact reviewed head, dedicated App, freshness remain | Unchanged admission/issuer trust checks; real-Git and App tests | Full current head owner dispatch still required; selected source workflow failure refuses; selected routes retain source/RI/owning. Freshness/issuer regression cases passed in the independent 67-test run. Provider/App configuration/live minting not observed. |
| TR07 website work explicitly inapplicable, never passed | Selection obligations, repository scanner report and operator actions | Hosted obligations are false; Python remains true; repository reports say `website:not-applicable`. **RA-01 remains:** refusal guidance still demands staging. |
| TR08 activation is a separate post-integration observation | Actual subsequent native technical run and no website deployment evidence | Guides and issue policy preserve this external TECHNICAL gate. Fixtures establish bounded behavior only; native activation is not observed or passed. |
| Article/stable-staging rights, publication, whole issue | Existing article/native/human DELIVERY/EDITORIAL/etc. gates | Delta changes no website/public output source. Supplied authorization retains PR170 full stable staging and STOP/show; no merge/production action performed. AC01–04/06–10 are not discharged by this technical review. |

## Actual independent checks

1. Pinned Node v24.19.0: `node --test tests/delivery-observation.test.cjs tests/delivery-admission.test.cjs` — exit 0, **67 tests passed**, zero failures/skips/cancelled/todo, 36.752 s. Tool session 75931.
2. Same Node: `node --test --test-name-pattern='repository (lint|security|advisories) reaches source scanners' tests/quality-sources.test.cjs` — exit 0, **3 selected tests passed**, zero failures/skips/cancelled/todo, 8.354 s. Tool session 10242. This is a targeted failure-propagation check, not a real successful scanner campaign.
3. Current `node tools/quality/format.cjs --check` — exit 0, `changed: []`; raw local output `/tmp/requirements-format.log`, tool session 49302.
4. Packet/source hashes and exact head/tree checked; scoped `git diff --check` exited 0. Direct selection against protected-main snapshot conservatively rejected repository-only for this enabling candidate.

Supplied targeted/scan logs agree with the bounded behavior. Their presence alone does not establish current native source/security/hosted completion; the historical format log reported a change, while the independently executed current check found none. No failures were erased or rerun into an invented acceptance claim.

## Limits and next gate

The supplied accepted requirements are sufficiently bounded and assessable for this technical delta; external native/security/App/owner decisions stay explicit rather than being replaced by fixture success. No additional scope authorization or design expansion is needed to fix RA-01. Preserve this first result, reconcile separately, then review the affected corrected source and refresh exact-candidate evidence. Bootstrap full-route/native gates must complete before actual technical activation can be claimed.

No browser/device/website interaction is required to assess the changed technical source, and none was claimed. This role did not observe live GitHub refs/checks, real scanner feeds, App installation, staging/deployment, native activation or owner approval. The orchestrator must attach actual none-fork launch/accepted execution receipts to complete the review gate; provider model/context internals are unobserved and no model/isolation attestation is inferred here. This operational source restriction is not an OS or provider sandbox claim.
