# Requirements preflight — repeated source-fixture cost

2026-11-07. Requirements & Acceptance continuation by `/root/media_requirements_preflight`; four bounded read/check cases, within eight minutes. No implementation, external writes, delegation or peer reports. First judgments remain separately preserved. Provider internals remain unknown; this is a continuation, not a new fresh-context execution.

**Verdict: bounded optimization of redundant test setup is within existing issue169/PR170 scope, provided the diagnostic and isolation conditions below are met. No final implementation or full-source acceptance is granted.** Keep the full profile, scenarios, oracles,300-second source deadline, four-worker behavior, scanner and outer job limits. A mutable fixture may be independently instantiated from an immutable current-input template. It may not reuse another case's execution result, rights acceptance or mutable state. The current evidence identifies expensive modules and a real CLI case; it does not yet identify all time inside preparation versus operations under test.

Inspected clean checkout: `1e770f3fb74e84ffa2c95bcf42a3a55530203b5d`, tree `223617530295c711a54f7b1533fbd1c1ea9ad62d`. Controller174550 is unchanged per supplied task, not revalidated remotely here. Native174 staging run42321367651 is ongoing per supplied task; no outcome is inferred. Endpoint remains verified stable R10 staging then STOP/show, with PR170 main merge/production excluded.

## Case1 — Failure and causal strength

Raw runner for42321844610/attempt1 binds the same clean1e770f3f/tree22361753, selects75 modules, reports4 available/configured workers, `timeoutMs:300000`, `ETIMEDOUT`, `pass:false`. Timing stderr contains34 completed module wrappers. TAP reaches665 named passing lines but has no final tests/pass/fail/cancelled/skipped/todo accounting; observed-accounting arrays are empty. This is incomplete failed execution, not665-case or partial full-source acceptance. Build log retains cancellation at01:13:37, orphan scanner cleanup and upload artifact13553633597, ZIP SHA-256 `34c5cb854c12ec0d56671c82f74e7dfef8b4e6d3f9a00b7bd10e7c1ed5400603`. No final successful prepublication report is established by that retained upload.

Primary comparison timing from EC's retained runner is source-bound to clean `ec35807bec4a233cf7e80eb39f455c1f6b19434a`, with1222/1222 final accounting. The target fixture files are unchanged between EC and1e. Observed module wall times:

| Module | EC milliseconds | 1e milliseconds | Interpretation |
| --- | ---: | ---: | --- |
| release-rights |123419.4|164610.9|1.33×; largest wrapper |
| executive |82573.9|117434.1|1.42×; separate SEO/reconciliation work |
| space |81403.8|117593.5|1.44×; VM/runtime scenarios |

Broad slowdown is consistent with host/resource variability; it does not independently prove host hardware as the sole cause. The supplied local1253-case161-second result and eight-shard success are separate observations, not the failed full native campaign's acceptance. Preserve first failures and do not retry the unchanged full campaign to seek a favorable host.

## Case2 — Exact setup versus subject boundary

`tests/release-rights.test.cjs:23–87` creates a new source/public fixture, copies finite sources/legal/provenance, selects either isolated historical catalog or native current article, then calls the actual builder for each fixture. Its default and `nativeCurrentArticle:true` forms are materially different and must never share a mismatched seed. Default synthetic cases explicitly use the historical catalog/source-rights oracle (`tests/fixtures/catalog.cjs:legacyCatalog,isolatePublicationCatalog`); the native case retains real R10 catalog, Git object access and canonical media declarations.

The largest individual raw TAP case is **“publication actual edition and package CLIs freeze exact sidecars before any upload” —77027.9ms**. At `release-rights.test.cjs:889–1075` it genuinely runs current article build, commits a clean fixture checkout, builds/freezes both staging and production editions, checks real rights/package CLIs, exercises missing/stale/wrong-commit/tree refusals, then changes source content and tests the content proof. Those real CLI calls, Git identities and negative cases are the subject; they cannot be replaced by a prepared green report, canned package, direct API shortcut or earlier successful execution.

One concrete redundant-setup hypothesis is the initial `fixture(...nativeCurrentArticle:true)` builder at line69 followed by the explicit real CLI build at line940. The case uses the checkout for that CLI and subsequent artifacts, rather than its initial external publicDirectory. Diagnose whether omitting only the unused initial output is behaviorally neutral before claiming the saving. Do not remove the later source-mutated build at1036 or either edition's required commands.

Other fixtures repeatedly call current rights compilation. `rights.verify:497–499` deliberately recompiles from current mutable source; `rights.checkout:502–513` checks clean commit/tree; neither may cache a pass. Mutation tests include source media, legal notices/templates, retained inputs, catalog/rights inventory, engine bytes, public resources, frozen reports and absence of source for archived verification. These are essential oracles, not preparation overhead.

`tests/fixtures/delivery.cjs` already demonstrates bounded input-data reuse: it rereads actual public paths/bytes, keys manifest/gzip reuse by full input identity and producer reference, writes each new public fixture and runs snapshot verification. Its current rightsInventory copies sources and compiles real rights on each call. `publication-records.cjs` separately preserves a pinned historical source/rights format. Any new reuse must clearly identify whether a generated report is merely adversarial fixture input or the operation under test. It may never become an accepted-check cache.

Do not modify executive/space merely because their wrappers are long. Space's mutable visit globals, VM contexts, clocks and canvas behavior must remain independently constructed; its source-script reuse already has that boundary. Further change requires a measured hotspot in its actual owner and a separate affected review.

## Case3 — Permissible template and independence invariants

If an immutable-template approach is chosen, acceptance requires all of these observable conditions:

- Template is produced from the current exact finite source inventory/options and appropriate historical/native mode. Preserve legal/provenance/retained/media/pin inputs and any immutable Git-object references. Include producer dependencies, not just article bytes; invalidate/reconstruct when any relevant source, declared options or producer changes. No persistent cross-run or CI acceptance cache.
- Every case obtains a distinct temporary source/public/Git working state and fresh parsed objects/records/buffers. Ordinary byte copies or verified copy-on-write copies may share storage internally only while mutations remain isolated; hardlinks and symlinked writable sources are unsafe. Template writes/deletes, fixture cleanup and captured record closures must not affect another instance.
- Each test still executes its original function/CLI and all assertions on its own mutations. Recompute live manifests/rights/source identity wherever that behavior is tested. Source changes, tampering, rehashing, missing inputs, stale proof, negative cases and error propagation must remain exercised rather than answered from seed data.
- Prove a representative two-fixture mutation sequence: mutate/delete source and public bytes and mutate nested manifest/record data in A; show template and B unchanged; run the real oracle and observe A's intended refusal and B's intended pass. Repeat with reversed creation/use order. Any source-input invalidation case must yield a new seed or explicit refusal. Include cleanup independence and fresh-process/cold setup. Keep existing per-file process isolation and serial-case defaults.

A seed may hold generated starting bytes as **test input**, provided the real subject consumes/verifies them anew where promised. A stored validation success is not starting data. A broad helper change impacts all consumers in the maintained registry; enumerate them and recheck their contracts. Prefer a local release-rights helper first if the evidence only justifies that scope. No new owner, feature, runtime/publication change or permission escalation is needed for this bounded test-preparation work.

## Case4 — Bounded next diagnostic and acceptance route

Before implementation, record a comparison plan with a concrete question: **how much of release-rights time is redundant pristine source/public construction, and how much is real mutable rights/CLI validation?** Run at most one baseline diagnostic of that module on pinned Node24.19 and the same source/media toolchain, preserving all24 named tests, with phase timings/build counts and final TAP accounting. Separate setup/copy/build time, actual CLI commands, rights compile/verify and cleanup. Instrumentation must be explicit and scoped; do not monkey-patch process-global production exports or use fixture timing as acceptance. Stop on a semantic failure or incomplete accounting; do not repeat until green.

After the measured correction is prepared, compare once under the same diagnostic conditions. The success criterion is equal preserved cases/oracles/negative outcomes, proven independence/current-input invalidation, fewer demonstrably redundant setup constructions and lower measured setup cost. Report actual total and relevant phase costs without promising an arbitrary speedup or extrapolating local savings to native full execution. If setup is not material, return to diagnosis; do not force the cache design onto actual CLI/rights subject work.

Then obtain affected four-role review of the concrete changes; run required style/RI/CI/profile-consumer/owning checks and the **unchanged complete source profile** on the exact clean candidate, including final accounting and all original300s/4worker/buffer bounds. Regenerate selection/RI metadata only from its owner. Source/scanner exclusivity and all prepublication guards remain. A full-source pass alone does not prove build completion; observe complete native prepublication/scanner result within the unchanged10-minute build job before any dependent hosting/staging claim. Failed scanner cancellation is not a scan pass.

Current AC05/11 remain pending exact-source checks/reviews; AC09/10 and full stable staging remain pending actual R10 hosted/article/PDF evidence. New executable-test/control head still follows the existing exact-head maintainer admission gate where applicable; this preflight does not supply attestation. Do not rerun the current failed unchanged campaign, merge PR170 into main, publish production or tick whole original ACs on a targeted speed diagnostic.

## Inspected source and raw identities

| Inspected source at1e770f3f | SHA-256 |
| --- | --- |
| `tests/release-rights.test.cjs` | `1dd519a2cb41c55e720e5c13dcf72c5c8afee96ab486a6bec5e635f145d86517` |
| `tests/fixtures/catalog.cjs` | `dd59ed1c44c4d92838a6ae718af249820ae9c4c034163df8f61bbafc457037c0` |
| `tests/fixtures/delivery.cjs` | `4bf3c43e42c63d5006d209d7c85acaceb86ad62b457e36c29882d71056b66adf` |
| `tests/fixtures/publication-records.cjs` | `0d604fd5e73def3734afffe8ddb411a7a64a541916eb682f8ed9dc0159e3d2be` |
| `tools/release/rights.cjs` | `07a3801b5b7bec3e19d12005a0011b3591b63db08e1bfd6f2f4b5b9c77d2d8a3` |
| `tools/quality/source-tests.cjs` | `792aec87f4abb3aec8c97b4a8d33cd958a643b8f6c77aaac4c5683d45aaf5086` |
| `tools/quality/source-test-worker.cjs` | `490e22564920e7c7847ef5b581a9740e53e0f9b167c0214a9769a85bb32954fe` |
| `media-r10-cancelled-prepublication/prepublication-source-tests-runner.json` | `ccb004f3d68941e24963bfabf5164aadb6a56bad7201433c31e725bff3621747` |
| `media-r10-cancelled-prepublication/prepublication-source-tests-runner.tap` | `252601f3884832ff2f6dae74362748d8c9becadf8a8adfcf6eef5af427c848f9` |
| `media-r10-cancelled-prepublication/prepublication-source-tests-runner.stderr` | `a63b84b674d34143921953aa90e650c0de0416c0b3363871f05b9bdd4e28cb34` |
| `media-r10-cancelled-build.log` | `ac8c14114d46157b313908ba03358b6abf880809e3cff8c6ef76527539480ca6` |

The original zip was identified by retained log digest; I did not redownload or rehash it. EC raw comparison, current source and cancelled raw artifacts were inspected directly. No new tests/campaigns were executed in this read-only preflight.
