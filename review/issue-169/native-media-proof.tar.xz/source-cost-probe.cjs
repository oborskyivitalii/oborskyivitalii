'use strict';
const cp = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const dir = '/workspace/scratch/b15f3a872203/reconcile-review/source-cost-profiles';
const spawn = cp.spawnSync;
cp.spawnSync = function (command, args, options) {
  const instrument = command === process.execPath && !args.includes('--cpu-prof');
  const actual = instrument ? ['--cpu-prof', '--cpu-prof-dir=' + dir, ...args] : args;
  const start = performance.now();
  const result = spawn.call(this, command, actual, options);
  fs.appendFileSync(path.join(dir, 'commands.jsonl'), JSON.stringify({pid:process.pid,command:path.basename(command),args,elapsedMs:performance.now()-start,status:result.status,signal:result.signal,error:result.error?.message}) + '\n');
  return result;
};
