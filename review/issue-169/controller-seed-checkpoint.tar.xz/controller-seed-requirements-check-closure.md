# Requirements & Acceptance — controller check closure

Verdict: **the previously pending full-controller, bounded timing and nested-alias negative-control observations are now verified.** No requirements blocker remains for the reviewed controller seed change. Exact-source/native source, security, staging and stable-host observations remain pending; this closure grants no whole-AC, merge or production acceptance.

This is a targeted continuation of `/root/fix_requirements`, not a new fresh context. Preflight and prepared-candidate final are preserved. Actual controller source remains SHA-256 `ae261cc44e020042ebc51fa0517f7b04dea0a3d19a4f7e95fc970698436f7cbe`, matching the final reviewed packet. No source changes, new campaign/test execution, delegation or external write were performed by this reviewer. Only permitted raw outputs and the child fault loader were inspected; no current peer narrative was read. Existing provider/isolation limits remain.

## Observed results

| Requirement / former pending gate | Primary observation | Disposition |
| --- | --- | --- |
| All original controller scenarios plus isolation | `controller-after.tap`: 31 tests, 31 passes, zero fail/cancel/skip/todo; empty stderr; duration 39480.343895 ms | Complete local module pass. Prior exact-source comparison established all original 30 bodies unchanged; the 31st is the added isolation/refusal case |
| Bounded same-module throughput | Before TAP: 30/30, 69692.28964 ms. After TAP: 31/31, 39480.343895 ms, including new isolation case and module setup | Observed local reduction 30211.945745 ms, about 43.35%. This is one module under observer, not a native four-worker campaign margin or stable-stage guarantee |
| Actual preparation count reduction | Before 27 compiler observations / 48948.67349 ms; after 14 / 25693.505438 ms | Raw observations support removing 13 repeated fixed preparations; independent custom preparations remain |
| Correct accounting after append-only observer reuse | Combined stream has 41 records. Its first 27 rows are byte-for-byte equal to preserved before stream; remaining 14 rows equal after stream, including original line endings | Phase split verified; no after records are counted as original baseline |
| Isolation oracle detects actual alias defect | Child loader replaces only `structuredClone(releaseSeed)` with shallow top-level/source/rights copies. Fault TAP fails at line135 `deepStrictEqual`, actual second proof rights flag false versus expected true after first-copy mutation; 0/1 pass, exit1 recorded | Meaningful negative control detects nested object sharing. Failure is expected fault evidence, not a candidate failure and not a synthetic source-text assertion |
| On-disk source unchanged after control | Actual source SHA-256 still `ae261cc44e020042ebc51fa0517f7b04dea0a3d19a4f7e95fc970698436f7cbe`; loader modifies only compiled child text through module extension hook | Original reviewed source retained |

Raw after TAP SHA-256: `11e3db7ac7a44a98107f2f92fed481093c5e3929842145db84cca54708fe1f79`. Before TAP: `b7af7ac6c26b559f515ed53f8b8ec560a7063336650f76a404548d461398e18b`. After summary agrees with independently counted raw streams and TAP totals; it is not their sole basis.

Stream hashes: before `9db9aadd3d3af60b938f831bec496175bdbfe9f67f1fb35cf831f3d885298979`; after `4c8b0c8cd8986c45567a78269e01e2d0b6507da4743212bd09abd6d66070bd9d`; combined `67a862964ce04b387e94e57881a974ed5d3c685ccc20467c2374919ab2a6fc68`. Combined data remains preserved independently of its split views.

Fault loader SHA-256: `71271c1d5980e1054ad927222bc38c371ae099cc53cb4e3b640fdb756a365fb5`; fault TAP: `6e4140e1372008c6e6ecd36e0d63fe3ff0027d3ff961569ee7b1c6e107c65fe3`. This deliberately introduced shallow alias fault validates the new isolation oracle only; it is not exhaustive mutation, path-safety, cleanup or dependency coverage.

The fixed-data boundary accepted in preflight remains unchanged: seed preparation actually executes once; each of the 14 original fixed-input callers receives independent full files and data while keeping subsequent real validators/CLIs and all original refusal scenarios. Shared delivery/product code and the independent native-current-article CLI route remain unchanged. Local measured improvement justifies advancing this bounded correction to its unchanged required checks; it cannot substitute for them.

Retain all earlier native failures, abandoned hypotheses and review results. Record final clean source/run identities and complete current-source/style/RI/owning and distinct role obligations, then authenticated native source/security/staging/hosted checks. Verify stable alias/source/article/PDF and STOP/show. No merge or production action follows from this closure.
