# Requirements & Acceptance — first preflight judgment

2026-11-07. Distinct nonauthor review of issue169 / PR170; preparation only. No implementation, external writes, delegation, parent scratch notes or current peer results were read. Live issue169 was independently fetched; it remains open, updated 2026-11-07T09:13:00Z. Its historical review claims are owner history, not adopted findings.

## Judgment

**The proposed bounded Draft prototype route is requirements-compatible. Proceed with the proposed preview preparation.** Exact author acceptance is not needed merely to display unaccepted R11 for review. This judgment does not accept the completed candidate, editorial claims, PDF, hosted behavior, stable staging, merge or publication. Final candidate review and execution receipts remain required.

Observed current checkout HEAD is 9fe9b701fcaba559c455bf17c92f5e96362e739b; supplied current-main integration target is096ed26abb018a52864d9f6fcea91e62731857d6. Original candidate kit is a dirty worktree at the same HEAD, not a clean Git candidate. R11 manuscript is already committed; derivatives are partially uncommitted. Relevant originals were read only.

The existing source contract explicitly permits editorial candidates through site/article-preview.json and SITE_ARTICLE_PREVIEW=true. tools/site/articles.cjs:40–67 makes local-article catalog inclusion require accepted status. Thus removing only publication-30 and its order entry while adding R11 to explicit preview selection is a legitimate pending-review representation; it must retain canonical tags. The existing workflow build env at .github/workflows/site-color-review.yml:219 currently selects prototype PR79 only. Extending that condition to Draft PR170 preserves the existing mechanism. Keep its prototype restriction: Ready/staging must not acquire editorial-preview admission accidentally.

## Findings and treatments

1. **Medium — stale acceptance wording and integration loss risk.** .github/acceptance/issue-169.json gates.EDITORIAL describes accepted/current R10 and says no repeated permission is pending; that is misleading for exact unaccepted R11. In addition, comparing current PR HEAD with supplied main096 shows AC05/11 technical scope and TECHNICAL gate missing in the PR's older copy. Treatment: preserve main's TR01–TR08 mapping during integration; append/update current R11 editorial state to pending exact author review while preserving historical R10 decisions. Do not tick whole ACs, merge PR170 or deploy production. This is a required correction before completed-candidate acceptance, not a reason to ask permission before preparing the prototype.
2. **Medium — imported profile changes exceed a derivative-only characterization.** Candidate profile.json raises linkedinCharacters from20000 to22000, alongside edition/byline changes. This does not affect the website byte budgets, but is a real publisher validation-limit change. Treatment: avoid copying it silently. Preserve20000 if actual R11 rendering fits; otherwise record the observed rendered count, existing platform constraint and rationale as a scoped profile change, and include it in final affected review. The manuscript alone is19045 Unicode characters; that does not establish rendered-platform length. No global/source/browser/scanner budget relaxation is authorized by this finding.
3. **Evidence admission limitation — bounded packet lacks a supplied comprehensive path/byte manifest and digest over all referenced candidate bytes.** preview-preflight.json is useful intent, but not such a manifest. The hashes below identify this first inspection. Treatment: bind final imported subset/diff, actual relevant policy bytes and execution receipts before final review acceptance; compare changed source with these inspected bytes. Do not characterize an inherited conversation boundary or provider model internals as independently attested. Provider internals are unknown.

No material route ambiguity blocks this preparation. In particular, approval:null in candidate materials.json is correctly excluded by tools/site/article-materials.cjs:336 even if visibility is public; private visibility is optional clarity, not necessary to prevent public admission. No invented approval record is needed. Deliver the unapproved PDF separately. Candidate publication status review and accepted underlying rights can coexist: rights acceptance is distinct from editorial acceptance.

## Intent/AC trace

| Intent / AC | Required check or owner gate | First-preflight observation |
| --- | --- | --- |
| Show current R11 through existing publisher; AC04/06 | Draft PR preview/config and immutable source-bound HTTP artifact | Existing native preview contract supports it; actual R11 hosted preview not observed in this review. Historical AC06 remains separate. |
| Preserve thesis/evidence/limited claims; AC01/02/07 | Exact-source editorial/evidence review and author decision | Actual R11 source retains industry diagnosis as author synthesis, conditional queue model, business economics and learning/recovery limits. No new empirical verification or editorial acceptance claimed. |
| Preserve images; AC03/08 | Retained source asset identities, native desktop/mobile/no-JS, PDF page review | Publication retains five visual asset records. Proposed plan preserves exact assets; runtime/rendered readability not observed by this role. |
| Matching five-page PDF/copies; AC04/09 | Native publisher kit, PDF page/link/content parity; separate author acceptance | R11 edition pins current manuscript hash/blob; pending PDF exists with hash below. Page count/layout/platform parity not tested here. Public material approval stays null. |
| Related reading; AC10 | Existing tags/component; valid destinations/no self; desktop/mobile/no-JS | Catalog removal must preserve tag assignment and preview-related behavior; actual emitted recommendations remain to inspect. |
| Source/review/hygiene; AC05/11 | Main integration, mapped Basic/RI/style/publisher checks, four distinct final role results/receipts | Requirements preflight only. Earlier full stage failures or old green evidence cannot substitute. Final new-source checks/results are pending. |
| STOP at preview; release boundaries | Draft prototype route; no stable alias, Ready, merge, production, external posts | Proposed scope complies. Prototype HTTP proof is not stable staging or whole issue acceptance. |

## Next gate and proportional verification

Prepare a minimal integrated Draft candidate, keep R11 review/null approval and original history/assets. Regenerate outputs and locks from authored owners. Run current-source native publisher/Basic and mapped style/RI checks, plus focused article-selection/catalog/preview/material exclusion regressions affected by the change. Verify exact package and hosted HTTP bytes. Inspect real desktop/mobile and no-JS reader, captions/links/recommendations, and all five R11 PDF pages separately. Complete four source-bound affected-role final reviews, preserve actual failed/deferred accounting, and publish only through the existing Draft preview mechanism. Do not require a new full stable staging campaign to merely show this Draft; all original later release obligations remain intact.

The owner must eventually decide exact R11 editorial/PDF acceptance. It is not a prerequisite for the bounded draft preview. No user decision is needed before the reversible proposed preparation.

## Inspected byte identities

The source packet, prompt and relevant source identities below are a bounded inspection receipt, not a comprehensive delivery manifest. Live issue body is identified by URL and observed updated_at above; no immutable live-response archive was supplied. No tests or browser checks were executed by this role.

| Root | Path | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| kit | site/assets/publications/sdlc-out-of-balance/materials/reading-r11.pdf | 869961 | 568c87ea56d054d6d5cdbcd647e878bcd122d688da5cb2370fb2b0cb3a914d58 |
| kit | site/publications/sdlc-out-of-balance/editions/sdlc-out-of-balance-en-r11-20261107.json | 548 | fb2efdbeda6d1089950e69f0845c94a6c3d1bbba1c35a85b325e4f3425ed5a89 |
| kit | site/publications/sdlc-out-of-balance/manuscript.en.md | 19084 | 4bee7c727e2a4add666b48888028ea04750804841fa1c7249e0cc5120950a80d |
| kit | site/publications/sdlc-out-of-balance/materials.json | 877 | 1800968884cc2ea3058d6361729503b277e7e4b853decb11a4e771336bd7d472 |
| kit | site/publications/sdlc-out-of-balance/profile.json | 1718 | 5ee8d15fe4e563e44ead35e7216fc80f6470ed2cd516d851e79e4c236fdf4e92 |
| kit | site/publications/sdlc-out-of-balance/publication.json | 8024 | bd4785528adbe9872b5b27446a9495a92b79ddae431d9915bce8c6f78d926f0c |
| packet | preview-preflight.json | 2374 | ac85630daaf070c77a6e4dab135af7e0021a9ff25b6ba0db20867f08bfdbca52 |
| repo | .github/acceptance/issue-169.json | 9091 | b9b2eac0fd306abf616b71d300ca7f268f764c9a6631ffa3a60a5386986c2510 |
| repo | .github/workflows/site-color-review.yml | 46952 | fc5861456ad5240f1179a68c127593265bc883bac0adebb65cc016d9bcdd76bc |
| repo | AGENTS.md | 6871 | f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01 |
| repo | CONTRIBUTING.md | 19704 | 804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442 |
| repo | README.md | 2153 | 6cfbf71fad0822cbd4d756afb76b2fd29cdd7b203541b098bfba040e2c24231e |
| repo | agents/reviewers/README.md | 6964 | 2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb |
| repo | agents/reviewers/requirements-acceptance.md | 3268 | 010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6 |
| repo | guides/ARTICLE-MATERIALS.md | 6716 | 1a84030b98385cc7db1770443f6a0add23d5e931664c8a4d85ef33819ded5bf6 |
| repo | guides/ARTICLE-WORKFLOW.md | 20345 | b1b8c1bf8e2320ce74ce24d9837cce2bb0b2cb0e32b28b23f9658ef79cee3579 |
| repo | guides/SITE-STAGING.md | 48723 | 2537cc62310d19b7cf2d314a7808575e1aef371de2d37bc5afb3b089f10b66ed |
| repo | site/README.md | 42166 | 6696e8f54d09d314ad1b0dda5249dffbcd1a1a6e80c62316ec5d2dabe7e50436 |
| repo | site/article-preview.json | 59 | 18ae63ca183f986aa0a23c7f78b93bd4098c5847a16e3505090d8dd953b295a9 |
| repo | site/content/article-tags.json | 3704 | dc314dcdd2871ecc368dd014739dffc9767bc6767347133411f2d47e51c20a73 |
| repo | site/content/catalog.json | 36769 | 7a71bf2254436e2c012183cdfbd2b13c68e35f6b168de8989986814cad875909 |
| repo | tools/site/article-materials.cjs | 13584 | 492e0377bea6741b57a59e87fcfd2c1ffd120371f3a13996633f66491d6622b0 |
| repo | tools/site/article-selection.cjs | 1230 | 67433dfb1a4c6f66f0d1b53d7e45f3ffc3949fa06afead0113e2a8472377a6dd |
| repo | tools/site/articles.cjs | 15845 | 78eba91a08bd9a83d4c4c644216968ce99a80382631302792a7971f24ee57954 |
