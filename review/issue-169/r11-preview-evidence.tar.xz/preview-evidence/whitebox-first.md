# White-box QA — first independent result

**Verdict: no blocking source defect found for the bounded Draft-preview purpose.** This does not establish browser, editorial, stable-stage or release acceptance. Current remote refs/checks/deployment were not independently queried by this source reviewer.

## Identity, isolation and source

Distinct nonauthor White-box QA task `/root/preview_whitebox`, first result. No implementation, delegation, external writes or peer-result reading. Packet requested explicit `fork_turns="none"`; orchestrator owns the actual launch receipt. Provider internal model/context behavior is unknown, not attested here. Relevant root MEMORY was included in the initial required-owner read; treated only as handoff assertions. No author conversation/current peer judgments read.

Owner issue169; Draft PR170. Base `9fe9b701fcaba559c455bf17c92f5e96362e739b`; main integration `096ed26abb018a52864d9f6fcea91e62731857d6`; inspected head `994e4c7ddfd150feb0cbf68c85e300a4810c494b`; tree `9cf6690124c508365c5f8150ac1f61cc6ede62b5`.

| Input | SHA256 |
| --- | --- |
| preview-final-packet.json |009755795ab21a7191c0a6fa405f92ef88b38d322e986a4526677869167883fc|
| source manifest |6661a2d1ccb03a05daa2dc4eadfa3300addac62b56f87f39f4e486a3b1cfdc80|
| integration diff |b203505d5fed71af694578dafcd95b512896c9c472064dc85199100f52733c28|
| common reviewer contract |2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb|
| White-box prompt |832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f|

All2,583 manifest files independently matched their size/hash at the initial inspection; HEAD/tracked working tree were clean then. Read root instructions/README/CONTRIBUTING, role/common contracts, applicable source/material owners, issue169 acceptance map, actual affected sources/diff and existing tests. Local Node was **v24.22.1**, whereas hosted pin is24.19.0; local observations do not substitute for the pinned hosted lane. Managed environment status tool was not exposed.

After initial checks, parent supplied a neutral factual delta: Basic18tests/17pass/1fail from archive test's hardcoded first-live-row assumption; correction in `tests/archive.test.cjs`. Parent also modified the versioned report. This result explicitly includes that dirty delta: test SHA256 `79fb38ad2745e6c55e177561a386e3ef78804eec9858a60195d9293a61f142b4`, `git diff -- tests/archive.test.cjs` SHA256 `4e26fc13770832a37903744ac2cc6baadd7ec11987bdee647a25c972fe1c2a2f`. Versioned report observed SHA256 `cfb2b08093717aecc5ce39fd290944c32ef53d5bfbbb4d40d1591220bc2356ea`. Do not call these final dirty bytes the immutable committed manifest. No new executable production source changed in that delta.

## Risk → fault → scenario/oracle → existing check

| Scope | Structural risk and independent invariant | Executed observation |
| --- | --- | --- |
| AC05 inventory | R11 PDF/review/edition use canonical owner and actual file kind; unsupported new executable/provenance/policy edits still refuse | publication-inventory positive/negative test and complete-inventory negative test pass; current RI/coupling/catalog3Python tests pass |
| AC05/AC11 technical route | Registry additions preserve previous rows and non-test policy; unsafe rename/mode/symlink/deletion/provenance/unmapped changes keep full route; executable trust still required |46delivery-observation tests pass; real-Git admission test passes exact-SHA and required-workflow refusal scenarios |
| AC05 source deadline |600000ms child and630000ms wrapper preserve original partial streams/ETIMEDOUT; all8shards required with20m enclosing budget | synthetic inner-timeout test passes; exact fail-closed shard adapter negative cases pass; workflow/source inspected |
| AC05 rights fixture | Missing rights cannot be bypassed by deleting descriptors or variant; actual alias inventory determines earliest valid refusal | licensed-publications negative case passes for both runtime edition modes |
| AC08/AC09 pending material | Null approval excludes PDF from rendered block and public assets; accepted material requires exact source/review binding |10material tests pass; actual R11 loader assertions confirm empty materials HTML/assets and no reading-r11 PDF resource |
| AC04/AC07/AC08 Draft separation | Ordinary catalog excludes review edition; explicit preview marks candidate; canonical stays null; production and sitemap reject candidates | current-source assertions pass; production/sitemap negative test passes |
| AC05 scanner integration | Repository lint/security/advisories need no website manifest, remain source-bound and retain actual engine failure |3missing-engine fault-injection tests pass; no artifact digest or phantom manifest |
| AC08 archive delta | Explicit eligible undated fixture must retain authored2026/delivery/en placement and first position through same4tag/year/language/reset scenarios; fixture cannot admit live review content | corrected full archive module10/10 passes; mutation remains fixture-only |

These are decision/scenario partitions, not measured branch coverage. No coverage percentage claimed.

## Executed commands, results and accounting

All checks used existing tests. No tests/source were authored or changed by reviewer. Exit0 unless otherwise stated. Every Node test run below reported zero fail/cancelled/skipped/todo.

1. `node --test tests/delivery-observation.test.cjs tests/article-materials.test.cjs` →56tests/56pass,17.020507s (46routing+10materials).
2. `node --test --test-name-pattern='known licensed publications|prepublication preserves inner source timeout' tests/publication-records.test.cjs` →2/2,1.450743s. The timeout test preserves original child TAP/stderr, ETIMEDOUT,600000ms raw deadline and630000ms wrapper; other guards remain180000ms.
3. `PYTHONPATH=tests python3 -m unittest test_ri_ci.RICICouplingTests.test_source_shard_ready_adapter_requires_exact_fail_closed_edge test_ri_ci.RICICouplingTests.test_current_repository_map_and_ci_routes test_issue31_acceptance.Issue31AcceptanceTests.test_complete_catalog_and_fresh_generated_views` → `Ran 3 tests in 3.894s`, `OK`.
4. `node --test --test-name-pattern='repository (lint|security|advisories) reaches source scanners' tests/quality-sources.test.cjs` →3/3,12.280686s. Deliberate missing-engine subprocess failures were retained and asserted.
5. `node --test --test-name-pattern='explicit candidate preview cannot enter a production edition|missing, unknown, duplicate, symlink and misclassified' tests/article-delivery.test.cjs tests/test-profile-selection.test.cjs` →2/2,0.964338s.
6. `node --test --test-name-pattern='publication inventory admits content bookkeeping' tests/test-profile-selection.test.cjs` →1/1,0.133752s.
7. `node --test --test-name-pattern='real Git collection keeps candidate bytes as data' tests/delivery-admission.test.cjs` →1/1,1.486730s.
8. Read-only inline Node assertions loaded actual catalog/preview via `articles.select`/`article-selection.select`; asserted ordinary exclusion, review/candidate status, exact edition, canonical null, empty materials and no PDF asset. Raw exit0 output:

```json
{"ordinary":[],"preview":["pmday-ai-both-sides","sdlc-out-of-balance"],"r11Candidate":true,"edition":"sdlc-out-of-balance-en-r11-20261107","pendingMaterialExcluded":true,"canonical":null}
```

9. After supplied dirty delta: `node --test tests/archive.test.cjs` →10/10,0.193663s. Raw case names include undated local-article authored-year/first-position filtering; complete catalog reset; URL/hash/history restoration; print; unknown URL/history failure; no-script semantic HTML; new-year inventory; asynchronous tag composition.

Total existing-suite observations: **78tests passed**, zero failed/cancelled/skipped/todo, plus direct source-selection assertions and manifest verification. Full source campaign was deliberately not launched. Initial rg discovery requests referenced absent files/globs and returned status2; lookup misses were resolved by actual inventory reads and supplied no test assurance.

## Source assessment / findings

No blocking finding in inspected Draft boundary.

- `.github/repository-paths.json:17032` onward now gives PDF/review/edition `kind:file`, source role and `guides/ARTICLE-WORKFLOW.md` owner. The unchanged `source-tests.cjs:304–367` guard still rejects wrong owner/schema/role, new unsupported executable and altered pinned provenance. Current-current admission and meaningful negative cases pass.
- `publication-records.test.cjs:582–633` chooses its expected refusal from actual public alias inventory; every altered record must still throw. This candidate executes the no-article-alias branch. Accepted-alias branch was inspected structurally, not independently constructed during this run; the correction does not claim broader fixture execution.
- `delivery-routing.cjs:511–626` retains previous registry rows/non-test policy and rejects unsafe/mixed source changes, controller/workflow/toolchain changes and issue acceptance snapshots from technical eligibility. It retains Python/control review and explicitly adds security/advisories. `site-checks.yml` uses protected-base selection and strict source matrix. Unit fixture success does not prove native activation/bootstrap/App trust.
-600s budget is consumed through existing shared prepublication limits with30s reporting grace. `check_ri_ci.py:131` requires exact20m source-shard bound,8shards, fail-fast false and preserved success edge. Actual600s exhaustion and concurrent native source campaign/resource fit are unobserved.
- `article-materials.cjs:336` excludes null approval before public target/resource selection. Current R11 source load confirms that outcome. `articles.cjs:40–85` selects accepted catalog records or explicit candidates, rejects an unaccepted catalog article and marks R11 candidate. Publication-30/order are absent; tags remain. Workflow preview opt-in covers prototype PR79/170. Separate PDF review does not constitute acceptance.
- Archive delta at `tests/archive.test.cjs:178–228` clones catalog, adds one explicit local-article fixture with archiveYear2026/topicdelivery/languageen and prepends that fixture only in test data. Year/topic/language/first-position assertions, all4tags, exclusion filters and reset identity/order assertions remain. Reset count becomes total+1 because fixture adds one row. It exercises archive behavior without modifying live catalog/status or replacing the production admission oracle. Full10case module passed independently.

Evidence metadata discrepancy, low severity: packet initially claimed corrected2-module76pass/1fail; actual `preview-targeted-corrected.tap:75–78` says73tests/72pass/1fail. Parent's subsequent delta explicitly corrected the receipt count. Preserve raw initial128/126/2, corrected73/72/1 and isolated inventory1/1/0 evidence. This reviewer independently verified corrected cases; prior failures remain historical failures. Parent-reported Basic18/17/1 was not rerun as a whole by this reviewer; corrected archive10/10 is the actual newly executed bounded evidence.

## Limits and remaining gates

Checks map to existing permanent source/PR-selected and RI/owning routes under SITE-CHECK-PROFILES. Inline current-source selection is a reviewer diagnostic, not a new accepted suite. Browser interaction, actual hosted HTTP/device/no-JS layouts, five PDF page visuals, platform parity/editor behavior, current GitHub trust/bootstrap/native runs, real scanner success, all8native source shards and full Basic/staging/production were not observed. Packet browser failures supply no browser pass. Draft-skipped readiness jobs are not completed checks.

AC05/AC11 receive scoped evidence only. AC04/AC07/AC08/AC09 retain human/editorial/copy/visual/served-delivery gates. No whole-AC closure, Ready transition, stable acceptance, merge, publication or production action follows from this result. Candidate changed after initial manifest verification; pin/reconcile the archive/report delta into the final source packet and affected review receipts before advancement.
