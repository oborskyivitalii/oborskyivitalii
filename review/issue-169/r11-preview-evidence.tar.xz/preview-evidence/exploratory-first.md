# Exploratory / Interaction QA — first independent result

Date: 2026-11-07. Owner: oborskyivitalii/oborskyivitalii issue169 / Draft PR170.
Role/task: distinct nonauthor `/root/preview_exploratory`. This first result is preserved before reconciliation. No implementation, external mutation, delegation or current peer-output reading occurred. Parent supplied an explicit none-fork launch; provider model/context internals are unknown. The issue body contains historical review summaries; those were read only as part of authoritative intent/history, not as evidence for this verdict. No current peer result was inspected.

## Verdict

**No product defect found in the bounded static reader/export and actual five-page PDF observations. Browser interaction remains BLOCKED / NOT OBSERVED.** The inspected artifact is suitable to present as a proposed Draft author-review candidate, with these limits visible; this review does not accept a loaded native/site preview, author editorial/visual decisions, whole ACs, stable staging, merge, release or platform publication.

The actual PDF is five pages and visually readable in the supplied page renders: no visible clipping, text/figure overlap, broken glyphs, blank page or missing figure was found. Native reader source has the complete five images, section destinations, references, author apparatus, staging identity and ordinary navigation targets. Static checks cannot establish their browser behavior.

## Source and authority

Repository HEAD observed `994e4c7ddfd150feb0cbf68c85e300a4810c494b`, tree supplied `9cf6690124c508365c5f8150ac1f61cc6ede62b5`; local main `096ed26abb018a52864d9f6fcea91e62731857d6`. Working tree clean at initial and final status observations; branch was ahead of origin by six commits. These are local refs, not an assertion that GitHub already hosts this candidate.

Read root README/AGENTS/CONTRIBUTING, applicable site contract, repository map, common reviewer contract and assigned role, `.github/acceptance/issue-169.json`, affected publication/profile/material owners, explicit article-preview selection, relevant diff, native public artifact and platform kit instructions. No nested AGENTS was listed in the supplied checkout. Read the live issue body through GitHub fetch_issue, returned open, updated2026-11-07T09:13:00Z; original hard five-page ceiling, site-first sequence, source/review and actual-delivery distinctions confirmed. Current comments and complete live PR/check/deployment state were not revalidated in this role.

| Identity | SHA-256 |
| --- | --- |
| `/workspace/scratch/59f72ef40bac/preview-final-packet.json` | `009755795ab21a7191c0a6fa405f92ef88b38d322e986a4526677869167883fc` |
| supplied sorted source manifest | `6661a2d1ccb03a05daa2dc4eadfa3300addac62b56f87f39f4e486a3b1cfdc80` |
| supplied integration diff | `b203505d5fed71af694578dafcd95b512896c9c472064dc85199100f52733c28` |
| `agents/reviewers/README.md` | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| `agents/reviewers/exploratory-interaction-qa.md` | `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a` |
| native reader `color-artifact/public/articles/the-sdlc-is-out-of-balance.html` | `1680bdf5e8411f5394acdec6b3512c153bdfe6bd6075a03c5334374a8426e2a6` |
| manuscript | `4bee7c727e2a4add666b48888028ea04750804841fa1c7249e0cc5120950a80d` |
| `site/assets/publications/sdlc-out-of-balance/materials/reading-r11.pdf` | `568c87ea56d054d6d5cdbcd647e878bcd122d688da5cb2370fb2b0cb3a914d58` |

Independently compared manifest hashes for root instructions, common/role prompts, article-preview selection, publication, materials, profile, manuscript and PDF: all eleven matched. The generated artifact's own metadata names sourceCommit/candidateCommit994e4c7d, sourceDirtyfalse and the supplied tree. The R11 PDF sibling under `/workspace/scratch/3db1b2682338/R11/The_SDLC_Is_Out_of_Balance_R11.pdf` has the same PDF SHA-256. Its five supplied PNGs were independently reproduced byte-identically using read-only `pdftoppm -png -f N -l N -scale-to 1300 <candidate PDF>` into memory; no reliance on the implementer's visual verdict.

## Charter and bound

A single bounded review of at most ten minutes, covering: direct-entry reading and orientation; section/figure/reference navigation and return paths; reader/proposed-PDF admission boundary; complete five-page PDF reading across page turns; platform preparation/handoff. Intended dynamic cases: loaded reader at desktop and narrow width, Contents select/close, figure zoom/original/Escape/focus return, citation return, back-to-Writing/history, and no-JS readability. No new universal device matrix or full test campaign.

Environment: Linux shell with Poppler; no local Chromium launch attempted by this role because the supplied first failure already diagnoses launch-before-load AF_UNIX EPERM. Separate shared cloud Chrome was tried once because it is a materially different accessible browser surface. That browser could not reach the executor's loopback listener. Environment-status tool was not exposed in available tool metadata.

## Actions and observations

| Case | Expected | Observed / evidence | Result |
| --- | --- | --- | --- |
| E01 direct reader entry | Candidate loads from local listener | Shared Chrome `cua.createBrowserTab("cdp", "http://127.0.0.1:8765/articles/the-sdlc-is-out-of-balance.html")`: `Browser Use cannot open … in tab 4. Browser reported: net::ERR_CONNECTION_REFUSED`. No loaded article/UI observed. | Blocked |
| E02 retained local launch failure diagnosis | Preserve first failure; avoid unchanged retry | `/workspace/scratch/59f72ef40bac/preview-browser.log` shows Chromium FATAL `process_singleton_posix.cc:297`, `socket() failed: Operation not permitted (1)`, SIGABRT before load. No unchanged local campaign rerun. Separate cloud-browser refusal does not diagnose site/application failure. | Executed diagnostic; no browser pass |
| E03 static native entry/navigation | Reader has content and resolvable local resource/fragment targets | Standard-library HTMLParser walked `a[href]`, `img[src]`, `script[src]`, `link[href]`, resolved relative paths and target HTML IDs: `LOCAL_REFERENCE_FAILURES []`. This includes Contents/skip/back-to-top/dialog fallback targets; not click behavior. | Pass, static only |
| E04 native figures and provisional state | Five images and safe Draft presentation | Hero1672×545 eager; four diagrams2000×825,2000×538,2000×638,2160×630 lazy. All have descriptive alt; conceptual limits remain in captions. Reader meta `robots=noindex,nofollow`, `site-environment=staging`; footer `STAGING · 994e4c7d`; edition R11 and author apparatus present. | Pass, static only |
| E05 proposed PDF boundary | Unapproved R11 PDF is not a public download | `materials.json` approval null; publication status review. Native reader has no R11 PDF download anchor; no reading-r11 or R11 PDF digest resource exists in public inventory. An external source URL ending `.pdf` is a reference, not this proposed reading PDF. Publication-index does not list the article; Writing HTML does contain the explicit preview candidate. | Pass, static only |
| E06 actual PDF reading | At most five pages, complete visible figures/text, no severe layout damage | `pdfinfo`: five A4 pages,869961bytes, title and R11 author-review subject. Inspected all five 920×1300 PNGs; byte-identical independent render confirmation below. Hero+Figure1 on p1; Figure2 on p2; Figures3/4 on p3; conclusion spans p4/5; references, evidence note, author bio and copyright on p5. No clipped text, footer overlap, blank pages or unreadable replacement glyphs observed. | Pass, bounded visual review |
| E07 platform handoff | Complete review copies, ordered figures, site-first/manual boundary | Kit at `dist/publications/sdlc-out-of-balance/18542b6b4686340a4ae39620da38cf9bbd7e6c909d206f39f6995c459042a547`: INSTRUCTIONS explicitly says canonical pending, planned destination, verify live site then author-manual posting and native-image inspection. Both TXT copies20938 Unicode characters and byte-identical; four numbered figure captions and planned stable site/material destinations present. Each copy-ready HTML has five embedded images. | Pass, static preparation; no native editor claim |
| E08 desktop/narrow/no-JS interaction | Real rendering/Contents/dialog/focus/history readable and usable | Neither browser route loaded this reader. These journeys remain designed but not executed. PDF visual inspection and HTML targets do not replace them. | Not observed |

PDF raw render identities, all five matches:

- page1 `4827ec704e443198a13c0db4616fb7c0d5fef2a67067ed36303331f36364993b`
- page2 `cf00b6ab2abc102a9dc3b91fc978762b1b484185d25d2081bfbee551b9955aa9`
- page3 `7dccd9e329596cac2146f808e1c1a51d79962f2f14455c85eb17a4a396d9c98f`
- page4 `1ff2d53c0d7a32c924d3b718c339355bc40abe50c2bfcc0847613927cd7075ab`
- page5 `eb4044a88a03e0ef155cac8f169831fa36976a73f90abc098cd2445c3a97117b`

A first exploratory parser command failed with `ModuleNotFoundError: No module named 'bs4'` before inspecting the HTML. It was retained as a tool/dependency failure; the subsequent smaller diagnostic used Python's standard-library HTMLParser and completed. No package installation or implementation change occurred. Other early broad reads/searches were truncated or named nonexistent speculative content paths; authoritative paths were then read directly through the map/actual inventory.

## Findings, acceptance impact and next observation

No confirmed implementation/layout defect. **B1 — material observation blocker:** exact-source native reader interaction is unavailable in this environment (retained launch EPERM; separate shared-browser connection refusal). This prevents claiming completed desktop/mobile/no-JS reader, focus/history/dialog and actual hosted observation under AC05/AC08/AC09/AC10/AC11 and VISUAL/DELIVERY. Severity: acceptance limitation, not a demonstrated product bug. Treatment: preserve these first failures, publish only the already authorized Draft candidate through the existing controller, then run the existing hosted reader journey against its exact origin/source. Do not waive those gates or accept the article from the PDF alone.

PDF observations support only the five-page/layout part of AC08/AC09. Full PDF/source meaning-and-link parity was not re-proven here; selected manuscript/reference/figure content was read, but automated author-claimed72-block/17URL parity was not substituted for a complete independent comparison. Actual native platform editors, external target availability and physical devices were not observed. PDF is untagged per pdfinfo; no PDF accessibility/conformance acceptance was requested or inferred.

Existing route reuse through `guides/SITE-CHECK-PROFILES.md`: retain `tests/reader-mode.test.cjs` for source-preserving Contents/citation/disclosure/history semantics and `tests/article-delivery.test.cjs` for exact transport and rejected preview promotion; registry maps both to permanent pr-targeted/staging/production profiles. Actual interaction belongs to existing `tools/quality/article-browser.cjs` / hosted preview and staging-regression owners, including the documented two-width normal/Off/no-Canvas/no-JS article journeys. These were not run successfully here. No proposed regression is counted executed, no duplicate suite/budget expansion proposed. Manual author PDF/editor acceptance stays with author, deferred pending exact candidate presentation/live-site prerequisite.
