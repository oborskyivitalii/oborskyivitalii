# Code / Artifact reconciliation review

Reviewer: `/root/timing_code`; 2026-11-06. This is a declared continuation/reconciliation after reading the authored report including role summaries; it is not a fresh independent first judgment. Earlier `code-first.md` and `code-profile-delta.md` remain unchanged. No campaigns or implementation occurred.

Reviewed report: `/workspace/scratch/20e98a342431/timing-evidence/review/issue-169/2026-11-06-staging-timing-investigation.md`, verified SHA-256 `4b3adf2a1e07191f4a86b527ba8f17a2f0155c755f6b783dab5f3deab0fc7a76`. Candidate source remains the previously inspected e50c63de/tree1c9d8054 pair.

Verdict: core deadline/hardware/history/repeated-preparation conclusions are supported within their stated bounds. Correct the factual failure-site statement and label the count observer scope before publishing this exact report. One small profiler number/denominator should also be clarified. No acceptance or release approval is provided.

## Findings

1. **Medium — F03 names an unproved and source-inaccurate legal-HTML rejection site.** The report says reader selection/media runs before `roomInventory` rejects altered legal HTML. `tools/release/rights.cjs:342–359` checks authored fallback-resource descriptor and byte equality; it does not inspect Credits license markup. The dedicated legal visibility/full-copy check is `publicNotices:363–387`, called at report construction `:472`. The raw child observer returns results unchanged and the test catches thrown exceptions generically; neither the retained profile nor child-count records establish the exact exception identity for each iteration. Sampling a function does not prove its throw site. Change to “before later rights validation rejects the candidate” unless an exact caught-error observation is available. Do not claim all source refusals occurred specifically for the mutated notice merely because generic assert.throws passed. This preserves the measured repeated-preparation finding while avoiding a stronger refusal-oracle claim than the evidence supplies. Affected requirement: investigation accuracy/source-bound cause evidence (issue169 AC05).

2. **Low — F03 subprocess counts need an explicit observational scope.** `timing-investigation/child-count.cjs` replaces only `cp.spawnSync`; it does not intercept `execFileSync`, `execSync`, asynchronous child APIs, subprocess descendants or Python-internal work. `tests/fixtures/delivery.cjs:143` uses `execFileSync` for the shared clone, for example. The raw JSON supports exactly 17 observed Python web-media calls (15649.747085ms), 51 observed Node AST calls (9505.214344ms), and 357 observed Git --no-replace-objects calls (1581.852918ms), all status0. Keep those values, but title/qualify the table as “calls intercepted through cp.spawnSync” rather than an inventory of all synchronous subprocess or Git invocations. The surrounding report already accurately says observer overhead is present and this is local one-case work.

3. **Low — F03 precise profiler percentage has no matching declared denominator.** Independent reconstruction finds 23596 of27282 samples (86.4893%) whose own frame is spawnSync. Weighting by timeDeltas gives26.236773/30.166436 seconds (86.9734%). The report says86.94% of samples. Use “about87% of sampled elapsed intervals” or report the independently reproducible weighted value; do not mix sample count and elapsed weighting. Roughly52% media and30% AST are supported. Native synchronous frames identify parent residence/waiting, not child CPU self-time, as the report correctly states.

## Confirmed raw evidence

- Inspected child-count.cjs, child-count-6.json, child-count-time.json, child-count.tap/stderr. The observer forwards original command/args/options and return value, times calls with performance.now and writes grouped counts on process exit. Test output records1/1 pass; time record wallSeconds30.673761108999315, exit0. No assertion/producer/fixture edits were present in this observer.
- Reparsed original cpu/license-wrappers.cpuprofile, using node parents and sample/timeDelta pairs. This independently supports the media/AST dominant paths and the local-versus-native measurement limits. Profiler rows merge repeated call stacks; exact invocation counts come from the separate observer, not CPU node counts.
- Inspected original `octfail/source-tests.json`, `octpass/source-tests.json`, and each lint.json environment. Source objects are identical and clean at808dae28fb65c5d39ceb16bec89cf5ab82e9c958/tree67040e44a85e2340a4c770061c55cbf1bf3e072b. Execution argv is byte-for-byte identical as parsed lists and contains79 selected modules. Both limits are180000ms. Attempt1/7763 times out; attempt2/9V45 passes1156 with source elapsed142059ms. Same Node24.19.0/image20261023.334.3/kernel6.17.0-1022-azure/memory16766414848. Run IDs/attempts in lint reports match40215263460/1 and/2. This materially strengthens the hardware/environment relationship without proving CPU model sole causality.
- Recomputed November completion counts for42119802341 and42207436828 from their retained advisory event streams:24 and62 respectively, matching the authored table. The latest two56-completion observations and unchanged costly source diff were already independently established.
- Historical Oct25 pair demonstrates the phenomenon predates R10/e50. It does not establish first-ever occurrence. The report states that limitation correctly. Full GitHub run downloads/artifact IDs, launch receipt/provider isolation and enclosing build cancellation attribution are outside this bounded Code recheck; no additional assurance is inferred for those surfaces.

No new peer output or parent interpretation beyond the explicitly reviewed authored report was consumed. Only this assigned reconciliation result was written.

## Correction re-review disposition

Preserved findings above. Re-read the corrected F03 paragraphs and independently verified the report now has SHA-256 `f15754ee258917b8af273bc9a6310d3e78f918b6ee167ec152e7b862c94bc5c6`.

- Finding1 resolved: it now says later rights validation rejects the candidate, identifies publicNotices as legal-copy owner, and states caught exception identity was not captured.
- Finding2 resolved: table and adjacent prose explicitly scope counts to cp.spawnSync and exclude execFileSync/total-process assurance.
- Finding3 resolved: it now uses about87% of sampled elapsed time at child-call frames and preserves the child-CPU limit.

Final Code disposition: no remaining blocking factual defect found in this bounded investigated/reconciled scope at the corrected report identity. Previously declared limitations and independent-first-report history remain. This acceptance concerns investigation statements only, not candidate correctness, staging or release approval. No new execution was performed.
