# Requirements & Acceptance — factual evidence delta

## Verdict

**The new same-source native pair materially strengthens the environmental/performance explanation and rules out changed repository bytes as a necessary condition for this class of timeout.** It does not isolate CPU model as the sole cause of the current PR170 staging failure. The October pair uses a different profile, selection and deadline from the November staging records.

The newly supplied evidence establishes source-test deadline failures by the archive-recorded date of 25 October and staging source-test deadline failures by 5 November. First-ever onset remains unknown. The 6 November `e50c63de` change is therefore not the origin of the broader observed timeout problem. Earlier success and failure now alternate across source identities; a single commit bracket must not be presented as a proven regression-introducing commit.

The local CPU profile also supplies a concrete expensive execution path: repeated rights validation reaches article selection, synchronous article-media encoding, publisher compilation and history checks. This is stronger than a guess about gzip or fixture copying, but one local targeted measurement does not quantify the native CI critical path or prove a sufficient fix.

## Execution and evidence boundary

- Reviewer task: `/root/timing_requirements`, same role and execution lineage as the first result. This is a scoped continuation with new primary evidence, not a newly clean first context. No peer narrative or verdict was read.
- The first result is preserved unchanged at `requirements-first.md`, SHA-256 `4d6fafede4a6d23581351e72e6df6192acd05d439c54de8fd519af41457b8ae8`.
- Original packet: SHA-256 `fca1c5dacd743fd251528077caeba3f2d71e0ae137921cf09d6c5a9ae9e99ea2`. The added evidence was supplied by the parent as exact paths, without a replacement packet manifest. Actual byte identities observed below identify this delta; they do not invent authenticated acquisition provenance.
- Rechecked local HEAD/tree: `e50c63de071de6837cf9b6405569bb9a68afd5da` / `1c9d8054afdb0e13377c6ccbcd14b92860653d99`, clean working tree. Common/role prompt, CONTRIBUTING, issue-169 policy and source runner/worker hashes remain the same as the original packet. Their unchanged contracts and first-result interpretation were reused.
- Parsed only supplied raw records and relevant authoritative source, with bounded read-only Python extraction. No tests, staging retries, implementation changes, external writes or delegation. The parent's already performed local experiment was inspected, not rerun.
- Actual parent launch parameters and provider model/context/memory internals remain unavailable to this reviewer. No additional unexpected history exposure was observed. Native JSON contains historical changed-path inventories; path names were visible, their narrative file bodies were not opened.

## New native observations

### Same-source pair

Both `octfail/source-tests.json` and `octpass/source-tests.json` record clean source `808dae28fb65c5d39ceb16bec89cf5ab82e9c958`, tree `67040e44a85e2340a4c770061c55cbf1bf3e072b`, before and after execution. They select the same ordered 79-module list, identical worker argv, `profile:pr`, 180,000 ms timeout and 16 MiB output bound. Both timing streams report Node 24.19.0 and four available/configured/concurrent workers.

| Observation | Failure | Success |
| --- | --- | --- |
| Source-test result | `ETIMEDOUT`, status 1, terminal accounting absent | Status 0; 1,156 tests/pass; fail/cancelled/skipped/todo all zero |
| Progress / duration | 65 dequeued, 61 completed wrappers; partial TAP ends at `ok 582` | 79 dequeued/completed; terminal TAP duration 142,025.488962 ms; report elapsed 142,059 ms |
| Adjacent native lint environment | Run `40215263460`, attempt 1; AMD EPYC 7763 | Same run, attempt 2; AMD EPYC 9V45 |
| Other recorded lint environment | Linux x64, Node 24.19.0, kernel `6.17.0-1022-azure`, image `ubuntu24` / `20261023.334.3`, 16,766,414,848 bytes memory | Same recorded values |
| ZIP source-test member timestamp | 2026-10-25 17:16:26 | 2026-10-25 17:22:02 |

I verified each JSON and lint file byte-for-byte against its unique member in that directory's `original.zip`. The lint environment is associated with the source-test result through matching source/tree and common native artifact, not embedded in the source-test process result itself. No live run/job API or signed runner attestation was observed. ZIP timestamps retain their archive-metadata meaning and unspecified timezone.

Interpretation: unchanged source and selected command can fail then pass with changed recorded host CPU identity. This defeats the claim that a repository source change is necessary to produce the October pair's different outcomes. It strongly supports sensitivity to execution conditions; the two attempts do not control all timing, cache, scheduling, host load, dependencies or filesystem conditions. Therefore “CPU identity is associated with the outcome” is supported; “EPYC 7763 alone causes all these failures” is not established.

### Additional November records

| Native directory / source | Profile, limit, result | Adjacent recorded CPU/image |
| --- | --- | --- |
| `stage-42119802341` / `b75a0a31e36be02bea15bb7a0b269d032fa3cdcb` | Staging; 75 modules; 300 s; ETIMEDOUT; final accounting absent | EPYC 7763; image `20261101.360.1`; attempt 1; source-test ZIP timestamp 2026-11-05 22:21:46 |
| `stage-42196241166` / `95d3e78d7e76d3e267351b8ca1efff206f99b748` | Staging; 75 modules; 300 s; 1,198 tests/pass, zero failures/cancellations/skips/TODO; elapsed 223,740 ms | EPYC 9V45; same image; attempt 1; source-test ZIP timestamp 2026-11-06 09:41:18 |
| `stage-42207436828` / `d5e915feb3ba02d7a80325664c9d1d10a2ac494e` | Staging; 75 modules; 300 s; ETIMEDOUT; final accounting absent | EPYC 7763; same image; attempt 1; source-test ZIP timestamp 2026-11-06 11:11:12 |

These three reports and associated lint JSON also match unique archive members. The November success still has `prepublication.json pass:false`, due to security: a source-test pass cannot be promoted into whole staging acceptance.

I also inspected the native lint environment fields in the three originally supplied directories: `42227207673` source-test pass records EPYC 9V45, while candidate failures `42233889474` and `42237763419` record EPYC 7763; all use image `20261101.360.1`. Thus the six supplied November staging invocations show four source-test failures associated with 7763 and two successes associated with 9V45. These are observationally selected records across different source commits, not a randomized experiment or a population failure-rate estimate. The October same-source pair is the better control for source bytes.

## Local profile: what it adds and what it cannot establish

`cpu/time.json` records a single selected test from `tests/release-rights.test.cjs`, with `--test-isolation=none`, a name pattern matching “publication comment and inert-template wrappers,” and CPU profiling enabled. Exit is 0; wall time 30.2620 s; recorded user/system CPU 30.296535 / 6.079514 s; maximum RSS 339,356 KB. The file named `test.tap` contains Node's human-readable reporter output rather than TAP syntax: one test passed, zero fail/cancelled/skipped/todo, duration 30,097.564118 ms. The parent supplied Node 24.22.1 as the local runtime; neither raw time JSON nor profile records a source commit/tree or full native CI environment.

The profile has 27,282 samples/deltas over approximately 30.1666 s. Summing sample time deltas at `spawnSync` leaves gives 26.2368 s, about 87.0% of sampled time. Ancestor classification, without double-counting each leaf, gives:

| Synchronous subprocess ancestor | Sampled time |
| --- | --- |
| Article-media `encode` | 15.7424 s |
| Publisher article `compile` | 9.0569 s |
| Article history Git helpers | 1.1444 s |
| Other synchronous subprocess paths | 0.2931 s |

This is parent-process sampled time while synchronous child calls are active, not a measurement of child CPU instructions or a native CI percentage. The profile does not attribute Python/media encoder internal work, OS waiting, contention or child compiler work precisely.

Source inspection corroborates the path: `tests/release-rights.test.cjs` near line 797 iterates 16 hidden/inert/comment wrapper variants and calls rights compilation/refusal checks for each; `tools/release/rights.cjs hostedInventory` calls article selection; `tools/site/articles.cjs select` loads and renders articles; `tools/site/article-media.cjs encode` invokes the Python media producer synchronously; `tools/publishing/article.cjs compile` invokes the AST subprocess. This is a real local cost path within a meaningful refusal test. It does not prove every native slow suite has this bottleneck or that the selected test alone causes the 300 s deadline.

## Updated findings / acceptance consequences

| First finding / intent | Delta disposition | Remaining boundary / treatment |
| --- | --- | --- |
| RQ-1: preserve mechanism/root-cause distinction | Refined: execution-condition sensitivity is now strongly supported by an exact-source pair; local subprocess-heavy rights path is directly observed. | Current PR170 attribution to a specific CPU/resource still requires a controlled or otherwise discriminating observation. Do not describe pure gzip cost, deadlock, assertion defect or the 6 November scanner change as proven cause. |
| RQ-2: onset limit | Materially updated: supplied native failure evidence now reaches 25 October for PR source tests and 5 November for staging source tests. | October is a different 79-module/180 s PR regime. First-ever occurrence and exact chronological onset still require earlier comparable native run history. The earliest supplied record is not necessarily the first event. |
| RQ-3: owner/live acceptance unavailable | Unchanged. No new owner issue text or live acceptance/run state was supplied. | Source-test successes remain bounded, historical and source-specific. No policy/human/release gate is passed here. |
| RQ-4: topology documentation differs from actual worker | Unchanged; new evidence also distinguishes older PR and current staging regimes. | Keep 180 s/79-module October comparison separate from 300 s/75-module staging. No deadline/selection equivalence claim. |
| User: relationships | More precise answer available: host CPU identity associates consistently with observed outcomes, and rights negative checks invoke substantial article pipeline work locally. | Distinguish observed association, measured local path and unresolved CI root cause explicitly. |

No new owner decisions or accepted ACs are introduced. Any future optimization must preserve the meaningful wrapper/refusal cases, fresh source/data binding, complete registry selection, terminal zero-skip accounting, original deadlines and all external gates. The profile justifies prioritizing bounded inspection of repeated article preparation in rights validation; it does not authorize removing cases, loosening budgets, accepting cached stale bytes or rerunning an unchanged full campaign.

The smallest remaining discriminating question is whether the same current selected workload's cost changes with host/resource conditions and whether the locally observed subprocess path dominates native slow suites. Reuse any retained exact-source comparisons and timing traces first. If a new diagnostic is subsequently authorized, define its specific controlled variable, instrumentation, expected supporting/contrary outcome and stopping condition before execution. A native pass following a retry would not, by itself, prove the cause or erase retained failures.

## Byte receipts for this delta

All paths below are relative to `/workspace/scratch/20e98a342431`.

| File | SHA-256 |
| --- | --- |
| `timing-investigation/octfail/source-tests.json` | `3477ad0c1cd6612b7f466864bc271444e742748125816360d3d245117a90aa34` |
| `timing-investigation/octpass/source-tests.json` | `cc5374f00971ada556a520197bbed174a35ca9ee16f1a3e1a6aedc639335308b` |
| `timing-investigation/octfail/lint.json` | `e9b53feb228c9a2e8aff4d9c416d559d14981c53c22f46518b8ffc4f8fb84192` |
| `timing-investigation/octpass/lint.json` | `914f2e929f9567388d57ac04dd143175270f9c79ad3288fa92f945b45c7352ea` |
| `timing-investigation/octfail/original.zip` | `928c6db039000f7a651879c45c3abf8acae9344aac32660b28368ecaf8bdc357` |
| `timing-investigation/octpass/original.zip` | `56e1fa0608b648f8109a9155d1536be7d0f338cb43576174f6649626de80af48` |
| `stage-42119802341/prepublication-source-tests-runner.json` | `3804a7f6fd4cf1d1fbc1739e48586d9dbf8dc11c72a36c3145dc18043898f5e7` |
| `stage-42119802341/lint.json` | `3be534fb689525eff114390f5d58d08d5c3d4bf0ef26708bf42b5cd59af8ecd7` |
| `stage-42119802341/original.zip` | `97199b81af2f445e4d62018fa7265061d60a58a7fe2ba659d50f16cfa71b5d84` |
| `stage-42196241166/prepublication-source-tests-runner.json` | `196145f650c2e496fef2b15cdc44ca396490e73a599a8add469975ca6124c825` |
| `stage-42196241166/lint.json` | `aefd7332bb600145426f2525ee148329e7a9665a0cbbc21fc069483086288113` |
| `stage-42196241166/original.zip` | `f07cb361798e5c35ec326f5a1f6e755331abdfa570128264bc9930a7055397de` |
| `stage-42207436828/prepublication-source-tests-runner.json` | `f2cca7549fe7ba1102769c6c7e97dd54d1abd0c99d1a09133a3c98eaf3c2fdec` |
| `stage-42207436828/lint.json` | `b7126696f5e6fa3d3ce548cc5a467d08d50d9c96bb77d65a0d5a5c1b53f2826b` |
| `stage-42207436828/original.zip` | `474ca4e32f2e0ce22649944f2e4c8f233e0ab997d6ed16ecf5f2ca2a4a94d63b` |
| `timing-investigation/cpu/license-wrappers.cpuprofile` | `1fec5f0d5112aa1f401cb063c80decbbbb2509a32b03790280e6ccefedf95858` |
| `timing-investigation/cpu/test.tap` | `8473f78d6510e1021168de8237ad5c7281dcb9503c0a6f6e6f925df1df7bd84c` |
| `timing-investigation/cpu/time.json` | `e76731ae1c52a713998f59f407dd4c3b84b84c855a193cec38ea27db03bd20c7` |

Additional source owners inspected for profile interpretation: `tools/release/rights.cjs` SHA-256 `1730fb1090799cdb81ece8af66102c73bb90732de4d99e8d19734f213757ceb6`; `tools/site/article-media.cjs` `23d46312c654be5286110ca965870ea489c95c68b7572d19fa32475a2cd7a798`; `tools/site/articles.cjs` `78eba91a08bd9a83d4c4c644216968ce99a80382631302792a7971f24ee57954`; `tools/publishing/article.cjs` `54459f1f49b3405bc5fdf9f5a3e627d026ad3bbe7822026dc1ca4602a69eb7cb`. Release-rights test identity remains `d9ed3d9463564e61a4e0a435618fcf5565b2165d7a78a9ab3e49d62083c7ec81`.
