# White-box final reconciliation review

Role `/root/timing_whitebox`; owner #169 / PR #170. This is declared reconciliation, not a fresh first judgment. Initial independent outputs remain retained. Reviewed authored report `/workspace/scratch/20e98a342431/timing-evidence/review/issue-169/2026-11-06-staging-timing-investigation.md`, verified SHA-256 `4b3adf2a1e07191f4a86b527ba8f17a2f0155c755f6b783dab5f3deab0fc7a76`. Exposure includes that report's role summaries, not the underlying peer files. Reused my independently recomputed native October/November timing/environment evidence and inspected the added raw child observer/results. No campaigns, source changes, peer-file reads, external writes or delegation; only this assigned output was written. Common/role/packet identities remain as in my first report.

Verdict: the substantive counters, timeline, hardware association and uncertainty are supported within the inspected evidence. The report preserves failed/incomplete acceptance and does not convert targeted profiling or source-only passes into staging admission. No blocking White-box finding. One low-severity wording correction is recommended below.

## Reconciliation checks

| Claim | Independently checked evidence | Result / boundary |
| --- | --- | --- |
| Latest deadline accounting | Native runner JSON/stderr/TAP previously recomputed | 75 selected, 60 dequeued, 56 complete, 4 active, 15 unstarted; ETIMEDOUT, missing terminal accounting; partial passes do not establish success |
| Broad November slowdown | Recalculated all 56 shared module ratios | Medians 1.643465x / 1.652252x; supports the report's about1.64–1.65x |
| Eight longer module subset | Rights/controller/Pages-delivery/Pages-migration/publication-records/Space/executive/publishing | Medians 1.577594x / 1.568671x; report's about1.57x is a distinct valid population, not contradictory accounting |
| November source passes versus full preflight | Reopened both 42196241166 and 42227207673 prepublication.json | source-tests pass in both, security fails in both, overall pass false |
| October exact-source pair | Original ZIP members byte-equal to extracted native records, as previously verified | Same source/tree, 79-module argv, base artifact, Node/image/kernel/RAM;180s timeout on7763 versus142.059s full1156-case pass on9V45; CPU-only causality remains unproved |
| Source history | Read Git sources/diffs for1f791427,9dc0d425,f9b98f79,e24168ea,f2f2ac25,fc205b17 | Existing16 wrapper variants and CLI tests; hosted reconstruction/media path; method6→4 plus heavy-guard exclusivity;180→300s change; added launch-validation AST compile are supported |
| Local profiler percentages | Reused my independent profile aggregation |86.945% synchronous-spawn sample weight;52.174% media and30.019% publisher compile callers; report correctly excludes interpretation as child CPU self-time |
| New child counter | Inspected observer source, JSON, time and TAP | Counts/durations below agree; no full-suite extrapolation |

The report's outer cancellation/hosted-skip description and launch-receipt mechanics were not newly independently reverified in this three-minute reconciliation scope. Its explicit uncertainty about the cancellation trigger is appropriate. No new assurance about those surfaces is supplied by this White-box result.

## Child observer verification

`child-count.cjs` replaces `cp.spawnSync` with a synchronous wrapper, calls the original with unchanged command/args/options/this, returns the result, and records elapsed time in finally. It aggregates by executable basename plus the first argument and writes rows on process exit. This records observed intercepted calls; it is not process-wide tracing of every possible spawning API, descendant process, CPU activity or I/O wait. The wrapper adds observer overhead and may perturb function identity; the report appropriately treats timings as local observations.

| Observed kind | Count | Raw wallMs | Report rounding | Nonzero results |
| --- | ---: | ---: | ---: | ---: |
| git:--no-replace-objects |357|1581.852918|1.58s|0|
| node:…/tools/publishing/ast.mjs |51|9505.214344|9.51s|0|
| python:web-media.py |17|15649.747085|15.65s|0|

Totals are425 intercepted calls and26736.814347ms accumulated synchronous-call wall time, about87.165% of the30.673761109s command wall time.17 preparations correspond structurally to the initial fixture preparation plus16 rights.compile calls;51 AST calls and357 Git calls are3 and21 per preparation. This supports repeated work in the observed case, not a guarantee that all of that wall time is removable. Child calls are serial in the observed parent path, but elapsed wall time still does not distinguish child compute from waiting.

The raw observer JSON itself records Nodev24.22.1, addressing the local-version provenance gap in the earlier profiler-only evidence. The TAP records1 test/pass, zero fail/cancel/skip/todo; case30519.932708ms, TAP duration30556.840208ms, command exit0. stderr is empty. time.json contains29.986864user/5.37375system CPU seconds; those are not used to infer single-thread parent utilization or CI speed. Current checkout inspection remains clean at e50c63de; the observer results themselves do not contain a source/tree identity at execution time, so the report relies on the separately retained launch/source receipt for that binding.

## Finding and acceptance boundary

**Low: F03 heading "Repeated article preparation is a measured avoidable cost surface" overstates the measured result slightly.** Repetition and elapsed cost are measured; avoidability with preserved successful-path and refusal behavior remains a proposed implementation hypothesis. Rename it to "Repeated article preparation is a measured cost surface" or "Repeated article preparation is a measured optimization target." The body and recommendations already correctly require checking failure precedence, source/media/pixel/rights invariants and invalidation, so this is wording precision rather than a blocker.

The report correctly distinguishes historical180s PR source timeouts from current300s staging timeouts, observed onset from first-ever occurrence, CPU association from sole causality, and local single-case measurements from native four-worker CI. Moving public-notice validation earlier is explicitly proposed and unimplemented. No justified whole-suite saving, completed staging, merge/promotion authorization, or satisfied whole-issue AC is claimed. AC04/05 DELIVERY remain pending on actual complete acceptance.

## Added evidence identities

- child-count-6.json: `afb776bada4ad35d803ebdc39ad931b2cf2e532f0df7c10570aa08ca5a4b329c`
- child-count-time.json: `7b4f2dee3952d80486856f96f5c8184aa783180bc3b426b178781ae2e7562e99`
- child-count.tap: `1195fc6522cdb7cda6d7f9ba1e0267e82d878fcbb7342c2e29fb965e3384dc6f`
- child-count.stderr: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- child-count.cjs: `3b30654d5bb1dc49c54aa3e2255ce8f60b44b5a0a988377189d1394396f3705f`

No measured branch coverage or new dynamic correctness assurance is claimed. Source readings and retained-result analysis are the actual checks performed.

## Reconciliation correction readback

Subsequently reviewed report revision SHA-256 `f15754ee258917b8af273bc9a6310d3e78f918b6ee167ec152e7b862c94bc5c6`. Its revised F03 correctly describes about87% of **sampled elapsed time**, limits the counter to intercepted `cp.spawnSync` calls, explicitly excludes `execFileSync` paths from that census, and says the malformed candidate is rejected by later rights validation without asserting an observed exception identity. Source readback confirms `publicNotices` owns exact legal-copy checks and is invoked after hostedInventory; roomInventory is not the owner of those legal-copy checks. This also corrects the overly specific roomInventory-rejection wording in my earlier historical delta; that earlier artifact remains retained as requested.

The revised counter/profiling/exception wording is accepted. No new campaign or source change was executed. The low-severity F03 heading suggestion above remains applicable: avoidability is proposed, while repeated cost is measured. No blocking finding or acceptance extrapolation was introduced by this revision.
