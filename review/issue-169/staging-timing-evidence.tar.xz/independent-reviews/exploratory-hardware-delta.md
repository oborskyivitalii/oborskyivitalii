# Exploratory / Interaction QA — hardware and cancellation delta

This is a separate continuation after the first independent result was retained. Role `/root/timing_exploratory`; no peer output, parent notes, MEMORY or narrative reports read. New factual input from the orchestrator: inspect `lint.json` CPU identity in the original three native artifacts and `stage-42119802341`, `stage-42196241166`, `stage-42207436828`; read-only GitHub job/cancellation metadata permitted. Original packet/prompt identities and investigation-only boundaries remain those recorded in `exploratory-first.md`. This continuation reuses its own source-path knowledge; it is not a new fresh-context first review.

Charter: determine whether environment identity strengthens attribution of source timeouts, distinguish capacity from CPU identity, and correlate late cancellation with missing final reports. Executed actions were bounded read-only JSON extraction, native timing counts, Git blob comparisons, repository-owned environment source inspection, and GitHub Actions job metadata/log retrieval. No new tests, staging run, implementation, recursive delegation or external mutation occurred. Repository working tree remained clean.

## Native hardware observations

`tools/quality/common.cjs:11–23` records `cpus` using `os.cpus().map(x => x.model)`, together with kernel, Node, image, memory, run and attempt identity. Thus these are model strings reported by the allocated runner, not an independent hardware attestation or a benchmark. Each `lint.json` binds the source/candidate commit and run ID; corresponding source reports bind the same commit, clean before/after.

| Run / source commit | Reported CPU model (four entries each) | Source execution | File starts / completions |
| --- | --- | --- | --- |
| 42119802341 / `b75a0a31e36be02bea15bb7a0b269d032fa3cdcb` | AMD EPYC 7763 64-Core Processor | failed: ETIMEDOUT, 300000 ms configured | 28 / 24 |
| 42196241166 / `95d3e78d7e76d3e267351b8ca1efff206f99b748` | AMD EPYC 9V45 96-Core Processor | passed: 223740 ms | 75 / 75 |
| 42207436828 / `d5e915feb3ba02d7a80325664c9d1d10a2ac494e` | AMD EPYC 7763 64-Core Processor | failed: ETIMEDOUT, 300000 ms configured | 66 / 62 |
| 42227207673 / `186f28c0ad8f94b21c350d50608d337f64c66708` | AMD EPYC 9V45 96-Core Processor | passed: 201620 ms | 75 / 75 |
| 42233889474 / `e50c63de071de6837cf9b6405569bb9a68afd5da` | AMD EPYC 7763 64-Core Processor | failed: ETIMEDOUT, 300000 ms configured | 60 / 56 |
| 42237763419 / same e50c63d | AMD EPYC 7763 64-Core Processor | failed: ETIMEDOUT, 300000 ms configured | 60 / 56 |

All six source timing headers report Node `v24.19.0`, available/configured parallelism 4, concurrency 4 and 75 files. The selected module **path sets** match exactly, not just counts. All six lint environments report Linux x64, kernel `7.0.0-1017-azure`, runner image `ubuntu24`, image version `20261101.360.1`. Memory is 16760344576 bytes except the final run, 16760336384 bytes, an 8192-byte difference. The model names' 64-/96-core labels do not mean the job could use 64/96 workers; the observed allocation/capacity is four.

Git blob comparisons across all six source commits show the same byte identity for `source-test-worker.cjs`, `source-tests.cjs`, `prepublication-runner.cjs`, `local.cjs` and `site-color-review.yml` (blob prefixes respectively `73e205eaa17f`, `6c0edb6f7a1e`, `a0ebeb3288df`, `f1a9265135e1`, `38c6667bb783`). `release-controller.test.cjs` and `tests/fixtures/delivery.cjs` are also unchanged. `release-rights.test.cjs` differs between the first three and last three; other tested source/data differ across commits. Identical harness and selected paths do not establish identical workload bytes.

Primary lint byte identities, SHA256:

| Run | lint.json SHA256 |
| --- | --- |
| 42119802341 | `3be534fb689525eff114390f5d58d08d5c3d4bf0ef26708bf42b5cd59af8ecd7` |
| 42196241166 | `aefd7332bb600145426f2525ee148329e7a9665a0cbbc21fc069483086288113` |
| 42207436828 | `b7126696f5e6fa3d3ce548cc5a467d08d50d9c96bb77d65a0d5a5c1b53f2826b` |
| 42227207673 | `34a9d220990ca524fa17d475215870d7cf06efe1d592045e88da67bc852ee915` |
| 42233889474 | `6e154d13c46022a46fff5b6e9bcc922193d60d0883abdde967df04830cf0bd5a` |
| 42237763419 | `6cb05000c69911c2fb96b2887b5ff83ffc7f911925b4844324fad4ca75eeeaf6` |

## Cancellation/reporting operator journey

Fetched directly through read-only GitHub API: jobs for both current-head runs and full decoded logs for their build jobs. API workflow `head_sha` is the protected controller `8cf15883125892710633b17133d9ee0fc4b23b92`, while native source/lint reports bind candidate e50c63d. These identities have different roles and must not be conflated.

| Observation, UTC 2026-11-06 | 42233889474 / job 127946740585 | 42237763419 / job 127960296355 |
| --- | --- | --- |
| Build started | 14:26:55 | 14:53:13 |
| Prepublication step started | 14:28:10 | 14:54:33 |
| Source report ZIP timestamp | 14:33:14 | 14:59:36 |
| Prepublication cancelled | 14:37:09 | 15:03:27 |
| Retain-observations step | success, 14:37:09–14:37:11 | success, 15:03:27–15:03:30 |
| Build completed / conclusion | 14:37:15 / cancelled | 15:03:33 / cancelled |
| Orphan cleanup in job log | 14:37:11; two MainThread processes and one python process terminated | 15:03:30; two MainThread processes and one python process terminated |

Links to primary job observations:

- [42233889474 build job](https://github.com/oborskyivitalii/oborskyivitalii/actions/runs/42233889474/job/127946740585), API `https://api.github.com/repos/oborskyivitalii/oborskyivitalii/actions/runs/42233889474/jobs`, log endpoint `/actions/jobs/127946740585/logs`.
- [42237763419 build job](https://github.com/oborskyivitalii/oborskyivitalii/actions/runs/42237763419/job/127960296355), API `https://api.github.com/repos/oborskyivitalii/oborskyivitalii/actions/runs/42237763419/jobs`, log endpoint `/actions/jobs/127960296355/logs`.

Each log has the same explicit cancellation error, respectively at `2026-11-06T14:37:09.3800910Z` and `2026-11-06T15:03:27.1836859Z`; immediately afterward the artifact upload runs. Final prepublication/security summaries are absent in native retained files, while downstream scanner subreports exist. This upgrades the first review's uncertainty: **actual prepublication cancellation and successful partial artifact preservation are now observed**, not inferred solely from missing JSON. It also establishes runner cleanup terminated remaining processes; application-level complete cleanup before job cleanup is not established.

Both cancellation errors occur about 614 seconds after job start, while the build workflow has `timeout-minutes:10`. This strongly aligns with whole-job deadline enforcement including cancellation grace/cleanup. However, the inspected job metadata/log text says cancelled and does not explicitly identify the actor/reason as deadline exceeded. Attempts to retrieve check-run annotations through the connected GitHub fetch route were unsupported; no annotation evidence was obtained. Therefore I do not elevate that inferred trigger to an explicitly reported timeout reason. I also cannot identify the terminated PIDs as selected source children versus scanner/local wrappers from process names alone. Source ETIMEDOUT was already retained roughly four minutes before cancellation, so the inner failure and later job cancellation are distinct observed events.

## Revised attribution and limits

Hardware identity materially strengthens the environment hypothesis: in this six-run observational sample, both 9V45 allocations completed source execution and all four 7763 allocations exhausted the source deadline. The earlier first review's “same reported parallelism” finding now has a concrete missing distinction: same worker count and runner-image version coexisted with different CPU model strings. Together with broad slowing of unchanged heavy-test paths and an unchanged harness, runner allocation is a strong explanatory factor to investigate.

This remains an association. There is no exact same commit run on both CPU models in the supplied sample; the only repeated same-commit pair is e50c63d on 7763 twice. Commit/content changes and CPU identity are therefore confounded. No CPU utilization, throttling/steal time, clock behavior, disk throughput, memory pressure or host contention was measured here, and the artifacts cannot isolate model-level performance from other correlated VM properties. There is no justified claim that 7763 invariably fails, that 9V45 guarantees success, or that CPU identity is the sole cause.

Onset also moves earlier than the original three-run slice: native source ETIMEDOUT is already observed for b75a0a31 / run42119802341, before the e50c63d security patch. That alone rules out the patch as the first appearance of this source-timeout class. It does not locate the first historical timeout or rule out later patch-specific workload effects. The b75a0a31 Git commit timestamp is 2026-11-05T23:03:22+01:00; a commit date is not the execution timestamp.

Acceptance consequence remains AC04/AC05 DELIVERY: current candidate has incomplete source execution and cancelled prepublication, although partial evidence retention succeeded. These hardware observations provide no passing delivery result or deployment authority. No new regression case was executed; possible controlled comparisons/cleanup diagnostics remain proposals within the existing source/profile/controller owners.
