# Requirements & Acceptance — final reconciliation

**No blocking attribution, onset or investigation-scope defect found in the inspected report. One low-severity numeric reporting correction is needed.** The conclusions remain bounded: native deadline failure, observed host-model association, an exact-source historical failure/pass pair, a measured local subprocess cost path, and unknown first-ever onset/sole cause. This result does not accept whole issue criteria, staging admission, a proposed optimization or release.

This is declared reconciliation by `/root/timing_requirements`, continuing its own first and delta reviews. The authored report now contains role summaries; that exposure is acknowledged and is not described as a fresh clean-context judgment. I did not open other peer output files. First/delta artifacts were not edited. Parent launch/provider-internal limits from my first result remain.

## Identities and actions

- Authored report inspected: `/workspace/scratch/20e98a342431/timing-evidence/review/issue-169/2026-11-06-staging-timing-investigation.md`, SHA-256 `4b3adf2a1e07191f4a86b527ba8f17a2f0155c755f6b783dab5f3deab0fc7a76`.
- Actual owner snapshot now inspected: `/workspace/scratch/20e98a342431/timing-investigation/owner.json`, SHA-256 `8d634ae75d8fcf5e667487931520b12693c79a93afd106c858a1ba45b8d22ba2`, issue #169, `readAt:2026-11-06`, open. It contains historical ACs plus dated amendments, including authorized website publication through existing gates and site-first sequencing. It does not authorize this review to waive those gates or create a new implementation/campaign.
- Local candidate rechecked clean: `e50c63de071de6837cf9b6405569bb9a68afd5da`, tree `1c9d8054afdb0e13377c6ccbcd14b92860653d99`.
- Reused my unchanged primary-evidence inspection from first/delta. Independently recomputed November completion counts, host metadata and both 56-module median timing ratios; inspected the supplied child-count observer/results/charter and re-parsed the CPU profile; read source establishing rights check order, article-media preparation and the Python encoder's exact pixel/ICC checks. A scoped Git diff confirmed no changes between `186f28c0` and `e50c63de` in the inspected release/site/publishing/rights/controller/Space/fixture/worker/workflow owners.
- No test execution, campaign, external write, implementation change or delegation. No narrative report outside the assigned final report was read. Only this assigned final artifact was written.

## Finding RQ-F1 — Low: F03 percentage has an unsupported value/denominator

Location: F03, local diagnostic 1: “86.94% of samples occur in synchronous child spawning.”

From `cpu/license-wrappers.cpuprofile`, leaf sample IDs whose frame function is `spawnSync` account for **23,596 / 27,282 samples = 86.49%**. Summing the corresponding `timeDeltas` gives **26,236,773 / 30,166,436 microseconds = 86.97%** of sampled elapsed intervals. The report's 86.94% matches neither recomputation. The media/AST shares of roughly 52%/30% are consistent with sampled elapsed-time classification from my delta review.

Implication: the broad explanation survives, but the exact percentage should not be represented as independently reproduced. This concerns evidence/reporting precision under AC05 and the failure-diagnosis protocol.

Treatment: replace with **“about 87% of sampled elapsed time was at synchronous child-call frames”**, retain the statement that this is not child CPU self-time, and keep denominator terminology consistent for the other percentages. The replacement is a proposed factual correction, not an edit made by this reviewer. Exact-source acceptance of a corrected report must record its new digest and verify the change preserves meaning.

## Claim and scope assessment

| Report claim / owner link | Check and observation | Assessment |
| --- | --- | --- |
| F01: deadline/progress and hardware grouping | Recomputed November completion counts 24/75, 75/75, 62/75, 75/75, 56/75, 56/75. Re-read matching native lint CPU/kernel/image fields. Candidate paired timing medians are 1.64346x and 1.65225x over 56 completed modules. | Reproduced. Recorded CPU model is an association; report correctly names unmeasured host/quota/load/I/O factors. |
| F02: historical same-source pair and onset limits | My prior raw inspection established identical source/tree/79-module argv, 180 s bound, failed attempt 1 versus successful attempt 2. | Correctly separates October's PR regime from current 75-module/300 s staging. “At least since 25 October” is earliest supplied native dated evidence, not first-ever occurrence. Current-wave staging failure is supplied for 5 November. |
| F03: repeated preparation and local limits | Child-count record: 17 Python media calls / 15,649.747085 ms; 51 AST calls / 9,505.214344 ms; 357 Git calls / 1,581.852918 ms; zero nonzero subprocess results. Local selected case 1/1 pass; command wall 30.673761 s. Observer forwards original `spawnSync` arguments/results and adds timing/accounting overhead. Source calls hosted inventory before room inventory. | Counts and rounded table values reproduced. Local Node 24.22.1 and one selected case are distinguished from native CI 24.19.0/four workers. This demonstrates a cost surface, not a guaranteed saving or a sufficient CI fix. Percentage correction above remains. |
| F04: not a new `e50c63de` origin | Earlier native failures and unchanged expensive owners are independently inspected. | Supports this bounded conclusion. I did not independently verify every dated historical commit row or all proposed chronology beyond my prior inspected history; those details are not newly attested by this result. |
| AC05 / AC11 independent review | Report records distinct handles and declared first/delta progression; actual owner requires completed source-bound independent roles. | My own execution/result is real; report summaries do not let this role certify peers or parent spawn receipts. Orchestrator retains actual receipts. |
| Owner release scope and remaining gates | Actual owner preserves review/native/hosted/release observations; report keeps source-pass/security-fail separate, stable staging pending and recommendations unimplemented. | No invented whole-issue acceptance or release waiver. Investigation-only boundaries respected in inspected work. |

The phrase “avoidable cost surface” is an engineering hypothesis supported by repeated work, not an already verified optimization. The report's separate recommendation to inspect earlier public-notice validation, preserve every negative case/successful source-media check and validate failure precedence makes this boundary adequately explicit. Any implementation would require its own requirements/check/review cycle.

Outer job cancellation/collector details and complete historical commit chronology were not independently re-executed or fully traced within this three-minute requirements reconciliation. The report's caveat that raw logs do not attest a cancellation trigger is appropriate. I do not convert another role's summary into my own observation.

## New raw byte receipts

Paths below are relative to `/workspace/scratch/20e98a342431/timing-investigation`.

| File | SHA-256 |
| --- | --- |
| `child-count-6.json` | `afb776bada4ad35d803ebdc39ad931b2cf2e532f0df7c10570aa08ca5a4b329c` |
| `child-count-time.json` | `7b4f2dee3952d80486856f96f5c8184aa783180bc3b426b178781ae2e7562e99` |
| `child-count.tap` | `1195fc6522cdb7cda6d7f9ba1e0267e82d878fcbb7342c2e29fb965e3384dc6f` |
| `child-count.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `child-count-charter.json` | `b56358e8000cc91e1085cd9516d5e2f6d13905424e7b52122d64d3a9d7886af2` |
| `child-count.cjs` | `3b30654d5bb1dc49c54aa3e2255ce8f60b44b5a0a988377189d1394396f3705f` |

Next gate: disposition/correct the small F03 percentage, preserve the first/delta/final results and exact report identity, and keep any later repair or full staging attempt separate from this investigation result. No new campaign is needed to resolve the arithmetic wording.

## Correction recheck — preserved initial result above

The corrected report was read back at SHA-256 `f15754ee258917b8af273bc9a6310d3e78f918b6ee167ec152e7b862c94bc5c6`. This is a targeted continuation after the parent supplied the correction locations, not a fresh independent first judgment.

- **RQ-F1 resolved:** F03 now says “About 87% of sampled elapsed time occurs at synchronous child-call frames,” consistent with my 86.97% time-delta calculation. The child-CPU caveat remains.
- **Failure-location precision improved:** F03 now attributes rejection neutrally to later rights validation, identifies `publicNotices` as owner of exact legal-copy checks, and says the observer did not capture the caught exception identity. I checked `tools/release/rights.cjs`: `hostedInventory` runs at line 398; `publicNotices` is defined at line 363, owns the full-notice assertion at line 386, and is called at line 472. The assertion that hosted preparation precedes later checks remains supported. The raw counter alone must not be used to identify the exact thrown check.
- **Counter scope corrected:** the table now explicitly counts calls observed through `cp.spawnSync`, and the paragraph excludes `execFileSync` from the census. This matches the observer source, which wraps only `cp.spawnSync`. The reported 17/51/357 counts remain unchanged and are bounded observed calls, not all process/Git operations.

No blocking Requirements finding remains in the corrected affected paragraphs. The original report-specific numeric defect remains preserved above as history and is resolved for this new digest. Causal/onset, local-versus-native, whole-issue acceptance and unverified-scope limits stated in the initial reconciliation remain. No new tests, campaign or implementation was needed or performed.
