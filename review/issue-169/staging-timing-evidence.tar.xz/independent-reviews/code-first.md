# Independent Code / Artifact first result — PR170 staging timing

Date: 2026-11-06. Role execution: `/root/timing_code`, distinct nonauthor reviewer. Scope is investigation, not implementation or release acceptance.

## Result

The native evidence establishes aggregate source-suite exhaustion of the unchanged 300000 ms deadline on two e50c63de runs. It does **not** establish that release-rights or release-controller failed: both files complete successfully before the suite is interrupted. These files are substantial contributors to the suite critical path, but their code, dependencies described below, public fixture bytes, selection, concurrency and deadline are unchanged between the passing 186f28c0 run and e50c63de. There is no demonstrated executable change in that interval that explains the broad early slowdown.

A common throughput reduction is a supported explanation: many independently unchanged files slow by approximately 1.5–1.7 times, beginning with the first four files before the changed quality-sources file starts. Machine CPU quota, actual delivered CPU, filesystem throughput, pressure and provider contention are not observed here. Identical reported four-worker capacity does not prove identical effective resources. Treat an environment explanation as a hypothesis, not a proved root cause.

## Source and isolation receipt

- Packet: `/workspace/scratch/20e98a342431/timing-investigation/packet.json`, SHA-256 `fca1c5dacd743fd251528077caeba3f2d71e0ae137921cf09d6c5a9ae9e99ea2`. Every file byte hash in the packet matched at inspection.
- Common prompt SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code prompt SHA-256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Candidate `e50c63de071de6837cf9b6405569bb9a68afd5da`, tree `1c9d8054afdb0e13377c6ccbcd14b92860653d99`. Comparison `186f28c0ad8f94b21c350d50608d337f64c66708`, tree `8b09d57484b1102e2b3f9affc020b9a3d12cc297`. Packet integration base `8cf15883125892710633b17133d9ee0fc4b23b92` is not the pass/failure comparison base.
- Local native Git checkout was clean; branch ref pointed to candidate. Inspected README, root AGENTS, applicable CONTRIBUTING reviewer/failure protocol, acceptance issue-169, repository-map owner entries, source/diffs and historical Git blobs. Only root AGENTS was found. The supplied task explicitly excludes MEMORY, overriding its usual startup reading route for this reviewer.
- Did not inspect MEMORY, narrative review reports, peer output, parent notes or conversations. Historical commit messages and source comments contain prior diagnostic/validation claims; those were encountered through Git/source inspection and were not accepted as timing evidence. No unexpected author/peer narrative file exposure occurred. Provider-side memory/context injection and accepted launch isolation parameters are not introspectable here; orchestrator owns that receipt.
- No campaigns, builds, installations, new tests, repository edits, external writes or delegation. Checks were source reads, `git diff/log/show/ls-tree/status/show-ref`, SHA-256 verification and bounded Python extraction of retained raw logs. Only this assigned result was written.

## Native comparison

Raw owners are each run directory under `/workspace/scratch/20e98a342431/stage-RUN/`: `prepublication-source-tests-runner.json`, `.stderr` and `.tap`. Values below come from the runner JSON and advisory file completion events, not recomputed tests.

| Run | Commit | Overall source result | Rights file duration | Controller file duration | Quality-sources file duration |
| --- | --- | --- | ---: | ---: | ---: |
| 42227207673 | 186f28c0 | 1202/1202 pass; 201620 ms | 128687.714 ms | 85975.806 ms | 12180.202 ms |
| 42233889474 | e50c63de | ETIMEDOUT; no final accounting | 205686.077 ms, pass | 132224.340 ms, pass | 19274.242 ms, pass |
| 42237763419 | e50c63de | ETIMEDOUT; no final accounting | 204605.637 ms, pass | 131106.159 ms, pass | 20049.914 ms, pass |

All three select 75 files and report Node v24.19.0, available/configured parallelism 4, concurrency 4. The passing run has 75 advisory file completions; each failure retains 56 completions. Their last dequeue is quality.test.cjs at 296532 / 296541 ms. These event counts are diagnostic observations, not final case accounting. Both failed JSONs explicitly lack final test/pass/fail summaries.

Quality-sources starts only at 134699 ms on the passing run and 218496 / 215644 ms on the failing runs. Earlier unchanged pages-migration slows 1.55/1.53 times, pages-delivery 1.55/1.54, controller 1.54/1.52, publication-records 1.56/1.55, rights 1.60/1.59. Later unchanged files show a similar pattern (space 1.67/1.63, site-engine 1.66/1.67, executive 1.65/1.68). This argues against attributing the early slowdown to the changed quality-sources test body.

`tools/quality/source-tests.cjs:573–610` launches one worker process under the 300000 ms bound; its 330000 ms outer wrapper adds report grace, not execution allowance. `tools/quality/source-test-worker.cjs:14–28,68–106` schedules longest-priority files on up to four isolated processes. The deadline covers the entire selected suite, not each file. Thus rights finishing at 205 seconds is compatible with subsequent aggregate timeout at 300 seconds.

## Exact 186f28c0 → e50c63de changes

Complete name/status inventory contains 16 paths. Fourteen are metadata, retained review report compression/new evidence, and security review ledger data. The only executable-code edits are:

1. `tools/quality/scanners.cjs:480–487`: two additional exact reviewed public-inventory path/type/hash tuples; no broad wildcard or suite scheduling change.
2. `tests/quality-sources.test.cjs:798ff`: the same exact-tuple acceptance/refusal assertions now iterate two hashes rather than one for two inventory paths. This adds bounded fixture ledger work in that file.

`tools/quality/secrets-reviewed-checksums.json` adds reviewed entries. The three old review Markdown files are replaced by short compressed-history pointers with `.gz` files added. This changes scanner/RI/format input data and cannot be called zero runtime impact, but it does not change docs or the site subtree copied by delivery fixtures. The raw early-file slowdown predates quality-sources execution. Source tests are exclusive in prepublication (`tools/quality/local.cjs:410–417`); `prepublication-runner.cjs:135–155` honors exclusivity, and synchronous mode also does not overlap guards. The scanner is therefore not evidenced as competing with source-tests inside this workflow step. Source-path effects through another test or subprocess remain a possibility requiring direct observation, not an established mechanism.

Explicit diff check is empty for release-rights/controller tests, delivery fixture, public-artifact, snapshot, source-tests/worker, local runner and site-color-review workflow. Docs, site/assets and site/retained Git inventories are byte-identical over this interval. Report compression is not a demonstrated cause of release fixture slowdown.

## Why these paths are expensive, and when that structure entered

**Release-rights fixture:** `tests/release-rights.test.cjs:23–79` creates and recursively copies a fresh source tree (including all `site`, `tools/site` and `tools/publishing`) for each fixture; builds all public output; and computes a manifest whenever `record()` is called. Its `compile()` calls record and `rights.compile`, which calls artifact verification and rereads/hashes public and authored source inventories (`tools/release/rights.cjs:62–90,391–405,468,496–498`). Negative tests intentionally invoke those paths repeatedly. `snapshot.verify` reads runtime/media aliases, routes, article assets and every HTML document and validates local link closure (`tools/site/snapshot.cjs:130–255`). These are real synchronous reads/copies/hashes, not a waiting network request.

**Delivery/controller fixture:** `tests/fixtures/delivery.cjs:13–60` still rereads/hashes docs on every source call even with seed reuse, writes a fresh public copy, and verifies snapshots. `rightsInventory` (`:140–185`) creates a shared local Git clone on a fresh source root, recursively copies `site` and other source scopes, compiles exact rights, and writes the report. `staging` and `production` call it. `tests/release-controller.test.cjs:23–64` repeatedly constructs a production fixture and launches Python release packing. `tools/release/package.py:33–50` rereads every public file and gzip-compresses its tar stream. That Python archive compression is separate from the JavaScript gzip-size cache.

**Article/rights work:** `rights.cjs:214–339` selects and renders accepted article sources via `tools/site/articles.cjs:24–87`, checks media/download/resource closure, and hashes input paths. Room inventory also recreates the authored scene model (`rights.cjs:342–359`). This survives caching of gzip sizes.

Relevant historical source anchors (dates are commit timestamps, not first observed timeout):

| Commit | Timestamp | Directly inspected change / significance |
| --- | --- | --- |
| 301a2f6169a4d377448032310f58aea76c93a86d | 2026-10-03 | Git pickaxe identifies gzipSync introduction in quality artifact history. This is the historical search result, not a benchmark. |
| a775acde6e328eafd752ff5713d3f1b59001fb4d | 2026-10-13 | Extracts shared public-artifact module with full reads/hashes and gzipSync on every manifest entry. It does not establish first existence of all compression work. |
| 1f79142760d5b114f35ef30e92601369c21172b6 | 2026-10-15 | Introduces release-rights fixture building/copying and delivery rightsInventory; staging/production fixture rights compilation becomes routine. |
| 0a0acbf56941e3c04a24ff1362c9b47b071b5b58 | 2026-10-15 | Adds source/staging seed reuse while preserving actual reads/hashes and copied isolated bytes. This reduces some repeated preparation, not all fixture work. |
| b0e59ddd21c39b23ec2fcf81d0f55392d826f659 | 2026-10-31 | Delivery rightsInventory adds local shared Git clone for immutable native article source resolution; native rights cases expand. |
| 326022f35e4a75b76c00f200ee229c39d44554db | 2026-11-01 | History search identifies introduction of nativeCurrentArticle fixture branch, retaining the actual native article/toolchain source checks. |
| 39b681ee0185f048d97815c7b4469fa8926e43db | 2026-11-01 | Moves measured long rights/controller/Pages files earlier without changing four-worker or 300-second contract. Its comments refer to earlier receipts, but those receipts were not in the supplied raw evidence. |
| 2353b7c82123e053b9987321be1f8fea4e6c0d1c | 2026-11-06 10:18 +01 | Adds bounded process-local gzip-size cache keyed by SHA-256 plus byte length. Full inventories, reads and hashes remain. Cache is not shared across isolated files or Python packing. Already present in both compared refs. |
| 8795e20b27c282c74c2dca2fbc1111c3d5acb62f | 2026-11-06 14:17 +01 | Hoists a repeated snapshot.verify/record computation out of retained-rights per-entry filter. Already present in both compared refs. |

The persistent public/source workload grew historically. Read-only `git ls-tree -rl REF docs site/assets site/retained` gave logical tracked-blob counts/bytes:

| Ref | docs | site/assets | site/retained |
| --- | ---: | ---: | ---: |
| 1f791427 | 41 / 1,944,946 | 5 / 158,923 | 15 / 610,622 |
| b0e59ddd | 68 / 5,606,156 | 51 / 22,417,042 | 45 / 4,539,887 |
| 7c292bd5 | 85 / 7,390,394 | 57 / 23,194,821 | 51 / 4,893,062 |
| 186f28c0 | 85 / 7,389,048 | 57 / 23,194,821 | 51 / 4,893,062 |
| e50c63de | 85 / 7,389,048 | 57 / 23,194,821 | 51 / 4,893,062 |

These counts establish more data for repeated full-tree fixture work over time. They are not copied-byte measurements and do not quantify a particular runtime regression. Article assets in a source tree can be copied even when the test later isolates its public catalog. Conversely, docs size alone understates source fixture copy cost.

## Findings and limits

1. **High evidence issue: causal attribution to e50c63de is unproved.** Exact source diff and early timing pattern do not connect its executable changes to release fixture slowdown. This affects investigation accuracy and issue-169 AC05 source-bound evidence. Treatment: preserve the narrow observed onset (pass at run 42227207673, failures at 42233889474/42237763419) separately from root-cause hypotheses. Do not label that commit the performance regression solely because it precedes failures.
2. **Medium diagnostic limitation: expensive operations are structurally identified, not profiled.** Repeated recursive copy, full inventory/hash/closure verification, native article selection and Python archive gzip are plausible work components. Current evidence cannot allocate the extra 76–77 seconds in rights or 45–46 seconds in controller among them. Treatment: if subsequently authorized, use a bounded instrumented single-file comparison recording per-operation wall/CPU time, copied bytes, cache misses and runner CPU/quota/pressure; no full staging retry is needed to answer that allocation question.
3. **High acceptance limit: partial failures cannot be called passing source coverage.** Successful rights/controller file wrappers do not establish final 1202-case completion, hosted staging or release readiness. Retain the failed attempt and unknown final accounting. No release approval is provided.

Earliest actual PR170 timeout cannot be dated from these three raw directories alone. Historical scheduling/performance/cache changes show longstanding pressure and mitigation, but commit messages/comments are not primary observations of first timeout. No exact assertion failure, deadlock, network stall or cache correctness defect was demonstrated in this bounded inspection.

## Factual source-packet delta received before return

The orchestrator subsequently authorized three additional primary raw directories only: `stage-42119802341`, `stage-42196241166`, and `stage-42207436828`, under the same scratch root. This is an access/evidence delta to packet-v1; the original packet digest remains unchanged. The initial three-run analysis above is preserved. No parent narrative or peer result was supplied or read.

Read each new `prepublication-source-tests-runner.json` and `.stderr`, and the 95d3e78 `prepublication.json` where available. Additional native observations:

| Run | Exact source | Source-suite result | Rights duration | Controller duration |
| --- | --- | --- | ---: | ---: |
| 42119802341 | b75a0a31e36be02bea15bb7a0b269d032fa3cdcb | ETIMEDOUT; no final accounting | 246514.245 ms, pass | 162164.313 ms, pass |
| 42196241166 | 95d3e78d7e76d3e267351b8ca1efff206f99b748 | 1198/1198 pass; 223740 ms | 143729.154 ms, pass | 93528.236 ms, pass |
| 42207436828 | d5e915feb3ba02d7a80325664c9d1d10a2ac494e | ETIMEDOUT; no final accounting | 202135.569 ms, pass | 129319.436 ms, pass |

Source trees respectively: `f3b8baa6f14e20d4b33593577e8bac4e07287814`, `28a95e053b0036bc7e1e947232847dd51ce410ff`, `33c68e13bc7c8c78acb9abc2cf61066977de1284`; all recorded clean. Every additional capacity event reports Node v24.19.0, 75 files and four configured/available/concurrent workers. The 95d3e78 whole prepublication result is false because security fails; its source suite independently passes.

**Updated onset conclusion:** among the six accessible runs, timeout is already observed at b75a0a31 (the supplied run is from 5 November), followed by a source-suite pass at 95d3e78, timeout at d5e915fe, pass at 186f28c0, then two timeouts at e50c63de. Therefore the failures demonstrably predate e50c63de and the 6 November gzip-cache change is not the original introduction of timeout. Exact first-ever PR170 timeout still requires earlier native run inventory. The changing source count (1198 versus 1202 later) prevents treating all historical workload as identical; the alternating results still refute a simple first-onset-at-e50 narrative.

### Additional primary environment observation

On the orchestrator's factual pointer, independently read `lint.json -> environment` in all six already permitted raw directories, then traced its producer to `tools/quality/common.cjs:11–20` (`os.cpus().map(x => x.model)`) and `scanners.cjs:1113`. Every lint report's sourceCommit and runId match its directory/source-runner record.

| Runs | CPU model reported for all four visible CPUs | Source-suite result |
| --- | --- | --- |
| 42119802341, 42207436828, 42233889474, 42237763419 | AMD EPYC 7763 64-Core Processor | All four time out |
| 42196241166, 42227207673 | AMD EPYC 9V45 96-Core Processor | Both pass |

All six report Linux x64, kernel `7.0.0-1017-azure`, Node `v24.19.0`, runner image `ubuntu24`, image version `20261101.360.1` and approximately 16.76 GB total memory. This independently observed CPU-family split materially strengthens the environment explanation and explains why identical visible concurrency is not an adequate machine comparison. It does **not** prove delivered CPU frequency, host load, quota or CPU-only attribution: source revisions differ between CPU families and no same-commit 9V45/7763 pair is in the six-run set. The two e50c63de repeats are both on 7763. Preserve this as a strong correlation with the broad timing slowdown, not an experimentally isolated processor benchmark.

An additional source diff check shows 95d3e78d→d5e915fe changes only three policy/ledger files under tools, tests, site, docs and workflows: bandit-policy.json, secrets-publication.json and secrets-reviewed-checksums.json. Release tests/fixtures/runner/public bytes are unchanged in that scoped comparison as well. No new campaign is needed to establish these recorded facts.
