# Independent White-box QA first judgment

Role/task: `/root/timing_whitebox`. Owner #169, PR #170. Investigation only: reasons for staging timeouts, onset and relationships; no implementation, full staging retry, merge or production. This is a first independent result, before peer reconciliation. I read no narrative reports, MEMORY, current peer outputs or parent scratch notes. The parent supplied a later factual evidence-location delta, described below. Actual launch/isolation acceptance and provider context/model internals must be recorded by the orchestrator; they are not independently observable inside this execution.

## Verdict

The raw evidence establishes a 300-second source-worker deadline failure with broad execution slowdown and incomplete accounting. It does **not** establish a single hung rights case or an e50 security-remediation regression. In the latest two failures, rights and controller modules both complete successfully long before the deadline. Almost all comparable completed modules are slower, including unrelated source tests. Hardware/runner capacity is a credible explanation, but CPU count alone cannot prove it; no CPU model, frequency, cgroup throttling, per-process CPU, storage latency or memory-pressure telemetry is in the inspected native reports.

The oldest additionally supplied timeout is already on 5 November at b75a0a31. A later 6 November run passes, another earlier R10 run fails, then the immediate predecessor passes, and both e50 runs fail. This is intermittent within the retained evidence window. This sample cannot establish the first-ever onset or all historical occurrences.

## Identity and execution limits

- Packet v1 `/workspace/scratch/20e98a342431/timing-investigation/packet.json`: SHA-256 `fca1c5dacd743fd251528077caeba3f2d71e0ae137921cf09d6c5a9ae9e99ea2`.
- Common prompt `agents/reviewers/README.md`: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role prompt `agents/reviewers/white-box-qa.md`: `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Local checkout is clean at `e50c63de071de6837cf9b6405569bb9a68afd5da`, tree `1c9d8054afdb0e13377c6ccbcd14b92860653d99`. Packet base is `8cf15883125892710633b17133d9ee0fc4b23b92`. All packet-listed source SHA-256 identities matched their actual local bytes at initial inspection. No live remote ref freshness is claimed by this execution.
- Read README, root AGENTS, reviewer prompts, relevant CONTRIBUTING diagnosis protocol, issue-169 acceptance manifest, relevant REPOSITORY-MAP entries, source runner/scheduler/prepublication owners, fixture/rights/controller/public-artifact sources, workflow runner labels, and bounded Git history/diffs. No nested AGENTS was found in the enumerated repository inventory.
- Executed only read-only shell/Git and bounded Python extraction of retained native JSON/stderr/TAP/ZIP metadata. No tests, campaigns, browser actions, source/test changes, external writes or delegation. The only created artifact is this assigned output.
- Original raw evidence: stages 42227207673, 42233889474, 42237763419. After initial calculations the parent supplied raw locations 42119802341, 42196241166 and 42207436828. I independently extracted them as factual packet-v1 delta; no parent diagnosis or peer output was supplied or inspected.

## Raw accounting recomputation

Each JSON contains 75 selected modules, Node v24.19.0, available/configured parallelism 4, concurrency 4, inner timeout 300000 ms and maxBuffer 16777216 bytes. Source and sourceAfter agree and are clean. All failure reports have child status 1, signal null and explicit `ETIMEDOUT`; none has final tests/pass/fail/cancelled/skipped/todo accounting. No top-level `not ok` appears in their retained TAP. Rendered passing cases are partial evidence, not whole-suite acceptance; completed modules can have output held behind earlier files, so rendered case count is not a complete count of work executed.

| Run | Source prefix | Result | Started / completed modules | Native final accounting | Rendered top-level subtests |
| --- | --- | --- | --- | --- | --- |
| 42119802341 | b75a0a31 | ETIMEDOUT | 28 / 24 | absent | 409 |
| 42196241166 | 95d3e78d | pass, 223740 ms runner elapsed | 75 / 75 | 1198 passed; 0 fail/cancel/skip/todo | 1181, plus 17 nested |
| 42207436828 | d5e915fe | ETIMEDOUT | 66 / 62 | absent | 606 |
| 42227207673 | 186f28c0 | pass, 201620 ms runner elapsed | 75 / 75 | 1202 passed; 0 fail/cancel/skip/todo | 1185, plus 17 nested |
| 42233889474 | e50c63de | ETIMEDOUT | 60 / 56 | absent | 608 |
| 42237763419 | e50c63de | ETIMEDOUT | 60 / 56 | absent | 608 |

The passing predecessor's native TAP duration is 201586.167498 ms; its outer prepublication source task took 201708 ms with 330000 ms wrapper bound. Its **whole prepublication report is failed**, specifically security; source-suite pass must not be presented as complete staging success. Later two directories lack a final prepublication.json, limiting whole-preflight accounting.

In both latest failures four modules are active at the deadline: delivery-observation, prepublication-reuse, publishing-profile and quality. Their elapsed active ages at 300 seconds are respectively 15.685/10.856/4.668/3.468 seconds and 15.954/11.235/5.021/3.459 seconds. Fifteen modules never dequeue: reader-controller, reader-mode, refactor-metrics, release-archive, renderer, review-flow, scroll-entry, scroll-sync, site-face-preparation, site-transaction, staging-gate, staging-regression, staging-reporting, staging-trust and test-profile-selection. This is unfinished total workload, not one case occupying the entire deadline.

## Module and individual-case timing

Seconds, recomputed from native `complete.wrapperDurationMs`:

| Module | 186f pass | e50 failure 1 | e50 failure 2 |
| --- | ---: | ---: | ---: |
| release-rights | 128.688 | 205.686 | 204.606 |
| release-controller | 85.976 | 132.224 | 131.106 |
| pages-delivery | 55.236 | 85.854 | 85.100 |
| pages-migration | 44.554 | 69.015 | 68.016 |
| publication-records | 48.345 | 75.266 | 74.809 |
| space | 65.037 | 108.319 | 106.067 |
| executive | 70.373 | 115.861 | 118.343 |
| site-engine | 16.229 | 26.967 | 27.172 |
| camera-view | 3.073 | 5.274 | 5.379 |
| content-delivery | 3.325 | 5.707 | 5.868 |
| quality-sources | 12.180 | 19.274 | 20.050 |

Across all 56 shared completed modules, median slowdown against predecessor is **1.643465x / 1.652252x**. 55/56 and 54/56 exceed 1.4x; ranges are 1.217876–2.004709x and 1.281459–2.077424x. Median latest-failure-2/failure-1 module ratio is 1.005031. The two failures have a highly similar broad slowdown signature.

Matching unique top-level case names and their native TAP durations produces 608 shared cases. Restricting comparisons to the 332 with predecessor duration at least 100 ms gives median ratios **1.626541x / 1.633451x**, with 266/332 and 264/332 exceeding 1.5x. The extractor matches caption/outcome/duration/type records; it is not branch coverage, nor used to reconstruct missing final accounting.

| Individual case | 186f seconds | e50 failure 1 | e50 failure 2 |
| --- | ---: | ---: | ---: |
| publication actual edition and package CLIs freeze exact sidecars before any upload | 47.126 | 77.280 | 78.539 |
| publication comment and inert-template wrappers cannot hide otherwise exact full license copies | 36.550 | 58.347 | 57.046 |
| preflight edition guard accepts production bytes on either host profile and rejects coverage-edition mismatches | 13.251 | 21.994 | 22.010 |
| migration preparation requires actual accepted source workflow, owner and exact attempt | 13.662 | 21.204 | 22.102 |

Those first two costly rights cases already consume about 65% of rights-module time in the passing predecessor; their proportional slowdown does not show a newly introduced rights-only stall.

Sum of completed module wrapper durations is 795.418 s for the passing predecessor and 1165.256 / 1164.272 s for the two failures. Adding still-active wrapper ages and dividing by four slots times the observation horizon gives approximately 98.65% / 99.994% / 99.995% slot occupancy. This measures occupied **worker slots**, not CPU utilization. A simple uniform 1.64x scaling of the predecessor's 201.6 s yields about 331 s, consistent with crossing a 300 s deadline; this is an explanatory estimate, not a measured finished duration.

Historical rights/controller durations are 246.514/162.164 s at b75a0a31, 143.729/93.528 s at 95d3e78d, and 202.136/129.319 s at d5e915fe. Against the 186f predecessor the median completed-module ratios are 1.885721x (24 comparable), 1.094545x (75), and 1.622345x (62). Historical source differences prevent treating those ratios as a controlled benchmark, but they directly refute onset only after e50.

ZIP member timestamps place these groups on 5 November (oldest supplied failure) and 6 November (all other supplied runs). ZIP timestamps do not establish timezone or authoritative workflow start. Git b75a0a31 author date is 2026-11-05T23:03:22+01:00. Earlier actual native runs are not supplied. Scheduler history already includes a 1 November long-files-first change, but a commit comment alone cannot date the first timeout.

## Structural cause analysis and discriminating checks

Protected invariant: admission requires successful child completion, every selected case passed, zero skips/cancellations and stable exact source. Source-tests lines 9–12 set the 300 s/16 MiB bounds; lines 574–582 apply them to spawnSync. The 330 s outer wrapper grants report-writing grace, not 30 s extra test execution. The worker uses isolated processes with four file slots and serial default tests within each file. Long rights/controller/Pages files already start immediately. Native failure output sizes are about 154 KiB stdout and 16 KiB stderr, far below 16 MiB, so output overflow is not evidenced.

Local.cjs marks source-tests and security exclusive; prepublication-runner's `advance` blocks overlapping local tasks while an exclusive task runs. The source and scheduler owners are unchanged between the passing predecessor and e50. This makes newly overlapping scanner work within this controller unsupported; it cannot exclude unrelated host activity or behavior outside the observed controller.

Exact Git blob comparisons show unchanged source-tests, source-test-worker, prepublication-runner, local, public-artifact, release-rights, release-controller, delivery fixture, Pages tests, Space and executive between 186f and e50. There are no changed paths under docs/, site/, tools/site/ or camera-view. The e50 executable change adds two exact scanner tuple literals; quality-sources extends an existing tuple test. Metadata/review bytes also change. Such inputs can affect repository-dependent tests, but cannot presently explain uniform ~1.6x scaling across unrelated modules. Shared fixtures read/hash/copy complete public bytes; rights compiles/copies source and uses Git clones; expensive rights cases repeatedly rebuild/reconcile editions. These are real intrinsic workload costs, present before e50, and may amplify host CPU/storage limits. Public-artifact gzip caching and delivery fixture caching already exist in both compared sources, so they are not newly absent at e50.

| Risk / AC impact | Structural hypothesis | Smallest proposed discriminating check | Independent oracle / stop |
| --- | --- | --- | --- |
| AC04/05 DELIVERY; correct cause attribution | Runner CPU model/speed, throttling or contention differs despite four reported CPUs | First recover existing runner initialization/image/CPU metadata for all six runs; if unavailable, later authorized targeted runs retain CPU model, affinity/cgroup quotas/throttle counters, peak RSS, per-process user/system time and disk latency | Four CPUs is not performance equivalence. Correlate wall/CPU ratios and metadata with fast/slow cohorts; stop after evidence acquisition, no full retry |
| AC05 exact-source attribution | e50 metadata/test change really causes broad source work | On one controlled machine, compare exact 186f/e50 snapshots with identical Node/toolchain and public bytes using a small unchanged computational module and one representative fixture-heavy case; record outputs, CPU and wall time | Persistent candidate-only increase on same host supports source mechanism; similar timings weaken it. At most one A/B pair per selected scenario, no suite-wide acceptance |
| AC04/05 DELIVERY; efficient existing check | Repeated fixture inventory, copying, Git and compression dominates or becomes I/O bound | Separately profile one existing slow rights case and one CPU-oriented module with bounded source-bound instrumentation outside accepted sources | Time attribution to reads/copies/hash/gzip/child CLI versus CPU/wait discriminates optimization target; preserve all refusal assertions and limits; no optimization authorized by this report |
| AC05 complete accounting | Incomplete TAP accidentally accepted or misreported | Source read confirms status assertion precedes accounting and native failure is retained; existing source-runner negatives own this invariant | Executed outcome is failed, never infer 608/608 full pass. No additional dynamic test needed for this investigation |
| Onset / history | A specific earlier source change created the cost | Obtain earlier retained native reports around 1 November scheduling and R9/R10 transitions, bind source/tree and compare module/case timing | Earliest observed failure remains a lower bound on history, not proof of first-ever occurrence |

Proposed execution belongs to the existing source-test/diagnostic route in SITE-CHECK-PROFILES, with source-tests/test-profiles as module owner and the current staging workflow as observed consumer. It is **deferred and unexecuted** here. No new budgets, source edits or unchanged full campaign retry are justified by these findings.

## Raw evidence identities

SHA-256 entries below are for each directory's `prepublication-source-tests-runner.json`, `.stderr`, `.tap`, respectively. This plus the packet and source hashes makes the extraction inputs reviewable without narrative dependence.

| Run | JSON | stderr | TAP |
| --- | --- | --- | --- |
| 42119802341 | `3804a7f6fd4cf1d1fbc1739e48586d9dbf8dc11c72a36c3145dc18043898f5e7` | `019e1e7aaf2c02b42738ca15a42057ef56f579b4f03cd2188be68f7c768f9e1f` | `3c9cd8f155068cb2b7c0456f51f55e0d815d8c022861f037ebf2cfac090da64e` |
| 42196241166 | `196145f650c2e496fef2b15cdc44ca396490e73a599a8add469975ca6124c825` | `25a8c970c4728a600899fc397ed22e5b082eecf6ef220dd639949d9e80255b82` | `57d50d0c685d18e1dd8e94aa14e513221d87fb852de8b03c7c93c98cd475f88c` |
| 42207436828 | `f2cca7549fe7ba1102769c6c7e97dd54d1abd0c99d1a09133a3c98eaf3c2fdec` | `284a1ead73c82c76a046c96b0029093a88ac3d9d7452e4feec1c8edb675aeff7` | `cfc66ce05aa7b080aa509cec5e289b9495ca2af0af33ed1ca3a7978d65f7089a` |
| 42227207673 | `0395e7dbc91370ca6b66094f9e2c35ffc033e1b7b135774678999845453db60d` | `a68ea08d9cf821b35ba6ca1e8b91be959d56f597c0d73a9574e68095e6ae1420` | `fcafce6497f4a96d39773df26e5b60e02b9c5ffa8fbac7c331362fe00d501ed9` |
| 42233889474 | `fc46368cd131b7dc2f84d8bcdc2073cf7152ad65b24f381413353fd1d43c7bae` | `d7d884eae46997fec3bdb6a6df97b52052a91e2d110203e4991a71d523e15a29` | `4c617825f64af2bbecb8dd744dc268700da61e8c51406f74fa2cb82e22b67f64` |
| 42237763419 | `d3b4910c2077bdd3851b76364e8e666326fcd739f16349c757b0cfb62971b2a9` | `1e775d69628adf6e20890c1ed7d2a012e328cd01d191fbb3ece77a9466acf48b` | `e714e2f5cd34ec5416366a6bc94270a2195ba4e81c242b99e441376589aef80b` |

Unobserved: actual host hardware/image differences, CPU versus I/O attribution, final execution of pending modules, complete later prepublication outcomes, remote ref freshness, earlier native onset, runtime/browser/product performance, and any full acceptance or release readiness.

## Factual delta after the preserved first judgment: retained runner environment

After this first report was written (pre-append SHA-256 `6495c2ea77f6ec3fea408247b1bea838113dc97a64a42a471c64a0896b4d7e6d`), the parent directed inspection of the additional primary field `lint.json.environment.cpus` in the same six native datasets. No parent or peer conclusion was provided. The first-judgment text above is retained unchanged; the following source inspection supersedes its limited statement that CPU model/image differences were not observed.

| Run | Native lint CPU model (four entries) | Source-worker outcome | lint.json SHA-256 |
| --- | --- | --- | --- |
| 42119802341 | AMD EPYC 7763 64-Core Processor | timeout | `3be534fb689525eff114390f5d58d08d5c3d4bf0ef26708bf42b5cd59af8ecd7` |
| 42196241166 | AMD EPYC 9V45 96-Core Processor | pass, 223.740 s | `aefd7332bb600145426f2525ee148329e7a9665a0cbbc21fc069483086288113` |
| 42207436828 | AMD EPYC 7763 64-Core Processor | timeout | `b7126696f5e6fa3d3ce548cc5a467d08d50d9c96bb77d65a0d5a5c1b53f2826b` |
| 42227207673 | AMD EPYC 9V45 96-Core Processor | pass, 201.620 s | `34a9d220990ca524fa17d475215870d7cf06efe1d592045e88da67bc852ee915` |
| 42233889474 | AMD EPYC 7763 64-Core Processor | timeout | `6e154d13c46022a46fff5b6e9bcc922193d60d0883abdde967df04830cf0bd5a` |
| 42237763419 | AMD EPYC 7763 64-Core Processor | timeout | `6cb05000c69911c2fb96b2887b5ff83ffc7f911925b4844324fad4ca75eeeaf6` |

All six lint environments report platform linux, architecture x64, kernel `7.0.0-1017-azure`, Node `v24.19.0`, runnerImage `ubuntu24`, imageVersion `20261101.360.1`, and about 16.76 GB memory. The runId matches each retained directory and attempt is 1. Thus the native telemetry exposes a concrete CPU-model difference despite the same reported four-worker allocation and runner image. All four supplied 7763 observations time out; both supplied 9V45 observations pass. Coupled with broad case/module timing inflation, this materially strengthens runner-hardware throughput as the leading explanation in this sample. It is still an observational association across different source commits, not a controlled estimate of CPU-model causality or a performance guarantee. The latest exact e50 source has two 7763 failures and no supplied 9V45 comparison. The lint and source checks are separate stages on the reported run; the fields do not measure CPU frequency, steal time, throttling, storage, GC or active CPU time during the source worker.

The next discriminating design can now be narrower: keep exact e50 source, toolchain, case set and instrumentation fixed, and compare the same small CPU-oriented and fixture-heavy scenarios across retained/authorized 7763 and 9V45 allocations; separately compare 186f/e50 on the same allocation if source causality remains material. Do not merely request another full staging attempt and hope for a 9V45. No execution was performed for this delta.
