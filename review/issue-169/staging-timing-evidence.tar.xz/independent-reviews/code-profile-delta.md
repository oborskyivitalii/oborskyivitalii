# Code / Artifact operation-profile delta

Execution: `/root/timing_code`, continuation after preserved first report. Date 2026-11-06. This result independently interprets newly supplied raw local profiling evidence. It is not a native CI benchmark, fresh-context review, correction implementation or release approval.

## Finding

The single existing license-wrapper rejection case repeatedly performs accepted-article selection, lossless media preparation and AST compilation before rejecting invisible legal notices. This is an observed operation-level mechanism for substantial work inside this case. It does not identify first timeout or prove which operations explain the native machine slowdown.

Of 30.166436 seconds represented by the profile time deltas, 26.236773 seconds (86.97%) are attributed to synchronous child-process calls. The dominant immediate repository callers are lossless media encoding (15.742401 seconds, 52.19%) and article AST compilation (9.056888 seconds, 30.02%). These are sampled elapsed time while the parent is in a synchronous native child call. They are **not** measurements of Node JavaScript CPU self-time or of particular Python child functions. No Python-internal profile is provided.

The largest repeated stack is:

`tests/release-rights.test.cjs:845 → rights.compile:391 → hostedInventory:214 → articles.select:24 → article-media.render:85 → encode:10 → spawnSync → web-media.py`

The rejection-loop branch alone attributes 25.319574 sampled seconds (83.93% of the whole profile) to `hostedInventory`; it enters that work before the legal-notice failure. This makes validation order a narrower initial optimization target than broad fixture or compression changes.

## Raw inputs, source identity and actions

Source remains clean at `e50c63de071de6837cf9b6405569bb9a68afd5da`, tree `1c9d8054afdb0e13377c6ccbcd14b92860653d99`. The original source packet stays v1 with SHA-256 `fca1c5dacd743fd251528077caeba3f2d71e0ae137921cf09d6c5a9ae9e99ea2`; this section records the separate factual access delta. First report `code-first.md` was not rewritten.

| Supplied raw file under timing-investigation | SHA-256 | Bytes |
| --- | --- | ---: |
| local-profile-charter.json | ac4f8746933253592a764c46b4e73267680fb1dc22d1cbd52890d7861a008dca | 663 |
| cpu/license-wrappers.cpuprofile | 1fec5f0d5112aa1f401cb063c80decbbbb2509a32b03790280e6ccefedf95858 | 782798 |
| cpu/test.tap | 8473f78d6510e1021168de8237ad5c7281dcb9503c0a6f6e6f925df1df7bd84c | 234 |
| cpu/test.stderr | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | 0 |
| cpu/time.json | e76731ae1c52a713998f59f407dd4c3b84b84c855a193cec38ea27db03bd20c7 | 469 |

The charter specifies one existing named test only, timeout 120 seconds, no source edits and no full acceptance claim. Recorded command:

`node --cpu-prof --cpu-prof-dir=/workspace/scratch/20e98a342431/timing-investigation/cpu --cpu-prof-name=license-wrappers.cpuprofile --test --test-isolation=none --test-name-pattern=publication comment and inert-template wrappers tests/release-rights.test.cjs`

The retained textual result says one test passed, zero failures/cancellations/skips, case duration 30062.928046 ms and report duration 30097.564118 ms. Although named `test.tap`, its retained content is the terminal-style summary, not TAP protocol accounting. `time.json` records exit 0, wallSeconds 30.262001768998744, userCpuSeconds 30.296535, sysCpuSeconds 6.079514 and maxRssKb 339356. Those timing fields are reported as retained measurements; their collection implementation is not in this delta. Local Node24.22.1 is the supplied environment declaration, distinct from native CI24.19.0.

Read and parsed only the supplied raw files and necessary pinned source/history: article-media.cjs, articles.cjs, rights.cjs, web-media.py, relevant publishing article/profile source functions discovered through profiler call stacks, and the already allowed test/fixture owners. Git status/ref and source/hash checks were read-only. No new test, campaign or profiler execution occurred. No peer output, parent interpretation, historical narrative reports or memory was read. No unexpected context exposure occurred. Only this assigned artifact was written.

## How the sampled values were derived

The JSON contains 2636 nodes and 27282 samples. Its start/end span is 30.166589 seconds; the sum of timeDeltas is 30.166436 seconds. For each `(sampleNodeId, timeDelta)` pair, assign the delta once as that node's self weight. Reconstruct parents from `children`. Inclusive weight for a function occurrence sums weights for that occurrence and all descendants. For subprocess categories, take samples whose own frame is `spawnSync`, then walk upward to the nearest repository frame; this avoids double-counting inclusive ancestors.

| Nearest repository caller of sampled spawnSync | Sampled elapsed seconds | Share of all profile deltas |
| --- | ---: | ---: |
| article-media.cjs encode:10 | 15.742401 | 52.185% |
| publishing/article.cjs compile:341 | 9.056888 | 30.023% |
| publishing/history.cjs gitResult:12 | 1.144405 | 3.794% |
| publishing/provenance.cjs git:11 | 0.284288 | 0.942% |
| delivery.cjs rightsInventory:140 | 0.008791 | 0.029% |

The history/provenance entries are labels from observed call stacks; they do not distinguish Git I/O, CPU or waiting. These categories total the 26.236773 seconds of subprocess samples; they do not include parent serialization, parsing or other JavaScript work.

Important inclusive call-stack occurrences:

| Occurrence | Sampled elapsed seconds | Share |
| --- | ---: | ---: |
| rights.compile under the loop's assert.throws callback at test:845 | 27.069445 | 89.734% |
| hostedInventory under that callback | 25.319574 | 83.933% |
| article-media.encode under that callback, including its own JS/descendants | 14.952598 | 49.567% |
| fixture rights.compile during delivery.staging | 1.690713 | 5.605% |
| fixture hostedInventory | 1.537385 | 5.096% |
| fixture article-media.encode | 0.901970 | 2.990% |

Inclusive rows overlap and must not be added together. CPU profiles merge repeated calls with the same stack: node/sample counts do not independently supply invocation counts. The 16-loop count is established by source and the completed one-test result, not by pretending each profile node is one subprocess launch.

## Source mechanism and obligations

`tests/release-rights.test.cjs:797–849` first prepares one real staged Color fixture. Its 16 wrapper mutations then conceal otherwise exact legal copies using comments, templates, scripts, styles, hidden/inert containers and malformed nesting. Each iteration modifies actual Credits alias/snapshot bytes, coherently updates the revision/hash/record/report, confirms metadata-only publication checks still accept, and demands both source rights compilation and frozen-byte verification reject. All 16 remain meaningful refusal obligations.

`rights.compile` first verifies actual artifact bytes and snapshot closure (`rights.cjs:393`), validates source identity and manifest, then invokes `hostedInventory` at `:398`. Only later, while constructing the report at `:472`, does it call `publicNotices`. That function (`:363–387`) reads actual Credits documents, strips nonvisible contexts through `frozen.noticeHTML`, checks required authored paragraphs/legal links and demands the exact full legal HTML. It is sufficient to reject these deliberately invisible copies, but currently runs after article work.

`hostedInventory` at `:223` always invokes `articles.select` for hosted descriptors. `articles.cjs:46–54` loads and compiles selected articles, passes them through article-media.render and then materials selection. `article-media.cjs:85–114` unconditionally calls `encode` for a nonempty webp-lossless article; there is no rendition memoization. It rereads manuscript bytes after encoding and recompiles the article with rendition asset URLs.

`article-media.encode` at `:10–34` serializes all image bytes to base64 JSON and starts Python web-media.py synchronously with the existing 60-second and buffer bounds. The Python implementation verifies the actual Pillow pin, WebP codec version, request fields, dimensions, pixel/byte budgets, input hashes, PNG format/frame/orientation/color metadata, and any equivalent JPEG identity. It either losslessly encodes WebP or selects the exact equivalent JPEG, then decodes output and compares full RGBA pixels and ICC profile (`web-media.py:29–141`). The profile does not establish how much of the child time belongs to encoding, pixel equality, decoding, startup or serialization. It establishes the encompassing child path.

The other principal child path is `publishing/article.cjs:341–383`, which checks installed dependency versions and synchronously launches Node `ast.mjs` with a complete markdown/asset request. The sampled rejection-loop paths include initial source compilation under loadArticle (2.989868 seconds of internal spawn samples), recompilation after media rendition (3.116059 seconds), and launch-destination compilation under loadProfile/validateLaunchDestinations (2.438610 seconds). These are distinct input/semantic responsibilities; their outputs cannot simply be substituted for one another. The parent source at `profile.cjs:127–139` deliberately uses parsed link destinations, not string presence, to check site-first launch links.

The public-artifact gzip cache remains irrelevant to media encoding and AST subprocess reuse. It can reduce gzip-size calculations while these additional processes still run.

## Historical introduction of the observed path

All anchors below are exact Git history/source observations; dates identify code introduction, not first native timing failure.

| Commit | Timestamp | Source change linked to this mechanism |
| --- | --- | --- |
| 49223225b195c413e7c3d210e7964a5ae349e296 | 2026-10-12 16:47 +02 | Publishing article pipeline introduces synchronous AST compilation. The current spawnSync and toolchain version-check lines blame here. |
| 1f79142760d5b114f35ef30e92601369c21172b6 | 2026-10-15 14:53 +02 | Original license-wrapper test already contains all 16 mutations and both rights.compile/frozen.verify refusals. Source rights publicNotices validation is already present. |
| 9dc0d4257559c9a954b1114ec787d6b1a18a44c6 | 2026-10-19 08:08 +02 | hostedInventory enters reader.select for current hosted source selection. |
| f9b98f792763a6aaa3d21a0bcedd0faddff6228d | 2026-10-19 10:11 +02 | Adds article-media adapter and Python web-media.py; selected articles now pass through encode/recompile. Initial WebP method is 6; exact pixel/ICC verification is present from introduction. |
| e24168ea5b9fb854d190560cbe8d9a22cbb66dec | 2026-10-20 17:51 +02 | Changes lossless WebP method 6 to 4; does not introduce a cache or eliminate repeated rendition. |
| fc205b17774ba703c63fdd7d142ddac178afffdd | 2026-11-06 09:36 +01 | Introduces validateLaunchDestinations and its additional parsed-AST compiler call. It is visible in this profile but cannot explain the independently recorded 5 November timeout. |

The entire profile-relevant source set above is unchanged over 186f28c0→e50c63de. Thus the local profile explains existing workload composition on e50, not an executable regression introduced in that comparison interval.

## Bounded optimization targets, not implemented fixes

1. **Prioritize exact notice rejection before expensive hosted rendition.** After actual artifact/identity/manifest admission, invoke the existing publicNotices validation before hostedInventory, and reuse only its resulting list in the final report. Its inputs are actual source-root legal/Credits owners plus current public bytes and record. Every valid path must still perform hosted selection, lossless media checks, source provenance, rights coverage and complete artifact verification. All 16 wrappers must continue to fail both source and frozen verification; visible exact copies must still exercise successful full validation. The profile directly supports this target because 83.9% of sample elapsed time is under hostedInventory inside known notice-refusal iterations. This percentage is an attribution on one local case, not a guaranteed saving for CI or the whole rights suite.

2. **For valid repeated source work, investigate bounded content-addressed rendition reuse.** Reuse only a successful, fully verified deterministic rendition when all ordered input bytes/hashes/dimensions, equivalent JPEG inputs, encoder implementation/parameters, selected toolchain/Pillow/WebP identities and relevant policy limits are identical. Continue actual file reads/hashes and current output/rights/closure verification. Bound retained memory, protect cached Buffers/objects against test mutations, invalidate on input or producer changes and never cache failures. Path names, metadata-declared digests, article ID or sourceCommit alone are insufficient keys. A retained externally supplied image cannot become trusted solely because its metadata resembles a previous result. An explicit request-scoped prepared context could reduce invalidation complexity, but a context that ends at each rights.compile would not by itself remove cross-iteration repetition.

3. **Investigate identical AST request reuse separately.** Initial article compilation, rendition recompilation and launch-link compilation have different requests and must retain their distinct semantics. A bounded reuse layer could key exact serialized markdown/title/preserveTables/assets plus compiler/toolchain identity, while keeping fresh source/provenance/profile checks. Preserve the AST parser and actual parsed-link oracle. Do not replace site-first link validation with substrings or remove the second rendition compile merely to make the test faster.

If changes are later authorized, the smallest confirming experiment is this same existing named case plus the directly affected positive/refusal/media invalidation cases, instrumenting encoder/AST call counts and verifying byte-identical valid output and unchanged invalid-input rejection. That is a proposed check allocation, not a run performed here. Before claiming a suite fix, preserve native exact-source evidence on the slower observed runner family and complete the unchanged selected coverage and budgets through the owning workflow.

## Evidence limits and disposition

The profile supports targeted validation-order and deterministic-work reuse hypotheses. It does not justify increasing deadlines, dropping wrappers, skipping pixel/ICC/media/provenance checks, trusting frozen metadata as source proof, or claiming new native success. A CPU-model causal estimate still needs a same-source cross-machine comparison; child-internal optimization still needs child profiling or bounded per-operation observation. No historical raw evidence beyond the six already inspected CI runs was supplied in this continuation; the referenced October narrative was intentionally not read.

Current investigation acceptance is limited to a source-bound mechanism and proposed bounded targets. Implementation, tests, benchmark improvements and release acceptance remain unobserved.
