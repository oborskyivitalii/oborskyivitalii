# Requirements & Acceptance — first independent result

## Verdict and scope

**Bounded investigation evidence is useful; root-cause, first-ever onset and whole-issue acceptance remain unestablished.** The supplied native records establish a source-test process deadline failure, with substantial earlier work still progressing, rather than a demonstrated assertion failure or a demonstrated hosting/browser timeout. They support a last-observed-pass/first-supplied-failure bracket between two source identities on 6 November. They do not distinguish source-dependent cost from environment/resource effects sufficiently to assign a root cause.

This is an investigation-only requirements review. No implementation, policy change, test run, staging retry, campaign, external write, merge or deployment was performed or accepted. No new acceptance criteria are asserted as agreed owner requirements.

### Execution identity and isolation limits

- Role: distinct nonauthor Requirements & Acceptance; first phase.
- Actual returned task identity available to this execution: `/root/timing_requirements`. No separate opaque agent ID or provider turn ID is available to me.
- Received launch instruction: independently inspect the named packet and permitted authoritative sources/native evidence; no delegation. The actual parent spawn arguments/tool receipt are not visible inside this execution, so requested/accepted `fork_turns`, model and effort must be recorded by the orchestrator from its real receipt. I do not attest those fields from a role name.
- Visible context contained the assignment and shared platform/project instructions. I did not receive or read parent diagnostic notes, peer outputs, private conversations or MEMORY contents. A Git diff statistic listed MEMORY and historical review paths; their bodies were not opened. Git commit messages were inspected as source-history metadata, not trusted diagnostic conclusions.
- Provider model/context/memory internals beyond the requested none-fork mechanism are unknown. No unexpected narrative/history exposure was observed in the material I opened; this observation is not a provider isolation attestation. If the orchestrator cannot establish the required actual launch parameter, independent preparation may stand but review acceptance remains blocked under the common contract.

## Inspected identities and actions

Repository: `/workspace/scratch/20e98a342431/author-site`, locally clean at inspection and at the final status check. Local branch `work/issue-169-sdlc-out-of-balance-plan`; HEAD `e50c63de071de6837cf9b6405569bb9a68afd5da`, tree `1c9d8054afdb0e13377c6ccbcd14b92860653d99`. Packet base: `8cf15883125892710633b17133d9ee0fc4b23b92`. I read local refs/history; I did not fetch or observe live GitHub refs, issue text, PR state or run metadata.

Packet `/workspace/scratch/20e98a342431/timing-investigation/packet.json` SHA-256: `fca1c5dacd743fd251528077caeba3f2d71e0ae137921cf09d6c5a9ae9e99ea2`. All 24 declared file SHA-256 values matched the working bytes when verified. Hash verification is not a claim that every declared source was read in full.

Required common contract: `agents/reviewers/README.md`, SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt: `agents/reviewers/requirements-acceptance.md`, SHA-256 `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`.

Substantive inspection: README; root AGENTS; CONTRIBUTING intake/failure-diagnosis/independent-review sections; `.github/ACCEPTANCE.md`; issue-169 local policy; relevant staging/check-profile/release-gate passages; source runner and worker execution/accounting; delivery fixture source preparation and rights construction; shared public-artifact inventory/gzip logic; relevant workflow timeout/source-test references; selected release-test call sites; exact `186f28c0`→`e50c63de` change inventory and scanner-source diff. Git history of runner/tests/check-profile owners was inspected. No repository changes or tests were made.

I parsed the three allowed native source-test JSON/TAP/stderr sets with bounded Python; counted timing events and accounting; compared those exact three extracted files in each directory to its `original.zip` member bytes (all nine matched, each member unique). Archive byte identity was checked locally; download provenance/authentication and live run metadata were not supplied/observed.

| Native evidence directory | `original.zip` SHA-256 | Source-test JSON SHA-256 |
| --- | --- | --- |
| `stage-42227207673` | `9f43457d1f8594f008a1b48b402bdad80a484b2b1cbc916d575407463d8e4be4` | `0395e7dbc91370ca6b66094f9e2c35ffc033e1b7b135774678999845453db60d` |
| `stage-42233889474` | `a494e8d0e5bd5174edb3032320d45d2003083d11e302a82329787150449ae223` | `fc46368cd131b7dc2f84d8bcdc2073cf7152ad65b24f381413353fd1d43c7bae` |
| `stage-42237763419` | `8a0f6f4938ff3d40ad4c57498a4a94324c59db08728f9a00bc1d1832f5fb3dca` | `d3b4910c2077bdd3851b76364e8e666326fcd739f16349c757b0cfb62971b2a9` |

## Observable evidence and its claim boundary

| Observation | Actual result/source | What it can establish |
| --- | --- | --- |
| Earlier supplied native source-test result | Run-labelled directory `42227207673`: clean `186f28c0ad8f94b21c350d50608d337f64c66708`, tree `8b09d57484b1102e2b3f9affc020b9a3d12cc297`; 75 modules; terminal TAP 1,202 tests/pass, zero fail/cancelled/skipped/todo; duration 201,586.167498 ms; all 75 file wrappers completed. | This source-test invocation completed under 300 seconds. It is not a successful whole staging result: its `prepublication.json` says `pass:false`, and security is failed. |
| Both later supplied invocations | Clean candidate `e50c63de…`, tree `1c9d8054…`; 75 modules; native execution error `spawnSync /opt/hostedtoolcache/node/24.19.0/x64/bin/node ETIMEDOUT`; configured `timeoutMs:300000`, status 1. | The selected source-test child exceeded its configured process deadline. No evidence here says the site's hosted requests timed out. |
| Later native accounting | Both TAP streams stop after `ok 608`, no terminal test accounting; JSON observed accounting arrays are empty. Both have 60 file dequeue and 56 completion events. | Progress and incomplete execution, never pass. No emitted `not ok` in these partial streams does not establish that all selected tests would pass. |
| Later incomplete wrappers | Both have dequeue without completion for delivery-observation, prepublication-reuse, publishing-profile and quality suites; 15 of 75 modules have no dequeue event. | Work remained at cutoff. Neither an incomplete wrapper nor the last printed test is thereby the causal bottleneck. |
| Comparable reported capacity | All three timing streams say Node `v24.19.0`, available/configured parallelism 4, concurrency 4, 75 files. | Same reported scheduling dimensions; not equivalent physical runner speed, CPU quota, throttling, I/O, memory pressure or competing process load. |
| Slow completed wrappers | Rights: 128,687.713621 ms earlier vs 205,686.076838 / 204,605.63672 ms later. Controller: 85,975.806267 ms earlier vs 132,224.340153 / 131,106.158926 ms later. All wrappers report passed. | A substantial and repeatable wall-time increase exists in multiple completed suites. It supports investigating broad execution/fixture/environment cost; it does not isolate the responsible function or resource. |
| Source change bracket | `186f28c0`→`e50c63de` changes 16 paths, including security scanner/quality-source test changes, reviewed ledger and repository/review inventory changes. Runner, worker, delivery fixture, release-rights/controller tests, public-artifact helper and this workflow are unchanged across those commits. | A direct code change in those unchanged expensive-suite owners cannot explain this bracket. Changed data/other dependencies and environment effects remain possible. Unchanged code is not unchanged execution cost. |
| Archive-member dates | Source-test members in the three ZIPs carry 2026-11-06 13:44:22, 14:33:14, 14:59:36 respectively. | Archive metadata ordering only. These are not independently authenticated run start/end times or an exact failure-onset timestamp. |

## Findings and treatments

### RQ-1 — High: cause must remain layered, rather than collapsing deadline mechanism into root cause

Evidence: failed native JSON `execution.error.code:ETIMEDOUT`; `tools/quality/source-tests.cjs` fixes 300,000 ms and 16 MiB; worker selects up to four isolated file processes; raw outputs are roughly 154 KB, far below the output bound. Multiple long wrappers finish successfully, then later work remains. Failure diagnosis is governed by CONTRIBUTING, “Diagnose failures before changing or rerunning,” steps 1–5.

Failure mechanism relevant to the user: the process deadline terminates an unfinished selected run. That explains how this attempt failed, not why its workload now costs more wall time. A definitive claim such as “security fix caused the timeout,” “runner was slow,” “deadlock,” or “last suite hung” exceeds these observations.

Treatment: report the confirmed deadline mechanism separately from supported workload observations and open causes. For each causal hypothesis state a discriminating observation, expected contrary result and bounded stopping condition before proposing execution or a fix. No budget increase, reduced selection or waiver is justified by this review.

### RQ-2 — High: first-ever onset cannot be accepted from the supplied chronology

Evidence: only three native run directories were supplied; one earlier source-test pass and two later candidate failures. The canonical check-profile owner records a 1 November topology amendment and an earlier 81-module timeout, while the worker has a dated scheduling-change history. Those prose/history records are not original run evidence for this first-onset question.

Implication: a statement “timeouts began on 6 November/e50c63de” would conflate this observed recurrence/source bracket with first appearance. The allowed records establish the earlier source passed this particular invocation and the candidate failed these two supplied invocations. Commit author dates and ZIP timestamps do not complete the CI chronology.

Treatment: phrase onset as “earliest failure in the supplied native evidence” and retain the earlier historical-timeout indication as a separate, unverified historical claim. To establish first appearance, obtain dated native earlier run/source/attempt records, including the preceding comparable pass and relevant protected-main/source workflow identity. Do not reconstruct first onset from a narrative report alone.

### RQ-3 — Medium: actual owner intent and live external acceptance are unavailable

Evidence: packet names issue 169 / PR 170 and supplies a local policy, but no live or explicitly dated full issue/AC body, PR/run metadata or policy-owner reconciliation. The local policy calls AC05 source-bound review/hygiene and maps INDEPENDENT/DELIVERY; DELIVERY explicitly requires exact-source native and hosted evidence. The same policy says RI/style checks prove inventory/freshness/routing only. `.github/ACCEPTANCE.md` makes the linked issue authoritative.

Implication: this investigation can inform AC05/DELIVERY, but cannot independently certify whole current AC wording, checkboxes, four-role execution, current readiness or any release gate. The packet's investigation-only instruction is sufficient for these read-only actions and the assigned artifact; missing live issue text does not require inventing investigation ACs.

Treatment: retain owner/PR binding and this limited intent. Before any dependent acceptance change, compare against actual owner text and exact source/run state. Keep failed/incomplete native results failed; no automatic/human policy gate is marked passed by this review.

### RQ-4 — Medium: documented scheduling terminology disagrees with current execution

Evidence: `guides/SITE-CHECK-PROFILES.md` near lines 48–52 says selected Space and executive suites start first. Current `tools/quality/source-test-worker.cjs` priority begins release-rights, release-controller, pages-delivery and pages-migration; every supplied timing stream confirms those first dequeues. The guide later describes eight-job PR/staging source sharding, while these prepublication native records show one 75-file worker invocation. This review has not established that sharding is required for every prepublication context.

Implication: a requirements/reporting narrative that assumes the documented first suites or equates PR matrix capacity to this prepublication worker would use the wrong execution model. It could mistake an intentional route difference for a missing implementation.

Treatment: state the actually observed worker topology and distinguish Basic/PR sharding from this selected source-test invocation. If future changes are considered, first confirm the authoritative coverage/deadline obligation for each route. Documentation correction is outside this assignment and is not implemented here.

## Intent → acceptance/check → observed result

The first three rows are the user's investigation questions, not newly accepted issue ACs.

| Intent / existing policy link | Required evidence or decision | This review's outcome |
| --- | --- | --- |
| Investigate why staging times out | Preserve failing command, source, limits, native error, partial accounting; distinguish mechanism from cause. | Deadline mechanism confirmed for these source-test invocations; root cause unresolved. |
| Identify when it appeared | Comparable chronological native runs, source identities, actual run/attempt dates; separate historical first occurrence from recurrence. | One observed earlier pass / two candidate failures established; first-ever occurrence and exact failure-onset time unestablished. |
| Identify possible relationships | Exact diff/dependency scope plus observations that distinguish source/data effects from resources/environment. | Unchanged expensive suite/runner owners and repeatable slowdown established; changed indirect data and environment remain candidates. |
| AC05 / INDEPENDENT | Four distinct completed source-bound clean-context role executions and correction disposition. | This is one role's first bounded result only. Other roles and actual parent launch receipts are not inspected or accepted. |
| AC05 / DELIVERY | Exact-source native/hosted checks, staging and required later release observations. | Candidate source tests failed/incomplete; no hosted or release completion claim can follow. |
| General failure-diagnosis protocol | No unchanged failed campaign rerun; next smallest useful diagnostic specified before execution. | Retained evidence was reused only; no run or repair authorized or performed. |

## Missing discriminating observations and next gate

1. **Source/data cost versus host speed:** retained per-suite timings for the same expensive suites on the two source identities with full host metadata, or an already retained controlled comparison. Equal Node/concurrency fields do not control CPU model/quota, process competition or filesystem performance. New execution needs a separately bounded, reviewed diagnostic plan; this is not authorization to run it.
2. **Where expensive wrappers spend time:** retained function/subprocess timing or OS resource observations separating fixture copies/rights compilation/gzip, Git work, filesystem and CPU time. The delivery fixture repeatedly reads/hashes public bytes, makes copies, verifies snapshots and constructs rights sources; the public-artifact helper reads/hashes every manifest input and caches only gzip sizes. These are plausible cost surfaces, not measured causes in the supplied records.
3. **Current source-change linkage:** per-file completion duration distribution and dependency/input comparison for changed tests/scanner/ledger/inventory versus unchanged slow suites. File-level completion durations show correlation only; a causal attribution needs a changed dependency path and measured or otherwise discriminating effect.
4. **Native provenance/chronology:** authenticated run metadata with attempt, event, executed workflow/protected source, runner image details, start/end times and artifact binding; bounded earlier native timeout records and last comparable pass. ZIP identity and local source reports do not replace those external observations.
5. **Acceptance gate:** preserve this first result before reconciliation; parent must attach actual none-fork launch evidence and resolve missing owner/source facts before using it for dependent acceptance. Unknown provider internals remain unknown. No action here changes the owner's scope or grants implementation, retry, merge or production authority.

All observations above are limited to read-only source/history/native-artifact inspection. First result preserved in this assigned file; no peer verdicts were read.
