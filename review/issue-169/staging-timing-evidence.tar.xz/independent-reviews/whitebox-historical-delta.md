# White-box QA historical and local-profile delta

Role/task `/root/timing_whitebox`, continuation of its own first review, owner #169 / PR #170. The initial report is preserved separately. This continuation received only additional raw evidence locations and the operator-supplied local Node version, with no author/peer verdict. It inspected `octfail`, `octpass`, and `cpu/license-wrappers.cpuprofile`, `cpu/time.json`, `cpu/test.tap`, `cpu/test.stderr`, `cpu/setup-failure.stderr`. No narrative reports, peer outputs, MEMORY, campaigns, source changes, delegation or external writes. Only this assigned artifact was created. Original packet-v1 SHA-256 remains `fca1c5dacd743fd251528077caeba3f2d71e0ae137921cf09d6c5a9ae9e99ea2`; this is a factual evidence delta, not a newly clean execution. Common/role prompt identities remain `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` and `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.

## Result

The 25 October pair is a materially stronger environment discriminator than comparisons across November commits: **the same clean commit/tree, selected modules, command arguments and generated artifact time out on attempt 1 and pass on attempt 2, while the reported CPU model changes from EPYC 7763 to EPYC 9V45**. This establishes that a source edit is not necessary to produce the timeout/pass transition in this retained pair. It supports runner-dependent throughput as a leading cause. The pair is not randomized and does not hold cache state, host load, CPU frequency, throttling or storage constant, so it cannot attribute the whole difference solely to CPU microarchitecture.

This moves the earliest directly observed timeout in the supplied evidence back to **25 October**, in the PR source profile under a historical **180-second** deadline. It does not establish that the exact present 300-second staging failure first occurred then, nor the project's first-ever timeout.

## Controlled source identity and accounting

| Field | Attempt 1 (`octfail`) | Attempt 2 (`octpass`) |
| --- | --- | --- |
| Actions run / attempt from native lint environment | 40215263460 / 1 | 40215263460 / 2 |
| Source and sourceAfter | `808dae28fb65c5d39ceb16bec89cf5ab82e9c958`, clean | identical, clean |
| Source tree | `67040e44a85e2340a4c770061c55cbf1bf3e072b` | identical |
| Profile / selected modules | pr / 79 | pr / same 79 |
| Node / reported file workers | v24.19.0 / 4 | v24.19.0 / 4 |
| Runner image / imageVersion | ubuntu24 / 20261023.334.3 | identical |
| Kernel / architecture / memory | 6.17.0-1022-azure / x64 / 16766414848 bytes | identical |
| CPU model (four reported entries) | AMD EPYC 7763 64-Core Processor | AMD EPYC 9V45 96-Core Processor |
| Child limit / output bound | 180000 ms / 16777216 bytes | identical |
| Child result | status 1, null signal, ETIMEDOUT | status 0, null signal, no error |
| Modules dequeued / complete | 65 / 61 | 79 / 79 |
| Final native accounting | absent for tests/pass/fail/cancel/skip/todo | 1156 tests, 1156 pass, all other counters zero |
| Top-level / nested rendered cases | 582 / 0 | 1139 / 17 |
| Runner elapsed / native TAP duration | no completed result | 142059 ms / 142025.488962 ms |

Both native lint records bind the same base artifact digest `b12e4ad141e3a1c2e1e215cec5a5f8469d74fa7b1daeb581c37ff87967ccf206`, variant base contract 1, fingerprint `48153b94fbae4f314eaa11b156df8a20227dec429abfee9e45c14fda4a1f1b2a`. Both lint checks themselves pass. Module lists and complete argv arrays compare exactly equal. Compact JSON SHA-256 identities are `5f491bbe2d7643d29fb7a361f192daf6aedddf0dae6efdcbeaa88a551f0a6628` for the module list and `da8258351ba84f490f807991c51cb04859633d56c047380283aafb7845ddcf2c` for argv (Python JSON separators `(',', ':')`, default ASCII encoding).

Every completed module reports wrapperPassed true. Neither retained TAP has a top-level `not ok`. Attempt 1's four active modules at 180 seconds are delivery-observation (17.985 s active), quality (5.154 s), reader-mode (2.588 s) and release-archive (0.677 s). Fourteen modules never dequeue. Its output is 147051 bytes stdout and 16889 stderr, far below the output bound. The 582 rendered passes cannot substitute for missing final accounting; output ordering also means that count is not all work executed.

All four extracted native files (lint.json and source-tests JSON/TAP/stderr) exactly match the corresponding bytes inside each original ZIP. ZIP member labels are 25 October, 17:13:20–17:16:26 and 17:19:38–17:22:02; ZIP timestamps do not carry authoritative workflow timezone/start semantics. Git author date for the shared commit is 2026-10-25T17:57:36+01:00. No current remote state is asserted.

The historical source runner itself declares timeout 180000 and grace 30000. Its source SHA-256 is `ffc97dfd66b1d6b3cdbe2d5712cf1a1789c68e51df1d000b1ef65caffb328b33`; historical worker SHA-256 is `fb99cd3aacc0e98470fcf2a4cc50fd159a54d9705bb422824fc9842c43b63945`. The worker uses four capped process-isolated file workers and the same ordering for both attempts, starting Space/executive/media/rights before later files. Thus the pair is not evidence of a changed timeout or scheduler between attempts. Actual installed publisher/Python dependency versions are not fully reported by these artifacts; identical source pins are narrower than independently observed complete installed toolchains.

## Recomputed timing comparison

Seconds from native complete.wrapperDurationMs:

| Module | 7763 timeout attempt | 9V45 passing attempt | Ratio |
| --- | ---: | ---: | ---: |
| space | 108.489 | 76.489 | 1.418 |
| executive | 77.355 | 55.080 | 1.404 |
| release-rights | 54.490 | 36.543 | 1.491 |
| release-controller | 40.589 | 27.409 | 1.481 |
| publishing | 31.944 | 20.355 | 1.569 |
| article-offline | 26.663 | 18.910 | 1.410 |
| pages-delivery | 25.254 | 17.443 | 1.448 |
| camera-view | 5.288 | 3.034 | 1.743 |

Across all 61 comparable completed modules the median fail/pass ratio is **1.462963x**, range 1.250503–1.743235x; 48/61 exceed 1.4x. Matching 582 shared unique top-level case names, with the passing duration at least 100 ms, yields 336 comparable cases, median ratio **1.467939x**; 235/336 exceed 1.4x. This again shows broad throughput variation rather than one isolated test fault. Simple scaling of the passing 142.059 seconds by 1.463 gives about 207.8 seconds, consistent with a 180-second deadline crossing; this is a rough explanatory estimate, not a completed failing-run duration.

## Separate local profile observation

The supplied local evidence concerns the current `publication comment and inert-template wrappers cannot hide otherwise exact full license copies` case, using `--test --test-isolation=none --test-name-pattern=publication comment and inert-template wrappers` with CPU profiling. It reports exit 0, one test/pass, zero fail/cancel/skip/todo, native case duration 30062.928046 ms and TAP duration 30097.564118 ms. time.json records wall 30.262001769 s, user CPU 30.296535 s, system CPU 6.079514 s and maxRssKb 339356. The initial missing `/usr/bin/time` setup failure is retained separately; it is not a testcase assertion failure. Operator metadata says Node **24.22.1**, whereas historical and latest CI use **24.19.0**. The local JSON/profile does not itself record that version, a source commit/tree or how the CPU resource counters were collected; no exact CI-equivalence claim is warranted. Current checkout inspection remains clean at e50c63de, and profile URLs/line locations agree with its inspected source, but that alone does not prove source cleanliness during the historical local execution.

The V8 profile spans 30.166589 seconds and contains 27282 samples. Summing timeDeltas yields 30.166436 seconds. Aggregated self-sample elapsed weights:

| Frame / first repository caller | Seconds | Share of sampled elapsed weight |
| --- | ---: | ---: |
| spawnSync total | 26.228086 | 86.945% |
| spawnSync ← article-media encode | 15.739170 | 52.174% |
| spawnSync ← publishing/article compile | 9.055793 | 30.019% |
| spawnSync ← publishing/history gitResult | 1.140044 | 3.779% |
| spawnSync ← publishing/provenance git | 0.284288 | 0.942% |
| crypto hash update total | 0.891693 | 2.956% |
| zlib processChunkSync total | 0.220995 | 0.733% |

These are profiler sample weights, not independent measurements of child CPU consumption. In particular a synchronous native spawn frame can cover waiting while a child runs; the parent profile does not identify CPU versus disk wait inside Python/AST/Git. CPU counters totaling more than wall time cannot be treated as single-thread parent utilization without their collection semantics.

Source interpretation is nevertheless concrete: the wrapper-negative case loops over 16 markup transformations and calls rights.compile at release-rights.test.cjs:845. rights.compile calls hostedInventory before roomInventory; hostedInventory selects/reconstructs the article. That path invokes article-media encode (Python web-media.py), publisher compile (Node ast.mjs), and Git provenance/history checks repeatedly before reaching the intended malformed-notice refusal. The largest individual sample stack is 14.843706 seconds in encode→render→reader.select→hostedInventory→rights.compile→the negative assertion. Gzip is a small direct sample contributor in this local case. This is useful attribution for a future bounded optimization study; it is not evidence that publisher work can be removed without preserving source/rights invariants, or that it alone causes CI hardware sensitivity.

## Discriminating next checks and limits

The October same-source pair now supplies a natural comparison without a new campaign. The next unresolved question is how much of current e50's cost comes from child computation versus filesystem/host contention. If separately authorized, instrument one existing wrapper-negative case's child durations/user/system time, capture CPU model/quotas/throttling and compare the unchanged scenario across the two runner classes. Preserve the refusal oracle, exact source and original budgets; do not repeat the full staging campaign as a diagnostic. A targeted experiment could also test whether repeated unchanged article preparation can safely reuse source-bound work, but cache invalidation, actual-byte verification and the existing tamper/refusal cases must remain explicit acceptance conditions. No such experiment or implementation ran here.

Historical PR source failure is observed by 25 October; current 300-second staging onset and the first-ever failure remain unproved. The raw pair strongly rules out source edit as a necessary trigger for its own transition, but does not prove CPU model is the only environmental variable. Local single-case profiling neither establishes CI performance nor full-source or delivery acceptance. AC04/05 DELIVERY remain blocked by the latest incomplete source campaigns.

## Additional raw identities

| Evidence | SHA-256 |
| --- | --- |
| octfail/original.zip | `928c6db039000f7a651879c45c3abf8acae9344aac32660b28368ecaf8bdc357` |
| octfail/lint.json | `e9b53feb228c9a2e8aff4d9c416d559d14981c53c22f46518b8ffc4f8fb84192` |
| octfail/source-tests.json | `3477ad0c1cd6612b7f466864bc271444e742748125816360d3d245117a90aa34` |
| octfail/source-tests.stderr | `9225d4cc119ba8b3e087071708c06b74afa531221f3960330d2175d82aef0227` |
| octfail/source-tests.tap | `d2e3d8370ae072f260ed976e7bdbccc2a4ce9e7d262189b431738cd5f7413d24` |
| octpass/original.zip | `56e1fa0608b648f8109a9155d1536be7d0f338cb43576174f6649626de80af48` |
| octpass/lint.json | `914f2e929f9567388d57ac04dd143175270f9c79ad3288fa92f945b45c7352ea` |
| octpass/source-tests.json | `cc5374f00971ada556a520197bbed174a35ca9ee16f1a3e1a6aedc639335308b` |
| octpass/source-tests.stderr | `6a02d38ac1ae694ad57aabdc9cf1cb94d55045ad7fedf39f7e76c9865c08779e` |
| octpass/source-tests.tap | `c45f331f2ccea7440d05c70086a4f94c03c8468959464cb0710ce366d9150254` |
| cpu/license-wrappers.cpuprofile | `1fec5f0d5112aa1f401cb063c80decbbbb2509a32b03790280e6ccefedf95858` |
| cpu/time.json | `e76731ae1c52a713998f59f407dd4c3b84b84c855a193cec38ea27db03bd20c7` |
| cpu/test.tap | `8473f78d6510e1021168de8237ad5c7281dcb9503c0a6f6e6f925df1df7bd84c` |
| cpu/setup-failure.stderr | `2be8de153270bcc10eaa1bc2f817c103486437ac1f50d4ae5d4458064f6525f3` |
