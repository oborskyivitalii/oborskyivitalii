'use strict';
// Temporary diagnostic observer; never imported by repository sources or CI.
const cp = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const original = cp.spawnSync;
const rows = new Map();
cp.spawnSync = function (command, args, options) {
  const kind = path.basename(String(command)) + ':' +
    (args?.[0] && /\.(?:py|cjs|js)$/.test(args[0]) ? path.basename(args[0]) : String(args?.[0] || ''));
  const start = performance.now();
  let result;
  try {
    result = original.call(this, command, args, options);
    return result;
  } finally {
    const row = rows.get(kind) || { kind, count: 0, wallMs: 0, nonzeroResults: 0 };
    row.count++;
    row.wallMs += performance.now() - start;
    if (result?.status !== 0) row.nonzeroResults++;
    rows.set(kind, row);
  }
};
process.once('exit', () => fs.writeFileSync(
  path.join(__dirname, 'child-count-' + process.pid + '.json'),
  JSON.stringify({ schema: 1, node: process.version, rows: [...rows.values()] }, null, 2) + '\n'
));
