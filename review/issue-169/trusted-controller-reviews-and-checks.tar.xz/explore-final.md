# Exploratory / Interaction QA — first independent result

Date: 2026-11-06. Role/task: `/root/controller_explore_final`. Owner169, publication PR170. This is the first result, before peer reconciliation. No implementation, external write or delegation occurred. Only supplied materials and necessary repository owners were inspected; no parent scratch notes, private history or peer result files were read.

## Verdict

**No blocking defect found in the bounded changed-controller interactions.** Current R10 producer crosses the pinned candidate's complete tested staging/production consumer closure. The changed failure paths reject the exercised malformed resource, incomplete accounting, mixed runtime and archive metadata cases. This is local compatibility evidence, not permission to merge PR170 or publish production, and not hosted/UI/device acceptance.

The prerequisite still needs its applicable current-source/native admission, exact-head owner control review and protected integration route. After that integration, refresh PR170 and perform the authorized full owner staging route, verify the stable alias and actual article/PDF bytes, then STOP/show. Whole AC05/09/10/11 are not closed by this review.

## Identity and inspection boundary

- Repository: `/workspace/scratch/94faff7d674c/controller-fix`.
- Base/local main: `8cf15883125892710633b17133d9ee0fc4b23b92`.
- Candidate: `19e75f66bba1f8e02860f6185a9555f1e154fbe8`; tree `b44bc1cc190503df31b25fcb3a7ba2fc608e98f0`. Local tracked/untracked status empty before and after checks. Live GitHub state was outside this read-only source review; local main is not a claim of a freshly fetched remote ref.
- Producer: `558682775b9798a961f91a86673000a0b13e34d9`; own pinned test reports `producerDirty:false`.
- Packet SHA256: `f8872a687d226b60312b9589797bcb6627a09b0227cdca7d9252b31a453170fe`.
- Manifest SHA256: `5fa4688a2dff0c97c51af653b5415f353bde1eac87b6067158c69d086a807b7b`; **all56 declared paths match**, including absent paths.
- Complete supplied diff SHA256: `8daac270285df1f3f41b5a1c596f55d80bd81ff799e351ed1303f37f699f2c70` (1,102,192 bytes,19,406 lines). All changed-path categories were inspected: substantive consumer/test/fixture/acceptance changes directly; large generated JSON/map/HTML sections through complete diff inventory, parsed semantic comparisons and exact-byte comparisons. Large JSON reformatting was not treated as new behavior.
- Common prompt SHA256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256: `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Read README, root AGENTS (only applicable AGENTS found), MEMORY as candidate handoff, CONTRIBUTING review/failure/acceptance routes, acceptance169, relevant repository map owners, site source contract, staging/release/profile contracts; inspected the four changed consumers, tests/fixtures and relevant snapshot, edition, package, rights and production workflow/action callers.
- Requested no-conversation-inheritance is stated in the packet. Actual launch acceptance must be established by the orchestrator's tool receipt. Provider model/history internals are not observable here; no platform isolation attestation is claimed. No unexpected author/peer conversation exposure was observed.

## Independent charter and actual surface

Charter: within8minutes and individual commands under120seconds, explore the operator's path from an ordinary main artifact and current R10 producer into trusted snapshot/runtime/rights/size/package consumers, then production and frozen-archive verification. Partition inputs by supported route/depth, declared versus absent/duplicate resources, intact versus changed passive SVG bytes, complete versus undercounted transfer, exact versus mixed runtime edition/bytes, and indexed versus corrupt article metadata. Preserve the unchanged budgets and release authority boundary. No full source/browser campaign was requested or executed.

The changed executable surface is CLI/API delivery validation. Candidate authored `site` content/templates/engine/assets are unchanged apart from generated output lock; no article is newly selected in this prerequisite output. Independent comparison found all five principal HTML documents equal to main after replacing only64-character lowercase SHA256 tokens, and all five ordinary runtime JS/CSS files byte-identical. Parsed path catalog has15 additions/10 removals/no changed entries, reflecting the new policy/evidence/fixtures and generated snapshot replacements. Generated agent artifact inventory has9 additions/5 removals/no changed entries. RI/CI's only substantive layer change adds acceptance169 to the existing intent-acceptance layer. These observations support absence of a new prerequisite UI behavior, rather than assuming UI is universally inapplicable.

The **publication reader UI is applicable** to the eventual R10 delivery: native and SPA entry, Back/history, deferred image requests/decoding, figure dialogs, fragment/reference navigation, desktop/mobile/no-JS readability, print/PDF and related links remain real affected journeys under the existing owners. They were **not observed** in this review. Hash parity and local consumer success do not establish them, nor TLS/CDN/redirect/MIME/cache/stable-alias behavior. Physical iOS/Android observations are unavailable here, not N/A; the existing release contract keeps those records distinct and does not create a new device matrix or make them a new staging publisher input.

## Executed actions and outcomes

Environment: Linux workspace, pinned `/tmp/issue169-review/node-v24.19.0-linux-x64/bin/node` (Node24.19). Commands ran existing tests; no reviewer-authored accepted tests or source were introduced.

| Action and independent expectation | Observed result | Raw evidence |
| --- | --- | --- |
| Verify packet/manifest/diff identity and clean source, compare ordinary main public meaning/runtime bytes. Expected exact identities and only generated SHA changes. | All56 paths and both supplied digests match; head/tree match; clean source; five HTML semantic comparisons and five runtime byte comparisons pass. | `explore-final-source.json` |
| Invoke three focused changed-interface tests. Writing resource must reconstruct exact geometry at root/snapshot depth and reject wrong routes, empty/duplicate closure, wrong depth/fragment, appended bytes and active/foreign SVG. Sizes must include full resource gzip and reject undercounted/omitted/forged dependencies. | Existing Writing test passes all its branches. | `explore-final-interactions.tap` |
| Same focused command: frozen production archive with native article must pass; deleting sitemap article or inventory, claiming candidate, noindex, wrong canonical or missing social tag must refuse, and restoring bytes must recover. | Existing archive test passes including restoration checks. | `explore-final-interactions.tap` |
| Same focused command: observed footer/history family fixtures must select exact plain/staging/production identities and retain rights requirement; wrong base engine, edition, every canonical/immutable byte and mixed navigation must refuse. | Existing family test passes. Total focused command **3/3**, zero failure/cancel/skip/TODO. | `explore-final-interactions.tap` |
| From actual current R10 producer, invoke its `current generated editions cross the selected controller consumers` with controller root and full SHA pinned. Expected all staging and production snapshot/runtime/rights/sizes/package consumers plus both production verifiers pass without changing public bytes. | **13/13**, zero failure/cancel/skip/TODO;12 named consumer leaves plus parent. Diagnostic confirms exact controller/producer; source labels synthetic, provider not called, productionEligible false. Test checks post-consumer public inventory equality and producer package still valid. | `explore-final-pinned.tap` |

Pinned command:

```sh
SITE_TEST_CONTROLLER_ROOT=/workspace/scratch/94faff7d674c/controller-fix SITE_TEST_CONTROLLER_SHA=19e75f66bba1f8e02860f6185a9555f1e154fbe8 /tmp/issue169-review/node-v24.19.0-linux-x64/bin/node --test --test-name-pattern='current generated editions cross the selected controller consumers' tests/reader-controller.test.cjs
```

It ran in `/workspace/scratch/94faff7d674c/repo`. Focused command ran in the candidate with pattern `Writing resources retain exact geometry|frozen production archives verify native|observed runtime families retain exact` against the three corresponding test modules. Files ending `.tap` contain Node's native test reporter output as actually emitted.

Raw log SHA256: interactions `14e22ad157c2bee6a0ff790fe04c7e390d07f17297139a3a782d67fe006a51c2`; pinned `819787e6dff8cdf16a7e6043e55872013a5f6d69008760d762673e6f6f54e972`.

## Operator route, regression allocation and remaining limits

The packet/review source identifies the trusted prerequisite versus unprivileged PR170 producers without consulting author chat. Production workflow calls main's `tools/release/actions.cjs`; rollback unpacks an authenticated archive then calls the frozen edition verifier. That verifier uses the frozen record/public bytes and its social descriptor rather than today's reviewed runtime table or portrait, while the normal production verifier still uses current policy. `artifact.verify` already invokes snapshot verification, so the additional explicit snapshot result does not introduce a new historical-format prerequisite beyond the existing artifact path. The new article loop closes canonical/robots/social/sitemap admission for current native articles. Local failures do not upload or promote anything.

Existing regression allocation is sufficient for these exercised cases: `site-engine`, `color-motion-contract` and `reader-controller` are permanent registry entries in PR-targeted/staging/production source profiles; added fixture and production archive/edition input paths route to their owners. Basic maps to `.github/workflows/site-checks.yml` checks job; source/hosted staging remains through `.github/workflows/site-color-review.yml` and its existing source/staging jobs. The producer-side pinned test is the cross-controller compatibility regression, not hosted admission. No additional routine suite or duplicate campaign proposed.

AC05: exact local source, resource/budget/package invariants observed; native checks/control attestation/integration remain separately required. AC09/10: article/PDF/resource and reader dependencies cross local consumers, but served PDF/copy/related-reading UI remains unobserved. AC11: this is one completed independent role result; no assertion about peer completion or orchestration acceptance.

Not adjudicated here: live refs/issues/PR status, full Basic/source/RI/style campaign completion, CI provenance of historical runtime fixture claims, actual protected controller integration, authenticated staging, stable alias, production, external platform posting, full browser/performance matrix or physical devices. Existing runtime fixtures identify clean CI plain/staging versus dirty private guarded production derivations explicitly; this reviewer did not re-fetch those historical provider artifacts. Own successful bounded executions do not erase the supplied earlier failed tests or replace any current required campaign. No blocking finding within this charter; the pending gates above must retain their actual states.
