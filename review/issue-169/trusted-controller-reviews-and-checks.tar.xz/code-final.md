# Independent Code / Changed-artifact Review — first judgment

Date: 2026-11-06. Reviewer task: `/root/controller_code_final`.
Owner: issue169; publication execution PR170. Verdict: **REQUEST CHANGES / blocked advancement**.
Two incomplete dependency updates are demonstrated by current exact-source failures. No additional defect found in the four consumer behavioral changes themselves.

## Candidate and inspection identity

- Native clean Git checkout: `/workspace/scratch/94faff7d674c/controller-fix`.
- Base `8cf15883125892710633b17133d9ee0fc4b23b92`.
- Head `19e75f66bba1f8e02860f6185a9555f1e154fbe8`, tree `b44bc1cc190503df31b25fcb3a7ba2fc608e98f0`.
- Actual binary Git diff equals supplied `candidate.diff`; SHA256 `8daac270285df1f3f41b5a1c596f55d80bd81ff799e351ed1303f37f699f2c70`.
- `final-manifest.json` SHA256 `5fa4688a2dff0c97c51af653b5415f353bde1eac87b6067158c69d086a807b7b`; every listed existing/absent path matched, including final readback.
- Packet SHA256 `f8872a687d226b60312b9589797bcb6627a09b0227cdca7d9252b31a453170fe`.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code prompt SHA256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Read root README, AGENTS (only applicable AGENTS found), CONTRIBUTING review/iteration/failure protocol, MEMORY as candidate text, repository-map/RI ownership, acceptance169, CODE-STYLE and relevant release/staging/profile/source contracts. Inspected complete changed consumer/test hunks, fixture identities and supporting snapshot/edition/artifact consumers. Generated RI and output changes were assessed structurally and by exhaustive path/hash/normalized-byte comparisons; large command outputs were sometimes truncated, so these comparisons replace any claim of line-by-line comprehension of generated registries.

## Blocking findings

### F1 — P1: changed fallback producer invalidates the still-active Research carrier binding

Location: changed `tools/site/fallback.cjs:192` / `:266`; dependent owner `review/issue-159/content-amendment.json:480`–482, consumed by `tools/check_site_seo.cjs:216`–235.

The active Research carrier contract still requires fallback SHA256 `66822a96b98fa151762dd72e601299c63b4ff57249a7d7134ee55d8ca03969c9`; candidate fallback bytes are `0060c45f858b1669a1ab830c0de6ab4ba8a69d0f8589502bd4f17f8e545161d9`. The verifier hashes the actual current source and rejects it. This is an actual regression in existing SEO/source checks even though Research output geometry is unchanged.

Raw current clean-head source production TAP has failures at `tests/executive.test.cjs:18`, `tests/executive.test.cjs:412` and `tests/content-rendering.test.cjs:174`; all stop at this same exact binding assertion in `tools/check_site_seo.cjs:232`.

Requirement: AC05 source/repository hygiene and complete consumer closure, AC09/10 delivery checks; CS01/CS04 preserve source ownership and update all affected bindings without weakening exact checks. Treatment: reconcile the current accepted producer binding through its authoritative amendment/verification route, retain historical source evidence and prove Research unchanged; then run affected checks. Do not remove or wildcard the producer assertion.

### F2 — P1: regenerated public identities leave maintained previews stale, breaking security prerequisite proof

Location: changed `docs/index.html` and `docs/site-revision.json` generated route identities; dependent maintained outputs from `tools/build_site_previews.cjs:479`, checked by `tools/quality/generated-checksums.cjs:673`–675.

The candidate regenerated docs/output-lock but omitted their maintained preview/bundle closure. `proveGeneratedChecksums` reconstructs current previews and compares exact bytes. In the raw source-production failure, an existing preview still contains Home route `4b8747ffc22ce0e753070c3a865aade7bf523feff3bda0167b592025e2c4248e` while current generated output requires `5faad090c9328b8b6a6a6c27520191cec171e359aef25c4b399fe45117042aa2`. Its assertion reports `Stale generated checksum preview`.

Observed failing source case: `tests/quality-sources.test.cjs:1981`, assertion at `:2105`. The scanner flow deliberately fails the first engines but expects the later secrets engine to complete; secrets now fails its generated-source prerequisite. This is not evidence of a secret leak and cannot be fixed by weakening scanner expectations.

Requirement: AGENTS step7 requires dependent previews to be regenerated; AC05/09/10 require current-source security/delivery closure; CS01/CS07/CS08. Treatment: regenerate and verify the maintained dependent preview/bundle identities using their ordinary owners, preserving security checks and historical observations; run the affected proof/scanner case before a new full acceptance attempt.

## Behavioral and architecture assessment

- Writing fallback admission retains a finite route allowlist, one declared resource, exact hash/path/fragment, only canonical depths, UTF8/size constraints and the existing passive SVG vocabulary. Cross-route, changed-byte, active SVG and incomplete transfer negatives exist. No budget value changed.
- Route size validation still binds HTML measurements and complete gzip dependency arithmetic to the exact record. Writing is added to the existing Research rule rather than admitting arbitrary routes or resources.
- Color registry additions are explicit complete edition/fingerprint/base-engine/runtime-byte tuples. Existing `select` still checks variant equality, edition, aliases and immutable runtime hashes. Rights-required policy is inherited. New footer/history fixture tests alter every alias/immutable hash and mix families. No wildcard or bypass was introduced. Fixture claimed CI/private derivation provenance was not independently fetched from provider records.
- Frozen archive verification continues exact artifact verification, adds snapshot/article inventory agreement and candidate refusal, and checks both article alias/snapshot canonical, indexability and social metadata plus the complete ordered sitemap. Frozen social image bytes/dimensions come from the archived package, not today's authored portrait. Rights/admission remain separate existing checks.
- No new module import edges are introduced by these four diffs. Artifact verification invokes snapshot after exports are available. The existing Color/block-flight back reference is invoked only inside `validateFlight`; block-flight reads pacing after the Color module has completed its exports. The edition/artifact/retention graph uses explicit callable build/verify paths; the changed archive reads/validates only, and no new module-scope execution or candidate-code privileged checkout was added. This is bounded changed-scope initialization review, not proof of every legacy deferred cycle.
- Test registry changes add fixture and archive/edition dependencies to existing permanent pr-targeted/staging/production suites. RI changes add issue169 policy/fixture/review paths and refreshed identities; intent-acceptance layer adds only issue169 policy. Acceptance maps mechanical checks narrowly and retains human/native gates. MEMORY/current review retain staging-then-STOP, protected integration and pending production. No article/PDF/media selected into this prerequisite.
- Independently recomputed: five principal HTML files and five renamed snapshots differ only in 64hex digest substitutions; five ordinary runtime JS/CSS files remain byte-equal to base. Revision has no articles key. Output-lock changes match producer/document/digest closure. These observations do not cure F1/F2.

## Actual checks and evidence

1. Own exact pinned Node24.19 run: `PATH=/tmp/issue169-review/node-v24.19.0-linux-x64/bin:$PATH timeout 90s node --test tests/color-motion-contract.test.cjs tests/reader-controller.test.cjs tests/site-engine.test.cjs`. Completed **66/66 passed**, 0 failed/cancelled/skipped/TODO, about15.2s. Raw: `code-final-tests.tap`.
2. Own manifest/diff and clean-head verification: `code-final-hashes.log`, final `code-final-readback.log`; no mismatch or worktree changes. Own output/parity/metadata comparisons: `code-final-parity.log`, `code-final-metadata.log`.
3. Read retained `pinned-current-producer.tap`: complete13/13 bounded checks, exact controller19e75f6 and producer5586827, explicit synthetic source labels/providerCalled:false/productionEligible:false. Includes production edition and frozen edition verifiers. This supplies local cross-controller compatibility evidence, not hosted acceptance.
4. Read retained Basic pass, RI29/29, RI-CI22/22, style pass, format changed[], architecture pass with declared deferred-cycle limitations. They do not override the full source failure.
5. During this review `source-production.json` changed from absent/running to completed failed at the exact same clean head/tree: **1195 tests,1191 passed,4 failed**, 0 cancelled/skipped/TODO; worker exit1, signal null, Node24.19. Own retained readback: `code-final-source-failure.log`; original detailed assertions in `source-production.tap`. No repeat full campaign was run. F1/F2 derive from actual final failure accounting and source, not a peer verdict.
6. Read neutral `native-package-verification.json`: records controller19e75f6/nativeRun42275940284/result:true/providerCalled:false. Its small receipt alone is not independent provider/package authentication; no live admission inferred.

## Limits and independent execution receipt

This is my complete first judgment. No current peer review outputs, private history, parent scratch notes, implementation changes, external writes or delegation were used. The orchestrator supplied neutral executable/evidence paths during execution. Candidate MEMORY/report claims were treated as review subjects.

The task packet states none-fork requested, but I cannot observe the spawn call's accepted parameters or provider context/model internals from this child. No author conversation or current peer verdict was observed in my supplied context. The orchestrator must attach actual launch/acceptance receipts; unknown provider history/model injection is not claimed clean or attested. The managed environment status tool was not available in the tool registry, so no runtime credential/readiness claim is made.

No GitHub live ref/protection/approval/staging/deployment state was fetched. Current clean local refs are observed; remote refs and cited provider fixture provenance are unobserved. No hosted/browser/device/PDF/live served surface or whole source campaign was independently executed. This review supplies neither release authorization nor whole-issue acceptance. F1/F2 and failed current-source evidence prevent advancement until corrected and re-reviewed on the changed candidate.
