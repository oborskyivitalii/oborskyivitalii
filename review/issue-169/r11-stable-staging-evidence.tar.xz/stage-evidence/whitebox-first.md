# White-box QA — first independent judgment

Verdict: **no implementation blocker found in the inspected accepted-state restoration**. Suitable to continue the normal current-source Ready/full-stage route once its separate gates pass. **This report does not establish Ready, full security, native staging or stable delivery success.**

Owner: issue169 / PR170. Candidate `a194bbf2d691ef2f07f915fb4ea6cf4ac39548f7`, tree `75cbf0229d747748034ef7f6d84709ac463ec7a7`; comparison preview `56f4bf90a0b77d180c2e662501c2c87092c08319`. Local HEAD/tree and clean working tree observed before/after checks. No implementation/external writes/delegation. The requested fresh execution is explicit none-fork; provider model/context internals remain unknown. I did not read current peer outputs, parent notes, personal context, stable-review-results contents or evidence archives. Candidate assertions were review subjects. Existing policy rationale mentions a Code review; that mention was not used as its verdict or authority.

## Inputs and authority

Read root README/AGENTS/CONTRIBUTING, common reviewer contract and white-box prompt, relevant map/allocation/acceptance material, actual candidate owners/diff, material and scanner guard implementations, existing tests, separate raw checksum/history/Bandit evidence. No nested AGENTS found in the affected inventory. Live GitHub issue169 is open; its original intent/ACs were fetched. Primary comment6705211415 was independently fetched through its exact API URL: exact displayed56f4 R11 reader/PDF acceptance, accepted catalog/material restoration, current-source Ready and existing full stable-stage route, preservation and STOP/no PR170 merge/production/posting are explicit. Other live PR/check/ref state was not independently refreshed in this bounded reviewer execution.

SHA256 identities:

- packet `d6cef0e27b7a6947a8da7a7d8abbebd584583f433c23aa3c9546627a40e3aeec`
- common contract `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`
- role prompt `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`
- source manifest `1393553d84b2ff293733fb456ddab84de116ef19e58ae701572afce5cf118786`
- supplied diff `79c61c749331ef9bd83cbd1d4a7b056a738544552545d0c2341313b8018b8c27`

The manifest and diff digests matched; every manifest file byte count/SHA256 matched the inspected checkout.

## Risk → structural fault → scenario → oracle → evidence

| Risk / AC | Structural fault/scenario | Independent oracle | Executed/inspected result |
| --- | --- | --- | --- |
| AC04/07/08 accepted native discovery | Accepted catalog row absent/wrong ordering/status, stale preview-only selection | Accepted primary decision; exact prior catalog; accepted-only selector | Entire catalog equals9fe9 catalog; publication30 first and2026/delivery/Article/Author site. Status accepted, explicit candidate removed only for this article; pmday remains. Native selector returns candidate=false. |
| AC09 PDF admission | Approval forged/stale source/file/label/evidence; private/unapproved leaks | Exact decision + source/file/evidence digests + fail-closed existing guard | Native load validates semantic and review binding/evidence; one869961-byte PDF optional download with content-addressed hash568c87ea…914d58; no embed/auto-use change. Existing10 material tests pass, including stale source/file/label/evidence and traversal/symlink/MIME/size failures. |
| AC07/08/09 preservation | Restoration silently rewrites accepted text/edition/figures/PDF/R10 | Git56f4 accepted preview bytes and9fe9 committed manuscript | Entire publication/assets delta against56f4 is only publication.json, materials.json and R11 review record. Manuscript/semantic/profile/PDF/five visuals/history R10 remain exact to accepted preview. Native CLI validates committed9fe9 source SHA4bee7c…a80d, seven sections/five figures. pdfinfo independently reports five A4 pages,869961bytes, no JS/encryption. |
| AC05 scanner dispositions | Blanket/other-value allowance; wrong tuple | Actual source producers/digests and exact ID path/rule/SHA1(value) | Exactly12 ledger rows appended, zero prior rows removed/changed. All12 proof locations contain the stated value on the stated line, ID SHA1 recomputed, exact ledger tuple present. All values independently regenerated through native semantic/material/rights producer or file/byline/source hash. No scanner/rule/input/threshold code changes in this delta. |
| AC05 Bandit binding | Changed finding/rule/line/source/expiry masked | Actual raw48 findings + source/line bytes + prior policy coordinates | All five check_ri_ci rows match raw line/rule/severity/confidence, current full-file/line hashes; other row fields except source hash/rationale remain equal. Exact locations16/B404,360/B102,438/B607+B603,493/B105. Fixed argv/no shell call, repository-owned test exec and literal report field inspected; developer tooling trust boundary remains explicit. |
| AC05/history retention | Historical bytes destroyed or pointer misleading; RI cap relaxed | Original Git56f4 blobs vs decompressed bytes + original hash | All10 gzip payloads decompress byte-identically to originals and match proof SHA256; original-path locator sampled. No RI limit/runtime/validator/selector/budget change in inspected delta. |
| AC05 guard negative behavior | Exact dispositions also admit changed/missing/uncovered findings | Existing fault/refusal suites | Six selected quality-sources cases pass: exact tuple, wrong path/rule/value, changed/new/missing/duplicate finding, stale source/shifted line/expiry/symlink, scanner errors/missing coverage/malformed report refusals. |

Recomputed native identities: semantic `1b46ff4224dfa8c7eb691bb8763704c54078c7b27c654258ee01988061162972`; reviewBinding `7b356b9ae34d76da2c631e4c917957894f7ff4664cc1d7ecd2398926183ca5b7`; evidence file `dee071eb94cad89de5583e21c15d7e5384d1aad992aaf12907b3e9edcabcc4f6`; native selected rights notice `9f0596639af391652308b3bcc909bb053ba70961e3778ff0ec33d5285a944618`; materials-render `3b7ce0cdba81ee0d20c43834a9e08f16d4bdffcaef2ee9d2dadbd39cde82c3c8`; AST byline `a29075608383b251ea819ab8fd1071f96db731b80e0508e309592d09c7048298`; Python source `8458c71b45d513eb6e0b7216dad4f27da9b99cc985e047b4539ba8ca49adf3c3`. PDF hash is validated both by native material loading and manifest/immutable asset identity. Rights notice recomputation uses native rendered renditions, rather than the raw publisher article, which has a different correct raw-source notice digest.

## Actual bounded executions

- `node --test --test-name-pattern='public inventory paths|closed secret ledgers|Bandit admission' tests/quality-sources.test.cjs`: exit0,6/6 pass,0fail/cancel/skip/TODO,116.588ms.
- `node --test tests/article-materials.test.cjs`: exit0,10/10 pass,0fail/cancel/skip/TODO,130.057ms.
- `node tools/publishing/cli.cjs validate sdlc-out-of-balance`: exit0, committed source/edition/provenance success.
- Read-only Python Git/hash comparison: complete supplied manifest validates, catalog equality true,10/10 history originals true,12/12 tuple/hash/location checks true,5/5 Bandit source/line/raw matches true.
- Native article selector/material producer: accepted noncandidate, six resources (five visual renditions plus PDF), one optional-download PDF; expected notice/material digests regenerated.
- `pdfinfo .../reading-r11.pdf`: exit0, five pages as above.

Two exploratory one-off AST lookup snippets failed with TypeError because I initially addressed nonexistent ast/document or model.children fields. Source inspection established the correct model.tree.children[2]; the corrected read-only recomputation passed. These were reviewer probe errors, not product failures, and no source was changed. An initial9fe9 whole-publication comparison also found the pre-existing profile changes; comparing to the actually accepted56f4 preview established that the profile is unchanged in this restoration. No blind full-suite/scanner rerun occurred.

Existing maintained mapping: article-materials/site-articles/article-budgets and publisher/profile/history checks are source registry entries in tools/quality/test-profiles.json and SITE-CHECK-PROFILES; quality-sources owns scanner/refusal checks. I executed the smaller relevant material and exact scanner refusal cases only; site-articles/budgets/full source are allocated to the parent campaign, not duplicated here. This is structural risk selection, not measured branch coverage.

## Remaining gates and limits

Separate raw corrected Bandit triage says48raw/48reviewed/0untriaged and no scanner errors. That is one component result, **not full current security success**. The full corrected scanner campaign was reported running and was not duplicated. First failures remain relevant; their retained subjects are not reclassified green here. The supplied checksum proof refers to an earlier source and is accepted only for demonstrably equal literal/producers recomputed against this candidate; no earlier scan is relabeled current-head success.

Full current-source/Basic/RI/RI-CI/owning/style/format/security/advisory native admission and all four completed review roles must be reconciled by the orchestrator. This bounded role did not execute those full campaigns or fetch final native checks. Actual Ready admission, owner full stable-stage success/promotion, exact final hosted article/PDF bytes, desktop/mobile/no-JS/normal-motion/settled-history, references/related links and stable PDF download are **not observed/pending**, not inapplicable. Five-page PDF visual readability is delegated to its separate visual/human gate; pdfinfo is not visual review. Local exact output is not hosted evidence. No merge/production/platform posting is authorized by this continuation. Whole ACs must remain open except valid historicalAC06.
