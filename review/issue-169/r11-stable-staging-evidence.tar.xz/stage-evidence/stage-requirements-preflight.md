# Requirements & Acceptance — first independent staging preflight

Date: 2026-11-07. Role: distinct nonauthor Requirements & Acceptance reviewer, task `/root/stable_requirements`. Read-only preflight; no implementation, tests, external changes or delegation performed. Only this assigned review artifact was written.

## Verdict

**Requirements permit the proposed bounded transition to accepted native catalog/PDF admission, followed by the existing Ready and owner full stable-staging route. This is not a Ready/staging acceptance result.** No additional author decision is needed for that authorized transition. The exact author decision is issue169 comment6705211415, fetched directly from GitHub: it identifies source56f4bf90a0b77d180c2e662501c2c87092c08319, accepts the delivered reader/PDF, authorizes accepted catalog/material restoration and current-source Ready/full stable staging, and expressly stops before PR170 merge, production activation or platform posting. Preserve original whole ACs and historical AC06; acceptance of one editorial decision does not complete all criteria.

The normal route remains required. Exact-byte author acceptance covers the displayed R11 manuscript, semantic edition, five visuals and five-page PDF. It supplies no unobserved mobile/no-JS/history/runtime evidence and does not waive native source/security/hosted/performance gates.

## Inspected identity and sources

- Live `git ls-remote`: main/HEAD096ed26abb018a52864d9f6fcea91e62731857d6; publication branch56f4bf90a0b77d180c2e662501c2c87092c08319. Local HEAD matches; working tree clean at inspection. GitHub PR170 fetched directly: open, Draft, unmerged, same head/base. No fetching/mutation was needed to establish these refs.
- Primary GitHub issue169 body/ACs and comments, specifically6705211415; the owner is unchanged. The issue body retains original IDs and whole criteria open except historical AC06. Current PR body still describes prior preview scope and requires reconciliation before Ready.
- Root AGENTS, README, CONTRIBUTING, MEMORY (dated handoff, not authority), REPOSITORY-MAP navigation; common reviewer contract and Requirements role; site source contract; native-check-allocation; issue169 acceptance policy; ARTICLE-WORKFLOW site-first/canonical boundary; ARTICLE-MATERIALS binding; SITE-STAGING Ready/full owner route; relevant release-gate routes.
- Actual publication, materials declaration, R11 edition, manuscript/PDF hashes, review record, article-preview selection, rights entry; historical9fe9b70 catalog row and first structuredOrder entry; actual native article/material tests and current eight-shard workflow.
- Packet SHA25658988e6f1eac73757fe86427c9cd91f34d3315e7ef3b8ec75070c700be2d8167. Common prompt SHA2562bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb. Role prompt SHA256010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6.
- R11 manuscript SHA2564bee7c727e2a4add666b48888028ea04750804841fa1c7249e0cc5120950a80d; committed9fe9b701fcaba559c455bf17c92f5e96362e739b/blobf30e2d5e41685407e7790678a79a0b036e23627f. Semantic SHA2561b46ff4224dfa8c7eb691bb8763704c54078c7b27c654258ee01988061162972. PDF SHA256568c87ea56d054d6d5cdbcd647e878bcd122d688da5cb2370fb2b0cb3a914d58. These actual hashes agree with native material/edition declarations.

Requested none-fork isolation is stated in assignment; actual spawn acceptance/provider internals are not observable from this child. No parent chat, personal context, scratch notes or current peer outputs were inspected. GitHub issue/comment history is primary authorized material. Initial combined navigation read produced truncated output; directly inspected relevant owners afterward. Full repository map was not treated as comprehensively audited. CLI `gh` lacked authentication; connector read succeeded, with no credential workaround.

## Requirements findings and treatment

1. **Required reconciliation before Ready, not a new scope blocker:** `.github/acceptance/issue-169.json` EDITORIAL, `native-check-allocation.md` R11 subsection, MEMORY, PR170 description and R11 material review still call exact approval pending/preview-only. Append the actual source-bound decision and current scope; preserve earlier statements as dated history. Do not leave contradictory current routing or claim every editorial/live gate complete.
2. **Native admission must follow exact authored owners:** publication currently has `status: review`; material approval is null; publication30 is absent from catalog/order; article-preview explicitly contains both pmday and sdlc. Restore publication30 and its first order entry exactly from9fe9b70, including2026/delivery/Article/Author site, set accepted status and native material review binding, remove only sdlc from review-preview selection, regenerate output/lock/RI. Keep existing pmday selection. Semantic edition/manuscript/figures/PDF stay unchanged; acceptance metadata/output route identity may necessarily change.
3. **No acceptance by tests alone:** actual `tests/site-articles.test.cjs` accepted-catalog scenario requires catalog selection and refuses invented datePublished without observed publication; materials tests reject stale source/file/label/evidence and exclude unreviewed records. These are appropriate existing oracles. Preserve them and inspect all selected full-source/staging tests for stale R10/current-review assumptions before Ready; repair only evidenced invalid assumptions with reviewed current-source oracles. Historical fixtures/evidence are not globally rewritten to R11. This bounded preflight did not audit or execute the complete selected campaign.
4. **Review timestamp must remain factual:** material approval must use actual `reviewBinding(declaration,item)` and the final review-file SHA256 after appending decision evidence. Record a factual UTC review/recording time; the fetched comment exposes null created_at, so do not invent a historical author-review timestamp from that connector output.

No contradictory substantive requirement or additional approval requirement found. Above items are necessary parts of the already proposed implementation, and become advancement blockers if omitted.

## Intent / AC to evidence and next gate

| Intent / stable AC | Required check or owner gate | Current observation / treatment |
| --- | --- | --- |
| AC01/07/08/09/11 exact R11 author decision | Actual source-bound author decision | Directly fetched comment6705211415 accepts displayed56f4 reader/PDF; restore exact bindings, preserve content bytes |
| AC04/07/10 native public selection | Existing accepted catalog and generated output checks; Writing2026/delivery/Article/Author site inspection | Current review-only source; historical9fe9 row/order verified; regeneration and desktop/mobile/no-JS placement checks remain |
| AC08/09 matching admitted PDF | Exact PDF hash, review binding/evidence, regenerated reader materials and hosted byte/link check | Actual PDF hash matches declaration; approval currently null; final native/hosted observations pending |
| AC05/11 current-source evidence | All four distinct affected role results, Basic/full source/security/advisories/RI/owning and exact accounting | This is Requirements preflight only; completed candidate reviews and selected-test audit/current checks required before Ready |
| AC05/09/10 stable delivery | Latest successful raw-head site-checks/navigation/owning, then existing owner /stage/full controller, promotion/receipt and stable reader/PDF verification | PR currently Draft; no stable acceptance claimed; skipped Draft checks do not admit staging |
| AC04/09 distribution and canonical | Existing site-first and actual production served-edition gates | Prepared links remain planned; do not record canonical/publication date/event from staging; manual platform posting outside scope |
| Whole ACs / release boundary | Existing closure/merge/production rights/archive and observed outcomes | Keep original whole criteria open except historical AC06; stop after verified stable reader/PDF; no PR170 merge/prod/posting |

The inspected current source workflow explicitly retains eight shards,20-minute jobs and600-second source deadline. Preserve full cases/accounting and existing budgets/controller protections. If any campaign fails, retain its exact source/log/accounting and diagnose before rerun under CONTRIBUTING. Stable-stage failure cannot be turned into acceptance by a documentation or timestamp refresh.

## Limits and next gate

No completed candidate exists yet; no runtime/visual/browser/test execution was performed by this role. PDF page/link/visual counts were inspected as source declarations, not independently re-rendered here. Full existing selected-test audit is explicitly still required. Provider context/model internals and the orchestrator launch receipt remain unknown to this child. The source packet references repository owners but is not itself a complete sorted byte manifest; parent must preserve actual final packet/diff/path identities for completed-candidate review.

Next: implement the bounded accepted-state restoration and reconcile current decision/allocation owners; audit current selected tests and run appropriate exact-source checks; obtain all four affected completed-candidate results; only then Ready/latest native admission → owner full stable staging → verify exact stable reader/PDF and stop.
