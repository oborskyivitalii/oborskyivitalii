# R11 White-box QA — first judgment

Verdict: no blocking artifact defect found for presenting this exact review kit and five-page PDF to the author. This is a bounded review-material verdict, not author acceptance, native site admission, integration readiness or release readiness. Whole ACs remain pending.

## Execution and inputs

Distinct nonauthor role, task /root/r11_final_whitebox; first judgment. Parent requested explicit none-fork. Provider model/context internals are unknown; no provider attestation claimed. No current peer verdicts, parent scratch conclusions or unrelated memory read. Candidate review notes were treated as subjects, not oracles. No unexpected exposure identified.

Packet SHA256 eca9448f9de74cc167ba51c6175f2958a65b6575126a745b4761ab28d9998620 verified. Byte manifest SHA256 1dc4f21e5a4b25bf29fbad63ff77228d2e17a75a0a4d379a040c73a52cb326d7 verified:66 entries, zero mismatches. Common prompt2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb; role prompt832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f. Manifest verification reads evidence bytes without interpreting peer conclusions.

Observed candidate root /workspace/scratch/3db1b2682338/r11-kit-candidate, HEAD9fe9b701fcaba559c455bf17c92f5e96362e739b. Status matches four modified and three new files in packet: dirty prepared subset, not a clean commit. Local main312fbe is stale against packet main096ed26; no integration conclusion. Manuscript SHA2564bee7c727e2a4add666b48888028ea04750804841fa1c7249e0cc5120950a80d; PDF568c87ea56d054d6d5cdbcd647e878bcd122d688da5cb2370fb2b0cb3a914d58; kit d1cf0d9d43cf5b3e36005d6cb3811732a9cc7f7f273e6001c5016e03a797e499.

Read root AGENTS/README, relevant map entries, dated MEMORY as handoff, CONTRIBUTING failure/review rules, site contract, supplied issue169 and R11 author handoff, acceptance policy, ARTICLE-WORKFLOW/MATERIALS and check-profile mapping. No relevant nested AGENTS found. Read complete manuscript, changed metadata/edition/materials/rights diff, native article/profile/kit/materials selection and relevant existing test inventory. Remote refs/PR/CI not independently refreshed by this bounded local role.

## Risk-to-check matrix

| AC/risk | Structural fault and oracle | Actual check/result |
| --- | --- | --- |
| AC07/09 wrong edition | R10 derivative pins accidentally retained; committed source and semantic/byline must bind R11 | Native validate pass; proposed R11, source committed, seven subordinate sections/five figures; native AST exactly equals supplied PDF AST |
| AC07/09 text loss/order | Footer interrupts split paragraph; assert exact footer before removal, then ordered full blocks | Existing verifier assertions pass:72 nonimage blocks in order; direct page4/page5 continuation checked |
| AC08/09 PDF overflow | Sixth page or clipped images/apparatus | Five pages,869961bytes,five images,four figure captions; all five page PNGs visually inspected, no observed clipping |
| AC02/09 lost URLs | PDF annotations differ from source declarations | Exact URI set17 unique declared reference/author URLs, pass; no reachability claim |
| AC04/09 platform drift | Missing format, adaptation or truncation | Eight files exist; full TXT prefixes and source byte parity pass; no authored adaptations; common native renderer inspected for all formats |
| AC04/09 false publication | Planned links imply canonical or accepted edition | Review status, approval null, pending canonical instructions, resolved planned article/materials links:pass |
| AC05/09 premature admission | Review article or unapproved PDF becomes public | Native article selection explicitly rejects catalog status other than accepted; materials consumer skips approval null. Source-inspected, no site admission run |
| AC04/05 history | R10/docs/catalog overwritten | Git diff empty for R10 edition/PDF/review, manuscript/docs/catalog; retained file pins match manifest |
| AC05 kit corruption | Changed/missing/extra output or forged identity | Existing native verifyKit verifies inventory/bytes and recalculated identity:pass |

## Executed checks and raw observations

All commands completed exit0; no full suite, source/test edit, external write, delegation or renderer execution.

1. SHA256 packet and all byte-manifest entries: manifest digest matches;66 entries, mismatches[]. Git status/rev-parse/show-ref confirm prepared state above.
2. node tools/publishing/cli.cjs validate sdlc-out-of-balance: source SHA4bee7c7, commit9fe9b70, blobf30e2d5e41685407e7790678a79a0b036e23627f, state committed, edition sdlc-out-of-balance-en-r11-20261107, sections7, figures5.
3. node tools/publishing/cli.cjs verify dist/publications/sdlc-out-of-balance/d1cf0d9d43cf5b3e36005d6cb3811732a9cc7f7f273e6001c5016e03a797e499: Verified artifact d1cf0d9d43cf5b3e36005d6cb3811732a9cc7f7f273e6001c5016e03a797e499.
4. Read/compile existing r11-verify-review.py only before its report assignment and execute existing assertions in memory; its output-writing section was not executed. Pass72 ordered blocks, captions/images,17 URLs, page/byte bounds, exact source, eight formats, TXT full prefixes, planned backlinks, launch placeholder resolution and review status.
5. Direct native loadArticle model.tree equality versus r11-model.json:true. This independently binds the PDF input to the maintained compiler. LinkedIn/Medium TXT each20938 Unicode code points, within22000/30000; adaptations[].
6. Pypdf:five pages/869961bytes/five images. Page4 ends with 'Investigate failures; a passed drill'; page5 after its asserted footer begins 'supports only the scope tested.' All supplied page1–5 images inspected, with hashes verified. Git diff over historical R10/source/docs/catalog paths empty.

## Failure diagnosis and oracle assessment

Initial20000 character rejection is an authored-profile boundary, not a platform rule. Native profile code counts Unicode code points including link furniture;22000 preserves complete R11. No platform editor capacity is inferred.

Initial six-page trial violates the hard ceiling. Inspected renderer preserves body10.2pt/reference9.1pt, changing spacing/leading/diagram width/margins only. Present output satisfies five-page constraint with readable figures. I did not overwrite trial or current PDF.

Footer correction is narrow: pypdf emits the exact known running footer before each page body, interrupting concatenated paragraphs. Existing verifier asserts that prefix before removing it, instead of deleting arbitrary prose. Direct extraction and page inspection confirm continuation. Ordered substring matching alone does not prove absence of added prose or semantic HTML parity; native source/AST equality, renderer and page inspection complement it. The corrected #article-materials matches native owner; guessed #materials would be a false oracle.

No new test or fault injection executed. Inspected existing publishing-profile tests cover authored character/footer bounds and malformed selections; article-materials tests cover pending/private exclusion and stale bindings; existing publishing/history suites own kit corruption/provenance. SITE-CHECK-PROFILES maps these to publisher/distribution source work. They were mapped, not reported executed or as measured branch coverage.

## Findings and limits

No blocking defect within presentation scope. Examined source/byline/semantic drift, paragraph omission/order, footer false negatives, fifth/sixth-page boundary, all-five-image presence, link loss, eight-format omission, pending-state leakage and R10 overwrite.

Catalog still selects the article while status is review: native accepted-only reader will refuse it. This is the expected review-only boundary, not a site pass. Approval null excludes the proposed PDF from public materials. Exact author acceptance and owner integration remain required; do not promote this result or proposed review note to author acceptance.

Not observed: accepted desktop/mobile/no-JS website, live/current remote refs/PR/CI, stable/production artifacts, URL reachability, native platform editor transfer, reciprocal publications, full RI/Basic/source suites or release-rights admission. No browser check attempted or claimed. Managed environment-status tool unavailable; no readiness inferred. Provider context internals remain unknown; orchestrator must preserve actual launch receipt and apply common isolation admission policy. Whole AC01–05/07–11 remain open; historical AC06 unchanged.
