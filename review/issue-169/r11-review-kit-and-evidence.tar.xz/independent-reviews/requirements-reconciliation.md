# Requirements & Acceptance — bounded factual reconciliation

Execution `/root/r11_final_requirements`, 2026-11-07. Continuation of the original Requirements review, not a fresh independent first judgment. Reconciliation input was the orchestrator’s factual clarification of caption receipt wording and native/emitted character accounting. No peer result was supplied or read. No candidate bytes changed. Only this reconciliation artifact is written.

## Outcome

**The presentation-only verdict stands. F1 is resolved as a receipt-wording disposition:** accurately state **five images and four numbered figure captions**, with the hero’s declared caption omitted from the reading PDF and visible for the author’s disposition. No five-caption pass is supported or claimed. The omission itself has not been changed, and this disposition does not invent author acceptance of it.

The orchestrator states that the hero treatment follows the R10 adapter. My original direct observation remains sufficient for the present disposition: the current renderer explicitly omits the hero caption; page 1 displays the hero, the four diagram captions are visible, the kit retains the full hero caption/credit, and page 5 retains author/rights apparatus. The historical adapter lineage is supplied context, not a newly independently executed historical comparison. The final author receipt was not separately supplied as a completed file; this closes the wording issue on the stated disposition, subject to the actual receipt preserving that wording.

## Character-count erratum

I independently loaded the actual native article with `loadArticle(process.cwd(), 'sdlc-out-of-balance')`, read the kit manifest’s exact distribution fields, reproduced the footer expression in `tools/publishing/profile.cjs::characterLimits`, and counted Unicode code points with `Array.from(...).length`. I independently counted both emitted TXT files with the same method.

| Quantity | Exact observed code points | What it measures |
| --- | ---: | --- |
| Native `loadArticle(...).text` | 20,880 | Actual native compiled article text supplied to the profile check |
| Exact profile distribution footer | 220 | Two leading newlines, both labels, separators and planned article/material destinations from the current manifest |
| Native profile oracle | 21,100 | Exact `selected.text + footer` expression protected by `characterLimits` |
| Emitted LinkedIn TXT | 20,938 | Actual decoded UTF-8 file, counted without newline translation |
| Emitted Medium TXT | 20,938 | Actual decoded UTF-8 file, counted without newline translation |
| LinkedIn authored bound | 22,000 | Current profile; 900 code points above the actual native profile oracle |
| Medium authored bound | 30,000 | Current unchanged profile bound |

The earlier packet figures 20,710/20,940 are **not** the exact native profile/emitted-file measurements and must not be reused as such. The orchestrator’s supplied explanation is that those figures came from a direct compile using shorter projected image URLs and a manually assembled footer. I did not rerun that historical failed projection. I verified the current exact measurements above directly, without changing implementation or requirements. The first review’s 20,938 TXT observation remains correct; this reconciliation adds the separate native profile oracle and resolves the ambiguity.

The authored 22,000 LinkedIn bound still accommodates the complete article under the actual 21,100 profile oracle. Both bounds remain authored review constraints, as the owner code explicitly states; none of these numbers is a verified native platform-editor rule. No source truncation, validator relaxation, platform acceptance or publication result follows from them.

## Preservation and remaining gates

Rechecked all 66 byte-manifest entries: zero mismatches. Candidate remains dirty prepared subset at HEAD `9fe9b701fcaba559c455bf17c92f5e96362e739b`, kit artifact `d1cf0d9d43cf5b3e36005d6cb3811732a9cc7f7f273e6001c5016e03a797e499`, PDF SHA256 `568c87ea56d054d6d5cdbcd647e878bcd122d688da5cb2370fb2b0cb3a914d58`. The original first result is unchanged: SHA256 `c4af6c190ade15a45a5e8bbca4d975f0ba8ed23496d97e15bdc1a6dbb8836698`. Original packet, failed observations and source-bound history remain retained; this erratum does not rewrite them.

Unchanged evidence from the first review is reused because every manifested candidate byte remains identical: five PDF pages, 869,961 bytes, 72 ordered nonimage source blocks, 17 exact declared reference URLs, native validation/kit verification and the observed review-state boundaries. No new full campaign or browser test was run for this factual reconciliation.

Exact author editorial/visual/PDF approval, including disposition of the hero caption omission; all required independent role/launch receipts; accepted native/catalog/material/output integration against current main; applicable exact clean-source checks; actual hosted desktop/mobile/no-JS/related-reading/PDF checks; full owner stable staging and exact stable reader/PDF inspection all remain pending. The continuation endpoint remains **verified stable staging, inspect, STOP/show**. PR170 merge, production activation, served canonical/date/event proof, native platform-editor equivalence, author-manual posting and later observed reciprocal platform links are still separate gates. All original whole article ACs remain pending except historical AC06.
