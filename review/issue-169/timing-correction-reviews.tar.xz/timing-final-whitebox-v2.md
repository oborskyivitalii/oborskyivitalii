# White-box QA — v2 correction continuation

**Verdict:** no blocking defect found in the additional HTML-only startup optimization or its regression tests. Four bounded existing cases executed successfully,4/4 native TAP tests with zero failed/cancelled/skipped/TODO. The reviewed optimization preserves parser-event and refusal behavior in those observations. Corrected full native prepublication deadline and verified stable staging remain **not observed**, so no whole delivery/issue acceptance follows.

## Identity, chronology and source

This is the same nonauthor role `/root/timing_final_whitebox`, continuing its own correction review; it is **not a fresh isolated launch**. The first output remains intact at `timing-final-whitebox.md`, SHA-256 `4d8af5fbb4ea2b01bba9aa5060eb4cf9df39d899625c9ee2b227c4c5d30d06ee`. Its own scheduling analysis and executed results are reused only because worker, source runner, profile tests and profile guide hashes remain unchanged.

Owner remains issue169/PR170; latest packet requires stable staging and STOP/show, excluding PR170 merge/production. Prepared subset, dirty checkout, base `53102d7d55012d6bd954d7d4b248d75dc75e9600`; not a clean native checkout.

- V2 packet `timing-correction-v2-packet.json`: SHA-256 `8cf598fea0c4907eae1f3e75834655cef7eea701529b66e4382012e008576a93`.
- V2 cumulative diff: SHA-256 `1491c1098faddd3936fb4998e954f040bdeb0534e44e1a1816536adbac121277`.
- Added inspected CJS helper: `tools/quality/format-parity.cjs`, SHA-256 `ca3622547e5e65cd7b7ebb5d7e1283e47833a83c7b8dcf14ac9010c3fbd4804e`.
- Unchanged actual Python parser: `tools/quality/format-parity.py`, SHA-256 `2f26d71bac62d7ed20579834a4d835bbae2a433e36ff80515714bb05c920b2d7`.
- Added inspected tests: `tests/format-parity.test.cjs`, SHA-256 `6e866b4a7310113f952e913a7cf25175770cfb75d453e741277111c57b1aaa05`.
- Common/role prompts remain SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` / `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.

All15 supplied source files and9 raw evidence files matched packet identities. All15 source files and cumulative diff matched again after execution. Original owner snapshot remains the supplied factual scope, hash recorded in first output. No current peer result, author private history or unrelated memory was read. No source/test edits, external writes or delegation occurred. Provider model/context internals remain unknown; orchestration launch receipts remain separately required.

## Changed structure and test oracles

The new delta is at `format-parity.cjs:156–164`: select `['-S', helper]` only for a nonempty array whose every row has `language === 'html'`; all other calls retain `[helper]`. Interpreter path, helper path, input serialization,64MiB output bound, process error/nonzero rejection, result cardinality, per-row error and missing-contract checks remain unchanged. The Python helper bytes are unchanged and the HTML path imports only standard-library `json`, `re`, `sys`, `html.parser`. YAML's third-party import remains local to its own language branch, which retains ordinary startup. This is an invocation change, not an alternative or weaker parser.

The new test at `tests/format-parity.test.cjs:15` independently executes the actual ordinary interpreter/helper and compares returned event contracts against the optimized API. It covers doctype/comment/attributes/entities/inline text, script/style raw content and SVG text. It also compares mixed YAML+HTML and empty requests against ordinary execution, then requires the duplicate-attribute refusal's exact type/message. Because ordinary and optimized paths use the same unchanged parser, this is a meaningful invocation-parity oracle. It does not by itself establish the parser's semantic correctness; the existing explicit positive/negative HTML and YAML contracts supply independent expected outcomes.

The retained HTML case at198 exercises entity equivalence, whitespace/inline boundaries, NBSP, links, raw pre/textarea/script, SVG and MathML handling, duplicate attributes and unsupported non-void self-closing syntax. Exact parser diagnostics at59 use literal expected messages for HTML/JSON/Python/YAML, including mixed order before/after YAML imports. The YAML semantics case at160 retains expression/scalar/folded/ordering distinctions. These are behavior checks, not merely subprocess-argument or source-text assertions.

| Risk / affected AC | Structural fault / scenario | Independent oracle | Existing check / result |
| --- | --- | --- | --- |
| AC05/11, CS07/08: `-S` changes HTML interpretation or swallows refusal | Actual ordinary vs optimized helper for markup event batches and duplicate attribute | Exact event-array equality and `ValueError: Duplicate HTML attribute` refusal | New HTML startup test, executed pass |
| AC05: HTML-only condition accidentally reaches mixed/empty calls | YAML+HTML batch and empty request list through optimized API versus ordinary helper | Same complete contracts, YAML import succeeds, empty returns empty | Same new test, executed pass; condition source-inspected |
| AC05, CS08: import/order changes error oracle | Invalid primary-parser requests individually and in both mixed orders | Literal exact error type/message for each row | Existing primary diagnostics, executed pass |
| AC05/09/10: same-helper equality hides semantic weakening | Explicit changed HTML links/text/separators/raw content and YAML data semantics | Accepted formatting equivalence, rejected meaning changes and invalid markup | Existing HTML + YAML semantic cases, both executed pass |
| Delivery acceptance: local optimization mistaken for full native timing pass | Exact final clean-source75-file prepublication execution | Actual complete strict native accounting under unchanged300s/16MiB limits and applicable staging gates | Existing native route, not observed for corrected candidate |

## Executed check and complete raw output

Working directory `/workspace/scratch/b15f3a872203/repo`; pinned Node v24.19.0, same interpreter used by prior bounded checks. Command:

```text
/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node --test --test-reporter=tap --test-name-pattern='^(HTML startup isolation preserves actual primary parser contracts and refusals|primary parser diagnostics retain exact types and messages before and after YAML requests|ordered YAML values preserve expressions, scalar types and folded content|HTML preserves wording, attributes, nonbreaking spaces and inline separator presence)$' tests/format-parity.test.cjs
```

Exit0, no signal or stderr:

```tap
TAP version 13
# Subtest: HTML startup isolation preserves actual primary parser contracts and refusals
ok 1 - HTML startup isolation preserves actual primary parser contracts and refusals
  ---
  duration_ms: 220.678051
  type: 'test'
  ...
# Subtest: primary parser diagnostics retain exact types and messages before and after YAML requests
ok 2 - primary parser diagnostics retain exact types and messages before and after YAML requests
  ---
  duration_ms: 328.17771
  type: 'test'
  ...
# Subtest: ordered YAML values preserve expressions, scalar types and folded content
ok 3 - ordered YAML values preserve expressions, scalar types and folded content
  ---
  duration_ms: 205.084581
  type: 'test'
  ...
# Subtest: HTML preserves wording, attributes, nonbreaking spaces and inline separator presence
ok 4 - HTML preserves wording, attributes, nonbreaking spaces and inline separator presence
  ---
  duration_ms: 425.599115
  type: 'test'
  ...
1..4
# tests 4
# suites 0
# pass 4
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 1265.009249
```

The supplied `parser-correction.tap` additionally reports10/10 whole-suite passes; this is reused supplied evidence, not an independently repeated suite. The supplied startup probe reports one successful executive case in10448.591696ms. Its observer JSON reports status0,11565.333505ms total,359 parser calls/448 requests with no duplicate rows and10788.186658ms parser time. Those bounded case observations motivate investigating startup cost; neither demonstrates a corrected full native deadline or a general speed guarantee. The original native ETIMEDOUT evidence remains retained and failed.

## Allocation, findings and remaining limits

No new suite is needed. `tests/format-parity.test.cjs` is already permanent, owned by `guides/SITE-CHECK-PROFILES.md`, selected for PR-targeted/staging/production and triggered by itself plus `tools/quality/format*`. Its existing ordinary source-shard route is `.github/workflows/site-checks.yml` `source_shards` with strict `checks` aggregation; full native prepublication remains the separate site-release-checks build/source-check route recorded in the first output. All four bounded checks exercised existing implementation/tests; this reviewer authored no accepted test or fix.

No new blocking finding. Examined startup classification, actual stdlib-parser event parity, mixed/empty fallback, unchanged refusals and process/accounting boundaries. The first review's worker cap, isolation and cancellation observations remain valid for unchanged bytes. Invalid nonarray requests, malformed row types, Python startup environmental customization, Windows execution, max-output failure and helper process failure were not newly executed; unchanged guards were inspected and no measured branch coverage is claimed. The new API test observes behavior rather than intercepting `-S` arguments; direct branch inspection supplies the invocation-allocation evidence.

**Still pending:** exact-source full native completion under the original deadline and subsequent verified stable staging, plus applicable article/PDF/visual gates. Whole AC05/09/10/11 remain open to their wider evidence. This report provides bounded source/test review only and does not authorize PR170 merge or production.
