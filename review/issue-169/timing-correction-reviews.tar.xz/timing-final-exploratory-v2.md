# Exploratory / Interaction QA — parser startup correction v2

Verdict: **no blocking interaction finding in the inspected v2 correction**. Four independently chosen API/operator cases passed using actual Python child processes. The HTML-only invocation preserves inspected event contracts, rejection diagnostics and public parity decisions. Native full staging/deadline acceptance remains pending.

## Continuity, identities and scope

This is the same role's correction continuation, `/root/timing_final_exploratory`, not a fresh independent launch. The first result remains intact at `timing-final-exploratory.md`, SHA-256 `2fefcc5577a5b1a9e53f01959e6a1dac746709392f5a7e1efa0135aea211abde`. No peer verdict, parent history, private author notes or unrelated memory was read. No implementation/test edits, external writes or delegation occurred. Requested/accepted original launch parameters belong to the orchestrator's receipt; provider model/context/memory internals remain unknown.

Owner issue169 / PR170; base `53102d7d55012d6bd954d7d4b248d75dc75e9600`; actual candidate is a prepared dirty subset, not a clean Git candidate. Latest scope remains verified stable staging and R10 inspection, then STOP/show; PR170 merge and production activation are excluded. AC05/AC11 receive this bounded review result only. AC09/AC10 article/PDF/browser evidence is not added.

Packet `/workspace/scratch/b15f3a872203/reconcile-review/timing-correction-v2-packet.json` SHA-256 `8cf598fea0c4907eae1f3e75834655cef7eea701529b66e4382012e008576a93`; diff SHA-256 `1491c1098faddd3936fb4998e954f040bdeb0534e44e1a1816536adbac121277`. All15 source manifest entries, nine raw-evidence entries, diff and original-owner snapshot matched supplied hashes; all15 source hashes matched again after execution.

Common prompt remains `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt remains `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`. Reviewed substantive delta and full helper boundary, Python parser behavior, added regression source and registry route. Applicable source/policy readings from the first review remain unchanged and are reused by byte identity.

| Source | SHA-256 |
| --- | --- |
| `tools/quality/format-parity.cjs` | `ca3622547e5e65cd7b7ebb5d7e1283e47833a83c7b8dcf14ac9010c3fbd4804e` |
| `tools/quality/format-parity.py` | `2f26d71bac62d7ed20579834a4d835bbae2a433e36ff80515714bb05c920b2d7` |
| `tests/format-parity.test.cjs` | `6e866b4a7310113f952e913a7cf25175770cfb75d453e741277111c57b1aaa05` |

Python helper bytes also match the actual base Git blob. Only nonempty arrays whose every row has `language === 'html'` choose `['-S', helper]`; all other requests retain `[helper]` using the same configured executable. Existing process failure, incomplete coverage, row error and missing contract handling remain unchanged. No browser/site/docs source changes appear in the correction diff.

## Charter and execution

Before running, chose four API journeys against the changed invocation: actual HTML event contract; empty/mixed/non-HTML boundary; exact invalid-input refusals and recovery; public `compareSources` semantic decisions. The independent oracle combined literal expected HTML events, existing advertised semantic invariants and ordinary invocation of the identical Python interpreter/helper. Actual child execution was used throughout; no mocked process or process-global monkey patch.

Environment: Linux prepared source, pinned Node `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node` observed v24.19.0; configured default venv Python observed3.12.14; `SITE_AUDIT_TOOLS` unset. Four top-level checks completed in0.396seconds, below the prior eight-minute bound. Multiple inputs within each boundary journey are disclosed below. The diagnostic ran via Node stdin and wrote no accepted source or new test file.

| Case | Expected | Observed |
| --- | --- | --- |
| V2-E1 HTML-only entities, inline and raw events | Exact literal declaration/comment/decoded ordered attributes/text/inline/NBSP events; unchanged script raw contents and ordinary-parser parity | Executed/pass; both HTML requests matched ordinary invocation and literal/raw assertions |
| V2-E2 empty, mixed YAML/HTML and non-HTML | Empty returns0 contracts; mixed YAML+HTML returns both ordered contracts; Python+JSON remains accepted; all match ordinary startup | Executed/pass for all three partitions, including successful third-party YAML import on the normal path |
| V2-E3 refusal and recovery | Duplicate HTML attribute yields exact `ValueError: Duplicate HTML attribute` alone and after YAML; non-void self-closing HTML yields exact refusal; subsequent valid call succeeds | Executed/pass; both startup paths retained matching refusal, valid next call returned exact expected events |
| V2-E4 public parity API | Entity spelling equivalence passes; NBSP deletion, changed href and inline-separator deletion fail parity; duplicate attributes throw exact error | Executed/pass for equivalence, three semantic changes and invalid source |

Raw execution receipt, exec chunk64c0f9, exit0:

```jsonl
{"node":"v24.19.0","python":"/workspace/scratch/b15f3a872203/repo/tools/quality/toolchain/venv/bin/python","pythonVersion":"Python 3.12.14"}
{"case":"V2-E1 HTML-only decoded entities, inline and raw events","status":"passed"}
{"case":"V2-E2 empty, mixed YAML/HTML and non-HTML requests","status":"passed"}
{"case":"V2-E3 exact refusals across HTML-only and mixed calls; recovery","status":"passed"}
{"case":"V2-E4 public compareSources preserves actual semantic-change rejection","status":"passed"}
{"cases":4,"passed":4,"failed":0}
```

## Evidence reuse, risks and acceptance limits

Prior source-runner/worker/profile-test bytes are unchanged from the first review. Its isolated scheduling, unknown-file ordering, visible failure accounting, durable CLI report and unknown-option observations remain reusable within their original bounds. I did not repeat those campaigns. The retained native failure42309808371/1 remains failed and is not converted into a pass by this review.

New supplied parser-correction parent evidence ends10/10 with zero skipped/cancelled/todo; it is separately supplied evidence, not this review's independently run test campaign. The supplied executive observer records one bounded passing case,359 parser calls/448 requests with zero duplicate inputs and11565.333505ms elapsed. This supports the stated startup investigation only; it does not prove the full profile fits300seconds or quantify a controlled before/after speedup. No full-profile timing claim is accepted here.

No concrete blocking defect found in the examined surface. Risks checked: HTML entity/text/raw corruption; mixed-language YAML import breakage from incorrectly applying `-S`; empty/non-HTML routing regression; silently accepted invalid attributes or unsupported self-closing HTML; changed exact diagnostics; incorrect parity decisions; failure persistence across calls. The same Python helper and complete original contracts remain the parser owner. Ordinary and `-S` invocations were compared using the same interpreter, not substitute parsers.

Browser interaction is reasoned not applicable to this code delta: it changes a build/check helper invocation and regression source, with no user-facing web implementation or rendered asset change. Actual browser, human usability and PDF/hosted inspection remain unobserved here and applicable to the wider owner. Windows/other Python installations and native hosted CPU contention were not observed. This bounded result establishes no complete AC, release readiness or source-wide performance guarantee.

Allocation through `guides/SITE-CHECK-PROFILES.md`: these parser contracts already belong to permanent `tests/format-parity.test.cjs`, with explicit `tools/quality/format*` and test-file inputs, PR-targeted/staging/production routes in `tools/quality/test-profiles.json`. The added existing test `HTML startup isolation preserves actual primary parser contracts and refusals` covers ordinary-vs-HTML-only/mixed/empty and refusal parity; the maintained HTML semantic suite covers V2-E4 invariants. No duplicate workflow or new campaign is proposed. Existing exact-source native staging source-test job remains the deferred timing/complete-accounting owner under issue169/PR170 orchestration, with all original limits and raw evidence retained.
