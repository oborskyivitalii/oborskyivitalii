# Exploratory / Interaction QA — timing correction

Verdict: **no blocking interaction finding in the inspected correction**. The bounded operator checks pass. This result permits only the correction-review gate for the inspected bytes; it does not establish a native 300-second staging pass, stable staging, article/PDF acceptance, or whole AC completion.

## Identity and boundary

- Role/execution: distinct nonauthor Exploratory / Interaction QA, `/root/timing_final_exploratory`, fresh correction-candidate review, 6 November 2026. I authored neither implementation nor accepted tests. No delegation or external writes occurred.
- Owner: issue169 / PR170, repository `oborskyivitalii/oborskyivitalii`. Latest packet scope authorizes integration and verified staging, then STOP/show; PR170 merge and production remain excluded.
- Local HEAD: `53102d7d55012d6bd954d7d4b248d75dc75e9600`. Prepared dirty subset: three modified files (`guides/SITE-CHECK-PROFILES.md`, `tests/test-profile-selection.test.cjs`, `tools/quality/source-test-worker.cjs`), not a clean candidate checkout. Native full acceptance remains separately required.
- Packet `/workspace/scratch/b15f3a872203/reconcile-review/timing-correction-packet.json`, SHA-256 `443920250fcb797b8cd8d7c9a2be945fba7c9ae28f26dc086a47d4739c3445e0`; diff SHA-256 `be7cbadeb04bba9ef6120ea4561a828e74025e0f530d31e55382e2cdd8de212f`.
- Common prompt SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA-256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- All 12 packet source hashes, diff hash and six raw-evidence hashes matched actual supplied bytes. All 12 source hashes matched again after checks. Principal source identities: worker `490e22564920e7c7847ef5b581a9740e53e0f9b167c0214a9769a85bb32954fe`; runner `792aec87f4abb3aec8c97b4a8d33cd958a643b8f6c77aaac4c5683d45aaf5086`; test module `7ab773d812c458eabdc2bc971fca185a5d7e3094fa7d9bd143bde07303faa894`.
- Additional owner snapshot `/workspace/scratch/b15f3a872203/issue169-current.md` hash matched `0ab9ce6e03cd50f6360b780ba21d3f20c26d021584d4552102b9da8f3d7d8cf6`; read original intent and stable AC01–AC11. Its historical status claims supply no current pass.
- Read common/role prompts, root AGENTS, README, relevant repository-map entries, CONTRIBUTING review/failure policy, code-style owner, check-profile owner, issue169 acceptance policy, actual diff/runner/worker and selected test implementations. No nested AGENTS was discovered in the affected agents/tools/tests/guides areas. Did not consult MEMORY, author-private notes, peer verdicts or parent conversation/history.
- Actual fork request/accepted launch receipt belongs to the orchestrator. I cannot attest provider context/model/memory internals; those remain unknown. No unexpected author/peer-history exposure was observed in supplied material.

## Independent charter

Before execution, selected the actual CLI/operator surface and four top-level checks within the supplied eight-minute bound: selected-file ordering including unknown future paths, isolated execution and visible failure accounting, durable CLI failure reporting, and rejection of an unsupported skip-like CLI option. Independent oracles: selected inventory must remain complete; known priorities must precede unknown paths; unknown paths must sort; process failures/empty or skipped work must not become green; failure output must survive into report/raw streams; an unknown flag must reject explicitly.

Browser/product UI is reasoned **not applicable to this correction**: the diff changes source-test scheduling, its regression expectations and operator documentation, with no browser assets, article, PDF, DOM or reader behavior changes. Actual hosted/browser/PDF acceptance is **not observed here**, remains applicable to the wider task, and is not waived.

Environment: Linux scratch prepared repository; pinned executable `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node`, observed `v24.19.0`. No package installation, network, website interaction or full native campaign. Four top-level checks completed in seconds, below eight minutes. Existing tests create and remove controlled temporary fixture repositories; no accepted source was edited.

## Executed journeys and raw evidence

Three existing behavioral tests were selected by exact name with pinned Node `--test --test-name-pattern` against `tests/test-profile-selection.test.cjs`. They exercise actual child processes rather than a simulated full-suite duration. They cannot establish production timing.

| Case | Independent expectation | Actual observation | Disposition |
| --- | --- | --- | --- |
| E1: serial isolated scheduling, test line1167 | Known expensive files launch first, unknown `aaa` remains selected; process/global isolation; selected assertions fully account; nonpassing child bodies reject | Exact expected order rights/executive/space/controller/migration/staging/aaa; native child fixtures and accounting passed. Existing test also probes six negative bodies: thrown assertion, uncaught error, exit3, skip, empty suite, exit0-without-tests; each rejected | Executed/pass |
| E2: CLI failure reporting, test line1506 | CLI exits1 and emits a matching failed structured report; retained raw TAP contains original failure and >8000 bytes; source before/after and byte counts remain bound; limits unchanged | All assertions passed using actual controlled CLI execution, retained reports and raw streams | Executed/pass |
| E3: corrected scheduling and unknown future paths, test line1673 | Reversed/unsorted selection executes known priority first; profile-selection remains included; unknown ordinary-a then ordinary-z execute last; every selected assertion counts | Exact expected 11-file ordering and 11 selected assertions passed | Executed/pass |
| E4: real runner CLI `--profile staging --silent-skip` | Unsupported option exits nonzero, names the option, and cannot silently skip source checks | Exit1; stderr `unknown source-test argument --silent-skip` | Executed/pass (expected rejection) |

Raw parent-check output (exec chunk4639d1, exit0):

```text
v24.19.0
✔ source scheduling starts expensive files early with isolated processes and preserves failure accounting (1253.6907ms)
✔ explicit source reporting retains actual failed process streams and source before the CLI exits nonzero (232.437399ms)
✔ source scheduling starts measured long files early without losing selected assertions (812.732427ms)
ℹ tests 3
ℹ suites 0
ℹ pass 3
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 2381.299414
```

Raw E4 output (exec chunk5ae074, exit1):

```text
unknown source-test argument --silent-skip
```

The top-level case count is four; E1 includes the six pre-existing negative child bodies explicitly listed above. No new test was authored. The test-name selection is a focused diagnostic, not a full profile pass. Fixture raw streams are asserted by the existing tests and cleaned up by them; only their parent-check output is retained here.

## Failure history, source assessment and limits

Inspected packet-native failed report and timing stream: staging run42309808371/attempt1 at clean source53102d7 reports status failed/pass false, ETIMEDOUT, 300000ms, 16777216-byte bound and absent final aggregate accounting. Its stderr has74 completed wrapper events for75 selected files. Highest observed durations are rights155054.293569ms, executive115228.873201ms, Space105446.850862ms, Pages delivery85168.77977ms and publication records75937.421769ms. These support prioritizing expensive modules; they do not prove the new total wall time. The unfinished profile suite cannot be assigned a measured native completion from that run.

Inspected source preserves the existing four-worker ceiling, process isolation, signal handling, full selected input accounting, clean-source checks and 300-second/30-second grace/16MiB limits. Worker order filters only selected known entries, then includes every unknown input sorted by path. Documentation explains the incomplete profile-suite estimate and explicitly denies a deadline guarantee. The packet's profile-diagnostic/corrected parent streams end48/48; profile-correction preserves the stale ordering expectation failure. Those retained historical diagnostics were not reused as current full acceptance. Current bounded checks directly rewalk the affected order/failure journeys.

No blocking defect found in the examined operator experience. Risks examined: omitted unknown files, duplicate/drop behavior from reordered priorities, loss of process isolation, failure/skip disguised as pass, hidden skip-like CLI option, and raw failure evidence being lost. Unknown/new expensive files deliberately remain path-ordered after the known list; this is documented behavior and may need future observation-based tuning, not a current missing-coverage exemption.

Unobserved: native complete corrected staging profile under its actual CPU/contention and deadline; full current-source Basic/scanners/RI; cancellation/capacity stress beyond unchanged source inspection; stable hosted publication; R10 browser/PDF and human review. These remain separate acceptance evidence. AC05/AC11 gain this bounded role result only. AC09/AC10 gain no new article/PDF/browser evidence. No whole criterion is marked complete.

## Check allocation and disposition

Per `guides/SITE-CHECK-PROFILES.md` and its maintained registry, E1/E2/E3 are existing `tests/test-profile-selection.test.cjs` behavioral cases selected for changed runner/worker/test inputs through PR-targeted source execution and retained permanent staging/production routes. No new suite, workflow or duplicated campaign is proposed. E4 is a manual focused CLI negative here; the module already owns unknown-argument rejection coverage around line1001. Proposed next observation is the existing exact-source native staging source-test job, owned by issue169/PR170 orchestration, with original limits, raw logs and zero-skip accounting. It is deferred/not executed by this reviewer and cannot be replaced by these fixtures or a fixed-duration simulation.
