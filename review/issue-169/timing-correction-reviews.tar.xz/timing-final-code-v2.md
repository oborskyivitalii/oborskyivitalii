# Code correction review v2 — issue169 / PR170

Verdict: no blocking or nonblocking Code findings in the additional HTML-only Python startup correction or its integration with the unchanged scheduler correction. Suitable for exact-source native validation. Actual native timing acceptance, complete Basic/required source checks and stable-staging readiness remain pending.

This is an own-role correction continuation by `/root/timing_final_code`, not a fresh-context launch or an additional independent role. The first result remains intact at `timing-final-code.md`, SHA-256 `9f21757cd2711b4c8a62d57ac1bd1359caa3fbbd0489a0a01030a9033d45295d`. No peer results, parent notes or private history were supplied or read. I made no implementation/test changes, external writes or delegation. Provider model/context/history-injection internals remain unknown; the orchestrator owns launch admission evidence.

## Inputs and reviewed identity

- Packet `timing-correction-v2-packet.json`: SHA-256 `8cf598fea0c4907eae1f3e75834655cef7eea701529b66e4382012e008576a93`.
- Complete actual dirty-checkout Git diff equals supplied v2 diff byte-for-byte: SHA-256 `1491c1098faddd3936fb4998e954f040bdeb0534e44e1a1816536adbac121277`; base `53102d7d55012d6bd954d7d4b248d75dc75e9600`.
- Scope digest `60808d2a8ed3b4fc6d452b35971156a38d4f781657839c6d1599e66ea28f06ee` and all referenced source/raw-evidence/owner identities validated with no mismatch.
- Common prompt `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; Code prompt `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`. Applicable source instructions and issue169 AC01–AC11 are unchanged from the first review. Latest packet scope retains STOP after staging and excludes PR170 merge/production.
- This is a prepared dirty checkout, not a clean/native admission. Actual Git status contains five changed paths: the original three scheduler correction paths and `tools/quality/format-parity.cjs`, `tests/format-parity.test.cjs`.

| Additional inspected source | SHA-256 |
| --- | --- |
| `tools/quality/format-parity.cjs` | `ca3622547e5e65cd7b7ebb5d7e1283e47833a83c7b8dcf14ac9010c3fbd4804e` |
| `tools/quality/format-parity.py` | `2f26d71bac62d7ed20579834a4d835bbae2a433e36ff80515714bb05c920b2d7` |
| `tests/format-parity.test.cjs` | `6e866b4a7310113f952e913a7cf25175770cfb75d453e741277111c57b1aaa05` |

Verified Python helper equality to the base Git blob, and revalidated every source-manifest hash before writing. The original worker, runner, profile test and profile guide hashes are unchanged from the first result, so its scheduler inspection and functional evidence are reusable within their stated bounds. The additional change alters helper invocation; the v1 scheduling-only description does not describe the entire v2 delta.

## Four bounded cases and relevant integration

1. **HTML primary-parser equality and refusal.** Read the new branch in `helperContracts` and the complete unchanged Python helper. A nonempty array whose every row declares `html` adds only `-S` before the same helper path, using the same configured venv executable. HTML uses `json`, `re`, `sys` and `html.parser`; YAML is imported only by its own branch. No parser, semantic normalization, row accounting, refusal behavior or output-buffer limit is replaced. Executed the new existing-suite regression comparing ordinary invocation with the corrected helper on declarations/comments, entities/attributes, inline separators, script/style raw text and SVG text. Duplicate attributes retain the exact `ValueError: Duplicate HTML attribute` refusal. The regression also compared an actual mixed YAML/HTML request and empty request with ordinary invocation.

2. **Diagnostics under normal startup.** Executed the existing primary-parser diagnostic case, which exercises exact JSON/Python/HTML/YAML errors individually, combined and reversed. Non-HTML, mixed and empty requests keep ordinary startup by source inspection; no YAML path is sent through `-S`. Error/exit propagation, complete-row coverage and missing-contract guards remain unchanged. No global monkey patch, new parser dependency or execution of inspected source is introduced.

3. **Non-HTML semantic failure detection.** Executed the existing ordered-YAML case. Expressions, scalar types, mapping order, folded content and duplicate-key rejection retain their independent semantic oracles. This confirms the dependency-bearing branch remains operational with the actual configured interpreter, rather than an HTML-only fixture standing in for all supported languages.

4. **HTML semantic negative coverage and SEO consumer.** Executed the existing HTML contract case: entities and finite formatter differences remain accepted; changed wording/links/inline separators/nonbreaking spaces/raw text/SVG text remain unequal; duplicate attributes, non-void self-closing HTML and invalid foreignObject content retain rejection. Inspected `tools/check_site_seo.cjs` integration: its normalizer passes explicit HTML rows to this helper, requires complete contract cardinality, renders every returned row before caching, and retains its existing entry/byte limits. The new helper branch does not modify that consumer, its cache, source reconciliation or SEO allowlists.

Exact command, using supplied pinned Node:

```sh
/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node --test --test-name-pattern='^(HTML startup isolation|primary parser diagnostics|ordered YAML values|HTML preserves wording)' tests/format-parity.test.cjs
```

Observed exit0; tests4, pass4, fail0, cancelled0, skipped0, todo0; duration1296.720155ms. These are targeted local semantic checks, not a native full-campaign pass.

The maintained registry already selects `tests/format-parity.test.cjs` through `tools/quality/format*` under PR-targeted/staging/production, and selects `tests/executive.test.cjs` for both parity helper sources. No new unselected test owner is introduced. Parsed the supplied executive observer evidence independently: one actual case passed, 359 successful parser process records cover448 HTML requests with448 distinct input hashes. Its11565.333505ms local elapsed time and the supplied10/10 format-parity receipt are bounded observations; neither establishes the corrected native75-module deadline. No fixed-duration simulation was used as acceptance evidence.

## Requirement and style disposition

CS01/04/05: the existing parity helper owns startup selection; dependency direction and parser ownership remain intact, with a small readable finite branch. CS07/08/09/10: no scanner rule, scanner input, assertion, test selection, clean-source requirement, process deadline, worker ceiling or native gate is loosened. The parser's64MiB existing buffer and the source campaign's300s +30s reporting grace/16MiB bounds remain unchanged. This review does not claim the full automatic style guard or Basic campaign ran here.

AC05/AC11 gain this bounded actual Code correction result only. No R10 article, PDF, site/docs output, related-reading logic or distribution source changes in this diff; AC09/AC10 visual/served/native obligations remain pending. The original failed native run remains failed and retained. No implementation finding or new owner decision remains from this review. The open evidence question is whether the complete corrected exact-source native campaign and stable staging meet the existing gates; only those actual executions can resolve it. No merge, production, external posting or whole-AC acceptance is supplied.
