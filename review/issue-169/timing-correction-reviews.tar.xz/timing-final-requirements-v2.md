# Requirements & Acceptance — correction v2

**Verdict: no blocking requirements defect found in the unchanged five-path v2 prepared delta. Exact-source native timing/staging acceptance remains pending.** This is the same role's disclosed correction continuation, not a fresh independent launch. First result `timing-final-requirements.md` is preserved intact (SHA-256 `1b5a6c27738f40b9f7ac7c906a0b09f0c4587edb856597b33c2146188bf43577`). No peer results or new author conversation were read; the new packet and actual referenced sources/evidence were inspected. Provider model/context internals remain unknown; the orchestrator retains launch assurance separately.

## Identity and boundary

Issue169 / PR170; base `53102d7d55012d6bd954d7d4b248d75dc75e9600`; dirty prepared subset, not a clean native checkout. V2 packet SHA-256 `8cf598fea0c4907eae1f3e75834655cef7eea701529b66e4382012e008576a93`; diff SHA-256 `1491c1098faddd3936fb4998e954f040bdeb0534e44e1a1816536adbac121277`. All 15 source-file and nine raw-evidence digests matched; original-owner snapshot hash `0ab9ce6e03cd50f6360b780ba21d3f20c26d021584d4552102b9da8f3d7d8cf6` is the previously read authoritative dated original AC text. Common and role prompt hashes remain `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` / `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`.

All supplied source hashes still matched at final inspection. The actual **five reviewed paths** still produced the packet diff exactly. During review the wider worktree acquired four additional changed paths: `.github/repository-intelligence/agent-context.json`, `.github/repository-paths.json`, `.github/ri-ci-map.json`, `REPOSITORY-MAP.md`; whole-worktree diff became `a49d5603f03c9025b6ba9e67a6566915619e5b454988ed119746328a53004053`. Their contents were not inspected as part of this packet. This result does not accept those changes or a later complete candidate; reconcile their identities/applicable deterministic exemptions and checks before advancing. No implementation, tests or external services were changed by this reviewer; no delegation occurred.

## Four bounded functional cases

Actual source inspection: `helperContracts` uses the same configured venv interpreter and same helper file. Only nonempty arrays whose every row has `language === 'html'` get `['-S', helper]`; empty, mixed and non-HTML requests keep `[helper]`. The Python helper is byte-identical to the base and imports only standard-library modules for HTML; its lazy YAML import still follows normal startup. Error handling, row coverage, contracts/fingerprints and limits are unchanged. `compareSources` and the SEO normalizer still consume this same helper; no replacement parser or acceptance shortcut was added.

Four cases were independently executed using pinned Node `/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node` v24.19.0:

| Case / independent oracle | Observation |
| --- | --- |
| `HTML startup isolation preserves actual primary parser contracts and refusals`: compare optimized helper results with actual ordinary same-interpreter helper results for HTML events, mixed YAML+HTML and empty input; duplicate-attribute refusal matches exact ordinary error | Pass, 269.943821 ms |
| `primary parser diagnostics retain exact types and messages before and after YAML requests`: real parser diagnostic rows for HTML/JSON/Python/YAML, separately and mixed/reordered | Pass, 300.961860 ms; this unchanged test exercises ordinary helper diagnostics and complements the new optimized-path case |
| `HTML preserves wording, attributes, nonbreaking spaces and inline separator presence`: actual `compareSources` route must retain allowed formatting and reject changed links, separators, raw-text content, duplicates and unsupported HTML self-closing syntax | Pass, 432.258021 ms |
| `approved contact and decorative title reconciliation retain changed destinations and copy`: actual `tests/executive.test.cjs` → `check_site_seo.cjs` → shared helper integration over current generated pages must distinguish changed contact destinations/copy/title identity while permitting the approved ink wrapper | Pass, 10282.804731 ms |

Parser command selected the three names above with `--test-name-pattern='HTML startup isolation|primary parser diagnostics|HTML preserves wording' tests/format-parity.test.cjs`: 3 tests, 3 pass, 0 fail/cancelled/skipped/todo, total1107.219736 ms. Executive command used its exact test name: 1 test, 1 pass, 0 fail/cancelled/skipped/todo, total10391.827201 ms. These are bounded checks, not full-suite/native campaign acceptance.

## Requirement and acceptance linkage

| Requirement / AC | Check or owner gate | Assessment |
| --- | --- | --- |
| Original scope: reconcile PR170 through verified stable staging, inspect R10 article/PDF, STOP/show | Existing controller and native source/hosted/staging gates, followed by actual reader/PDF inspection | Helper startup correction is a bounded prerequisite optimization; original publication/content requirements and STOP limit are unchanged. PR170 merge and production remain outside current continuation. |
| AC05/11: exact-source review, truthful actual execution states and four distinct role results | Packet/source binding, affected review, full mapped checks and separate other-role results | This correction result covers supplied unchanged paths only. Other roles, new metadata delta and exact clean candidate remain separate gates. Whole ACs remain open. |
| Preserve parser meaning/refusals; no test/scanner/budget weakening | Same parser source, actual event/error equivalence, existing semantic mutation negatives and real consumer integration | Source and four cases above support the bounded preservation claim. No new oracle, reduced refusal or removed case found. `-S` removes site-package initialization only on the finite standard-library HTML path; it is not a scanner-rule exemption. |
| Preserve scheduling constraints and full selected suites | Same 75-member queue, original300s+30s grace/16MiB, four-worker isolation/cancellation and zero-skip native accounting | Scheduling/runner/test hashes unchanged from this role's first review; earlier source/invariant and four-case scheduling evidence reused only for those unchanged bytes. No fresh native timing pass inferred. |
| AC04/07/08/09/10: accepted R10 manuscript/PDF/figures, site-first copies and existing related-reading/Writing behavior | Native publisher/Basic/current-source checks, exact hosted desktop/mobile/no-JS, reader/PDF/copy/visual gates | Five-path delta has no `site/`, `docs/`, manuscript/PDF or distribution record edits. Preservation within this delta is observed; content/visual/hosted acceptance is not newly executed here. |

The existing registry already selects `tests/format-parity.test.cjs` and the direct `tests/executive.test.cjs` consumer from helper changes in permanent PR-targeted/staging/production routes. The added regression has an owned execution route. Relevant CS01/04/05/07/08/09/10 concerns remain existing owner placement, narrow mutation, preserved parser/toolchain boundaries and honest resource/evidence claims; native style/format/scanner checks remain required.

## Evidence limits and next gate

Raw native failure remains ETIMEDOUT with incomplete final accounting; it is not superseded by local passes. The supplied v2 observer records one successful executive case on Node24.19.0, 359 successful HTML parser calls /448 unique input rows, zero duplicate rows, parser time10788.186658 ms, total11565.333505 ms. This supports actual same-helper consumer observation and continued call cost. It does not establish comparative speed against a controlled full native baseline, completion under contention or all-suite success. The supplied parser log is10/10 in its own local scope; this reviewer independently ran only the four cases listed above.

The packet's retained phrase “Reorder only” is stale shorthand now that a helper invocation flag also changes; the explicit appended HTML-only clause and actual diff make the v2 scope clear. Final public review/commit wording should describe both changes. This is a metadata clarification, not a changed acceptance criterion or blocker to bounded verification.

No owner decision or weakened requirement is needed for this reversible correction. Preserve both review versions and all failures. Bind the final complete candidate (including the added metadata paths), complete applicable role/RI/style/owning/native checks and run full native staging with unchanged limits and complete accounting. Actual stable staging and R10 reader/PDF inspection remain pending; keep original whole ACs open except historicalAC06 and stop/show after the authorized verification work.
