# White-box QA — timing correction

**Verdict:** no blocking source/test defect found in the bounded scheduling-only correction. The four independently executed existing cases passed. This accepts the inspected structural correction for further exact-source native verification; it does **not** establish the corrected native 300-second deadline, stable staging, whole AC completion, PR170 merge or production authorization. The native timing/delivery gate remains pending.

## Execution identity and inputs

- Role/task: nonauthor White-box QA, `/root/timing_final_whitebox`; correction-phase inspection of the supplied candidate, with no previous role verdict read or reused.
- Owner: issue169 / PR170, repository `oborskyivitalii/oborskyivitalii`; supplied base `53102d7d55012d6bd954d7d4b248d75dc75e9600`. Candidate is a **prepared subset in a dirty checkout**, not a clean native checkout. Exact source is the packet's path/byte manifest.
- Packet: `timing-correction-packet.json`, SHA-256 `443920250fcb797b8cd8d7c9a2be945fba7c9ae28f26dc086a47d4739c3445e0`.
- Diff: `timing-correction.diff`, SHA-256 `be7cbadeb04bba9ef6120ea4561a828e74025e0f530d31e55382e2cdd8de212f`.
- Common contract: `agents/reviewers/README.md`, SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role prompt: `agents/reviewers/white-box-qa.md`, SHA-256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Worker: SHA-256 `490e22564920e7c7847ef5b581a9740e53e0f9b167c0214a9769a85bb32954fe`; source runner: `792aec87f4abb3aec8c97b4a8d33cd958a643b8f6c77aaac4c5683d45aaf5086`; profile suite: `7ab773d812c458eabdc2bc971fca185a5d7e3094fa7d9bd143bde07303faa894`.
- All13 packet source files, all6 raw evidence files and diff matched supplied hashes. Source manifest and diff matched again after checks.
- Additional supplied owner snapshot `issue169-current.md` matched SHA-256 `0ab9ce6e03cd50f6360b780ba21d3f20c26d021584d4552102b9da8f3d7d8cf6`. Its historical execution summaries were treated as historical claims, not current review verdicts or test oracles. Latest packet STOP scope controls.
- Read applicable root AGENTS, README, relevant repository map entries, CONTRIBUTING review/diagnosis rules, CODE-STYLE, profile owner, issue169 acceptance policy, registry row and immediate CI/prepublication consumers. No nested AGENTS was returned in the scoped tools/tests/guides/agents/.github inventory.
- No author private history, current peer results or unrelated memory were inspected; no implementation/tests/external services were changed and no delegation occurred. Requested/accepted launch parameters require the orchestrator's separate tool receipt. Provider model/context internals are unknown; this report does not attest platform isolation internals.

## Structural analysis and independent oracles

The change edits the priority list and two scheduling test expectations plus the profile explanation. Selection, accounting, runner limits, signal cleanup and process isolation are unchanged in the supplied diff. The priority array contains75unique paths and its set exactly equals the failed native staging report's75selected modules. The scheduler intersects that priority with the caller's selection and appends all other selected files lexically; it cannot add unselected priority entries. Duplicate caller entries reject before scheduling.

I compared the candidate ordering against raw `source-test-timing` completions from native run42309808371/attempt1. There are74completed file records, all successful wrappers, and no descending-duration inversion among their priority positions. The only dequeued but unfinished file is `tests/test-profile-selection.test.cjs`, started at290036ms. The supplied separate diagnostic completed in9152.964081ms, whose doubled value18305.928162ms fits its candidate position between reader-controller18412.137562ms and content-rendering17122.017975ms. This is an estimate from a different execution; it is not the missing native completion measurement. The later corrected profile report's9648.010732ms is a separate observation, not a reason to rewrite the recorded estimate.

The independent scheduling oracle is preserve the complete selected set and native case outcomes while launching measured long work first; unknown selected files follow by path. Exact order expectations were checked against primary duration records rather than accepted merely because they mirror the array. Serial process fixtures make the observed order deterministic; isolated-global assertions and actual TAP accounting test behavior beyond array text.

The protected resource/lifecycle invariants remain: `Math.min(4, parallelism)`, positive integer capacity, `isolation: 'process'`, one AbortController, SIGTERM/SIGINT abort with nonzero exit, stream error abort, missing summary/non-success failure, and signal-listener disposal on end/close. `source-tests.cjs` still enforces300000ms,16777216bytes,330000ms wrapper allowance, clean-source guards and strict single native summary requiring positive tests, all passing and zero failed/cancelled/skipped/TODO. Reading those branches is structural inspection, not measured branch coverage.

## Risk → scenario → oracle → check allocation

| Risk / AC | Structural fault and bounded scenario | Independent oracle | Existing case / outcome |
| --- | --- | --- | --- |
| AC05/11, CS07/08: order changes hide cases/failures | Reorder mixed priority/unknown files at capacity1; then assertion, uncaught, nonzero exit, skip, empty suite and empty execution inputs | Every selected file runs once in its own process; each meaningful failed/incomplete partition rejects | `source scheduling starts expensive files early with isolated processes and preserves failure accounting` at profile suite1167: executed, pass |
| AC05/11: lost selection or wrong measured order | Scrambled selected known paths including profile suite plus two unknown future paths | Measured duration precedence; both unknowns lexically after knowns; all11native leaves counted | `source scheduling starts measured long files early without losing selected assertions` at1673: executed, pass |
| AC05, CS07: resource cap or queued coverage regression | Five actual holding files, requested capacity64 | Four simultaneous owned files, fifth stays queued, all five eventually pass | `source scheduling caps simultaneous isolated files at four without dropping queued coverage` at1239: executed, pass |
| AC05, CS08: cancellation becomes green or leaks child | Complete one file, keep another child alive, interrupt worker separately with SIGTERM and SIGINT | Nonzero normal worker exit, child no longer alive, original partial TAP retained | `source scheduling cancels owned child processes and retains partial TAP on termination` at1302: executed, both subcases pass |
| AC05/09/10 delivery: missing native timing pass | Full75-file clean-source prepublication run under unchanged deadline | Actual exact-source native process completes within300s with full strict accounting; subsequent hosted/stable staging gates pass | Existing single-runner staging/prepublication route: **not observed for corrected candidate**, remains required |

These cases already belong to permanent `tests/test-profile-selection.test.cjs`, owned by `guides/SITE-CHECK-PROFILES.md`, registered for PR-targeted/staging/production and directly targeted by changes to this suite, source runner and worker. No new suite/diagnostic/registry route is needed. The ordinary `.github/workflows/site-checks.yml` `source_shards` jobs run selected partitions; `checks` aggregates all receipts. The native full prepublication source route is separate: `.github/workflows/site-release-checks.yml` build/source-check step runs `local.cjs --prepublication`, and the supplied failed raw report proves the full staging single-runner surface is relevant. Passing shard/fixture checks cannot substitute for that failed surface. No browser/UI change exists in this delta; article/PDF/related-reading visual acceptance remains outside this correction review, not waived.

## Actual bounded execution and raw result

Working directory: `/workspace/scratch/b15f3a872203/repo`. Pinned binary reported `v24.19.0`. Four named existing cases were executed, with their existing internal negative partitions and signal subcases; no full-suite retry or duration simulation was performed.

```text
/home/agent/.npm/_npx/09ae5d3560c7b1f2/node_modules/node/bin/node --test --test-reporter=tap --test-name-pattern='^source scheduling (starts expensive files early with isolated processes and preserves failure accounting|starts measured long files early without losing selected assertions|caps simultaneous isolated files at four without dropping queued coverage|cancels owned child processes and retains partial TAP on termination)$' tests/test-profile-selection.test.cjs
```

Tool command returned exit0, no signal or stderr. Complete TAP:

```tap
TAP version 13
# Subtest: source scheduling starts expensive files early with isolated processes and preserves failure accounting
ok 1 - source scheduling starts expensive files early with isolated processes and preserves failure accounting
  ---
  duration_ms: 1364.28826
  type: 'test'
  ...
# Subtest: source scheduling caps simultaneous isolated files at four without dropping queued coverage
ok 2 - source scheduling caps simultaneous isolated files at four without dropping queued coverage
  ---
  duration_ms: 337.78447
  type: 'test'
  ...
# Subtest: source scheduling cancels owned child processes and retains partial TAP on termination
    # Subtest: SIGTERM
    ok 1 - SIGTERM
      ---
      duration_ms: 151.844193
      type: 'test'
      ...
    # Subtest: SIGINT
    ok 2 - SIGINT
      ---
      duration_ms: 149.278152
      type: 'test'
      ...
    1..2
ok 3 - source scheduling cancels owned child processes and retains partial TAP on termination
  ---
  duration_ms: 301.99018
  type: 'test'
  ...
# Subtest: source scheduling starts measured long files early without losing selected assertions
ok 4 - source scheduling starts measured long files early without losing selected assertions
  ---
  duration_ms: 842.321503
  type: 'test'
  ...
1..4
# tests 6
# suites 0
# pass 6
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 2938.790008
```

Supplied historical evidence was inspected, not rerun: native failed report retains ETIMEDOUT at300000ms, source/tree `53102d7…`/`f07f15d…`, zero complete summary arrays and pass=false; diagnostic profile48/48; first correction47/48 failing the stale order expectation; corrected profile48/48 zero failed/cancelled/skipped/TODO. The stale expectation failure matches the actual reordered sequence and was corrected without weakening failure/accounting assertions. These records do not establish a corrected native deadline pass.

## Findings and limits

No new blocking source finding. Examined risks: membership preservation, duplicate priority entries, duration oracle, lexical unknown fallback, isolated globals, actual worker overlap/cap, queued completion, fail/skip/empty rejection, both termination signals, partial evidence and unchanged limits/accounting integration.

**Open acceptance gate, not waived:** corrected exact-source native prepublication completion and stable staging are unobserved. AC05/11 and delivery-dependent AC09/10 remain open to their wider required evidence. Retain the native failure; next bounded native campaign must use the exact final candidate and unchanged budgets, then inspect complete source-bound raw report/accounting. Do not describe fixture/simulation success as native timing acceptance.

No measured branch/statement coverage is claimed. Invalid path/capacity, output overflow, report-write errors, source mutation, reporter error and clean native checkout were not independently re-executed in this four-case campaign. Their unchanged source and the packet's bounded existing report evidence were inspected where relevant; absence of new execution is a limit. No article/PDF/browser/hosted surface was exercised. Final relevant source hashes still match the packet.
