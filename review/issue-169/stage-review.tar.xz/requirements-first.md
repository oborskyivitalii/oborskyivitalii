# Requirements & Acceptance — first preimplementation judgment

Owner: issue169 / PR170. Phase: bounded failure diagnosis, before dependent edits.
Candidate inspected: `9513dbecc1caee39eebb94910c105ee0675e6bb8`, tree
`39efdca0c5cfe46aae5cebacb2cda1c9302f5a80`; supplied main
`8cf15883125892710633b17133d9ee0fc4b23b92`. Local HEAD/tree match and working
tree was clean. Packet SHA256:
`3e72d92414e20e96f408e77851a2b39d43f6ee9d76b263d338f48690c42200af`.
All18 source-manifest entries and all3 evidence-manifest entries matched.

## Verdict and authority

**Advancement is blocked by the reproduced current assertion failure and the
separate unresolved historical staging timeout.** A bounded correction to the
historical test's cohort selection is justified by the inspected source. Changing
the expected number to five alone is insufficient: it changes which negative
controls execute. No production, merge, publication or acceptance waiver follows
from author preview acceptance.

The supplied current instruction authorizes required checks, stable staging and
then STOP/show. The issue's historical website-production authorization remains
history; this increment stops at verified stable staging. Preserve R10 article,
PDF/media, current DevCon completion and Writing behavior. Whole issue criteria
remain open where their later delivery/manual conditions remain pending.

## Findings

### RA1 — High: stale historical cohort and positional negative controls

Evidence: `tests/executive.test.cjs:953–1011`; canonical event change in
`site/content/events.json:96`; exact CI42220631455 / shard6 / job127901491511,
`shard-6-job.log:370–388`.

The test selects every non-Upcoming card and asserts four. DevCon is now correctly
in `other-talks`, so this selector returns five. Current order is PMDay Autumn,
DevCon, Corning, Betelgeuse, swarchua. The original historical order was PMDay
Autumn, Corning, Betelgeuse, swarchua. Thus merely accepting five makes
`cards[1]` deletion target DevCon instead of Corning; `cards[3]` deletion,
substitution and language mutation target Betelgeuse instead of swarchua;
`cards[3] -> cards[2]` changes the original replacement pair. Existing meaningful
mutation assertions do not establish preservation of those original scenarios.
The failed count currently prevents these controls from running at all.

Affected obligation: AC05/11 exact-source checks and review, CONTRIBUTING's
preservation of scenarios/refusals, plus the existing test's own promise to retain
historical event/source/date/language/resource rejection.

Smallest justified treatment: explicitly identify the four retained historical
events and bind the existing mutation cases to those identities. Assert the exact
historical cohort and preserve every original mutation target and replacement
pair; do not derive the independent expected cohort solely from the same mutable
catalog being checked. Keep the current complete inventory/current DevCon contract
separate. Existing `tests/content.test.cjs:1147–1209` already asserts six total
events, DevCon's completed placement/date/title/programme, absence of invented
resources, unchanged previous cards and actual date/copy/programme/resource
refusals. Reuse that maintained check rather than inventing a new suite. A changed
test/oracle requires fresh affected review and current-source acceptance.

No authored event or generated Talks HTML change is supported by this failure.

### RA2 — High: current assertion correction cannot resolve the old staging timeout

Evidence: retained `old-stage/prepublication-source-tests-runner.json` and TAP;
original staging42207436828 / build127857788068. That runner used clean source
`d5e915feb3ba02d7a80325664c9d1d10a2ac494e`, tree
`33c68e13bc7c8c78acb9abc2cf61066977de1284`, selected75 modules, four workers,
300000ms deadline and16777216-byte output cap. It reports status1,
`ETIMEDOUT`, `pass:false`, and empty final observed-accounting arrays. This is a
different source/run and failure mechanism from the current complete assertion
failure. Emitted individual TAP passes are partial output, not completed source
acceptance.

Affected obligation: AC05/11 and DELIVERY, plus SITE-CHECK-PROFILES' complete
prepublication guards before upload and SITE-STAGING's current successful raw-head
admission before stable staging.

Smallest justified treatment: retain this failed attempt; continue bounded
diagnosis from retained timings/profile/raw evidence before another staging
campaign. A1.67s isolated rights-inventory pass establishes only that case's local
result; it neither identifies the aggregate hosted bottleneck nor demonstrates
that the complete staging workload fits300s. This review establishes no evidenced
performance fix. Any proposed optimization must name the measured hotspot, its
mechanism, a bounded comparison and preserved scenario/accounting checks before
implementation. Do not replace full staging evidence with PR shards, extend
deadlines/workers, delete refusals or broaden scanner/ledger exceptions.

## Traceability and actual observations

| Intent / AC | Check or owner gate | Observed result and limit |
| --- | --- | --- |
| Preserve accepted preview/current content; AC07–10 | Canonical events + generated Talks + existing completed-DevCon test | Source inspected; targeted DevCon check passed1/1. Article/PDF/media and browser surfaces not reaccepted by this review. |
| AC05/11, historical negative controls | `timeout 60s node --test --test-name-pattern='^Talks reconciliation rejects' tests/executive.test.cjs` | Reproduced current failure1/1,5 versus4, about1.05s; exit1, no skipped/cancelled/TODO tests. No failed full campaign was rerun. |
| Preserve completed DevCon independent contract | `timeout 60s node --test --test-name-pattern='^completed DevCon talk belongs' tests/content.test.cjs` | Passed1/1, about1.80s; exit0, no skips/cancellations/TODOs. Includes meaningful current-data refusal cases. |
| AC05/11 and DELIVERY | Original full staging source report | Failed timeout on older exact source; final native accounting incomplete. Remains unresolved. |
| Stable staging, current increment | Successful current Basic/source/RI/owning admission; reviewed correction; authenticated original prepublication/security/advisory/host/browser gate and stable-alias verification | Not established by this preflight. Current shard failure blocks advancement. |
| AC04/09 distribution and production | Exact served edition, later author-manual external copies and publication gates | Beyond current STOP-at-staging instruction; not claimed performed or waived. |

The owner source was read directly from `owner-169.json` (dated update2026-11-06),
including original AC IDs and dated amendments. `.github/acceptance/issue-169.json`
and `review/issue-169/native-check-allocation.md` preserve the distinction between
RI/style evidence and native/hosted/human acceptance. No new owner decision is
necessary to preserve the accepted event meaning or repair the test selection.

## Isolation, limits and next gate

Distinct nonauthor first review requested; no implementation/tests authored here.
Only supplied sources, necessary authoritative owners, actual diff and raw failure
evidence were read. No MEMORY, private history, parent notes or peer outputs were
read; no external writes or delegation occurred. The task was accepted and executed
as this role. The actual spawn request/accepted `fork_turns` tool receipt is not
visible within this reviewer session and must be retained by the orchestrator;
this report does not fabricate it. Provider memory/context injection internals
remain unknown. Shared tools/filesystem are not a security sandbox. Acceptance of
the isolation admission requirement remains conditional on the actual explicit
none-fork/equivalent launch receipt.

Read AGENTS, README, scoped CONTRIBUTING failure/independent-review protocol,
reviewer contract/role, repository-map routes, check/staging owners, current
acceptance allocation, canonical events, historical/current tests and SEO event
restoration. All bounded executions were under60s. This is requirements preflight,
not completed four-role review, browser inspection, full-suite pass or release
readiness. No unaffected article/editorial/rights decisions were reopened.

Next gate: author repairs only the justified cohort/identity test defect, obtains
affected independent review, verifies retained negative-control meanings and the
current DevCon case, then completes required exact-source checks. Resolve the
separate staged-source timeout with an evidenced diagnostic/fix before a new
staging attempt; authenticate complete stable-staging evidence and STOP as directed.
