# White-box QA — prepared two-file candidate

2026-11-06. First independent result by `/root/stage_final_whitebox`, distinct nonauthor White-box QA reviewer. **No blocking candidate defect found in the bounded changed scope.** This is targeted test assurance, not full-suite/staging acceptance. The previous full staging-source timeout remains unresolved pending a complete current-source run with final accounting. No merge or production authorization is supplied by this review.

## Identity, inputs and isolation

- Repository `/workspace/scratch/f4dcb060a703/repo`; inspected HEAD/base `9513dbecc1caee39eebb94910c105ee0675e6bb8`, base tree `39efdca0c5cfe46aae5cebacb2cda1c9302f5a80`. Working tree was dirty in exactly `tests/executive.test.cjs` and `tests/release-rights.test.cjs`: 23 insertions, 12 deletions. This is a prepared candidate, not a clean checkout.
- Packet `/workspace/scratch/f4dcb060a703/stage-diagnostics/candidate-packet.json`, SHA-256 `d74bf2abddc59f417f322f316938f823474b3f94ca0fb692cabb616d3ebf4b9c`; diff SHA-256 `0e517b718c51f42636450ec48d1d9e68532a8b3c3c58c60c21585d7365c6475b`. All 13 packet source-manifest entries were recomputed and matched. Candidate test hashes were rechecked after execution and matched.
- `tests/executive.test.cjs`: `b235b4cc435e55a34494b35af10167e2cfb910a9b93affc294140083371cf746`; `tests/release-rights.test.cjs`: `d9ed3d9463564e61a4e0a435618fcf5565b2165d7a78a9ab3e49d62083c7ec81`.
- Common prompt `agents/reviewers/README.md`: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/white-box-qa.md`: `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Owner issue snapshot `/workspace/scratch/f4dcb060a703/stage-diagnostics/owner-169.json`: `cfafbd80467e70d13fbd746c8d82b537240fdcf253810287614e5efa5f10d14a`. Read actual issue body/ACs, README, root AGENTS, relevant CONTRIBUTING protocol, reviewer prompts, style/check-profile owners and registry, complete candidate diff and affected actual sources. No nested `tests/**/AGENTS.md` was found. Repository-map read was overlarge/truncated; relevant paths were subsequently read directly through verified test/registry owners.
- Scope is issue169/PR170, accepted preview → required checks → stable staging → STOP/show; no merge/production. AC05/AC11 apply to source-bound checks/reviews. Earlier broad website publication instructions in the issue do not enlarge this review's narrower execution authorization.
- No author implementation/conversation or peer verdicts were used. No MEMORY, parent notes, private history or peer output contents were read. Directory inventory exposed peer output filenames only. Permitted factual raw TAP evidence was inspected after the actual independent tests.
- Actual spawn `fork_turns`/accepted runner parameters are not visible from this child transcript; orchestrator must attach its actual launch receipt before admitting this review. No claim of provider memory isolation or model/context internals is made; those internals are unknown. Shared filesystem/instructions/tools remain shared. This report alone cannot attest the launch parameter.

## Risk → structure → scenario → independent oracle → route

| Risk / requirement | Structural fault and scenario | Independent oracle | Existing check / allocation |
| --- | --- | --- | --- |
| AC05: historical Talks checks accidentally target newly completed DevCon | Positional selection shifts when DevCon moves out of Upcoming; missing/duplicated historical identity | Exactly five completed cards; one match for each of four historical URL/anchor identities; history reverses to frozen accepted amendment bytes | Complete selected Talks reconciliation test; executive suite, permanent, pr-targeted/staging/production |
| AC05: weakened failure detection | Missing/substituted card, source/date/resource/language/claim edits, metadata substitution | Change must remain different from original restored result or be rejected by canonical event collection guard; each mutation must change actual input | Same test retains all 17 mutation pairs and historical amendment integrity assertions |
| AC05: completed DevCon lost or reclassified | Date/past-tense/source/slides alterations; card ordering/inventory | Six total events; exact completed card; previous five cards match baseline in order; four semantic mutations throw | Complete selected completed-DevCon test; content suite, same profiles |
| AC05: rights membership comparison changes meaning | Empty/missing assets, duplicates, overlapping/current and retained-only resources | For string path keys, absence from any route assets equals absence from union Set; actual inventory remains exact; no approval granted | Selected actual rights inventory test plus four bounded independent equivalence partitions; release-rights suite, same profiles |
| AC05/11: partial execution mistaken for acceptance | Previous staging timeout / targeted success reported as campaign success | Complete final campaign accounting bound to actual source required | Targeted results here only; full current source/staging remains orchestrator gate |

All three existing suites are registered in `tools/quality/test-profiles.json`, retain `guides/SITE-CHECK-PROFILES.md` ownership and their source-tests profile route. No new test suite or CI route is proposed. There is no changed runtime/UI surface, so browser/device testing is not applicable to this two-file delta; existing website delivery gates remain intact.

## Actual commands and raw accounting

Each executed test command had a 60-second process bound. No full suite or browser matrix was run.

```text
$ timeout 60s node --test --test-name-pattern='Talks reconciliation rejects missing events, substituted sources and invented dates or resources' tests/executive.test.cjs
✔ Talks reconciliation rejects missing events, substituted sources and invented dates or resources (3405.83152ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 3531.547484
exit 0; tool chunk ac5240

$ timeout 60s node --test --test-name-pattern='completed DevCon talk belongs with past events and preserves previous public facts' tests/content.test.cjs
✔ completed DevCon talk belongs with past events and preserves previous public facts (1562.759091ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1952.948258
exit 0; tool chunk c96b8f

$ timeout 60s node --test --test-name-pattern='rights inventory covers actual current and retained bytes without granting approval' tests/release-rights.test.cjs
✔ rights inventory covers actual current and retained bytes without granting approval (937.295103ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1098.738417
exit 0; tool chunk f86da7
```

Independent negative probe, retained honestly: my first custom diagnostic imposed a stronger oracle than the actual accepted contract, expecting description tampering to throw the event-section error. It produced `AssertionError [ERR_ASSERTION]: Missing expected exception` at stdin:8 on Node v24.22.1 (chunk f56896). The Node probe exited 1; the enclosing multi-command shell reported 0 because later source-inspection commands succeeded. No source was changed, no candidate defect inferred, and the subsequent partition loop in that first probe did not execute. Diagnosis from actual test/guard source: the event guard validates the Talks section; description changes may remain visible rather than throw. The existing test explicitly admits either outcome. The next diagnostic changed the assertion to the actual protected invariant, not the candidate or oracle contract.

The complete corrected bounded probe (chunk d7dee0, exit0, 1.581s tool wall time) was:

```javascript
const fs=require('node:fs'),assert=require('node:assert/strict');
const seo=require('./tools/check_site_seo.cjs');
const html=seo.normalizeHTML(fs.readFileSync('docs/talks.html','utf8'));
const description=[...html.matchAll(/<meta name="description"[^>]*>/g)];
assert.equal(description.length,1);
const mutation='<meta name="description" content="including invented events">';
const restored=seo.restore(html.replace(description[0][0],mutation),'talks');
assert.notEqual(restored,seo.restore(html,'talks'));
assert.ok(restored.includes(mutation));
console.log('PASS metadata: invented actual current description remains visible and cannot equal frozen comparison; 2 assertions');
for(const routes of [{}, {a:{}}, {a:{assets:[]}}, {a:{assets:['x','x']},b:{assets:['y']}}]) {
 const retained=['x','y','z'];
 const old=retained.filter(name=>!Object.values(routes).some(route=>(route.assets||[]).includes(name)));
 const current=new Set(Object.values(routes).flatMap(route=>route.assets||[]));
 assert.deepEqual(retained.filter(name=>!current.has(name)),old);
}
console.log('PASS rights-equivalence: 4 route partitions; empty routes, missing/empty assets, duplicate and overlapping assets, current and retained-only names');
```

Executed as `timeout 60s node - <<'JS' ... JS`. Both PASS lines appeared. Four equivalence partitions passed. The unique-current-description count, differing restored output and mutation preservation all passed. This proves refusal of equivalence to the accepted comparison, not a thrown exception for head metadata.

## Structural conclusions and limits

`tests/executive.test.cjs:955–1012` binds historical fixtures by four stable existing identities and selects the live unique description, while keeping five completed cards as an explicit current inventory. Existing missing-card, substituted-source, invented date/resource, recording/title/language/claim mutations remain meaningful and passed. The complete historical restoration/assertion tail also ran. Current DevCon integration is separately checked against the accepted previous page and current event facts.

`tests/release-rights.test.cjs:181–196` hoists snapshot verification and computes a union once. For validated arrays of string asset paths, Set membership is equivalent to the old existential array membership predicate, including duplicate paths. The fixture does not mutate its source/output between these computations. Actual test confirms inventory/retained identity, linked counts, publication sources and `approvalPass === false`; production/rights authority is unchanged. No measured speedup, branch-coverage percentage or full rights-suite pass is claimed.

No blocking finding in these changed test paths. Remaining gates: actual fork/launch receipt admission; complete current-source campaign with final accounting; required other role results and full authorized staging/controller checks. Old staging timeout is not explained or erased by these bounded passes. Retained prior TAP passes were inspected, but are supplementary evidence, not substitutes for the independent executions above. Only this assigned report was intentionally written; no implementation, external write or delegation occurred.
