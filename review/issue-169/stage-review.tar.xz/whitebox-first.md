# White-box QA — first independent diagnostic result

Date: 2026-11-06. Reviewer task: `/root/stage_whitebox`, distinct nonauthor. Scope: issue169 / PR170 preimplementation failure diagnosis only. Verdict: **blocked for staging; a narrow test-oracle correction is justified, while the old full-source timeout remains unresolved on the current candidate.** No implementation or tests were changed, no external write occurred, no delegation occurred. Only this assigned report was written.

## Identity and isolation

- Inspected checkout HEAD `9513dbecc1caee39eebb94910c105ee0675e6bb8`, tree `39efdca0c5cfe46aae5cebacb2cda1c9302f5a80`, local main `8cf15883125892710633b17133d9ee0fc4b23b92`; working tree clean before/after checks. Local refs were read. Live GitHub state was not independently fetched by this role; hosted facts below come from supplied raw logs.
- Packet `/workspace/scratch/f4dcb060a703/stage-diagnostics/preflight.json`, SHA256 `3e72d92414e20e96f408e77851a2b39d43f6ee9d76b263d338f48690c42200af`; all listed source and evidence hashes matched bytes read. Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; White-box prompt SHA256 `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.
- Read AGENTS, README, relevant REPOSITORY-MAP entries, CONTRIBUTING failure-diagnosis/reviewer protocol, common/role prompts, owner169 primary issue packet, current executive test and SEO/event source, rights tests/fixture/inventory helper, source-runner owners and source-profile routes. No nested AGENTS were found by the repository inventory.
- No MEMORY, private history, parent scratch notes or peer result files were read. Parent supplied additional neutral raw-profile locations and timings during execution; those files were independently inspected. The packet's failure descriptions were treated as claims requiring raw-source verification.
- The assignment requests distinct nonauthor execution; this role cannot attest the parent's actual spawn call parameters or accepted tool response. The visible task context does not contain the author's working conversation. Shared platform/project instructions and shared filesystem remain visible; provider memory/history injection, actual model/context internals and OS isolation are unknown. This is an operational reading boundary, not a security sandbox or provider attestation.

## Findings

**High — current required source check is blocked by a stale Talks oracle, and changing only the count loses historical mutation coverage.** `tests/executive.test.cjs:958` expects four non-Upcoming cards. Current generated Talks has five, matching `site/content/events.json`: PMDay, DevCon, Corning, Betelgeuse, swarchua. Raw current shard6 job `127901491511`, run `42220631455`, records expected4/actual5 and failure at this assertion on pinned HEAD. The failure occurs before its mutation loop, so the loop was not executed by that test in this hosted run. No runtime content defect is established by this count failure.

The positional targets at lines961–972 drifted when DevCon joined the completed list: `cards[3]` now means Betelgeuse, formerly swarchua; `cards[1]` now means DevCon, formerly Corning; `cards[2]` now means Corning, formerly Betelgeuse. Thus count4→5 alone silently changes deletion, substitution and invented-language scenarios. Retain the original four targets with unique stable event links/IDs and assert their unique presence; independently acknowledge DevCon as the fifth completed event. Keep all original mutation cases and their meaningful-input assertions. Do not exclude DevCon from canonical current-output verification. A new DevCon-specific omission/source/date guard is useful if not already equivalent in `events.test.cjs`; this role did not execute that suite. PMDay and DevCon share a title, so title alone is an ambiguous selector.

This affects AC05 source-bound checks/repository hygiene and AC11 completed independent verification, plus the packet's no-scenario-loss invariant. It requires a correction reviewed on its new source identity before advancement.

**Medium — a measured redundant rights-test calculation is a valid small optimization target, not a demonstrated cure for staging.** `tests/release-rights.test.cjs:183–195` invokes `source.record()` (complete public manifest) and `snapshot.verify()` inside a filter over every retained entry. The public fixture is unchanged during this comparison. Compute that record/revision and its active route asset set once locally for this assertion, retaining the same complete retained-name comparison. Avoid broader fixture caching across mutations: `source.record()` deliberately re-reads actual public bytes, and later tests mutate source/public data. Preserve all omission, changed-source, changed-public-byte, stale-report, edition and approval-negative cases. This is a supported local cost reduction under CS01/04/05/07/08/09/10; its impact on the full hosted deadline must be measured before any full-staging claim.

The independently read inventory profile samples total1613.413ms, with self time hash305.144ms, read132.144ms, zlib127.228ms, snapshot.verify83.406ms. These observations support reducing repeated reads/hash/verification in that one case. They do not attribute the old202135.569ms whole rights-suite duration to this one loop.

**Open diagnostic — current native publication CLI case spends time in child processes; parent profiling cannot locate the child hotspot.** `tests/release-rights.test.cjs:870` runs real build/artifact/Color/staging-or-production/rights/package-gate/package commands, and missing/stale/wrong-source negatives, with original30s per child. Its current supplied raw result is1/1 pass, zero failures/cancellation/skips/TODO,41692.428ms total. Parent-process CPU sample is41625.950ms, of which41073.472ms is `spawnSync`; that is waiting attributed to the parent frame, not proof the children are CPU-bound, stuck or redundant. Proposed next information gain: per-child walltime/status instrumentation around this same retained sequence, then a CPU profile of only the slowest supported child under the original timeout. Do not skip native R10/media/PDF preparation or replace the package integration with mocks to obtain a pass. No child-level run was performed by this role within its bound.

## Old staging evidence remains separate

Original full staging run42207436828 / build127857788068 / artifact13498231842 is bound to source `d5e915feb3ba02d7a80325664c9d1d10a2ac494e`, tree `33c68e13bc7c8c78acb9abc2cf61066977de1284`, clean before/after. Its `prepublication-source-tests-runner.json` says profile staging,75 selected modules, status failed/passfalse, child status1, signalnull, `spawnSync ... ETIMEDOUT`, original timeout300000ms, buffer16777216, stdout153289bytes, stderr17116bytes. The JSON's observedAccounting arrays are empty; no complete accounting is present.

Raw TAP has606 observed `ok` lines, no observed `not ok`, and **no final plan or tests/pass/fail/cancelled/skipped/TODO summary**. These are partial observations, not606 accepted passes or complete coverage. The timing string inside the error is truncated mid-record after elapsed266049ms: only27 complete timing records parse from it. Those are a lower bound, not the complete number of completed modules. Reported capacity was Node24.19.0, four available/configured workers, concurrency4. Among complete records: rights202135.569ms, controller129319.436ms, executive114520.836ms, Space101922.544ms, Pages delivery82846.337ms. The executive wrapper passed in that old source run. Current shard6 instead has thirteen module wrappers, executive58470.214ms false and twelve other complete wrappers true. Its assertion failure is distinct from the previous full-run timeout.

Current worker source still caps concurrent isolated file processes at four; source runner retains300000ms and16MiB. There is no evidence here that removing cases, increasing workers/timeouts, changing scanner gates or weakening source/artifact binding is needed. Current PR shards alone cannot establish full staging source completion or security/advisory/hosted acceptance.

## Compact risk-to-check map

| Risk / requirement | Structural fault and scenario | Independent oracle | Existing/proposed route and observed state |
| --- | --- | --- | --- |
| AC05/11; historical scenario preservation | New completed event shifts card indexes | Original four distinct event sources remain uniquely selected; five current completed cards; each intended mutation remains meaningful and rejected | `executive.test.cjs`, source registry → required PR shards and staging source. Current hosted test fails before mutations; seven small memory-only probes below detect mutations. Correction not authored/executed here. |
| Rights retained closure | Per-entry recomputation on unchanged bytes; omission/source/public-byte edits | Same full retained-name set after subtracting current route assets; all original negatives preserved | `release-rights.test.cjs` staging/production permanent suite. Supplied current inventory case1/1 passes. Hoisting is proposed only; before/after comparison needed. |
| Actual publication pipeline and refusal boundaries | Slow child CLI, stale/missing/wrong-source package records | Both actual editions freeze sidecars before upload; exact source/tree/artifact/rights; negative child statuses remain nonzero | Existing native CLI case in release-rights, supplied current1/1 passes41.69s. Child attribution unobserved. |
| Complete required staging | Partial TAP/timeouts mistaken for success | Full exact-source75/current-registry module accounting, zero failed/cancelled/skipped/TODO, original limits and all staging reports | Retained old staging fails; no unchanged campaign rerun. New full staging remains blocked pending diagnosis/correction and required current-source checks. |

## Actual execution and raw accounting

All role-run executable diagnostics were bounded with `timeout 60s`; neither ran a full suite. Read-only shell inspections returned normally except `rg --files -g AGENTS.md` under selected subdirectories found no nested match (exit1), and one `ls` included a nonexistent optional writing-review/cpu path (exit2). These are inventory misses, not failed tests. Some broad read output was truncated by the output budget; numerical conclusions above use later focused extraction from original bytes.

1. Memory-only Node diagnostic read current Talks, called `seo.restore`, printed ordered card identities, and exercised five current positional mutations plus explicit swarchua and Corning removal. Exit0, no signal; measured internal1377.818ms / tool wall1.366s. Full assertion error messages made its tool output long; the following distinct concise check added unique-selector assertions and a DevCon removal while printing only exception headings.
2. Exact concise diagnostic command:

```js
// Shell: timeout 60s node - <<'JS'  (cwd: pinned repository)
const fs=require('fs'),seo=require('./tools/check_site_seo.cjs');
const html=fs.readFileSync('docs/talks.html','utf8');
const cards=[...html.matchAll(/<article class="publication"[\s\S]*?<\/article>/g)].map(r=>r[0]).filter(c=>!c.includes('<span>Upcoming</span>'));
const needles=['xSgWjuGqC9I','devcon-romania-2026','id="corning"','activity-7477275989761384448-k8J9','1MPsDi3wuF4'];
const chosen=needles.map(n=>{const found=cards.filter(c=>c.includes(n));if(found.length!==1)throw Error('nonunique '+n);return found[0]});
const baseline=seo.restore(html,'talks');
const probes=[['positional remove3',cards[3],''],['positional remove1',cards[1],''],['positional substitute3with2',cards[3],cards[2]],['positional language3',cards[3],cards[3].replace('<article class="publication"','<article class="publication" data-language="en"')],['explicit swarchua removal',chosen[4],''],['explicit Corning removal',chosen[2],''],['explicit DevCon removal',chosen[1],'']];
for(const [label,from,to] of probes){if(from===to)throw Error('vacuous '+label);let result;try{result=seo.restore(html.replace(from,to),'talks')===baseline?'MISSED':'visible'}catch(e){result=e.message.split('\n')[0]}console.log(label+': '+result)}console.log('completed7; no files changed; node '+process.version);
```

Raw result: all seven lines ended `event output differs from validated canonical data`; footer `completed7; no files changed; node v24.22.1`. Exit0, no signal, tool wall1.301s. Five unique selector checks and seven meaningful mutation probes completed. This custom diagnostic is not native test-runner coverage/accounting and does not execute the complete original17-mutation loop.

Supplied raw profile evidence independently inspected, not executed by this role:

- `rights-inventory-profile.tap` SHA256 `11a686c6d35803b7e8a08ddf238f075af5f7bb767a5ff521c4de9004deb5e5d2`: tests1/pass1/fail0/cancelled0/skipped0/todo0,1666.746ms. CPU SHA256 `8375090529489cb027acd7d92f0b43e5a9fea99bac0dfaf60af1fcba5659164a`.
- `rights-cli-profile.tap` SHA256 `3f6ea2b8510dd6a48a21023a06b76e93c169d23d75006740523631f43194dd58`: tests1/pass1/fail0/cancelled0/skipped0/todo0,41692.428ms. CPU SHA256 `90337c29582670d001a1a7d39ee0f6bf53b8775f530ca8db67c548b4400ff4b4`.
- Current shard raw log SHA256 `34d0c565f4cb614a6dd76b06b59c5296b713409384ab978a2fbb9301fffcdb65`. This role did not inspect the current shard's uploaded full TAP/JSON, so complete test-case counts are unobserved.

## Minimal useful validation after correction

Run the corrected single Talks reconciliation case first under a60s diagnostic bound: verify all17 retained mutation entries remain meaningful, exact historical targets, canonical current five-card output, and original historical restoration checks. Run affected event/SEO checks through their existing registry selection; then required current-source shards/Basic/RI/owner checks. For the rights loop correction, compare the exact current inventory case before/after on identical source/public input, retain its complete zero-skip accounting and full rights negative suite; do not infer a hosted timing guarantee from the local speedup. Diagnose child CLI timing before choosing a broader performance patch. Only after an evidenced correction and independent correction review should the authorized original stable-staging controller run with unchanged cases/limits and exact source/tree/package/rights/scanner/host binding. Stop after showing stable staging; no merge or production authority is supplied by this report.

No branch/line coverage percentage, browser/device behavior, child-process CPU hotspot, complete current staging success or release acceptance was measured. Each executable diagnostic was below60s; a continuous end-to-end role wall-clock timer was not captured, so no measured total-duration claim is made.
