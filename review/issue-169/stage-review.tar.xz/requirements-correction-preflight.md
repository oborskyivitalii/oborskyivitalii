# Requirements correction preflight — continuation

Owner issue169 / PR170. This is a continuation of `requirements-first.md`, with
the parent's proposed treatment supplied as an explicit review subject after the
first judgment. It is not a fresh-context review of the eventual candidate.
HEAD remains9513dbe; inspected dirty diff changes only
`tests/executive.test.cjs` historical-card selection. No implementation was
authored during this review.

**The proposed current-description mutation is semantically justified.** It must
select exactly one actual ordinary description meta element and retain the same
invented-events replacement and visibility/refusal oracle. Historical snapshot
bytes should remain historical comparison inputs, not be inserted into current
HTML to make a mutation target exist.

## Observed correction and new failure

The actual diff preserves five completed cards and identifies the original four
historical targets using the PMDay recording URL, Corning anchor, Betelgeuse
follow-up URL and swarchua recording URL, each requiring exactly one match. Their
ordered identities preserve the original deletion, substitution and language
targets. This resolves the positional-drift objection in the first report; it
does not establish that the whole test passes.

Retained `talks-fixed.tap` reports one failed targeted test at the existing
`mutation input exists` guard, about1.53s. The historical issue126
`name="description"` amendment's `.after` describes *upcoming DevCon*, whereas
`docs/talks.html:6` now carries the approved earlier description. An independent
read-only check found exactly one current ordinary description meta element;
normalizing its bytes gives exact equality with issue126 `.before`, not `.after`.
The `.after` bytes are absent. This supports a stale mutation input, not a need to
change the legitimate current metadata.

The same check replaced the actual current meta element in memory with
`<meta name="description" content="including invented events">` and observed:

- the HTML changed;
- `restore(mutated, 'talks') !== restore(original, 'talks')` remained true.

This directly exercises the original negative-control meaning: invented event
metadata cannot disappear through approved restoration. It supplies no full-suite
acceptance and wrote no candidate file.

## Required treatment boundaries

Select the unique ordinary `name="description"` meta element from current HTML,
assert its existence and uniqueness, then use its complete actual bytes as the
mutation input. Keep the existing invented-events replacement, meaningful-change
guard, and restoration visibility/refusal assertion. Do not replace this with a
presence-only test, permit zero/ambiguous matches, remove the case, or accept a
generic restore error. The historical amendment's own integrity/hash/reversal
checks remain separate and unchanged. Current-description copy correctness is
already constrained by the maintained source/output/SEO owners; this mutation is
about refusing an unsupported alteration, so selecting its current input does not
make its refusal oracle circular.

After implementation, run the complete targeted Talks reconciliation case and
the completed-DevCon case, then required current-source checks and four affected
role reviews. The current first failure remains retained. This preflight approves
the treatment's requirement meaning, not the unimplemented exact test bytes.

## Prospective rights-loop hoist

Inspected `tests/release-rights.test.cjs:153–208`: in the unchanged positive
rights-inventory case, the retained-name filter calls
`snapshot.verify(source.publicDirectory, source.record()).routes` for each
retained name. `source.record()` constructs a new artifact manifest each time.
There is no fixture mutation between the preceding inventory assertions and this
filter. `tools/release/rights.cjs` has no proposed diff yet.

Hoisting one fresh record and its verified current route descriptors immediately
outside this single comparison is a justified local optimization in the test.
Every retained name must still be filtered by the same active-route asset
membership predicate, and compared against the same sorted report inventory.
Keep actual snapshot verification, all assertions, the later `rights.verify`
execution, refusal cases, and all fixture mutations/recomputations in other cases.
Do not carry the hoisted result across a write, fixture, test or global cache.
No release/rights implementation or inventory/approval semantics change is
supported by this local observation.

This is a prospective scope/semantics finding. I did not independently measure a
before/after speedup in this continuation, inspect an implemented rights diff, or
establish a complete hosted timeout cause. The old source/staging timeout remains
failed and unresolved pending the required full successful exact-source run after
evidenced correction; neither this hoist nor a passing current shard supplies it.

## Traceability and limits

| Obligation | Evidence / current result |
| --- | --- |
| AC05/11; preserve original historical negative controls | Actual dirty cohort diff uses four stable unique identities; original mutation table retained. |
| Preserve invented-events metadata refusal | Current meta matches approved issue126 `.before`; in-memory actual-meta replacement remains visible after restoration. |
| Preserve complete rights inventory and refusals | Prospective hoist confined to mutation-free positive comparison; exact resulting code/test evidence still required. |
| Complete staging and STOP | Current targeted test still fails; old staging timeout remains independent. No readiness, merge, production or deployment pass supplied. |

Operational boundaries from the first review continue: no MEMORY/private history,
peer verdicts, source writes, external writes or delegation. Parent follow-up and
candidate rationale were disclosed inputs to this continuation. Actual spawn
isolation receipts remain the orchestrator's evidence; provider context/memory
internals remain unknown. Only this assigned report was written. All read-only
diagnostics completed well within60s each.
