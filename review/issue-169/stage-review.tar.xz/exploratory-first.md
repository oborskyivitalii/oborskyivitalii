# Exploratory / Interaction QA — first independent result

Date: 2026-11-06. Reviewer task: `/root/stage_exploratory`. Phase: first judgment, before peer reconciliation. Nonauthor: no candidate source or tests authored/modified by this reviewer. Only this assigned report was written. No external writes or delegation.

## Verdict and scope

No blocking finding in the two-file prepared candidate within the bounded operator scenarios executed below. This is a scoped test-change review, not full-source, hosted, staging, rights approval, merge or production acceptance. AC05/AC11 review evidence is contributed; whole issue criteria are not accepted by this result. The accepted operator sequence remains preview → all required checks → stable staging → STOP/show, with no merge or production action.

The actual changed surface is the Node test CLI and its test inputs. `git diff --name-only` showed only `tests/executive.test.cjs` and `tests/release-rights.test.cjs`; no public UI/runtime, workflow, profile or limit changed. Browser/device interaction testing is reasoned not applicable to this delta. Existing article/hosted/browser acceptance obligations remain separate and were not observed here.

## Source and isolation receipt

Repository: `/workspace/scratch/f4dcb060a703/repo`. HEAD/base: `9513dbecc1caee39eebb94910c105ee0675e6bb8`; packet base tree: `39efdca0c5cfe46aae5cebacb2cda1c9302f5a80`. Working tree is dirty with the two test changes, not a clean checkout. Local refs/status inspected; no remote fetch or GitHub state refresh was performed in this delegated review. Issue169/PR170 ownership and accepted scope were read from the supplied owner snapshot and packet, not freshly authenticated remotely.

Identities verified against the bytes inspected:

| Input | SHA-256 |
| --- | --- |
| candidate-packet.json | `d74bf2abddc59f417f322f316938f823474b3f94ca0fb692cabb616d3ebf4b9c` |
| candidate.diff and actual `git diff` | `0e517b718c51f42636450ec48d1d9e68532a8b3c3c58c60c21585d7365c6475b` |
| tests/executive.test.cjs | `b235b4cc435e55a34494b35af10167e2cfb910a9b93affc294140083371cf746` |
| tests/release-rights.test.cjs | `d9ed3d9463564e61a4e0a435618fcf5565b2165d7a78a9ab3e49d62083c7ec81` |
| agents/reviewers/README.md | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| agents/reviewers/exploratory-interaction-qa.md | `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a` |
| CONTRIBUTING.md | `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442` |
| guides/SITE-CHECK-PROFILES.md | `a95c260343e6718650b3c9307a1ebc61e9ec1c0fd970e15cb020d828405335f9` |
| site/content/events.json | `6c584ae43e52a1e8cc25151a792bd5d274f2f99126f7593b098bf346ac2cb96a` |
| tools/check_site_seo.cjs | `0b749ddda512fc58e0b43ac9698a2548ffd9fedcff33f1961983f9afd69bf04c` |
| tools/quality/test-profiles.json | `5d3bb52fc8cd46de5c3744b787a349ee86fbe41ebb488846194a40c75965beb7` |
| .github/workflows/site-checks.yml | `d558533020175d569ab112520320bd55728cdbd2eac6c9fec0dd8080e0537250` |

Read root README/AGENTS, relevant CONTRIBUTING failure/reviewer rules, repository-map entries, common/role prompts, packet, owner snapshot, changed test bodies, rights implementation boundary, event records and profile registration. A bounded recursive filename inventory found no nested AGENTS under agents/tests/tools/site. Initial broad map/ref output was truncated; scoped map/source reads followed. Missing root package.json and .github/workflows/ci.yml were discovered during scheduling lookup; actual owners were found directly instead. These lookup errors are not test failures.

Visible inputs were this delegated source packet and shared platform/project instructions. No MEMORY, parent scratch notes, private history or peer output was read. I have not seen the actual parent spawn request/accepted response, so cannot independently attest its `fork_turns` value; the orchestrator must bind its actual launch receipt. Provider model/context/memory internals and any hidden history injection are unknown. This is an operational read boundary, not OS isolation or provider attestation. No peer conclusions were consulted before this first result.

## Independent charter and executed journeys

Charter: as the operator of the selected test CLI, verify that the current accepted event catalog no longer causes a stale four-card fixture assumption while meaningful mutation failures remain exercised, and that the inventory comparison still distinguishes current assets from retained assets and does not grant approval. Bound: two exact-name CLI cases, each hard-limited to 55 seconds; no full suite/browser campaign. Environment: Linux workspace, bash, Node `v24.22.1`; local repository and existing dependencies only.

| Scenario | Expected oracle | Observed disposition |
| --- | --- | --- |
| Current/retained inventory CLI | Complete inventory equality and retained/current exclusion comparison pass; `approvalPass` remains false and acceptance without clearance throws | Executed/pass, exit0; one selected test, zero failures/cancellations/skips |
| Current Talks + historical reconciliation CLI | Five completed cards including DevCon; exactly one match for each of four historical identities and one current description; existing unsupported source/date/language/resource mutations remain detected | Executed/pass, exit0; one selected test, zero failures/cancellations/skips |
| Public browser/focus/mobile interaction for this two-test delta | Applicable only if a public surface changed | Reasoned not applicable to this delta after diff inspection; unchanged public behavior is not re-proved |
| Full-source/stable staging/remote delivery | Exact-source complete accounting and controller evidence | Not observed in this role; still separate gates |

The event source explicitly contains a completed DevCon talk on 4 November 2026 and the future PMDay event marked Upcoming. The changed fixture selects historical cards by retained identifiers, rather than treating every completed card as historical. The entire selected Talks case ran, including its mutation-input-exists/meaningful checks and historical amendment integrity assertions. This is actual execution of those assertions, not a separately invented browser or usability observation.

The rights edit obtains one verified revision and a Set of route assets before filtering retained names. The selected case still checks exact inventory keys, retained classification and non-approval, then calls rights verification. Other rights cases were inspected only where necessary for context; their execution is not claimed.

## Raw actual execution

Working directory for both commands: `/workspace/scratch/f4dcb060a703/repo`.

Command 1 (exec chunk `da1f56`, exit0, tool elapsed 0.904551076s):

```text
timeout 55s node --test --test-name-pattern='^rights inventory covers actual current and retained bytes without granting approval$' tests/release-rights.test.cjs
✔ rights inventory covers actual current and retained bytes without granting approval (808.193058ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 941.90883
```

Command 2 (exec chunk `db044a`, session66005; final poll chunk `c9ad49`, exit0):

```text
timeout 55s node --test --test-name-pattern='^Talks reconciliation rejects missing events, substituted sources and invented dates or resources$' tests/executive.test.cjs
✔ Talks reconciliation rejects missing events, substituted sources and invented dates or resources (3250.776636ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 3394.048818
```

No check failed or timed out in these two executions; no rerun was performed. Candidate hashes were rechecked after execution and remained identical; final diff digest remained identical.

## Allocation, limits and next gate

Both existing cases are permanent source tests registered for `pr-targeted`, `staging`, `production` in `tools/quality/test-profiles.json`, with `guides/SITE-CHECK-PROFILES.md` as owner. PR source selection/aggregation is in `.github/workflows/site-checks.yml` (`checks` job). Their surviving command route includes `node tools/quality/source-tests.cjs --profile production`. This narrow direct CLI execution is diagnostic evidence, not the registered profile's complete zero-skip campaign. No new tests or mandatory matrices are proposed: retain these two existing regressions and execute the required source-bound selected campaigns through the existing controller.

The packet reports the previous full-source staging campaign timed out at 300000ms on `d5e915fe`; its raw failure was not independently reopened here. That historical failure remains unresolved by these local passes. I make no claim about its cause or about pending full dirty-tree diagnostics. No test/profile/time/output limits or negative controls were changed by this candidate. Current-source required checks and actual stable-staging evidence must be completed and diagnosed separately, then stop/show as authorized. This result cannot authorize merge or production.
