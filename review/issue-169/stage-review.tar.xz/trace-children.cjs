const cp = require('node:child_process');
const fs = require('node:fs');
const out = '/workspace/scratch/f4dcb060a703/stage-diagnostics/children.jsonl';
for (const name of ['spawnSync', 'execFileSync']) {
  const original = cp[name];
  cp[name] = function (...args) {
    const start = performance.now();
    try { return original.apply(this, args); }
    finally { fs.appendFileSync(out, JSON.stringify({pid:process.pid,parent:process.argv.slice(1),method:name,command:args.slice(0,2),ms:performance.now()-start})+'\n'); }
  };
}
