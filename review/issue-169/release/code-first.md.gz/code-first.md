# Code / Changed Artifact Reviewer — initial diagnosis

Date: 2026-11-06. Role execution: `/root/release_code`, nonauthor, read-only preimplementation diagnosis. Candidate inspected: clean Git HEAD `fc205b17774ba703c63fdd7d142ddac178afffdd`, supplied base `8cf15883125892710633b17133d9ee0fc4b23b92`; this is not corrected-source acceptance or release approval. The large base-to-head campaign diff was inventoried, not fully audited; this judgment is confined to the requested preflight/setup owners.

Packet SHA-256 independently verified: `d292b75d927ec60b07487ec7726e619322bf27a15b408035b6d7fc2461fb2a90`. Issue169 snapshot SHA-256 `fcca751ea21a7742ef4ca8eabe0dd89b1e966013ed7b059d33e086c0f7893376`. Original raw ZIP SHA-256 `97199b81af2f445e4d62018fa7265061d60a58a7fe2ba659d50f16cfa71b5d84`.

Intent inspected from packet and actual issue body: publish accepted R10 via the existing process, preserve manuscript/PDF/figures, full test scenarios, original budgets and source/rights/control/artifact binding. Website production is authorized; later LinkedIn/Medium operator work remains separate. Relevant impact: AC05 source-bound repository hygiene, AC09 exact delivery, AC11 independent execution; historical snapshots do not prove live acceptance.

## Findings and diagnosis

1. **High / retained acceptance blocker: historical source campaign is incomplete.** The actual raw runner JSON records 75 modules, four workers, 300000ms timeout, status failed, pass false, ETIMEDOUT and empty final accounting. Source before/after is clean `b75a0a31e36be02bea15bb7a0b269d032fa3cdcb`, tree `f3b8baa6f14e20d4b33593577e8bac4e07287814`. This is deadline exhaustion, not observed assertion failure. Raw timings show release-rights completed in 246514ms, release-controller 162164ms, pages-delivery 113026ms, pages-migration 90713ms. Several wrappers passed, but this cannot establish campaign success. The ZIP does not contain the full build-job cancellation log, so the parent-supplied 10-minute build cancellation was not independently verified here. Preserve this failure and require corrected-source acceptance later.

2. **Medium / strongest shared optimization candidate: `tools/site/public-artifact.cjs:31–42` recompresses every current file on every manifest call.** `entries()` correctly rereads actual bytes, rejects symlinks/nonfiles and sorts inventory every time; `manifest()` then computes SHA-256 and gzip length repeatedly. `tools/quality/artifact.cjs` imports this same owner and calls it from size checks. The rights negative loops recompute manifests after deliberate changes; delivery/edition/Pages fixtures repeatedly invoke manifest/size/rights work over overwhelmingly identical retained media. `tests/fixtures/delivery.cjs:14–30` already avoids some seed manifest calls by validating actual input hashes; it does not eliminate manifests inside downstream validators and edition construction. A cache of whole manifests or frozen rights reports would weaken these checks. Caching only deterministic gzip **length** by current content digest and raw length can remove duplicate compression while preserving the byte reads, hashes, inventory/ordering and all refusal paths.

   Bounded read-only diagnostic on the current 85-file `docs` tree: 7,390,394 total bytes, 68 unique content digests / 6,459,191 unique bytes. First full manifest 170.09ms, immediate repeated full manifest 162.87ms; direct gzip loop 155.77ms (about 92% of first manifest wall time). Both manifest results were byte-for-byte JSON-identical, artifact digest `7d2a147be45c737c79f1dc35be5addd010b72406ff75efc83bb2bc3a0a334a48`. This establishes a real repeated CPU cost locally, not its exact historical CI share or a promise that the full staging campaign now fits 300s. The cache would be process-local and would not accelerate a new CLI process's cold compression.

3. **Medium / concrete fixture setup waste: `tests/release-rights.test.cjs:43–49` puts a `filter` on `mkdirSync`, while its `cpSync` lacks a filter.** `mkdirSync` does not perform recursive copying, so this cannot exclude dependencies. The local `tools/publishing` inventory contains 1,164 files / 21,306,188 bytes, of which 1,142 files / 21,059,580 bytes are under node_modules; the fixture copies that tree for every `fixture(t)` call before its synthetic/native branch. In contrast the authored site has 281 files / 28,851,908 bytes and tools/site 32 files / 240,430 bytes. This is evidenced repeated setup overhead, but do not move the filter blindly: native CLI uses the copied publishing/toolchain behavior and module-resolution dependencies need to be preserved. A source-only copy with explicit external dependency resolution may be possible, but has greater behavioral surface than gzip-length reuse. No claim that removing installed publishing dependencies is safe has been established.

4. **Nonblocking preservation observation: live fixtures have essential current-byte checks.** `delivery.sourceSeed()` reads and hashes every docs file; `staging()` binds source identity, input tool/effect bytes and actual producer functions, copies fresh bytes and revalidates snapshots/motion; `rightsInventory()` clones local objects without checkout and copies required authored source before current compilation. `pages-delivery.test.cjs:13–66` explicitly verifies fixture mutation isolation and original size data. These behaviors must stay; optimize the deterministic suboperation, not source/rights admission. The rights CLI test intentionally exercises both staging and production, multiple real processes, upload ordering and negative sidecars; do not remove/reuse those scenarios. Its raw duration was 86767ms and hidden-license wrapper loop 59060ms, but those subtest timings include setup and validation, not exclusive gzip/copy profiles.

## Smallest proposed treatment and bounded next observation

Preferred small fix hypothesis: bounded process-local memoization of **only** `gzipSync(bytes).length` in the existing public-artifact owner. Calculate the SHA-256 from freshly read bytes once per entry, include raw length in the key, keep the exact gzip defaults, return ordinary fresh manifest objects and preserve traversal and errors. Bound entry count/metadata retention (store numbers and keys, not all buffers); eviction may affect speed only. If runtime options or producer identity can vary, include/reset for that identity rather than returning stale compression results. No runner/controller/worker/concurrency/deadline/selection/profile/budget/evidence-binding change is needed for this hypothesis.

Before a campaign, a small diagnostic should instrument/compare a cold and repeated manifest with native gzip as the independent oracle, then mutate bytes including a same-length edit, add/delete/rename a file, and check symlink/non-file rejection and cache eviction. Require deep equality to an uncached native oracle for the entire inventory and artifact digest; then run the unchanged affected rights/edition/Pages checks on the corrected source within their existing limits. No full campaign was run here and no correction was implemented or approved. Time saved at cold/current CI scale remains unknown; if bounded affected checks do not improve enough, preserve that result and diagnose again instead of adjusting budgets or treating partial output as acceptance.

## Execution and limits

Read actual root/protocol/reviewer prompts, README and relevant repository map entries, issue snapshot, raw ZIP runner/TAP/stderr, requested fixtures/build and artifact owners. Used filesystem counts and two read-only manifest measurements; no external writes, implementation, test changes, delegation or full campaign. Did not read MEMORY, parent scratch notes or peer output. A later parent message identified public-artifact as an additional candidate; the cost/behavior assessment above is from direct source and measurements, not a peer verdict. Provider-internal isolation/model facts are unavailable; launch parameters are the orchestrator's receipt responsibility. Relevant source hashes must be compared before corrected-source review.

## Source/prompt identities

| Path | SHA-256 |
| --- | --- |
| `AGENTS.md` | `f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01` |
| `CONTRIBUTING.md` | `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442` |
| `agents/reviewers/README.md` | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| `agents/reviewers/code-review.md` | `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697` |
| `tests/release-rights.test.cjs` | `36e20d4a7b9b9b6757178070fcadf2b3cd38ec97da0a22640a96d13175983b28` |
| `tests/release-controller.test.cjs` | `acdc7f22dc63c75ff17b1dc72ccae386c3bbd57e4889d5b2d4d3e28afede40f1` |
| `tests/fixtures/delivery.cjs` | `4bf3c43e42c63d5006d209d7c85acaceb86ad62b457e36c29882d71056b66adf` |
| `tests/fixtures/catalog.cjs` | `dd59ed1c44c4d92838a6ae718af249820ae9c4c034163df8f61bbafc457037c0` |
| `tests/pages-delivery.test.cjs` | `ff9120a4ace98297cac6cb7d774ad0ee469a7b0af430305b59125a68f2479d41` |
| `tests/pages-migration.test.cjs` | `5b968519903066c2f9a84c4d26613b53ec4dfeedba6b10b510e3344ec44ecc67` |
| `tools/site/build.cjs` | `3d9b80f989008ae487cccf4b38aea630bd4ddf62782a971e7e62142c9fbbc869` |
| `tools/site/public-artifact.cjs` | `c61ac003a19a49fd673dd8aec08666520158dd7ea5b875141b3cf932e163c058` |
| `tools/quality/artifact.cjs` | `3dab8113e50df470c14a7f0e59d9a6ecae8b13ef799a8383b43538be37f9fc29` |
| `tools/quality/source-tests.cjs` | `792aec87f4abb3aec8c97b4a8d33cd958a643b8f6c77aaac4c5683d45aaf5086` |
| `tools/quality/source-test-shards.cjs` | `d22729bb252d0aac71f05dcd313beda4534babb93a7f2a8869894cf59b38969c` |
