# Requirements & Acceptance — first independent result

Reviewer: `/root/cache_requirements`, distinct nonauthor Requirements & Acceptance role. Phase: completed prepared-candidate review, including the formatting-only v2 update received before this first verdict. Date: 2026-11-06. Owner: issue169 / PR170.

## Verdict

**The v2 correction is consistent with the authorized production objective and preserves the inspected release requirements. No blocking requirements defect was found in the two-file correction. This is scoped review acceptance, not clean-source CI, staging acceptance, proof the historical timeout is resolved, or production readiness.**

The authorized result is publication of accepted R10 through the existing controller. Process-local reuse of deterministic gzip lengths is an implementation means within that goal. It does not change the accepted article, PDF, figures, rights, release decisions or test selection. The actual diff changes only `tools/site/public-artifact.cjs` and `tests/build-cohesion.test.cjs`. The unchanged inventory/read/hash path remains authoritative; cache hits cannot admit a changed path inventory or stale filesystem metadata.

Review acceptance also requires the orchestrator's actual clean-context launch receipt and the other mandatory role results. My inner execution cannot independently observe the parent's requested/accepted fork parameters or provider context internals.

## Inspected identities and boundaries

- Baseline HEAD: `fc205b17774ba703c63fdd7d142ddac178afffdd`; baseline tree: `a605aff62e7c2ae28ce2ff3f81f06c1efa0fea7e`, independently read from Git. This is a dirty prepared subset, not a clean candidate commit. Packet comparison base: `8cf15883125892710633b17133d9ee0fc4b23b92`.
- Initial packet `cache-candidate.json`: SHA256 `209ffec796c274ba5c1a02429eee79d4bf5f04d40c5d7ccfb8b2d5d412b58bdb`; initial actual diff `f891976186dc66967c5e502c477286dfcf159962cfb48e68e0a40f3ecdaa7d88`. All listed source/artifact pins verified before v2 arrived.
- Final packet `cache-candidate-v2.json`: SHA256 `18798370f6ea9667a7a60f0fe03688dc54d6575c378295341fca4e7fe24fa88d`; independently recomputed final diff `7bfe92637bf55b37073db51683154339f1bb619523663b986cb714b535547e10`. All listed v2 source/artifact pins verified.
- Final source SHA256: public-artifact `2814ddf9eae981e145f9ad351227d03d628ed52fbdf9943abf7babbf99a58419`; build-cohesion tests `341134612f3006afe912d1ac7007a9baa47c234632612632f4b4e5f68dcdd5d6`.
- Common reviewer contract SHA256: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256: `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`. Both read in full.
- Read root AGENTS, CONTRIBUTING's intake/failure/acceptance/independent-review provisions, README, relevant REPOSITORY-MAP entries, acceptance policy, test registry, check-profile source/guard/staging rules and relevant code-style provisions. No nested AGENTS files were found under tools/tests/agents.
- Root AGENTS SHA256: `f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01`; CONTRIBUTING: `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442`; acceptance contract: `6469a66a36171404ce8448d75c3c5d96dc43563c76af41d4d2367598836fcaa8`.
- Original authorized request read from the packet; issue text read from the explicitly dated local issue169 snapshot, updated 2026-11-06T08:38:01Z. Issue snapshot SHA256: `fcca751ea21a7742ef4ca8eabe0dd89b1e966013ed7b059d33e086c0f7893376`. Its dated author acceptance and planned-link/site-first amendment support website production and later manual LinkedIn/Medium posting. No fresh live issue/GitHub state was observed by this role.
- Historical archive SHA256: `97199b81af2f445e4d62018fa7265061d60a58a7fe2ba659d50f16cfa71b5d84`. Independently opened its raw `prepublication-source-tests-runner.json`, SHA256 `3804a7f6fd4cf1d1fbc1739e48586d9dbf8dc11c72a36c3145dc18043898f5e7`. It reports failed staging, 75 selected modules, source `b75a0a31e36be02bea15bb7a0b269d032fa3cdcb`, clean tree `f3b8baa6f14e20d4b33593577e8bac4e07287814`, ETIMEDOUT at 300000ms and no final aggregate test accounting. Emitted successes cannot convert this to a pass.
- Issue/archive hashes above bind references that were supplied by path rather than individually pinned inside the packet. Preserve these identities in the execution receipt.

The v1 implementation/tests were inspected and the focused tests executed before the factual v2 formatting update arrived. No first verdict or peer reconciliation had occurred. I then inspected the full v2 diff, verified v2 pins and reran affected checks. The v2 diff restores canonical formatting and retains the same bounded gzip behavior; the broad v1 formatting noise is absent. No peer report, parent history/scratch notes or MEMORY was read. I did not author implementation or tests, delegate, or write externally. Provider model/context/memory internals are unknown; filesystem discipline is not provider isolation attestation.

## Intent and acceptance linkage

| Requirement / affected AC | Independent check or continuing gate | Observed result |
| --- | --- | --- |
| Publish accepted R10 through the existing publisher; preserve manuscript/PDF/figures and rights (AC04/07/08/09) | Actual two-file diff, dated author scope; later exact served-edition/rights verification | No publication/content/assets/controller edits in this subset. Publication remains unobserved. |
| Fresh complete public inventory and content identity (AC05) | Source lines29–45,48–63; native baseline/current manifest comparison; mutation/refusal tests | Each call rereads sorted entries, lstats and reads bytes, then hashes current bytes. Native manifest JSON including artifactDigest is identical on inspected docs. |
| Gzip values remain native deterministic results (AC05) | Source lines11–22,52–58; direct native-zlib oracle in new tests | Lengths only are reused by fresh SHA256 plus raw length; producer identity changes clear cache. No manifest/schema/digest algorithm change. |
| Bounded process-local state; no persistent evidence shortcut (AC05) | Map construction and eviction source; 2049 distinct values plus revisit test | At most2048 numeric lengths keyed by digest/length; FIFO eviction forces native recomputation. No file bytes or reports are retained in the cache. |
| Preserve scenarios, refusals and original budgets (AC05/11) | Full diff and unchanged source-runner/workflow pins; original test names; current focused execution | All8 existing tests remain, two tests added. Symlink/non-file refusals unchanged. 300-second source-process and workflow job budgets/selection/controller sources unchanged. |
| New behavior receives enduring check selection (AC05) | test-profiles.json build-cohesion entry and tools/site/** input | Existing permanent module routes to PR-targeted, staging and production; new cases are in that module, without scenario deletion or reduced selection. |
| Independent review, exact current-source checks and existing stage/production gates (AC05/11) | Four actual role results, launch receipts; Basic/RI/style/owner policy and mapped source checks; hosted controller gates | This report supplies only this role's bounded result. Current dirty subset tests and baseline green CI cannot satisfy clean-candidate or hosted acceptance. |
| Site-first release followed by author platform publication (AC04/09/10/11) | Existing controller/live observation and later author actions | Cache change supplies no live article/PDF/link observations and does not waive them. Later manual platform posting does not block initial website publication. |

## Actual checks

1. Independently verified both packet digests, every listed source/artifact SHA256, current HEAD/tree, both prepared-diff identities and final scoped dirty status.
2. Ran `node --test tests/build-cohesion.test.cjs` against v1:10/10 pass, no fail/cancel/skip/todo,1682ms. Reran after v2 source verification:10/10 pass, no fail/cancel/skip/todo,1555ms.
3. Loaded the baseline public-artifact source directly from Git into a separate VM module and compared its native manifest with current cold and warm manifests of real `docs/`. All85 files and complete serialized manifest matched, artifactDigest `7d2a147be45c737c79f1dc35be5addd010b72406ff75efc83bb2bc3a0a334a48`. Baseline elapsed173.4ms; two candidate calls together157.3ms. This small local timing is diagnostic, not a hosted performance threshold or campaign proof.
4. Independently compared baseline/candidate named test inventories: all8 baseline names retained, with2 added. Inspected the full v2 diff; pre-existing test behavior is retained.
5. Inspected existing source-test accounting and limits:300000ms timeout, complete no-skip accounting, clean-source identity and after-run source comparison remain. Workflow job bounds remain unchanged by the correction.
6. Read the supplied focused log and corrected manifest timing artifact as retained evidence, not independent execution or acceptance. Did not rerun the failed75-module campaign.

The focused tests exercise reuse across identical files/calls, changed same-size/same-mtime content, rename/deletion, simulated symlink/non-file refusals, changed gzip producer and bounded eviction. My additional real-docs parity comparison covers the nested public inventory. The test's refusal injection is a mocked lstat boundary; this role did not independently create every possible filesystem fault or run hostile release-controller scenarios.

## Findings, limits and next gates

No candidate requirements defect requiring a code or oracle change was found. Risks explicitly examined were stale-size reuse, path/mtime identity shortcuts, unbounded cache growth, altered gzip/digest bytes, loss of refusals, deleted scenarios and using old/partial checks as release evidence. No such weakening appears in the inspected correction.

The local parity and warm-reuse evidence support the proposed reduction of repeated gzip work. They do **not** establish that gzip was the sole cause of historical staging failure, that all test processes benefit equally, or that the full campaign now fits the original deadline. Per-process first-use compression still occurs; eviction may reduce reuse. No promised end-to-end improvement percentage or guaranteed deadline recovery is accepted.

Before advancing to readiness: preserve raw failure evidence; finish the other independent reviews and launch/result receipts; record applicable CS01/04/05/07/09 mapping in the owner review; run required current-source Basic/style/RI/acceptance and selected behavioral checks; then obtain exact clean-candidate hosted staging through the existing controller with complete unchanged accounting/budgets. A new candidate commit needs its own clean-source evidence. Follow existing merge/production admission and actual served-edition checks afterward. Current baseline CI remains evidence for baseline only.

No maintainer decision is invented here. The original website release authorization remains applicable; this scoped review neither requests redundant permission nor replaces remaining rights, editorial, source, staging, merge or live-observation gates. Whole issue criteria remain open wherever any required part is still pending.
