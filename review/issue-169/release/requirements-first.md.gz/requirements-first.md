# Requirements & Acceptance — initial release diagnosis

Role: distinct nonauthor Requirements & Acceptance Reviewer; task `/root/release_requirements`; first judgment, 2026-11-06. Scope: read-only preimplementation diagnosis of the historical staging source/preflight failure for owner #169 / PR170. No implementation, external writes, test execution or delegation. This report is the only written artifact. No MEMORY, parent notes, author conversation or peer review output was read. Actual spawn request/admission receipts belong to the orchestrator; this reviewer cannot independently attest provider context/model internals.

## Verdict

**Release advancement remains blocked; bounded diagnosis and a behavior-preserving test/helper optimization can continue within the authorized production task.** The current PR's eight-shard source success does not establish completion of staging prepublication's separate single-runner source gate. The smallest justified route preserves that staging runner's 300000 ms limit, all selected tests, the build's 10-minute limit, complete accounting, and every subsequent source/control/rights/artifact/host gate. No requirement or oracle change is necessary merely to investigate repeated fixture preparation cost. A correction requires evidence before implementation and independent review afterward.

## Identity and evidence limits

- Original request: packet states accepted current R10 to production using existing release process; preserve manuscript/PDF/figures, all scenarios, original budgets and source/rights/control/artifact binding. LinkedIn/Medium are author-manual later.
- Packet `/workspace/scratch/f4dcb060a703/release-diagnosis/packet.json` SHA256 `d292b75d927ec60b07487ec7726e619322bf27a15b408035b6d7fc2461fb2a90`, verified.
- Base `8cf15883125892710633b17133d9ee0fc4b23b92`; inspected HEAD `fc205b17774ba703c63fdd7d142ddac178afffdd`; tree `a605aff62e7c2ae28ce2ff3f81f06c1efa0fea7e`; working tree clean at inspection.
- Owner snapshot SHA256 `fcca751ea21a7742ef4ca8eabe0dd89b1e966013ed7b059d33e086c0f7893376`. Read original intent, stable AC01–11 and dated website authorization / later manual distribution amendment. It is a supplied snapshot, not a fresh independent GitHub fetch.
- Raw failed artifact ZIP SHA256 `97199b81af2f445e4d62018fa7265061d60a58a7fe2ba659d50f16cfa71b5d84`; raw `prepublication-source-tests-runner.json` SHA256 `3804a7f6fd4cf1d1fbc1739e48586d9dbf8dc11c72a36c3145dc18043898f5e7`. Read JSON, raw timing stderr and TAP tail/accounting characteristics directly from ZIP.
- Common and role prompt hashes are in the inspected manifest below and match packet. Other scoped reads included root instructions, release/staging/acceptance contracts, source runner/shards and selected heavy tests/helpers. Repository map and large contract output were partially truncated; only relevant displayed portions are credited. Full article/diff/rights acceptance was not audited. No live CI/preview/staging/production observation was made; current green run statuses are task-supplied facts, not independently verified results.

## Findings and requirements consequences

1. **Blocker — staging source completion is unproven (AC05, AC11, DELIVERY).** Historical run42119802341 on source `b75a0a31e36be02bea15bb7a0b269d032fa3cdcb`, tree `f3b8baa6f14e20d4b33593577e8bac4e07287814`, clean, selected75modules. Raw report says `status=failed`, `pass=false`, `ETIMEDOUT`, `timeoutMs=300000`; there is no aggregate result. Timing shows28dequeued and24completed module wrappers before deadline; TAP ends at passing case409 without final aggregate accounting. No top-level `not ok` was present in retained TAP, but that cannot establish an assertion-free completed campaign or all-module success. Treatment: retain original failure and obtain complete exact-candidate staging evidence only after an evidenced correction/diagnosis. Never relabel partial passes as acceptance.

2. **High — PR sharding and staging are distinct execution contracts (AC05/11).** Current `tools/quality/local.cjs:441` invokes `source-tests.cjs --profile staging --require-clean` in prepublication when no genuine content admission exists. `source-tests.cjs:9–12,575–610` retains one300000ms process /330000ms wrapper. `source-test-shards.cjs` validates eight PR receipts; it is not used by that prepublication call. Current `site-color-review.yml:205` still caps build at10minutes and line303 runs full prepublication. Thus a passing new-head PR sharded source run cannot resolve the historical single-runner bottleneck or authorize an unchanged staging retry. Treatment: diagnose/optimize the existing test/helper owners; do not import PR shard receipts into staging, recategorize the candidate as content, remove modules, or expand parallel campaign budgets without an explicit accepted contract change.

3. **High — supplied broader cancellation is not fully explainable from ZIP alone (DELIVERY).** The packet reports build cancellation after10minutes while security was still running. ZIP contains raw scanner outputs, but no completed aggregate prepublication report. The source timeout alone is directly proven; exact full-job critical path and security termination reason need retained job timestamps/logs. Treatment: inspect those retained logs first. Do not claim source optimization alone guarantees the entire build will fit10minutes.

4. **No new scope/acceptance defect in production continuation.** Owner's dated instruction authorizes website production and explicitly supersedes historical publication-pending/no-release statements. Whole AC06 is a historical Draft-delivery milestone; its no-release wording cannot silently revoke the later explicit website authorization. LinkedIn/Medium posting and later reciprocal links remain separate manual follow-up; do not block initial website release on them or claim they happened. AC05/11 independent roles, native/human/rights/source gates and exact served edition remain mandatory. Current owning-policy automated pass cannot tick whole criteria whose external gates remain open.

## Facts, hypotheses and smallest next diagnostic

Observed facts: the four-worker historical runner spent246514ms in release-rights,162164ms release-controller,113026ms pages-delivery,109369ms executive,102055ms space and90713ms pages-migration. The24completed wrappers sum1170208ms of worker duration; with four workers that nearly consumes300seconds before the remaining modules are accounted for. These durations include contention and are not independent CPU measurements. Longest-first scheduling was already active; reordering alone is not an evidenced solution.

Current source inspection shows `tests/release-rights.test.cjs:23–69` repeatedly creates/copies a source fixture and calls the real site builder; numerous cases request fresh fixtures. `tests/fixtures/delivery.cjs` already uses source-keyed immutable preparation seeds and fresh per-case copies with builder/input identity checks. **Hypothesis:** repeated immutable fixture generation/copy work contributes materially to the heavy-module runtime. This is supported as an investigation direction, not yet a measured root-cause attribution or approved cache design.

Smallest next route: (1) reuse retained full job logs to separate setup/build/source/security elapsed costs; (2) statically count heavy fixture preparations and identify exact mutable versus immutable inputs; (3) if existing evidence cannot answer cost attribution, record one targeted diagnostic of the heaviest fixture owner with phase timing, exact candidate/toolchain, original300000ms process bound, and a stop at the first completed measurement or deadline. No full campaign rerun. Information gain: quantify copy/build/rights/proof costs and test whether repeated preparation dominates. Contradiction: low preparation cost or dominant unique scenario work rejects this optimization hypothesis. Only then consider reuse of identical immutable preparation within existing helpers, keeping fresh mutable case directories and real generators/adversarial validation. All selected scenarios and independent expected failures must remain.

Any fixture reuse must preserve mutations/invalidations of content, rights/provenance, source commit/tree, build function or configuration, artifact inventories, edition identity, and refusal paths. A cache hit cannot supply a prior check result, accepted proof, or bypass execution of the scenario. This is a preservation checklist for review, not proposed new accepted requirements.

## Traceability

| Intent / AC | Check or gate | Observed evidence / disposition |
| --- | --- | --- |
| Accepted R10 meaning, illustrations, PDF; AC02/07/08/09 | Exact accepted source / visual/editorial/rights and PDF parity gates | Preservation required; no content changes proposed or audited here |
| Source-bound execution; AC05/11 | Full clean-source staging source accounting, bounded prepublication, four roles | Historical source failed/incomplete; current PR sharded success supplied; separate staging completion missing |
| Existing authorized controller; AC04/05 DELIVERY | Same accepted source/tree, frozen artifact and control/rights binding | Mandatory; no new controller, gate reuse or alternate release path authorized |
| Publication authority; AC04/09 | Author website authorization → accepted staging → merge/production controller → exact served edition/live article and PDF | Authorization exists in supplied original intent/owner snapshot; stage/merge/served observations absent here |
| Platform copies and reciprocal links; AC04/09/10 | Complete copies with prepared links; later author editor/publication observations | Later manual posting does not block website; guessed links/green host checks do not prove posting |
| Whole issue completion; AC01–11 | Every mapped automated check and applicable external gate | Owner snapshot leaves whole criteria open except historicalAC06; do not infer closure from CI |

## Decisions / next gate

No new permission is needed for read-only diagnosis or an evidenced behavior-preserving correction in existing authorized helper/test owners. Increasing300s/10min limits, removing scenarios, converting required checks into optional diagnostics, accepting partial accounting, switching staging to PR shards or reusing unrelated source receipts would change requirements/oracles and needs an explicit owner decision; they are outside this preserved-budget request. No such change is recommended.

Before another staging attempt: preserve first failure; document measured cause/fix and all gate/budget invariants; implement only the smallest supported correction; complete affected four-role source-bound review and exact-candidate verification; verify pending preview and existing admission requirements. Maintain blocker status until the actual staging gate completes. This is an initial requirements diagnosis, not final release approval.

## Inspected byte identities (SHA256)

```text
f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01  AGENTS.md
804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442  CONTRIBUTING.md
2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb  agents/reviewers/README.md
010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6  agents/reviewers/requirements-acceptance.md
6cfbf71fad0822cbd4d756afb76b2fd29cdd7b203541b098bfba040e2c24231e  README.md
aac36d4dced4db5aa8121f45dd500e2b3819879ee289e12bcbe90793f9fe9d7a  REPOSITORY-MAP.md
6469a66a36171404ce8448d75c3c5d96dc43563c76af41d4d2367598836fcaa8  .github/ACCEPTANCE.md
fcdf6622a5e6a0ba7e62fad828b82e14b2c6e8c75a96b18f97f12d1abc87025e  .github/acceptance/issue-169.json
44c37986027125585e54787337da6debdd014b0b5b70c87518f92ed74d62f63a  guides/SITE-STAGING.md
80e3893557584c46713a2055b6bd747f73d167352da013339ed64c538a5ce3ce  guides/SITE-RELEASE-GATES.md
415426b649d4344b17698d10aace6bab61a9c5e87cc37e31b3f56d458098a16f  tools/quality/source-test-worker.cjs
792aec87f4abb3aec8c97b4a8d33cd958a643b8f6c77aaac4c5683d45aaf5086  tools/quality/source-tests.cjs
ea8550ebac5b2f62147c60c8e0b70a54f6e60d20643cf190ec45c6a5d693f96d  tools/quality/local.cjs
d22729bb252d0aac71f05dcd313beda4534babb93a7f2a8869894cf59b38969c  tools/quality/source-test-shards.cjs
d184fb3e54d5c3a42901f10597313e4cd4da0f5d3d51cb0f7ba3ab30a9f4dbe2  .github/workflows/site-color-review.yml
36e20d4a7b9b9b6757178070fcadf2b3cd38ec97da0a22640a96d13175983b28  tests/release-rights.test.cjs
acdc7f22dc63c75ff17b1dc72ccae386c3bbd57e4889d5b2d4d3e28afede40f1  tests/release-controller.test.cjs
ff9120a4ace98297cac6cb7d774ad0ee469a7b0af430305b59125a68f2479d41  tests/pages-delivery.test.cjs
5b968519903066c2f9a84c4d26613b53ec4dfeedba6b10b510e3344ec44ecc67  tests/pages-migration.test.cjs
4bf3c43e42c63d5006d209d7c85acaceb86ad62b457e36c29882d71056b66adf  tests/fixtures/delivery.cjs
614fd3334fbbcf72b11fd033b1668065e82d205b028a731a0885eee9ee42e174  tests/fixtures/staging-evidence.cjs
```

## Post-first-result addendum — neutral gzip attribution follow-up

The initial judgment above was completed before the orchestrator supplied this follow-up; its pre-addendum SHA256 was `5aee3e3a90d9a97d127013c664656c1ae2651c2177f1a03b04b66427220839c5`. No peer output or author conversation was exposed. The newly supplied measurement is inspected as evidence, not an accepted correction: three unchanged85-file manifest calls have equal digest,509.08ms total,255gzip calls and472.61ms attributed to gzip. These are supplied measurements; I did not rerun them. The evidence supports redundant compression in these calls. It does not yet establish the total staging critical-path savings or resolve the broader10-minute security/build budget.

Independent source inspection confirms `tools/site/public-artifact.cjs:29–42` inventories every entry, reads bytes, hashes them, and synchronously recompresses each on each manifest call. `tools/quality/artifact.cjs` consumes these manifests for size checks and binding verification. A bounded process-local cache **only of the gzip byte length for freshly hashed actual content**, keeping fresh complete filesystem traversal/read/hash and the exact return shape/digest, is a compatible candidate optimization within the existing artifact mechanism. It changes engineering implementation, not the size oracle or acceptance threshold, provided the uncached zlib result remains its independent oracle. It is not test-result/proof reuse and must not become manifest/inventory caching. No extra owner decision is required for this constrained behavior-preserving correction within the already authorized release fix; normal code/style/four-role review and gates still apply.

Necessary affected validation before acceptance:

- Compare cold and warm complete manifests byte-for-byte against an independently constructed uncached inventory using real `zlib.gzipSync(bytes).length`; include empty content, duplicate content at distinct paths, different content and large accepted files. Assert identical per-file sha256/raw/gzip and aggregate artifactDigest. Do not derive expected gzip values through the new cache.
- Modify a file between calls with same-length bytes while retaining mtime if possible: the new bytes/hash must force their own gzip computation and changed digest even if compressed lengths coincide. Restore bytes and verify exact parity. Path/mtime/size alone must never establish a hit.
- Add, delete and rename files between calls; verify a fresh complete sorted inventory. After warming, a symlink/non-file or unreadable input must retain current rejection/error behavior instead of returning a remembered manifest.
- Demonstrate the cache is finite with a deterministic capacity/eviction check, retains only small key/size metadata, and eviction changes compression work only, never results. No persistent disk state or cross-run/source receipt reuse. Keep default compression semantics fixed; if configurable compression is introduced, options must enter identity or the cache is invalid.
- Use deterministic compression-call accounting to demonstrate warm identical-content hits and changed-content misses; wall-clock improvement is useful diagnostic evidence but cannot replace parity oracles. Run existing affected manifest/artifact/rights/size/fixture checks, obtain independent review of this shared producer and its tests, and only then perform the required exact-candidate acceptance/staging checks with300s/10min limits unchanged.

The proposed cache touches a shared artifact producer, so review impact extends beyond helper runtime: size budgets, frozen artifact identity, rights inventory and publication verification must remain unchanged. An implementation that caches full manifests, skips file reads/hashing, suppresses an error, accepts a changed inventory, changes gzip options, weakens test selection or gates fails this preflight. Final staging acceptance is still missing.

Additional inspected SHA256 identities:

```text
34c490c5cb889ba1f5a6a2955d5874c199f26d505ff5668b4184b5b6a27a2f55  manifest-timing.json
3dab8113e50df470c14a7f0e59d9a6ecae8b13ef799a8383b43538be37f9fc29  tools/quality/artifact.cjs
c61ac003a19a49fd673dd8aec08666520158dd7ea5b875141b3cf932e163c058  tools/site/public-artifact.cjs
```
