# Exploratory / Interaction QA — v3 generated-closure continuation

## Identity, chronology and source binding

Role/agent: Exploratory / Interaction QA, `/root/cache_exploratory`, owner #169 / PR170. This is a **same-role continuation/rebind**, not a new fresh-context review. The first independent judgment is preserved untouched at `/workspace/scratch/f4dcb060a703/release-diagnosis/cache-exploratory-first.md`, SHA256 `6e702134cdf464d6f8543ad4d1ee5011eee2e68f1f0eba7c7f98f57d1012cc5b`.

Inputs were my own first output, the factual continuation request, actual generated/source files and the v3 packet/parity record. No peer reports, parent histories, MEMORY or unrelated notes were read. No source/test modifications, external writes, delegation or full campaign occurred. Only this assigned final artifact was written. Requested/accepted launch evidence belongs to the orchestrator; provider model/context internals remain unknown.

- Observed baseline HEAD: `fc205b17774ba703c63fdd7d142ddac178afffdd`.
- Candidate is a prepared staged/dirty generated closure, **not clean committed-source acceptance**. Generated current pages/snapshots/previews/bundle manifest/output lock and the original two implementation/test paths are staged; release-review material is also untracked. No claim covers unspecified untracked report bytes.
- V3 packet: `review/issue-169/release/cache-candidate-v3.json`, SHA256 `38becd17f6bc55bbdcd84dd48cd7d77b4278077d61880aed57342dd7667d6ac7`. Independently read and recomputed **all 43 file pins**, all equal.
- Parity record: `review/issue-169/release/regeneration-parity.json`, SHA256 `9cf5213066a576292e5bd08c4197531cff429ff6915fa2270313faff2189baae`.
- Implementation/test bytes equal my first v2 result: helper SHA256 `2814ddf9eae981e145f9ad351227d03d628ed52fbdf9943abf7babbf99a58419`; build-cohesion tests SHA256 `341134612f3006afe912d1ac7007a9baa47c234632612632f4b4e5f68dcdd5d6`.
- Common/role prompts remain pinned and verified: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` / `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`. Root scoped instructions and their identities remain those recorded in the first result.

## Charter and surface

Bounded read-only continuation, up to four minutes, no full campaign. Check whether the expanded generated delta changes a reader's article/navigation/PDF or an operator's artifact closure. Test actual source-bound parity rather than relying on a visible-text boolean alone. Check that new snapshot identities resolve consistently, previews refer to their exact sources and packaging metadata still equals native uncached compression.

The actual delta inspected in staged Git diff changes provenance/version metadata and current snapshot paths; it does not change runtime bytes, visible HTML structure or content. A new browser interaction campaign is reasoned unnecessary for this provenance-only generated delta because exact full document parity, except explicit route-version substitutions, can be established. Dynamic hosted delivery, navigation execution, perceptual QA, mobile/no-JS and physical-device behavior remain unobserved here and retain their existing release gates. Static/native verification does not establish that a deployed browser fetched these files.

Environment: local repository, Node `v24.22.1`, native fs/crypto/zlib/VM and existing read-only snapshot/runtime verifiers.

## Executed actions and independent oracles

| Journey/check | Expected versus observed | Accounting |
| --- | --- | --- |
| Rebind packet to actual candidate | Every pin equals actual bytes | PASS, 43/43 pins; exact packet hash verified. |
| Six canonical pages | Baseline and candidate equal after substituting only the old→new route/article versions declared in `site-revision.json` | PASS, 6/6 full document byte comparisons after those exact substitutions. This is stronger than extracted visible-text parity; all other markup, text, links, inline styles/scripts and attributes remain equal. |
| Six current snapshots | Follow each old/new revision URL; compare full bytes with the same explicit version mapping; recompute snapshot digest | PASS, 6/6 snapshots and digests. Five room snapshots and one article snapshot resolve locally. |
| Runtime/manuscript/PDF | Read current and `git show HEAD:path` independently; compare exact bytes and declared hashes | PASS, 7/7 files: five runtime/style aliases, manuscript and accepted R10 PDF. Engine identity unchanged. |
| Native generated closure | Existing `snapshot.verify('docs', outputLock)` checks inventory, runtime/media aliases, current snapshots, article download/assets, document identities, local dependency links and original byte budgets | PASS, 5 routes and 1 article. This executes existing verifier assertions, not a fresh test suite. |
| Client/document compatibility | Existing runtime compatibility verifier with correct UTF-8 read adapter | PASS. Current runtime hashes/fingerprint and document hooks remain compatible. |
| Preview/source handoff | Recompute all source/file hashes in static preview manifest | PASS, 15 source hashes and 16 preview/index file hashes. Capture remains explicitly pending; no visual acceptance is inferred. |
| Offline bundle manifest handoff | Map every `site/` entry to current docs and `review/` entry to current preview file, recompute hashes | PASS, 85 site entries and 16 review entries. ZIP bytes not checked; expected conventional local ZIP path was absent. Manifest parity is not a delivered-archive proof. |
| Current regenerated native manifest | Compare complete current helper cold/warm JSON with uncached baseline helper loaded directly from Git | PASS, all 85 files. New artifact digest `a69512776efa16b8049bc9c5387f2a1f74c812481b65e6202f9a83bea059b410`; generated metadata changed legitimately, so the earlier v2 artifact digest is not reused. |

Raw diagnostic observations:

```json
{"packet":"38becd17f6bc55bbdcd84dd48cd7d77b4278077d61880aed57342dd7667d6ac7","pins":43,"all":"PASS"}
{"unchangedRuntimeAndManuscriptPDF":7,"all":"PASS","paritySHA256":"9cf5213066a576292e5bd08c4197531cff429ff6915fa2270313faff2189baae"}
{"canonicalPagesEqualExceptExactRouteVersionSubstitution":6,"currentSnapshotsEqualExceptExactRouteVersionSubstitution":6,"all":"PASS","engineUnchanged":true}
{"nativeUncachedColdWarmParity":"PASS","files":85,"artifactDigest":"a69512776efa16b8049bc9c5387f2a1f74c812481b65e6202f9a83bea059b410"}
{"snapshotVerify":"PASS","routes":5,"articles":1}
{"runtimeCompatibilityVerify":"PASS"}
{"previewSourceHashes":15,"previewFileHashes":16,"bundleSiteEntries":85,"bundleReviewEntries":16,"all":"PASS","zipBytesIndependentlyChecked":false,"zipPathAvailable":false}
```

One initial diagnostic invocation failed in my adapter: runtime compatibility was passed Buffers, while its document parser expects strings (`TypeError: html.matchAll is not a function`, `tools/site/html.cjs:105`, reached through `runtime-compatibility.cjs:111`). Snapshot verification had completed before that adapter error. Inspection of the API established the expected string input; changing only the diagnostic callback to `readFileSync(..., 'utf8')` produced the recorded PASS. No candidate fix or repeated unchanged campaign was used. This is retained as a reviewer harness error, not hidden as product execution success.

## Reused evidence, allocation and acceptance limits

The first result's independent warm-cache mutation, rename/delete, symlink/non-file refusal, missing-directory and compressor-replacement observations remain applicable to unchanged helper/test bytes. They were not rerun or recounted as new executions. Current generated manifest parity was rerun because generated bytes changed.

I inspected `build.cjs` source/producer signature ownership and staged metadata/snapshot deltas, snapshot/runtime verifier owners and existing registry routes. Existing `tests/build-cohesion.test.cjs`, `tests/site-engine.test.cjs`, `tests/preview.test.cjs` own permanent PR-targeted/staging/production coverage through `tools/quality/source-tests.cjs` and the Basic/source workflow route under SITE-CHECK-PROFILES; hosted delivery retains its existing staging/production owners. No new regression suite, duplicated campaign or budget change is proposed. My focused native diagnostics are supplementary observations, not executions of those suites.

The continuation request reports a first full 75-module local run timed out with 74 completed modules, later setup/history/tooling repairs, publication-record tests 25/25, and an affected-scope result 111/112 with repository-lint awaiting a clean committed-Git precondition. Those campaign logs were not independently audited by this role. These reports supply no complete current-source campaign pass and cannot be relabelled as one. Neither the prior hosted timeout nor the reported local incomplete result is erased. The remaining clean-source CI check must retain its genuine prerequisite and fail-visible accounting. Original budgets, source/rights/control/artifact binding and all release decisions remain in force.

AC05/AC11 receive this bounded source-bound continuation. AC07/08/09/10 regression risk is reduced by unchanged manuscript/PDF, exact canonical document parity and locally verified generated dependencies. No whole AC, author editorial decision, live PDF URL, publication event, platform publication, visual acceptance or production observation is completed by this report.

## Verdict

**No blocking exploratory/interaction finding in the v3 generated closure.** Reader content, canonical link/markup behavior, current snapshot references, preview sources and native compression metadata are consistent with the inspected unchanged implementation. The generated delta warrants rebinding to its new artifact identity and has been independently checked here. Advancing to remaining clean-source checks is supported; release readiness remains pending complete exact-source acceptance and hosted/production observations. Provider internals and actual ZIP delivery remain outside observed evidence.
