# Exploratory / Interaction QA — first independent result

## Identity and inspected candidate

- Role/agent: Exploratory / Interaction QA, `/root/cache_exploratory`; nonauthor first judgment for owner #169 / PR170. No implementation or test edits, external writes, delegation, MEMORY, parent notes, private history or peer outputs were read.
- Runner launch parameters/accepted response are the orchestrator's receipt responsibility; this reviewer cannot independently attest provider context injection, model internals or isolation. Provider internals are unknown. The only follow-up received before judgment was a factual source-format update, not a peer verdict.
- Baseline HEAD observed: `fc205b17774ba703c63fdd7d142ddac178afffdd`. Prepared dirty candidate, **not a clean checkout**. `git status --short` shows only `tests/build-cohesion.test.cjs` and `tools/site/public-artifact.cjs` modified.
- Initial packet SHA256: `209ffec796c274ba5c1a02429eee79d4bf5f04d40c5d7ccfb8b2d5d412b58bdb`. Source formatting changed during inspection before a completed judgment. Final result is bound to **v2** packet SHA256 `18798370f6ea9667a7a60f0fe03688dc54d6575c378295341fca4e7fe24fa88d` and `cache-v2.diff` SHA256 `7bfe92637bf55b37073db51683154339f1bb619523663b986cb714b535547e10`.
- Final source SHA256: `tools/site/public-artifact.cjs` = `2814ddf9eae981e145f9ad351227d03d628ed52fbdf9943abf7babbf99a58419`; `tests/build-cohesion.test.cjs` = `341134612f3006afe912d1ac7007a9baa47c234632612632f4b4e5f68dcdd5d6`. Both match v2 packet. The formatter change was inspected in the final diff; actual-source cold/warm parity was rerun on v2.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- Scoped authority read: root AGENTS (`f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01`), CONTRIBUTING (`804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442`), README, relevant REPOSITORY-MAP entries and SITE-CHECK-PROFILES review/allocation/routes. No nested project AGENTS found. Supplied issue body SHA256 `fcca751ea21a7742ef4ca8eabe0dd89b1e966013ed7b059d33e086c0f7893376` includes original ACs and subsequent website-publication/distribution author amendments.

## Charter and actual surface

Bound: up to four minutes, small read-only diagnostics; no campaign. Explore the operator-visible manifest contract when identical byte inputs recur: cold/warm inventory parity, native gzip values, changed same-length bytes, rename/delete, invalid entries, missing directory and compressor replacement. Verify the correction does not turn old staging timeouts or local speed observations into production acceptance.

The changed runtime is a synchronous Node helper producing inventories and digests, not browser-rendered code. The public content reader receives the same artifact metadata for the same bytes; this helper never writes article/PDF/rendered assets. Therefore a new browser interaction exercise is **reasoned not applicable to this correction's changed surface**. Full hosted/article/PDF/mobile/no-JS acceptance remains a separate required observation; no browser result or physical-human usability claim is made here.

Environment: local Linux repository, Node `v24.22.1`, native Node fs/crypto/zlib/vm. The meaningful executable operator surface was `manifest(directory)` using actual generated `docs` plus an in-memory filesystem boundary fixture. The latter performed no disk mutation.

## Actions, oracles and accounting

| Case | Expected | Observed/accounting |
| --- | --- | --- |
| Existing real `docs`, cold and repeated warm calls | JSON, file metadata and artifact digest equal uncached HEAD helper | PASS. Loaded original helper directly from `git show HEAD:tools/site/public-artifact.cjs` into a separate VM; compared full serialized manifests. 85 files, including 2 PDFs, equal. Repeated on final v2 source: both cold and warm equal. |
| Every real file native oracle | SHA256, raw length and native `zlib.gzipSync(bytes).length` equal current file bytes | PASS. Independently read all 85 files and computed values; artifact digest `7d2a147be45c737c79f1dc35be5addd010b72406ff75efc83bb2bc3a0a334a48`. |
| Two equal-byte names, repeated call | Compression may be reused; both paths remain inventoried | PASS. Two calls, one actual compression. Full independent sorted native manifest oracle equal. |
| Same-length byte edit | Fresh digest/native gzip despite warm cache | PASS. Changed `same` to `Same`; native compression count increased to 2; serialized oracle equal. |
| Rename then delete | Current path inventory; no stale names | PASS. Oracle equal after each action. |
| Warm inventory sees symlink/non-file | Refuse, not silently reuse | PASS. VM filesystem supplied each kind; received existing `Symlink` / `Non-file` refusals. Simulated metadata, not a real OS symlink/device exercise. |
| Compressor function replacement | Invalidate old sizes and recompute | PASS. Replacement triggered recompression; total count 3. |
| Nonexistent real directory | Preserve native read failure | PASS. `ENOENT` thrown. |
| Eviction above 2048 unique inputs | Bounded cache, native recomputation on return to oldest | Inspected new existing test plus implementation and retained `cache-focused.log` (10 pass/0 fail); **not independently executed** in this role. |
| Whole staging/security/production campaign | Complete exact-source accounting before acceptance | **Not executed / not observed** under this bounded charter. Prior timeout remains failed, not a passing prerequisite. |

Independent virtual journey accounting: 6 full manifest parity assertions passed, 2 refusal assertions passed, native compression count assertions passed. Independent real-data parity and missing-directory checks passed. Read-only diagnostics exited 0. No full suite was run by this reviewer; retained author-focused results were read as evidence, not relabelled as this reviewer's execution.

Raw diagnostic output retained here:

```json
{"test":"real-docs baseline/cold/warm/native parity","verified":85,"pdf":2,"digest":"7d2a147be45c737c79f1dc35be5addd010b72406ff75efc83bb2bc3a0a334a48","missingDirectory":"ENOENT","node":"v24.22.1"}
{"test":"virtual boundary journeys","parityChecks":6,"nativeCompressionCalls":3,"symlink":"refused","nonFile":"refused","renameAndDelete":"current inventory","sameLengthEdit":"fresh digest/gzip","producerReplacement":"recompressed"}
```

Final-v2 raw readback:

```text
V2 exact-source cold/warm baseline parity: PASS, 85 files, artifactDigest 7d2a147be45c737c79f1dc35be5addd010b72406ff75efc83bb2bc3a0a334a48
```

## Operator impact and acceptance boundaries

The helper still rereads inventory, file type and bytes and hashes bytes on every manifest request. Only deterministic native gzip length is retained by content hash plus byte length. Rename/delete/path changes therefore remain visible; same-size edits cannot be hidden by mtime reuse. Cache contains sizes and keys, not file buffers; the entry count is bounded. Native zlib options are unchanged. There is no persistent or cross-run acceptance reuse, no caller/profile/timeout/workflow change, and no source/artifact admission bypass in the two-file correction.

Article/PDF/figure and other public files are outside the modified paths. Full manifest parity across all existing generated files, including both PDFs, supports unchanged packaging metadata for the actual inspected artifacts. This is not newly rendered five-page PDF acceptance, semantic editorial acceptance, actual HTTP delivery, content rights review, or proof that current production serves these bytes.

The old run 42119802341 is described in the neutral packet as an incomplete 75-module staging run with ETIMEDOUT at 300000 ms and build cancellation while security remained running. I did not unzip or independently audit that historical raw runner report. Nothing executed here changes its failed status or establishes the timeout's complete cause. The retained warm/cold timing samples support a local optimization opportunity; they do not establish that all required staging modules/security will finish within their unchanged budgets. Full original scenarios and complete accounting remain required at the final exact source.

AC impact: this review supplies a bounded correction review input to AC05/AC11 and checks against regression to AC07/08/09/10 content/asset behavior. It does not complete any whole AC or authorize publication. Owner #169/PR170 and the authorized website-first process remain the route; manual LinkedIn/Medium publication is not observed.

## Regression allocation and verdict

Existing regression owner: `tests/build-cohesion.test.cjs`, permanent registry entry in `tools/quality/test-profiles.json`, profiles `pr-targeted`, `staging`, `production`, inputs including `tools/site/**`; source runner selection → existing Basic/source route, `site-checks.yml` `checks`, plus applicable hosted owner routes. Existing new cases cover fresh inventory/native parity, mutation/rename/delete, invalid entries, compressor replacement and eviction. No new suite or duplicate campaign is proposed. Optional future strengthening: warm-cache filesystem read-error propagation can be added to this same suite if a future inventory/cache change touches that boundary; it is proposed, not executed or a present blocker.

**Verdict: no blocking exploratory/interaction finding in the final v2 prepared correction.** The examined risks were stale inventory after warm reuse, incorrect native gzip/artifact digest, concealed invalid entries, cross-function reuse and changed public/PDF bytes. Bounded observed parity and direct source inspection support advancing this correction to its remaining required checks, not release readiness. Acceptance stays limited by the dirty candidate, no complete current-source campaign, unobserved hosted/production outcomes and unknown provider internals.
