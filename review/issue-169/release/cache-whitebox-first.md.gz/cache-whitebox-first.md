# White-box QA — independent first result

Verdict: no blocking correctness finding in the bounded gzip-length cache correction. Independent read-only checks passed 14/14. This is partial component evidence for issue169 AC05/AC11; it does not establish clean-source, staging, production, full-profile, timing, editorial or rights acceptance.

## Identity and independence

Role: distinct nonauthor White-box QA, task `/root/cache_whitebox`, first judgment. Inspected only assigned packet, actual source/diff, instructions and authoritative owners. No MEMORY, author conversation, parent scratch notes, current peer output, external writes or delegation. The requested fresh-context launch and accepted tool/provider details must be supplied by the orchestrator's launch receipt; provider internals are not observable here. No unexpected author/peer verdict was exposed.

Repository HEAD: `fc205b17774ba703c63fdd7d142ddac178afffdd`; packet base `8cf15883125892710633b17133d9ee0fc4b23b92`, tree `a605aff62e7c2ae28ce2ff3f81f06c1efa0fea7e`. Working tree is a prepared dirty two-file subset, not a clean Git source. Actual final diff is 105 additions/1 deletion in tests and 29 additions/8 deletions in the producer. Existing test behavior is preserved; the one preexisting test diff is formatting.

The initial packet and source were inspected before the orchestrator disclosed a formatting correction. The single dynamic probe loaded the corrected producer bytes (its own printed source SHA is the v2 SHA below). Actual final source/diff were then reinspected and all v2 packet file pins verified. No initial verdict had been recorded before this correction; this report is the first result, bound to v2. The correction input contained format/pin facts and no peer verdict.

| Input | SHA-256 |
| --- | --- |
| Initial source packet | `209ffec796c274ba5c1a02429eee79d4bf5f04d40c5d7ccfb8b2d5d412b58bdb` |
| Corrected source packet | `18798370f6ea9667a7a60f0fe03688dc54d6575c378295341fca4e7fe24fa88d` |
| Corrected diff | `7bfe92637bf55b37073db51683154339f1bb619523663b986cb714b535547e10` |
| Issue169 intent/AC snapshot | `fcca751ea21a7742ef4ca8eabe0dd89b1e966013ed7b059d33e086c0f7893376` |
| Root instruction | `f8f13dd686d977fc90d8e9932c388842b3beedb046810a0be3c14302a9496d01` |
| Protocol | `804fb3da9a0bc7369bbd902313224221becc6c6b775536ca943f8664bf741442` |
| Common reviewer prompt | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` |
| White-box role prompt | `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f` |
| Executed producer | `2814ddf9eae981e145f9ad351227d03d628ed52fbdf9943abf7babbf99a58419` |
| Candidate test inventory | `341134612f3006afe912d1ac7007a9baa47c234632612632f4b4e5f68dcdd5d6` |


## Structural risk and checks

Independent oracle: sorted recursive path inventory, fresh native SHA-256 over each current Buffer, native `node:zlib.gzipSync(bytes).length`, and independent SHA-256 over serialized files. Oracle code does not call the candidate's digest or entries functions. The candidate source runs unmodified in a VM with an in-memory filesystem plus observable native crypto/gzip adapters; a separate actual read-only filesystem integration checks `site/content/shared` twice. All successful simulated manifest calls assert one file read and one content hash per file plus the artifact hash. Only metadata scalars are cached; no returned object or input Buffer is cached.

| Risk / invariant | Structural fault | Executed scenario and independent oracle | Result |
| --- | --- | --- | --- |
| AC05 exact current-byte identity | Cache keyed by path/mtime would hide edits | Equal-length edit with constant modeled mtime; current native digest/size oracle; fresh-read/hash counters | Pass |
| Duplicate bytes may share compression only | Reusing an entire manifest would hide paths/content | Cold/warm duplicates, cross-root different path, nested addition, delete and rename; exact serialized native oracle | Pass |
| Caller ownership | Returned object mutation could poison cache | Mutate gzip field, add forged file and alter artifactDigest; next native oracle | Pass |
| File-type refusals | Warm cache might bypass lstat guard | Substitute warmed file with symlink and fifo-like nonfile; specific refusal required | Pass |
| Filesystem/hash failure propagation | Memoization might bypass inventory/read/hash | Inject directory error, read error on warmed path and native hash adapter error; each must throw | Pass |
| Compression producer identity | Old size might survive producer replacement | Replace gzip function with native length+7 function, then restore original; both manifests must match corresponding oracle | Pass |
| Compression error path | Warm entry might survive producer replacement/failure | Throwing replacement producer refuses manifest; restore and independently verify recovery | Pass |
| Bounded cache | Entry growth/eviction might alter manifest | 2049 unique contents in one logical file, then return to oldest; 2049 initial gzip calls and one recomputation | Pass |
| Empty input | Cache behavior might change empty identity | Empty directory equals independent empty JSON/digest | Pass |
| Real filesystem boundary | Simulation might miss actual require/fs wiring | Actual `site/content/shared` inventory compared with separately read native hash/gzip oracle twice | Pass |

The same-mtime scenario models filesystem metadata rather than changing an on-disk file, honoring the read-only constraint. The candidate never reads mtime, and observed read/hash counters establish fresh bytes for each successful call. Symlink/nonfile and I/O failures were injected through the filesystem adapter, not created on disk. No percent/branch-coverage measurement is claimed.

## Executed accounting and raw observation

Command: one `node <<'NODE'` inline diagnostic in the repository; source loaded from `tools/site/public-artifact.cjs`, evaluated without edits via `vm.runInNewContext`; actual integration loaded the module with native `require`. The full inline command and raw JSON are retained in the tool execution transcript. Exit0, no signal; tool wall time0.087527396s. Node v24.22.1. This duration describes only this tiny probe.

Raw returned accounting:

```json
{
  "kind": "independent-whitebox-readonly-probe",
  "node": "v24.22.1",
  "sourceSha256": "2814ddf9eae981e145f9ad351227d03d628ed52fbdf9943abf7babbf99a58419",
  "passed": 14,
  "failed": 0,
  "counters": {"gzip": 2059, "reads": 2091, "stats": 2108, "dirs": 2090, "hashes": 4157},
  "filesystemWrites": 0
}
```

The counters belong to the instrumented VM component; the actual native filesystem check is additional. The14 scenarios correspond to the matrix; cold/warm duplicate reuse, same-size edit, inventory changes, result mutation, cross-root identity, symlink, nonfile, read failure, hash/inventory failure, producer replacement, producer throw/recovery, eviction, empty inventory and actual filesystem integration. All completed; no partial or skipped case in this diagnostic. Repository source/tests were not edited; this report is the only written artifact.

## Existing suite route and gaps

Inspected both added tests in `tests/build-cohesion.test.cjs`: native compression equivalence/reuse and2048-entry eviction. They exercise same-size/same-mtime edits, rename/deletion and synthetic symlink/nonfile rejection, plus producer replacement. The test registry routes this permanent module through `pr-targeted`, `staging` and `production`; the documented surviving command is `node tools/quality/source-tests.cjs --profile production`. The added cases reuse this module, without reducing old assertions/scenarios. Additional independently exercised negative cases above could be retained in that module if future regression experience warrants it; no test changes are proposed as a prerequisite of this correction.

Existing test files were inspected, not executed by this reviewer. The independent probe is not a full build-cohesion module run or full campaign. Existing focused-log and manifest-timing packet artifacts were not used as a correctness oracle. Hosted75-module completion, original300000ms worker budget, original workflow deadlines, browser/product limits and aggregate report completeness remain for exact-source campaign verification. Git diff confirms no budget/runner/workflow file changes in this prepared subset. The packet reports the preserved historical ETIMEDOUT300000ms/incomplete75-module staging failure; this reviewer did not independently open that archive and makes no claim the correction resolves it. No inference about staging/production elapsed time follows from the probe.

Unexecuted/limited surfaces: full artifact/build/controller integration, real on-disk mtime edits and special files, platform-specific filesystems, cross-process behavior and release/hosted checks. Cross-process persistence is intentionally absent; cache entries are process-local native-gzip lengths. SHA-256 collision resistance and native gzip determinism under a stable producer are the existing content-identity assumptions, not independently proven here. There is no changed UI/operator surface in this component; broader publication/device gates remain outside this review.

No blocking defect found. Advance only to the remaining exact-source verification and other required decisions; retain the historical failed campaign and this bounded evidence separately.
