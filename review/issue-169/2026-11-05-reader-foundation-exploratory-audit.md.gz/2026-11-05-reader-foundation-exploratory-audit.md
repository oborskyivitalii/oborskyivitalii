# Reader foundation: real-flow audit and latest diagnostic failure

Refs #169 / PR170; read-only continuation of Exploratory QA. Production advancement is paused by the latest author instruction while the shared reader/navigation/delivery foundation is audited. No app/QA/assertion/budget changes, browser reruns or current peer-verdict reading occurred in this pass. Large raw files remain in scratch/CI. Provider model/context internals are unknown.

Inspected clean source `d3a49960714e5f158afba23d02dd0f8e871cb28e`, tree `64b5bf1c039b82abe3de0ae726c726e41aeaf0a9`. The report is a bounded source/actual-evidence audit, not a complete reader, hosted, staging or release pass.

## Latest actual result: a different history failure

Run [42105950320](https://github.com/oborskyivitalii/oborskyivitalii/actions/runs/42105950320), job127520697527, reports20pass,2fail,18not-observed across the unchanged40case/four-context plan. Elapsed52,466ms. Both first `forward-reader` cases now pass: current delivery-heading text has real non-pseudo same-node CSS start/end events,0.7s elapsed duration, and departure/arrival both complete by animationend. This is new evidence for the tested first Forward leg; it is not a pass for the unexecuted second cycles or the whole prior F2 charter.

Both failures are now `normal-WIDTH-cycle-1-forward-back`, at `restoration()`'s existing3-second wait. The route and animation complete correctly; the restored scroll position is stale.

| Width | Position recorded before Forward | Position after the following Back | Trace evidence |
| --- | --- | --- | --- |
| 1440 |574px |2163px | `call@416` after snapshot remains2163 at24522.248ms |
| 390 |1076px |3832px | `call@845` after snapshot remains3832 at46346.915ms |

The restored values are exactly the earlier card positions that the original first reader-Back successfully restored. The URL is correct `/writing.html?topic=delivery`. The expected focus in both cases is the same article link. Because `restoration()` stores its `actual` object only after its wait succeeds, the failure record omits direct actual-focus readback; this review does **not** invent a focus failure. The definite scroll mismatch already explains the wait failure.

Actual trace timing further narrows the mechanism: the new heading-position snapshot precedes Forward by about178ms on desktop and72ms on mobile. `navigation.js` persists scroll through a350ms debounce; `save()` refuses a location that resolves to a different document, and `saveDeparture()` saves click departures but skips pop navigations. Thus recent read-time scroll can miss the departing history entry before native Forward changes the location, and the subsequent Back uses the old card position. This is the strongest source-backed explanation; no extra waiting in the assertion can reconstruct a position that was not saved.

The sequence is a real user path: Back to an archive, read/scroll elsewhere, Forward, then Back again. It is not a requirement to wait350ms before using browser history. Keep the latest-position requirement explicit in the shared foundation contract; do not add a settle sleep to make this path disappear. A narrow regression should cover scroll immediately before native history traversal, both before and after the current persistence interval, while preserving entry count, unrelated history state, focus and recent intentional input. Application design/fixes remain outside this read-only task.

No page/console/request or evidence-capture errors are recorded. All six no-JS cases pass. Original normal legs captured/pass4of16; added history legs captured4of8, pass2. Both subsequent footer legs and all second cycles are not-observed. The correct final status remains failed. Prior18/2/20 run42100535479 remains preserved separately and must not be silently rewritten into the latest20/2/18 result.

## Real-flow coverage versus the current40case charter

“Test exists” and “current source has an executed pass” are separate columns. No source suites were rerun in this audit.

| User path or boundary | Existing coverage source | Audit assessment |
| --- | --- | --- |
| Writing topic → native R9 → Back; two repeats |40case probe's original cases plus filter cases | Source-bound and explicit, but latest execution reaches only the first cycle. It includes actual title/images/PDF/local targets, viewer open/close and exact native destinations. |
| Back → new reading position → Forward → Back | Added `forward-reader`/`forward-back` cases | This exposes the latest stale-position defect. Earlier28case evidence did not contain this path. Maintain it without timing accommodation. |
| Filter/history composition | `article-browser.cjs:normalJourney`, `article-tags-browser.cjs`, `archive.test.cjs` | Broader sources exercise topic, language query, tags, reset/reload and history. The40case probe covers topic only, including same-topic refresh. It does not establish every year/language/tag intersection. |
| History with recent input during asynchronous reads | `navigation.test.cjs` inherited smooth-scroll/input cases | Existing examples explicitly run the350ms timer before checking persistence. The ordinary Back/Forward test at line927 does not change the archive position between traversals. These are useful tests but do not represent the new immediate-scroll/history boundary. |
| Direct entry/bookmark, extensionless aliases, deep anchors and refresh | Maintained `article-browser.cjs` normal/native-history/fallback journeys; navigation/resource tests | Broader than the40case probe. Direct/native no-JS entry is exercised by the probe; the complete normal deep-refresh/anchor/native-entry inventory still requires its own current actual evidence. |
| Reader exit to every principal page and rapid retarget | Maintained article journey and navigation tests | The40case probe uses Writing and footer Talks only. Its success cannot replace every header destination, interrupted navigation or cancellation cleanup. |
| Image/reference/PDF controls and fallback | Common reader controller, article journey, synthetic reader-reference/material tests | R9 covers a hero image modal and PDF byte/link serving. Actual-size zoom, every diagram viewer, reference popovers, tables/code and presentation viewer are not established by that R9 probe. Do not infer them from the existence of the shared controls. |
| Optional tags/index unavailable or invalid | `article-tags-browser.cjs` blocked/invalid index journeys | Explicit maintained coverage exists; not included in the40case run. Native content availability must remain separate from optional recommendation success. |
| Motion Off/reduced/no-Canvas, no-JS | Maintained article fallback journeys; source fixtures;40probe no-JS contexts | The40case normal contexts force no-preference and verify actual motion. Its no-JS cases are useful; it does not execute the maintained Off/reduced/no-Canvas article cases or physical touch gestures. |
| Template/profile parity across publications | Shared template/AST adapter, reader-mode/site-articles fixtures, native candidate admission | Shared source is confirmed below; one selected R9 reader is not an executed cross-publication parity result. |
| Native bytes → Color package → hosted served reader | Artifact/snapshot/content-delivery contracts and hosted reader jobs | The40probe is exact loopback bytes, `fullGate:false`, unknown family unadmitted. It cannot establish Color/native retention parity, hosted identity or a release gate from a browser subset. |

## Shared template parity: what the source does and does not prove

There is one maintained article shell, `site/templates/pages/article.html`, assembled by `tools/site/articles.cjs` and the shared `tools/site/reader.cjs` AST adapter. Shared Contents and reader-tools templates supply the common controls. The shell owns title/byline/contents/body/closing/tags/related/appendices/end navigation; profile-bound optional AST roles and material/presentation adapters add finite features. This is a common owner route, not evidence of separate per-article reader implementations.

Current publication source inventory has one accepted native R9 article, a synthetic draft reader-reference, a review PMDay AI article, and a draft PMDay two-shifts article. Their profiles/features differ. The `reader-mode.test.cjs` source fixture verifies another article through the same adapter and preserves source/platform AST; `site-articles.test.cjs` creates a controlled synthetic catalog/publication inventory. These establish structural/generative properties, not current browser acceptance of each exact draft/review edition.

The maintained `articleJourney` chooses the first descriptor for its actual document journey and lists the other available documents. `article-tags-browser` similarly selects one eligible reader. Consequently, merely adding another admitted/candidate article does not demonstrate that all profiles' optional controls and long-content geometry have been exercised. The bounded R9 diagnostic also pins one article/PDF explicitly. This selection should be visible in every foundation claim and test-allocation receipt.

A foundation audit should map representative feature cases to the common contract—short illustrated R9, long/cited text, quotations/endnotes, table/code, presentation/material links and technical reference controls—then distinguish static shared-template parity, synthetic fixture execution and exact selected-edition browser execution. Reuse the existing owner/profile/test routes. Do not create another renderer, recommendation engine, release system or blanket per-PR browser matrix. The present source check alone neither publishes other PRs' manuscripts nor grants their editorial/rights decisions.

## Next read-only audit/acceptance priorities

1. Confirm the canonical native reading/history contract for recent positions, input and filter state. The latest actual failure is a concrete foundation gap, not a reason to expand the article's release campaign repeatedly by guess.
2. Reconcile maintained case → suite/profile/workflow routes and actual source identities for entry/exit/filter/history/deep link/motion/failure paths. Distinguish production admission proof from controlled fixtures and diagnostics. Preserve every failed run and its limits.
3. Audit the history fixture's event/timer model against native traversal. Meaningful negatives must represent recent scroll before a pop navigation, not only click navigation or a manually flushed timer. Retain original timing and resource budgets.
4. Establish the representative shared-template/profile matrix above and the selected-publication limits of current collectors. Resolve the entry/exit/history foundation before using another article/PR's nominal green status as acceptance for R9.
5. When work resumes after the audit, require independently reviewed source corrections and current actual observations. Production remains paused; no merge/deploy/staging/rights-policy advancement is performed or authorized by this report.

A small evidence-quality improvement to consider later: retain actual URL/scroll/focus at the start of restoration and on timeout. Today the trace supplies the scroll diagnosis, while the failed report omits actual focus. This is a proposed audit finding, not a QA edit or an assertion relaxation.

## Exact evidence receipt

Artifact13451702106: scratch `tmp/r9-owner-diagnostic-failure/diagnostic.zip`, SHA256 `b504821653f82db284894a5ab71c66034282584a19c4c0529588896b0718f8af`, independently recomputed against the supplied GitHub digest. Raw report SHA256 `a3c12c99aa146b98397d555de2e2214197dad1d9b32ac5f53b127c07b4ce6984`. Raw report is the archive's source-bound failed diagnostic; no new browser run was performed.

Actual Color `8a7416d0fa9713b75bdd818a655291c414f74fc9e23aa9de33e0464022f56786`, base engine `bc0bc4c430599eb8448a7289d818649f7ebaa534889c8bd289d5d30b545ab943`, public digest `e352f80d3f0b4a0555256024b580adbe49ba2cd5eeff169ddd2dc1a34569f8d0`. Manifest SHA256 `903d7551036af47dd9fb1e32f9a66c088268e333fdd30fefc60915b56a7e383f`; observation script unchanged `09e995a1726da63b7eeea7778f12a1af93a68f79798c35f6b1b36c98975984d9`. Source/workflow/candidate/HEAD agree atd3a499; clean start and initial public verification pass. Success-only final public/clean checks were not reached.

Inspected static owners SHA256: article shell `6b4d543a6b4f5c1374f047d90850d9c0ecc3abe0e07f4c610e8408297cf7236a`; shared reader adapter `6ae95e796e6bd8b9b4bd03a30f92c44cfead057c525d88b2e1a85fe5d6d7072f`; article assembly `78eba91a08bd9a83d4c4c644216968ce99a80382631302792a7971f24ee57954`; navigation `bab45afc73a36333f4b4ee3e81a7fc4fa19762f50d92dd5b82dad345fb82011b`; maintained article browser helper `b52c67fca8ce592531d1574b5886b95d2dd95f614b460bcecf460c229f36b05c`.

No physical-device, exhaustive accessibility/performance, complete theme/engine matrix, exact cross-publication delivery, new hosted or production result is claimed. Missing observations remain open.
