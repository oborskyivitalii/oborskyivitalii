# Requirements & Acceptance — independent first R12 preflight

Verdict: the supplied accepted content change is sufficiently defined to author R12. No additional editorial decision is needed for the exact three paragraphs and closing question. Current acceptance-policy phase descriptions conflict with the latest accepted scope and must be corrected before claiming this increment accepted. PDF fit, actual candidate RI fit and completed-candidate acceptance remain unobserved; this is a preflight, not a pass for R12 deliverables or release.

## Identity and independence

Role execution: `/root/r12_requirements_clean`, first judgment, 10 November 2026. Requested launch: fork none, model/effort omitted, per task supplied to this execution. Actual provider model/context internals and any platform memory injection are unknown; I cannot attest to them. The accessible task contains no author conversation or peer judgments. I read no peer result, parent scratch notes, MEMORY or private history. Follow-up messages supplied additional scope facts/options; these were treated as claims and checked against primary contracts/files, not accepted verdicts. This receipt establishes bounded operational separation, not provider isolation. Orchestrator must retain actual accepted launch evidence and platform-memory audit; unknown applicable author-history injection cannot be called clean or support dependent acceptance.

Packet `/tmp/issue169-r12/preflight-packet-v2.json` SHA256 `a4dcea20f3e6784c3c5218359aa6faa5e422ff6abc34c7261266f7258a97eaf0`; every referenced file digest matched on inspection. Scope-v2 SHA256 `249b8c653b32d8254b74c67c0f2cdfeec9403da2631f4c46562035e6d2606860`. HEAD `a9f576918defbed3950c8ab95b4161be26e56ade`; `git status --short` empty when checked. No PR or R12 candidate yet. Issue/author instruction is explicitly dated supplied text, not independently refreshed GitHub observation.

Common contract SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`; CONTRIBUTING `a175f65e207b653b323f81a7543bea5a80f1f49b8ab6c9666c63656727667f65`.

## Findings and treatments

1. **High, phase-policy mismatch — `.github/acceptance/issue-169.json`, gates COPY/EDITORIAL/HISTORY/DELIVERY/TECHNICAL.** COPY says prepare complete external copies now; EDITORIAL binds R11 acceptance and stable continuation; HISTORY says publication instruction supersedes no-publish boundaries. These conflict with scope-v2's R12 Draft PR plus exact preview STOP and deferred platform generation/revision. Preserve original AC IDs/full issue obligations and historical decisions, but explicitly select the current R12 increment and list future release/platform gates as pending. R11 acceptance cannot approve R12 PDF or authorize merge/stable/production. Generic ARTICLE-WORKFLOW preparation guidance is superseded for this issue phase by the explicit later author instruction; do not change the generic engine/workflow merely to align this exception. Affects AC04/05/06/09/11.

2. **Medium, material approval/parity hazard — `materials.json` source R11 and `reading-pdf-r11` approval.** Changing manuscript/edition while retaining the old current-material binding would either fail the source-bound contract or advertise an obsolete PDF as matching R12. Preserve R11 files/edition byte-exact, create R12 source/semantic edition and distinct PDF identity, and keep new PDF approval null until actual review. Delivery as a separate review artifact is valid while public-material approval is pending. Do not transplant the R11 review binding. This is separate from prose acceptance: supplied scope already accepts the exact replacement prose, so retaining `publication.status: accepted` for that prose is defensible. It supplies neither PDF author approval nor deployment permission. The existing catalog route can therefore remain available without a new per-PR preview workflow exception. The actual renderer/catalog selection and approved materials behavior still require candidate verification. Affects AC07/09; no requirement to remove the catalog or edit site-color-review.yml is inferred.

3. **Medium, PDF feasibility is bounded but not yet proven — factual producer `review/issue-169/r10/pdf-renderer.py.txt`.** Adapter consumes the native AST and uses ReportLab A4, body10.2pt/leading13.6pt/gap2.5pt; R11 material source record independently records adjusted body leading13.2pt/gap1.5pt, references9.1pt, diagrams460pt and five pages. Do not mistake original R10 parameters for exact R11 layout. The accepted replacement lengthens the ending, so an unchanged layout cannot be presumed to remain five pages. Structural stream compression is compatible with preserving text/links/images but cannot fix page count; PDF-only hero reduction near250dpi is explicitly permitted, whereas diagram pixel bytes and source/site images are invariant. If layout changes are necessary they require actual inspection and separate author decision; do not silently infer approval. Affects AC08/09.

No content requirement defect found in the accepted passage: it extends the already present system/economic argument to upstream selection, organisational authority and bounded pilots, retains conditional language and introduces no quantitative empirical claim. Existing empirical statements, positive evidence, bounded synthesis note, recovery constraints, references, author apparatus and five visuals should remain unchanged. The full resulting ending needs rereading for coherent transition into the retained pilot example.

## Storage feasibility and exact observations

I measured sizes using RI's actual ignored-directory/output rules, without running its build/tests: 2,640 hashed inputs, **249,998,538 bytes**, leaving **1,462 bytes** under unchanged `MAX_HASH_TOTAL_BYTES=250,000,000`. This is a size inventory, not successful RI verification. Producer `tools/repository_intelligence.py` SHA256 `dad68d88d241c2cd223081d6a28961c1aa7abc19c0f4c223c9c3382c562aa792` retains per-file32,000,000 bytes, decoded text2,000,000/file and50,000,000 total. Material contract retains2MB/file and16MB newly selected material.

The ten remaining substantial v6 loose HTML files examined offer **1,258,236 bytes** aggregate raw-to-deterministic-gzip savings before locator/metadata overhead. Example `review/site-v1-20261002-v6-research-day.html`:208,428 original bytes, gzip25,528, SHA256 `13305118117ea0ed692fe6256175e3c3a4af8db01cb3a24789aeb3f226628e22`. This supports narrow compression feasibility, not a final minimum subset or sufficient candidate fit. Targeted searches of tools/tests/site/.github found these old paths only as repository-path inventory entries, with no runtime/test producer consumer found in those searched owners. Update inventory/catalog references and retain honest original-path locators plus original digest, decoded size, archive digest and recovery command. Preserve historical manifests as original-byte manifests; RI hashes the new physical archives/locators normally. No threshold/exclusion change is warranted.

Additional checked storage option: unchanged `review/site-v1-20261002-v6.zip`, SHA256 `afe6784c18da5d5be6f4311d153e870bccd3ab7e8cb10275a883476b45a8cb42`, already holds exact byte matches for these three loose files, each under the identical `review/` ZIP member path:

| Suffix after `site-v1-20261002-v6-` | Original bytes | Original SHA256 |
| --- | ---: | --- |
| day.html |219798|fc9feac3278c6028e5209c695e37e36bbe0393a2b2bec4c21b4d6bdcd1d4b49a|
| night.html |219825|cc9391abc5ad09214d66e369fae330c6b811cae81a34c5e7f17607b42a849e30|
| interactive.html |243721|f5c243f9bbaed9b197ed926f3f5ae1dbe672e5bfde23d317d285612b338a5a8b|

Thus replacing only those recoverable loose duplicates with honest ZIP-member locators could recover683,344 bytes before locator overhead, without creating redundant gzip copies. This satisfies decoded-byte preservation, subject to explicit recording of this storage treatment in the implementation scope and final archive/locator verification. It must not be reported as gzip archival if ZIP is used. Use only the subset actually needed after measuring R12 additions. No preservation of old HTML's direct browser presentation is promised by scope; recovery remains mandatory.

## AC → gate → observation

| Intent/AC | Appropriate check or decision | Preflight observation |
| --- | --- | --- |
|AC02/07: accepted organisational/upstream scope and question|Exact source comparison, full ending read, edition/semantic binding|Clear accepted text; R12 absent; no new empirical claim required|
|AC04/06: site-first Draft PR then STOP|Phase policy, Draft state and exact-source preview receipt|Current policy stale; no PR/preview observed|
|AC05/11: source integrity and review|Four actual fresh-role results, launch receipts, applicable source/RI/profile checks|This Requirements preflight only; subsequent roles/candidate review pending|
|AC08/09: matching five-page PDF|AST block/text order, exact URLs, five images/four captions, page count and all-page visual inspection; author PDF decision|R11 factual record:869,961 bytes,5pages,72blocks,17unique URLs; no R12 observations|
|AC05/09: fixed budgets and archives|Exact recovery/hash proof, whole-candidate RI build/verify, existing bounded checks|Storage options measured; final candidate fit unproven|
|AC10: Writing/related reading, stable route|Existing native/desktop/mobile/no-JS checks proportional to changed surface|Preserve current route/tags/component; no new recommendation engine|
|AC01/03 and original external AC09 obligations|Retained history plus later owner/platform decision|No wholesale issue closure or platform parity claim in this increment|

## Limits and next gate

Read-only source inspection, hashing, targeted consumer lookup, in-memory gzip sizing and ZIP-member byte comparison only. No test campaign, rendering, PDF regeneration, implementation or external write; only this assigned artifact written. Original R10 adapter SHA256 `853ac4b55b523410a30611c6431c7af654328459ae04855aa4cf9f1d92fb0c64`; factual R11 material review record `dee071eb94cad89de5583e21c15d7e5384d1aad992aaf12907b3e9edcabcc4f6`; manuscript `4bee7c727e2a4add666b48888028ea04750804841fa1c7249e0cc5120950a80d`.

Next: reconcile phase-specific acceptance language, author canonical R12 source first, then integrate native reader and separately reviewed PDF using preserved assets; measure actual additions before choosing smallest archive subset. Re-review changed requirements/policy and the completed candidate with all four roles; exact-source checks and preview remain required. Keep PDF/layout author acceptance, stable staging, merge, production and platform preparation/posting explicitly pending according to the current phase.
