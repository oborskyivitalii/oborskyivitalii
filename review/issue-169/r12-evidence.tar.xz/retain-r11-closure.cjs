const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process');
const root=process.cwd(),snapshot=require(root+'/tools/site/snapshot.cjs'),{documentElements}=require(root+'/tools/site/html.cjs');
const manifest=JSON.parse(fs.readFileSync('site/retained/manifest.json')),rights=JSON.parse(fs.readFileSync('site/rights.json'));
const starting=Object.keys(manifest.files).filter(x=>x.includes('a67b6e9f54e17606')||x.includes('080da808855bdc7c'));
const queue=[...starting],seen=new Set(),added=[];
while(queue.length){const rel=queue.shift();if(seen.has(rel))continue;seen.add(rel);if(!rel.endsWith('.html'))continue;
 const html=fs.readFileSync('site/retained/'+rel,'utf8'),base=new URL(rel,'https://retained.invalid/');
 for(const el of documentElements(html,{includeScriptSources:true}))for(const attr of ['href','src']){
  const val=el.attributes[attr];if(val===undefined)continue;const url=new URL(val,base);if(url.origin!==base.origin)continue;
  const name=decodeURIComponent(url.pathname.slice(1));if(!snapshot.immutable(name))continue;
  if(!manifest.files[name]){const b=cp.execFileSync('git',['show','79a275d47f63698c195f876fbffb194b5e68f750:docs/'+name],{maxBuffer:4000000});const sha=require('node:crypto').createHash('sha256').update(b).digest('hex');const p='site/retained/'+name;fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b);manifest.files[name]=sha;rights.retained[name]={sha256:sha,bases:['retained-edition']};added.push({path:p,sha256:sha,bytes:b.length});}
  queue.push(name);
 }
}
fs.writeFileSync('site/retained/manifest.json',JSON.stringify(manifest,null,2)+'\n');fs.writeFileSync('site/rights.json',JSON.stringify(rights,null,2)+'\n');fs.writeFileSync('/tmp/issue169-r12/closure-added.json',JSON.stringify({starting,added,visited:[...seen]},null,2)+'\n');process.stdout.write(JSON.stringify(added)+'\n');
