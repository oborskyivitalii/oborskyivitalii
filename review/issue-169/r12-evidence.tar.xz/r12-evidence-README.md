# R12 literal evidence

Local candidateb70022f and correctionsb0c85a4/75595e7 are recorded source identities,
not a claim those exact local commit IDs were published. Actual remote freeze47b9
and final PR source carry their own exact identities. Paper/reader bytes remain
unchanged through retention corrections; receipts and generated RI are separate.

Retain failed campaigns honestly:84cases/50pass34missinghistoricalcatalogblob;
then43/22pass21incompleteoldR11resourcedependencyfailures; completeclosure43/42pass
1missingtoolchainPython. Prefetch and normalclone resolve fixture assumptions;
full16-node historicalclosure is copiedbyte-exact frombase withoutguardchanges.
Last CLIenvironmentcase runs after installing exactlockedPillow13.0.0; its actual
result belongs in PR/source checkpoint, not inferred from installation.

ExistingR11 ASTReportLab reading adapter is reused; r12-model.json is the exact
validatednativeAST. Use archived renderer with ROOT/OUT/model paths adjusted to
reproduce the layout; PDF timestamps can differ. Optimizer removesASCII85/Flate
redundancy and resamplesonlydecorativehero to910px, keepingdiagram pixels.
FiveactualfinalPNGs were viewed by implementer and independentExploratory; PDF
is storedonce as authoredmaterial, not duplicatedhere. Fonts/body10pt/ref9.1pt
remainreadable; source74orderedblocks/17URLs unchanged. No final authorapproval.

Actual publicarticlepreview follows finalGitHubDraftPR. LocalUI was not used;
root provides realHTTP(S)URL toExploratory for nativeinspection. Platformkits
remain deferred. ParentPR185 is an explicit unmergedcapacity dependency.
