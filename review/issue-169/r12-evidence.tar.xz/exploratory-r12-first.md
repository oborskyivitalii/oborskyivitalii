# R12 independent Exploratory / Interaction QA — first result

Verdict: bounded PDF/artifact inspection PASS with no blocking perceptual defect found. Native website interaction remains NOT OBSERVED pending actual HTTP(S) preview; this is not whole AC08/09/10/11 acceptance, author approval, staging or production evidence.

## Identity and independence

Distinct nonauthor role, first judgment; requested fork=none per supplied assignment. No model/effort override supplied; accepted runner/provider context internals are unknown. Read supplied scope/ACs, common/role contracts, actual manuscript/PDF/HTML bytes, root instructions and check-profile owner. Did not read excluded MEMORY, mixed execution report/archive, private history or peer outputs. Root/source instructions require independent review; assignment's first-reading exclusions govern this bounded reviewer. No source/test edits, delegation, external writes or local browser attempts.

Repository /workspace/scratch/faafe921a49f/r12-work. Owner #169. Observed clean working tree; HEAD b70022f915590a5b574708d08c9f3dbe79b73665, tree ed99b0f55716f7931b9af78c937d11d8d3aa2c66. No independent remote-ref/PR assertion in this bounded review. Packet /tmp/issue169-r12/r12-candidate-packet.json SHA256 772fc0c1fb5ad341528952662a647233e080a48266a890b3ff2f9022e332cfeb, verified. Scope SHA256 249b8c653b32d8254b74c67c0f2cdfeec9403da2631f4c46562035e6d2606860 as supplied. Common contract SHA256 2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb; role SHA256 280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a, verified against actual bytes.

## Charter and bounded observations

Initial charter: <=3 minutes; walk all five rendered PDF pages in order, examine legibility/overlap/edge loss, figure-caption ordering, page transitions, ending/references/author apparatus, then independently check the three accepted paragraphs and exact closing question in PDF extraction. Website journey explicitly deferred to the real preview; source hashes alone do not pass UI.

Actual PDF site/assets/publications/sdlc-out-of-balance/materials/reading-r12.pdf SHA256 c3686dce007b399d3fb175d5b235a51b1000500a3e4bc6f024be9767bfb33996, verified. pdfinfo: 5 A4 pages, 516886 bytes, no encryption/JavaScript, untagged. Manuscript SHA256 4ed3380c73f46e7e9bf086fa2f1c99f5183fc0ccb16b7b1f270276173e5f1f8d, HTML SHA256 42fcfcd8d79914410fbdd940b2c30b29f30a80e7bdcec6eaab1f3d58e314b236, verified against packet.

| Case | Expected | Observed | Status |
|---|---|---|---|
| Page 1 | Title/date/R12, hero, diagnosis and capacity diagram readable | Full title and byline, hero, Figure 1 and caption visible; body clears footer; no overlap/cut-off observed | Executed/pass |
| Page 2 | Argument and dual-function review figure readable | Continuous body, Figure 2 labels/arrows/caption readable, comprehension-gap paragraph complete above generous lower whitespace | Executed/pass |
| Page 3 | Both conceptual figures and evidence claims readable | Figure 3 then Figure 4 with captions in sequence; evidence section and bottom text clear. Small figure annotation text is dense but available at supplied render | Executed/pass |
| Page 4 | New organisational passage before pilot, no bottom collision | All three new paragraphs present in readable body text before pilot; recovery paragraph continues onto page 5 without overlap | Executed/pass |
| Page 5 | Coherent ending, exact question, all references and author apparatus | Recovery continuation readable; prominent full question; references 1–13, evidence note, about-author, web/LinkedIn and rights line visible | Executed/pass |
| Exact accepted additions | Three paragraphs and closing question survive PDF text | pdftotext whitespace-normalized comparison of each exact manuscript paragraph and stripped-bold question returned True for all four | Executed/pass |
| Native article controls/navigation/mobile/no-JS | Actual preview journey required | No hosted preview supplied at first judgment; HTML byte identity only | Not observed/pending |
| PDF hyperlinks and assistive-tech reading | Working destinations and semantic reading order | No click or assistive-tech interaction executed; PDF is untagged | Not observed |

Visual raw evidence inspected using image viewer: /tmp/issue169-r12/R12/final-page-{1..5}.png. SHA256 in page order:

1. ef2bc775c76d422bac847db18f59fd7f8b4cd08a3e8b30527bbce6068398388d
2. fe9cbaecfe228bd343249ba24b631065aea9271d988eff9f8972a356abd8384a
3. 5c0414ca8f2b25cb382a34d63d8b8a84de5528b89b8a07e7d18c5b92067c1f73
4. 791010a758473bfb5ca045473d17388734c8060ba8cb6459ae6f9ef2bcac40f0
5. 8386c6e7681e17db6231e9c82eb1ae1caea9657c32b095eed3ff5eec07de5fe1

No blocking findings in inspected risks. Visual sweep cannot prove exact full-document semantic/link parity; extracted exact additions checked separately, other content compared as a reading journey. Supplied render provenance is not independently regenerated here. Physical print/mobile-device/human comprehension not established. R12 PDF/material approval remains null and delivery is separate as instructed. Platform adaptations are out of current phase.

## Existing allocation / next gate

Per guides/SITE-CHECK-PROFILES.md, keep manuscript/native-source parity in existing Content update source suites, actual article/Writing/reader desktop/mobile/no-JS journey in the existing affected hosted Content update/content staging allocation, and all-five-page visual review with the #169 VISUAL owner. This report is manual bounded evidence; no new suite or duplicate campaign authored. Proposed follow-up on actual Draft preview: open native article, navigate contents to Finding a new balance, check accepted passage and question, inspect figure/references/related-reading path, and record actual viewport/reader controls observed. Pending URL/access must remain pending rather than N/A. No release inference follows from a pass.
