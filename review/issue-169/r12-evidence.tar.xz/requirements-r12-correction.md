# Requirements & Acceptance — bounded R12 correction

Verdict: **affected requirements remain correctly scoped; acceptance advancement remains blocked by supplied failed closure checks until a passing exact-source replacement result is evidenced.** Current article/PDF can be delivered as proposed Draft-review artifacts with their actual pending status. This result does not approve full historical closure or readiness.

Same-role correction continuation of `/root/r12_requirements_clean`; original first judgments preserved. No peer output, mixed report/archive, MEMORY, implementation edits, external writes, delegation or broad test campaign. Provider/context internals remain unknown as previously stated.

Packet `/tmp/issue169-r12/r12-correction-packet.json` SHA256 `404ac10ee8d703b0295631641e6b6b1a14cc8d54d32651ab7152fd6334288730` verified. HEAD `b0c85a46b186117eeb49e2756527d8aee56bdea8`, tree `20eaa6d8618a8a8bb7dbd70e89928ae40ecd1525`, working tree clean on inspection. Scope remains `249b8c653b32d8254b74c67c0f2cdfeec9403da2631f4c46562035e6d2606860`; base is explicit unmerged PR185 `79a275d47f63698c195f876fbffb194b5e68f750`, not current-main acceptance. No further archive requirement is introduced.

## Affected source and reused findings

I independently confirmed manuscript, current native article HTML, proposed PDF, profile and acceptance-policy hashes equal both prior candidate packet and correction packet. Therefore previous exact prose/semantic/source, five-page516,886-byte PDF/font observations, pending PDF approval and Draft-preview-only/platform-deferred conclusions remain applicable. No new empirical/editorial/phase decision is needed.

New retained `runtime/1c34e64047482a214a50a115582adb08988fe8721f5ee651bd8a231a300e2cf7/analytics.js` is1,491bytes, SHA256 `1c34e64047482a214a50a115582adb08988fe8721f5ee651bd8a231a300e2cf7`, independently byte-identical to main's original `docs/runtime/.../analytics.js`. The retained manifest registers its exact digest; repository-path catalog registers historical purpose. Semantic comparison of rights JSON against b70022f9 found exactly one added retained analytics record, bases `retained-edition` and `original-code`; the large textual diff otherwise changes JSON formatting, not rights meaning. This correction is necessary for the requirement to retain the actual historical dependency rather than relying on current analytics being enabled. It does not change the250MB RI cap or release authority. I did not independently rerun RI build/verify or infer whole-candidate budget acceptance from this small addition.

## Finding requiring evidence reconciliation

**High — AC05/09/11, raw check accounting and retained closure.** At inspection the packet-listed `/tmp/issue169-r12/closure-corrected.tap` ends43tests,22pass,21fail; `/tmp/issue169-r12/fixture-corrected-b700.tap` also ends43tests,22pass,21fail. `/tmp/issue169-r12/targeted-b700.tap` retains84tests,50pass,34fail. The first failure in closure-corrected.tap reports missing historical article dependency `article-media/e9c3a80d51e554bc46719133faa73fec2d11fae3e80bee5eba2969b9472deac7/delivery-capacity-r6.webp`. This is concrete failed closure evidence, not a passing normal-clone result. The supplied fixture-diagnosis describes initial missing historical Git catalog blob/lazy-fetch behavior, but does not by itself prove these later missing-resource failures resolved.

Treatment: preserve these failed results; identify the exact later normal-clone source/run/result if it exists, and reconcile its observed scope and source binding before saying affected checks pass. No conclusion that tests pass can rest only on the packet's narrative. This review does not prescribe extra archive work or a speculative code change; the failure may reflect fixture/environment behavior requiring bounded diagnosis. Parent was notified of the evidence mismatch immediately. Until corrected evidence is supplied, historical full closure and readiness remain unverified.

| AC | Observation | Disposition |
| --- | --- | --- |
|AC02/07 accepted content|MD/native/PDF and phase policy byte-identical to reviewed candidate|Prior scoped pass reused|
|AC04/06 current delivery phase|Acceptance policy unchanged: actual Draft article preview plus separate PDF, STOP|Still applicable; hosted PR outcome not observed|
|AC05/09 historical dependency|Analytics exact original bytes plus manifest/catalog/rights declaration|Affected source treatment appropriate; full closure check presently failed|
|AC05/11 exact-source checks/review|Packet-listed corrected TAP remains failed|Pending replacement result; do not mark whole gate passed|
|Budget preservation|No cap/exclusion change in correction; no new archive task|Final RI/check observation remains separate|

Next gate: deliver the requested reviewable article/PDF honestly, reconcile actual affected-check evidence, and preserve PDF author approval and all stable/merge/production/platform work as pending. No author-history/provider attestation or peer outcome is inferred.
