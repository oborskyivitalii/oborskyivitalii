# Code / changed-artifact R12 correction review

Verdict: analytics correction is sound, but complete retention closure remains blocked by a concrete omitted-image dependency exposed in supplied corrected tests. Do not treat this correction as resolving the fixture campaign.

Continuation of my own first review; no peer verdicts or author/private history read. Earlier first result remains unchanged at `code-r12-first.md`. This continuation is not a newly fresh independent execution.

Candidate: `b0c85a46b186117eeb49e2756527d8aee56bdea8`, tree `20eaa6d8618a8a8bb7dbd70e89928ae40ecd1525`; observed clean native worktree. Compared to previously reviewed `b70022f915590a5b574708d08c9f3dbe79b73665`. Recomputed correction-packet SHA256 `404ac10ee8d703b0295631641e6b6b1a14cc8d54d32651ab7152fd6334288730`. Recomputed all nonexcluded packet source hashes: no mismatch. Original common/role prompt identities and first-review limitations continue.

## Checked correction

- Inspected complete analytics/retained-manifest/path-catalog diff and structural central rights JSON diff. Sole semantic rights change is an exact retained analytics record with retained-edition/original-code bases; formatting restoration introduces no other rights meaning change.
- Compared new 1491-byte analytics.js directly to original base `79a275d47f63698c195f876fbffb194b5e68f750:docs/runtime/1c34e64047482a214a50a115582adb08988fe8721f5ee651bd8a231a300e2cf7/analytics.js`: identical; SHA256 matches retained path/manifest.
- Both retained R11 article and Writing snapshot directly reference this exact analytics dependency.
- Diff confirms docs, site/publications, site/assets and issue169 acceptance policy unchanged since first review; prior article/PDF/source/profile review can be reused.
- Read supplied fixture diagnosis, corrected TAP error locations and unchanged snapshot dependency checker. No implementation or test edits made. No broad test rerun.

## Blocking finding

Severity: high for validation/retained-closure acceptance (AC05 and AC09); bounded current R12 article text/PDF is unaffected.

Location/evidence: `site/retained/article-snapshots/a67b6e9f54e17606a934aeab6b7ea1e747b1020213215e50c8613248f8cc6995/the-sdlc-is-out-of-balance.html` references `article-media/e9c3a80d51e554bc46719133faa73fec2d11fae3e80bee5eba2969b9472deac7/delivery-capacity-r6.webp`, which is absent from `site/retained/manifest.json` and source retention. `/tmp/issue169-r12/closure-corrected.tap` ends 43 tests, 22 pass, 21 fail; its first failure (line9) is precisely this missing snapshot dependency, asserted by `tools/site/snapshot.cjs:256`.

Mechanism: current output happens to regenerate the image, but fixture variants that replace/isolate the current article catalog no longer generate it. The newly retained historical HTML remains and has an unresolved local resource. Adding analytics solves only one dependency. Independent inspection also finds these directly referenced current diagram resources absent from retained source:
- `article-media/a2e3bbf68aff502306ba2ada61e75690eb81a3fffdf200a1034223983827097a/review-learning-r7.webp`
- `article-media/ca7ba278e0efe6e7fc12301ff5c0a4155a4efdcd5ce8c3e0aa1c757a0108a551/comprehension-gap-r7.webp`
- `article-media/8082d70ee11d652202f57db57cb427c704de971ba734b26905febc1ee000526f/asymmetry-r9.webp`

Treatment: preserve byte-exact required historical diagram resources through the established retention/rights/catalog owner and recheck affected source closure under existing fixture variants. Inspect all direct historical HTML dependencies, including current shared runtime reliance, so fixes do not merely reveal the next absent resource. Preserve failed campaign evidence. A final normal-clone campaign is reported running but no completed successful result was supplied/read; it cannot presently resolve this finding.

## Limits

No claim of hosted preview, author PDF acceptance, release/merge authority, whole inventory/RI/CI completion or successful final fixture campaign. Supplied closure-corrected TAP was read as raw evidence, not a peer conclusion. No external writes, delegation or source/test changes.

