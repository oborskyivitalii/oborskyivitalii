# Independent Code / changed-artifact R12 first review

Verdict: no blocking changed-artifact finding for the bounded Draft-PR/source/native-reader/PDF proposal. This is not release, merge, author-PDF acceptance, hosted-preview verification or approval of the unmerged archive dependency.

## Identity and scope

- Role: distinct nonauthor Code / changed-artifact reviewer, first judgment, task `/root/r12_code`.
- Requested launch: explicit none fork; no explicit model/effort override supplied. Provider model, memory injection and context internals are unknown. No author conversation, peer verdict, root scratch notes or excluded mixed report/evidence archive/MEMORY were read.
- Repository: native Git worktree `/workspace/scratch/faafe921a49f/r12-work`; observed clean status and HEAD `b70022f915590a5b574708d08c9f3dbe79b73665`, tree `ed99b0f55716f7931b9af78c937d11d8d3aa2c66`.
- Comparison base: `79a275d47f63698c195f876fbffb194b5e68f750`. Main identity supplied as `a9f576918defbed3950c8ab95b4161be26e56ade`; main is not the bounded diff base. Explicit PR185 dependency remains unmerged.
- Packet: `/tmp/issue169-r12/r12-candidate-packet.json`, independently recomputed SHA256 `772fc0c1fb5ad341528952662a647233e080a48266a890b3ff2f9022e332cfeb`.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- Read original accepted scope at `/tmp/issue169-r12/scope-v2.md`, root README/AGENTS, relevant CONTRIBUTING iteration protocol, source-owner route in REPOSITORY-MAP, site source contract, CODE-STYLE, ARTICLE-MATERIALS, relevant ARTICLE-WORKFLOW sections and issue169 acceptance changes. No nested AGENTS found under changed site/docs/.github scope.

## Actual inspection and checks

Read full canonical manuscript and source/profile/material/edition metadata, substantive source/acceptance/provenance diffs; inspected changed path inventory and semantic JSON differences for rights, retention and generated revision manifest. Some initially broad combined outputs truncated; narrowed reads and JSON structural comparisons recovered the substantive article and metadata scope. Excluded review records/archives, MEMORY and mechanical RI bulk diff were not substantively reviewed.

1. Recomputed all packet-listed nonexcluded repository file hashes: zero mismatch.
2. Ran existing `node tools/publishing/cli.cjs validate sdlc-out-of-balance`: success; committed R12 source SHA256 `4ed3380c73f46e7e9bf086fa2f1c99f5183fc0ccb16b7b1f270276173e5f1f8d`, commit `47b9a946a274a49b80cd3e7d88e08ad9a0f71bba`, blob `f09b1716861fe08aa533e636459d3d960b85d3ae`; seven sections, five figures.
3. Independently opened actual final PDF with PyMuPDF: five pages, 516886 bytes, SHA256 `c3686dce007b399d3fb175d5b235a51b1000500a3e4bc6f024be9767bfb33996`; title/author and R12 dated subject are coherent. Five embedded images and seventeen unique URI links observed. Extracted text contains new upstream passage, new organisation-wide question and R12 edition; old question absent.
4. Inspected raw supplied parity and optimisation JSON as bounded recorded evidence, not independent proof of all 74-block ordering, image pixel equality or visual layout. Own checks confirm key new text/native presence, PDF counts and links.
5. Native generated article includes new passage and excludes old question. New pending PDF download is absent from native article; generated revision removes current download declaration. This matches `approval: null` exclusion under ARTICLE-MATERIALS and the separate-PDF review delivery instruction.
6. Compared R11 original PDF and R11 edition bytes against base: unchanged. Independently recomputed new retained R11 PDF, prior article HTML and Writing HTML hashes against retention manifest: exact.
7. Structural comparison of central rights JSON shows only four additions: R12 PDF rights and three retained original records; prior rights statements unchanged despite formatting churn. Retained manifest adds precisely those three files.
8. No tools, engine or template changes in bounded diff. Runtime architecture/dependency and CSS refactoring obligations therefore have no changed implementation surface; existing schema/pin validation is the meaningful focused code check.

## Findings and AC impact

No blocking defects observed in examined metadata/source binding, accepted three-paragraph/question integration, conditional synthesis framing, semantic-edition bump, null material approval, rights additions, R11 retention, absence of engine changes or website-first phase language (AC02/04/05/07/08/09/10/11).

The full ending remains coherent: organisational authority precedes bounded pilots, retained recovery drill and business outcome constraints. Empirical paragraphs/references remain unchanged by this editorial diff.

## Limits and required dispositions

- This role does not establish all four mandatory independent roles, full RI/Basic/CI results, whole inventory budget, author visual acceptance, actual Draft PR creation or exact hosted preview.
- No browser interaction, device run, visual PNG/PDF layout audit or complete PDF paragraph-by-paragraph sequence comparison performed by this role. Own PDF checks are structural/textual and narrower than raw parity report.
- The one-off PDF adapter/layout was not supplied as an accessible source reference in the packet; I reviewed its actual output and raw optimisation accounting, not its implementation or regeneration reproducibility. This limits reproducibility assurance, without inventing an engine-change requirement.
- No external research URL freshness or source scientific claims were revalidated; this revision adds no empirical claim and retains explicit synthesis limits.
- R12 PDF author/layout approval remains pending; `approval: null` correctly prevents public material selection. Deliver exact reviewed PDF separately with Draft PR preview and stop.
- PR185 archive/cap-headroom implementation is an explicit parent dependency outside this bounded diff; this review grants no merge/staging authority for it or R12.

