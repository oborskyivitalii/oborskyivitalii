from pathlib import Path
from io import BytesIO
import json, struct, zlib, hashlib
from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, NumberObject, DictionaryObject

SOURCE = Path('/tmp/issue169-r12/R12/The_SDLC_Is_Out_of_Balance_R12.pdf')
OUT = Path('/tmp/issue169-r12/R12')

def png_payload(raw, width, height):
    image = Image.frombytes('RGB', (width, height), raw)
    buf = BytesIO()
    image.save(buf, format='PNG', optimize=True, compress_level=9)
    data = buf.getvalue()
    cursor, chunks = 8, []
    while cursor < len(data):
        size = struct.unpack('>I', data[cursor:cursor+4])[0]
        kind = data[cursor+4:cursor+8]
        if kind == b'IDAT':
            chunks.append(data[cursor+8:cursor+8+size])
        cursor += size+12
    return b''.join(chunks)

def optimise(name, hero=False):
    writer = PdfWriter(clone_from=SOURCE)
    changed, seen = [], set()
    for page in writer.pages:
        for ref in page['/Resources'].get('/XObject', {}).values():
            obj = ref.get_object()
            if obj.get('/Subtype') != '/Image' or ref.idnum in seen:
                continue
            seen.add(ref.idnum)
            before = len(obj._data)
            filters = obj.get('/Filter')
            if '/DCTDecode' in filters:
                jpg = obj.get_data()
                if hero:
                    image = Image.open(BytesIO(jpg))
                    image.thumbnail((910, 910), Image.Resampling.LANCZOS)
                    buf = BytesIO()
                    image.save(buf, format='JPEG', quality=88, optimize=True, progressive=False, subsampling=0)
                    jpg = buf.getvalue()
                    obj[NameObject('/Width')] = NumberObject(image.width)
                    obj[NameObject('/Height')] = NumberObject(image.height)
                obj._data = jpg
                obj[NameObject('/Filter')] = NameObject('/DCTDecode')
            else:
                raw = obj.get_data()
                width, height = int(obj['/Width']), int(obj['/Height'])
                payload = png_payload(raw, width, height)
                raw_deflate = zlib.compress(raw, 9)
                obj._data = min((payload, raw_deflate), key=len)
                obj[NameObject('/Filter')] = NameObject('/FlateDecode')
                obj[NameObject('/DecodeParms')] = DictionaryObject({
                    NameObject('/Predictor'): NumberObject(15),
                    NameObject('/Colors'): NumberObject(3),
                    NameObject('/BitsPerComponent'): NumberObject(8),
                    NameObject('/Columns'): NumberObject(width),
                })
            if '/DCTDecode' not in filters and len(raw_deflate) <= len(payload):
                del obj['/DecodeParms']
            changed.append({'object': ref.idnum, 'before': before, 'after': len(obj._data), 'filters': str(filters)})
    for page in writer.pages:
        page.compress_content_streams(level=9)
    target = OUT / (name+'.pdf')
    writer.write(target)
    return {'path': str(target), 'bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'images': changed}

def signature(path):
    pdf = PdfReader(path)
    return {'pages':len(pdf.pages), 'text':[p.extract_text() for p in pdf.pages],
        'links': [[str(a.get_object().get('/A',{}).get('/URI','')) for a in p.get('/Annots',[])] for p in pdf.pages],
        'boxes': [str(p.mediabox) for p in pdf.pages], 'metadata':dict(pdf.metadata)}

results = [optimise('r12-lossless'), optimise('r12-compact-hero', hero=True)]
original = signature(SOURCE)
for result in results:
    actual = signature(result['path'])
    result['parity'] = {k: original[k] == actual[k] for k in original}
    result['saving_percent'] = round(100*(1-result['bytes']/SOURCE.stat().st_size),1)
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
