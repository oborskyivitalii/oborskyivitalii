# Requirements & Acceptance — final historical closure delta

Verdict: **PASS for the affected historical preservation, fixed-cap and unchanged phase/content requirements.** The prior missing-history source concern is resolved in this bounded review. Required check completion remains pending because the supplied latest campaign is42pass/1fail, not a full pass. The remaining failure identifies missing test-environment Python, not a missing retained resource. This does not block honest delivery of proposed article/PDF review artifacts, but cannot establish Ready/full acceptance or authorize release.

Same-role continuation `/root/r12_requirements_clean`, retaining prior first judgments. Packet SHA256 `fc083042251915ecf741bef6060f249b9f1b78177ffb0f539e519174a26505b4` verified; actual HEAD `75595e73c54c73a3198134bdfd10db8b54bc1ce4`, tree `7d640ce1e963195fd688c89672665231f3d02f4d`, working tree clean. Original accepted scope remains `249b8c653b32d8254b74c67c0f2cdfeec9403da2631f4c46562035e6d2606860`. Explicit unmerged PR185 base `79a275d47f63698c195f876fbffb194b5e68f750` remains a dependency rather than merged-main authority.

No peer judgments, excluded MEMORY, mixed report/archive or author conversation read. Provider model/context internals remain unknown; initial launch assurance remains as previously qualified. Source-only inspection, hashes, byte comparisons and file-size inventory; no implementation/tests edits, test campaign, external writes or delegation.

## Actual affected checks

For all nine newly retained files—five runtime files under `runtime/68fa384f47c646e4f2bc7d96c645f42efa6dabf9b84f5f514af4b959f561f72c/` and the four declared diagram WebPs—I independently compared actual bytes with their exact `docs/` paths at frozen main `a9f576918defbed3950c8ab95b4161be26e56ade`: every file matches. Each actual digest matches its declared closure-added record, retained manifest and rights registration. Earlier analytics preservation remains the separate1491-byte exact-base addition. Retaining the historical graph atomically protects history when current article/media/analytics selections change; it does not rewrite historical HTML or confer new rights.

I rehashed current R12 Markdown, native article HTML, PDF, profile and acceptance policy against the original reviewed b700 packet: all unchanged. Prior accepted-prose comparisons, five-page516,886-byte PDF identity `c3686dce007b399d3fb175d5b235a51b1000500a3e4bc6f024be9767bfb33996`, layout observations, pending PDF approval and Draft-preview-only/platform-deferred boundary therefore remain applicable without another paper/render campaign.

Size inventory using the actual RI ignored-directory/derived-output rules: **248,293,860 bytes**, leaving **1,706,140 bytes** beneath the unchanged **250,000,000-byte** cap. This checks physical byte headroom; it is not a replacement for RI deterministic build/verify or all per-file/text/count constraints. No cap/exclusion change or extra archive task is needed by these observations.

## Remaining check disposition

`/tmp/issue169-r12/full-closure-corrected.tap` actually completed43tests:42pass,1fail,0skipped. Its sole failure is case22, `publication actual edition and package CLIs freeze exact sidecars before any upload`, with `spawnSync /tmp/issue169-r12/check-source/tools/quality/toolchain/venv/bin/python ENOENT`. Earlier missing historical article-resource errors are absent from this final campaign. The exact failed result must remain retained; restore the required environment/dependency and obtain the bounded affected-case result before calling the campaign passed. Existing failed historical/lazy-fetch campaigns remain historical failed observations, not erased by this partial improvement. Parent was notified of the exact result.

| Affected obligation | Result / next gate |
| --- | --- |
|AC05/09 R11 immutable dependencies and rights|Nine new files independently exact-base and correctly registered; prior missing-history source concern cleared|
|AC05 unchanged RI budget|Physical size fits with1,706,140bytes headroom; actual RI verification separate|
|AC02/07 R12 accepted prose and source|Exact unchanged source; prior scoped acceptance reused|
|AC04/06 present delivery phase|Unchanged policy: actual Draft article preview plus separate proposed PDF; stop there|
|AC05/11 affected check completeness|42/43pass; one Python-environment failure pending, no full-pass claim|
|PDF/layout author acceptance and release/platform actions|Remain explicitly pending; no authority inherited from R11|

Proceed to the user's concrete Draft article PR/preview and revised PDF delivery within the existing phase, preserving accurate check accounting. Complete the bounded environmental check correction without expanding editorial, archive or platform scope. Full issue acceptance, stable staging, merge and production remain outside this verdict.
