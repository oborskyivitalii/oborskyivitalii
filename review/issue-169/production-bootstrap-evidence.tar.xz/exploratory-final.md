# Issue 169 — production bootstrap exploratory review, 2026-11-07

First independent result: **no blocking finding in the bounded prepared workflow/test delta**. This is a local operator/CLI assessment, not production readiness or a clean-consumer/native/live success claim. PB01's actual clean production build remains unobserved by this reviewer.

Reviewer: `/root/prod_bootstrap_exploratory`, distinct nonauthor Exploratory / Interaction QA. No implementation, external writes, delegation, current peer verdicts, parent notes or private history used. Requested context mode was explicitly reported as `fork_turns="none"` in the task; actual launch-tool receipt is the orchestrator's evidence. Provider context/model/memory internals are unknown. Shared filesystem is not isolation enforcement. No later reconciliation input preceded this first result.

## Source identity and scope

- Repository: `/workspace/scratch/a6215a1720e5/repo`; inspected HEAD `8e0aa848aba08dc9407832ed56d8a6404f985ae7`, dirty prepared state. Status showed changed candidate workflow and `tests/quality.test.cjs`, plus an untracked owning review document, which was not read.
- Packet: `final-packet.json`, SHA-256 `741342f553a18954c4bcef28c6d4da388519c46527d707a6e9e3e76c92d652e8`.
- Diff: `final.delta.diff`, SHA-256 `e5734b3fd120c40d7c584e0425c873fd6a952c5cce272e3663f65df5e3114eee`; independently recomputed `git diff -- .github/workflows/site-release-candidate.yml tests/quality.test.cjs` produced that same hash.
- Common prompt `agents/reviewers/README.md`: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `agents/reviewers/exploratory-interaction-qa.md`: `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a`.
- All 19 packet manifest files matched their declared hashes in the final local identity check. The packet omits a full-file digest for the changed test; supplemental inspected `tests/quality.test.cjs` hash is `3b2354926234793140efa50e5b687c273922deb2940964d5808e2f381672f777`, bound additionally by the matching diff.
- Read root AGENTS/CONTRIBUTING, README, relevant map routes, common/role prompts, review template, acceptance/check-profile/release/staging owners; inspected candidate and production workflows, canonical media action, article compiler, source reader, artifact/local gate, staging package, rights/archive/edition/live and browser consumers. No nested AGENTS files were found in the affected `.github`, `tests`, `tools`, `guides` or `agents` trees. Large initial map/log reads were truncated; conclusions below use subsequent bounded source reads and the exact failure excerpt.

Intent: publish the accepted exact R11 while preserving public/article/PDF bytes and existing gates; correct evidenced production dependency omissions within owner 169. Review criteria PB01–PB04 are those supplied in the packet.

## Charter and actual actions

Charter independently set before judgment: walk authenticated staging retrieval → isolated candidate dependency preparation → source-bound freeze/rights/package → frozen publisher → live navigation smoke. Explore missing, late, conditional and tolerated setup failure; distinguish compiler consumers from frozen-byte consumers. Bound: at most six local cases / ten minutes; no network, deployment, expensive full suite or staging campaign. Environment observed: Linux x64, Node `v24.22.1` (workflow pins `24.19.0`). Environment-status tool was not exposed.

| Case / expected result | Observed result and evidence | Disposition |
| --- | --- | --- |
| Exact inspected bytes remain bound to the supplied candidate | Packet, diff and 19 manifest checks matched; current two-file Git diff equals supplied diff | Executed/pass; prepared bytes only |
| Operator can find dependency preparation before the failed article consumer | Candidate build steps 4/5 install locked publisher and canonical media; step 6 freezes edition, step 7 inventories rights, step 10 builds package. Both setup steps are unconditional and fail closed | Executed/pass tabletop + parsed CLI inventory; source `.github/workflows/site-release-candidate.yml:71` |
| Missing/late/conditional/tolerated preparation must be rejected | Targeted regression passed, including in-memory removals, moved setup, `if: false`, `continue-on-error: true`; four audited jobs each retain a named consumer | Executed/pass targeted Node test; exact raw output below |
| Canonical media setup must bind one interpreter and avoid exporting a failed setup | Same test exercises action script under mocked POSIX/Windows paths; controlled requirement/install/verification failures throw and do not export environment | Executed/pass mocked action; no real Python/pip/native setup claimed |
| Independent production consumers should not borrow producer caches | Parsed both workflows; source-bound compiler path is candidate build. Candidate publish/http consume frozen records/bytes. Production publish installs quality toolchain/browser prerequisites before local-browser smoke; its live/archived rights checks use frozen validators. No additional article parser/media installation need found in these frozen consumers | Executed/pass source/operator audit; no actual fresh-runner success claim |
| Original failure is retained and recovery does not become retry-until-green | Original native log shows `article.cjs:347` → rights hosted inventory → edition build, missing publisher dependencies, exit 1. Baseline regression retained separately fails on missing media; current quality log reports 22/22. Failure and test outcomes are distinct | Read retained raw evidence; no failed campaign rerun |

Actual independent command:

```text
node --test --test-name-pattern='every article-compiling job prepares its own locked parser and canonical media' tests/quality.test.cjs
✔ every article-compiling job prepares its own locked parser and canonical media (76.307561ms)
ℹ tests 1
ℹ suites 0
ℹ pass 1
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 181.899926
exit_code: 0
```

Read-only evidence: `../evidence/production-candidate-first-failure.log`, `baseline-regression-failure.tap`, `quality-fixed.tap`. The latter two are retained executions by others, not my independent execution. Two exploratory source lookups used guessed filenames (`tools/quality/preview.cjs`, `tools/publishing/web-media.cjs`) that do not exist; these were inspection-command misses, not product failures. Subsequent direct inspection used the actual `local-browser.cjs`, Python media action and source adapter.

## Findings, applicability and acceptance limits

No blocking defect found in the examined operator journeys. The added preparation is before both the observed rights compilation failure and sibling source-bound package verification. It uses existing locks/action rather than changing versions, public content, budgets or authorization. Browser UI interaction is reasoned not applicable to this workflow-only delta: no interface/reader bytes change. Actual native setup and clean-source build are applicable but **not observed**, not N/A. No physical-device, hosted, live, production-success or protected-controller proof is supplied.

| Criterion | This review establishes | Remaining evidence |
| --- | --- | --- |
| PB01 | Correct source-bound setup ordering and targeted negative guard | Real clean-consumer parser/media build, exact-source native candidate run |
| PB02 | Source audit of isolated candidate build/publish/http and production authorization/publish/recovery; frozen consumers have reasoned no-change disposition | Native integrated execution, including later live smoke |
| PB03 | New targeted regression passes; missing/late/conditional/tolerated negatives execute; original failure remains distinguishable | Exact committed-source selected checks/full required route |
| PB04 | Two-file diff adds setup and regression only; observed gates/versions/public owners unchanged | Other role results, style/RI/CI/owner checks and new exact-head control admission/maintainer decision |

Regression allocation: the modified existing `tests/quality.test.cjs` test remains in the permanent `pr-targeted`, `staging`, `production` profiles via `tools/quality/test-profiles.json`; `node tools/quality/source-tests.cjs --profile production` is its registered route. Its missing/late/optional setup cases are existing executed coverage, not proposed additions. A real clean-consumer experiment and exact-source native/full route remain separate orchestrator-owned acceptance; no duplicate full campaign requested here. I did not inspect or modify the parallel `clean-consumer-8e` or `frozen-smoke` experiments.

No current-source publication, issue closure or production approval is inferred from this result. Source changes after the recorded hashes require affected re-review.
