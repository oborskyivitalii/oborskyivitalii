# Independent White-box QA — affected final review

Date: 2026-11-07. Reviewer `/root/prod_bootstrap_whitebox`; continuation of the first independent audit, not a new fresh-context launch. First judgment remains intact in `whitebox-first.md`. No peer outputs, private history or parent notes were read. Orchestrator supplied the final packet/diff and factual primary-check locations. Provider context/model/memory internals remain unknown.

**Affected source/test verdict: PASS, no blocking implementation finding.** The prepared change fixes both missing setups in the consuming job and the extended existing regression detects the original omission plus missing, late, conditional and non-fatal setup variants. **PB01 clean-consumer execution remains pending** at this review boundary; native/full/control and release decisions remain separate gates. This is not production readiness or successful candidate evidence.

## Exact reviewed identity

- Baseline HEAD `8e0aa848aba08dc9407832ed56d8a6404f985ae7`, branch `work/issue169-production-publisher-bootstrap`; prepared dirty checkout.
- Packet `final-packet.json` SHA-256 `741342f553a18954c4bcef28c6d4da388519c46527d707a6e9e3e76c92d652e8` independently verified. All19 listed source hashes independently match current bytes.
- `final.delta.diff` SHA-256 `e5734b3fd120c40d7c584e0425c873fd6a952c5cce272e3663f65df5e3114eee` matches the actual current `git diff -- .github/workflows/site-release-candidate.yml tests/quality.test.cjs` byte-for-byte.
- Current changed test SHA-256 `3b2354926234793140efa50e5b687c273922deb2940964d5808e2f381672f777`. The test is not a separate packet manifest row, so this report records its full current-file identity in addition to the verified base/diff binding.
- Common/role prompts unchanged from first result (`2bcb3978…faeb` / `832762ea…596f`). Applicable instructions, accepted PB01–PB04 intent and restrictions reused unchanged.
- Worktree also showed untracked `review/issue-169/2026-11-07-production-bootstrap.md`; it was not read as a source oracle and is outside this executable delta judgment.

## Findings resolved and integration reasoning

| Prior finding / criterion | Current source and independent oracle | Disposition |
| --- | --- | --- |
| WB-PB01 / PB01 | Candidate/build now runs `npm ci --prefix tools/publishing/toolchain --ignore-scripts` at workflow71–72, after pinned Node and before freeze. `article.compile` continues using the publisher-local exact declared parser modules. | Source correction accepted; clean-install/build observation still pending. |
| WB-PB02 / PB01/PB02 | Candidate/build invokes the existing canonical publication-media action at workflow73–74 before edition/rights selection. Action retains Python3.12.14, canonical Pillow/WebP verification and job-local `SITE_MEDIA_PYTHON` export. | Source correction accepted. Both direct rights compilation and package-gate source-build branches share this setup. |
| WB-PB03 / PB03 | Existing quality test now parses candidate/build alongside staging/linux/native, checks exact publisher command plus unconditional/fail-closed media setup before every matched consumer, and injects refusal variants. | Regression accepted; independently executed targeted test and extra sensitivity probes below. |
| PB02 sibling audit | Production workflow, parsers/media owners and frozen consumers unchanged. Complete table and dynamic fixture distinction in first result remain applicable. | No new setup in frozen candidate publish/HTTP or production publication/rollback/recovery justified. |
| PB04 | Executable diff changes4workflow lines plus the existing setup-contract test. Dependency declarations/locks, public/site source, versions, time budgets and gates unchanged. | Accepted for this delta; RI/style/native/full/control obligations remain. |

The first consumer block runs artifact accepted-generation copying, Color transformation, production edition build and source rights reconstruction. Both setups precede the entire block, so the fact that parser compilation is reached later within that shell step causes no ordering gap. Setup failures stop the candidate before public artifact upload. All subsequent rights build/verify and optional package source-check branches retain the same environment.

The browser distinction was rechecked against unchanged source identity: production smoke invokes inline-HTML `analytics-browser.isolationJourney`, descriptor/DOM `articleJourney`, and Color scene model construction. It does not invoke the separate source-cloning `analytics-browser.buildFixture/journeys` branch. Frozen rights verification still uses `rights-record`, and historical archives stay bound to their own bytes. No source or call-graph change invalidates the first audit's no-change dispositions.

## Test sensitivity and selection

The implemented assertion protects the consuming job rather than searching the whole workflow. Moving setup to another job leaves the consuming step list incomplete and fails. `consumers.length > 0` prevents a silently vacuous test if the covered entrypoint disappears. It checks both parser and media for each relevant job and verifies setup occurs before all matched edition/rights/package or functional/staging-regression commands.

The test executes4jobs ×2setups ×4negative variants =32in-memory rejection cases: remove, append after consumers, `if: 'false'`, and `continue-on-error: true`. Existing action script tests retain the Unix/Windows interpreter paths and install/verification failure behavior; failures do not export an interpreter. These are structural/contract scenarios, not measured branch coverage or actual package installation.

I independently extracted the actual current `prepared` function into a read-only VM probe. Actual candidate steps passed; baseline8e0aa848 candidate steps failed; parser-only absence failed; changing the parser command to the quality prefix, `npm install`, or omitting `--ignore-scripts` each failed with the parser-specific missing-setup assertion. This verifies that the green current test does not merely accept a vague npm token. No source or test file was mutated.

Registry changes are unnecessary: existing `tests/quality.test.cjs` input ownership includes workflows, publication-media action, Python media owner and canonical requirements, and the test remains permanent in PR/staging/production. The new assertion does not read publisher package declarations/locks, so no new registry input for those bytes is needed. Actual `source-tests.select` calls independently confirmed quality-test inclusion for candidate-workflow-only change, quality-test-only change, media-action-only change, staging and production. Selection checks did not execute the selected suites.

## Actual checks and raw evidence

1. Independently executed:

   `node --test --test-name-pattern='every article-compiling job prepares its own locked parser and canonical media' tests/quality.test.cjs`

   Exit0, `tests 1; suites 0; pass 1; fail 0; cancelled 0; skipped 0; todo 0; duration_ms 151.324415`.

2. Independently executed read-only source/selection probe, exit0:

   `selection PASS pr .github/workflows/site-release-candidate.yml`

   `selection PASS pr tests/quality.test.cjs`

   `selection PASS pr .github/actions/publication-media/action.yml`

   `selection PASS staging all permanent`

   `selection PASS production all permanent`

   `final source manifest PASS 19`

3. Independently executed actual assertion-function sensitivity probe, exit0:

   `reviewer sensitivity PASS: actual current positive; original baseline negative; quality-prefix/install-command/missing-ignore-scripts negatives; sibling-job setup cannot satisfy consuming steps`

4. Read supplied primary `baseline-regression-failure.tap`:1test,0pass,1fail,0skipped; error `media must be prepared in the consuming job`. Its stack uses an earlier prepared test-body line allocation; this raw failure corroborates the omission but is not claimed to prove execution of the final test bytes. The independent baseline probe above binds sensitivity to the final assertion.

5. Read supplied primary `quality-fixed.tap`:22tests,22pass,0fail/cancelled/skipped/todo, duration3662.600369ms; the new setup test is case15. This is supplied local evidence, not my rerun of the whole module or native evidence.

The original native failed log remains preserved and is not superseded by these bounded observations. The accepted-stage ZIP download/digest/unpack and clean-consumer experiment were reported as in progress or prepared by the orchestrator; I did not run, edit or inspect that experiment, and I do not claim its result. Local runtime remains Node24.22.1 rather than pinned native24.19.0.

## Remaining acceptance limits

PB02 dependency audit and PB03 regression sensitivity/selection are accepted for the reviewed executable delta. PB01 requires the pending isolated consumer's real parser/media/build result without borrowed dependency caches; retain its exact source, environment, raw commands, final accounting and public-byte binding. PB04's source-preservation conclusion applies to this diff, while applicable current-source RI/style/native/full/control checks remain required before advancement. No full suite, stage, browser/live request or production publication was executed by this reviewer. Later factual experiment results can be reviewed as a separate evidence addendum without rewriting this result.
