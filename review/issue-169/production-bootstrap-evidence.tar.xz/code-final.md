# Code / Artifact Review — production publisher bootstrap

Date: 2026-11-07. Role: independent nonauthor Code / Artifact Reviewer.
Execution: `/root/prod_bootstrap_code`; first judgment for this prepared final delta.
Owner: #169. Scope: PB01–PB04 in the supplied final packet.

## Verdict

No blocking code findings in the frozen workflow/test delta. The correction supplies the existing isolated publisher and media toolchains before their production-candidate consumers. The regression meaningfully rejects absent, late, conditional and tolerated-failure setup. Existing release guards and public/source behavior are unchanged by this delta.

This is acceptance of the inspected source correction, not a successful native production candidate, release authorization, or proof of clean-environment dependency installation. PB01's actual clean parser/build smoke and the current-source native/protected/full-route gates must retain their own exact-source evidence before advancement.

## Identity and isolation

- Git HEAD/base inspected: `8e0aa848aba08dc9407832ed56d8a6404f985ae7`.
- Checkout is dirty: the two reviewed source paths are modified; an untracked owning review report was present. No clean-checkout/native acceptance claim is made.
- Packet: `final-packet.json`, SHA-256 `741342f553a18954c4bcef28c6d4da388519c46527d707a6e9e3e76c92d652e8`.
- Frozen delta: `final.delta.diff`, SHA-256 `e5734b3fd120c40d7c584e0425c873fd6a952c5cce272e3663f65df5e3114eee`.
- Independently regenerated the two-path Git diff against the stated base: exact byte match with that frozen delta.
- Workflow SHA-256: `fd994835d43df8453ce9168b7654b63ad0903eed1ad40d7999bff70f02e0773a`.
- Test SHA-256: `3b2354926234793140efa50e5b687c273922deb2940964d5808e2f381672f777`.
- Common prompt: `agents/reviewers/README.md`, SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`.
- Role prompt: `agents/reviewers/code-review.md`, SHA-256 `26b3fba125bf65126455bcd1aa7d2500d4f1766f2865bae5041378893a970697`.
- All 19 supplied manifest entries matched their actual bytes when inspected.
- Task explicitly specifies a none-fork launch; actual launch acceptance receipt belongs to the orchestrator. Provider model/context internals are unknown. No current peer result, author conversation, parent scratch notes, private history or unrelated memory was read. No recursive delegation, implementation or external write occurred.

## Inspected source and failure mechanism

Read root AGENTS, README, applicable CONTRIBUTING reviewer/iteration/test-impact instructions, the common and role prompts, source/acceptance/style contracts, relevant map and profile entries, release/staging owners, complete two-path diff, both production workflows and the canonical media action. No nested AGENTS were found under the affected workflow/test/tool trees.

The retained original run log `../evidence/production-candidate-first-failure.log` shows run 42381347247 attempt 1 failing before upload/live writes. `edition.cjs build` calls `rights.write`; `rights.compile` calls `hostedInventory`; selected article loading reaches `article.compile` and rejects missing exact publisher packages at article.cjs:347. The original error is thus an actual isolated-job dependency omission, not a failed public-byte or policy check.

At site-release-candidate.yml:71–74 the added unconditional, fail-closed steps use the existing package lock with `npm ci --prefix tools/publishing/toolchain --ignore-scripts`, then the existing canonical publication-media action. They follow authenticated source/staging retrieval and precede the freeze step at line 75. No package declaration, package lock, interpreter version, action version or rendering source changes.

The parser performs explicit declared-version checks before launching the existing AST worker. The media action uses its pinned Python 3.12.14 interpreter, installs the exact Pillow requirement already declared by the media owner, verifies Pillow/WebP, and only then exports SITE_MEDIA_PYTHON. Reusing that action preserves the established media interpreter boundary and avoids introducing an independent setup owner.

## Isolated production consumer allocation

| Consumer | Actual dependency/use | Review disposition |
| --- | --- | --- |
| Candidate `build` | Accepted-generation artifact verification, Color/production derivation, article-backed rights compilation, package build with `verifySource: true` | New parser/media setup is in this same job and precedes the consumers. No quality browser installation is needed for those source/package commands. |
| Candidate `publish` | Downloads frozen preview package; package and edition verification; pinned Wrangler action | Verifies existing artifact bytes and records, not article source compilation. No publisher parser/media install added. Wrangler retains its existing action-managed installation. |
| Candidate `http` | Downloads frozen artifacts; HTTP observation and staging-admission reduction | Frozen-byte and network verification with Node/Python primitives; no article compiler/browser startup. No install added. |
| Production `authorization` / recovery control | Authenticates request, producer, protection and frozen records | Existing controller/authentication behavior remains untouched; no article compilation introduced. |
| Production `publish` archive/composition | Frozen rights/admission/archive verification, Python stdlib archive pack/unpack, Pages package composition | Consumes the accepted source artifact and frozen rights record; the candidate's `verifySource` compilation is not repeated here. Adding publisher/media tools here would not repair the observed candidate failure. |
| Production live policy | `live.cjs` verifies archived edition and bytes, hosted MIME/TLS/canonical/indexing and HTTP routes | No parser/media work. Existing Node/HTTP path remains unchanged. |
| Production live navigation | `local-browser.cjs --smoke` and article journey over the downloaded manifest/public bytes | Existing quality-toolchain npm install, Chromium OS dependency preparation and pinned browser archive restoration precede deployment and smoke. Article-browser consumes descriptors and DOM observations, not the Markdown compiler. No publisher/media omission found here. |

## Test and guard review

The existing tests/quality.test.cjs case at line 1197 is extended rather than creating an unselected test route. It parses each real workflow, checks that consumers exist, and requires both local parser and media setup before every matched consumer. Setup cannot be conditional or continue-on-error. It retains the existing canonical action interpreter/env/export behavior checks and controlled failures.

For each setup in staging/Linux/native fixture jobs and production-candidate build, the test actually invokes its contract on copies with setup deleted, moved after consumers, given `if: false`, or allowed to fail. Each must throw. These are substantive workflow omission/order/fail-closed negatives. The helper is small and scoped to one dependency contract; its current exact command recognition intentionally checks the approved locked installation boundary.

Selection is already permanent through the `tests/quality.test.cjs` registry entry: pr-targeted, staging and production, with `.github/workflows/**` among inputs and the existing source-tests route. No registry selection, refusal case, suite budget, runtime guard, release policy or original interpreter assertion is removed.

The packet's `baseline-regression-failure.tap` retains a real initial missing-media setup rejection (0/1 passing). Its helper line numbers identify that earlier regression version; it is not represented here as execution of the final strengthened test bytes. `quality-fixed.tap` records 22/22 passing in the supplied current quality run. Independently executed the final focused case below, including its built-in setup mutations.

Applicable style assessment: CS01 keeps orchestration in the workflow and assertions in its existing test; CS04 reuses the canonical media owner; CS05 follows touched code formatting and gives the helper a bounded concern; CS08 adds meaningful negative behavior and preserves selection; CS09's bounded guard passes; CS10 remains an orchestrator evidence/owning-AC obligation. Guard success is not a claim of full architectural or release compliance.

## Actual reviewer checks

| Action | Actual result / limit |
| --- | --- |
| `node --test --test-name-pattern='every article-compiling job prepares its own locked parser and canonical media' tests/quality.test.cjs` | PASS: 1 test, 1 pass, 0 fail/skipped; approximately 155 ms total. |
| `python3 tools/check_code_style.py` | PASS: 156 files scanned, 0 legacy occurrences; enforced inline-style/token-owner/history/literal-import subset only. |
| `git diff --check BASE -- .github/workflows/site-release-candidate.yml tests/quality.test.cjs` | PASS, no whitespace errors. |
| Packet/manifest/frozen diff verification | PASS as identities above. |

## Findings, limits and required continuation

Blocking findings: none. Nonblocking code changes requested: none.

Risks examined: separate-runner dependency isolation, setup ordering and failure propagation, missing media interpreter/environment, exact locked parser resolution, accidental browser/publisher dependency borrowing, selection loss, weakening of existing interpreter tests, changes to source/public identity and release guards.

This reviewer did not install dependencies in a fresh runner, execute a complete production build, launch browsers or a hosted/staging campaign, inspect live GitHub state, or observe production activation. The scoped source review therefore supports PB01/PB02's implementation allocation and PB03/PB04's reviewed invariants; it cannot close PB01's execution condition or any native/protected/live gate. Report/catalog/RI/verbatim receipt additions outside the frozen source delta are outside this review. If relevant source bytes change, affected re-review is required.
