# Requirements & Acceptance — first production-bootstrap preflight

Date: 2026-11-07. Owner: issue169; existing publication execution PR170.

## Verdict

The bounded correction is justified by primary failure evidence and can proceed under the supplied author publication instruction, subject to the mandatory dependency interpretation and verification below. This is pre-implementation requirements preflight, not candidate acceptance, protected integration approval, successful production preparation, or publication evidence. No implementation exists for this increment in the inspected checkout.

PB01/PB02 must cover both the locked Markdown parser and the canonical media interpreter wherever the actual consumer reconstructs selected article content. Installing only the parser does not satisfy these criteria. Record that allocation before editing/advancement; it follows existing source contracts and needs no new product or publication scope decision. No owner ambiguity about preserving R11/public bytes or avoiding platform posting was identified.

## Identity and independence

- Checkout: `/workspace/scratch/a6215a1720e5/repo`, HEAD `8e0aa848aba08dc9407832ed56d8a6404f985ae7`; clean at initial and final inspected status; origin is the requested GitHub repository.
- Packet: `production-bootstrap/preflight-packet.json`, SHA256 `53dd26af3e842fa18423f141d23dc665997b057c23407ff1b40663552a768a8d`. All19 referenced path hashes independently matched inspected bytes.
- Common prompt SHA256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt SHA256 `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`.
- Failure: `evidence/production-candidate-first-failure.log`, SHA256 `ea4932bb816273829fc62986bae9cad6f4eb97c94f02d6a17128d461488e1a9f`; actual logged parser dependency exception, Node24.19.0, exit1 in the edition/rights path.
- Task explicitly states none-fork; this reviewer received no author conversation or current peer results. Actual spawning tool response/launch parameters belong in the orchestrator receipt, not inferred here. Provider model/context/history internals remain unknown; operational read restrictions are not provider attestation.
- Read only packet, raw failure, current issue169 body via GitHub read API, applicable repository owners and necessary direct consumers. No private author history, parent notes, current peer output or unrelated MEMORY was inspected. Issue169 historical status is dated and not treated as live release evidence. No implementation, external writes, test generation, full suites, staging or delegation occurred. Only this assigned output was written.

## Primary source observations and requirements findings

### RA01 — High: parser setup alone leaves a directly reachable media prerequisite uncovered

Evidence: `.github/workflows/site-release-candidate.yml:41-75` provides Node but neither publishing npm install nor canonical media setup before `edition.cjs build`. `tools/release/edition.cjs:179-184` calls `rights.write`; `tools/release/rights.cjs:215-223` calls `reader.select`; `tools/site/articles.cjs:48-53` calls `publisher.loadArticle` and `article-media.render`. The observed failure stops in `tools/publishing/article.cjs:342-353` before later work. `tools/site/article-media.cjs:10-34,85-112` invokes the media Python process for `webp-lossless`; `site/publications/sdlc-out-of-balance/profile.json:36` selects that mode. `tools/publishing/web-media.py:17-36` requires the canonical Pillow pin and WebP1.6.0. The existing media action installs/verifies these and binds `SITE_MEDIA_PYTHON`.

Mechanism/AC impact: after parser repair, the same job still depends on an undeclared runner image media installation unless this existing prerequisite is supplied. This is source-backed dependency risk, not a claimed second observed native failure. PB01 clean setup and PB02 completeness cannot pass on parser installation alone.

Treatment: include existing locked publishing packages and existing canonical media setup before the first dependent candidate-build command; preserve existing dependency versions and action policy. Run a clean actual parser/selected-article/media path and production derivation smoke, rather than only checking npm command presence. Preserve the native failure.

### RA02 — Medium: PB03 needs a semantic setup oracle, not unrestricted text presence

Evidence: packet proposed scope says missing/late/excluded negatives “where useful,” whereas PB03 expressly requires rejection of missing/late/inapplicable setup. Existing workflow-sensitive coverage in `tests/release-controller.test.cjs:610-640` inspects summary wiring, not the complete dependency setup/consumer ordering contract. The permanent test registry already selects that module for production and changes to both affected workflows (`tools/quality/test-profiles.json:1801-1838`).

Mechanism/AC impact: an assertion that installation text appears somewhere could accept installation in another job, after its consumer, or behind an incompatible condition. Such a result cannot establish PB03 or compensate for PB01 runtime proof.

Treatment: minimal regression in the existing release-controller suite should check successful applicable job-local setup before the earliest actual dependent consumer, and demonstrate detection by missing, late and excluded/wrong-job variants. Check canonical media action identity/wiring if reused, including exported interpreter binding. Keep the existing suite/profile; expand registry dependency inputs only for newly read owners. Avoid demanding parser/media in jobs that only verify frozen records. Independent QA and Code must review the authored oracle; this preflight does not accept future tests.

## Isolated-consumer allocation

| Surface | Actual dependency path / disposition | Required evidence |
| --- | --- | --- |
| Frozen candidate build | Edition CLI and rights source verification reconstruct selected article: locked parser plus canonical Python/Pillow/WebP. Later package build uses `rights.readPublication(...verifySource:true)` and has the same needs. Existing job omits both. | Early applicable setup; clean selected-article/media/edition/rights/package smoke; exact new native frozen candidate success. |
| Candidate preview publish | `staging/package.verify` checks frozen rights record/public copies; `release/edition.verify` checks frozen files. No source article rebuild found. | Source-backed no-change disposition; existing exact-byte/project/controller checks retained. |
| Candidate HTTP | `review-flow.http` reads/verifies frozen package; staging-policy gate verifies bound admission. No source parser/media consumer found. | Source-backed no-change disposition; actual immutable HTTP and admission results remain required. |
| Production authorization / publish composition / recovery | Archive uses `rights.verifyArchived` → frozen `rights-record.verify`; Pages composition and recovery verify retained packages. No current article compilation found. | Preserve frozen historical verification, rights acceptance, predecessor leases and recovery semantics. No speculative parser/media install is required here on inspected calls. |
| Production live policy | `tools/release/live.cjs:10-22` uses `edition-archive.verify`, artifact verification and hosted requests. No source article rebuild found. | Existing live exact-byte/TLS/MIME/canonical/404 gates; retain no-change disposition. |
| Production Chromium smoke | `local-browser.cjs:819-901` directly inspects admitted public documents, article journeys and Color. `analytics.isolationJourney` is local mocked network setup; its separate `buildFixture` is not called by that path. `articleJourney` inspects DOM/HTTP and does not build article fixtures. Color model inspection reads scene owners, not article selection. | Existing quality npm, Chromium OS dependencies and pinned archive setup already precede browser. No source-backed parser/media omission found on this active smoke path. Retain all cases/widths/modes. |
| Optional full production/staging checker | `site-release-checks.yml:181-189` installs publishing/quality locks and full locked Python requirements before source/build. Linux/native/staging browser jobs already install parser and canonical media action at402-408,466-471,604-610. | Keep optional regression separate from release admission; its green status never replaces successful frozen candidate/live gates. |

The audit distinguishes current reachable source reconstruction from reading frozen artifacts. A new fixture call or changed consumer invalidates the affected no-change disposition and requires review before advancement.

## Intent / acceptance trace

| Requirement / owning AC | Independent check or owner gate | Current observation |
| --- | --- | --- |
| PB01; AC05/09 delivery | Job-local declared setup, clean parser/media/production derivative smoke, exact-source native candidate | Current native candidate failed parser setup; successful correction not yet observed. |
| PB02; AC05/11 | Isolated consumer inventory above plus review of actual final diff/calls | Bounded source audit completed; candidate-build parser/media correction required. |
| PB03; AC05 | Existing release-controller suite with meaningful missing/late/inapplicable negatives; mapped source selection | Missing focused setup oracle identified; future test execution pending. Raw first failure retained. |
| PB04; AC05/11 and accepted R11 | Full diff/byte comparison; CS01/04/05/08/09/10; four independent roles; current Basic/RI/CI/owning/native/full route | Checkout unchanged; no new candidate or final checks reviewed. |
| Production publication; AC04/07/08/09/10 | Author decision, authenticated staging→identical merged tree→frozen production admission/rights/archive→actual live article/PDF/HTTP/browser | Author publication authorization supplied in task/packet. No successful new frozen candidate or production result claimed. |
| AC09 external editions | Author manual platform editor/posting checks after verified website, then actual platform/backlink observations | Outside this correction and still pending; website release does not complete manual platform acceptance. |

## Authority and next gate

`guides/SITE-STAGING.md:175-200` explicitly keeps workflows/actions full-route and control=true; the technical-repository exemption does not apply. A new correction controller SHA needs a complete reviewed diff, all existing Basic/RI/owning/native/full owner staging and source-bound four-role results, then explicit maintainer trust for that exact full `reviewed_sha` and normal App/protected integration. Existing approval of a previous controller or author website-release intent does not supply an unseen controller SHA. Do not fabricate that trust or bypass protection.

After protected integration and reconciliation with current main, derive a successful frozen production candidate through existing authenticated staging-bound mechanisms. Preserve R11 manuscript/PDF/figures and public meaning/bytes except existing intentional production edition policy. Production dispatch uses the successful exact frozen candidate, matching rights inventory/owner decision and existing archive/live/recovery gates. Keep failed, staged, merged, frozen, served and accepted states separate. Do not tick whole original issue ACs on this preflight.

Next: record the parser+media dependency allocation and test-impact plan in the owning review, implement the bounded evidenced correction, obtain fresh final Requirements/Code/White-box/Exploratory results on the exact candidate, then advance through unchanged full/control gates. Re-read only changed source and invalidate affected evidence if identities change.
