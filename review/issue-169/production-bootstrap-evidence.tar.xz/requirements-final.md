# Requirements & Acceptance — prepared production-bootstrap final source review

Date: 2026-11-07. Owner169. This is a continuation of this role's preserved first preflight, not a fresh-isolation execution. The first judgment remains intact in `requirements-preflight.md`. Later factual input identified the existing canonical media setup test in `tests/quality.test.cjs`; no current peer result, private author history or parent scratch notes were read. Provider context/model internals remain unknown; none-fork was stated in the original task and the orchestrator owns actual launch-response evidence.

## Verdict

The prepared workflow/test correction is consistent with PB01–PB04 and accepted issue169 scope. No blocking requirement or acceptance-design defect was found in the final inspected source delta. RA01 is addressed in source by both locked parser and canonical media setup. RA02 is addressed by extending the existing owning test, which evaluates job-local ordering and fail-closed applicability with meaningful negatives. The original suggestion of release-controller placement was a proposed treatment, not a requirement: reuse of the existing media-owner test avoids duplicate coverage and has an established source-selection route.

This is source acceptance within this role's remit. PB01 remains incomplete because the clean parser/media/production-build experiment is still pending at this review cutoff. Native/full staging, other role results, exact-head maintainer control trust, protected integration, successful frozen production candidate and actual live article/PDF verification are future gates. This review grants none of those outcomes and does not close whole original article ACs.

## Inspected identity and actual checks

- Base/HEAD: `8e0aa848aba08dc9407832ed56d8a6404f985ae7`; prepared dirty checkout, not an immutable final commit. Tracked delta contains only `.github/workflows/site-release-candidate.yml` and `tests/quality.test.cjs`. An untracked owning review report was listed but not read as candidate evidence or peer output.
- Final packet SHA256: `741342f553a18954c4bcef28c6d4da388519c46527d707a6e9e3e76c92d652e8`. Actual `git diff` for both source paths exactly equals `final.delta.diff`, SHA256 `e5734b3fd120c40d7c584e0425c873fd6a952c5cce272e3663f65df5e3114eee`. All19 final packet manifest paths matched actual bytes.
- Workflow SHA256: `fd994835d43df8453ce9168b7654b63ad0903eed1ad40d7999bff70f02e0773a`.
- Changed test SHA256 independently recorded because the final packet identifies it through its pinned diff rather than its path manifest: `3b2354926234793140efa50e5b687c273922deb2940964d5808e2f381672f777`.
- Common/role prompt identities unchanged from first preflight: `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` / `010e22ec72bb081a1041068f3128d4d2496f5dabe560e01ed83f02e3b442b7a6`.
- Independently executed `node --test --test-name-pattern='every article-compiling job prepares its own locked parser and canonical media' tests/quality.test.cjs`: exit0,1test,1pass,0fail/skip/cancel,183.633ms. `git diff --check`: exit0. These bounded observations are not full source or native acceptance.
- Inspected retained `quality-fixed.tap`: complete22tests/22pass/0fail/0skip/0cancel; SHA256 `f49ed0652acaf3cfcfb406c2cf8ebd209bc202806706f358357607fea1ebaf71`. This is retained author execution evidence, separately from the independent focused execution above.
- Inspected retained `baseline-regression-failure.tap`:1test/0pass/1fail, `media must be prepared in the consuming job`; SHA256 `fdf216877a7909d6fe96b4b4d3222a8a48842a88e6457a3cc4f08caba8048294`. It supports the reported missing-media failure class; its exact earlier source identity is supplied by the packet/history, not independently reconstructed here.
- Original native failure retained unchanged: SHA256 `ea4932bb816273829fc62986bae9cad6f4eb97c94f02d6a17128d461488e1a9f`.

## Requirement-to-evidence matrix

| Requirement / owning linkage | Final source and oracle | Observed result / remaining gate |
| --- | --- | --- |
| PB01; AC05/09 delivery | Candidate workflow inserts existing `npm ci --prefix tools/publishing/toolchain --ignore-scripts` and existing canonical media action before the freeze command. Dependency chain to article parser and media reconstruction independently established in first preflight. | Setup/order source correct; focused contract test passes. Actual clean parser/media/production-build smoke pending, so whole PB01 remains open. |
| PB02; AC05/11 | Same candidate build handles edition/rights/source package verification. Frozen preview publish, HTTP, production archive/composition/recovery, live policy and DOM/HTTP browser consumers retain source-backed no-change dispositions. Optional full checker already supplies its declared dependencies. | First-preflight audit reused because these actual consumer sources and production workflow are unchanged and packet hashes match. No new sibling omission demonstrated. |
| PB03; AC05 | `tests/quality.test.cjs:1197-1321` covers four isolated consumers: three browser jobs and candidate build. Each requires own parser/media before consumers, no `if`, no `continue-on-error`. Missing, late, conditional and ignored setup mutations must fail; existing action script interpreter export/failure cases remain. | Independent focused1/1; retained full module22/22; retained missing-setup regression failure and original native failure. Existing registry at `tools/quality/test-profiles.json:856-890` includes test, workflow glob and media-action/Python inputs with pr-targeted/staging/production membership. No new suite or registry change required. |
| PB04; AC05/11 | Only four production-candidate setup lines and focused owning test extension. No packages/locks, R11 source, PDF, figures, public renditions, budgets, admission gates, protected settings or production controller sources changed in actual tracked diff. | Source preservation supported for this prepared delta; CS01/04/05/08/09/10 final checks and independent code judgment remain part of complete route. Full final commit/metadata identity must be reconciled before acceptance reuse. |
| Production publication; AC04/07/08/09/10 | Existing successful staging→identical merged tree→frozen candidate/rights/archive→actual live HTTP/browser/article/PDF. | Owner publication intent supplied; new successful frozen candidate and live outcome unobserved. External platform posting remains author-manual under the established sequence. |

## Risks examined and limits

The regression parses actual workflow jobs rather than matching unrestricted file text. Requiring setup in each consuming job prevents a sibling job's environment from masquerading as this runner's dependency installation. Its recognized consumer set includes edition build, rights build and staging-package build, and refuses an empty inventory. Existing action checks preserve the canonical pinned interpreter, declared Pillow requirement, interpreter-path use and export only after success. The four workflow lines use exactly that action; no duplicate media owner or version change is introduced.

The test is a bounded policy/orchestration oracle and does not simulate every possible shell/GitHub expression. Clean actual consumer execution is therefore still necessary for PB01; unit success cannot establish native installed-package availability or successful production. Test existence and unchanged public-source paths do not establish successful live publication.

No full expensive suite, browser/staging campaign, external mutation, implementation edit or delegation was performed by this reviewer. Only the assigned final artifact was written. The completed delta was independently inspected rather than accepted from packet narrative.

## Next gates and evidence reuse

Complete and retain the clean consumer experiment, then current-source required local/native checks and all four role outcomes. Workflow/action control changes remain full-route under `guides/SITE-STAGING.md:175-200`; technical-repository exemption does not apply. Before protected integration obtain the maintainer's explicit trust for the actual final full `reviewed_sha`, alongside normal App/freshness/full staging obligations. Existing production authorization or an earlier controller approval cannot imply that unseen SHA decision.

This result is reusable only while both reviewed source byte hashes and relevant unchanged dependency owners match. Later report/catalog/derived-metadata/verbatim-receipt additions need final delta identity reconciliation under repository rules; changed meaning, source, selection, oracle or control policy requires affected review. Continue production only from a successful authenticated frozen candidate through unchanged rights/archive/live/recovery gates.
