# Independent White-box QA — production bootstrap, first audit

Date: 2026-11-07. Reviewer execution: `/root/prod_bootstrap_whitebox`.

**Verdict: block advancement of the unchanged baseline.** The failed candidate lacks its declared publisher installation, and the same candidate job will subsequently need the canonical Python/Pillow/WebP setup. Correct both together. No source-backed need was found to install publisher/media dependencies in the isolated frozen candidate publisher/HTTP jobs or the production authorization, publication, rollback or metadata-recovery consumers. This is a dependency preflight judgment, not final review of an implemented correction or permission to publish.

## Identity and independence

- Requested launch: `fork_turns="none"`; supplied task says provider internals unknown. My accessible context contains the role task and applicable system/project instructions, not author conversation. Actual provider memory/model/context internals remain unknown; this is not an isolation attestation.
- Owner169; criteria PB01–PB04 from the supplied packet. Scope: existing locked dependencies and setup ordering only; public/source bytes, versions, gates and budgets must remain unchanged.
- Inspected baseline HEAD `8e0aa848aba08dc9407832ed56d8a6404f985ae7`, branch `work/issue169-production-publisher-bootstrap`; worktree clean at inspection. This review did not independently fetch current GitHub refs or issue authorization; those remain orchestrator responsibilities.
- Packet `/workspace/scratch/a6215a1720e5/production-bootstrap/preflight-packet.json`, SHA-256 `53dd26af3e842fa18423f141d23dc665997b057c23407ff1b40663552a768a8d`. Independently verified all 19 listed source-file hashes against bytes on disk.
- Common prompt SHA-256 `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; White-box prompt `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f` (both included in the verified manifest).
- Read root instructions, README, relevant repository-map owners, dated MEMORY as a handoff only, CONTRIBUTING failure/test-impact/reviewer requirements, reviewer common/role prompts, and actual production routes. File inventory found no nested AGENTS/CONTRIBUTING files. No peer result, private history or parent scratch-note files were read. A follow-up from the orchestrator named source call sites; those were independently traced and were not accepted as conclusions. No external writes, implementation edits, delegation, full suite or staging campaign.

## Findings

### WB-PB01 — High: candidate builder has no publisher install

Evidence: `.github/workflows/site-release-candidate.yml:41–76` sets Node24.19.0 and then invokes artifact/Color/production-edition construction without `npm ci --prefix tools/publishing/toolchain --ignore-scripts`. The primary native log `/workspace/scratch/a6215a1720e5/evidence/production-candidate-first-failure.log:285–289,766–779` records the failed freeze step at source8e0aa848 and the exact stack:

`edition.cjs CLI build -> rights.write -> rights.compile -> hostedInventory -> articles.select -> article.loadArticle -> compile`.

`tools/publishing/article.cjs:340–374` explicitly requires the exact declared versions of unified, remark-parse, remark-gfm and remark-stringify before spawning `ast.mjs`. Installing only the quality toolchain or using setup-node cannot satisfy the publisher-local `tools/publishing/toolchain/node_modules` lookup. The raw failure is preserved; it is not evidence that later steps ran successfully.

Treatment: install the existing lock with the existing prefix and `--ignore-scripts` in **candidate/build**, unconditionally after Node setup and before the freeze step. No version or library changes. Affects PB01/PB02/PB04.

### WB-PB02 — High: the same candidate requires canonical media setup after parsing

Evidence: `tools/release/rights.cjs:214–224` invokes `articles.select`; `tools/site/articles.cjs:48–56` calls both `publisher.loadArticle` and `article-media.render`. `tools/site/article-media.cjs:10–35,87–126` invokes the selected Python interpreter and then recompiles the article using rendered media. The accepted `site/publications/sdlc-out-of-balance/profile.json:36–41` selects `webp-lossless` and equivalent images. Equivalent JPEG selection still executes the Python encoder; it does not bypass Pillow or its pixel/ICC equivalence checks.

`tools/publishing/web-media.py:25–32` requires the canonical Pillow pin and WebP1.6.0. Candidate/build currently has no `publication-media` action or equivalent setup. Ambient runner Python/Pillow are not a declared substitute. Separately, candidate `local.cjs --package-gate` calls `site/build.cjs --check` when `contentRelease` is absent (`tools/quality/local.cjs:290–319`); the build selects and renders articles (`tools/site/build.cjs:800–829`). Thus source branch conditions must not hide media setup even if accepted-generation artifact copying itself avoids recompilation.

Treatment: reuse `./.github/actions/publication-media` unconditionally in **candidate/build**, after Node setup and before the freeze step. This already pins Python3.12.14, installs only the canonical Pillow requirement, verifies Pillow/WebP, and persists the chosen interpreter using `GITHUB_ENV`. Its interpreter export is job-local and must not be assumed to cross a `needs` boundary. Do not install the full scanner requirements to solve this media need. Affects PB01/PB02/PB04. The media failure is a source-backed next-step risk, not an observed second native failure.

### WB-PB03 — Medium: current regression coverage excludes candidate setup

`tests/quality.test.cjs:1197–1260` checks canonical media setup/order for `site-release-checks.yml` staging/linux/native fixture-building jobs. It does not inspect candidate/build. Existing `tests/release-controller.test.cjs` tests production edition/staging admission/archives, but no candidate parser/media setup guard was found. Current setup omission therefore survives the existing media wiring test (actual bounded pass below).

Treatment: minimally extend the existing `tests/quality.test.cjs` dependency-setup contract to candidate/build, parsing the actual workflow and checking job-local, unconditional publisher and media installations before the freeze consumer. Exercise missing, late and conditionally excluded setup independently; a setup found in another job must fail. Check the publisher prefix plus `--ignore-scripts`, not a vague npm token. Reuse the existing media-action pin/environment verification rather than duplicating its script test. Affects PB03. The existing production workflow/browser/gate tests retain their behavior; no replacement pipeline is needed.

## Complete isolated-consumer audit and no-change dispositions

| Isolated job / operation | Actual call graph or branch | Required environment / disposition |
| --- | --- | --- |
| Candidate/build — authentication and retrieval | `pages.controller`, `staging-policy.authenticate`, `gh api`, `pages/unpack.py` | Node24.19.0; Git/gh and Python3 stdlib from the pinned Ubuntu24.04 runner. `unpack.py` imports only stdlib. No Pillow for extraction. |
| Candidate/build — accepted-generation artifact | `artifact.build -> stagedGeneration -> trustedContentBaseline`, fingerprint comparison and frozen copy; Color decoration and production edition transform | Git and Node; accepted-generation branch does not call `site.build` directly. Do not infer parser exemption for the entire job because subsequent rights/package branches do compile. |
| Candidate/build — production edition and rights | edition CLI additionally calls `rights.write`; explicit later rights build/verify reconstruct source rights via selected articles | Publisher parser + canonical media required before freeze. Findings above. Rights verify also compiles; setup must persist for all later shell steps. |
| Candidate/build — bind and package gate | `staging-policy.bind`, `local.gate(profile=package)`, staging-package build | Frozen bind and package operations; package gate additionally runs full source check when `!manifest.contentRelease`, reaching parser/media. Same already-prepared job environment suffices; no scanner/browser dependency needed. |
| Candidate/publish | `review-flow.configuration`, `staging/package.verify`, `release/edition.verify`, Wrangler Action deploy | Frozen byte/descriptor checks, no `rights.compile`, article selection or fixture build. Node already present; Wrangler Action declares version4.147.0. No parser/Pillow setup change justified. |
| Candidate/http | `review-flow.http -> pkg.verify`/HTTP exact-byte checks; `staging-policy.gate -> validate` | Node/fetch + frozen rights/manifest verification. Does not call source rights verification or builders. No parser/Pillow setup change justified. |
| Production/disabled | one intentional exit1 | No content tooling. |
| Production/authorization — publish/rollback/recover | `release/actions.resolve -> authenticate/controller`; API/source/protection/request/archived-identity checks | Node and API actions; no source article/media compilation. Any predecessor upload inspection in `pages/controller.uploadedInventory` uses Python3 stdlib. No parser/Pillow setup change justified. |
| Production/publish — normal frozen admission/archive | `actions.prepareArchive -> controller.admission -> edition-archive.verify`; `rights.verifyArchived -> rights-record.verify`; `package.py pack`; archive verification; `actions.compose -> pages/package.build` with trusted rights digest | Frozen inputs use `rights-record` byte/binding validation. Importing `rights.cjs` is not calling `rights.compile`. Python3 package uses only gzip/hashlib/io/json/sys/tarfile/pathlib; Git/gh/tar from runner. No parser/Pillow setup required. |
| Production/publish — explicit rollback | `prepareArchive` rollback branch restores accepted archive, `package.py unpack`, `archive.verify`, historical `edition-archive.verify`, then same composition and live checks | Same stdlib/frozen consumer disposition. Historical rights must stay frozen; installing current parser does not improve this invariant. |
| Production/publish — post-live HTTP/policy | `pages/http.check`; `release/live.check -> edition-archive.verify + artifact.verify + hosted.verify` | Node/fetch, frozen bytes only. JPEG dimensions use Node byte parsing (`edition-archive.jpegDimensions`), not Pillow. No parser/media additions. |
| Production/publish — post-live browser smoke, including rollback target | `local-browser.main -> analytics-browser.isolationJourney`; tag journey; hosted navigation scenarios; `articleJourney`; optional content journey; Color smoke | Existing quality npm, Playwright Chromium system dependencies, browser archive setup already precede deploy/browser. No source article/media fixture producer on these paths; details below. Retain setup unconditionally for both publish and rollback. |
| Production/publish — automatic failed-transition rollback | retained previous Pages bytes uploaded before live write; deploy previous artifact; `actions.verifyRecovery -> pages/http.ready`; `recover` metadata restoration | Reuses prepared artifact and stdlib/API environment in the same job; no source builder/browser fixture compilation in recovery itself. No parser/Pillow additions. |
| Production/recovery — first-release metadata compensation | authenticated ZIP extraction via `pages/unpack.py`; `actions.recoveryInputs/recoverFailed -> canonicalPredecessor/migration` | Node, gh and Python3 stdlib. `pages/migration` operates verified predecessor packages/HTTP state; no article parser or media production. No dependency change justified. |

### Browser fixture distinction

The actual smoke call graph is material: `local-browser.cjs:822` calls **isolationJourney**, whose implementation (`analytics-browser.cjs:36–169`) synthesizes a small HTML string using the actual integration factory, with controlled route fulfillment, fake token and local network sink. It does not call `buildFixture`. `analytics-browser` top-level `content.catalog` is pure catalog validation, not source article loading.

By contrast, `analytics-browser.cjs:453–495` **buildFixture/journeys** clones/copies source and invokes `site/build.cjs.build` and preview generation. That branch does require parser/media tooling and is the reason staging/full functional jobs use publication-media. It is not reached by the production `local-browser --smoke` call.

`article-browser.cjs:1924–1990` takes already-passed descriptors and an existing browser, then executes normal/fallback journeys against hosted DOM/resources; it does not create articles or PDFs. The Color smoke (`local-browser.cjs:901 -> color-browser.main({smoke:true})`) consumes the frozen artifact; its scroll model helper invokes `site/build.model/configuration`, which constructs scene/model inputs, not `site/build.build` or article selection. Article tags likewise use the browser API plus supplied index/descriptors. Scene-model construction and inline browser fixtures must not be equated with a full article-building fixture.

## Risk → scenario → oracle → check allocation

| Risk / AC | Structural fault and bounded scenario | Independent oracle | Existing/proposed route |
| --- | --- | --- | --- |
| PB01 parser missing or wrong location | pristine candidate/build with no inherited node_modules | `article.compile` exact package/version lookup and real minimal Markdown parse succeeds | Extend existing quality setup-order regression; one isolated install + parser smoke before native/full continuation. No upgrade. |
| PB01/PB02 media serial failure | accepted image article selected after parser setup; no ambient media env | canonical action exports actual selected interpreter; `article-media.encode` passes Pillow/WebP/pixel checks | Reuse existing quality media-action contract; extend candidate setup wiring and perform bounded real encoder smoke after setup. |
| PB03 false setup guard | delete setup, move after freeze, add excluding `if`, place it in sibling job | every variant rejects while unchanged eligible workflow passes | Mutations of parsed in-memory workflow in existing test, not edits to repository files. Do not use token-presence-only assertions. |
| PB02/PB04 unnecessary installs or historical recomputation | frozen normal/rollback/publication/live consumers | frozen rights digest, archive bytes and historical edition remain exact without source parsing | Retain existing admission/archive/rollback tests and scoped post-live smoke; source-backed no-change rows above. No additional full source-build test in publisher. |
| PB04 source/byte/gate drift | proposed correction diff | only setup/regression/registry/evidence owners change; no source/tool versions/budgets/gates | Code/style/RI checks and required exact-source native/full/control route remain orchestrator gates. |

`tests/quality.test.cjs` already belongs to permanent `pr-targeted`, `staging`, `production` profiles and its inputs already include `.github/workflows/**`, `.github/actions/publication-media/**`, the Python media owner and canonical requirements (`tools/quality/test-profiles.json:856+`). Keep that selection and extend this existing setup owner rather than creating a competing suite. Add publisher declaration/lock input paths if the new assertion reads them. `tests/release-controller.test.cjs` independently covers both production workflows and should retain its historical archive, refused admission and recovery cases unchanged.

## Actual bounded execution (all commands exit0)

Environment Node `v24.22.1`, not native pinned24.19.0. These observations prove the listed local checks only; installed dependencies were already present. No clean-install or native production claim is made.

1. `node --test --test-name-pattern='every fixture-building browser job prepares the same canonical media interpreter' tests/quality.test.cjs`

   Raw result: `tests 1; suites 0; pass 1; fail 0; cancelled 0; skipped 0; todo 0; duration_ms 170.803461`. This validates existing release-checks/media action contract but demonstrates its candidate coverage gap.

2. Inline Node diagnostic verified the 19 packet hashes, parsed `site-release-candidate.yml` using existing quality `yaml`, located the first freeze consumer, and asserted both candidate setup omissions. Raw result:

   `packet manifest verification PASS: 19 files; repository HEAD 8e0aa848aba08dc9407832ed56d8a6404f985ae7`

   `candidate setup omission reproduced by parsed job inspection: {"firstConsumer":4,"publisherSetup":-1,"mediaSetup":-1}`

   It then required actions/live/local-browser/analytics-browser/article-browser/color-browser entry modules: `module-load audit PASS; 6 entry modules load; import alone is not build/fixture execution`. This is only a load check, not a dynamic smoke/call-graph coverage result.

3. Inline actual `article.compile('# Bootstrap smoke\n\nParser works.\n', [], {title:'Bootstrap smoke'})`, asserting rendered output contains `Parser works`: `existing-environment parser smoke PASS; not clean-install proof`.

4. Inline generated a 1×1 RGBA PNG in memory with ambient Python, passed it to actual `article-media.encode`, and asserted 1×1 WebP plus declared Pillow13.0.0/WebP1.6.0. Raw result: `actual media encode smoke PASS: 1 image; canonical Pillow13.0.0/WebP1.6.0; ambient interpreter; not clean-install proof`.

No measured structural-coverage percentage, browser launch, live network test, full release-controller suite, native run, staging or production action was performed. Those remain distinct evidence. Missing/late/excluded setup negatives are recommendations for the implementer, not executed regression tests. First judgment preserved here before any changed-candidate review.
