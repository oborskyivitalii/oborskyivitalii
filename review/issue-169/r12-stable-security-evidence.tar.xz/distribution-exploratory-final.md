# Exploratory / Interaction QA — first independent result

Verdict: PASS for bounded preparation/operator reading, with hosted and native-editor interaction gates NOT OBSERVED. This result does not approve whole COPY/DELIVERY acceptance, Ready/stable admission, merge, production or posting.

## Identity and scope

Role: separate nonauthor Exploratory / Interaction QA; task handle `/root/r12_distribution_exploratory`. Requested fresh role parameters supplied by orchestrator: none, no model override. Provider isolation/model internals are unknown; no peer reports, MEMORY or parent scratch notes were read. Repository HEAD observed `937623a2ed7a5d32238413fc77364102c3ae7f7b`, branch `work/issue169-r12-security-correction-20261110`; prepared dirty worktree, not clean checkout. Packet SHA-256 `57d4e506d0b623aeb8239afae349ce4d7247619196a35684fb19dc64d50c70d5` verified. Read AGENTS, common and role prompts, README, relevant policy excerpts and actual supplied material. No nested AGENTS found under site/ or agents/.

Bounded charter (90-second read/check target): walk the operator route from accepted R12 manuscript to LinkedIn/Medium kit, image transfer instructions, final argument/call to action, canonical/materials navigation, website material declaration and publish boundary. Assess applicable interactive surfaces without fabricating observations. No browser, code/source edits, external writes or delegation. Only this assigned result artifact is written.

## Executed observations

- Operator preparation route: INSTRUCTIONS identifies R12, pending canonical, planned site URL, copy-ready files, image upload positions, captions/alt/credit recheck, actual platform verification and reciprocal pair. Expected preparation now and publication after verified website: observed consistent with current COPY and ARTICLE-WORKFLOW.
- Manuscript/kit reading: LinkedIn and Medium Markdown files are byte-identical; their HTML files are byte-identical per verified hashes. New ending, context-specific delegation and ownership-cost clause retained in all four outputs (below). Manuscript literal full-substring comparison is false because rendition changes image paths/furniture; this is not evidence of lost prose and was not used as a parity pass.
- Five ordered image records are present with meaningful alternative text, captions and credits. Local upload files and copy-ready embedded images have matching actual digests; captions distinguish conceptual illustration from measurements. This is source/bytes inspection, not visual rendering or native-editor transfer proof.
- Planned footer links point to article and `#article-materials`, with label “Illustrated PDF and other formats”. Generated site contains that exact section ID, public “Download the illustrated PDF” anchor, description/credit and digest-addressed PDF target. Native materials source binds R12 and actual PDF digest. Materials discoverability is established at generated-source level only.
- Native editor journey is applicable: select-all/copy, paste, manual images and caption/alt/source inspection. No native editor supplied/observed; formatting, paste fidelity, focus, keyboard interaction, mobile reflow and image upload remain NOT OBSERVED, not N/A.
- Hosted website download journey is applicable: follow materials footer, locate PDF, download and inspect bytes/current edition. Current URL was not supplied and browser use prohibited until then. No public/current hosted click, status/MIME/download or layout observation is claimed.
- Policy route: COPY explicitly permits preparation now; actual platform URLs/dates/events and reciprocal parity stay pending after corrected website verification. Full current checks/full stable then STOP/show is the candidate authority boundary; none of these live delivery outcomes were verified by this review.

## Actual bounded checks

- linkedin.md: exact new ending present=True; context-specific operating models=True; total-cost ownership clause=True
- medium.md: exact new ending present=True; context-specific operating models=True; total-cost ownership clause=True
- linkedin-copy-ready.html: exact new ending present=True; context-specific operating models=True; total-cost ownership clause=True
- medium-copy-ready.html: exact new ending present=True; context-specific operating models=True; total-cost ownership clause=True
- images/01-hero.png: local=3fb21ca8f7aae0ebe85f9da0cc5aaf5e124deb916d9fc625d3a46e4dfd33293f; upload/embedded match=True; alt match=True; caption/credit present=True
- images/02-delivery-capacity-r6.png: local=327adbaf3721383619fd5b67de49a5792cf0470d298c4d43080570f9a79ad5d5; upload/embedded match=True; alt match=True; caption/credit present=True
- images/03-review-learning-r7.png: local=372ca25f635dbcc8440381a4e35027806f6b61168e9a27c1723f688741bf1c43; upload/embedded match=True; alt match=True; caption/credit present=True
- images/04-comprehension-gap-r7.png: local=338acabde7cd23ce93534c23a0bce2e71978a69c246feade8d779850af8c61b1; upload/embedded match=True; alt match=True; caption/credit present=True
- images/05-asymmetry.png: local=65741f7bf96495d834a4163e4122b2c03d0b5e0e966048679bf144d4925a7249; upload/embedded match=True; alt match=True; caption/credit present=True

One attempted read helper failed immediately with `ModuleNotFoundError: No module named bs4`. No source was changed and no dependency was installed. Diagnosis: absent optional parser, not candidate failure. The bounded follow-up used Python standard library HTMLParser. An intermediate regex extraction printed excessively large embedded image content and was truncated; no conclusion relies on that truncated image output. Final hash/alt/caption extraction used the bounded parser above.

## Findings and remaining gates

No source-level preparation defect found in the examined operator journeys. Medium/LinkedIn native paste and actual hosted PDF click are material remaining observations for COPY/VISUAL/DELIVERY. They are limitations of this execution, not a proposed scope expansion or a reason to call those criteria complete.

Existing/proposed mapping: publisher/planned-link/material source invariants map to existing `publishing.test.cjs`, `publication-history.test.cjs`, and `article-materials.test.cjs` through SITE-CHECK-PROFILES; not executed here. Actual current staging desktop/mobile normal/no-JS material navigation belongs to the existing hosted affected-reader/media observations; designed but NOT OBSERVED here. Actual platform paste/image order/captions/alt/backlinks remain manual native-editor COPY owner observations after website verification; proposed/deferred, not executed. No universal device matrix or new UI tests proposed.

## Actual identities

All 16 packet file hashes recomputed and matched at inspection. Common and role prompt identities appear below. Hashes bind bytes, not comprehension or runtime behavior. Recheck changed relevant bytes before accepting this result.

| Source | Actual SHA-256 | Packet |
| --- | --- | --- |
| `AGENTS.md` | `31ef44be1936809de5690da0b505fba5cf600f62e9a33d34b9d90e806387ae4a` | match |
| `CONTRIBUTING.md` | `0dc5be319f0269b4ba56751348dc1758ca874cb0f067b440b2b0d60a6d8b577a` | match |
| `agents/reviewers/README.md` | `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb` | match |
| `agents/reviewers/exploratory-interaction-qa.md` | `280feac9d22508fbcef6e7181feaf3625d45b1718fd833576a0e8fb9520c295a` | match |
| `.github/acceptance/issue-169.json` | `c486705f7bed1230888491958d6651c87edde53d6a9d228d0502c6d4146856ce` | match |
| `site/publications/sdlc-out-of-balance/manuscript.en.md` | `4ed3380c73f46e7e9bf086fa2f1c99f5183fc0ccb16b7b1f270276173e5f1f8d` | match |
| `site/publications/sdlc-out-of-balance/materials.json` | `ae125c2278f00d9889551c5440f51ac8a0be3491f99e519a9610fe1a325160c3` | match |
| `site/assets/publications/sdlc-out-of-balance/materials/reading-r12.pdf` | `c3686dce007b399d3fb175d5b235a51b1000500a3e4bc6f024be9767bfb33996` | match |
| `docs/articles/the-sdlc-is-out-of-balance.html` | `49e4d2b89531bf7e0cecdc2f2c91d2bd22a86aec9d71e1b1c2632cb1464e39b3` | match |
| `dist/publications/sdlc-out-of-balance/85133c2b45ac42108a3476d4bb8127063571b6d5e5012c66c99b7e297ef53cdc/manifest.json` | `000e4ffdfa2806be327273a21168d9c3244b36109798e297b842108684c95086` | match |
| `dist/publications/sdlc-out-of-balance/85133c2b45ac42108a3476d4bb8127063571b6d5e5012c66c99b7e297ef53cdc/linkedin.md` | `c25c0805012ca92a9f72803f33565cbc98f1f3b83be35e52cdba5470bc822f4c` | match |
| `dist/publications/sdlc-out-of-balance/85133c2b45ac42108a3476d4bb8127063571b6d5e5012c66c99b7e297ef53cdc/medium.md` | `c25c0805012ca92a9f72803f33565cbc98f1f3b83be35e52cdba5470bc822f4c` | match |
| `dist/publications/sdlc-out-of-balance/85133c2b45ac42108a3476d4bb8127063571b6d5e5012c66c99b7e297ef53cdc/linkedin-copy-ready.html` | `4b97510224a5d859bf8df77da321cb4dafe3181d3085b6dc3de8b38633902e39` | match |
| `dist/publications/sdlc-out-of-balance/85133c2b45ac42108a3476d4bb8127063571b6d5e5012c66c99b7e297ef53cdc/medium-copy-ready.html` | `4b97510224a5d859bf8df77da321cb4dafe3181d3085b6dc3de8b38633902e39` | match |
| `dist/publications/sdlc-out-of-balance/85133c2b45ac42108a3476d4bb8127063571b6d5e5012c66c99b7e297ef53cdc/INSTRUCTIONS.md` | `38759b4074e9eab76e2a7e3e1ddc6b8d5286818d5a27338d1312320ab32ae2c1` | match |
| `dist/publications/sdlc-out-of-balance/85133c2b45ac42108a3476d4bb8127063571b6d5e5012c66c99b7e297ef53cdc/medium-upload-kit.json` | `4942efd97a7d890e2a1ce620303c8476caab36676ef0c5c42076f49d4b24b1be` | match |
