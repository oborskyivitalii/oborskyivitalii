# Exploratory / Interaction QA — security proof and optional retention delta

Verdict: bounded reader/download/retention applicability PASS. Current accepted article/PDF/materials and five figures have no byte delta; only two explicitly optional preapproval R12 snapshot endpoints are removed from served historical resources. No new actual hosted download/mobile/no-JS observation; that gap stays pending. No security or full-staging acceptance inferred.

Same-role continuation, <=90sec, read/check-only, no browser/source edits/external writes/delegation. No current peers/MEMORY/parent notes opened. Input packet /tmp/issue169-r12/stable/security-candidate-packet.json SHA256ae73360e3200981beab204ff697f938716c5528db34992c6b6488c9efaf225fb verified. Observed HEAD/base937623a2ed7a5d32238413fc77364102c3ae7f7b. Prepared dirty security/optional-retention subset, not clean Git. Scope authorization comes from supplied task/packet, not any peer verdict.

Charter: independently compare accepted native paper/download/artwork, inspect removed endpoint selection and remaining retained byte closure, check for current public references to removed IDs, then determine whether old own UX evidence applies. No new visual/browser execution claimed.

## Executed observations

| Case | Expected | Observed | Result |
|---|---|---|---|
| Native article | Accepted body/byline/figures/download unchanged | Exact bytes equalbase; SHA25649e4d2b89531bf7e0cecdc2f2c91d2bd22a86aec9d71e1b1c2632cb1464e39b3 | Pass |
| Canonical source | Accepted prose unchanged | Exact bytes equalbase; SHA2564ed3380c73f46e7e9bf086fa2f1c99f5183fc0ccb16b7b1f270276173e5f1f8d | Pass |
| R12 PDF/materials | Same approved PDF and ordinary native target | PDF bytes equalbase SHA256c3686dce007b399d3fb175d5b235a51b1000500a3e4bc6f024be9767bfb33996; materials declaration equalbase SHA256ae125c2278f00d9889551c5440f51ac8a0be3491f99e519a9610fe1a325160c3 | Pass |
| Five images/download inventory | Existing current article resources intact | Current HTML contains five img elements and same immutable reading-r12.pdf href under c3686dce… | Pass/source |
| Removed optional endpoints | Only identified preapproval R12 Article/Writing snapshots removed from retained manifest/rights | Manifest loses exactly article-snapshots/58c70d6edea51b0dd47fefe3c80cb1c78c59e24a8956093616fee4229786dc98/the-sdlc-is-out-of-balance.html and snapshots/412f5b5cd2d1991265f5b6dd9d899516e79e8f4f78bd3d8c59f63975bd72b52e/writing.html; all remaining mapping values unchanged. Rights diff removes only matching two declarations | Pass within authorized scope |
| Remaining history resource bytes | Preserve R11/published closure and all remaining retained nodes | Independently hashed every remaining retained manifest file in both site/retained and docs; zero missing/hash mismatches. Retained reading-r11.pdf remains SHA256568c87ea56d054d6d5cdbcd647e878bcd122d688da5cb2370fb2b0cb3a914d58 | Pass |
| Current public dangling references | No active current docs link to removed optional IDs | rg over currentdocs found no reference to either removed snapshot identifier | Pass/source |
| Current hosted download/mobile/no-JS | New exact served material journey required | No new actual URL provided or browser action executed | Pending/not observed |

Actual diff scope includes generated maps/RI manifests, optional source+docs snapshot deletion, retained/rights/output locks, offline bundle manifest and checksum ledger. Unlike prior offline-only correction, complete docs diff is nonempty specifically because these two optional HTML endpoints are deleted. Do not call the entire public tree byte-identical: current accepted reader/PDF are identical, optional historical served URLs are intentionally withdrawn by this scope.

Existing own five-page PDF visual observations remain reusable against exact SHA; prior hosted754c normal desktop body/figures/anchor observations remain limited to unchanged content at the original origin. Local source deletion does not alter the previously observed immutable Cloudflare deployment, but this continuation did not recheck that external origin or attest its current availability. Git historical source is not erased by working-tree deletion.

No additional reader-interaction defect found. Security ledger467tuple proof validity, scanner outcome, secret absence and admission are outside this role's UI observation and must use their actual independent source/security checks. Do not infer them from no UI delta. SITE-CHECK-PROFILES existing fullstable source/hosted route remains; no duplicate browser campaign for ledger metadata is warranted, while actual newly exposed download/mobile/no-JS observations remain required. Stable then STOP; no production/platform authority.
