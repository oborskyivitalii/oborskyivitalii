# Independent White-box QA: issue 169 R12 security correction

Verdict: PASS for the bounded security-ledger correction checks below; this is not Ready/full-stable acceptance. Current security/full CI/stable results were not supplied or observed. Their gates remain pending. No source or test edits, external writes, deployment, merge or delegation performed.

## Identity and independence

Reviewed prepared working subset at `/workspace/scratch/faafe921a49f/r12-work`, HEAD `937623a2ed7a5d32238413fc77364102c3ae7f7b`; working tree is dirty/staged and unstaged, not a clean checkout. Packet SHA256 `35e2009a19e45177fb7b04bbf230c45ae4671a457e83fb8c8f7f987598d88174`. Every packet-referenced file SHA256 matched at initial and final checks. Proof gzip SHA256 `c97a46e3e3d9b62ea0b49b7f7d1239ee00864a1342cd6ab88c59d71dae1165d0`. Common prompt `2bcb3978b499d35bb0850aead987e5b7e07fc75cf9095552c0fcab07ff24faeb`; role prompt `832762ea95a540fd6fce09d9ca75084ac3573ee100dd67081d99ba7ac528596f`.

Read role/common, root AGENTS, README, relevant map, scanner/admission owners and exact supplied evidence. Did not read MEMORY, peer outputs, parent notes or unrelated history. Launch fork parameters/provider context/model internals are not observable from this reviewer; orchestrator must retain actual clean-context launch evidence. This report cannot attest provider isolation.

## Risk → structural fault → executed oracle

| Risk / invariant | Fault/scenario | Independent expected oracle and result |
|---|---|---|
| Prior authority preserved | Overwrite/reorder existing ledger | Compared HEAD JSON: all 3214 prior finding objects/order/reasons exactly equal candidate prefix; exactly 467 appended IDs equal proof set. PASS. |
| No broadened scanner | Changed inputs/rules/bounds/other ledgers | HEAD byte comparison: scanners.cjs, generated-checksums.cjs and all other three ledgers unchanged. Read closed four-file loader, exact schema, duplicate ID checks and 2,000,000-byte bound. Candidate 1,888,630 bytes and actual loadSecretReviews succeeds. PASS. |
| Exact candidate tuple | Wrong original value/location or stale current occurrence | For all 467, recomputed SHA1(value), path/type/hash ID, required Hex rule, current literal occurrence and original Git source line occurrence. No errors. PASS. |
| Exact refusal | Wrong path, type or value | Exercised actual reviewedSecretFinding: 467 positives and 1401 negatives (one changed path, Secret Keyword type, changed hash per row). Every negative refused. PASS. |
| Byte identity proof | Fabricated declared hash | Independently SHA256-hashed all 499 current-file annotations, all 503 protected-base annotations (Git show bytes/length), four immutable manuscript blobs. All matched. These counts are annotations, not distinct candidate rows. PASS. |
| Archive preservation | Wrong member/locator/original | All 33 archive-index items: ZIP full hash, member hash/length, exact Git protected-base bytes, current locator hash/length and introduction commit object existence. PASS. Commit existence is not a full historical first-introduction proof. |
| Historical semantics | Treat semantic declaration as byte hash | Independently reconstructed canonical semantic identity from four historical metadata Git blobs plus edition source; verified each metadata blob at stated commit/path. R3/R4/R9/R10 digests all matched. PASS. |
| Current semantic/material/AST | Wrong producer or field | Independently reconstructed current semantic JSON digest and current material approval binding. Native compiler loaded current article and independently canonical-hashed AST nodes; exact profile block digest found once. PASS. |
| Hosted rights/material renderer | Hash raw rather than hosted assets | Independently built hosted rendition resource identity and JSON-hashed rights record; native material renderer output binding matched exact candidate values. PASS after diagnostic described below. |
| Accepted content and optional removal | Delete published content | Git deletion inventory contains exactly two snapshot HTMLs in docs plus their two retained twins. No site/publications or docs/article-media diff against HEAD: accepted current paper/PDF preserved. PASS for this diff; publication history classification is bounded to supplied evidence. |

## Execution record and interpretation

All completed Python/Node checks above exited 0 except one deliberately recorded diagnostic mistake: rights reconstruction initially used raw loadArticle assets and exited 1, producing `1f991968267d5437c5f707b29a26e8a4297bda8dc199f0d35a607c30645ebfe6` instead of hosted `1b0bbd38a454694aa823c4a268b39ebd7a4e72ffa1d83df2833a75c97841fb40`. Inspection of articles.cjs select established the required article-media.render/social stages. The subsequent changed diagnostic used that actual pipeline and matched rights and material renderer binding. This is reviewer-oracle setup correction, not a candidate fix or unchanged blind rerun.

Executed checks used inline Python stdlib hashlib/subprocess/zipfile and inline Node assert/crypto against actual owners, without running the author's prove-values.py. One initial Python invocation yielded without retained session output; its result is not counted. The later complete invocation produced explicit zero-error accounting and exit 0. No branch-coverage measurement claimed.

## Finding and limits

Low, evidence consistency: `/tmp/issue169-r12/stable/security-disposition.json` field `proofSha256` retains `8beb23ad...`, whereas current proof gzip is `c97a46e3...`. The replacement packet and proof-annotation-correction.json correctly bind current bytes. This is a stale summary pointer, not a candidate tuple/proof failure; refresh or explicitly supersede before treating that summary as final evidence.

No blocker found in executed security-correction checks. Protected invariant: every addition remains a concrete path/type/value disposition; unrelated path/type/value stays rejected and prior authority stays intact. No general entropy exception was introduced.

Not independently replayed: every cold-native-builder/reconstructed historical revision annotation, complete R11 hosted rights/material reconstruction, ICC/pixel transformations, full protected tree enumeration, every historical introduction chronology, and full fresh detect-secrets/security/stable/hosted CI. Current/publication preservation checked against provided HEAD, not live production. No UI/browser interaction surface belongs to this ledger correction. Relevant integration remains security stage and the scanner/generated-checksum contracts mapped in tools/quality/test-profiles.json and guides/SITE-CHECK-PROFILES.md; this bounded check is additional review evidence and cannot replace required suite/profile execution. Ready and subsequent advancement must await those source-bound results and all mandatory independent-role/launch gates.
