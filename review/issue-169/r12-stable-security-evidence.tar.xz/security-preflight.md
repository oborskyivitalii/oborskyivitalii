# Requirements & Acceptance — security triage / optional preview preflight

Verdict: **the two unpublished pre-approval R12 snapshot declarations are optional and may be removed narrowly, together with their retained files and exclusive catalogue/rights entries.** They are not an author requirement or a previous-production retention obligation. Preserve the complete mandatory R11 production closure, current accepted R12 article/PDF, actual previous Cloudflare preview deployment and exact Git754c22a5 evidence. This source-scope correction is preferable to expanding scanner admission merely to retain an optional duplicate. It does not justify suppressing unresolved scan findings.

Same-role preflight continuation `/root/r12_requirements_clean`, before dependent edits. Actual HEAD937623a2ed7a5d32238413fc77364102c3ae7f7b, clean on inspection; raw report identifies treed290451bda23219bef2eddd62df68f0388bded80. Supplied immutable security packet SHA256 `0d6921641015fbd2f99331195e290cdb0c3287421eac7b17541239c99e006732` verified; every listed file/report hash matched. Raw detect-secrets SHA256 `a0cf12555744313642eabe138d9a48aa34631ac22e9363edbc047558ddb76eba`; filtered list `112769784670133303bd0cfc26db0d52831e70aa0fbbaa7f78c55657aabd73dd` independently counted483rows:481Hex High Entropy String,2Base64 High Entropy String. No finding values reproduced. Raw repository-security report explicitly passes=false, error `Scanner engines failed: secrets`; unchanged Semgrep/Bandit success cannot supply secrets acceptance.

No peers, MEMORY or parent scratch rationale read. Source/contract inspection and hashing only; no edits to sources/tests/ledgers, scanner execution, external writes or delegation. Only this assigned review written. Existing provider/context limitations remain.

## Retention requirement decision

`site/README.md:411–424` requires explicit import of **prior published versions** from a verified artifact and preserving every immutable input of the previous known-good package. It explicitly says current unpublished candidate snapshots are not retained implicitly. The no-automatic-pruning clause protects that previous-version continuity; it does not make every voluntarily copied unpublished preview a permanent production requirement.

The two questioned entries are:

- `article-snapshots/58c70d6edea51b0dd47fefe3c80cb1c78c59e24a8956093616fee4229786dc98/the-sdlc-is-out-of-balance.html`
- `snapshots/412f5b5cd2d1991265f5b6dd9d899516e79e8f4f78bd3d8c59f63975bd72b52e/writing.html`

I independently checked that neither exists in main's retained declaration and that neither identifier appears in main's original current article HTML. Prior own source-bound reviews identify them as the pre-PDF-approval R12 preview, added on implementation initiative. The exact article/PDF acceptance and stable instruction require current material delivery and R11 production preservation, not republishing this superseded preview in every future package. Their recoverable evidence remains Git754c22a5 and the unchanged already-issued preview deployment. Removal therefore changes optional retained scope, not the accepted paper or previous production.

Existing edition-retention producer validates every explicitly declared entry and follows immutable HTML dependencies; its tests expressly forbid silently retaining replaced active article snapshots. Remove the two declarations coherently rather than leaving missing declared files. Do not remove shared runtime/media dependencies needed by current R12, old R11 or other retained editions. Treat this as a reviewed bounded choice, not general pruning authority. If another real accepted known-good package or immutable document is found to require either exact path, retain it and return that new fact for affected review.

## Exact triage requirements and oracles

| Scope / AC | Required independent oracle | Acceptance boundary |
| --- | --- | --- |
|AC05/09 optional preview removal|Diff restricted to two optional retained files/declarations and exclusive inventory/rights entries; current MD/PDF/native content and mandatory R11 graph hash/closure comparisons|No R11 published bytes or required resource removed; preview evidence remains attributable to original source|
|AC05 scanner disposition|For every retained new tuple, exact path+type+hashed value matched to actual source location; recompute checksum/Git/blob/archive/member/binding from primary bytes|Grouping helps work allocation but cannot classify all481Hex rows automatically|
|Issue184 inventory identities|Recompute each actual referenced object's digest/size/path against immutable Git/archive/member bytes and original inventory semantics|A digest-shaped string alone is insufficient evidence; preserve archive recoverability and failed run history|
|Closed ledger authority|Append only individually proven exact findings in an existing permitted ledger; preserve all prior rows/order/reasons and other ledgers, scanner schema/rules/bounds|No new input, wildcard, broad entropy exclusion, scanner-control change or unsupported Base64 rule|
|Post-edit reconstruction|Existing producers regenerate maps/outputs; fresh exact locked security run and untriaged accounting|Removing optional source may remove its two real candidates; only fresh scan establishes resulting count|
|Current phase|Current checks/Ready/full stable then STOP|No production/merge/platform authority or separate PR185 stage|

Actual scanner entry validation permits Hex in the checksum ledger and a closed list of exact inventory Base64 tuples; the newly described preview-directory literal is not admitted merely because it is a path. Do not broaden that control or relabel its rule to fit the ledger. Removing the genuinely unnecessary source declaration is permissible; prove after regeneration that its two candidates disappeared because the source literal is absent, while scanners still inspect the complete intended current/required historical scope.

No individual false-positive disposition is approved by this preflight: the483candidate set has not been proved row by row here. Obtain source-bound per-ID evidence, affected independent review and exact-source successful security/check accounting before advancement. Existing byte/row/public/RI budgets remain unchanged. Prior failed scans and staging stay failed historical observations; final native stable result remains pending.
