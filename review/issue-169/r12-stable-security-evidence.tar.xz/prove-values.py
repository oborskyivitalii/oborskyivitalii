import json,pathlib,hashlib,subprocess,re,io,zipfile,collections
root=pathlib.Path.cwd(); dest=pathlib.Path('/tmp/issue169-r12/stable');base='a9f576918defbed3950c8ab95b4161be26e56ade';known=collections.defaultdict(list)
def add(v,why):
 if re.fullmatch('[a-f0-9]{32,64}',v) and why not in known[v]:known[v].append(why)
def hashbytes(b,why):
 h=hashlib.sha256(b).hexdigest();add(h,why);return h
def git(*args):return subprocess.check_output(['git',*args])
# Authenticate current tracked bytes and immutable production blobs, not declared digests.
for n in git('ls-files','-z').decode().split('\0'):
 if not n or not pathlib.Path(n).is_file():continue
 b=pathlib.Path(n).read_bytes();hashbytes(b,{'kind':'current-file-sha256','path':n,'bytes':len(b)})
entries=[]
for line in git('ls-tree','-r','-z',base).split(b'\0'):
 if line:
  meta,n=line.split(b'\t',1);mode,kind,sha=meta.decode().split();
  if kind=='blob':entries.append((n.decode(),sha))
baseby={}
for i in range(0,len(entries),80):
 group=entries[i:i+80];out=git('cat-file','--batch') if False else subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(x[1] for x in group)+'\n').encode());stream=io.BytesIO(out)
 for n,sha in group:
  header=stream.readline().decode().split();assert header[0]==sha and header[1]=='blob';b=stream.read(int(header[2]));assert stream.read(1)==b'\n';h=hashbytes(b,{'kind':'protected-base-file-sha256','commit':base,'path':n,'blob':sha,'bytes':len(b)});baseby[n]=(sha,h,len(b));add(sha,{'kind':'actual-git-blob','commit':base,'path':n,'bytes':len(b)})
# Every selected archive locator is authenticated independently from its ZIP and Git original.
index=json.load(open('review/issue-184/archive-index.json'));archives={}
for item in index['items']:
 ap=item['archive']
 if ap not in archives:
  b=pathlib.Path(ap).read_bytes();assert hashlib.sha256(b).hexdigest()==item['archiveSha256'];archives[ap]=zipfile.ZipFile(io.BytesIO(b))
 b=archives[ap].read(item['member']);assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'];assert baseby[item['path']][1:]==(item['sha256'],item['bytes']);add(item['sha256'],{'kind':'verified-archive-member-and-Git-original','archive':ap,'member':item['member'],'base':base,'path':item['path'],'bytes':len(b)})
 locator=pathlib.Path(item['path']).read_bytes();assert len(locator)==item['locatorBytes'] and hashlib.sha256(locator).hexdigest()==item['locatorSha256']
 c=item['originalWorkIntroductionCommit'];assert git('cat-file','-t',c).strip()==b'commit';add(c,{'kind':'actual-Git-introduction-commit','path':item['path']})
# Edition source pins are real Git commits/blobs and actual manuscript digests.
for p in pathlib.Path('site/publications/sdlc-out-of-balance/editions').glob('*.json'):
 d=json.load(open(p));s=d.get('source',{});c=s.get('commit');blob=s.get('blob')
 if not c or not blob:continue
 assert git('cat-file','-t',c).strip()==b'commit';b=git('cat-file','blob',blob);assert hashlib.sha256(b).hexdigest()==s['sha256'];assert blob.encode() in git('ls-tree','-r',c);add(c,{'kind':'actual-Git-manuscript-commit','edition':str(p)});add(blob,{'kind':'actual-Git-manuscript-blob','edition':str(p)});hashbytes(b,{'kind':'immutable-manuscript-sha256','commit':c,'blob':blob,'edition':str(p)})
# Own structured computations and historical semantic reconstructions are provided separately.
extra=json.load(open(dest/'computed-values.json'))
for v,items in extra.items():
 for item in items:add(v,item)
# Public client-side analytics identifier is byte-exact to the production script.
analytics='site/retained/runtime/1c34e64047482a214a50a115582adb08988fe8721f5ee651bd8a231a300e2cf7/analytics.js';b=pathlib.Path(analytics).read_bytes();old=git('show',base+':docs/'+analytics.removeprefix('site/retained/'));assert b==old
for v in re.findall(rb'"token":"([a-f0-9]{32})"',b):add(v.decode(),{'kind':'unchanged-published-client-beacon-identifier','commit':base,'path':analytics,'fileSha256':hashlib.sha256(b).hexdigest()})
rows=json.load(open(dest/'untriaged.json'));proved=[];unproved=[];removed=[]
for r in rows:
 p=pathlib.Path(r['file'])
 if not p.exists():removed.append(r);continue
 original=git('show','937623a2ed7a5d32238413fc77364102c3ae7f7b:'+r['file']).decode();line=original.splitlines()[r['line_number']-1]
 vals=[v for v in set(re.findall(r'(?<![a-f0-9])[a-f0-9]{12,64}(?![a-f0-9])',line)) if hashlib.sha1(v.encode()).hexdigest()==r['hashed_secret']]
 if (r['type']=='Base64 High Entropy String' and '58c70d6edea51b0dd47fefe3c80cb1c78c59e24a8956093616fee4229786dc98' not in p.read_text()) or (len(vals)==1 and vals[0] not in p.read_text()):
  removed.append(r);continue
 if r['type']=='Hex High Entropy String' and len(vals)==1 and vals[0] in known:
  proved.append({'id':r['file']+':'+r['type']+':'+r['hashed_secret'],'path':r['file'],'rule':r['type'],'hashedValue':r['hashed_secret'],'value':vals[0],'originalLine':r['line_number'],'sourceBlob':git('rev-parse','937623a:'+r['file']).decode().strip(),'proofs':known[vals[0]]})
 else:unproved.append({**r,'values':vals,'context':line[:250]})
result={'base':base,'originalScanSource':'937623a2ed7a5d32238413fc77364102c3ae7f7b','proved':proved,'removed':removed,'unproved':unproved,'archiveRowsVerified':len(index['items']),'protectedBlobsHashed':len(baseby)}
(dest/'proof-draft.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'proved':len(proved),'removedFiles':len(removed),'unproved':len(unproved),'unprovedPaths':collections.Counter(r['file'] for r in unproved)}));print(json.dumps(unproved[:4],indent=2))
